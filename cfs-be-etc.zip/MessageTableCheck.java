package com.gsenc.wsf.common.util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MessageTableCheck {

    private static final Pattern T_FUNCTION_PATTERN = Pattern.compile("t\\((.*?)\\)", Pattern.DOTALL);
    private static final Pattern ARGUMENT_PATTERN = Pattern.compile("(\"([^\"]*?)\")|('([^']*?)')|(`([^`]*?)`)");

    private static final String DB_URL = "jdbc:postgresql://13.124.203.107:55432/wsfdb";
    private static final String DB_USER = "developer";
    private static final String DB_PASSWORD = "ami2025!";
    private static final String FOLDER_PATH = "C:\\workspace\\ami\\wsf-fe\\src";

    public static void main(String[] args) throws Exception {
        Path rootPath = Paths.get(FOLDER_PATH);
        List<String> extensions = Arrays.asList(".js", ".jsx", ".ts", ".tsx");

        Map<String, String> keyValueMap = new HashMap<>();

        Files.walk(rootPath)
                .filter(Files::isRegularFile)
                .filter(path -> extensions.stream().anyMatch(path.toString()::endsWith))
                .forEach(path -> {
                    try {
                        keyValueMap.putAll(extractKeysFromFile(path));
                    } catch (IOException e) {
                        System.err.println("파일 읽기 실패: " + path);
                    }
                });

        System.out.println("🔎 추출된 키 개수: " + keyValueMap.size());

        Map<String, Integer> dbKeyCount = queryKeyCountsFromDB(keyValueMap.keySet());

        System.out.println("\n📌 DB에 3개 미만으로 존재하는 키:");
        int missingCount = 0;
        for (Map.Entry<String, String> entry : keyValueMap.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();

            if (key.contains("/api/v1") || key.contains("${") || !key.contains(".")) {
                continue;
            }

            int count = dbKeyCount.getOrDefault(key, 0);
            if (count < 3) {
                System.out.printf("%d [%s] → \"%s\"\n", missingCount, key, value);
                missingCount++;
            }
        }

        if (missingCount == 0) {
            System.out.println("✅ 모든 키가 3개 이상 존재합니다.");
        }
    }

    private static Map<String, String> extractKeysFromFile(Path filePath) throws IOException {
        Map<String, String> keyValuePairs = new HashMap<>();
        String content = Files.readString(filePath);
        Matcher matcher = T_FUNCTION_PATTERN.matcher(content);

        while (matcher.find()) {
            String inside = matcher.group(1);
            Matcher argMatcher = ARGUMENT_PATTERN.matcher(inside);

            List<String> args = new ArrayList<>();
            while (argMatcher.find()) {
                String val = argMatcher.group(2) != null ? argMatcher.group(2)
                        : argMatcher.group(4) != null ? argMatcher.group(4)
                        : argMatcher.group(6);
                if (val != null) args.add(val);
            }

            if (args.size() >= 2) {
                String key = args.get(0);
                String value = args.get(1);
                keyValuePairs.put(key, value);
            }
        }

        return keyValuePairs;
    }

    private static Map<String, Integer> queryKeyCountsFromDB(Set<String> keys) throws SQLException {
        Map<String, Integer> keyCounts = new HashMap<>();

        String sql = "SELECT msg_ctn, COUNT(*) as cnt " +
                "FROM tb_wsf_msg_m " +
                "WHERE msg_ctn = ANY (?) " +
                "AND lang_cd in ('ko','en','zhC') " +
                "GROUP BY msg_ctn";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            Array keyArray = conn.createArrayOf("text", keys.toArray());
            ps.setArray(1, keyArray);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String key = rs.getString("msg_ctn");
                int count = rs.getInt("cnt");
                keyCounts.put(key, count);
            }
        }

        return keyCounts;
    }
}

