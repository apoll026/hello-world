package com.gsenc.wsf.common.util;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.nio.file.*;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class MyBatisXmlParser {

    public static void main(String[] args) throws Exception {
        String rootPath = "C:\\workspace\\ami\\wsf-be\\src\\main\\resources\\sql\\primary\\core"; // 최상위 디렉토리 경로
        String outputPath = "crud_matrix.xlsx"; // 출력할 엑셀 파일 경로

        List<String[]> results = new ArrayList<>();

        // 1. 파일 탐색
        Files.walk(Paths.get(rootPath))
                .filter(Files::isRegularFile)
                .filter(path -> path.toString().endsWith(".xml"))
                .forEach(path -> {
                    try {
                        // 파일명(확장자 제거)
                        String fileNameWithoutExt = path.getFileName().toString().replaceFirst("[.][^.]+$", "");

                        // 2. XML 파싱
                        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                        dbFactory.setValidating(false);
                        dbFactory.setNamespaceAware(false);
                        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                        Document doc = dBuilder.parse(path.toFile());
                        doc.getDocumentElement().normalize();

                        Element root = doc.getDocumentElement();
                        if (!"mapper".equals(root.getTagName())) {
                            System.err.println("잘못된 XML 형식 (mapper 루트 아님): " + path);
                            return;
                        }

                        String namespace = root.getAttribute("namespace");
                        if (namespace == null || namespace.isEmpty()) {
                            System.err.println("namespace 없음: " + path);
                            return;
                        }

                        // 3. 하위 태그(id 찾기)
                        NodeList childNodes = root.getChildNodes();
                        for (int i = 0; i < childNodes.getLength(); i++) {
                            Node node = childNodes.item(i);
                            if (node.getNodeType() == Node.ELEMENT_NODE) {
                                Element elem = (Element) node;
                                if (elem.hasAttribute("id")) {
                                    String id = elem.getAttribute("id");

                                    String tagName = elem.getTagName().toLowerCase();
                                    String crudType = getCrudType(tagName);

                                    if (crudType.equals("?")) {
                                        continue;
                                    }

                                    // 저장: {namespace, id, 파일명, crudType}
                                    results.add(new String[]{namespace, id, fileNameWithoutExt, crudType});
                                }
                            }
                        }
                    } catch (Exception e) {
                        System.err.println("파일 파싱 실패: " + path + " - " + e.getMessage());
                    }
                });

        // 4. 엑셀 생성
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Mapper Info");

            // 스타일 생성
            CellStyle headerStyle = createHeaderStyle(workbook);
            CellStyle cellStyle = createCellStyle(workbook);

            // 헤더 작성
            Row headerRow = sheet.createRow(0);
            String[] headers = {"Class Name", "Query ID", "Mapper ID", "CRUD"};
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            // 데이터 작성
            int rowNum = 1;
            for (String[] result : results) {
                Row row = sheet.createRow(rowNum++);
                for (int i = 0; i < result.length; i++) {
                    Cell cell = row.createCell(i);
                    cell.setCellValue(result[i]);
                    cell.setCellStyle(cellStyle);
                }
            }

            // 칼럼 자동 너비
            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            // 파일 저장
            try (FileOutputStream fos = new FileOutputStream(outputPath)) {
                workbook.write(fos);
            }

            System.out.println("엑셀 파일 저장 완료: " + outputPath);
        }
    }

    // CRUD 타입 구분
    private static String getCrudType(String tagName) {
        switch (tagName) {
            case "select": return "R";
            case "insert": return "C";
            case "update": return "U";
            case "delete": return "D";
            default: return "?";
        }
    }

    // 헤더 스타일 (회색 + 볼드 + 테두리)
    private static CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        setAllBorders(style);
        return style;
    }

    // 데이터 셀 스타일 (테두리만)
    private static CellStyle createCellStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        setAllBorders(style);
        return style;
    }

    // 테두리 적용
    private static void setAllBorders(CellStyle style) {
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
    }
}
