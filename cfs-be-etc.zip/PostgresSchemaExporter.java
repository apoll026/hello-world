package com.gsenc.wsf.common.util;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.yaml.snakeyaml.Yaml;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class PostgresSchemaExporter {

    public static void main(String[] args) {
        String outputPath = "table_schema.xlsx"; // 엑셀 저장 경로

        try {

            String dbUrl = "jdbc:log4jdbc:postgresql://13.124.203.107:55432/wsfdb";
            String dbUser = "developer";
            String dbPassword = "ami2025!";

            try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword)) {
                System.out.println("DB 연결 성공");

                Map<String, String> columnComments = loadColumnComments(conn);

                try (Workbook workbook = new XSSFWorkbook()) {
                    Sheet sheet = workbook.createSheet("Schema");

                    CellStyle headerStyle = createHeaderStyle(workbook);
                    CellStyle cellStyle = createCellStyle(workbook);

                    int rowNum = 0;

                    DatabaseMetaData metaData = conn.getMetaData();
                    ResultSet tables = metaData.getTables(null, "public", "%", new String[]{"TABLE"});
                    while (tables.next()) {
                        String tableName = tables.getString("TABLE_NAME");

                        // 테이블마다 헤더
                        Row headerRow = sheet.createRow(rowNum++);
                        createHeaderRow(headerRow, headerStyle);

                        // 기본키 컬럼 수집
                        ResultSet pkRs = metaData.getPrimaryKeys(null, "public", tableName);
                        Map<String, Boolean> primaryKeyMap = new HashMap<>();
                        while (pkRs.next()) {
                            primaryKeyMap.put(pkRs.getString("COLUMN_NAME"), true);
                        }
                        pkRs.close();

                        // 컬럼 정보
                        ResultSet columns = metaData.getColumns(null, "public", tableName, "%");
                        while (columns.next()) {
                            String columnName = columns.getString("COLUMN_NAME");
                            String dataType = columns.getString("TYPE_NAME");
                            String isNullable = columns.getString("IS_NULLABLE"); // YES/NO
                            String columnDefault = columns.getString("COLUMN_DEF");

                            String columnComment = columnComments.getOrDefault(tableName + "." + columnName, "");

                            Row row = sheet.createRow(rowNum++);
                            createDataRow(
                                    row,
                                    tableName,
                                    columnName,
                                    dataType,
                                    "YES".equalsIgnoreCase(isNullable) ? "O" : "X",
                                    primaryKeyMap.containsKey(columnName) ? "O" : "X",
                                    columnDefault != null ? columnDefault : "",
                                    columnComment,
                                    cellStyle
                            );
                        }
                        columns.close();

                        // 테이블 사이 빈 줄
                        rowNum++;
                    }
                    tables.close();

                    for (int i = 0; i < 7; i++) {
                        sheet.autoSizeColumn(i);
                    }

                    try (FileOutputStream fos = new FileOutputStream(outputPath)) {
                        workbook.write(fos);
                    }

                    System.out.println("엑셀 파일 저장 완료: " + outputPath);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // application.yml 읽기
    private static Map<String, Object> loadDbProperties(String ymlPath) throws Exception {
        Yaml yaml = new Yaml();
        try (InputStream input = new FileInputStream(ymlPath)) {
            Map<String, Object> yamlData = yaml.load(input);
            Map<String, Object> dbProps = (Map<String, Object>) yamlData.get("database");
            if (dbProps == null) {
                throw new IllegalArgumentException("application.yml에 'database' 항목이 없습니다.");
            }
            return dbProps;
        }
    }

    // 컬럼 주석(comment) 읽기
    private static Map<String, String> loadColumnComments(Connection conn) throws SQLException {
        Map<String, String> result = new HashMap<>();
        String sql = "SELECT a.attrelid::regclass AS table_name, a.attname AS column_name, d.description AS column_comment " +
                "FROM pg_attribute a " +
                "LEFT JOIN pg_description d ON a.attrelid = d.objoid AND a.attnum = d.objsubid " +
                "WHERE a.attnum > 0 AND NOT a.attisdropped " +
                "AND a.attrelid IN (" +
                "  SELECT c.oid FROM pg_class c " +
                "  JOIN pg_namespace n ON n.oid = c.relnamespace " +
                "  WHERE n.nspname = 'public' AND c.relkind = 'r'" +
                ")";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                String tableName = rs.getString("table_name");
                String columnName = rs.getString("column_name");
                String comment = rs.getString("column_comment");
                if (comment != null) {
                    result.put(tableName + "." + columnName, comment);
                }
            }
        }
        return result;
    }

    // 헤더 한 줄 생성
    private static void createHeaderRow(Row row, CellStyle style) {
        String[] headers = {"테이블명", "컬럼명", "데이터 타입", "널 여부", "기본키 여부", "기본값", "컬럼 설명"};
        for (int i = 0; i < headers.length; i++) {
            Cell cell = row.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(style);
        }
    }

    // 데이터 한 줄 생성
    private static void createDataRow(Row row, String tableName, String columnName, String dataType,
                                      String nullable, String isPrimaryKey, String defaultValue,
                                      String comment, CellStyle style) {
        String[] values = {tableName, columnName, dataType, nullable, isPrimaryKey, defaultValue, comment};
        for (int i = 0; i < values.length; i++) {
            Cell cell = row.createCell(i);
            cell.setCellValue(values[i]);
            cell.setCellStyle(style);
        }
    }

    // 헤더용 스타일 생성
    private static CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        setAllBorders(style);
        return style;
    }

    // 데이터용 스타일 생성
    private static CellStyle createCellStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        setAllBorders(style);
        return style;
    }

    // 테두리 스타일 적용
    private static void setAllBorders(CellStyle style) {
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
    }
}