# 본 Python을 실행시킨 디렉토리 아래에서 html, java 파일에 포함된 다국어 처리 구문을 추출하는 프로그램. ( Back-End 용 )
# 추출된 다국어는 메시지 테이블에 insert 하여 다국어 적용될 수 있도록 하세요.
# 다국어코드는 com.menu.{menuid}, com.code.{groupcode}.{code} 는 각각 메뉴 / 공통코드에 사용되는 형태이며
#             tmpl.템플릿파일명 은 메일/결재 용 thymeleaf 템플릿 입니다.
#             
#
# Python 설치는 개발자용 설치 패키지를 참고하세요. - PIP 설치 가이드 참조.
# 
# 실행 예) C:\workspace\back-end\src> python multi-lang-find-be.py > out.txt

# 아래 쿼리를 활용하여 out.txt를 TB_WSF_MSG_TMP_M 테이블에 입력하고, tb_wsf_msg_m 테이블의 데이터를 갱신하세요.

# 이 테이블은 메시지코드 생성을 위한 임시 테이블 입니다.
# create table TB_WSF_MSG_TMP_M
# (
#   seq               NUMBER,
#   file_path         VARCHAR(4000),
#   msg_ctn           VARCHAR(4000),
#   MSG_TXT_CTN       VARCHAR(4000)
# );

# comment on table TB_WSF_MSG_TMP_M
#   is '메시지 입력 임시 테이블';


# 메시지를 새로 추가합니다. 
# insert into tb_wsf_msg_m
# WITH msg_tmp AS (SELECT Z1.*
#           FROM (
#                SELECT msg_ctn
#                     , MSG_TXT_CTN
#                     , FILE_PATH
#                     , RANK() OVER(PARTITION BY msg_ctn ORDER BY seq) AS rnk
#                  FROM TB_WSF_MSG_TMP_M
#                ) Z1
#          WHERE Z1.rnk = 1)
# select aa.msg_ctn
#      , aa.lang_cd
#      , replace(( select zz.MSG_TXT_CTN || '(' || aa.lang_cd || ')' from msg_tmp zz where zz.msg_ctn = aa.msg_ctn ),'(ko)','') as msg_txt_ctn
#      , ( select zz.MSG_TXT_CTN from msg_tmp zz where zz.msg_ctn = aa.msg_ctn ) as rmk
#      , ( select zz.FILE_PATH from msg_tmp zz where zz.msg_ctn = aa.msg_ctn ) as opt_val_ctn1
#      , '' as opt_val_ctn2
#      , '' as opt_val_ctn3     
#      , 'Y' as use_yn
#      , 'BE_EXTRACT' as DATA_INS_USER_ID
#      , '0.0.0.0'
#      , current_date
#      , 'BE_EXTRACT'  as DATA_UPD_USER_ID
#      , '0.0.0.0'
#      , current_date
# from (
# select a.msg_ctn as msg_ctn
#      , b.cmn_cd  as lang_cd
#   from msg_tmp a
#   cross join ( select bb.cmn_cd from tb_wsf_cmn_c bb where bb.cmn_gr_cd = 'LANG_CD') b
# minus
# select c.msg_ctn
#      , c.lang_cd
#   from tb_wsf_msg_m c
# ) aa
# ;


# 사용하지 않는 메시지는 삭제합니다.
# -- SELECT *
# DELETE
#   FROM  tb_wsf_msg_m a
# WHERE ( a.msg_ctn , a.lang_cd ) IN (
# select c.msg_ctn
#      , c.lang_cd
#   from tb_wsf_msg_m c
#  WHERE c.data_ins_user_id = 'BE_EXTRACT'
# minus
# select a.msg_ctn as msg_ctn
#      , b.cmn_cd  as lang_cd
#   from (SELECT Z1.*
#           FROM (
#                SELECT msg_ctn
#                     , MSG_TXT_CTN
#                     , RANK() OVER(PARTITION BY msg_ctn ORDER BY seq) AS rnk
#                  FROM TB_WSF_MSG_TMP_M
#                ) Z1
#          WHERE Z1.rnk = 1) a
#   cross join ( select bb.cmn_cd from tb_wsf_cmn_c bb where bb.cmn_gr_cd = 'LANG_CD') b
# )
# ;



import re
import glob

# path = r'C:\workspace\glsp-be\src\**\*.html'
path = r'.\**\*.html'
file_list = glob.glob(path, recursive = True)

# print(file_list)


results_html = []
matches_html = []

pattern = r"\#\{\s*?.+?\s*?[\(\}]"


for html_file in file_list:

    with open(html_file, encoding='utf8') as f:
        content = f.read().replace('\n','')
        matches_html = re.findall(pattern,content)
        # print(matches)


        clean_pattern1 = r"\#\{"
        clean_pattern2 = r"[\(\}]"
        clean_pattern3 = r"tmpl\..+?\."
        for message in matches_html:
            # message = re.sub(clean_pattern1, "t('", message)
            # message = re.sub(clean_pattern2, "','", message)
            # message = re.sub(clean_pattern3, "')", message)
            message = re.sub(clean_pattern1, "", message)
            message = re.sub(clean_pattern2, "", message)

            message_txt = re.sub(clean_pattern3, "", message)

            message = html_file + "\t" + message + "\t" + message_txt

            results_html.append(message)



# write_file = open("out.txt", "w", encoding="utf8")

# for index, value in enumerate(results):
#     print(value)
    # write_file.write(value)

# write_file.close()


# path = r'C:\workspace\glsp-be\src\**\*.java'
path = r'.\**\*.java'
file_list = glob.glob(path, recursive = True)

# print(file_list)


results_java = []
matches_java = []

pattern = r"getMessage\(\".+?\""


for java_file in file_list:

    with open(java_file, encoding='utf8') as f:
        content = f.read().replace('\n','')
        matches_java = re.findall(pattern,content)
        # print(matches)


        clean_pattern1 = r"getMessage\(\""
        clean_pattern2 = r"\""
        clean_pattern3 = r".+?\..+?\."
        for message in matches_java:
            # message = re.sub(clean_pattern1, "t('", message)
            # message = re.sub(clean_pattern2, "','", message)
            # message = re.sub(clean_pattern3, "')", message)
            message = re.sub(clean_pattern1, "", message)
            message = re.sub(clean_pattern2, "", message)

            message_txt = re.sub(clean_pattern3, "", message)

            message = java_file + "\t" + message + "\t" + message_txt

            results_java.append(message)



write_file = open("out-be.txt", "w", encoding="utf8")

for index, value in enumerate(results_html):
    # print(value)
    write_file.write(value + '\n')

for index, value in enumerate(results_java):
    # print(value)
    write_file.write(value + '\n')

write_file.close()

