# Getting Started

## WEB F/W 환경설정 가이드

본 Git repository를 ( http://10.94.57.6:8080/project/eswf-2023/eswf-be-template.git ) Download 한 후 각자 프로젝트 repository로
복사해서 작업하시기 바랍니다.

DB Object Import 에 관한 공지

- 전사데이터표준관리시스템을 참조하시기 바랍니다.
- setup/oracle 하위에 제공되는 Script의 테이블 명이 모두 TB_WSF_ 로 시작하는데, 각 시스템에서 부여받은 DB 주제영역 약어로 replace 하여 생성바랍니다.
  ( WSF 주제영역에서 모든 업무시스템의 수정사항을 수용할 수 없으므로 각 시스템으로 복사해가는 개념입니다. )
- src/resources/sql/primary/core 하위에 있는 쿼리도 변경된 테이블 명으로 수정이 필요합니다.

소스에서 수정할 내용

- settings.gradle 파일의 YOUR_SYSTEMID_HERE 문자열
- src/resource/config 하위의 default, dev, prd 의 config.yml 파일의 datasource, i18n, todo, ifApproval, ifLibrary, sso
  Propertie 들 수정,
  default 는 local, dev 는 개발서버용, prd 는 운영서버용입니다.
  datasource 의 정보는 default에만 프로젝트의 개발DB 정보로 넣으시기 바랍니다.
- YourSystemIdBeApplication.java 파일 Rename
- YourSystemIdBeApplicationTests.java 파일 Rename
- src/main/java/com/lgit/yourproject 패키지 경로의 yourproject 수정
- LogAspect.java의 yourproject 수정
- 두개 이상의 DB를 사용한다면 SecondaryDataSourceConfig.java 소스를 참조하세요.

이메일 발송에 관한 내용

1. 일괄발송 기능

- TB_WSF_EML_SNDO_QUE_M 테이블에 발송할 메일정보를 저장합니다.
- 각 시스템의 Batch 처리 프로세스에 따라 일괄발송 기능을 수행합니다.
  > ex) Jenkins Job 사용시 curl http://pjt.lgit.com/api/v1/mailBatch -d {}
- TB_WSF_EML_SNDO_QUE_M 발송한 메일의 상태값이 업데이트 됩니다.
- TB_WSF_EML_SNDO_LOG_M 테이블에 발송된 메일 로그가 기록됩니다.
  > 구현체
    - MailServiceImpl.sendMail()
    - MailServiceImpl.sendMailBatch()

2. 즉시발송 기능

- 이메일이 즉시 발송됩니다.
  > 구현체
    - MailServiceImpl.sendMailImmediately()

3. 메일발송시 유의사항

- 수신자가 다수인 경우 InternetAddress[] 을 사용해 MimeMessageHelper 한객체에 담을 수 있도록 합니다.
- 같은 내용의 메일을 다수한테 발송하는 경우 반드시 리스트로 수신자를 넣고(지연시간 방지), 업무 로직상 필요한 경우라면 숨은 참조 등을 사용합니다.
- MimeMessageHelper.setTo() : 수신자(다건 가능)
- MimeMessageHelper.setCc() : 참조(다건 가능)
- MimeMessageHelper.setBcc() : 숨은참조(다건 가능)

참고

- Nexess SSO Agent 를 이용한 SSO 연동은 지원하지 않습니다. ( 공급사인 이니텍 측에서 javaxEE 환경 라이브러리 지원 불가함을 통보 - 2024년 개발 시작 예정?? )

## 로컬 환경 구성 (아래는 각 프로젝트에서 편집 바랍니다.)

로컬 Spring Boot 환경 구성

### IDE

- [IntelliJ IDEA Community](https://www.jetbrains.com/ko-kr/idea/download)
  > IntelliJ Plugins
  >
  > - Lombok (Build,Execution,Deployment→Compliler→Annotation Processors→Enable annotation processing)
- [VS Code](https://code.visualstudio.com)
  > VS Code Extensions
  >
  > - Extension Pack for Java
  > - Language Support for Java by Red Hat
  > - Java Dependency Viewer
  > - Debugger for Java
  > - Spring Boot Extension Pack
  > - Spring Boot Tools
  > - Lombok Annotations Support for VS Code
  > - Gradle Language Support
  > - Gradle Task
  > - SonarLint
  > - Java Test Runner

### CI - 소스관리

- GitLab 계정 발급
- GitLab에서 소스코드 clone: git clone {주소}

### Swagger - API 관리

- http://localhost:7070/api/swagger-ui/index.html
- 로그인 체크가 있기 때문에 /api/v1/dev/login api 로 로그인 후 호출하도록 합니다.

### Spotless

```
./gradlew spotlessApply
```

### Build

./gradlew clean build

### Start

./gradlew bootRun
