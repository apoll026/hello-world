import {
  Description,
} from '@amxis/design-system';
import { Box, Typography } from '@mui/material';

function Cfsnw0300(){
  return (
    <Typography>
        <Box width="596px">
            <Description
                listData={[
                {
                    content: '사업자 번호로 발급받은 범용공인인증서로 로그인 가능합니다.'
                },
                {
                    content: '공인인증서 등록 및 신청은 인증서 발급/등록 버튼을 클릭하시기 바랍니다.'
                },
                {
                    content: '인증서 로그인이 안될 경우'
                },
                {
                    content: 'SCORE PKI for OpenWeb 프로그램 버전체크 오류가 발생하는 경우, 주소창에 http://가 없으면 주소에 붙여서\n 다시 진행해보시기 바랍니다. ',
                    textLink: ''
                }
                ]}
                ordered
                usecase="normal"
            />
        </Box>
    </Typography>
  );
};

export { Cfsnw0300 };
