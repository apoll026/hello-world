import React from 'react';

function Cfsnw0100(){
  return (
    <div>
      <h1>메인 컴포넌트</h1>
    </div>
  );
};

export { Cfsnw0100 };