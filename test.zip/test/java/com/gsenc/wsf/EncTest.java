package com.gsenc.wsf;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest()
public class EncTest {

    @Test
    public void EncTestEncrypt() {
        String key = "Ami2025!";
        StandardPBEStringEncryptor pbeEnc = new StandardPBEStringEncryptor();
        pbeEnc.setAlgorithm("PBEWithMD5AndDES");
        pbeEnc.setPassword(key);

        String encText = pbeEnc.encrypt("tldpvm$dptm3");
        //String encText = "Nj8i7w96amga/24NMeGhGsy4+E53gGym";
        String decText = pbeEnc.decrypt(encText);
        System.out.println("encryptedText = " + encText);
        System.out.println("decryptedText = " + decText);

    }
}
