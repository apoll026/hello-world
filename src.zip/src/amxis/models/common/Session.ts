import { Menu } from '@/amxis/models/admin/Menu.ts';
import { RoleButtonCode } from '@/amxis/models/admin/RoleButtonCode.ts';

export type LangType = 'ko' | 'en' | 'zhC';
export const RootPgm = 'CFS_P0000000';
export enum LanguageCode {
  ko = 'ko',
  en = 'en',
  zhC = 'zhC',
}

export interface Session {
  // 기존 AMXIS 필드
  mailId?: string; // 메일 ID (기존 userId)
  userIp?: string;
  langCd?: LanguageCode;
  roleCodes?: string[];
  roleButtonCodes?: RoleButtonCode[];
  personalSearches?: [];
  menus?: Menu[];
  timeZoneCd?: string;

  // UAT 세션 필드
  biztTitl?: string; // 출장 직급(D1~D6)
  siteCd?: string; // 부서/현장구분 1:본사, 2:현장
  passwd?: string; // 패스워드
  empNo?: string; // 사번
  empName?: string; // 사용자명
  engName?: string; // 사용자 영문명
  titlCode?: string; // 직위코드
  titlName?: string; // 직위명
  grdeName?: string; // 직급명
  deptCode?: string; // 부서코드
  deptName?: string; // 부서명
  funcArea?: string; // 계정과목(FATY500_SAP.CLSS:A0
  funcAreaName?: string; // 계정과목명
  actAuth?: string; // 기술개발지원 전송/사용여부 권한
  ordrFlag?: string; // 현장(SA), 본사(MA), 리조트(RA)
  auth?: string; // 권한
  lderEmpName?: string; // 리더이름
  lderEmpno?: string; // 리더사번
  lderDeptCode?: string; // 리더 부서코드
  lderDeptName?: string; // 리더 부서명
  lderTitlCode?: string; // 리더 직위코드
  lderTitlName?: string; // 리더 직위명
  dvsnCode?: string; // 사업부 코드
  empTel?: string; // 전화번호
  cardAuth?: string; // 카드 권한
  mainDept?: string; // 주 사용부서 코드
  mainName?: string; // 주 사용부서명
  partFlag?: string; // 담당파트
  userGrp?: string; // 사용자 그룹
  newWin?: string; // 품보비 사용권한이 NULL 일 때 N
  quaAuth?: string; // 품보비 사용권한
  eipPasswd?: string; // 암호화 패스워드
  eipPasswd512?: string; // 암호화 패스워드2
  cmpnCode?: string; //사업자코드
  cmpnNum?: string;  //사업자번호
}

export enum GridNoRowsTemplateData {
  ko = '조회 가능한 데이터가 없습니다.',
  en = 'There is no data available to view.',
  pl = 'Brak danych do wyświetlenia.',
  zhC = '没有可查看的数据。',
  zhT = '没有可供查看的数据。',
}
