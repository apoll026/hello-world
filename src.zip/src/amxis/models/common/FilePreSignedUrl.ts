export interface FilePreSignedUrl {
    preSignedUrl: string;
    atchFileGrId: string;
    atchFileId: string;
    fileSize: string;
    atchFileNm: string;
    atchFileTpCd: string;
}

