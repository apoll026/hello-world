export interface PatuahResult {
  seq: string;
  corpNum: string;
  vatKind: string;
  closeDate: string;
}
