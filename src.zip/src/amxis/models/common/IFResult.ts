export interface IFResult {
    // To-Do result
    returnCode: string;
    returnDesc: string;

    // Talk result
    o_ret_code: string;
    o_ret_msg: string;
}

