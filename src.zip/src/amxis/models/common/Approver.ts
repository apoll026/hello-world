import { Crud } from './Edit.ts';

export interface ApprovalMaster {
  reqNo?: string; //결재요청번호
  systemId?: string; //Legacy 시스템ID
  formId: string; //양식 ID
  reqEmpNo: string; //요청자 사번
  apprTitle: string; //결재문저 세목
  bodyHtml?: string; //모바일 본문내용
  formEditorData: string; //웹 본문내용
  apprSecurityType?: string; //문서종류
  apprLineType?: string; //협의유형
  apprPeriodCd: string; //보존연한코드
  fileLinkName?: string; //첨부파일명
  fileLinkUrl?: string; //첨부파일 URL
  fileSize?: string; //첨부파일사이즈
  readUser?: string; //통보자사번
  readDept?: string; //공개 부서코드
  referenceId?: string; //참조자 사번
  formData?: string; //연동양식 layout용 본문
  relevantDepts?: string; //유관부서 정보
  reviewComments?: string; //검토의견
  dataInsUserId?: string; //데이터입력사용자ID
  dataInsUserIp?: string; //데이터입력사용자IP주소
  dataInsDtm?: string; //데이터입력일시
  dataUpdUserId?: string; //데이터수정사용자ID
  dataUpdUserIp?: string; //데이터수정사용자IP주소
  dataUpdDtm?: string; //데이터수정일시
  aprReqProgStatCd?: string; //결재진행 상태 코드
}

export interface ApprovalMasterResponseVo extends ApprovalMaster {
  reqUserId: string; //요청자 유저 아이디
  reqEmpNm: string; //요청자 이름
  reqDeptNm: string; //요청자 부서명
  reqJpsNm: string; //요청자 직급/직책 명
  aprReqProgStatCdNm: string; //결재진행 상태 코드명
}

export interface ApprovalLine extends Crud {
  reqNo: string; //결재요청번호
  apprLnSeq: string; //결재라인순번
  nextApprSeq: string; //결재선 순서
  nextApprType: string; //결재타입
  nextApprEmpNo: string; //결재 유저 사번
  prlYn: string; //병렬 유무
  apprStatus: string; //결재 상태
  apprMessage: string; //의견
  apprDate: string; //결재시간
}

export interface ApprovalLineResponseVo extends ApprovalLine {
  nextApprTypeCdNm: string; //결재타입코드명
  nextApprUserId: string; //결재 유저 아이디
  nextApprEmpNm: string; //결재 유저 이름
  nextApprDeptNm: string; //결재 유저 부서명
  nextApprJpsNm: string; //결재 유저 직급/직책명
  dlgtUserId: string; //결재 위임자 아이디
  dlgtEmpNm: string; //결재 위임자 이름
  dlgtDeptNm: string; //결재 위임자 부서명
  dlgtJpsNm: string; //결재 위임자 직급/직책명
  apprStatusCdNm: string; //결재 상태 명
}
export interface ApprovalMasterLineRequestVO {
  approvalMasterVO: ApprovalMaster;
  approvalLineVOList: ApprovalLine[];
}

export interface CommonReturnData {
  /**
   * 처리 결과 코드
   */
  result: string;
  /**
   * 요청 url
   */
  path: string;
  /**
   * 요청시간
   */
  timestamp: string;

  /**
   * 처리 결과 설명
   */
  message: string;

  returnCode: string;

  returnDesc: string;
}

export interface ApprovalMasterLineResponseVo {
  approvalMasterResponseVO: ApprovalMasterResponseVo;
  approvalLineResponseVOList: ApprovalLineResponseVo[];
}
