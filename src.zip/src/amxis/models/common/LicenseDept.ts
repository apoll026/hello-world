export const licenseDeptCd = '70000591'; // 특허.특허라이센스팀 부서 코드
