import { IBSheetInstance } from '@ibsheet/loader/dist/cjs/lib/ibsheet';

export type Sheet = IBSheetInstance;

export interface SheetOptions {
  Def?: any;
  Cfg?: any;
  LeftCols?: any;
  Cols?: any;
  RightCols?: any;
  Events?: any;
  Head?: any;
  Foot?: any;
  Solid?: any;
  Filter?: any;
}
