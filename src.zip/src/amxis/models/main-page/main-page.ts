export interface MainPageCountDataResponse {
  apprCnt?: number;
  apprPndgCnt?: number;
  cardUnprCnt?: number;
  reApprCnt?: number;
  unprocPurTaxCnt?: number;
  vchrTempCnt?: number;
}

export interface MainNoticeDataResponse {
  noticeNo: string;
  noticeTitle: string;
  dataUpdDtm: string;
}

export interface MainBbsDataResponse {
  bbsNo: string;
  bbsTitle: string;
  dataUpdDtm: string;
}
