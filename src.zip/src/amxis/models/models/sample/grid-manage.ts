export interface GridManageConditionVO {
    sPriceFrom: string;
    sPriceTo: string;
    searchItem: string;
  }
  
  export interface GridManageResponseVO {
    sColMsgCode?: string;
    sColMsgCtnKR?: string;
    sColMsgCtnEN?: string;
  }
  
  export interface GridManageRequestVO extends GridManageResponseVO {
    sId?: string;
    sState?: string;
  }