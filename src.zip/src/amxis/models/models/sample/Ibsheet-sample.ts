export interface IBSheetSampleConditionVO {
  sPriceFrom: string;
  sPriceTo: string;
  searchItem: string;
}

export interface IBSheetSampleResponseVO {
  sCompany?: string;
  sCountry?: string;
  sSaleQuantity?: number;
  sSaleIncrease?: number;
  sPrice?: number;
  sSatisfaction?: number;
  sComment?: string;
  sColMsgCode?: string;
  sColMsgCtnKR?: string;
  sColMsgCtnEN?: string;
}

export interface IBSheetSampleRequestVO extends IBSheetSampleResponseVO {
  sId?: string;
  sState?: string;
}
