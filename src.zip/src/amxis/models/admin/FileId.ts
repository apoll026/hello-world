export interface FileId {
  atchFileGrId: string;
  atchFileId: string;
}
