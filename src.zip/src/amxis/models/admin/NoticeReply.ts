export interface NoticeReplyRequest {
  noticeNo: string;
  noticeReCtn?: string;
  prntReNo?: string;
}

export interface NoticeReply {
  noticeNo: string;
  noticeReNo: string;
  noticeReCtn: string;
  dataInsDtm: string;
  dataInsUserId: string;
  dataUpdDtm: string;
  dataUpdUserId: string;
  empName: string;
  empNo: string;
  ofcPhn: string;
  empHphn: string;
  emlDmnIfoNm: string;
  deptNm: string;
  jtiNm: string;
  jpsNm: string;
  reReplies: NoticeReReply[]; //대댓글 목록
  delYn: string;
}
export interface NoticeReReply {
  noticeNo: string;
  noticeReNo: string;
  noticeReCtn: string;
  dataInsDtm: string;
  dataInsUserId: string;
  dataUpdDtm: string;
  dataUpdUserId: string;
  delYn: string;
  empName: string;
  empNo: string;
  ofcPhn: string;
  empHphn: string;
  emlDmnIfoNm: string;
  deptNm: string;
  jtiNm: string;
  jpsNm: string;
  anonYn: string;
  prntNoticeReNo: string;
}
export interface NoticeReplyUpdateRequest {
  noticeNo: string;
  noticeReNo: number | string;
  noticeReCtn?: string;
}
