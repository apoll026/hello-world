import { PaginationRequest } from '@/amxis/models/common/Pagination.ts';

export interface LoginLogRequest extends PaginationRequest {
  contDtmFr: string;
  contDtmTo: string;
  searchItem: string;
}

export interface LoginLog {
  contLogId: string;
  contDtm: string;
  contUserId: string;
  empName: string;
  deptNm: string;
  contIp: string;
}
