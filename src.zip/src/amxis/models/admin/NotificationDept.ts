import { CommonYN } from '@/amxis/models/common/Common.ts';
import { Crud } from '@/amxis/models/common/Edit.ts';

export interface NotificationDeptCondition {
  ntdkDeptNm?: string;
  ntdkDeptId?: string;
  useYn?: string;
}

export interface NotificationDeptGroup extends Crud {
  ntdkDeptId: string;
  ntdkDeptNm: string;
  ntdkDeptDesc?: string;
  useYn?: CommonYN;
}

export interface NotificationDeptGroupDivision extends Crud {
  ntdkDeptDivsCd: string;
  ntdkDeptDivsNm?: string;
}

export interface NotificationDeptGroupUser extends Crud {
  aprNotfDeptCd: string;
  deptNm?: string;
  deptCd?: string;
  copCd?: string;
  ntdkDeptSeq: number;
  ntdkDeptDivsCd?: string;
  ntdkDeptId: string;
  sortOrd?: string;
  useYn?: string;
}
