export interface Company {
  userInfo?: string;
  mailId?: string;        // 메일ID
  empNo?: string;         // 사번
  empName?: string;       // 사용자명
  passwd?: string;        // 패스워드
  empSttu?: string;       // 사용자상태
  deptCode?: string;      // 부서코드
  deptName?: string;        // 부서명
  lderEmpno?: string;     // 리더사번
  titlCode?: string;      // 직위
  titlName?: string;      // 직위명
  grdeCode?: string;      // 직급
  grdeName?: string;      // 직급명
  auth?: string;          // 권한
  ordrFlag?: string;      // 현장(SA),본사(MA),리조트(RA)
  empTel?: string;        // 전화번호
  empMobl?: string;       // 모바일번호
  updEmpno?: string;      // 최종수정자
  updDate?: string;       // 최종수정일
  updId?: string;         // 최종수정ID
  biztTitl?: string;      // 출장직급
  empSsn?: string;        // 주민번호
  engName?: string;       // 영문명
  apprPasswd?: string;    // 결재암호
  actAuth?: string;       // 기술개발지원전송/사용여부권한
  cardAuth?: string;      // 카드사용권한
  useDept?: string;       // 사용부서
  partFlag?: string;      // 주관부서담당파트
  newWin?: string;        // 미확인
  quaAuth?: string;       // 품보비 사용권한
  frsAuth?: string;       // 기타 권한
  insaDivs?: string;      // A:인사시스템관리, B: 기타
  partCharge?: string;    // Y:재무업무 담당자 N:일반
  retireDate?: string;    // 퇴직일
}

export interface TeamLeaderInfo {
  userId: string;
  userName: string;
}