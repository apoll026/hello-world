import { Crud } from '@/amxis/models/common/Edit.ts';
import { RootPgm } from '../common/Session';

export interface Menu {
  pgmId: string;
  pgmName?: string;
  pgmUrl?: string;
  pgmAuth?: string;
  mnuLvNo?: number;
  upgmId?: string;
  sortOrd?: number;
  useYn?: string;
  mnuOptValCtn1?: string;
  mnuOptValCtn2?: string;
  mnuOptValCtn3?: string;
  mnuOptValCtn4?: string;
  mnuOptValCtn5?: string;
  msgCtn?: string;
  mnuKoNm?: string;
  mnuEnNm?: string;
  mnuPlNm?: string;
  mnuZhtNm?: string;
  mnuZhcNm?: string;
  mnuDesc?: string;
  childrens?: Menu[];
}

export interface MenuVO extends Menu {
  isChecked?: boolean;
  optionName?: string;
  optionValue?: string;
}

export interface MenuRequest extends Crud {
  pgmId: string;
  pgmName: string;
  targetMenuId: string;
  menuLocation: string; //'1' : up, '2' : down, '3':inner, '4':none
  useYn: string;
  mnuOptValCtn1?: string;
  mnuOptValCtn2?: string;
  mnuOptValCtn3?: string;
  mnuOptValCtn4?: string;
  mnuOptValCtn5?: string;
  msgCtn?: string;
  pgmUrl: string;
  mnuDesc: string;
}

export enum MenuEnum {
  root = RootPgm,
  home = 'HOME',
}

export interface Page {
  pageNm?: string;
  ctnsNo?: number;
  pgGrNo?: number;
  pgLangCd?: string;
  ctnsFrmtCd?: string;
  ctnsLv?: number;

  isBullete?: boolean;
  pageType?: 'regist' | 'modify' | 'detail';
  //쓸지 안쓸지 모르겠음
  mnuTpCd?: string;
  url?: string;
}

export interface BookMark {
  empNo?: string;
  pgmUrl?: string;
  pgmName?: string;
  pgmId?: string;
}

export interface MenuContextType {
  selectedHeaderMenu: string;
  currentMenu: Menu;
  clickedByHeaderMenu: boolean;
  handleMenuChange: (item: MenuContextType) => void;
  showMenu: boolean;
  handleShowMenuChange: (showMenu: boolean) => void;
}

export const defaultMenuContext: MenuContextType = {
  selectedHeaderMenu: '',
  currentMenu: { pgmId: '' } as Menu,
  clickedByHeaderMenu: false,
  handleMenuChange: () => {},
  showMenu: true,
  handleShowMenuChange: () => {},
};

export const HomeMenu: Menu = {
  pgmId: MenuEnum.root,
  pgmName: MenuEnum.home,
};

export interface AuthMenuRequest extends Crud {
  pgmId: string;
  auth: string;
  pgmAuth: string;
}

export const INTERNAL_MENU_PATHS = ['access-denied', 'login'];
