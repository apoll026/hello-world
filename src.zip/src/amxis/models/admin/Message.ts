import { CommonYN } from '@/amxis/models/common/Common.ts';
import { Crud } from '@/amxis/models/common/Edit.ts';
import { Nullable } from '@/amxis/models/common/FalsyGeneric.ts';
import { PaginationRequest } from '../common/Pagination.ts';

export interface MessageCondition extends PaginationRequest {
  msgCtn?: string;
  msgTxtCtn?: string;
  useYn?: string;
}

export interface Message extends Crud {
  msgCtn: Nullable<string>;
  langCd: Nullable<string>;
  msgTxtCtn: Nullable<string>;
  rmk: Nullable<string>;
  optValCtn1: Nullable<string>;
  optValCtn2: Nullable<string>;
  optValCtn3: Nullable<string>;
  useYn: Nullable<CommonYN>;
  dataInsUserId: Nullable<string>;
  dataInsUserIp: Nullable<string>;
  dataInsDtm: Nullable<string>;
  dataUpdUserId: Nullable<string>;
  dataUpdUserIp: Nullable<string>;
  dataUpdDtm: Nullable<string>;
  langCdList: Nullable<string>; // ||로 구분된 langCd string : ko||en
  msgTxtCtnList: Nullable<string>; // ||로 구분된 msgTxtCtn string : 한국어||영어
  dataUpdDtmList: Nullable<string>;
  dataUpdUserIdList: Nullable<string>;
  useYnList: Nullable<string>;
}

export interface ShowingMessage extends Crud {
  msgCtn: Nullable<string>;
  msgTxtCtn1: Nullable<string>;
  msgTxtCtn2: Nullable<string>;
  msgTxtCtn3: Nullable<string>;
  msgTxtCtn4: Nullable<string>;
  msgTxtCtn5: Nullable<string>;
  rmk: Nullable<string>;
  optValCtn1: Nullable<string>;
  optValCtn2: Nullable<string>;
  optValCtn3: Nullable<string>;
  useYn: Nullable<CommonYN>;
  dataInsUserId: Nullable<string>;
  dataInsUserIp: Nullable<string>;
  dataInsDtm: Nullable<string>;
  dataUpdUserId: Nullable<string>;
  dataUpdUserIp: Nullable<string>;
  dataUpdDtm: Nullable<string>;
}

export interface MessageInfo {
  msgCtn: string;
  msgTxtCtn1: string;
  msgTxtCtn2: string | undefined;
  msgTxtCtn3: string | undefined;
  msgTxtCtn4: string | undefined;
  msgTxtCtn5: string | undefined;
  rmk: string;
  useYn: CommonYN;
}
