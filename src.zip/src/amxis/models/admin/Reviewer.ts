export interface reviewerContent {
  empName: string;
  empNo?: string;
  jtiNm: string;
  jtiCd?: string;
  deptNm: string;
  deptCd?: string;
  ctrcCt?: number;
  cnstCt?: number;
  fatnCt?: number;
  sucCt?: number;
  userId?: string;
}
