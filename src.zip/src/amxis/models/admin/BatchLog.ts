import { PaginationRequest } from '@/amxis/models/common/Pagination.ts';

export interface BatchLogRequest extends PaginationRequest {
  batchLogDtmFr: string;
  batchLogDtmTo: string;
  searchItem: string;
}

export interface BatchLog {
  btchLogDtm: string;
  btchClsNm: string;
  btchMthdNm: string;
  btchCrn: string;
  btchRslt: string;
  content: string;
  result: string;
}
