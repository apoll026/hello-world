import { PaginationRequest } from '@/amxis/models/common/Pagination.ts';
import { FileInfo } from '@/amxis/models/admin/FileInfo.ts';
import { BbsReply } from './BbsReply.ts';
import internal from 'stream';

export interface BbsCondition extends PaginationRequest {
  bbsTpCd?: string;
  bbsTitle?: string;
  bbsCtn?: string;
  searchType?: string;
  searchCtn?: string;
  sortValue?: string | number;
  isUnread?: string;
  inputValue?: string;
  optionType?: string;
  optionalType?: string;
}

export interface BbsPost {
  bbsNo: string;
  rank: string;
  bbsTpCd: string;
  bbsTpNm: string;
  bbsTitle: string;
  bbsCtn: string;
  atchFileExist: string;
  atchFileGrId: string;
  dataInsUserId: string;
  dataInsUserInfo: string;
  dataInsDtm: string;
  bbsVwct: string;
  bbsReplyct: string;
  imptYn: string; //공지사항 상단 고정 여부
  readYn: string; //읽음여부
  reBbsYN: string; //답글 여부
  prntReBbsNo: string; //부모 답글 번호
  firstImgTag?: string; //최초 이미지 url
  deptNm: String; //작성자 부서
  userNm: string; //작성자 이름
  jpsNm: string; //작성자 직책
  jtiNm: string; //작성자 직위
  ptupEndDt: string;
  poupStDtm: string;
  poupEndDtm: string;
  poupEpsNuseDdn: number;
  ptupTgtCopNm: string;
}

export interface BbsEmployee {
  mailId: string;
  empName: string;
  deptName: string;
  titlName: string;
  jtiNm: string;
  jpsNm: string;
  ofcTanoPhn: string;
  email: string;
}

export interface BbsPostDetail {
  bbsNo: string;
  prntReBbsNo: string;
  bbsVwct?: string;
  dataInsUser: BbsEmployee;
  dataInsDtm: string;
  dataUpdUserId?: string;
  dataUpdDtm: string;
  bbsTpCd: string;
  bbsTpNm: string;
  ptupTgtCopNm?: string;
  bbsTitle: string;
  bbsCtn: string;
  atchFiles: FileInfo[];
  atchFileGrId?: string;
  ptupEndDt?: string;
  poupStDt?: string;
  poupEndDt?: string;
  poupStTm?: string;
  poupEndTm?: string;
  poupStDtm?: string;
  poupEndDtm?: string;
  poupEpsNuseDdn: number;
  replies?: BbsReply[];
  imptYn?: string;
  reBbsYN: string; //답글 여부
}

export type BbsPostRequest = {
  bbsTpCd: string;
  bbsTitle: string;
  bbsCtn: string;
  atchFileGrId: string;
  ptupEndDt: string;
  imptYn: string;
  reBbsYN: string;
  prntReBbsNo: string;
};

export type BbsPostUpdateRequest = { bbsNo: string } & BbsPostRequest;
