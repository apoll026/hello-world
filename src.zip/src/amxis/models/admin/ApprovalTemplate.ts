import { Crud } from '@/amxis/models/common/Edit.ts';

export interface ApprovalTemplate extends Crud {
  aprTplId: string;
  intgAprTpCd: string;
  aprTplNm: string;
  sortOrd: number;
  aprTplDesc: string;
  useYn: string;
  prsDesc: string;
  ntdkId: number;
  wcstUseYn: string;
  wcstDesc: string;
  notfUseYn: string;
  mgrUseYn: string;
}
