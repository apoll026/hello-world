import { Crud } from '@/amxis/models/common/Edit.ts';

export interface Role extends Crud {
  roleCd: string;
  roleNm: string;
  roleDesc: string;
  useYn: string;
}

export interface RoleEmployee extends Crud {
  mailId: string;
  empName: string;
  deptName: string;
  officeNumber: string;
  emlDmnIfoNm: string;
  isUpdated?: boolean;
}

export interface RoleDepartmentMutateRequest {
  roleCd: string;
  deptCdList: string[];
}

export interface RoleEmployeeMutateRequest {
  roleCd: string;
  mailIdList: string[];
}
