import { Crud } from '@/amxis/models/common/Edit.ts';

export interface ApprovalRuleMaster {
  aprRuleId: string;
  aprRuleNm: string;
  aprLnAddPmitYn: string;
  aprRferAddPsblYn: string;
  aprLnRstbPmitYn: string;
  aprLnDuplPmitYn: string;
  mstNtdkDeptId: string;
  mstNtdkId: string;
}

export interface ApprovalRuleDetail {
  aprRuleId: string;
  aprLnId: string;
  aprTpDivsCd: string;
  prlYn: string;
  aprLnSnb: string;
  seq: string;
  aprLnRoleCd: string;
  deptCd: string;
  deptNm?: string;
  userId: string;
  userNm: string;
  userInfo?: string;
  aprLnChgPsblYn: string;
  aprLnDelPsblYn: string;
  crudKey?: string;
}

export interface ApprovalCommon {
  apiType: string;
  formId: string;
  apprTitle: string;
  reqUser: string;
  appkey01: string;
  appkey02: string;
  appkey03: string;
  appkey04: string;
  appkey05: string;
  formEditorData: string;
  formMobileData: string;
  apprSecurityType: string;
  apprDocNo: string;
  apprLineType: string;
  apprPeriodCd: string;
  fileLinkName: string;
  fileLinkUrl: string;
  fileSize: string;
  nextApprType: string;
  nextApprover: string;
  readUser: string;
  readDept: string;
  formData: string;
  isReturnApprId: string;
  appUrl: string;
  appWaitUrl: string;
  appMobileUrl: string;
  apprStatus: string;
  apprMessage: string;
  isAllDelete: string;
  deleteUser: string;
  nextApproverUrl: string;
  summaryData: string;
}

export interface ApprovalSetEntrust {
  apiType: string;
  reqUser: string;
  signUser: string;
  startDate: string;
  endDate: string;
}

export interface ApprovalCommonResponse {
  ifErrmsg: string;
  ifStatus: string;
}

export interface ApprovalDelegate extends Crud {
  aprDlgtNo: string;
  aprDlgtUserId: string;
  aprDlgtUserDisplay: string;
  dlgtUserDept: string;
  aprDeleUserId: string;
  aprDeleUserDisplay: string;
  deleUserDept: string;
  aprDlgtStDt: string;
  aprDlgtEndDt: string;
  status: string;
  useYn: string;
  dataInsUserId: string;
  dataInsDtm: string;
}

export interface BaseApprovalLineResponseVO {
  aprLnDivsCd: string; //결재라인구분코드(APPD:결재라인, INFR:통보라인)", example = "APPD
  aprRuleId: string; //결재라인기본ID", example = "AR-001
  aprRuleNm: string; //결재규칙명
  aprLnAddPmitYn: string; //결재라인추가허용여부
  aprRferAddPsblYn: string; //결재참조자추가가능여부
  aprLnRstbPmitYn: string; //결재라인재설정허용여부
  aprLnDuplPmitYn: string; //결재라인중복허용여부
  aprExcTgtId: string; //결재제외대상ID
  mstNtdkId: number; //기본통보처ID
  aprLnId: string; //양식결재선아이디", example = "ARL-001
  nextApprType: string; //결재유형코드 ( 담당,협의,합의,결재,보고,참조 )", example = "APV
  prlYn: string; //병렬여부 (순차/병렬)", example = "
  nextApprSeq: number; //결재차수 (병렬일경우 동일차수)", example = "1
  apprLnSeq: number; //단순순번", example = "1
  aprLnRoleCd: string; //역할코드( 특정사용자, 기안자의 상위자, 기안자의 차상위자, 특정부서장지정 )", example = "USER
  basDeptCd: string; //특정부서장일경우 기준 부서코드", example = "
  basUserId: string; //특정사용자일경우 기준 사용자ID", example = "
  aprLnChgPsblYn: string; //결재라인사용자수정가능여부", example = "N
  aprLnDelPsblYn: string; //결재라인삭제가능여부", example = "N
  userId: string; //결재자사용자ID
  userInfo: string; //결재자사용자Info", example = "
  empNo: string; //결재자사원번호
  nextApprEmpNo: string; //결재자사원번호
  empName: string; //결재자사원명
  empEngNm: string; //사원영어명
  empCngNm: string; //사원중국어명
  deptCd: string; //부서코드
  deptNm: string; //부서명
  deptEngNm: string; //부서영어명
  deptCngNm: string; //부서중국어명
  copCd: string; //법인코드
  jtiCd: string; //직위코드
  jtiNm: string; //직위명
  jtiEngNm: string; //직위영어명
  jtiCngNm: string; //직위중국어명
  jpsCd: string; //직책코드
  jpsNm: string; //직책명
  jpsEngNm: string; //직책영어명
  jpsCngNm: string; //직책중국어명
  upprEmpNo: string; //상위사원번호
  onduRegnCd: string; //근무지역코드
  onduRegnNm: string; //근무지역명
  ctryCd: string; //국가코드
  emlDmnIfoNm: string; //메일서버정보
  useYn: string; //사용여부
  aprDlgtNo: string; //결재위임번호
  aprDlgtUserId: string; //결재위임사용자ID
  aprDlgtUserEmpNm: string; //결재위임사용자명
  aprDlgtUserJtiNm: string; //결재위임직위명
  aprDlgtUserDeptNm: string; //결재위임부서명
  aprDlgtUserInfo: string; //결재위임사용자정보
  aprDeleUserId: string; //결재수임사용자ID
  aprDeleEmpName: string; //결재수임사용자명
  aprDeleJtiNm: string; //결재수임사용자직위명
  aprDeleDeptNm: string; //결재수임사용자부서명
  aprDeleUserInfo: string; //결재수임사용자정보
  aprDlgtStDt: string; //결재위임시작일자
  aprDlgtEndDt: string; //결재위임종료일자
}
