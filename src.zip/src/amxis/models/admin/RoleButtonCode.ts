import { Crud } from '@/amxis/models/common/Edit.ts';

export interface RoleButtonCode extends Crud {
  btnKeyCd?: string;
  btnGrCd?: string;
  btnCd?: string;
  roleCd?: string;
  useYn?: string;
  btnDesc?: string;
  optValCtn1?: string;
  optValCtn2?: string;
  optValCtn3?: string;
  optValCtn4?: string;
  optValCtn5?: string;
  optValCtn6?: string;
  optValCtn7?: string;
  optValCtn8?: string;
  optValCtn9?: string;
  optValCtn10?: string;
  dataInsUserId?: string;
  dataInsUserIp?: string;
  dataInsDtm?: string;
  dataUpdUserId?: string;
  dataUpdUserIp?: string;
  dataUpdDtm?: string;
}
