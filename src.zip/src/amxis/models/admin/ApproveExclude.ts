import { Crud } from '@/amxis/models/common/Edit.ts';
import { DmlResponse } from '@/amxis/models/common/RestApi.ts';
import { Code } from '@/amxis/models/common/CommonCode.ts';

export interface ApproveExcludeMaster extends Crud {
  aprExcTgtId: string;
  aprExcNm: string;
  dataInsUserId?: string;
  dataInsUserIp?: string;
  dataInsDtm?: string;
  dataUpdUserId?: string;
  dataUpdUserIp?: string;
  dataUpdDtm?: string;
}

export interface ApproveExcludeDetail extends Crud {
  aprExcTgtId: string;
  aprExcSeq?: number;
  aprExcDivsCd: string;
  aprExcUserId: string;
  aprExcUserInfo?: string;
  dataInsUserId?: string;
  dataInsUserIp?: string;
  dataInsDtm?: string;
  dataUpdUserId?: string;
  dataUpdUserIp?: string;
  dataUpdDtm?: string;
  delete?: boolean;
  userInfo?: string;
}

export interface ApprovalExcludeRequest {
  approvalExcludeMaster: ApproveExcludeMaster[];
  approvalExcludeDetail: ApproveExcludeDetail[];
}

export interface ApproveExcludeResponse {
  approvalExcludeMaster: DmlResponse;
  approvalExcludeDetail: DmlResponse;
}

export interface ApproveExcludeCode {
  divisionCode: Code[];
  jpsCode: Code[];
  jtiCode: Code[];
}
