import { PaginationRequest } from '@/amxis/models/common/Pagination.ts';

export interface ButtonLogRequestVo extends PaginationRequest {
    contDtmFr: string;
    contDtmTo: string;
    searchItem: string;
}

export interface ButtonLogResponseVo {
    btnKeyCd?: string;
    btnGrCd?: string;
    btnCd?: string;
    contDtm?: string;
    btnDesc?: string;
    userNm?: string;
    contIp?: string;
}
