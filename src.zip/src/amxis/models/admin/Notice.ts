import { PaginationRequest } from '@/amxis/models/common/Pagination.ts';
import { FileInfo } from '@/amxis/models/admin/FileInfo.ts';
import { NoticeReply } from './NoticeReply.ts';

export interface NoticeCondition extends PaginationRequest {
  noticeTpCd?: string;
  noticeTitle?: string;
  noticeCtn?: string;
  searchType?: string;
  searchCtn?: string;
  sortValue?: string | number;
  isUnread?: string;
  inputValue?: string;
  optionType?: string;
  optionalType?: string;
}

export interface NoticePost {
  noticeNo: string;
  rank: string;
  noticeTpCd: string;
  noticeTpNm: string;
  noticeTitle: string;
  noticeCtn: string;
  atchFileExist: string;
  atchFileGrId: string;
  dataInsUserId: string;
  dataInsUserInfo: string;
  dataInsDtm: string;
  noticeVwct: string;
  noticeReplyct: string;
  imptYn: string; //공지사항 상단 고정 여부
  readYn: string; //읽음여부
  reNoticeYN: string; //답글 여부
  prntReNoticeNo: string; //부모 답글 번호
  firstImgTag?: string; //최초 이미지 url
  deptNm: String; //작성자 부서
  userNm: string; //작성자 이름
  jpsNm: string; //작성자 직책
  jtiNm: string; //작성자 직위
  ptupEndDt: string;
  poupStDtm: string;
  poupEndDtm: string;
  poupEpsNuseDdn: number;
  ptupTgtCopNm: string;
}

export interface BbsEmployee {
  mailId: string;
  empName: string;
  deptName: string;
  titlCode: string;
  titlName: string;
  ofcTanoPhn: string;
  email: string;
}

export interface NoticePostDetail {
  noticeNo: string;
  prntReNoticeNo: string;
  noticeVwct?: string;
  dataInsUser: BbsEmployee;
  dataInsDtm: string;
  dataUpdUserId?: string;
  dataUpdDtm: string;
  noticeTpCd: string;
  noticeTpNm: string;
  ptupTgtCopNm?: string;
  noticeTitle: string;
  noticeCtn: string;
  atchFiles: FileInfo[];
  atchFileGrId?: string;
  ptupEndDt?: string;
  poupStDt?: string;
  poupEndDt?: string;
  poupStTm?: string;
  poupEndTm?: string;
  poupStDtm?: string;
  poupEndDtm?: string;
  poupEpsNuseDdn: number;
  replies?: NoticeReply[];
  imptYn?: string;
  reNoticeYN: string;
  poupUseYn: string;
  //답글 여부
}

export type NoticePostRequest = {
  noticeTpCd: string;
  noticeTitle: string;
  noticeCtn: string;
  atchFileGrId: string;
  ptupEndDt: string;
  imptYn: string;
  reNoticeYN: string;
  poupStDtm: string;
  poupEndDtm: string;
  poupEpsNuseDdn: number;
  prntReNoticeNo: string;
  poupUseYn: string;
};

export type NoticePostUpdateRequest = { noticeNo: string } & NoticePostRequest;
