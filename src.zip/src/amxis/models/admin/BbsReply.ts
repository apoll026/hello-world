export interface BbsReplyRequest {
  bbsNo: string;
  bbsReCtn?: string;
  prntReNo?: string;
}

export interface BbsReReply {
  bbsNo: string;
  bbsReNo: string;
  bbsReCtn: string;
  dataInsDtm: string;
  dataInsUserId: string;
  dataUpdDtm: string;
  dataUpdUserId: string;
  delYn: string;
  empName: string;
  empNo: string;
  deptNm: string;
  jtiNm: string;
  jpsNm: string;
  anonYn: string;
  prntBbsReNo: string;
  ofcPhn: string;
  empHphn: string;
  emlDmnIfoNm: string;
}

export interface BbsReply {
  bbsNo: string;
  bbsReNo: string;
  bbsReCtn: string;
  dataInsDtm: string;
  dataInsUserId: string;
  dataUpdDtm?: string;
  dataUpdUserId?: string;
  empName: string;
  empNo?: string;
  deptNm: string;
  jtiNm: string;
  jpsNm: string;
  reReplies?: BbsReReply[]; //대댓글 목록
  delYn?: string;
  ofcPhn?: string;
  empHphn?: string;
  emlDmnIfoNm?: string;
}

export interface BbsReplyUpdateRequest {
  bbsNo: string;
  bbsReNo: number | string;
  bbsReCtn?: string;
}
