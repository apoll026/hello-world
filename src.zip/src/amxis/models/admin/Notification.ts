import { CommonYN } from '@/amxis/models/common/Common.ts';
import { Crud } from '@/amxis/models/common/Edit.ts';

export interface NotificationCondition {
  ntdkNm?: string;
  ntdkId?: string;
  useYn?: string;
}

export interface NotificationGroup extends Crud {
  ntdkId: string;
  ntdkNm: string;
  ntdkDesc?: string;
  useYn?: CommonYN;
}

export interface NotificationGroupDivision extends Crud {
  ntdkDivsCd: string;
  ntdkDivsNm?: string;
}

export interface NotificationGroupUser extends Crud {
  aprNotfUserId: string;
  empName?: string;
  jtiNm?: string;
  deptNm?: string;
  ofcPhn?: string;
  emlDmnIfoNm?: string;
  ntdkSeq: number;
  ntdkDivsCd?: string;
  ntdkId: string;
  sortOrd?: string;
  useYn?: string;
}
