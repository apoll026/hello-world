import { Crud } from '@/amxis/models/common/Edit.ts';

export interface Department extends Crud {
  deptCode: string;
  deptDate?: string;
  deptName: string;
  sortCode?: string;
  lderEmpno?: string;
  upprDeptCode?: string;
  upprDeptDate?: string;
  workCode?: string;
  siteFlag?: string;
  partFlag?: string;
  useYn?: string;
  updEmpno?: string;
  updDate?: string;
  updId?: string;
  chifEmp1?: string;
  chifEmp2?: string;
  chifEmp3?: string;
  chifEmp4?: string;
  chifEmp5?: string;
  orgnLder?: string;
  deptDivs?: string;
}

export interface DepartmentResponse {
  deptCode: string;
  orgId: string;
  children: any;
  useYn: any;
  deptName: string;
  departmentList: Department[];
  userDeptCode: string;
}