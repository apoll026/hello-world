import { PaginationRequest } from '@/amxis/models/common/Pagination.ts';

export interface MenuLogRequest extends PaginationRequest {
  contDtmFr: string;
  contDtmTo: string;
  searchItem: string;
}

export interface MenuLog {
  acesLogId: string;
  contDtm: string;
  pgmId: string;
  pgmName: string;
  contUserId: string;
  empName: string;
  contIp: string;
}
