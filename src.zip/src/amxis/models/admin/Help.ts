export interface HelpCondition {
  helpNm?: string;
  useYn?: string;
  pgmId?: string;
}

export interface Help {
  pgmId?: string;
  helpNm?: string;
  helpType?: string;
  helpFile?: string;
  helpLink?: string;
  useYn?: string;
}
