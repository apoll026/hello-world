export type EmployeeSearchCondition = {
  searchItem?: string;
  deptCode?: string;
  deptName?: string;
  empName?: string;
};
