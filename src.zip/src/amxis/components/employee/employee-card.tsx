import { Dialog, useTheme } from '@amxis/design-system';
import { Box, Card, CardContent, DialogTitle, Typography } from '@mui/material';
import { DeviceMobileIcon, FunctionCallIcon, FunctionMailIcon } from '@amxis/design-system/icon';
import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { getEmployeeByEmpNo } from '@/amxis/apis/admin/Employee.ts';
import { useEffect, useState } from 'react';
import EmptyeAvartar from '@/amxis/assets/icons/empty-avatart.gif';

interface EmployeeCardProps {
  open: boolean;
  onClose: () => void;
  empNo?: string;
}

const EmployeeCard = ({ open, onClose, empNo }: EmployeeCardProps) => {
  const { data: empInfo } = useReactQuery({
    queryKey: ['employee', empNo],
    queryFn: () => (empNo ? getEmployeeByEmpNo(empNo) : null),
  });
  const [
    {
      palette: { semantic },
    },
  ] = useTheme();

  const [isImageLoaded, setIsImageLoaded] = useState<boolean | null>(null);

  // useEffect(() => {
  //   const img = new Image();
  //   if (empNo) {
  //     img.src = `https://hr.lginnotek.com/cm/service/image/download.ncd?baRs=DOWNLOAD&baRq=IN_DOWNLOAD&IN_DOWNLOAD.FILE_ID=${empNo}`;
  //
  //     img.onload = () => {
  //       setIsImageLoaded(true);
  //     };
  //
  //     img.onerror = () => {
  //       setIsImageLoaded(false);
  //     };
  //   }
  // }, []);

  return (
    <Box>
      <Dialog
        position="basic"
        type={'modal'}
        size={400}
        open={open}
        customHeaderTitle={
          <DialogTitle
            sx={{
              position: 'relative',
              fontSize: '18px',
              padding: 0,
            }}
          >
            <Box display="flex" gap="8px" alignContent="center">
              <Typography fontSize="16px" fontWeight={700} color="#1B1D22" lineHeight="24px">
                {empInfo?.empName}
              </Typography>
              <Typography fontSize="13px" fontWeight={400} color="#464C5A" lineHeight="24.5px">
                {empInfo?.deptNm}
              </Typography>
            </Box>
          </DialogTitle>
        }
        customContentArea={
          <Box>
            <Box display="flex">
              <Card
                sx={{
                  width: '136px',
                  height: '100%',
                  backgroundColor: 'transparent',
                  boxShadow: 'none',
                  border: 'none',
                }}
              >
                <CardContent
                  sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    padding: '0 !important',
                  }}
                >
                  <Box
                    width="136px"
                    height="165px"
                    sx={{
                      background: `url(${
                        isImageLoaded
                          ? // ? `https://hr.lginnotek.com/cm/service/image/download.ncd?baRs=DOWNLOAD&baRq=IN_DOWNLOAD&IN_DOWNLOAD.FILE_ID=${empNo}`
                            null
                          : EmptyeAvartar
                      }) no-repeat center center`,
                      backgroundSize: 'contain',
                      backgroundPosition: 'top',
                    }}
                  />
                </CardContent>
              </Card>
              <Box marginLeft="15px" display="flex" flexDirection="column" gap="8px">
                <Box
                  sx={{
                    padding: '10px',
                    background: '#F7F7F8',
                    borderRadius: '4px',
                    display: 'flex',
                    gap: '5px',
                    width: '100%',
                    minWidth: '200px',
                  }}
                >
                  <FunctionMailIcon
                    appearance="filled"
                    sx={{ color: semantic.color.commonTextBasic }}
                  />
                  <Typography fontSize="13px" fontWeight={400} color="#1B1D22">
                    {empInfo?.emlDmnIfoNm}
                  </Typography>
                </Box>
                <Box
                  sx={{
                    padding: '10px',
                    background: '#F7F7F8',
                    borderRadius: '4px',
                    display: 'flex',
                    gap: '5px',
                    width: '100%',
                    minWidth: '200px',
                  }}
                >
                  <FunctionCallIcon
                    appearance="filled"
                    sx={{ color: semantic.color.commonTextBasic }}
                  />
                  <Typography fontSize="13px" fontWeight={400} color="#1B1D22">
                    {empInfo?.ofcPhn}
                  </Typography>
                </Box>
                <Box
                  sx={{
                    padding: '10px',
                    background: '#F7F7F8',
                    borderRadius: '4px',
                    display: 'flex',
                    gap: '5px',
                    width: '100%',
                    minWidth: '200px',
                  }}
                >
                  <DeviceMobileIcon
                    appearance="filled"
                    sx={{ color: semantic.color.commonTextBasic }}
                  />
                  <Typography fontSize="13px" fontWeight={400} color="#1B1D22">
                    {empInfo?.empHphn}
                  </Typography>
                </Box>
              </Box>
            </Box>
          </Box>
        }
        handleClose={onClose}
      />
    </Box>
  );
};

export default EmployeeCard;
