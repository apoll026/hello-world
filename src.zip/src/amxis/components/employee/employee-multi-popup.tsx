/**
  Component Name : 사용자검색팝업(다건)
  Component ID   : employee-multi-popup
  Component Desc : WSF > 공통 > 사용자검색팝업(다건)
  Author         : lgho
  Create Date    : 2024.09.01
  modify Date    : 2024.11.01
*/
/** @jsxImportSource @emotion/react */
import { zodResolver } from '@hookform/resolvers/zod';
import { useEffect, useRef, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import * as z from 'zod';

import {
  DialogButtonGroup,
  DialogContent,
  DialogContentContainer,
  Spacer,
} from '@/amxis/components/layout/layouts.tsx';
import CustomDialogTitle from '@/amxis/components/modals/common/CustomDialogTitle.tsx';
import {
  AgGridReact,
  Button,
  DataGrid,
  Dialog,
  FormItem,
  HelperText,
  InputField,
  SearchArea,
  TitleArea,
} from '@amxis/design-system';
import { ArrowChevron2Icon, ControlConfirmIcon } from '@amxis/design-system/icon';
import { Box, Grid } from '@mui/material';

import { useDepartmentsQuery } from '@/amxis/hooks/queries/department/use-departments-query.ts';

import { DefaultCellTooltip } from '@/amxis/components/data-grid/default-cell-tooltip.tsx';
import { EmployeeSearchCondition } from '@/amxis/components/employee/employee-modal.types.ts';
import { RelativeLoader } from '@/amxis/components/loader';
import CustomDialog from '@/amxis/components/modals/common/CustomDialog.tsx';
import { useEmployeesQuery } from '@/amxis/hooks/queries/employee/use-employees-query.ts';
import { Employee } from '@/amxis/models/admin/Employee.ts';
import useSessionStore from '@/amxis/stores/useSessionStore.ts';
import DepartmentTree from '../department/department-tree.tsx';

type EmpMultiPopupProps = {
  open: boolean;
  onClose: () => void;
  selectedEmployee?: Employee[];
  onSave?: (employees: Employee[]) => void;
};

const EmployeeMultiPopup = ({ open, onClose, selectedEmployee, onSave }: EmpMultiPopupProps) => {
  const { t } = useTranslation();
  const { langCd } = useSessionStore();
  const searchSchema = z.object({
    searchItem: z
      .string()
      .refine(
        (value) => (value ?? '') === '' || value.length >= 2,
        String(
          t(
            'common.label.검색어는 두 글자 이상 입력해주세요.',
            '__검색어는 두 글자 이상 입력해주세요.'
          )
        )
      ),
  });
  type SearchForm = z.infer<typeof searchSchema>;
  const defaultValues: SearchForm = {
    searchItem: '',
  };

  const [employeeSearchCondition, setEmployeeSearchCondition] =
    useState<EmployeeSearchCondition>(defaultValues);

  const [addEmpList, setAddEmpList] = useState<Employee[]>([]);
  const [delEmpList, setDelEmpList] = useState<Employee[]>([]);
  const [selectedEmployees, setSelectedEmployees] = useState<Employee[]>([]);

  // modal
  const [isNoRowOpen, setIsNoRowOpen] = useState<boolean>(false);
  // query
  const { isLoading: isDepartmentsLoading, data: departmentsData } = useDepartmentsQuery({
    searchItem: '',
  });

  const { data: employeesData } = useEmployeesQuery(employeeSearchCondition);
  console.log(employeesData);

  const {
    handleSubmit,
    control,
    formState: { errors },
  } = useForm<SearchForm>({
    resolver: zodResolver(searchSchema),
    defaultValues,
  });

  useEffect(() => {
    if (!isDepartmentsLoading && departmentsData) {
      const userDeptCode = departmentsData.userDeptCode;
      setEmployeeSearchCondition({ deptCode: userDeptCode });
    }
  }, [isDepartmentsLoading, departmentsData]);

  useEffect(() => {
    if (selectedEmployee) {
      setSelectedEmployees(selectedEmployee);
    }
  }, []);

  // 검색시 '사용자목록'에만 결과출력
  const handleSearchClick = handleSubmit(({ searchItem }) => {
    if (searchItem !== '') {
      setEmployeeSearchCondition({
        searchItem: searchItem,
      });
    }
  });

  // 선택된목록에 추가
  const handleInsertEmpList = () => {
    if (addEmpList && addEmpList.length > 0) {
      const selectedMailIdList = addEmpList.map((row) => row.mailId);
      const alreadyInsertedEmpList = selectedEmployees.map((emp) => {
        if (selectedMailIdList.includes(emp.mailId)) {
          return emp.mailId;
        }
      });
      const filteredRows = addEmpList.filter(
        (selectedRow) => !alreadyInsertedEmpList.includes(selectedRow.mailId)
      );
      setSelectedEmployees((selectedEmpList) => [...selectedEmpList, ...filteredRows]);
    } else {
      setIsNoRowOpen(true);
      return;
    }
  };

  // 선택된목록에서 제거
  const handleExtractEmpList = () => {
    if (delEmpList && delEmpList.length > 0) {
      const selectedMailIdList = delEmpList.map((row) => row.mailId);
      setSelectedEmployees((selectedEmpList) =>
        selectedEmpList.filter((selectedEmp) => !selectedMailIdList.includes(selectedEmp.mailId))
      );
    } else {
      setIsNoRowOpen(true);
      return;
    }
  };

  // 전체목록 그리드에서 체크된 항목(추가할 항목)
  const gridRef = useRef<AgGridReact<Employee>>(null);
  const onSelectionChanged = () => {
    const selectedNodes = gridRef.current?.api.getSelectedNodes() ?? [];
    const selectedRows = selectedNodes
      .map((node) => node.data)
      .filter((row) => row !== undefined) as Employee[];
    setAddEmpList(selectedRows);
  };

  // 선택된목록 그리드에서 체크된 항목(제거할 항목)
  const gridRef2 = useRef<AgGridReact<Employee>>(null);
  const onSelectionChanged2 = () => {
    const selectedNodes = gridRef2.current?.api.getSelectedNodes() ?? [];
    const selectedRows = selectedNodes
      .map((node) => node.data)
      .filter((row) => row !== undefined) as Employee[];
    setDelEmpList(selectedRows);
  };

  // 선택 핸들러
  const handleOnSelect = () => {
    const isSelectedEmployees = selectedEmployees.length > 0;
    if (!isSelectedEmployees) {
      setIsNoRowOpen(true);
      return;
    }
    onSave?.(selectedEmployees);
  };

  return (
    <Dialog
      position="basic"
      type={'modal'}
      size={1400}
      open={open}
      handleClose={() => {
        onClose();
      }}
      customContentArea={
        <DialogContentContainer>
          <DialogContent>
            <Box width="100%">
              <SearchArea
                searchButtonLabel={String(t('common.button.조회', '__조회'))}
                conditions={
                  <>
                    <Grid item xs={6}>
                      <FormItem
                        label={String(t('user-choice-popup.label.검색어', '__검색어'))}
                        labelAlign="right"
                        render={() => (
                          <>
                            <Controller
                              control={control}
                              name="searchItem"
                              render={({ field: { ref, ...field } }) => (
                                <InputField
                                  {...field}
                                  fullWidth
                                  size="medium"
                                  status="default"
                                  textAlign="left"
                                  type="text"
                                  placeholder={String(
                                    t(
                                      'common.label.사용자 이름, 사용자ID, 부서명을 입력하세요.',
                                      '__사용자 이름, 사용자ID, 부서명을 입력하세요.'
                                    )
                                  )}
                                  onKeyUp={(e) => {
                                    if (e.key === 'Enter') handleSearchClick();
                                  }}
                                />
                              )}
                            />
                            <Box mt="4px">
                              <HelperText
                                infoText={(errors?.searchItem?.message as string) ?? ''}
                                usecase="error"
                              />
                            </Box>
                          </>
                        )}
                      />
                    </Grid>
                  </>
                }
                onSearch={handleSearchClick}
              />
            </Box>
            <Spacer type="h" size="12" />
            <Box sx={{ display: 'flex', gap: '24px', width: '100%' }}>
              <Box sx={{ width: '20%' }}>
                <TitleArea
                  isSubTitle
                  title={t('department-choice-popup.title.부서목록', '__부서목록')}
                  totalCases={departmentsData?.departmentList?.length ?? 0}
                  language={langCd === '' ? 'ko' : langCd}
                ></TitleArea>
                <Box sx={{ height: '648px', marginTop: '4px' }}>
                  {departmentsData && (
                    <DepartmentTree
                      departmentList={departmentsData?.departmentList ?? []}
                      initialDeptCd={departmentsData?.userDeptCode}
                      setEmployeeSearchCondition={setEmployeeSearchCondition}
                    />
                  )}
                </Box>
              </Box>

              <Box sx={{ width: '40%' }}>
                <DataGrid
                  columnDefs={[
                    {
                      width: 50,
                      sortable: false,
                      resizable: false,
                      headerClass: 'checkbox',
                      checkboxSelection: true,
                      headerCheckboxSelection: true,
                    },
                    {
                      field: 'empName',
                      resizable: false,
                      unSortIcon: false,
                      headerName: String(t('user-choice-popup.column.사용자명', '__사용자명')),
                      flex: 0.3,
                      tooltipComponent: DefaultCellTooltip,
                      tooltipField: 'empName',
                    },
                    {
                      field: 'deptName',
                      headerName: String(t('user-choice-popup.column.부서명', '__부서명')),
                      flex: 0.5,
                      tooltipComponent: DefaultCellTooltip,
                      tooltipField: 'deptName',
                    },
                    {
                      field: 'emlDmnIfoNm',
                      headerName: String(t('user-choice-popup.column.이메일', '__이메일')),
                      flex: 0.5,
                      tooltipComponent: DefaultCellTooltip,
                      tooltipField: 'emlDmnIfoNm',
                    },
                  ]}
                  currentPage={1}
                  gridHeight="648px"
                  isHeaderSectionEnabled
                  minGridHeight="648px"
                  rowData={employeesData}
                  rowHeight={25}
                  rowSelection="multiple"
                  title={String(t('common.label.전체목록', '__전체목록'))}
                  totalCount={employeesData?.length}
                  onSelectionChanged={onSelectionChanged}
                  gridRef={gridRef}
                  language={langCd === '' ? 'ko' : langCd}
                  emptyLabel={
                    t(
                      'common.label.조회 가능한 데이터가 없습니다.',
                      '__조회 가능한 데이터가 없습니다.'
                    ) ?? ''
                  }
                />
              </Box>

              <Box
                sx={{
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'center',
                  gap: '8px',
                }}
              >
                <Button
                  appearance="outlined"
                  iconComponent={<ArrowChevron2Icon direction="right" appearance="single" />}
                  onClick={handleInsertEmpList}
                  priority="normal"
                  size="large"
                />
                <Button
                  appearance="outlined"
                  iconComponent={<ArrowChevron2Icon direction="left" appearance="single" />}
                  onClick={handleExtractEmpList}
                  priority="normal"
                  size="large"
                />
              </Box>

              <Box sx={{ width: '40%' }}>
                <DataGrid
                  columnDefs={[
                    {
                      width: 50,
                      sortable: false,
                      resizable: false,
                      headerClass: 'checkbox',
                      checkboxSelection: true,
                      headerCheckboxSelection: true,
                    },
                    {
                      field: 'empName',
                      resizable: false,
                      unSortIcon: false,
                      headerName: String(t('user-choice-popup.column.사용자명', '__사용자명')),
                      flex: 0.3,
                      tooltipComponent: DefaultCellTooltip,
                      tooltipField: 'empName',
                    },
                    {
                      field: 'deptName',
                      headerName: String(t('user-choice-popup.column.부서명', '__부서명')),
                      flex: 0.5,
                      tooltipComponent: DefaultCellTooltip,
                      tooltipField: 'deptName',
                    },
                    {
                      field: 'emlDmnIfoNm',
                      headerName: String(t('user-choice-popup.column.이메일', '__이메일')),
                      flex: 0.5,
                      tooltipComponent: DefaultCellTooltip,
                      tooltipField: 'emlDmnIfoNm',
                    },
                  ]}
                  currentPage={1}
                  gridHeight="648px"
                  isHeaderSectionEnabled
                  minGridHeight="648px"
                  rowData={selectedEmployees ?? []}
                  rowHeight={25}
                  rowSelection="multiple"
                  title={String(t('common.label.선택한목록', '__선택한목록'))}
                  totalCount={selectedEmployees?.length}
                  onSelectionChanged={onSelectionChanged2}
                  gridRef={gridRef2}
                  language={langCd === '' ? 'ko' : langCd}
                  emptyLabel={
                    t(
                      'common.label.조회 가능한 데이터가 없습니다.',
                      '__조회 가능한 데이터가 없습니다.'
                    ) ?? ''
                  }
                />
              </Box>
            </Box>
          </DialogContent>
          <DialogButtonGroup>
            <Button
              appearance="outlined"
              priority="normal"
              size="medium"
              onClick={() => {
                onClose();
              }}
              buttonLabel={t('common.button.취소', '__취소')}
            />
            <Button
              appearance="contained"
              priority="primary"
              size="medium"
              onClick={handleOnSelect}
              iconComponent={<ControlConfirmIcon size="small" />}
              autoFocus
              buttonLabel={t('common.button.선택', '__선택')}
            />
          </DialogButtonGroup>
          <CustomDialog
            content={t('common.alert.선택된 행이 없습니다.', '__선택된 행이 없습니다.')}
            type="2"
            isOpen={isNoRowOpen}
            onClose={() => {
              setIsNoRowOpen(false);
            }}
            onSubmit={() => {
              setIsNoRowOpen(false);
            }}
          />
          <RelativeLoader isLoading={isDepartmentsLoading} />
        </DialogContentContainer>
      }
      customHeaderTitle={
        <CustomDialogTitle
          title={t('user-choice-popup.title.사용자 검색', '__사용자검색') as string}
        />
      }
    />
  );
};

export default EmployeeMultiPopup;
