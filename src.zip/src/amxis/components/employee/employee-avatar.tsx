import styled from '@emotion/styled';
import { Avatar, Chip, ChipAvatar, Tooltip } from '@amxis/design-system';
import { Box } from '@mui/system';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import EmployeeCard from './employee-card.tsx';
interface EmployeeAvatarProps {
  displayEmpNm?: string;
  userId?: string;
  type?: string;
  empNo?: string;
}

const useWindowSize = () => {
  const [size, setSize] = useState([0, 0]);
  useLayoutEffect(() => {
    const updateSize = () => {
      setSize([window.innerWidth, window.innerHeight]);
    };
    window.addEventListener('resize', updateSize);
    updateSize();
    return () => window.removeEventListener('resize', updateSize);
  }, []);
  return size;
};

const EmployeeAvatar = ({ displayEmpNm, type, empNo }: EmployeeAvatarProps) => {
  //Employee 명이 비어있다면 기본값은 ---
  const empName = displayEmpNm ? displayEmpNm : '---';

  const [toolTipFlag, setToolTipFlag] = useState<boolean>(false);
  const [width, height] = useWindowSize();
  const contentRef = useRef<HTMLDivElement>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleClickAvatar = (e) => {
    if (!isModalOpen && empNo && displayEmpNm) {
      setIsModalOpen(true);
    }
  };

  useEffect(() => {
    if (width && height) {
      if (contentRef.current) {
        const pHeight = contentRef.current.getBoundingClientRect().height;
        const cHeight = contentRef.current.querySelector('p')?.getBoundingClientRect().height;
        if (cHeight && cHeight > pHeight) {
          setToolTipFlag(false);
        } else {
          setToolTipFlag(true);
        }
      }
    }
  }, [width, height]);

  const [isImageLoaded, setIsImageLoaded] = useState<boolean | null>(null);

  // useEffect(() => {
  //   const img = new Image();
  //   if (empNo) {
  //     img.src = `https://hr.lginnotek.com/cm/service/image/download.ncd?baRs=DOWNLOAD&baRq=IN_DOWNLOAD&IN_DOWNLOAD.FILE_ID=${empNo}`;
  //
  //     img.onload = () => {
  //       setIsImageLoaded(true);
  //     };
  //
  //     img.onerror = () => {
  //       setIsImageLoaded(false);
  //     };
  //   }
  // }, []);

  return type === 'chip' ? ( // chip 높이 28
    <Tooltip placement="bottom" title={empName} type="hover" disableHoverListener={toolTipFlag}>
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
        }}
        ref={contentRef}
      >
        <Chip
          className="first"
          chipText={empName}
          onClick={handleClickAvatar}
          leadingContents={
            <ChipAvatar
              border
              contentType="icon-inversed"
              countBadge={0}
              statusBadge="online"
              textAvatar="ami client"
              size={'small'}
            />
          }
          size="medium"
          type="input"
          sx={{
            height: '28px',
            '& > div': {
              overflow: 'hidden',
              textOverflow: 'ellipsis',
            },
          }}
        />
        {isModalOpen && (
          <EmployeeCard open={isModalOpen} onClose={() => setIsModalOpen(false)} empNo={empNo} />
        )}
      </Box>
    </Tooltip>
  ) : type === 'grid' ? ( // chip 높이 24
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        // , justifyContent: 'center'
      }}
    >
      <Tooltip placement="bottom" title={empName ?? ''} type="hover">
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
          }}
          ref={contentRef}
        >
          {isModalOpen && (
            <EmployeeCard open={isModalOpen} onClose={() => setIsModalOpen(false)} empNo={empNo} />
          )}
          <Chip
            chipText={empName}
            onClick={handleClickAvatar}
            leadingContents={
              <ChipAvatar
                border
                contentType="icon-inversed"
                countBadge={0}
                statusBadge="online"
                textAvatar="ami client"
                size={'small'}
                sx={{
                  color: '#FFFFFF',
                  // width: '16px',
                  // height: '16px',
                }}
              />
            }
            size="small"
            type="action"
          />
        </Box>
      </Tooltip>
    </Box>
  ) : type === 'bbs' ? (
    <AvatarBox onClick={handleClickAvatar}>
      <Box
        sx={{
          '& .MuiBadge-root': {
            verticalAlign: 'baseline',
          },
        }}
      >
        {isModalOpen && (
          <EmployeeCard open={isModalOpen} onClose={() => setIsModalOpen(false)} empNo={empNo} />
        )}
        <Avatar size="xxsmall" alt={empName} contentType="icon-inversed" textAvatar={empName} />
      </Box>
      <span
        id="target-tooltip"
        style={{
          fontSize: '12px',
          fontWeight: '600',
          textOverflow: 'ellipsis',
          overflow: 'hidden',
        }}
      >
        {empName}
      </span>
    </AvatarBox>
  ) : type === 'bbsChip' ? (
    <Box sx={{ display: 'flex' }}>
      <Chip
        chipText={empName}
        onClick={handleClickAvatar}
        leadingContents={
          <ChipAvatar
            border
            contentType="icon-inversed"
            countBadge={0}
            statusBadge="online"
            textAvatar="ami client"
            size={'small'}
          />
        }
        size="large"
        type="input"
      />
      {isModalOpen && (
        <EmployeeCard open={isModalOpen} onClose={() => setIsModalOpen(false)} empNo={empNo} />
      )}
    </Box>
  ) : (
    //배경없는 Avatar
    <AvatarBox onClick={handleClickAvatar}>
      <Avatar
        size="xxsmall"
        alt={empName}
        contentType="image"
        textAvatar={empName}
        sx={{
          alignSelf: 'flex-start',
        }}
        src={
          ''
          // isImageLoaded
          //   ? `https://hr.lginnotek.com/cm/service/image/download.ncd?baRs=DOWNLOAD&baRq=IN_DOWNLOAD&IN_DOWNLOAD.FILE_ID=${empNo}`
          //   : ''
        }
      />
      <span
        id="target-tooltip"
        style={{ fontSize: '13px', textOverflow: 'ellipsis', overflow: 'hidden' }}
      >
        {empName}
      </span>
      {isModalOpen && (
        <EmployeeCard open={isModalOpen} onClose={() => setIsModalOpen(false)} empNo={empNo} />
      )}
    </AvatarBox>
  );
};

const AvatarBox = styled.div`
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 4px;

  .MuiBadge-root {
    vertical-align: top;
  }
`;

const popupCenter = ({ url, title, w = 1102, h = 870 }) => {
  // Fixes dual-screen position                             Most browsers      Firefox
  const dualScreenLeft = window.screenLeft !== undefined ? window.screenLeft : window.screenX;
  const dualScreenTop = window.screenTop !== undefined ? window.screenTop : window.screenY;

  const width = window.innerWidth
    ? window.innerWidth
    : document.documentElement.clientWidth
    ? document.documentElement.clientWidth
    : screen.width;
  const height = window.innerHeight
    ? window.innerHeight
    : document.documentElement.clientHeight
    ? document.documentElement.clientHeight
    : screen.height;

  const systemZoom = width / window.screen.availWidth;
  const left = (width - w) / 2 / systemZoom + dualScreenLeft;
  const top = (height - h) / 2 / systemZoom + dualScreenTop;

  const newWindow = window.open(
    url,
    title,
    `
    scrollbars=yes,
    width=${w / systemZoom}, 
    height=${h / systemZoom}, 
    top=${top}, 
    left=${left}
    `
  );

  if (newWindow) newWindow.focus();
};

export default EmployeeAvatar;
