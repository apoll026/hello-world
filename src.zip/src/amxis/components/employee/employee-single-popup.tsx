/**
  Component Name : 사용자검색팝업(단건)
  Component ID   : employee-single-popup
  Component Desc : WSF > 공통 > 사용자검색팝업(단건)
  Author         : lgho
  Create Date    : 2024.09.01
  modify Date    : 2024.11.01
*/
/** @jsxImportSource @emotion/react */
import * as z from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm, Controller } from 'react-hook-form';
import { useState, useRef, useEffect } from 'react';
import { useTranslation } from 'react-i18next';

import { Box } from '@mui/material';
import { Grid } from '@mui/material';
import {
  DialogButtonGroup,
  DialogContentContainer,
  DialogContent,
  Spacer,
} from '@/amxis/components/layout/layouts.tsx';
import CustomDialogTitle from '@/amxis/components/modals/common/CustomDialogTitle.tsx';
import {
  AgGridReact,
  Button,
  DataGrid,
  DataGridCellHeaderRadio,
  DataGridCellRadio,
  Dialog,
  FormItem,
  InputField,
  SearchArea,
  TitleArea,
  HelperText,
} from '@amxis/design-system';
import { ControlConfirmIcon } from '@amxis/design-system/icon';

import { Employee } from '@/amxis/models/admin/Employee.ts';
import { useDepartmentsQuery } from '@/amxis/hooks/queries/department/use-departments-query.ts';
import { EmployeeSearchCondition } from '@/amxis/components/employee/employee-modal.types.ts';
import DepartmentTree from '../department/department-tree.tsx';
import { RelativeLoader } from '@/amxis/components/loader';
import CustomDialog from '@/amxis/components/modals/common/CustomDialog.tsx';
import { DefaultCellTooltip } from '@/amxis/components/data-grid/default-cell-tooltip.tsx';
import useSessionStore from '@/amxis/stores/useSessionStore.ts';
import { useEmployeesQuery } from '@/amxis/hooks/queries/employee/use-employees-query.ts';
import { DepartmentSearchCondition } from '../department/department-modal.types.ts';

// 사용자 검색 단건 팝업
type EmpSinglePopupProps = {
  open: boolean;
  setOpen;
  selectedEmployee?: Employee[];
  onSave?: (employees: Employee[]) => void;
};

const EmployeeSinglePopup = ({ open, setOpen, selectedEmployee, onSave }: EmpSinglePopupProps) => {
  const { t } = useTranslation();
  const { langCd } = useSessionStore();
  const [selectedEmployees, setSelectedEmployees] = useState<Employee[]>([]);
  const searchSchema = z.object({
    searchItem: z
      .string()
      .refine(
        (value) => (value ?? '') === '' || value.length >= 2,
        String(
          t(
            'common.label.검색어는 두 글자 이상 입력해주세요.',
            '__검색어는 두 글자 이상 입력해주세요.'
          )
        )
      ),
  });
  type SearchForm = z.infer<typeof searchSchema>;
  const defaultValues: SearchForm = {
    searchItem: '',
  };
  const [departmentSearchCondition, setDepartmentSearchCondition] =
    useState<DepartmentSearchCondition>(defaultValues);
  const [employeeSearchCondition, setEmployeeSearchCondition] =
    useState<EmployeeSearchCondition>(defaultValues);
  // modal
  const [isNoRowOpen, setIsNoRowOpen] = useState<boolean>(false);
  // query
  const { isLoading: isDepartmentsLoading, data: departmentsData } =
    useDepartmentsQuery(departmentSearchCondition);
  const { data: employeesData } = useEmployeesQuery(employeeSearchCondition);
  console.log(employeesData);

  const {
    handleSubmit,
    control,
    formState: { errors },
  } = useForm<SearchForm>({
    resolver: zodResolver(searchSchema),
    defaultValues,
  });

  useEffect(() => {
    if (!isDepartmentsLoading && departmentsData) {
      const userDeptCd = departmentsData.userDeptCode;
      setEmployeeSearchCondition({ deptCode: userDeptCd });
    }
  }, [isDepartmentsLoading, departmentsData]);

  useEffect(() => {
    if (selectedEmployee) {
      setSelectedEmployees(selectedEmployee);
    }
  }, []);
  // 검색시 '사용자목록'에만 결과출력
  const handleSearchClick = handleSubmit(({ searchItem }) => {
    if (searchItem !== '') {
      setEmployeeSearchCondition({
        searchItem: searchItem,
      });
    }
  });

  // 사용자목록 그리드에서 선택된 항목(추가할 항목)
  const gridRef = useRef<AgGridReact<Employee>>(null);
  const onSelectionChanged = () => {
    const selectedNodes = gridRef.current?.api.getSelectedNodes() ?? [];
    const selectedRows = selectedNodes
      .map((node) => node.data)
      .filter((row) => row !== undefined) as Employee[];
    setSelectedEmployees(selectedRows);
  };

  // 선택 핸들러
  const handleOnSelect = () => {
    const isSelectedEmployees = selectedEmployees.length > 0;
    if (!isSelectedEmployees) {
      setIsNoRowOpen(true);
      return;
    }
    onSave?.(selectedEmployees);
  };

  return (
    <Dialog
      position="basic"
      type={'modal'}
      size={1200}
      open={open}
      handleClose={() => {
        setOpen(false);
      }}
      customContentArea={
        <DialogContentContainer>
          <DialogContent>
            <Box width="100%">
              <SearchArea
                conditions={
                  <>
                    <Grid item xs={6}>
                      <FormItem
                        label={String(t('user-choice-popup.label.검색어', '__검색어'))}
                        labelAlign="right"
                        render={() => (
                          <>
                            <Controller
                              control={control}
                              name="searchItem"
                              render={({ field: { ref, ...field } }) => (
                                <InputField
                                  {...field}
                                  fullWidth
                                  size="medium"
                                  status="default"
                                  textAlign="left"
                                  type="text"
                                  placeholder={String(
                                    t(
                                      'common.label.사용자 이름, 사용자ID, 부서명을 입력하세요.',
                                      '__사용자 이름, 사용자ID, 부서명을 입력하세요.'
                                    )
                                  )}
                                  onKeyUp={(e) => {
                                    if (e.key === 'Enter') handleSearchClick();
                                  }}
                                />
                              )}
                            />
                            <Box mt="4px">
                              <HelperText
                                infoText={(errors?.searchItem?.message as string) ?? ''}
                                usecase="error"
                              />
                            </Box>
                          </>
                        )}
                      />
                    </Grid>
                  </>
                }
                onSearch={handleSearchClick}
                searchButtonLabel={t('common.button.조회', '__조회') ?? ''}
              />
            </Box>
            <Spacer type="h" size="12" />
            <Box sx={{ display: 'flex', gap: '24px', width: '100%' }}>
              <Box sx={{ width: '40%' }}>
                <TitleArea
                  isSubTitle
                  title={t('department-choice-popup.title.부서목록', '__부서목록')}
                  totalCases={departmentsData?.departmentList?.length ?? 0}
                  language={langCd === '' ? 'ko' : langCd}
                ></TitleArea>
                <Box sx={{ height: '415px', marginTop: '4px', width: '322px' }}>
                  {departmentsData && (
                    <DepartmentTree
                      departmentList={departmentsData?.departmentList ?? []}
                      initialDeptCd={departmentsData?.userDeptCode}
                      setEmployeeSearchCondition={setEmployeeSearchCondition}
                    />
                  )}
                </Box>
              </Box>
              <Box sx={{ width: '100%' }}>
                <DataGrid
                  rowSelection="single"
                  singleClickEdit={false}
                  columnDefs={[
                    {
                      width: 34,
                      sortable: false,
                      resizable: false,
                      headerComponent: () => <DataGridCellHeaderRadio />,
                      cellRenderer: DataGridCellRadio,
                    },
                    {
                      field: 'empName',
                      resizable: false,
                      unSortIcon: false,
                      headerName: String(t('user-choice-popup.column.사용자명', '__사용자명')),
                      tooltipComponent: DefaultCellTooltip,
                      tooltipField: 'empName',
                      flex: 0.3,
                    },
                    {
                      field: 'mailId',
                      headerName: String(t('user-choice-popup.column.사용자ID', '__사용자ID')),
                      flex: 0.3,
                      tooltipComponent: DefaultCellTooltip,
                      tooltipField: 'mailId',
                    },
                    {
                      field: 'deptName',
                      headerName: String(t('user-choice-popup.column.부서명', '__부서명')),
                      flex: 0.5,
                      tooltipComponent: DefaultCellTooltip,
                      tooltipField: 'deptName',
                    },
                    {
                      field: 'emlDmnIfoNm',
                      headerName: String(t('user-choice-popup.column.이메일', '__이메일')),
                      flex: 0.5,
                      tooltipComponent: DefaultCellTooltip,
                      tooltipField: 'emlDmnIfoNm',
                    },
                  ]}
                  currentPage={1}
                  gridHeight="415px"
                  isHeaderSectionEnabled
                  minGridHeight="415px"
                  sxOfWrapper={{
                    height: '300px',
                  }}
                  rowData={employeesData}
                  rowHeight={25}
                  title={String(t('to-inform.label.사용자목록', '__사용자목록'))}
                  totalCount={employeesData?.length}
                  onSelectionChanged={onSelectionChanged}
                  gridRef={gridRef}
                  language={langCd === '' ? 'ko' : langCd}
                  emptyLabel={
                    t(
                      'common.label.조회 가능한 데이터가 없습니다.',
                      '__조회 가능한 데이터가 없습니다.'
                    ) ?? ''
                  }
                />
              </Box>
            </Box>
          </DialogContent>
          <Spacer type="h" size="4" />
          <DialogButtonGroup>
            <Button
              appearance="outlined"
              priority="normal"
              size="medium"
              onClick={() => {
                setOpen(false);
              }}
              buttonLabel={t('common.button.취소', '__취소')}
            />
            <Button
              appearance="contained"
              priority="primary"
              size="medium"
              onClick={handleOnSelect}
              iconComponent={<ControlConfirmIcon size="small" />}
              autoFocus
              buttonLabel={t('common.button.선택', '__선택')}
            />
          </DialogButtonGroup>
          <CustomDialog
            content={t('common.alert.선택된 행이 없습니다.', '__선택된 행이 없습니다.')}
            type="2"
            isOpen={isNoRowOpen}
            onClose={() => {
              setIsNoRowOpen(false);
            }}
            onSubmit={() => {
              setIsNoRowOpen(false);
            }}
          />
          <RelativeLoader isLoading={isDepartmentsLoading} />
        </DialogContentContainer>
      }
      customHeaderTitle={
        <CustomDialogTitle
          title={t('user-choice-popup.title.사용자 검색', '__사용자검색') as string}
        />
      }
    />
  );
};

export default EmployeeSinglePopup;
