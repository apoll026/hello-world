/* eslint-disable */
import { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router';
import { AuthUtil } from '@/amxis/utils/ApiUtil.ts';
import useLanguageStore from '@/amxis/stores/useLanguageStore.ts';
import useSessionStore from '@/amxis/stores/useSessionStore.ts';
import { createAccessLog } from './menu-provider.utils.ts';
import { useMenuContext } from './menu-provider.tsx';

function MenuProviderInitializer({ children }: { children: React.ReactNode }) {
  const { pathname } = useLocation();
  const { mailId, menus, setSession } = useSessionStore();
  const { changeLanguage, initLanguage } = useLanguageStore();
  const { handleShowMenuChange } = useMenuContext();

  const [initialized, setInitialized] = useState(false);

  const initialize = async () => {
    try {
      if (mailId || pathname === '/login' || pathname.indexOf('template') != -1) {
        return;
      }

      const session = await AuthUtil.validateSession();
      if (session) {
        changeLanguage(session.langCd || 'ko');
        setSession(session);

        // 메뉴 접근 로그 생성
        if (pathname !== '/') {
          const menuId = menus
            .filter((menu) => menu.pgmUrl && pathname.endsWith(menu.pgmUrl))
            .map((menu) => menu.pgmId)
            .find(Boolean);
          menuId && createAccessLog(menuId);
        }
      } else {
        return;
      }
    } catch (e :any) {
      console.error('초기화 중 오류:', e);
      if (e?.response?.status !== 403) {
        AuthUtil.handleLoginRedirect();
      }
    } finally {
      setInitialized(true);
    }
  };

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    if (params.get('showMenu') === 'No' || params.get('appint_url')) {
      handleShowMenuChange(false);
      initLanguage();
    }

    initialize();
  }, []);

  if (!initialized) {
    // TODO: loading or inform message
    return null;
  }

  return <>{children}</>;
}

export { MenuProviderInitializer };
