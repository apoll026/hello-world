import { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router';
import { getSession } from '@/amxis/apis/Session.ts';
import useLanguageStore from '@/amxis/stores/useLanguageStore.ts';
import useSessionStore from '@/amxis/stores/useSessionStore.ts';
import { createAccessLog } from './menu-provider.utils.ts';
import { useMenuContext } from './menu-provider.tsx';
import {
  CommonRequest,
  CommonResponse,
  Method,
  ServiceName,
} from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';

function useMenuInitEffect() {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const { mailId, menus, setSession } = useSessionStore();
  const { changeLanguage, initLanguage } = useLanguageStore();
  const { handleShowMenuChange } = useMenuContext();

  const initialize = async () => {
    const response = await getSession();
    if (response.successOrNot === 'Y' && response?.data) {
      const session = response.data;
      changeLanguage(session.langCd || 'ko');
      setSession(session);

      if (pathname !== '/') {
        const menuId = menus
          .filter((menu) => menu.pgmUrl && pathname.endsWith(menu.pgmUrl))
          .map((menu) => menu.pgmId)
          .find(Boolean);
        menuId && createAccessLog(menuId);
      }
    } else if (response.successOrNot === 'N') {
      const appEnv = `${process.env.NODE_ENV}`;

      if (appEnv == 'local') {
        navigate('/login', { replace: false });
        return;
      } else {
        console.log('use-menu-init-effects');
        const request: CommonRequest = {
          method: Method.GET,
          url: `/v1/sso/redirect-url`,
          serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
        };
        const response: CommonResponse<string> = await callApi(request);
        console.log(response);
        if (response?.data) {
          window.location.href = response.data;
        } else {
          window.location.href = `/login`;
        }
      }
    }
  };

  useEffect(() => {
    const params = new URLSearchParams(location.search);

    if (params.get('showMenu') === 'No' || params.get('appint_url')) {
      handleShowMenuChange(false);
      initLanguage();
    }
    if (!mailId && pathname !== '/login') {
      initialize();
    }
  }, []);
}

export { useMenuInitEffect };
