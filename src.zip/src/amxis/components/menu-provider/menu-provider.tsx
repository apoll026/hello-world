import { createContext, useContext, useState, useCallback, useMemo } from 'react';
import { MenuContextType, defaultMenuContext } from '@/amxis/models/admin/Menu.ts';
import { MenuProviderInner } from './menu-provider-inner.tsx';
import { MenuProviderInitializer } from './menu-provider-initializer.tsx';

const MenuContext = createContext<MenuContextType>(defaultMenuContext);

function useMenuContext() {
  const context = useContext(MenuContext);
  if (!context) {
    throw new Error('MenuContext must be used within MenuProvider');
  }

  return context;
}

type MenuProviderProps = {
  children: React.ReactNode;
};

function MenuProvider({ children }: MenuProviderProps) {
  const [showMenu, setShowMenu] = useState(true);
  const [menuState, setMenuState] = useState(defaultMenuContext);
  
  // handleMenuChange 함수 메모이제이션
  const handleMenuChange = useCallback((item: MenuContextType) => {
    setMenuState(item);
  }, []);
  
  // handleShowMenuChange 함수 메모이제이션  
  const handleShowMenuChange = useCallback((isShowMenu: boolean) => {
    setShowMenu(isShowMenu);
  }, []);
  
  // contextValue 메모이제이션
  const contextValue = useMemo(() => ({
    ...menuState,
    showMenu,
    handleMenuChange,
    handleShowMenuChange,
  }), [menuState, showMenu, handleMenuChange, handleShowMenuChange]);

  return (
    <MenuContext.Provider value={contextValue}>
      <MenuProviderInitializer>
        <MenuProviderInner>{children}</MenuProviderInner>
      </MenuProviderInitializer>
    </MenuContext.Provider>
  );
}

export { MenuProvider, useMenuContext };
