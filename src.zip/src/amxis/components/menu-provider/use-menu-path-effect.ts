import { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router';
import useSessionStore from '@/amxis/stores/useSessionStore.ts';
import { HomeMenu, INTERNAL_MENU_PATHS, Menu } from '@/amxis/models/admin/Menu.ts';
import { useMenuContext } from './menu-provider.tsx';

// 특정 메뉴가 선택된 헤더 메뉴의 하위 메뉴인지 확인하는 헬퍼 함수
function isChildOfSelectedHeader(menu: Menu, selectedHeaderId: string, allMenus: Menu[]): boolean {
  if (!menu.upgmId) return false;
  
  // 직접적인 자식인 경우
  if (menu.upgmId === selectedHeaderId) return true;
  
  // 재귀적으로 상위 메뉴를 찾아 올라가기
  const parentMenu = allMenus.find(m => m.pgmId === menu.upgmId);
  if (!parentMenu) return false;
  
  return isChildOfSelectedHeader(parentMenu, selectedHeaderId, allMenus);
}

function useMenuPathEffect() {
  const navigate = useNavigate();
  const { pathname } = useLocation();

  const { menus, headerMenus } = useSessionStore();
  const menuContext = useMenuContext();

  const { handleMenuChange } = menuContext;

  useEffect(() => {
    if (menus?.length > 0) {
      const currentUrl = location.pathname.substring(1);

      if (currentUrl === '') {
        handleMenuChange({
          ...menuContext,
          currentMenu: HomeMenu,
          clickedByHeaderMenu: false,
          selectedHeaderMenu: '',
        });
        return;
      }

      // 현재 선택된 헤더 메뉴의 하위 메뉴에서 우선 찾기
      let menuEqualsByCurrentUrl = menus.find((menu) => 
        menu.pgmUrl === currentUrl && 
        menuContext.selectedHeaderMenu && 
        isChildOfSelectedHeader(menu, menuContext.selectedHeaderMenu, menus)
      );
      
      // 헤더 메뉴 하위에서 찾지 못했다면 전체에서 찾기
      if (!menuEqualsByCurrentUrl) {
        menuEqualsByCurrentUrl = menus.find((menu) => menu.pgmUrl === currentUrl);
      }

      if (menuEqualsByCurrentUrl) {
        handleMenuChange({
          ...menuContext,
          currentMenu: menuEqualsByCurrentUrl,
          clickedByHeaderMenu: false,
          selectedHeaderMenu:
            headerMenus.find((headerMenu) => headerMenu.pgmId === menuEqualsByCurrentUrl.upgmId)
              ?.pgmId ?? menuContext.selectedHeaderMenu,
        });
        return;
      }

      const internalMenuEqualsByCurrentUrl = INTERNAL_MENU_PATHS.find(
        (internalMenu) => internalMenu === currentUrl
      );

      if (internalMenuEqualsByCurrentUrl) {
        handleMenuChange({
          ...menuContext,
          clickedByHeaderMenu: false,
        });
        return;
      }

      let menuSimilarByCurrentUrl: Menu | undefined;
      let splittedUrls = currentUrl.split('/');
      let len = splittedUrls.length;
      while (len > 1) {
        splittedUrls = splittedUrls.slice(0, len - 1);
        const similarUrl = splittedUrls.join('/');
        // 헤더 메뉴 하위에서 우선 찾기
        menuSimilarByCurrentUrl = menus.find((menu) => 
          menu.pgmUrl && similarUrl === menu.pgmUrl &&
          menuContext.selectedHeaderMenu && 
          isChildOfSelectedHeader(menu, menuContext.selectedHeaderMenu, menus)
        );
        
        // 헤더 메뉴 하위에서 찾지 못했다면 전체에서 찾기
        if (!menuSimilarByCurrentUrl) {
          menuSimilarByCurrentUrl = menus.find((menu) => menu.pgmUrl && similarUrl === menu.pgmUrl);
        }

        if (menuSimilarByCurrentUrl) {
          break;
        }
        len = splittedUrls.length;
      }

      if (menuSimilarByCurrentUrl) {
        handleMenuChange({
          ...menuContext,
          currentMenu: menuSimilarByCurrentUrl,
          clickedByHeaderMenu: false,
          selectedHeaderMenu:
            headerMenus.find((headerMenu) => headerMenu.pgmId === menuSimilarByCurrentUrl!.upgmId)
              ?.pgmId ?? menuContext.selectedHeaderMenu,
        });

        return;
      }

      handleMenuChange({
        ...menuContext,
        currentMenu: HomeMenu,
        clickedByHeaderMenu: false,
        selectedHeaderMenu: '',
      });
      navigate('/errorPage', { replace: false });
    }
  }, [pathname, menus]);
}

export { useMenuPathEffect };
