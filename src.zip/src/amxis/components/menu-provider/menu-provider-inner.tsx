import { useMenuAccessEffect } from './use-menu-access-effect.ts';
import { useMenuPathEffect } from './use-menu-path-effect.ts';

type MenuProviderInnerProps = {
  children: React.ReactNode;
};

function MenuProviderInner({ children }: MenuProviderInnerProps) {
  useMenuAccessEffect();
  useMenuPathEffect();

  return <>{children}</>;
}

export { MenuProviderInner };
