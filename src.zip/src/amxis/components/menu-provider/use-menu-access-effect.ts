import { useEffect } from 'react';
import { useLocation } from 'react-router';
import { createAccessLog, createAccessLogByPath } from './menu-provider.utils.ts';
import useSessionStore from '@/amxis/stores/useSessionStore.ts';

function useMenuAccessEffect() {
  const { pathname } = useLocation();
  const { mailId, menus } = useSessionStore();

  useEffect(() => {
    if (pathname !== '/' && mailId) {
      const menuId = menus
        .filter((menu) => menu.pgmUrl && pathname.endsWith(menu.pgmUrl))
        .map((menu) => menu.pgmId)
        .find(Boolean);
      if (menuId) {
        createAccessLog(menuId);
      } else {
        createAccessLogByPath(pathname);
      }
    }
  }, [pathname]);
}

export { useMenuAccessEffect };
