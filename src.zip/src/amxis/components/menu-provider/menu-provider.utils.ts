import { createMenuAccessLog } from '@/amxis/apis/admin/Log.ts';

function createAccessLog(menuId: string) {
  createMenuAccessLog(menuId);
}

function createAccessLogByPath(path: string) {
  createMenuAccessLog(path);
}

export { createAccessLog, createAccessLogByPath };
