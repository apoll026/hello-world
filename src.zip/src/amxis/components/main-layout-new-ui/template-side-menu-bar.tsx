import { useTheme } from '@amxis/design-system';
import { Box, Typography } from '@mui/material';
import { SidebarToggleButton } from '@/amxis/components/sidebar-toggle-button';
import { useState } from 'react';
import { TemplateSideMenuList } from './template-side-menu-list.tsx';
import { mockSideMenu } from './mockData.ts';
import { useLocation } from 'react-router-dom';

type TemplateSideMenuBarProps = {
  handleMenuBarClick?: (isOpen: boolean) => void;
};

function TemplateSideMenuBar({ handleMenuBarClick }: TemplateSideMenuBarProps) {
  const location = useLocation();

  const [isOpened, setIsOpened] = useState(
    !location.pathname.includes('home1') &&
      !location.pathname.includes('home2') &&
      !location.pathname.includes('home3')
  );
  const [theme] = useTheme();
  const sideMenus = mockSideMenu;

  return (
    <>
      {sideMenus.length > 0 && (
        <Box
          position="relative"
          zIndex={11}
          width={isOpened ? '240px' : '0'}
          height="calc(100vh - 52px)"
          bgcolor={theme.palette.semantic.color.commonBgDeep}
          borderRight={`1px solid ${theme.palette.semantic.color.commonBorderBasic}`}
          sx={{
            transition: '0.3s',
          }}
        >
          {isOpened && (
            <Box
              width="100%"
              height="100%"
              sx={{
                overflowY: 'auto',
              }}
            >
              <Box
                padding="24px 30px 16px 12px"
                borderBottom={`1px solid ${theme.palette.semantic.color.commonBorderBasic}`}
              >
                {/* {generateHeaderMenuName(menuContext.selectedHeaderMenu)} */}
                <Typography
                  fontSize={14}
                  fontWeight={700}
                  color={theme.palette.semantic.color.commonTextLight}
                >
                  1Depth Menu Name
                </Typography>
              </Box>
              {sideMenus.map((it) => (
                <TemplateSideMenuList
                  key={it.menuInfo.pgmId}
                  summary={{ menuInfo: it.menuInfo }}
                  content={it.children}
                  isActive={false}
                />
              ))}
            </Box>
          )}

          <SidebarToggleButton
            onClick={() => {
              setIsOpened(!isOpened);
              handleMenuBarClick?.(!isOpened);
            }}
            isClicked={isOpened}
          />
        </Box>
      )}
    </>
  );
}

export { TemplateSideMenuBar };
