import { useTheme } from '@amxis/design-system';
import { Box, Typography } from '@mui/material';
import { useTranslation } from 'react-i18next';
import { mockHeaderMenus } from './mockData.ts';
// import useSessionStore from 'stores/useSessionStore';

function TemplateHeaderLinkList() {
  //   const { headerMenus, menus } = useSessionStore();
  const headerMenus = mockHeaderMenus;
  const { t } = useTranslation();
  const [theme] = useTheme();

  return (
    <Box height="100%" display="flex" alignItems="center">
      <Box
        height="100%"
        display="flex"
        gap="50px"
        sx={{
          '@media (max-width: 1600px)': {
            gap: '40px',
          },
          '@media (max-width: 1400px)': {
            gap: '30px',
          },
        }}
      >
        {headerMenus &&
          headerMenus.map((menu) => (
            <Box
              //   component={Link}
              key={menu.pgmId}
              position="relative"
              width="fit-content"
              height="100%"
              display="flex"
              alignItems="center"
              justifyContent="center"
              sx={{
                cursor: 'pointer',
              }}
            >
              <Typography
                fontSize="14px"
                fontWeight={700}
                color={
                  menu.pgmId === '000001'
                    ? theme.palette.semantic.color.commonTextPrimary
                    : theme.palette.semantic.color.commonTextLighter
                }
              >
                {t(`${menu.msgCtn}`, `${menu.pgmName}`)}
              </Typography>
              <Box
                position="absolute"
                display={menu.pgmId === '000001' ? 'block' : 'none'}
                width="120%"
                height="3px"
                bottom="-15px"
                left="50%"
                bgcolor={theme.palette.semantic.color.navTopBorderSelected}
                sx={{
                  transform: 'translateX(-50%)',
                  transition: '3s',
                }}
              />
            </Box>
          ))}
      </Box>
    </Box>
  );
}

export { TemplateHeaderLinkList };
