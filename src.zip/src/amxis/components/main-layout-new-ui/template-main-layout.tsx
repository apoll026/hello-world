import { Breadcrumb, TitleArea, useTheme } from '@amxis/design-system';
import { Box } from '@mui/material';
import { useMenuContext } from '@/amxis/components/menu-provider';
import { Outlet, useLocation } from 'react-router';
import { usePreventRightClickEffect } from '../main-layout/use-prevent-right-click-effect.ts';
import { usePreventDevToolShortcutEffect } from '../main-layout/use-prevent-dev-tool-shortcut-effect.ts';
import { NoticePopupModals } from '../main-layout/notice-popup-modals.tsx';
import { TemplateHeaderMenuBar } from './template-header-menu-bar.tsx';
import { TemplateSideMenuBar } from './template-side-menu-bar.tsx';
import { QuickMenuBar } from './quick-menu-bar.tsx';
import { useState } from 'react';

type TemplateMainLayoutProps = {
  noPaddingPage?: boolean;
  noShowPageHeader?: boolean;
  noShowPageHeaderBreadcrumbMenu?: boolean;
  showQuickMenu?: boolean;
  paddingX?: string;
};

function TemplateMainLayout({
  noPaddingPage = false,
  noShowPageHeader = false,
  noShowPageHeaderBreadcrumbMenu = false,
  showQuickMenu = false,
  paddingX = '32px',
}: TemplateMainLayoutProps) {
  const location = useLocation();
  const { showMenu } = useMenuContext();
  const [theme] = useTheme();

  usePreventRightClickEffect();
  usePreventDevToolShortcutEffect();

  const hasMenuBar = showMenu && location.pathname !== '/errorPage';

  return (
    <>
      {hasMenuBar && <TemplateHeaderMenuBar />}
      <Box
        width="100%"
        flex="1"
        display="flex"
        height={showMenu ? 'calc(100vh - 52px)' : '100%'}
        position="relative"
        borderBottom={`1px solid ${theme.palette.semantic.color.commonBorderBasic}`}
        bgcolor={theme.palette.semantic.color.navTopBgBasic}
      >
        {hasMenuBar && <TemplateSideMenuBar />}
        <Box
          flex="1"
          display="flex"
          flexDirection="column"
          height={showMenu ? 'calc(100vh - 52px)' : '100%'}
          bgcolor={theme.palette.semantic.color.commonBgBasic}
          paddingLeft={noPaddingPage ? '0' : paddingX}
          paddingRight={noPaddingPage ? '0' : paddingX}
          sx={{
            transition: '0.3s',
            overflowY: 'auto',
          }}
        >
          {!noShowPageHeader && (
            <Box
              sx={{
                height: '48px',
                width: '100%',
                padding: '12px 0 4px 0',
              }}
            >
              <TitleArea
                bookmark={false}
                breadcrumb={
                  noShowPageHeaderBreadcrumbMenu ? null : (
                    <Breadcrumb
                      data={[
                        { label: 'Home', onClick: () => {}, url: '/home' },
                        { label: 'Child1', onClick: () => {}, url: '/child1' },
                        { label: 'Page Name' },
                      ]}
                    />
                  )
                }
                onFavorite={() => {}}
                onShow={() => {}}
                isSubTitle={false}
                bullet={false}
                title="화면 타이틀"
              />
            </Box>
          )}
          <Box
            flex="1"
            sx={{
              '&.hasInnerNav': {
                padding: '0 30px 50px 0',
              },
            }}
          >
            <Outlet />
          </Box>
        </Box>
        {showQuickMenu && <QuickMenuBar />}
      </Box>
    </>
  );
}

function PlainMainLayout() {
  return <TemplateMainLayout noPaddingPage noShowPageHeader noShowPageHeaderBreadcrumbMenu />;
}

function NewUIMainLayoutWithNoticePopups() {
  return (
    <>
      <TemplateMainLayout />
      <NoticePopupModals />
    </>
  );
}

export { PlainMainLayout, TemplateMainLayout, NewUIMainLayoutWithNoticePopups };
