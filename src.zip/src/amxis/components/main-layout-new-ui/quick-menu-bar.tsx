import { Button, useTheme } from '@amxis/design-system';
import {
  FileApprovalIcon,
  FunctionCalendarIcon,
  FunctionMailIcon,
  FunctionSettingIcon,
  OtherPiechartIcon,
  UserUserIcon,
} from '@amxis/design-system/icon';
import { Box, Stack } from '@mui/material';

interface IQuickMenuBarProps {}

export const QuickMenuBar = () => {
  const [theme] = useTheme();
  return (
    <Box
      height={'100%'}
      width={'48px'}
      borderLeft={`1px solid ${theme.palette.semantic.color.commonBorderBasic}`}
    >
      <Stack
        spacing={1}
        alignItems={'center'}
        padding="8px 3px"
        color={theme.palette.semantic.color.commonTextBasic}
        sx={{
          '.MuiButton-root .MuiButton-icon svg': {
            fontSize: '24px',
          },
        }}
      >
        <Button
          size="large"
          iconComponent={<FileApprovalIcon appearance="lined" iconSize={24} />}
          appearance="unfilled"
          priority="normal"
        />
        <Button
          size="large"
          iconComponent={<FunctionMailIcon appearance="lined" iconSize={24} />}
          appearance="unfilled"
          priority="normal"
        />
        <Button
          size="large"
          iconComponent={<OtherPiechartIcon appearance="lined" iconSize={24} />}
          appearance="unfilled"
          priority="normal"
        />
        <Button
          size="large"
          iconComponent={<FunctionCalendarIcon appearance="lined" iconSize={24} />}
          appearance="unfilled"
          priority="normal"
        />
        <Button
          size="large"
          iconComponent={<UserUserIcon appearance="lined" iconSize={24} />}
          appearance="unfilled"
          priority="normal"
        />
        <Button
          size="large"
          iconComponent={<FunctionSettingIcon appearance="lined" iconSize={24} />}
          appearance="unfilled"
          priority="normal"
        />
      </Stack>
    </Box>
  );
};
