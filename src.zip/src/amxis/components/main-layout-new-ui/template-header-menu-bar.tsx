import useSessionStore from '@/amxis/stores/useSessionStore.ts';
import { Avatar, Button, OptionList, Switch, useTheme } from '@amxis/design-system';
import {
  CommunicationBookmarkIcon,
  FunctionSettingIcon,
  MenuMoreIcon,
  StatusHelpIcon,
} from '@amxis/design-system/icon';
import { Box } from '@mui/material';
import { useMenuContext } from '@/amxis/components/menu-provider';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { TemplateHeaderLinkList } from './template-header-link-list.tsx';
import { mockHeaderMenus } from './mockData.ts';

function Logo() {
  const { langCd } = useSessionStore();
  const menuContext = useMenuContext();
  const [theme] = useTheme();

  const handleMenuBar = () => {
    menuContext.handleMenuChange({ ...menuContext, selectedHeaderMenu: '' });
  };
  return (
    <Box height="51px" display="flex">
      <Box
        component={Link}
        onClick={handleMenuBar}
        to={'/'}
        display="flex"
        color={theme.palette.semantic.color.navTopTextSysNamePrimary}
        margin="0"
        height="100%"
        flex="0 0 20rem"
        alignItems="center"
        justifyContent="start"
      >
        <Box
          component="span"
          alignSelf="end"
          marginLeft="14px"
          height="100%"
          display="flex"
          alignItems="flex-start"
          flexDirection="column"
          justifyContent="center"
        >
          <Box
            component="span"
            display="inline-block"
            fontSize="14px"
            fontWeight={400}
            color={
              !langCd || langCd === 'ko'
                ? theme.palette.semantic.color.navTopTextSysNamePrimary
                : theme.palette.semantic.color.navTopTextSysNameBasic
            }
            whiteSpace={!langCd || langCd === 'ko' ? 'initial' : 'pre-line'}
          >
            한글시스템명
          </Box>
          <Box
            component="span"
            marginTop="3px"
            display="inline-block"
            fontSize="12px"
            fontWeight={300}
            color={theme.palette.semantic.color.navTopTextSysNameBasic}
          >
            English System Name
          </Box>
        </Box>
      </Box>
    </Box>
  );
}

function TemplateHeaderMenuBar() {
  //   const { headerMenus, userId } = useSessionStore();
  //   const { displayEmpNm } = useDisplayEmpName();
  const displayEmpNm = '이노택';
  const headerMenus = mockHeaderMenus;
  const menuContext = useMenuContext();
  const [theme, toggleTheme] = useTheme();

  const [anchorEl, setAnchorEl] = useState<null | HTMLElement | SVGSVGElement>(null);
  const handleClickMoreMenu = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(anchorEl ? null : event.currentTarget);
  };

  return (
    <Box
      position="relative"
      zIndex={10}
      width="100%"
      height="52px"
      bgcolor={theme.palette.semantic.color.navTopBgBasic}
      display="flex"
      alignItems="center"
      justifyContent="space-between"
      paddingRight="22px"
      borderBottom={`1px solid ${theme.palette.semantic.color.commonBorderBasic}`}
    >
      <Box
        height="100%"
        display="flex"
        alignItems="center"
        paddingLeft={'35px'}
        borderLeft={
          menuContext.selectedHeaderMenu
            ? 'none'
            : `16px solid ${theme.palette.semantic.color.commonBgPrimary}`
        }
      >
        <Logo />
      </Box>
      <>
        <Box>
          <TemplateHeaderLinkList />
        </Box>
        <Box height="100%" display="flex" alignItems="center" gap="8px">
          {headerMenus.filter((menu) => menu.useYn === 'Y').length > 5 && (
            <>
              <Button
                appearance="unfilled"
                iconComponent={<MenuMoreIcon direction="horizontal" />}
                iconPosition="leading"
                onClick={handleClickMoreMenu}
                priority="normal"
                size="small"
              />
              <OptionList
                sx={{ zIndex: '101' }}
                options={headerMenus
                  .filter((menu) => menu.useYn === 'Y')
                  .filter((menu, index) => index > 4)
                  .map((menu) => ({
                    label: menu.pgmName || '',
                    value: menu.pgmId || '',
                  }))}
                anchorEl={anchorEl}
                open={Boolean(anchorEl)}
                onMouseLeave={() => {
                  setAnchorEl(null);
                }}
                type="none"
                onSelectClick={(value) => {
                  const selectedMenu = headerMenus.find((menu) => menu.pgmId === value);

                  selectedMenu &&
                    menuContext.handleMenuChange({
                      ...menuContext,
                      selectedHeaderMenu: selectedMenu.pgmId,
                      clickedByHeaderMenu: true,
                    });
                }}
              />
            </>
          )}
          <Box
            display="flex"
            alignItems="center"
            gap="8px"
            color={theme.palette.semantic.color.commonTextLight}
          >
            <CommunicationBookmarkIcon
              appearance="lined"
              iconSize={24}
              sx={{ cursor: 'pointer', verticalAlign: 'middle' }}
            />
            <StatusHelpIcon
              appearance="lined"
              iconSize={24}
              sx={{ cursor: 'pointer', verticalAlign: 'middle' }}
            />
            <FunctionSettingIcon
              appearance="lined"
              iconSize={24}
              sx={{ cursor: 'pointer', verticalAlign: 'middle' }}
            />
          </Box>
          <Box height="30px">
            <Switch
              color="primary"
              onChange={() => {
                toggleTheme();
              }}
              type="contained-icon"
              checked
            />
          </Box>
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              gap: '4px',
              marginRight: '8px',
              cursor: 'pointer',
            }}
          >
            <Avatar size="xsmall" alt={displayEmpNm} contentType="icon" textAvatar={displayEmpNm} />
            <Box
              sx={{ paddingTop: '4px' }}
              fontSize="13px"
              color={theme.palette.semantic.color.commonTextLight}
            >
              {displayEmpNm}
            </Box>
          </Box>
        </Box>
      </>
    </Box>
  );
}

export { TemplateHeaderMenuBar };
