import { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Box, Typography } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import { useTheme } from '@amxis/design-system';
import { useMenuContext } from '@/amxis/components/menu-provider';
import { Menu } from '@/amxis/models/admin/Menu.ts';
import useSessionStore from '@/amxis/stores/useSessionStore.ts';
import { toAbsolutePath } from '../main-layout/main-layout.utils.ts';
import { RootPgm } from '@/amxis/models/common/Session.ts';

type SideMenuContentProps = {
  contentList: Menu[];
  isActive: boolean;
  openParent: () => void;
};

type SideMenuSummaryProps = {
  header: Menu;
  isSelectedMenu: boolean;
  hasEpsMenus: boolean;
};

function SideMenuSummary({ header, isSelectedMenu, hasEpsMenus }: SideMenuSummaryProps) {
  const { t } = useTranslation();
  const [theme] = useTheme();

  const fontColor = (() => {
    if (hasEpsMenus) {
      return isSelectedMenu
        ? theme.palette.semantic.color.navLeftTextSelected
        : theme.palette.semantic.color.commonTextBasic;
    }

    return isSelectedMenu
      ? theme.palette.semantic.color.commonTextPrimary
      : theme.palette.semantic.color.commonTextBasic;
  })();

  return (
    <Box display="flex" alignItems="center" gap="8px">
      {header.pgmUrl ? (
        <Link to={toAbsolutePath(header.pgmUrl)}>
          <Typography
            fontSize="13px"
            color={fontColor}
            sx={{
              wordBreak: 'keep-all',
              whiteSpace: 'pre',
            }}
          >
            {t(`${header.msgCtn}`, `${header.pgmName}`)}
          </Typography>
        </Link>
      ) : (
        <Typography
          fontSize="13px"
          color={fontColor}
          sx={{
            wordBreak: 'keep-all',
            whiteSpace: 'pre',
          }}
        >
          {t(`${header.msgCtn}`, `${header.pgmName}`)}
        </Typography>
      )}
    </Box>
  );
}

function SideMenuContent({ contentList, isActive, openParent }: SideMenuContentProps) {
  const [count, setCount] = useState<number>(1);
  const { currentMenu } = useMenuContext();
  const { menus } = useSessionStore();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [theme] = useTheme();
  currentMenu.pgmId = '000008';
  const navigateToMenu = (prgmUrl: string) => {
    prgmUrl && navigate(toAbsolutePath(prgmUrl), { replace: false });
  };

  useEffect(() => {
    if (contentList.find((item) => item.pgmId === currentMenu?.pgmId)) {
      openParent();
    } else if (currentMenu) {
      let cur: Menu | null = currentMenu;

      while (cur.pgmId != RootPgm) {
        cur = menus.find((menu) => menu.pgmId === cur?.upgmId) ?? null;
        if (!cur) break;
        const lowestParent = contentList.find((item) => item.pgmId === cur?.pgmId);
        if (lowestParent) {
          openParent();
          break;
        }
      }
    }
  }, [currentMenu]);

  return (
    <>
      {contentList.map((it) => {
        if (it.childrens && it.childrens.some((child) => child.useYn === 'Y')) {
          return (
            <Box
              width="100%"
              height={isActive ? `calc(40px * ${count})` : 0}
              overflow="hidden"
              sx={{
                transition: 'height 0.35s ease',
              }}
              key={it.pgmId}
              onClick={() => setCount(isActive ? it.childrens?.length ?? 0 + 1 : 1)}
            >
              {/* <TemplateSideMenuList
                  summary={{ menuInfo: it }}
                  content={it.childrens}
                  isActive={isActive}
                  openParent={openParent}
                /> */}
            </Box>
          );
        }

        const isCurrentMenu =
          currentMenu?.pgmId === it.pgmId ||
          (currentMenu?.useYn === 'N' && currentMenu?.upgmId === it.pgmId);

        return (
          <Box
            width="100%"
            height={isActive ? 'calc(40px * 1)' : 0}
            overflow="hidden"
            bgcolor={
              isCurrentMenu
                ? theme.palette.semantic.color.navLeftBgLastChildSelected
                : theme.palette.semantic.color.navLeftBg3Level
            }
            borderLeft={
              isCurrentMenu ? `4px solid ${theme.palette.semantic.color.commonBgPrimary}` : 'none'
            }
            sx={{
              transition: 'height 0.35s ease',
            }}
            key={it.pgmId}
            onClick={() => {
              navigateToMenu(it.pgmUrl ?? '');
            }}
          >
            <Box
              component={Link}
              to={it.pgmUrl ? toAbsolutePath(it.pgmUrl) : '/errorPage'}
              width="100%"
              height="100%"
              paddingLeft="36px"
              display="flex"
              alignItems="center"
              color={
                isCurrentMenu
                  ? theme.palette.semantic.color.commonTextPrimary
                  : theme.palette.semantic.color.commonTextBasic
              }
              fontSize="12px"
              sx={{
                cursor: 'pointer',
                transition: '0.3s',
                '&:hover': {
                  color: isCurrentMenu
                    ? theme.palette.semantic.color.commonTextInverse
                    : theme.palette.semantic.color.commonTextPrimary,
                },
              }}
            >
              {t(`${it.msgCtn}`, `${it.pgmName}`)}
            </Box>
          </Box>
        );
      })}
    </>
  );
}

type SideMenuListProps = {
  summary: { menuInfo: Menu };
  content: Menu[];
  isActive: boolean;
  openParent?: () => void;
};

function TemplateSideMenuList({ summary, content, isActive, openParent }: SideMenuListProps) {
  const [isOpen, setIsOpen] = useState(isActive);
  // const { t } = useTranslation();
  const navigate = useNavigate();
  const { currentMenu } = useMenuContext();
  const [theme] = useTheme();

  const { menuInfo } = summary;

  const isCurrentMenu =
    currentMenu?.pgmId === menuInfo.pgmId ||
    (currentMenu?.useYn === 'N' && currentMenu?.upgmId === menuInfo.pgmId);
  const hasEpsMenus = content.some((item) => item.useYn === 'Y');
  const isSelectedMenu = hasEpsMenus ? isOpen : currentMenu?.pgmId === menuInfo.pgmId;

  const navigateToMenu = (prgmUrl: string, linkTo?: boolean) => {
    linkTo && prgmUrl && navigate(toAbsolutePath(prgmUrl), { replace: false });
    setIsOpen(!isOpen);
  };

  useEffect(() => {
    isOpen && openParent && openParent();
  }, [isOpen]);

  return (
    <Box width="100%" display="flex" flexDirection="column" overflow="hidden">
      {menuInfo.useYn === 'Y' && (
        <Box
          width="100%"
          height="40px"
          display="flex"
          alignItems="center"
          justifyContent="space-between"
          padding="0 15px"
          overflow="hidden"
          bgcolor={
            isCurrentMenu
              ? theme.palette.semantic.color.navLeftBgLastChildSelected
              : theme.palette.semantic.color.commonBgDeep
          }
          sx={{
            cursor: 'pointer',
            transition: '0.3s',
            '&:hover': {
              bgcolor: isCurrentMenu
                ? theme.palette.semantic.color.navLeftBgLastChildSelected
                : theme.palette.semantic.color.navLeftBg1LevelHover,
            },
          }}
          onClick={() => {
            navigateToMenu(menuInfo.pgmUrl ?? '', !hasEpsMenus);
          }}
        >
          <SideMenuSummary
            header={menuInfo}
            isSelectedMenu={isSelectedMenu}
            hasEpsMenus={hasEpsMenus}
          />
          {hasEpsMenus && (
            <>
              {isSelectedMenu ? (
                <RemoveIcon
                  fontSize="small"
                  sx={{
                    width: '13px',
                    height: '13px',
                    transition: '0.3s',
                  }}
                />
              ) : (
                <AddIcon
                  fontSize="small"
                  sx={{
                    width: '13px',
                    height: '13px',
                    transition: '0.3s',
                  }}
                />
              )}
              a
            </>
          )}
        </Box>
      )}
      {hasEpsMenus && (
        <SideMenuContent
          contentList={content.filter((item) => item.useYn === 'Y')}
          isActive={isOpen}
          openParent={() => setIsOpen(true)}
        />
      )}
    </Box>
  );
}

export { TemplateSideMenuList };
