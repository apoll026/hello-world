import { useFilesUploadMutation } from '@/amxis/hooks/queries/file/use-files-upload-mutation.ts';
import { FileInfo, FileSaveResult } from '@/amxis/models/admin/FileInfo.ts';
import { FileUploader } from '@/amxis/components/ui/file-uploader';
import { BoxProps } from '@mui/material';
//import {  FileUploader} from "@amxis/design-system";
import { CSSProperties, forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { useFindFilesQuery } from '@/amxis/hooks/queries/file/use-find-files-query.ts';
import { useFilesUpdateMutation } from '@/amxis/hooks/queries/file/use-files-update-mutation.ts';
import CustomDialog from '@/amxis/components/modals/common/CustomDialog.tsx';
import { useTranslation } from 'react-i18next';
import { initial, lowerCase } from 'lodash';
import { getUploadPreSignedUrl } from '@/amxis/apis/common/FilePreSignedUrl.ts';
import axios from 'axios';
import { filesize } from 'filesize';

type CustomFileUploaderProps = {
  atchFileGrId?: string;
  fileMaxCnt?: number; //첨부파일 최대 갯수
  containerBoxProps?: BoxProps;
  acceptFiles?: string[];
  multiple?: boolean;
  currentSize?: number;
  selectedFiles?: File[];

  onFileChange?: (value: File[]) => void;
  renderFooter?: () => JSX.Element;
  placeholder?: string;
  initialFiles?: File[];
  initialGrId?: string;
  sxFileName?: CSSProperties;
  variant?: 'default' | 'readonly' | 'thumbnail' | 'namo';
  isRaw?: boolean;
  totalFileSizeLimit?: number;
  setFilelength?: (len: number) => void;
};

// eslint-disable-next-line react/display-name
export const CustomFileUploader = forwardRef(
  (
    {
      fileMaxCnt = Number.MAX_SAFE_INTEGER,
      totalFileSizeLimit = Number.MAX_SAFE_INTEGER,
      ...rest
    }: CustomFileUploaderProps,
    ref: React.Ref<any>
  ) => {
    const [selectedFiles, setSelectedFiles] = useState<File[]>(rest.initialFiles ?? []);
    const { t } = useTranslation();
    const { mutateAsync: filesUploadMutateAsync } = useFilesUploadMutation();
    const { mutateAsync: filesUpdateMutateAsync } = useFilesUpdateMutation();
    const { data: rawfiles } = useFindFilesQuery(rest.initialGrId);
    const [isPopupOpen, setIsPopupOpen] = useState<any>({
      tp: false,
      size: false,
      cnt: false,
      dup: false,
    });
    const deletedFiles = useRef<FileInfo[]>([]);
    useEffect(() => {
      setSelectedFiles(rest.initialFiles ?? []);
    }, [rest.initialFiles]);
    useEffect(() => {}, [selectedFiles]);
    // const createDownloadURL = (atchFileId: string, atchFileGrId: string) => {
    //   return `${process.env.API_BASE_URL}/api/v1/file/download?atchFileGrId=${atchFileGrId}&atchFileId=${atchFileId}`;
    // };

    const handleSaveFiles = async () => {
      const oldFiles = selectedFiles.filter((file, idx) => 'atchFileId' in file);
      //만약 atchFileId를 비교해서 initialFiles에는 있는데 oldFiles에는 없는 파일이 있다면 삭제된 파일이므로 deletedFiles에서 atchFileId로 찾아서 useYn을 N으로 변경
      if (rest.initialFiles?.length) {
        const deletedFileIds = rest.initialFiles
          .filter((item) => !oldFiles.some((file) => file.atchFileId === item.atchFileId))
          .map((item) => item.atchFileId);
        deletedFiles.current = deletedFiles.current.map((item) => {
          if (deletedFileIds.includes(item.atchFileId)) {
            return { ...item, useYn: 'N' };
          }
          return item;
        });
      }
      updateFiles(deletedFiles.current);
      const response = await uploadFiles(selectedFiles);
      return response;
    };
    const updateFiles = async (files: FileInfo[]) => {
      if (!files || files.length === 0) return;

      const response = await filesUpdateMutateAsync(files);
      if (!response) {
        throw new Error('failed file update');
      }
    };

    useImperativeHandle(ref, () => ({
      getFileListLength: () => {
        return selectedFiles.length;
      },

      handleSaveFiles: () => {
        return handleSaveFiles();
      },
    }));

    const getExtension = (filename: string) => {
      const parts = filename.split('.');
      return parts.length > 1 ? '.' + parts[parts.length - 1] : undefined;
    };

    const validationCheck = (files: File[]) => {
      let fileSize: number = 0;
      const result = files.map((item) => {
        fileSize += item.size;
        const extension = '.' + lowerCase(getExtension(item.name)).replace(/\s+/g, '');
        if (!rest.acceptFiles?.includes(extension ?? '')) {
          setIsPopupOpen({ ...isPopupOpen, tp: true });
          return false;
        }
      });
      if (result.includes(false)) {
        return false;
      }
      if (files.length > fileMaxCnt) {
        setIsPopupOpen({ ...isPopupOpen, cnt: true });
        return false;
      }

      if (fileSize / (1024 * 1024) > totalFileSizeLimit) {
        setIsPopupOpen({ ...isPopupOpen, size: true });
        return false;
      }

      return true;
    };

    const refineFiles = (files: File[]) => {
      const addFiles: File[] = [];
      const fileNames = new Set<string>();
      let chk = false;
      files.forEach((item) => {
        if (!fileNames.has(item.name)) {
          addFiles.push(item);
          fileNames.add(item.name);
        } else chk = true;
      });

      if (chk) setIsPopupOpen({ ...isPopupOpen, dup: chk });

      return addFiles;
    };

    const handleFileOnChange = (files: File[]) => {
      if (!validationCheck(files)) return;
      const addFiles: File[] = refineFiles(files);
      setSelectedFiles(addFiles);
      deletedFiles.current = rawfiles ?? [];
    };
    const blobToFile = (blob: Blob, fileName: string): File => {
      const file = new File([blob], fileName);
      return file;
    };
    const uploadFiles = async (files: File[] = []) => {
      try {
        const appEnv = `${process.env.NODE_ENV}`;
        if (appEnv == 'local') {
          if (files.length === 0) {
            return {
              atchFileGrId: '',
              fileSaveResult: FileSaveResult.NONE,
            };
          }
          const atchFileGrId = rest.atchFileGrId ? rest.atchFileGrId : uuidv4();

          const fileFormData = new FormData();
          const fileSortOrdList: string[] = [];
          const transBlob: File[] = [];

          const result = await Promise.all(
            files.map(async (data) => {
              try {
                // const blob = await urlToBlob(data.url);
                const blob = data;
                const fileName = data.name;
                const file = blobToFile(blob, fileName);
                transBlob.push(file);
              } catch (error) {
                console.error('Fail to fetch URL');
                throw new Error('Fail to fetch URL');
              }
            })
          )
            .then(async () => {
              for (const file of transBlob) {
                fileFormData.append('files', file!);
              }
              if (fileFormData.has('files')) {
                fileFormData.append('atchFileGrId', atchFileGrId);
                fileFormData.append('fileSortOrds', fileSortOrdList.filter(Boolean).join(','));
                fileFormData.append('atchFileTpCd', '');
                const response = await filesUploadMutateAsync(fileFormData);
                if (!response) {
                  throw new Error('failed file upload');
                } else {
                  return {
                    atchFileGrId,
                    fileSaveResult: FileSaveResult.SUCCESS,
                  };
                }
              }
            })
            .catch((e) => {});
          if (result) {
            return result;
          } else {
            throw new Error('failed file upload');
          }
        } else {
          if (files.length === 0 && selectedFiles.length === 0) {
            return {
              atchFileGrId: '',
              fileSaveResult: FileSaveResult.NONE,
            };
          } else if (files.length === 0) {
            return {
              atchFileGrId: '',
              fileSaveResult: FileSaveResult.NOTUPDATED,
            };
          }

          const atchFileGrId = rest.initialGrId || uuidv4();
          const atchFileTpCd: string = '';
          const fileSizeArr: number[] = [];
          const fileNameArr: String[] = [];
          const fileTypeArr: String[] = [];
          const newFiles = files.filter((file, idx) => !('atchFileId' in file));
          const oldFiles = files.filter((file, idx) => 'atchFileId' in file);
          for (const idx in newFiles) {
            if (!('atchFileId' in newFiles[idx])) {
              fileSizeArr.push(newFiles[idx].size);
              fileNameArr.push(newFiles[idx].name.replace(/,/g, '_'));
              fileTypeArr.push(newFiles[idx].type);
            }
          }
          const preSignedUrlResponse = await getUploadPreSignedUrl(
            atchFileGrId,
            fileSizeArr.join(','),
            fileNameArr.join(','),
            fileTypeArr.join(','),
            atchFileTpCd
          );
          if (preSignedUrlResponse) {
            // Pre가지고 파일 업로드
            for (const idx in preSignedUrlResponse) {
              await axios.put(preSignedUrlResponse[idx].preSignedUrl + '', newFiles[idx], {
                headers: {
                  'Content-Type': newFiles[idx].type,
                },
              });
            }
          }
          return {
            atchFileGrId,
            fileSaveResult: FileSaveResult.SUCCESS,
          };
        }
      } catch (e) {
        console.error(e);

        return {
          atchFileGrId: '',
          fileSaveResult: FileSaveResult.FAIL,
        };
      }
    };

    // const handleFileClick = (fileName: string, fileUrl: string) => {
    //   try {
    //     const link = document.createElement('a');
    //     link.href = fileUrl;
    //     link.setAttribute('download', fileName);
    //     document.body.appendChild(link);
    //     link.click();
    //     document.body.removeChild(link);
    //   } catch (error) {
    //     console.log(error);
    //   }
    // };

    return (
      <div>
        <FileUploader
          selectedFiles={selectedFiles}
          onFileChange={handleFileOnChange}
          totalFileSizeLimit={totalFileSizeLimit}
          //onFileClick={handleFileClick}
          //containerBoxProps={{ maxWidth: '100%' }}
          {...rest}
        />
        <CustomDialog
          content={t(
            'com.msg.rstcFileFrmt',
            `__첨부할 수 없는 파일 형식입니다.(첨부가능한 파일 형식 : ${rest.acceptFiles})`,
            { acceptFiles: rest.acceptFiles }
          )}
          title={t('com.label.chk', '__확인')}
          type="2"
          isOpen={isPopupOpen.tp}
          onSubmit={() => {
            setIsPopupOpen({ ...isPopupOpen, tp: false });
          }}
          onClose={() => {
            setIsPopupOpen({ ...isPopupOpen, tp: false });
          }}
        />
        <CustomDialog
          content={t('com.msg.rstcFileCnt', `__총 ${fileMaxCnt}개의 파일까지 첨부 가능합니다.`, {
            fileMaxCnt: fileMaxCnt,
          })}
          title={t('com.label.chk', '__확인')}
          type="2"
          isOpen={isPopupOpen.cnt}
          onSubmit={() => {
            setIsPopupOpen({ ...isPopupOpen, cnt: false });
          }}
          onClose={() => {
            setIsPopupOpen({ ...isPopupOpen, cnt: false });
          }}
        />
        <CustomDialog
          content={t(
            'com.msg.rstcFileCapa',
            `__총 ${totalFileSizeLimit}MB의 파일까지 첨부 가능합니다.`,
            { totalFileSizeLimit: totalFileSizeLimit }
          )}
          title={t('com.label.chk', '__확인')}
          type="2"
          isOpen={isPopupOpen.size}
          onSubmit={() => {
            setIsPopupOpen({ ...isPopupOpen, size: false });
          }}
          onClose={() => {
            setIsPopupOpen({ ...isPopupOpen, size: false });
          }}
        />
        <CustomDialog
          content={t('com.msg.rstcFileNmDupl', `__이미 같은 이름의 파일이 존재합니다.`)}
          title={t('com.label.chk', '__확인')}
          type="2"
          isOpen={isPopupOpen.dup}
          onSubmit={() => {
            setIsPopupOpen({ ...isPopupOpen, dup: false });
          }}
          onClose={() => {
            setIsPopupOpen({ ...isPopupOpen, dup: false });
          }}
        />
      </div>
    );
  }
);
