import { MenuProvider } from '@/amxis/components/menu-provider';
import { ReactQueryProvider } from '@/amxis/components/react-query-provider';
import { ThemeProvider } from '@/amxis/components/theme-provider';
import { CookiesProvider } from '../cookie-provider';
import { MessageBarProvider } from '@amxis/design-system';

type ProvidersProps = {
  children: React.ReactNode;
};

function Providers({ children }: ProvidersProps) {
  return (
    <CookiesProvider>
      <ThemeProvider>
        <ReactQueryProvider>
          <MessageBarProvider>
            <MenuProvider>{children}</MenuProvider>
          </MessageBarProvider>
        </ReactQueryProvider>
      </ThemeProvider>
    </CookiesProvider>
  );
}

export { Providers };
