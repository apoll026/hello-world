import { Tag } from '@amxis/design-system';
import { useTranslation } from 'react-i18next';

type BoardTypeTagProps = {
  bbsTpCd: string;
};

function BoardTypeTag({ bbsTpCd }: BoardTypeTagProps) {
  const { t } = useTranslation();

  if (bbsTpCd === 'NOTI') {
    return (
      <Tag colorType="colorD" appearance="boxing">
        {t('notice.label.공지', '공지')}
      </Tag>
    );
  }

  if (bbsTpCd === 'ASK') {
    return (
      <Tag colorType="colorA" appearance="boxing">
        {t('notice.label.문의', '문의')}
      </Tag>
    );
  }

  if (bbsTpCd === 'OPIN') {
    return (
      <Tag colorType="warning-major" appearance="boxing">
        {t('notice.label.의견', '의견')}
      </Tag>
    );
  }

  return null;
}

export { BoardTypeTag };
