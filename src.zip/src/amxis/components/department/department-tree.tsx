/**
  Component Name : 부서검색팝업 tree
  Component ID   : department-tree.tsx
  Component Desc : 공통
  Author         : lgho
  Create Date    : 2024.09.01
  modify Date    : 2024.11.01
*/
import React, { useEffect, useState } from 'react';
// import { Tree, TreeData, findTreeParentIds } from '@/components/tree';
import { Department } from '@/amxis/models/admin/Department.ts';
import useDepartmentStore from '@/amxis/stores/useDepartmentStore.ts';
import { findTreeParentIds, Tree, TreeData } from '@amxis/design-system';
// import useDepartmentStore from '@/stores/erpm/board/useDepartmentStore';
// import useExtensionStore from '@/stores/erpm/board/useExtensionStore';

type DepartmentTreeProps = {
  departmentList: Department[];
  initialDeptCd?: string;
  hasCheck?: boolean;
  setEmployeeSearchCondition?: any;
};

type MakeTreeDataParams = {
  departmentList: Department[];
  parentDeptCd?: string[];
  initialDeptCd?: string;
};

function makeTreeData({ departmentList, parentDeptCd = ['0'], initialDeptCd }: MakeTreeDataParams) {
  if (departmentList.length === 0) {
    return [];
  }

  return departmentList
    .sort((a) => {
      // 상단 법인 우선정렬
      if (a.upprDeptCode == '') {
        return -1;
      }
      return 1;
    })
    .filter((department) => parentDeptCd.includes(department.upprDeptCode ?? ''))
    .map((department) => ({
      id: department.deptCode,
      nodeName: department.deptName,
      deptNm: department.deptName,
      deptCd: department.deptCode,
      isSelected: department.deptCode == initialDeptCd ? true : false,
      childrens: makeTreeData({ departmentList, parentDeptCd: [department.deptCode], initialDeptCd }),
    }));
}

const DepartmentTree = ({
  departmentList,
  initialDeptCd,
  hasCheck,
  setEmployeeSearchCondition,
}: DepartmentTreeProps) => {
  const { setCheckedList } = useDepartmentStore((state) => state);
  // const { checkedContent } = useExtensionStore((state) => state);

  const [tree, setTree] = useState<TreeData[]>([]);
  const [expandedNodes, setExpandedNodes] = useState<string[]>([]);

  const data = makeTreeData({ departmentList, initialDeptCd });

  // 로그인한 사용자 부서까지의 경로 펼쳐짐
  useEffect(() => {
    if (data) {
      setTree(data);
      if (initialDeptCd) {
        const expanded = findTreeParentIds(data, String(initialDeptCd));
        setExpandedNodes([...expanded]);
      } else {
        setExpandedNodes([]);
      }
    }
  }, [departmentList, initialDeptCd]);

  // 팝업 안에서 체크 시 initTree 1depth 펼쳐짐
  // useEffect(() => {
  //   // 체크 해제 시 펼쳐짐 방어(체크 했을 때에만 펼쳐짐)
  //   if (checkedContent[1] === true) {
  //     const newExpanded = findTreeParentIds(tree, checkedContent[0]);
  //     setExpandedNodes([...expandedNodes, ...newExpanded]);
  //   }
  // }, [checkedContent]);

  // 체크된 노드 추가
  const onChangeTree = (id: string, checked: boolean, checkedNodes: TreeData[]) => {
    setCheckedList(checkedNodes);
  };

  const onClickTree = (id: string, selected: TreeData[]) => {
    if (expandedNodes.includes(id) && selected[0]?.id === id) {
      setEmployeeSearchCondition({
        deptCd: id,
      });
      return;
    } else if (expandedNodes.includes(id)) {
      setExpandedNodes(expandedNodes.filter((item) => item !== id));
    } else {
      setExpandedNodes([...expandedNodes, id]);
    }

    if (!hasCheck) {
      setEmployeeSearchCondition({
        deptCd: id,
      });
    }
  };

  return (
    <>
      {tree && (
        <>
          {hasCheck ? (
            <Tree
              data={tree}
              maxDepth={8}
              onClick={onClickTree}
              onChange={onChangeTree}
              variant="triangle"
              hasCheckBox
              expandedNodes={expandedNodes}
              // setExpandedNodes={setExpandedNodes}
            />
          ) : (
            <Tree
              data={tree}
              maxDepth={8}
              onClick={onClickTree}
              variant="triangle"
              expandedNodes={expandedNodes}
              // setExpandedNodes={setExpandedNodes}
            />
          )}
        </>
      )}
    </>
  );
};

export default React.memo(DepartmentTree);
