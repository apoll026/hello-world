export type DepartmentSearchCondition = {
  searchItem?: string;
  deptName?: string;
};
