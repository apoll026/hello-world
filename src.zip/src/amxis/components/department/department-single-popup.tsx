/**
  Component Name : 부서검색팝업(단건)
  Component ID   : department-single-popup
  Component Desc : WSF > 공통 > 부서검색팝업(단건)
  Author         : lgho
  Create Date    : 2024.09.01
  modify Date    : 2024.11.01
*/
/** @jsxImportSource @emotion/react */
import * as z from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useState, useRef, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useForm, Controller } from 'react-hook-form';
import {
  DialogButtonGroup,
  DialogContentContainer,
  DialogContent,
  Spacer,
} from '@/amxis/components/layout/layouts.tsx';
import CustomDialogTitle from '@/amxis/components/modals/common/CustomDialogTitle.tsx';
import {
  AgGridReact,
  Button,
  DataGrid,
  DataGridCellHeaderRadio,
  DataGridCellRadio,
  Dialog,
  FormItem,
  InputField,
  SearchArea,
  HelperText,
} from '@amxis/design-system';
import { ControlConfirmIcon } from '@amxis/design-system/icon';
import { Box } from '@mui/material';
import { Grid } from '@mui/material';
import { useDepartmentsQuery } from '@/amxis/hooks/queries/department/use-departments-query.ts';
import { Department } from '@/amxis/models/admin/Department.ts';
import { RelativeLoader } from '@/amxis/components/loader';
import CustomDialog from '@/amxis/components/modals/common/CustomDialog.tsx';
import useSessionStore from '@/amxis/stores/useSessionStore.ts';
import { DefaultCellTooltip } from '../data-grid';
import { DepartmentSearchCondition } from './department-modal.types.ts';

// 부서 검색 단건 팝업
type DeptSinglePopupProps = {
  open: boolean;
  setOpen;
  selectedDept?: Department[];
  onSave?: (department: Department[]) => void;
};

const DepartmentSinglePopup = ({ open, setOpen, selectedDept, onSave }: DeptSinglePopupProps) => {
  const { t } = useTranslation();
  const { langCd } = useSessionStore();
  const [selectedDepartment, setSelectedDepartment] = useState<Department[]>([]);
  const searchSchema = z.object({
    searchItem: z
      .string()
      .refine(
        (value) => (value ?? '') === '' || value.length >= 2,
        String(
          t(
            'common.label.검색어는 두 글자 이상 입력해주세요.',
            '__검색어는 두 글자 이상 입력해주세요.'
          )
        )
      ),
  });
  type SearchForm = z.infer<typeof searchSchema>;
  const defaultValues: SearchForm = {
    searchItem: '',
  };
  const [departmentSearchCondition, setDepartmentSearchCondition] =
    useState<DepartmentSearchCondition>(defaultValues);
  // modal
  const [isNoRowOpen, setIsNoRowOpen] = useState<boolean>(false);
  // query
  const { isLoading, data: departmentsData } = useDepartmentsQuery(departmentSearchCondition);
  const {
    handleSubmit,
    control,
    formState: { errors },
  } = useForm<SearchForm>({
    resolver: zodResolver(searchSchema),
    defaultValues,
  });

  useEffect(() => {
    if (selectedDept) {
      setSelectedDepartment(selectedDept);
    }
  }, []);

  // 검색 핸들러
  const handleSearchClick = handleSubmit(({ searchItem }) => {
    if (searchItem !== '') {
      setDepartmentSearchCondition({
        searchItem: searchItem,
      });
    }
  });

  // 부서목록 그리드에서 선택된 항목(추가할 항목)
  const gridRef = useRef<AgGridReact<Department>>(null);
  const onSelectionChanged = () => {
    const selectedNodes = gridRef.current?.api.getSelectedNodes() ?? [];
    const selectedRows = selectedNodes
      .map((node) => node.data)
      .filter((row) => row !== undefined) as Department[];
    setSelectedDepartment(selectedRows);
  };

  // 선택 핸들러
  const handleOnSelect = () => {
    const isSelectedDepartment = selectedDepartment.length > 0;
    if (!isSelectedDepartment) {
      setIsNoRowOpen(true);
      return;
    }
    onSave?.(selectedDepartment);
  };

  // 취소 핸들러
  const handleOnCancel = () => {
    setOpen(false);
    setSelectedDepartment([]);
  };

  return (
    <Dialog
      position="basic"
      type={'modal'}
      size={800}
      open={open}
      handleClose={handleOnCancel}
      customContentArea={
        <DialogContentContainer>
          <DialogContent>
            <Box width="100%">
              <SearchArea
                conditions={
                  <>
                    <Grid item xs={10}>
                      <FormItem
                        label={String(t('department-choice-popup.label.__검색어', '__검색어'))}
                        labelAlign="right"
                        render={() => (
                          <>
                            <Controller
                              control={control}
                              name="searchItem"
                              render={({ field: { ref, ...field } }) => (
                                <InputField
                                  {...field}
                                  fullWidth
                                  size="medium"
                                  status="default"
                                  textAlign="left"
                                  type="text"
                                  placeholder={String(
                                    t(
                                      'common.label.부서명이나 부서코드, 법인코드명을 입력하세요.',
                                      '__부서명이나 부서코드, 법인코드명을 입력하세요.'
                                    )
                                  )}
                                  onKeyUp={(e) => {
                                    if (e.key === 'Enter') handleSearchClick();
                                  }}
                                />
                              )}
                            />
                            {errors?.searchItem?.message && (
                              <Box mt="4px">
                                <HelperText
                                  infoText={(errors?.searchItem?.message as string) ?? ''}
                                  usecase="error"
                                />
                              </Box>
                            )}
                          </>
                        )}
                      />
                    </Grid>
                  </>
                }
                onSearch={handleSearchClick}
                searchButtonLabel={t('common.button.조회', '__조회') ?? ''}
              />
            </Box>
            <Spacer type="h" size="12" />

            <Box>
              <DataGrid
                rowSelection="single"
                singleClickEdit={false}
                columnDefs={[
                  {
                    width: 34,
                    sortable: false,
                    resizable: false,
                    headerComponent: () => <DataGridCellHeaderRadio />,
                    cellRenderer: DataGridCellRadio,
                  },
                  {
                    field: 'deptNm',
                    headerName: String(t('department-choice-popup.label.부서명', '__부서명')),
                    flex: 0.5,
                    tooltipComponent: DefaultCellTooltip,
                    tooltipField: 'deptNm',
                  },
                  {
                    field: 'deptCd',
                    headerName: String(t('department-choice-popup.label.부서코드', '__부서코드')),
                    cellStyle: { textAlign: 'center' },
                    flex: 0.5,
                    tooltipComponent: DefaultCellTooltip,
                    tooltipField: 'deptCd',
                  },
                  {
                    field: 'copCd',
                    headerName: String(t('role-department.column.법인코드', '__법인코드')),
                    cellStyle: { textAlign: 'center' },
                    flex: 0.5,
                    tooltipComponent: DefaultCellTooltip,
                    tooltipField: 'copCd',
                  },
                ]}
                currentPage={1}
                gridHeight="407px"
                isHeaderSectionEnabled
                minGridHeight="407px"
                rowData={departmentsData?.departmentList}
                rowHeight={25}
                title={String(t('department-choice-popup.title.부서목록', '__부서목록'))}
                totalCount={departmentsData?.departmentList.length}
                onSelectionChanged={onSelectionChanged}
                gridRef={gridRef}
                language={langCd === '' ? 'ko' : langCd}
                emptyLabel={
                  t(
                    'common.label.조회 가능한 데이터가 없습니다.',
                    '__조회 가능한 데이터가 없습니다.'
                  ) ?? ''
                }
              />
            </Box>
          </DialogContent>
          <DialogButtonGroup>
            <Button
              appearance="outlined"
              priority="normal"
              size="medium"
              onClick={handleOnCancel}
              buttonLabel={t('common.button.취소', '__취소')}
            />
            <Button
              appearance="contained"
              priority="primary"
              size="medium"
              onClick={handleOnSelect}
              iconComponent={<ControlConfirmIcon size="small" />}
              autoFocus
              buttonLabel={t('common.button.선택', '__선택')}
            />
          </DialogButtonGroup>
          <CustomDialog
            content={t('common.alert.선택된 행이 없습니다.', '__선택된 행이 없습니다.')}
            type="2"
            isOpen={isNoRowOpen}
            onClose={() => {
              setIsNoRowOpen(false);
            }}
            onSubmit={() => {
              setIsNoRowOpen(false);
            }}
          />
          <RelativeLoader isLoading={isLoading} />
        </DialogContentContainer>
      }
      customHeaderTitle={
        <CustomDialogTitle
          title={t('department-choice-popup.title.부서검색', '__부서검색') as string}
        />
      }
    />
  );
};

export default DepartmentSinglePopup;
