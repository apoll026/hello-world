/**
  Component Name : 부서검색팝업(다건)
  Component ID   : department-multi-popup
  Component Desc : WSF > 공통 > 부서검색팝업(다건)
  Author         : lgho
  Create Date    : 2024.09.01
  modify Date    : 2024.11.01
*/
/** @jsxImportSource @emotion/react */
import * as z from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useTranslation } from 'react-i18next';
import { Controller, useForm } from 'react-hook-form';

import {
  DialogButtonGroup,
  DialogContentContainer,
  DialogContent,
  Spacer,
} from '@/amxis/components/layout/layouts.tsx';
import { useState, useRef, useEffect } from 'react';
import CustomDialogTitle from '@/amxis/components/modals/common/CustomDialogTitle.tsx';
import {
  AgGridReact,
  Button,
  DataGrid,
  Dialog,
  FormItem,
  InputField,
  SearchArea,
  TitleArea,
  HelperText,
} from '@amxis/design-system';
import { ArrowChevron2Icon, ControlConfirmIcon } from '@amxis/design-system/icon';
import { Box } from '@mui/material';
import { Grid } from '@mui/material';

import { TreeData } from '@amxis/design-system';
import DepartmentTree from './department-tree.tsx';
import { useDepartmentsQuery } from '@/amxis/hooks/queries/department/use-departments-query.ts';

import { RelativeLoader } from '@/amxis/components/loader';
import CustomDialog from '@/amxis/components/modals/common/CustomDialog.tsx';
import { Department } from '@/amxis/models/admin/Department.ts';
import { DefaultCellTooltip } from '@/amxis/components/data-grid/default-cell-tooltip.tsx';
import useSessionStore from '@/amxis/stores/useSessionStore.ts';
import useDepartmentStore from '@/amxis/stores/useDepartmentStore.ts';
import { DepartmentSearchCondition } from './department-modal.types.ts';

// 부서 검색 다건 팝업
type DeptMultiPopupProps = {
  open: boolean;
  setOpen;
  selectedDeptList?: Department[];
  onSave?: (department: any[]) => void;
};

const convertDepartmentsToTreeData = (departments: Department[]): TreeData[] => {
  return departments.map((dept) => ({
    dept,
    id: dept.deptCd,
    nodeName: dept.deptNm,
    deptNm: dept.deptNm,
    deptCd: dept.deptCd,
  }));
};

const DepartmentMultiPopup = ({ open, setOpen, selectedDeptList, onSave }: DeptMultiPopupProps) => {
  const { t } = useTranslation();
  const { langCd } = useSessionStore();
  const { checkedList, setCheckedList } = useDepartmentStore((state) => state);
  const [delDeptList, setDelDeptList] = useState<TreeData[]>([]);
  const [selectedDepartments, setSelectedDepartments] = useState<TreeData[]>([]);

  const searchSchema = z.object({
    searchItem: z
      .string()
      .refine(
        (value) => (value ?? '') === '' || value.length >= 2,
        String(
          t(
            'common.label.검색어는 두 글자 이상 입력해주세요.',
            '__검색어는 두 글자 이상 입력해주세요.'
          )
        )
      ),
  });
  type SearchForm = z.infer<typeof searchSchema>;
  const defaultValues: SearchForm = {
    searchItem: '',
  };
  const [departmentSearchCondition, setDepartmentSearchCondition] =
    useState<DepartmentSearchCondition>(defaultValues);
  // modal
  const [isNoRowOpen, setIsNoRowOpen] = useState<boolean>(false);
  // query
  const { isLoading, data: departmentsData } = useDepartmentsQuery(departmentSearchCondition);
  const {
    handleSubmit,
    control,
    formState: { errors },
  } = useForm<SearchForm>({
    resolver: zodResolver(searchSchema),
    defaultValues,
  });

  const [initDeptList, setInitDeptList] = useState<Department[]>([]);
  // 초기값 설정
  useEffect(() => {
    if (!isLoading && departmentsData && initDeptList.length === 0) {
      setInitDeptList(departmentsData.departmentList);
    }
  }, [isLoading, departmentsData, initDeptList]);

  useEffect(() => {
    if (selectedDeptList) {
      const newTreeData = convertDepartmentsToTreeData(selectedDeptList);
      setSelectedDepartments(newTreeData);
    }
  }, []);

  // 검색 핸들러
  const handleSearchClick = handleSubmit(({ searchItem }) => {
    if (searchItem !== '') {
      setDepartmentSearchCondition({
        searchItem: searchItem,
      });
    }
  });

  // 선택된목록에 추가
  const handleInsertDeptList = () => {
    if (checkedList && checkedList.length > 0) {
      const selectedDeptIdList = checkedList.map((row) => row.id);
      const alreadyInsertedDeptList = selectedDepartments.map((dept) => {
        if (selectedDeptIdList.includes(dept.id)) {
          return dept.id;
        }
      });
      const filteredRows = checkedList.filter(
        (selectedRow) => !alreadyInsertedDeptList.includes(selectedRow.id)
      );
      setSelectedDepartments((selectedEmpList) => [...selectedEmpList, ...filteredRows]);
    } else {
      setIsNoRowOpen(true);
      return;
    }
  };

  // 선택된목록에서 제거
  const handleExtractDeptList = () => {
    if (delDeptList && delDeptList.length > 0) {
      const selectedDeptIdList = delDeptList.map((row) => row.id);
      setSelectedDepartments((selectedDeptList) =>
        selectedDeptList.filter((selectedDept) => !selectedDeptIdList.includes(selectedDept.id))
      );
    } else {
      setIsNoRowOpen(true);
      return;
    }
  };

  // 선택한 목록 그리드에서 체크된 항목(제거할 항목)
  const gridRef = useRef<AgGridReact<TreeData>>(null);
  const onSelectionChanged = () => {
    const selectedNodes = gridRef.current?.api.getSelectedNodes() ?? [];
    const selectedRows = selectedNodes
      .map((node) => node.data)
      .filter((row) => row !== undefined) as TreeData[];
    setDelDeptList(selectedRows);
  };

  // 선택 핸들러
  const handleOnSelect = () => {
    const isSelectedDepartments = selectedDepartments.length > 0;
    if (!isSelectedDepartments) {
      setIsNoRowOpen(true);
      return;
    }
    onSave?.(selectedDepartments);
  };

  // 취소 핸들러
  const handleOnCancel = () => {
    setOpen(false);
    setCheckedList([]);
    setDelDeptList([]);
    setSelectedDepartments([]);
  };

  return (
    <Dialog
      position="basic"
      type={'modal'}
      size={1000}
      open={open}
      handleClose={handleOnCancel}
      customContentArea={
        <DialogContentContainer>
          <DialogContent>
            <Box width="100%">
              <SearchArea
                conditions={
                  <>
                    <Grid item xs={10}>
                      <FormItem
                        label={String(t('department-choice-popup.label.__검색어', '__검색어'))}
                        labelAlign="right"
                        render={() => (
                          <>
                            <Controller
                              control={control}
                              name="searchItem"
                              render={({ field: { ref, ...field } }) => (
                                <InputField
                                  {...field}
                                  fullWidth
                                  size="medium"
                                  status="default"
                                  textAlign="left"
                                  type="text"
                                  placeholder={String(
                                    t(
                                      'common.label.부서명이나 부서코드, 법인코드명을 입력하세요.',
                                      '부서명이나 부서코드, 법인코드명을 입력하세요.'
                                    )
                                  )}
                                  onKeyUp={(e) => {
                                    if (e.key === 'Enter') handleSearchClick();
                                  }}
                                />
                              )}
                            />
                            <Box mt="4px">
                              <HelperText
                                infoText={(errors?.searchItem?.message as string) ?? ''}
                                usecase="error"
                              />
                            </Box>
                          </>
                        )}
                      />
                    </Grid>
                  </>
                }
                onSearch={handleSearchClick}
                searchButtonLabel={t('common.button.조회', '__조회') ?? ''}
              />
            </Box>
            <Spacer type="h" size="12" />
            <Box sx={{ display: 'flex', gap: '24px', width: '100%' }}>
              <Box sx={{ width: '30%' }}>
                <TitleArea
                  isSubTitle
                  title={t('department-choice-popup.title.부서목록', '__부서목록')}
                  totalCases={initDeptList?.length ?? 0}
                  language={langCd === '' ? 'ko' : langCd}
                ></TitleArea>
                <Box sx={{ height: '660px', marginTop: '4px', width: '285px' }}>
                  {departmentsData && (
                    <DepartmentTree
                      hasCheck
                      departmentList={initDeptList ?? []}
                      initialDeptCd={
                        // 1. 초기 진입 시 사용자 부서 selected
                        // 2-1. 검색 시 검색 결과 중 첫번째 결과값 selected
                        // 2-2. 검색 시 검색 결과 없는 경우 최상위 트리가 닫힌 상태로 보여짐
                        departmentSearchCondition.searchItem !== ''
                          ? departmentsData?.departmentList?.[1]?.deptCd
                            ? departmentsData?.departmentList[1].deptCd
                            : '0'
                          : departmentsData?.userDeptCd
                      }
                    />
                  )}
                </Box>
              </Box>

              <Box
                sx={{
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'center',
                  gap: '8px',
                }}
              >
                <Button
                  appearance="outlined"
                  iconComponent={<ArrowChevron2Icon direction="right" appearance="single" />}
                  onClick={handleInsertDeptList}
                  priority="normal"
                  size="large"
                />
                <Button
                  appearance="outlined"
                  iconComponent={<ArrowChevron2Icon direction="left" appearance="single" />}
                  onClick={handleExtractDeptList}
                  priority="normal"
                  size="large"
                />
              </Box>

              <Box sx={{ width: '70%' }}>
                <DataGrid
                  columnDefs={[
                    {
                      width: 50,
                      sortable: false,
                      resizable: false,
                      headerClass: 'checkbox',
                      checkboxSelection: true,
                      headerCheckboxSelection: true,
                    },
                    {
                      field: 'nodeName',
                      headerName: String(t('user-choice-popup.column.부서명', '__부서명')),
                      flex: 0.5,
                      tooltipComponent: DefaultCellTooltip,
                      tooltipField: 'nodeName',
                    },
                  ]}
                  currentPage={1}
                  gridHeight="660px"
                  isHeaderSectionEnabled
                  minGridHeight="660px"
                  rowData={selectedDepartments}
                  rowHeight={25}
                  rowSelection="multiple"
                  title={String(t('common.label.선택한목록', '__선택한목록'))}
                  totalCount={selectedDepartments.length}
                  onSelectionChanged={onSelectionChanged}
                  gridRef={gridRef}
                  language={langCd === '' ? 'ko' : langCd}
                  emptyLabel={
                    t(
                      'common.label.조회 가능한 데이터가 없습니다.',
                      '__조회 가능한 데이터가 없습니다.'
                    ) ?? ''
                  }
                />
              </Box>
            </Box>
          </DialogContent>
          <DialogButtonGroup>
            <Button
              appearance="outlined"
              priority="normal"
              size="medium"
              onClick={handleOnCancel}
              buttonLabel={t('common.button.취소', '__취소')}
            />
            <Button
              appearance="contained"
              priority="primary"
              size="medium"
              onClick={handleOnSelect}
              iconComponent={<ControlConfirmIcon size="small" />}
              autoFocus
              buttonLabel={t('common.button.선택', '__선택')}
            />
          </DialogButtonGroup>
          <CustomDialog
            content={t('common.alert.선택된 행이 없습니다.', '__선택된 행이 없습니다.')}
            type="2"
            isOpen={isNoRowOpen}
            onClose={() => {
              setIsNoRowOpen(false);
            }}
            onSubmit={() => {
              setIsNoRowOpen(false);
            }}
          />
          <RelativeLoader isLoading={isLoading} />
        </DialogContentContainer>
      }
      customHeaderTitle={
        <CustomDialogTitle
          title={t('department-choice-popup.title.부서검색', '__부서검색') as string}
        />
      }
    />
  );
};

export default DepartmentMultiPopup;
