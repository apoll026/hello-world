/**
  Component Name : 부서 검색 search-input
  Component ID   : department-search-input.tsx
  Component Desc : 권한설정 팝업 > 부서 검색 input
  Author         : lgho
  Create Date    : 2024.09.01
  modify Date    : 2024.11.01
*/

import styled from '@emotion/styled';
import parse from 'autosuggest-highlight/parse';
import match from 'autosuggest-highlight/match';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Chip, InputField, Tooltip } from '@amxis/design-system';
import { Autocomplete, CircularProgress, Grid, useTheme } from '@mui/material';
import DepartmentMultiPopup from './department-multi-popup.tsx';
import { Department } from '@/amxis/models/admin/Department.ts';
import { getDepartments } from '@/amxis/apis/admin/Department.ts';
import { Box } from '@mui/system';
import { UserTeamIcon, StatusMisuseIcon, FunctionSearchIcon } from '@amxis/design-system/icon';
import DepartmentSinglePopup from './department-single-popup.tsx';

interface AutoDeptInputParams {
  onlyPopup?: boolean;
  disabled?: boolean;
  readonly?: boolean;
  height?: string;
  size?: string;
  status?: 'default' | 'error' | 'warning' | 'confirm';
  type?: '1' | '2';
  chipType?: 'default' | 'user';
  chipImg?: string;

  limitTag?: boolean;

  onInit?: Department[];
  onChange: (deptList: Department[]) => void;
  handleExistInputValue?: (e: any) => void;
  width?: string;

  limitTags?: number;
  singleSelect?: boolean;
  isInGrid?: boolean;
  placeholder?: string;
  helperText?: string;
}

interface InputChipBoxProps {
  onlyPopup?: boolean;
  readonly?: boolean;
  disabled?: boolean;
  chipType?: 'default' | 'user';
  chipImg?: string;

  width?: string;
  height?: string;
  status?: 'default' | 'error' | 'warning' | 'confirm';
  type?: '1' | '2';
  isInGrid?: boolean;
}

const PADDING_SIZE = {
  large: {
    paddingTop: '5px',
    paddingBottom: '5px',
  },
  medium: {
    paddingTop: '3px',
    paddingBottom: '3px',
  },
  small: {
    paddingTop: '1px',
    paddingBottom: '1px',
  },
};

const DepartmentSearchInput = ({
  onlyPopup,
  readonly,
  disabled,
  height,
  size = 'small',
  status = 'default',
  type,
  chipType = 'user',
  chipImg = '',
  onInit,
  onChange,
  handleExistInputValue,
  width,

  limitTags = 3,
  singleSelect = false,
  isInGrid = false,
  placeholder = '',
  helperText,
}: AutoDeptInputParams) => {
  const theme = useTheme();
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);
  const [options, setOptions] = useState<Department[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [openModal, setOpenModal] = useState<boolean>(false);
  const [textValue, setTextValue] = useState<string>('');
  const [deptList, setDeptList] = useState<Department[]>(onInit ?? []);

  useEffect(() => {
    if (onInit) {
      setDeptList(onInit);
    }
  }, [onInit]);

  //텍스트 입력시 실행되는 함수
  useEffect(() => {
    if (textValue?.length > 1) {
      // 입력이 끝날 때마다 타이머를 재설정
      const timer = setTimeout(() => {
        // 0.7초 후에 실행되는 코드
        setLoading(true);
        setOpen(true);
        getDepartments(textValue).then((data) => {
          setOptions(data.departmentList);
          setLoading(false);
        });
        // setOpen(true);
      }, 700);

      // cleanup 함수를 이용하여 타이머 해제
      return () => clearTimeout(timer);
    } else {
      // setOpen(false);
      setOptions([]);
    }
  }, [textValue]);

  const handleClickText = () => {
    if (textValue?.length > 1) {
      setOpen(true);
    }
  };

  const handleClickSearchBtn = (e) => {
    e.stopPropagation();
    setOpenModal(true);
  };

  //부서 팝업
  const renderModal = () => {
    return (
      <>
        {singleSelect ? (
          <DepartmentSinglePopup
            open={openModal}
            setOpen={(open: boolean) => setOpenModal(open)}
            onSave={(dept) => {
              handleChangeDept(dept, false);
              setOpenModal(false);
            }}
            selectedDept={deptList}
          />
        ) : (
          <DepartmentMultiPopup
            open={openModal}
            setOpen={() => setOpenModal(false)}
            onSave={(dept) => {
              handleChangeDept(dept, false);
              setOpenModal(false);
            }}
            selectedDeptList={deptList}
          />
        )}
      </>
    );
  };

  /**
   * 부서팝업 저장 버튼 클릭시 아니면 input에 key-in으로 유저 넣을 경우 유저 데이터 상태 변경함수
   * onChange로 변경된 내용 상위 컴포넌트에 올림
   * @param {Department[]} dept
   * @param {boolean} isLastSelect
   * @returns {void}
   */
  const handleChangeDept = (dept: Department[], isLastSelect: boolean) => {
    let selectedDeptList = dept;
    if (singleSelect && dept.length > 1) {
      if (isLastSelect) {
        selectedDeptList = [dept[dept.length - 1]];
      } else {
        selectedDeptList = [dept[0]];
      }
    }

    setDeptList(selectedDeptList);
    onChange(selectedDeptList);
    setOpen(false);
  };

  const handleTextFieldChange = (e) => {
    setTextValue(e.target.value);
    handleExistInputValue && handleExistInputValue(e.target.value);
  };

  return (
    <>
      <StyledInputWrapper width={width}>
        <Container
          width={width}
          height={height}
          status={status}
          type={type}
          readonly={readonly}
          disabled={disabled}
          chipType={chipType}
          chipImg={chipImg}
          isInGrid={isInGrid}
        >
          <Autocomplete
            limitTags={limitTags}
            readOnly={readonly || onlyPopup}
            disabled={disabled}
            open={open}
            multiple
            options={options}
            filterOptions={(x) => x}
            filterSelectedOptions
            noOptionsText={t('common.label.부서를 찾을 수 없습니다.', '__부서를 찾을 수 없습니다.')}
            value={deptList}
            sx={{
              '& .MuiInputBase-root button.MuiAutocomplete-clearIndicator': {
                display: singleSelect ? 'none' : 'block',
              },
            }}
            onInputChange={(e, value, reason) => {
              //input에 delete버튼 클릭시 reason 값을 통해 input값 제어
              if (reason === 'clear' || reason === 'reset') {
                setTextValue('');
                setOptions([]);
              }
            }}
            onChange={(event, newValue, reason) => {
              //delete 버튼과 dept 넣는 이벤트 모두 이곳에서 통제된다.
              if (reason === 'clear') {
                setTextValue('');
              }
              handleExistInputValue && handleExistInputValue('');

              const allString = newValue.every((value) => typeof value === 'string');

              if (allString) {
                //이 경우는 delete 버튼을 눌러서 Autocomplete에 데이터가 빈 경우 이곳으로 통제된다.
                if (newValue) {
                  handleChangeDept([], false);
                }
              } else {
                //이 경우는 delete 버튼을 눌러도 데이터가 있을 경우, dept를 추가한 경우 이곳으로 통제된다.
                handleChangeDept(newValue as Department[], true);
              }
            }}
            onBlur={() => {
              handleExistInputValue && handleExistInputValue('');
              setOpen(false);
            }}
            onClose={() => {
              setLoading(false);
            }}
            isOptionEqualToValue={(option, value) => option.deptCd === value.deptCd}
            getOptionLabel={(option) => {
              if (typeof option === 'string') {
                return option;
              } else {
                return option.deptNm ? option.deptNm : '';
              }
            }}
            loading={loading}
            renderTags={(value: readonly Department[]) =>
              //태그 컴포넌트
              value.map((option: any, index: number) => (
                <Box
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    height: '100%',
                    // maxWidth: isInGrid && singleSelect ? 'calc(100% - 40px)' : undefined,
                    maxWidth: index === 0 ? 'calc(100% - 38px)' : 'calc(100% - 23px)',
                  }}
                  key={option.deptCd + index}
                >
                  <Tooltip placement="bottom" title={option.deptNm ?? ''} type="hover">
                    <Box sx={{ width: '100%', height: '100%' }}>
                      <Chip
                        chipText={option.deptNm ?? ''}
                        deletable={true}
                        onDelete={() => {
                          if (readonly || disabled) return;

                          const updatedDeptList =
                            deptList?.filter((dept) => dept.deptCd !== value[index].deptCd) || [];
                          setDeptList(updatedDeptList);
                          onChange(updatedDeptList);
                        }}
                        // onClick={handleClickAvatar}
                        leadingContents={
                          <UserTeamIcon
                            appearance="filled"
                            iconSize={2}
                            sx={{
                              // backgroundColor: '#554596',
                              // borderRadius: '50%',
                              color: '#FFFFFF',
                              width: '14px',
                              height: '14px',
                              // border: '1px solid #ffffff',
                            }}
                          />
                        }
                        size="small"
                        type="input"
                        sx={{
                          width: '100%',
                          height: '100%',
                          '& > div': {
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            gap: '4px',
                            textAlign: 'left',
                            minWidth: '20px',
                          },
                          '& > div > div:nth-of-type(1)': {
                            backgroundColor: '#1FBC97',
                            borderRadius: '50%',
                            border: '1px solid #ffffff',
                          },
                          '& > div > div:nth-of-type(2)': {
                            // maxWidth: isInGrid && singleSelect ? 'calc(100% - 20px)' : undefined,
                            maxWidth: 'calc(100% - 16px)',
                          },
                          '& > div > div:nth-of-type(2) > p': {
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap',
                          },
                        }}
                      />
                    </Box>
                  </Tooltip>
                </Box>
              ))
            }
            renderOption={(props, option, { inputValue }) => {
              if (!option) return undefined;

              //key-in시 드롭박스에 list 컴포넌트
              const matches = match(option?.deptNm || '', inputValue, { insideWords: true });
              const parts = parse(option?.deptNm || '', matches);

              return (
                <li {...props} key={option?.deptCd} style={{ padding: '5px 5px 5px 5px' }}>
                  <Grid container alignItems="center">
                    <Grid item sx={{ width: 'calc(100% - 35px)', wordWrap: 'break-word' }}>
                      {parts.map((part, index) => (
                        <span
                          key={index}
                          style={{
                            fontWeight: part.highlight ? 700 : 400,
                          }}
                        >
                          {part.text}
                        </span>
                      ))}
                    </Grid>
                  </Grid>
                </li>
              );
            }}
            renderInput={(params) => (
              //input 컴포넌트
              <InputField
                sx={{
                  minWidth: '10%',
                }}
                onClick={handleClickText}
                value={textValue}
                onChange={handleTextFieldChange}
                placeholder={
                  deptList.length === 0
                    ? placeholder === ''
                      ? (t(
                          'common.label.부서명을 입력하거나 돋보기를 클릭하세요.',
                          '__부서명을 입력하거나 돋보기를 클릭하세요.'
                        ) as string)
                      : placeholder
                    : ''
                }
                onKeyDown={(event) => {
                  if (event.key === 'Enter') {
                    if (options?.[0]) {
                      setTextValue('');
                      handleChangeDept([options[0], ...deptList], false);
                      setOptions([]);
                      setOpen(false);
                    }

                    event.preventDefault();
                  }
                }}
                {...params}
                InputProps={{
                  ...params.InputProps,
                  style:
                    !readonly && !disabled
                      ? {
                          // padding: isInGrid ? '1px 30px 1px 6px' : '4px 12px 4px 6px',
                          paddingTop: PADDING_SIZE[size].paddingTop,
                          paddingBottom: PADDING_SIZE[size].paddingBottom,
                          paddingLeft: '6px',
                          paddingRight: singleSelect ? '6px' : '30px',
                          minHeight: isInGrid ? 'unset' : '28px',
                          height: height,
                          alignItems: 'center',
                          display: 'inline-flex',
                          // display: isInGrid ? 'flex' : undefined,
                          flexDirection: isInGrid ? 'row' : undefined,
                          alignContent: 'flex-start',
                          flexWrap: isInGrid ? 'nowrap' : undefined,
                        }
                      : {
                          // padding: isInGrid ? '1px 7px 1px 7px' : '5px 7px 5px 7px',
                          paddingTop: PADDING_SIZE[size].paddingTop,
                          paddingBottom: PADDING_SIZE[size].paddingBottom,
                          paddingLeft: '6px',
                          paddingRight: '6px',
                          minHeight: isInGrid ? 'unset' : '28px',
                          height: height,
                          alignItems: 'center',
                          flexWrap: isInGrid ? 'nowrap' : undefined,
                        },
                  startAdornment: (
                    <>
                      {!readonly && !disabled && (
                        <FunctionSearchIcon
                          appearance="lined"
                          iconSize={16}
                          fill={theme.palette.semantic.color.commonTextBasic}
                          sx={{
                            margin: `2px`,
                            cursor: 'pointer',
                          }}
                          onClick={handleClickSearchBtn}
                        />
                      )}
                      {params.InputProps.startAdornment}
                    </>
                  ),
                  endAdornment: (
                    <>
                      {loading ? (
                        <CircularProgress
                          color="primary"
                          size={20}
                          style={{ margin: 'auto', boxSizing: 'content-box' }}
                        />
                      ) : null}
                      {params.InputProps.endAdornment}
                    </>
                  ),
                }}
              />
            )}
            clearIcon={
              !singleSelect && (
                <StatusMisuseIcon
                  appearance="filled"
                  fill={theme.palette.semantic.color.commonTextLighter}
                  iconSize={16}
                  sx={{ marginRight: '-1px' }}
                />
              )
            }
          />
        </Container>
        {helperText && <HelperText status={status}>{helperText}</HelperText>}
      </StyledInputWrapper>
      {openModal && renderModal()}
    </>
  );
};

export default DepartmentSearchInput;

// 따로 추가한 CSS
const StyledInputWrapper = styled.div<InputChipBoxProps>`
  display: flex;
  flex-direction: column;
  width: ${(props) => props.width || '100%'};
`;

// 따로 추가한 CSS
const HelperText = styled.span<InputChipBoxProps>`
  font-family: Spoqa Han Sans Neo;
  font-size: 12px;
  font-weight: 400;
  line-height: 150%;
  color: #979998;

  margin-top: 4px;
  width: auto;
  height: auto;

  ${(props) =>
    props.status === 'error' &&
    `
    color: #f94b50;
    `}

  ${(props) =>
    props.status === 'warning' &&
    `
    color: #ff9322;
    `}
    
    ${(props) =>
    props.status === 'confirm' &&
    `
    color: #00806a;
  `}
`;

const Container = styled.div<InputChipBoxProps>`
  z-index: 10;
  position: relative;
  width: ${(props) => props.width};
  height: ${(props) => props.height};
  ${(props) => (props.disabled ? `opacity: 0.6; pointer-events: none;` : `opacity: 1;`)};
  ${(props) => (props.readonly ? `pointer-events: none;` : ``)};

  &::after {
    // position: absolute;
    top: 50%;
    right: 8px;
    transform: translate(0, -50%);
    width: 16px;
    height: 16px;
    background-color: #fff;
    cursor: pointer;
  }

  .MuiAutocomplete-root {
    .MuiTextField-root {
      .MuiOutlinedInput-root {
        ${(props) =>
          props.type === '1' ? 'padding: 6px 50px 6px 30px;' : 'padding: 6px 50px 6px 8px;'}
        display: flex;
        gap: 4px 2px;
        ${(props) => (props.readonly ? `background-color: #f1f4f3` : `background-color: #fff`)};
        .MuiAutocomplete-input {
          min-width: 0;
          // width: auto;
          height: 24px;
          margin-left: 2px;
          padding: 0;
          &::placeholder {
            color: #979998;
            opacity: 1;
          }
        }

        .MuiButtonBase-root.MuiChip-root > .MuiChip-deleteIcon {
          z-index: 100;
        }

        .MuiAutocomplete-input:focus {
          flex-shrink: 1;
          min-width: 0;
        }
        .MuiAutocomplete-endAdornment {
          top: 50%;
          transform: translate(0, -50%);
          ${(props) => (props.type === '1' ? `display:flex; flex-direction: row-reverse;` : ``)}
          .MuiButtonBase-root-MuiIconButton-root-MuiAutocomplete-clearIndicator {
            width: 14px;
            height: 14px;
            margin-right: 0;
            background-color: #5b5c5b;
            .MuiSvgIcon-root {
              padding: 2px 2px 2px 4px;
              color: #fff;
            }
          }
          .MuiButtonBase-root-MuiIconButton-root-MuiAutocomplete-popupIndicator {
            ${(props) => (props.type === '1' ? `width: 0; height: 0; padding: 0;` : ``)}
            .MuiSvgIcon-root {
              ${(props) => (props.type === '1' ? `width: 0;` : ``)}
            }
          }
          .MuiButtonBase-root-MuiIconButton-root-MuiAutocomplete-popupIndicator {
            ${(props) => (props.type === '1' ? `width: 0; height: 0; padding: 0;` : ``)}
            .MuiSvgIcon-root {
              ${(props) => (props.type === '1' ? `width: 0;` : ``)}
            }
          }
        }
        .MuiOutlinedInput-notchedOutline {
          top: 0;
          width: 100%;
          padding: 0;
          border-radius: 2px;
          ${(props) => props.isInGrid && `border: none;`}
          ${(props) =>
            !props.isInGrid && props.status === 'default' && `border: 1px solid #b9bcbb;`}
          ${(props) => !props.isInGrid && props.status === 'error' && `border: 1px solid #fda293;`}
          ${(props) =>
            !props.isInGrid && props.status === 'warning' && `border: 1px solid #FF9322;`}
          ${(props) =>
            !props.isInGrid && props.status === 'confirm' && `border: 1px solid #00806A;`}
        }
      }
    }
  }

  .MuiOutlinedInput-root {
    padding-right: 30px;
  }

  .MuiOutlinedInput-notchedOutline {
    border: none;
  }

  .Mui-focused .MuiOutlinedInput,
  .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline {
    ${(props) => (!props.isInGrid ? 'border: 1px solid #5b5c5d !important;' : '')}
  }

  /* chip tag */
  .MuiAutocomplete-root .MuiAutocomplete-tag {
    margin: auto 0;
    margin-left: 2px;
    max-width: 145px;
    height: 20px;

    & > span {
      overflow: hidden;
      text-overflow: ellipsis;
      height: 20px;
      color: #1f1f1f;
      font-size: 13px;
      font-weight: 400;
      line-height: 150%;
      ${(props) =>
        props.chipType === 'default' ? `padding: 0 16px 0 8px;` : `padding: 0 16px 0 26px;`}
      position: relative;
    }
    & > svg {
      width: 14px;
    }
  }

  .MuiAutocomplete-popupIndicator {
    display: none;
  }
`;
/* 툴팁 */
export const Tip = styled.span`
  font-family: 'Spoqa Han Sans Neo';
  color: #fff;
  font-weight: 300;
  font-size: 12px;
`;
