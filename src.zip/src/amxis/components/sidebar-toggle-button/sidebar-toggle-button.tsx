import { useTheme } from '@amxis/design-system';
import { MenuMenuIcon } from '@amxis/design-system/icon';
import { Box } from '@mui/material';

type SidebarToggleButtonProps = {
  onClick: () => void;
  isClicked?: boolean;
};

function SidebarToggleButton({ onClick }: SidebarToggleButtonProps) {
  const [theme] = useTheme();

  return (
    <Box
      component="button"
      onClick={onClick}
      sx={{
        zIndex: 11,
        position: 'absolute',
        top: '-52px',
        left: 0,
        width: '52px',
        height: '52px',
        padding: '16px 0',
        textAlign: 'center',
        color: '#fff',
        border: 0,
        outline: 0,
        bgcolor: theme.palette.semantic.color.commonBgPrimary,
        cursor: 'pointer',
        '&:hover': {
          bgcolor: theme.palette.primary[500],
        },
      }}
    >
      <MenuMenuIcon sx={{ color: theme.palette.semantic.color.commonTextBasic }} />
    </Box>
  );
}

export { SidebarToggleButton };
