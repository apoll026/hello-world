import { useEffect, useState } from 'react';
import { FormControlLabel } from '@mui/material';
import { Checkbox, useTheme } from '@amxis/design-system';
import { Box } from '@mui/material';
import { Button } from '@amxis/design-system';
import { Dialog, DialogActions, DialogContent, DialogTitle } from '@/amxis/components/ui/dialog';
import { useCookies } from 'react-cookie';
import { NamoCrossEditorViewer } from '../namo-cross-editor';
import { useTranslation } from 'react-i18next';
import { ControlCloseIcon } from '@amxis/design-system/icon';

const NOTICE_EXPIRE_COOKIE_PREFIX = 'NOTICE_EXPIRES_';

const getExpiredDate = (days: number) => {
  const date = new Date();
  date.setDate(date.getDate() + days);
  return date;
};

type NoticeModalProps = {
  noticeNo: string;
  noticeTitNm: string;
  noticeCtn: string;
  poupEpsNuseDdn: number;
};

function NoticeModal({ noticeCtn, noticeNo, noticeTitNm, poupEpsNuseDdn }: NoticeModalProps) {
  const { t } = useTranslation();
  const [theme] = useTheme();
  const [checked, setChecked] = useState(false);
  const [open, setOpen] = useState(false);
  const [appCookies, setAppCookies] = useCookies();
  const closeModalUntilExpires = () => {
    if (!appCookies) {
      return;
    }

    const expires = getExpiredDate(poupEpsNuseDdn);
    setAppCookies(NOTICE_EXPIRE_COOKIE_PREFIX + noticeNo, true, { path: '/', expires });
  };

  const onClose = () => {
    if (checked) {
      closeModalUntilExpires();
    }

    setOpen(false);
  };

  useEffect(() => {
    if (appCookies[NOTICE_EXPIRE_COOKIE_PREFIX + noticeNo]) {
      setOpen(false);
    } else {
      setOpen(true);
    }
  }, []);

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="md">
      <DialogTitle
        sx={{
          position: 'relative',
          p: '24px',
          fontSize: '18px',
          fontWeight: 700,
          color: theme.palette.semantic.color.commonTextPrimaryExtreme,
          '&:before': {
            content: '""',
            display: 'inline-block',
            verticalAlign: 'middle',
            mr: '8px',
            width: '8px',
            height: '8px',
            borderRadius: '50%',
            bgcolor: theme.palette.semantic.color.commonTextPrimary,
          },
        }}
      >
        {noticeTitNm}
        <Button
          type="button"
          size="medium"
          appearance="unfilled"
          priority="normal"
          sx={{
            position: 'absolute',
            top: '50%',
            right: '24px',
            transform: 'translateY(-50%)',
            height: '32px',
            width: '32px',
            p: '6px',
            svg: {
              width: '20px',
              height: '20px',
            },
          }}
          onClick={onClose}
        >
          <ControlCloseIcon size="default" />
        </Button>
      </DialogTitle>
      <DialogContent sx={{ p: '12px 24px' }}>
        <NamoCrossEditorViewer content={noticeCtn} />
      </DialogContent>
      <DialogActions sx={{ padding: '12px 24px' }}>
        <Box display="flex" justifyContent="space-between" alignItems="center" width="100%">
          <FormControlLabel
            control={<Checkbox />}
            onChange={() => setChecked(!checked)}
            checked={checked}
            value={checked}
            label={`${poupEpsNuseDdn}` + t('common.label.일 동안 보지 않기', '일 동안 보지 않기')}
            sx={{ ml: 0 }}
          />
          <Button size="medium" appearance="contained" priority="primary" onClick={onClose}>
            {t('common.button.확인', '확인')}
          </Button>
        </Box>
      </DialogActions>
    </Dialog>
  );
}

export { NoticeModal };
