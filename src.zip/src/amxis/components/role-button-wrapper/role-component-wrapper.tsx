import React, { ReactElement, useCallback } from 'react';
import useButtonAuth from '../../hooks/use-button-auth.ts';
import { saveButtonClickLog } from '@/amxis/apis/admin/ButtonLog.ts';

type AuthComponentWrapperProps = {
  children: ReactElement;
  btnKeyCd: string;
  type?: 'display' | 'disabled';
  logClick?: boolean;
  pgmAuth?: string;
  requiredAuth?: string;
  pgmName?: string;
  // 로그를 남길 이벤트 핸들러들 지정
  logEvents?: string[];
  // 권한 체크할 이벤트 핸들러들 지정
  authEvents?: string[];
  // 비활성화할 때 추가로 적용할 props
  disabledProps?: Record<string, any>;
  // 권한 없을 때 보여줄 fallback 컴포넌트
  fallback?: ReactElement | null;
};

function AuthComponentWrapper({
  children,
  btnKeyCd,
  pgmAuth,
  requiredAuth,
  pgmName,
  type = 'disabled',
  logClick = false,
  logEvents = ['onSearch', 'onClick', 'onSubmit'],
  authEvents = ['onSearch', 'onClick', 'onSubmit'],
  disabledProps = {},
  fallback = null,
}: AuthComponentWrapperProps) {
  const { isButtonAuth } = useButtonAuth();

  const hasAuth = React.useMemo(() => {
    if (requiredAuth === undefined || pgmAuth === undefined) {
      console.warn('requiredAuth or pgmAuth is undefined');
      return true;
    }
    return isButtonAuth(requiredAuth, pgmAuth);
  }, [requiredAuth, pgmAuth, isButtonAuth]);

  // 이벤트 핸들러를 래핑하는 함수
  const wrapEventHandler = useCallback(
    (originalHandler: any, eventName: string) => {
      return async (...args: any[]) => {
        // 권한 체크가 필요한 이벤트인지 확인
        const requiresAuth = authEvents.includes(eventName);

        if (requiresAuth && !hasAuth) {
          return;
        }

        // 로그를 남길 이벤트인지 확인
        const shouldLog = logClick && logEvents.includes(eventName);

        if (shouldLog) {
          try {
            await saveButtonClickLog(`${pgmName}.${btnKeyCd}`);
          } catch (error) {
            console.error('버튼 클릭 로그 저장 실패:', error);
          }
        }

        // 원본 핸들러 실행
        if (originalHandler) {
          await originalHandler(...args);
        }
      };
    },
    [hasAuth, type, logClick, logEvents, authEvents, pgmName, btnKeyCd]
  );

  // 권한 없으면 fallback 또는 숨김
  if (!hasAuth && type === 'display') {
    return fallback;
  }

  // children의 props를 클론하면서 이벤트 핸들러들을 래핑
  const clonedChildren = React.Children.map(children, (child) => {
    if (!React.isValidElement(child)) return child;

    const element = child as React.ReactElement<any>;
    const wrappedProps: Record<string, any> = {};

    // 모든 이벤트 핸들러들을 찾아서 래핑
    Object.keys(element.props).forEach((propName) => {
      const propValue = element.props[propName];

      // 이벤트 핸들러인지 확인 (on으로 시작하고 함수인 경우)
      if (propName.startsWith('on') && typeof propValue === 'function') {
        wrappedProps[propName] = wrapEventHandler(propValue, propName);
      }
    });

    // 권한 없을 때 추가 props 적용
    if (!hasAuth && type === 'disabled') {
      Object.assign(wrappedProps, {
        disabled: true,
        ...disabledProps,
      });
    }

    return React.cloneElement(element, wrappedProps);
  });

  return <>{clonedChildren}</>;
}

export { AuthComponentWrapper };
