import { Button } from '@amxis/design-system';
import React, { ReactElement } from 'react';
import useButtonAuth from '../../hooks/use-button-auth.ts';
import { saveButtonClickLog } from '@/amxis/apis/admin/ButtonLog.ts';

type RoleButtonWrapperProps = {
  children: ReactElement<typeof Button>;
  btnKeyCd: string;
  type?: 'display' | 'disabled';
  logClick?: boolean;
  pgmAuth?: string;
  requiredAuth?: string;
  pgmName?: string;
};

function AuthButtonWrapper({
  children,
  btnKeyCd,
  pgmAuth,
  requiredAuth,
  pgmName,
  type = 'disabled',
  logClick = false,
}: RoleButtonWrapperProps) {
  const { isButtonAuth } = useButtonAuth();

  const setConfig = () => {
    const conf: any = { disabled: false };
    try {
      if (requiredAuth === undefined || pgmAuth === undefined) {
        console.warn('requiredAuth or pgmAuth is undefined');
        return conf;
      }
      if (type == 'disabled') {
        conf.disabled = !isButtonAuth(requiredAuth, pgmAuth);
      } else if (type == 'display') {
        conf.sx = { display: isButtonAuth(requiredAuth, pgmAuth) ? 'block' : 'none' };
      }
    } catch (e) {
      console.error(e);
    }

    return conf;
  };

  const clonedChildren = React.Children.map(children, (child) => {
    if (!React.isValidElement(child)) return child;

    const element = child as React.ReactElement<any>; // 타입 명시
    const originalOnClick = element.props.onClick;

    // const originalOnClick = child.props.onClick;
    const wrppedOnClick = async (...args: any[]) => {
      if (logClick) {
        saveButtonClickLog(pgmName + '.' + btnKeyCd).catch();
      }

      if (originalOnClick) {
        await originalOnClick(...args);
      }
    };

    return React.cloneElement(child, { ...setConfig(), onClick: wrppedOnClick });
  });

  return <>{clonedChildren}</>;
}

export { AuthButtonWrapper };
