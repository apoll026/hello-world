import styled from '@emotion/styled';
import { useTranslation } from 'react-i18next';
import { FileRejection, useDropzone } from 'react-dropzone';
import './Dropzone.css';
import { v4 as uuidv4 } from 'uuid';
import { downloadAllFiles } from '@/amxis/apis/admin/FileUpload.ts';
import { FileInfo } from '@/amxis/models/admin/FileInfo.ts';
import axios from 'axios';
import RemoveIcon from '@mui/icons-material/Remove';
import { CommonYN } from '@/amxis/models/common/Common.ts';
import { CrudCode } from '@/amxis/models/common/Edit.ts';
import SearchIcon from '@mui/icons-material/Search';
import { css } from '@emotion/react';
import { BorderColor, FontColor, BgColor } from '@/amxis/ui/theme/Color.ts';
import { Link } from 'react-router-dom';
import { useControllableState } from '@/amxis/hooks/use-controllable-state.ts';
import { getAllAcceptFiles, handleAcceptFiles } from '../ui/file-uploader/file-uploader-utils.tsx';
import { Button, useMessageBar } from '@amxis/design-system';

const CustomInputText = styled.input`
  height: 32px;
  padding: 0 10px;
  border-radius: 3px;
  border: solid 1px ${BorderColor.Form};
  background-color: ${BgColor.White};
  font-size: 13px;
  font-family: 'Spoqa Han Sans Neo', '맑은 고딕', 'malgun gothic', 'AppleGothicNeoSD',
    'Apple SD 산돌고딕 Neo', 'Microsoft NeoGothic', 'Droid sans', sans-serif;
  color: ${FontColor.Default};
  vertical-align: middle;

  &:focus,
  &:hover,
  &:active {
    outline: 0;
  }

  &:disabled {
    background-color: ${BgColor.Gray50};
    color: ${FontColor.Gray400};
  }
  &::placeholder {
    color: ${FontColor.Gray200};
  }

  &.fullWidth {
    width: 100% !important;
  }
  &.halfWidth {
    width: 43.777777% !important;
  }
  &.fullWidthCell {
    width: 100% !important;
    height: 28px !important;
    horizontal-align: middle;
  }

  &.widhButton {
    width: calc(100% - 30px);
  }

  &:read-only {
    background-color: ${BgColor.Gray50};
  }

  &.width280 {
    min-width: 280px;
    width: 280px;
  }

  &.width200 {
    min-width: 200px;
    width: 200px;
  }

  &.width120 {
    min-width: 120px;
    width: 120px;
  }

  &.Width110 {
    min-width: 110px;
    width: 110px;
  }

  &.width30p {
    min-width: 30%;
    width: 30%;
  }

  &.marginL0 {
    margin-left: 0;
  }

  &.inline-flex {
    display: inline-flex;
  }

  & + button {
    vertical-align: middle;
  }

  label + & {
    margin-left: 10px;
  }
`;

const ViewTable = styled.table`
  width: 100%;
  min-width: 500px;
  border: 1px solid ${BorderColor.Primary};
  table-layout: fixed;
  line-height: 1.4;

  th,
  td {
    height: 38px;
    padding: 3px 8px;
    vertical-align: middle;
    font-size: 13px;
    border-right: 1px solid ${BorderColor.Primary};
    border-bottom: 1px solid ${BorderColor.Primary};

    &.borderR0 {
      border-right: 0;
    }
  }

  th {
    text-align: left;
    font-weight: 500;
    background-color: ${BgColor.White100};
  }

  thead th,
  .alignC {
    text-align: center;
  }
  .alignR {
    text-align: right;
  }

  td {
    color: ${FontColor.Default};
  }

  &.width300 {
    width: 300px;
  }

  .heightAuto {
    height: auto;
  }

  & + & {
    margin-top: 20px;
  }

  & + .contentEnd {
    margin-top: 10px;
  }

  .padding0 {
    padding: 0;
  }

  .margin0 {
    margin: 0;
  }

  .marginT15 {
    margin-top: 15px;
  }
`;

const st = {
  root: css`
    height: 100%;
    min-height: 100px;
    width: 100%;
    text-align: center;
    position: relative;
    border: solid 1px ${BorderColor.Primary};
  `,
  input: css`
    display: none;
  `,
  inputLabel: css`
    height: 100px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-style: dashed;
    background-color: transparent;

    svg {
      margin-right: 5px;
      fill: ${FontColor.Gray300};
    }

    p {
      color: ${FontColor.Gray400};
      letter-spacing: -0.32px;
      font-size: 13px;
      font-weight: 400;
      transition: 0.3s;
    }

    &.drag-active p {
      color: ${BgColor.Gray300};
      transition: 0.3s;
    }
  `,
  element: css`
    position: absolute;
    width: 100%;
    height: 100%;
    border-radius: 1rem;
    top: 0px;
    right: 0px;
    bottom: 0px;
    left: 0px;
  `,
};

const ALL_FILE_MAX_SIZE = 50 * 1024 * 1024; // 50MB

type MyDropzoneProps = {
  acceptFiles?: string[];
  showAllDownload?: boolean;
  selectedFiles?: FileInfo[];
  onFileChange?: (value: FileInfo[]) => void;
  atchFileGrId?: string;
};

function MyDropzone({
  acceptFiles,
  showAllDownload = false,
  onFileChange,
  selectedFiles,
  atchFileGrId = uuidv4(),
}: MyDropzoneProps) {
  const { t } = useTranslation();
  const { showMessageBar } = useMessageBar();
  const [files = [], setFiles] = useControllableState<FileInfo[]>({
    prop: selectedFiles,
    onChange: onFileChange,
    defaultProp: [],
  });

  const onDropHandler = (dropFiles: File[], rejectedFiles: FileRejection[]) => {
    const newFiles = dropFiles.map((dropFile) => {
      const newFile: FileInfo = {
        atchFileGrId: atchFileGrId,
        atchFileId: uuidv4(),
        atchFileNm: dropFile.name,
        sortOrd: '',
        atchFileSaveLocDivsCd: '',
        atchFileSaveNm: dropFile.name,
        atchFileSize: dropFile.size,
        atchFileEfnmNm: '',
        atchFileSavePathCtn: '',
        atchFileTpCd: '',
        optValCtn1: '',
        optValCtn2: '',
        optValCtn3: '',
        optValCtn4: '',
        optValCtn5: '',
        useYn: CommonYN.Y,
        newYn: true,
        crudKey: CrudCode.CREATE,
        file: dropFile,
      };

      return newFile;
    });

    setFiles((prev) => [...(prev ?? []), ...newFiles]);

    if (rejectedFiles.length > 0)
      showMessageBar({
        message: rejectedFiles[0].errors[0].message,
        usecase: 'error',
      });
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    noClick: false,
    onDrop: onDropHandler,
    accept: acceptFiles ? handleAcceptFiles(acceptFiles) : getAllAcceptFiles(),
    maxSize: ALL_FILE_MAX_SIZE,
  });

  const handleAllDownload = async () => {
    await downloadAllFiles(atchFileGrId);
  };

  const handleDownloadFile = async (file: FileInfo) => {
    try {
      const response = await axios.get(
        `${process.env.API_BASE_URL}/api/v1/file/download?atchFileGrId=${file.atchFileGrId}&atchFileId=${file.atchFileId}`,
        {
          responseType: 'blob',
        }
      );

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', file.atchFileNm);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error(error);
    }
  };

  const handleSortOrdChange = (atchFileId, sortOrd) => {
    if (files.length === 0) {
      return;
    }

    const newSortOrd = sortOrd.replace(/[^-0-9]/g, '');
    setFiles(
      files.map((file) =>
        file.atchFileId === atchFileId
          ? {
              ...file,
              crudKey: file.crudKey == CrudCode.CREATE ? CrudCode.CREATE : CrudCode.UPDATE,
              sortOrd: newSortOrd,
            }
          : file
      )
    );
  };

  const handleDeleteFile = (fileToDelete: FileInfo) => {
    if (files.length === 0) {
      return;
    }

    setFiles(
      files.map((file) =>
        file.atchFileId === fileToDelete.atchFileId
          ? { ...file, useYn: CommonYN.N, sortOrd: '', crudKey: CrudCode.UPDATE }
          : file
      )
    );
  };

  const handleDeleteCancel = (atchFileId: string) => {
    if (files.length === 0) {
      return;
    }

    setFiles(
      files.map((file) => {
        if (file.newYn) {
          return file.atchFileId === atchFileId
            ? { ...file, useYn: CommonYN.Y, crudKey: CrudCode.CREATE }
            : file;
        } else {
          return file.atchFileId === atchFileId
            ? { ...file, useYn: CommonYN.Y, crudKey: CrudCode.READ }
            : file;
        }
      })
    );
  };

  return (
    <div>
      {files && files.length > 0 && (
        <ViewTable>
          <colgroup>
            <col width="130px" />
            <col />
            <col width="130px" />
          </colgroup>
          <thead>
            <tr>
              <th scope="col">{t('common.label.정렬순번', '정렬순번')}</th>
              <th scope="col">{t('common.label.파일명', '파일명')}</th>
              <th scope="col">
                {showAllDownload && (
                  <Button className="small" onClick={handleAllDownload}>
                    {t('common.button.All Download', 'All Download')}
                  </Button>
                )}
              </th>
            </tr>
          </thead>
          <tbody>
            {files.map((file) => (
              <tr key={file.atchFileId}>
                <td>
                  <CustomInputText
                    id="sortOrd"
                    className="fullWidth alignC"
                    value={file.sortOrd || ''}
                    onChange={(e) => {
                      handleSortOrdChange(file.atchFileId, e.target.value);
                    }}
                    disabled={file.useYn === CommonYN.N}
                  />
                </td>
                <td colSpan={2}>
                  <div key={file.atchFileId} className="file-item">
                    {file.useYn === CommonYN.N ? (
                      <Link to="#" className="link" key={file.atchFileId}>
                        <del>
                          {file.atchFileNm}
                          <span className="file-size">
                            {` [${(file.atchFileSize / 1024).toFixed(2)} KB ]`}
                          </span>
                        </del>
                        <Button
                          onClick={() => {
                            handleDeleteCancel(file.atchFileId);
                          }}
                          className="small"
                        >
                          {t('common.button.삭제취소', '삭제취소')}
                        </Button>
                      </Link>
                    ) : (
                      <div className="file-info" key={file.atchFileId}>
                        <Link to="#" className="link" onClick={() => handleDownloadFile(file)}>
                          {file.atchFileNm}
                          <span className="file-size">
                            {` [${(file.atchFileSize / 1024).toFixed(2)} KB ]`}
                          </span>
                        </Link>
                        <Button onClick={() => handleDeleteFile(file)}>
                          <RemoveIcon className="xs"></RemoveIcon>
                        </Button>
                      </div>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </ViewTable>
      )}
      <div {...getRootProps()} css={st.root}>
        <input {...getInputProps()} css={st.input} />
        <label
          css={st.inputLabel}
          htmlFor="input-file-upload"
          className={isDragActive ? 'drag-active' : ''}
        >
          <SearchIcon />
          <p>{t('Drag and Drop file here')}</p>
        </label>
      </div>
    </div>
  );
}

export { MyDropzone };
