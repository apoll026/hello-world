import { useCreateBbsReplyMutation } from '@/amxis/hooks/queries/bbs/use-create-bbs-reply-mutation.ts';
import { useUpdateBbsReplyMutation } from '@/amxis/hooks/queries/bbs/use-update-bbs-reply-mutation.ts';
import { useControllableState } from '@/amxis/hooks/use-controllable-state.ts';
import {
  BbsReplyRequest,
  BbsReply as BbsReplyType,
  BbsReplyUpdateRequest,
} from '@/amxis/models/admin/BbsReply.ts';
import useSessionStore from '@/amxis/stores/useSessionStore.ts';
import { Avatar, Button, useTheme, useMessageBar } from '@amxis/design-system';
import { ControlConfirmIcon, EditDeleteIcon, EditEdit2Icon } from '@amxis/design-system/icon';
import { Box, TextField, Typography } from '@mui/material';
import dayjs from 'dayjs';
import { useTranslation } from 'react-i18next';
import { useDeleteBbsReplyMutation } from '@/amxis/hooks/queries/bbs/use-delete-bbs-reply-mutation.ts';
import { useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { BbsQueryKeys } from '@/amxis/hooks/queries/bbs/bbs-query-keys.ts';
import { useCommonDialogStore } from '@/amxis/stores/useCommonDialogStore.ts';

const formatDateTime = (dataDtm: string, lang: string) =>
  dayjs(dataDtm)
    .locale(lang ?? 'ko')
    .format('YYYY.MM.DD A hh:mm');

type BbsReplyViewType = 'edit' | 'view';
type BbsReplyProps = {
  // initial value
  bbsReply: BbsReplyType;
  // configure
  initialView?: BbsReplyViewType;
  limit?: number;
  minRows?: number;
  maxRows?: number;
  // text field
  placeholder?: string;
  initialValue?: string;
  onViewToggle?: () => void;
};

type BbsReplyEditProps = { isNew?: boolean } & Omit<BbsReplyProps, 'initialView'>;

function BbsReplyEdit({
  isNew = false,
  bbsReply,

  limit = 500,
  minRows = 3,
  maxRows = 5,

  placeholder,
  initialValue,
  onViewToggle,
}: BbsReplyEditProps) {
  const queryClient = useQueryClient();
  const { t } = useTranslation();
  const [theme] = useTheme();
  const { openCommonDialog } = useCommonDialogStore();
  const { showMessageBar } = useMessageBar();

  const [value = '', onChange] = useState(initialValue);

  // mutation
  const { mutateAsync: createBbsReplyMutateAsync } = useCreateBbsReplyMutation();
  const { mutateAsync: updateBbsReplyMutateAsync } = useUpdateBbsReplyMutation();

  const clear = () => {
    onChange('');
  };

  const onSave = async () => {
    // validate
    if (!value) {
      openCommonDialog({
        content: t('bbs-reply.alert.댓글을 입력해 주세요', '댓글을 입력해 주세요'),
      });
      return;
    }

    try {
      if (isNew) {
        const newReply: BbsReplyRequest = {
          bbsNo: bbsReply.bbsNo,
          bbsReCtn: value,
        };

        const isSuccess = await createBbsReplyMutateAsync(newReply);

        if (!isSuccess) {
          throw new Error('failed create reply');
        }

        showMessageBar({
          message: t('common.alert.저장되었습니다.', '저장되었습니다.'),
          usecase: 'success',
        });
        queryClient.invalidateQueries({
          queryKey: BbsQueryKeys.Post(bbsReply.bbsNo),
        });
        clear();

        return;
      } else {
        const updateReply: BbsReplyUpdateRequest = {
          bbsNo: bbsReply.bbsNo,
          bbsReNo: bbsReply.bbsReNo,
          bbsReCtn: value,
        };

        const isSuccess = await updateBbsReplyMutateAsync(updateReply);

        if (!isSuccess) {
          throw new Error('failed update reply');
        }

        showMessageBar({
          message: t('common.alert.저장되었습니다.', '저장되었습니다.'),
          usecase: 'success',
        });
        queryClient.invalidateQueries({
          queryKey: BbsQueryKeys.Post(bbsReply.bbsNo),
        });
        clear();
        onViewToggle?.();

        return;
      }
    } catch (e) {
      console.error(e);

      showMessageBar({
        message: t('common.alert.저장 중 오류가 발생했습니다.', '저장 중 오류가 발생했습니다.'),
        usecase: 'error',
      });
      return;
    }
  };

  return (
    <Box p="12px" bgcolor={theme.palette.semantic.color.commonBgDeep}>
      <Box display="flex" alignItems="center">
        <Avatar
          size="xsmall"
          border={false}
          alt={bbsReply.empName}
          textAvatar={bbsReply.empName ?? ''}
        />
        <Typography
          variant="bodySmallBold"
          sx={{ ml: '4px', color: theme.palette.semantic.color.commonTextBasic }}
        >{`${bbsReply.empName ?? ''} ${bbsReply.jtiNm}`}</Typography>
      </Box>
      <Box mt="4px">
        <Box
          sx={{
            width: '100%',
            bgcolor: theme.palette.semantic.color.commonBgBasic,
            p: '8px',
            borderRadius: '2px',
            border: `1px solid ${theme.palette.semantic.color.commonBorderStrong}`,
          }}
        >
          <TextField
            value={value}
            onChange={(e) => onChange?.(e.target.value)}
            placeholder={
              placeholder ??
              String(t('bbs-reply.alert.댓글을 입력해 주세요', '댓글을 입력해 주세요'))
            }
            inputProps={{
              maxLength: limit,
            }}
            multiline
            minRows={minRows}
            maxRows={maxRows}
            fullWidth
            variant="outlined"
            sx={{
              '& .MuiOutlinedInput-root': {
                border: 'none',
                padding: 0,

                '& fieldset': {
                  border: 'none',
                },
              },
            }}
          />

          <Box mt="4px" display="flex" alignItems="center" justifyContent="space-between">
            <Box display="flex" alignItems="center">
              <Typography
                variant="bodySmall"
                sx={{ color: theme.palette.semantic.color.commonTextLight }}
              >
                {value.length} / {limit}
              </Typography>
            </Box>
            <Box display="flex" alignItems="center" gap="8px">
              {!isNew && (
                <Button
                  type="button"
                  size="medium"
                  appearance="outlined"
                  priority="normal"
                  onClick={onViewToggle}
                >
                  {t('common.button.취소', '취소')}
                </Button>
              )}
              <Button
                type="button"
                size="medium"
                appearance="contained"
                priority="primary"
                iconPosition="leading"
                iconComponent={<ControlConfirmIcon size="default" />}
                onClick={onSave}
              >
                {t('common.button.저장', '저장')}
              </Button>
            </Box>
          </Box>
        </Box>
      </Box>
    </Box>
  );
}

type BbsReplyViewProps = {
  onViewToggle: () => void;
} & BbsReplyType;

function BbsReplyView({
  bbsNo,
  bbsReNo,
  deptNm,
  empName,
  jtiNm,
  bbsReCtn,
  dataInsUserId,
  dataInsDtm,
  onViewToggle,
}: BbsReplyViewProps) {
  const queryClient = useQueryClient();
  const [theme] = useTheme();
  const { i18n } = useTranslation();
  const { mailId } = useSessionStore();
  const { showMessageBar } = useMessageBar();
  const { t } = useTranslation();
  const { openCommonDialog } = useCommonDialogStore();

  const isMe = mailId === dataInsUserId;

  // mutate
  const { mutateAsync: deleteBbsReplyMutateAsync } = useDeleteBbsReplyMutation();

  const onDelete = async () => {
    try {
      const isSuccess = await deleteBbsReplyMutateAsync({ bbsNo, bbsReNo });

      if (!isSuccess) {
        throw new Error('failed delete reply');
      }

      showMessageBar({
        message: t('common.alert.삭제되었습니다.', '삭제되었습니다.'),
        usecase: 'success',
      });
      queryClient.invalidateQueries({
        queryKey: BbsQueryKeys.Post(bbsNo),
      });
    } catch (e) {
      console.error(e);

      showMessageBar({
        message: t('common.alert.삭제 중 오류가 발생했습니다.', '삭제 중 오류가 발생했습니다.'),
        usecase: 'error',
      });
      return;
    }
  };

  return (
    <Box
      sx={{
        p: '12px',
        display: 'flex',
        alignItems: 'flex-start',
        borderBottom: `1px solid ${theme.palette.semantic.color.commonBorderLight}`,
      }}
    >
      <Box>
        <Avatar size="xsmall" border={false} alt={empName} textAvatar={empName ?? ''} />
      </Box>
      <Box ml="8px" flex="1">
        <Box display="flex" alignItems="center" justifyContent="space-between">
          <Box display="flex" alignItems="center">
            <Typography
              variant="bodyBasicBold"
              sx={{ color: theme.palette.semantic.color.commonTextBasic }}
            >
              {`${empName ?? ''} ${jtiNm}`}
            </Typography>
            <Typography
              variant="bodySmall"
              sx={{ ml: '4px', color: theme.palette.semantic.color.commonTextBasic }}
            >
              {deptNm}
            </Typography>
          </Box>
          <Box display="flex" alignItems="center">
            {isMe && (
              <>
                <Button
                  type="button"
                  size="small"
                  appearance="unfilled"
                  priority="normal"
                  iconPosition="leading"
                  iconComponent={<EditEdit2Icon appearance="lined" />}
                  onClick={onViewToggle}
                />
                <Button
                  type="button"
                  size="small"
                  appearance="unfilled"
                  priority="normal"
                  iconPosition="leading"
                  iconComponent={<EditDeleteIcon appearance="lined" />}
                  sx={{
                    ml: '4px',
                  }}
                  onClick={() => {
                    openCommonDialog({
                      modalType: 'confirm',
                      content: t(
                        'bbs.alert.게시글을 삭제하시겠습니까?',
                        '게시글을 삭제하시겠습니까?'
                      ),
                      onSubmit: () => {
                        onDelete();
                      },
                    });
                  }}
                />
              </>
            )}
          </Box>
        </Box>
        <Box>
          <Typography
            variant="bodyBasic"
            sx={{ color: theme.palette.semantic.color.commonTextBasic }}
          >
            {bbsReCtn}
          </Typography>
        </Box>
        <Box>
          <Typography variant="bodySmall">{formatDateTime(dataInsDtm, i18n.language)}</Typography>
        </Box>
      </Box>
    </Box>
  );
}

type BbsReplyNewProps = {
  bbsNo: string;
  initialCtn?: string;
};
function BbsReplyNew({ bbsNo, initialCtn }: BbsReplyNewProps) {
  const { mailId, deptName = '', empName } = useSessionStore();

  const bbsReplyNew: BbsReplyType = {
    bbsNo,
    bbsReNo: '',
    dataInsDtm: '',
    bbsReCtn: initialCtn ?? '',
    dataInsUserId: mailId,
    deptName,
    empName,
    jpsNm,
    jtiNm,
  };

  return <BbsReplyEdit bbsReply={bbsReplyNew} isNew />;
}

function BbsReply({ initialView, ...props }: BbsReplyProps) {
  const [view = 'view', setView] = useControllableState({
    prop: initialView,
  });

  const onViewToggle = () => {
    setView((prev) => (prev === 'edit' ? 'view' : 'edit'));
  };

  if (view === 'view') {
    return <BbsReplyView {...props.bbsReply} onViewToggle={onViewToggle} />;
  }

  return (
    <BbsReplyEdit {...props} initialValue={props.bbsReply.bbsReCtn} onViewToggle={onViewToggle} />
  );
}

export { BbsReply, BbsReplyNew };
