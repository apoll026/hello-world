import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Breadcrumb, Button, TitleArea } from '@amxis/design-system';
import { useMenuContext } from '@/amxis/components/menu-provider';
import { useParentMenus } from './use-parent-menus.ts';
import React, { useEffect, useMemo, useState } from 'react';
import { useBookMarkStore } from '@/amxis/stores/useBookMarkStore.ts';
import { StatusHelpIcon } from '@amxis/design-system/icon';
import { useCommonDialogStore } from '@/amxis/stores/useCommonDialogStore.ts';
import { useHelpStore } from '@/amxis/stores/useHelpStrore.ts';
import { ImageDialog } from '@/amxis/pages/system/help/components/image-dialog.tsx';
import { downloadFile, findFiles } from '@/amxis/apis/admin/FileUpload.ts';
import axios from 'axios';

const appendSlashUrl = (url: string) => (url.startsWith('/') ? url : `/${url}`);

type PageHeaderLayoutProps = {
  showBreadcrumbMenu?: boolean;
};

function PageHeaderLayout({ showBreadcrumbMenu = false }: PageHeaderLayoutProps) {
  const { currentMenu, showMenu } = useMenuContext();
  const { parentMenus } = useParentMenus();
  const navigate = useNavigate();
  const { t, i18n } = useTranslation();
  const isShowMenu = showMenu && showBreadcrumbMenu;
  const { fetchHelp, getHelpData } = useHelpStore();
  const { openCommonDialog } = useCommonDialogStore();
  const [isOpenHelpImg, setIsOpenHelpImg] = useState<boolean>(false);
  const [helpImgSrc, setHelpImgSrc] = useState<string>('');

  useEffect(() => {
    if (currentMenu?.pgmId) {
      fetchHelp(currentMenu.pgmId);
    }
  }, [currentMenu?.pgmId, fetchHelp]);

  // 하나의 함수로 모든 정보 가져오기
  const { hasHelp, helpData } = currentMenu?.pgmId
    ? getHelpData(currentMenu.pgmId)
    : { hasHelp: false, helpData: false };

  const parseHelpData = typeof helpData === 'object' && helpData !== null ? helpData : undefined;

  const { toggleBookMark, isBookMarked } = useBookMarkStore();
  const isMenuBookmarked = currentMenu?.pgmUrl ? isBookMarked(currentMenu.pgmUrl) : false;
  const handleClickBreadcrumb = (url: string) => {
    navigate(appendSlashUrl(url));
  };

  // 북마크 토글 핸들러
  const handleBookmarkToggle = async () => {
    try {
      await toggleBookMark(currentMenu);
    } catch (error) {
      console.error(error);
    }
  };

  const breadcrumbData = useMemo(() => {
    if (!currentMenu) return [];

    const breadcrumbMenus = parentMenus.map((parentMenu, index) => {
      return {
        label: t(`${parentMenu.msgCtn}`, `${parentMenu.pgmName}`),
        url: parentMenus.length !== index + 1 ? parentMenu.pgmUrl : undefined,
        onClick:
          parentMenus.length !== index + 1
            ? () => {
                handleClickBreadcrumb(parentMenu.pgmUrl ?? '');
              }
            : undefined,
      };
    });

    breadcrumbMenus.push({
      label: t(`${currentMenu.msgCtn}`, `${currentMenu.pgmName}`),
      url: undefined,
      onClick: undefined,
    });

    return breadcrumbMenus;
  }, [parentMenus, currentMenu, i18n.language, t]);

  // currentMenu가 없으면 렌더링하지 않음
  if (!currentMenu) {
    return null;
  }

  const handleClickHelpIcon = async () => {
    if (hasHelp) {
      switch (parseHelpData?.helpType) {
        case 'image': {
          setIsOpenHelpImg(true);
          const fileId = await getImgSrc(parseHelpData?.helpFile ?? '');
          setHelpImgSrc(fileId);
          break;
        }
        case 'file': {
          const files = await findFiles(parseHelpData.helpFile ?? '');
          try {
            const response = await axios.get(
              `${process.env.API_BASE_URL}/api/v1/file/download?atchFileGrId=${files[0].atchFileGrId}&atchFileId=${files[0].atchFileId}`,
              {
                responseType: 'blob',
              }
            );

            const url = window.URL.createObjectURL(new Blob([response.data]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', files[0].atchFileNm);
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
          } catch (error) {
            console.error(error);
          }
          break;
        }
        case 'link': {
          window.open(parseHelpData.helpLink);
          break;
        }
      }
    } else {
      openCommonDialog({
        modalType: 'alert',
        content: t('message-help.alert.도움말이 없습니다.', '__도움말이 없습니다.'),
      });
    }
  };

  const getImgSrc = async (atchFileGrId: string) => {
    const fileId = await findFiles(atchFileGrId ?? '');
    console.log('fileId[0].atchFileId', fileId[0].atchFileId);
    return fileId[0].atchFileId;
  };

  return (
    <>
      <TitleArea
        title={t(`${currentMenu.msgCtn}`, `${currentMenu.pgmName}`)}
        isSubTitle={false}
        bullet={false}
        bookmark={!isMenuBookmarked}
        searchAreaSwitch={false}
        isShowIconArea={true}
        breadcrumb={
          isShowMenu &&
          parentMenus &&
          breadcrumbData.length > 0 && (
            <Breadcrumb data={breadcrumbData} maxLength={5} limitWidth="214" />
          )
        }
        onFavorite={handleBookmarkToggle}
        hasRightButtons
        rightButtons={
          <Button
            size="medium"
            appearance="outlined"
            priority="normal"
            iconComponent={<StatusHelpIcon appearance="lined" />}
            sx={{ marginLeft: '4px' }}
            onClick={handleClickHelpIcon}
          />
        }
        sx={{ paddingBottom: '16px' }}
      />
      {isOpenHelpImg && (
        <ImageDialog
          open={isOpenHelpImg}
          onClose={() => setIsOpenHelpImg(false)}
          dialogTitle={parseHelpData?.helpNm ?? ''}
          imageSrc={
            process.env.API_BASE_URL +
            `/api/v1/file/download?atchFileGrId=${parseHelpData?.helpFile}&atchFileId=${helpImgSrc}`
          }
        />
      )}
    </>
  );
}

export { PageHeaderLayout };
