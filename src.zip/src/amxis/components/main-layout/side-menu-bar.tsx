import { useEffect, useState } from 'react';
import { Box, Drawer, IconButton, Typography, useMediaQuery } from '@mui/material';
import { Close as CloseIcon, Menu as MenuIcon } from '@mui/icons-material';
import { useTranslation } from 'react-i18next';
import { Divider, InputField, useTheme } from '@amxis/design-system';
import { useMenuContext } from '@/amxis/components/menu-provider';
import useSessionStore from '@/amxis/stores/useSessionStore.ts';
import { useSideBarMenus } from './use-side-bar-menus.ts';
import { SideMenuList } from './side-menu-list.tsx';
import { MenuLeftIcon } from '@/components/icon/menu/menu-left-icon.tsx';
import { Link, useNavigate } from 'react-router-dom';
import { getAllMenusSearch } from '@/amxis/apis/admin/MenuApi.ts';
import { MenuVO } from '@/amxis/models/admin/Menu.ts';

type SideMenuBarProps = {
  setIsSidebarOpen: React.Dispatch<React.SetStateAction<boolean>>;
  isSidebarOpen: boolean;
};

function SideMenuBar({ setIsSidebarOpen, isSidebarOpen }: SideMenuBarProps) {
  const [isOpened] = useState(true);
  const [isMobile, setIsMobile] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [menuOptions, setMenuOptions] = useState<{ label: string; value: string }[]>([]);
  const [menuData, setMenuData] = useState<MenuVO[]>([]);

  // 1뎁스 메뉴들의 토글 상태 관리
  const [activeDepth1MenuId, setActiveDepth1MenuId] = useState<string | null>(null);

  const menuContext = useMenuContext();
  const { headerMenus } = useSessionStore();
  const { t } = useTranslation();
  const [theme] = useTheme();
  const navigate = useNavigate();

  // 1376px 이하 체크
  const isUnder1376 = useMediaQuery('(max-width:1376px)');

  const { sideMenus } = useSideBarMenus();

  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobile(window.innerWidth <= 768);
    };

    checkScreenSize();
    window.addEventListener('resize', checkScreenSize);

    return () => window.removeEventListener('resize', checkScreenSize);
  }, []);

  // 메뉴 검색 옵션 데이터 가져오기
  useEffect(() => {
    const fetchMenuOptions = async () => {
      // 세션이 없거나 헤더 메뉴가 없으면 API 호출하지 않음
      if (!menuContext.selectedHeaderMenu || headerMenus.length === 0) {
        return;
      }

      try {
        const menuDataResult = await getAllMenusSearch();
        if (menuDataResult) {
          setMenuData(menuDataResult);
          const options = menuDataResult.map((menu: MenuVO) => ({
            label: menu.pgmName || menu.pgmId,
            value: menu.pgmId,
          }));
          setMenuOptions(options);
        }
      } catch (error) {
        console.error('메뉴 검색 데이터를 가져오는데 실패했습니다:', error);
      }
    };

    fetchMenuOptions();
  }, [menuContext.selectedHeaderMenu, headerMenus]);

  const generateHeaderMenuName = (pgmId: string) => {
    const headerMenu = headerMenus.find((item) => item.pgmId === pgmId);
    return String(t(`${headerMenu?.msgCtn}`, `${headerMenu?.pgmName}`));
  };

  const handleMobileMenuToggle = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const handleMobileMenuClose = () => {
    setMobileMenuOpen(false);
  };

  // 1뎁스 메뉴 토글 핸들러
  const handleDepth1MenuToggle = (menuId: string | null) => {
    setActiveDepth1MenuId(menuId);
  };

  // 메뉴 검색에서 선택된 메뉴로 이동
  const handleMenuSelect = (e, selectedValue) => {
    const selectedMenu = menuData.find(menu => menu.pgmId === selectedValue.value);

    if (selectedMenu && selectedMenu.pgmUrl) {
      navigate("/" + selectedMenu.pgmUrl);
    }
  };

  // @ts-ignore
  const sideMenuContent = (
    <Box
      width="100%"
      height="100%"
      sx={{
        overflowY: 'hidden',
      }}
    >
      <Box
        fontSize={15}
        fontWeight={700}
        padding="19px 4px 12px 10px"
        color={theme.palette.semantic.color.commonTextBasic}
        display="flex"
        justifyContent={isMobile || isUnder1376 ? 'flex-start' : 'space-between'}
        alignItems="center"
        margin={0}
        sx={{
          // 1376px 이하일 때 제목과 햄버거 버튼 간격 조정
          gap: isUnder1376 ? '12px' : '0',
        }}
      >
        {/* 1376px 이하에서 햄버거 버튼을 제목 우측에 배치 */}

        <Box
          size="small"
          sx={{
            display: 'flex',
            color: theme.palette.semantic.color.commonTextLight,
            justifyContent: 'space-between',
            alignItems: 'center',
            width: '100%',
            padding: 0,
            fontSize: '17px',
            fontWeight: '700',
            cursor: 'default',
          }}
        >
          {/* {generateHeaderMenuName(menuContext.selectedHeaderMenu)} */}
          <Link to="/">협력사계좌관리</Link>
          <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <MenuLeftIcon
              fontSize="small"
              sx={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                '& svg': { transform: 'translate(15%, 20%)' },
              }}
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            />
          </span>
        </Box>

        {/* 기존 모바일 닫기 버튼 */}
        {isMobile && (
          <IconButton
            onClick={handleMobileMenuClose}
            size="small"
            sx={{
              color: theme.palette.semantic.color.commonTextLight,
              marginTop: '4px',
              ml: 'auto', // 우측 정렬
            }}
          >
            <CloseIcon fontSize="small" />
          </IconButton>
        )}
      </Box>
      <Box
        sx={{
          padding: '0 8px',
        }}
      >
        <InputField
          type="search"
          usecase="text"
          onSearchClick={() => console.log('search Clicked')}
          onChange={handleMenuSelect}
          placeholder="메뉴를 검색하세요"
          options={menuOptions}
        />
      </Box>
      <Box
        sx={{
          padding: '12px 10px 4px',
        }}
      >
        <Typography
          sx={{
            fontSize: '16px',
            fontWeight: 700,
            color: '#232B35',
          }}
        >
          {generateHeaderMenuName(menuContext.selectedHeaderMenu)}
        </Typography>
      </Box>
      <Divider sx={{ margin: '4px 8px' }} />
      <Box
        padding={'0 8px'}
        sx={{
          overflow: 'auto',
          height: window.innerWidth <= 1376 ? 'calc(100vh - 170px)' : 'calc(100vh - 139px)',
        }}
      >
        {sideMenus.map((it) => (
          <SideMenuList
            key={it.menuInfo.pgmId}
            summary={{ menuInfo: it.menuInfo }}
            content={it.children}
            isActive={true}
            menuId={it.menuInfo.pgmId}
            activeMenuId={activeDepth1MenuId}
            onMenuToggle={handleDepth1MenuToggle}
          />
        ))}
      </Box>
    </Box>
  );

  if (!menuContext.selectedHeaderMenu || sideMenus.length === 0) {
    return null;
  }

  return (
    <>
      {/* 기존 모바일 햄버거 버튼 (768px 이하) */}
      {isMobile && (
        <Box
          position="fixed"
          top="60px"
          left="0"
          zIndex={12}
          bgcolor={theme.palette.semantic.color.commonBgDeep}
          borderRight={`1px solid ${theme.palette.semantic.color.commonBorderBasic}`}
          borderBottom={`1px solid ${theme.palette.semantic.color.commonBorderBasic}`}
        >
          <IconButton
            onClick={handleMobileMenuToggle}
            sx={{
              border: 'none',
              color: theme.palette.semantic.color.commonTextPrimary,
              padding: '12px',
            }}
          >
            <MenuIcon />
          </IconButton>
        </Box>
      )}

      {isMobile ? (
        <Drawer
          anchor="left"
          open={mobileMenuOpen}
          onClose={handleMobileMenuClose}
          sx={{
            '& .MuiDrawer-paper': {
              width: '230px',
              bgcolor: '#fdfdfd',
              borderRight: `1px solid ${theme.palette.semantic.color.commonBorderBasic}`,
              top: '60px',
              height: 'calc(100vh - 60px)',
            },
          }}
        >
          {sideMenuContent}
        </Drawer>
      ) : (
        <Box
          position="relative"
          zIndex={11}
          width={isOpened ? '230px' : '0'}
          height="100vh"
          borderRadius={'0 12px 0 0'}
          bgcolor={'#fdfdfd'}
          borderRight={`1px solid ${theme.palette.semantic.color.commonBorderBasic}`}
          sx={{
            transition: 'width 0.3s ease',
            flexShrink: 0,
            boxShadow: '0px 0px 10px 0px rgba(0, 0, 0, 0.12)',
          }}
        >
          {isOpened && sideMenuContent}
        </Box>
      )}
    </>
  );
}

export { SideMenuBar };
