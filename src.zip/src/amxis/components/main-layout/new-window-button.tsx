function NewWindowButton() {
  // not included in std system
  return null;
}

export { NewWindowButton };
