import { useMemo } from 'react';
import { useMenuContext } from '@/amxis/components/menu-provider';
import { Menu } from '@/amxis/models/admin/Menu.ts';
import useSessionStore from '@/amxis/stores/useSessionStore.ts';
import { MenuType } from './menu.types.ts';
import { nest } from './main-layout.utils.ts';

// Menu[]를 MenuType[]로 변환하는 헬퍼 함수
const convertToMenuType = (menus: Menu[], allMenus: Menu[]): MenuType[] => {
  return menus.map((menu) => ({
    menuInfo: menu,
    children: convertToMenuType(nest(allMenus, menu.pgmId), allMenus),
  }));
};

function useSideBarMenus() {
  const { menus } = useSessionStore();
  const { selectedHeaderMenu } = useMenuContext();

  // 메뉴 트리 계산 캐싱
  const sideMenus = useMemo(() => {
    if (!menus || !selectedHeaderMenu) return [];
    
    const depth1Menus: Menu[] = menus.filter((item) => item.upgmId === selectedHeaderMenu);
    const newSideMenuList: MenuType[] = [];

    depth1Menus.forEach((item) => {
      const tree = convertToMenuType(nest(menus, item.pgmId), menus);
      newSideMenuList.push({
        menuInfo: item,
        children: tree,
      });
    });
    
    return newSideMenuList;
  }, [menus, selectedHeaderMenu]);

  return { sideMenus };
}

export { useSideBarMenus };
