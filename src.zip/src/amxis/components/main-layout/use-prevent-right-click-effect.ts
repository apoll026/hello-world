import { useEffect } from 'react';

function usePreventRightClickEffect() {
  const isLocal = process.env.NODE_ENV === 'local' || process.env.NODE_ENV === 'dev';

  const preventRightClick = (event: MouseEvent) => {
    if (isLocal) {
      return;
    }
    event.preventDefault();
    alert('우클릭을 사용할 수 없습니다.');
  };

  useEffect(() => {
    window.addEventListener('contextmenu', preventRightClick);

    return () => {
      window.removeEventListener('contextmenu', preventRightClick);
    };
  }, []);

  return null;
}

export { usePreventRightClickEffect };
