import {
  Box,
  ClickAwayListener,
  MenuItem,
  MenuList,
  Paper,
  Popper,
  IconButton,
} from '@mui/material';
import { Avatar, Button, OptionList, useTheme } from '@amxis/design-system';
import { useMenuContext } from '@/amxis/components/menu-provider';
import useSessionStore from '@/amxis/stores/useSessionStore.ts';
import { useDisplayEmpName } from './use-display-emp-name.ts';
import { HeaderLinkList } from './header-link-list.tsx';
import { CommunicationBookmarkIcon, MenuMoreIcon } from '@amxis/design-system/icon';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useBookMarkStore } from '@/amxis/stores/useBookMarkStore.ts';
import { BookMark } from '@/amxis/models/admin/Menu';

const CloseIcon = () => (
  <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
    <path
      d="M9 3L3 9M3 3l6 6"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

type HeaderMenuBarProps = {
  headerMenusNum?: number;
  isSidebarOpen: boolean;
  setIsSidebarOpen?: (open: boolean) => void;
};

function HeaderMenuBar({
  headerMenusNum = 0,
  isSidebarOpen,
  setIsSidebarOpen,
}: HeaderMenuBarProps) {
  const { headerMenus, cmpnCode, menus } = useSessionStore();
  const menuContext = useMenuContext();
  const { displayEmpNm } = useDisplayEmpName();
  const [theme] = useTheme();
  const { bookMarkMenus, removeBookMark } = useBookMarkStore();
  const navigate = useNavigate();

  // 선택된 메뉴가 자식 메뉴를 가지고 있는지 확인하는 함수
  const hasChildMenus = (menuId: string): boolean => {
    if (!menus) return false;

    const childMenus = menus.filter((menu) => menu.upgmId === menuId && menu.useYn === 'Y');
    return childMenus.length > 0;
  };

  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [bookmarkAnchorEl, setBookmarkAnchorEl] = useState<null | Element>(null);
  const [bookmarkOpen, setBookmarkOpen] = useState(false);
  const { fetchBookMarkMenus } = useBookMarkStore();

  useEffect(() => {
    fetchBookMarkMenus();
  }, [fetchBookMarkMenus]);

  // 더보기 메뉴 클릭 핸들러
  const handleClickMoreMenu = (event: React.MouseEvent<HTMLElement>) => {
    // event.currentTarget을 미리 저장 (React의 이벤트 풀링 대응)
    const target = event.currentTarget;

    // 북마크가 열려있으면 먼저 닫기
    if (bookmarkOpen) {
      setBookmarkOpen(false);
      setBookmarkAnchorEl(null);
    }

    // 더보기 메뉴 토글
    if (anchorEl) {
      setAnchorEl(null);
    } else {
      setAnchorEl(target);
    }
  };

  const handleOptionListClose = () => {
    setAnchorEl(null);
  };

  // 북마크 아이콘 클릭 핸들러
  const handleBookmarkClick = (event: React.MouseEvent<SVGSVGElement, MouseEvent>) => {
    // 더보기 메뉴가 열려있으면 먼저 닫기
    if (anchorEl) {
      setAnchorEl(null);
    }

    // 북마크 메뉴 토글
    if (bookmarkOpen) {
      setBookmarkOpen(false);
      setBookmarkAnchorEl(null);
    } else {
      setBookmarkAnchorEl(event.currentTarget);
      setBookmarkOpen(true);
    }
  };

  const handleBookmarkClose = () => {
    setBookmarkOpen(false);
    setBookmarkAnchorEl(null);
  };

  // 북마크 아이템 클릭 핸들러
  const handleBookmarkItemClick = (pgmUrl: string) => {
    // 북마크 메뉴 닫기
    handleBookmarkClose();

    // 페이지 이동
    if (pgmUrl) {
      navigate('/' + pgmUrl);
    }
  };

  // 북마크 삭제 핸들러
  const handleBookmarkDelete = async (event: React.MouseEvent, bookMark: BookMark) => {
    event.stopPropagation(); // 메뉴 아이템 클릭 이벤트 방지
    await removeBookMark(bookMark);
  };

  return (
    <Box
      position="relative"
      zIndex={10}
      width="100%"
      height="60px"
      bgcolor={theme.palette.semantic.color.navTopBgBasic}
      display="flex"
      alignItems="center"
      justifyContent="space-between"
      borderBottom={`1px solid ${theme.palette.semantic.color.commonBorderBasic}`}
    >
      {cmpnCode && (
        <>
          <Box flex={1} display="flex" justifyContent="center">
            <HeaderLinkList
              headerMenusNum={headerMenusNum}
              isSidebarOpen={isSidebarOpen}
              setIsSidebarOpen={setIsSidebarOpen}
            />
          </Box>

          <Box
            height="100%"
            display="flex"
            alignItems="center"
            gap="16px"
            position="absolute"
            right="16px"
          >
            {/* 더보기 메뉴 버튼 */}
            {headerMenus.filter((menu) => menu.useYn === 'Y').length > headerMenusNum && (
              <ClickAwayListener onClickAway={handleOptionListClose}>
                <Box>
                  {headerMenusNum < 10 && (
                    <Button
                      appearance="unfilled"
                      iconComponent={<MenuMoreIcon direction="horizontal" />}
                      iconPosition="leading"
                      onClick={handleClickMoreMenu}
                      priority="normal"
                      size="small"
                    />
                  )}
                  <Popper
                    open={Boolean(anchorEl)}
                    anchorEl={anchorEl}
                    placement="bottom-start"
                    modifiers={[
                      {
                        name: 'offset',
                        options: {
                          offset: [0, 0],
                        },
                      },
                    ]}
                  >
                    <OptionList
                      sx={{
                        zIndex: '101',
                        '& .MuiList-root': {
                          marginTop: 0,
                          border: '1px solid' + theme.palette.semantic.color.commonBorderStrong,
                          borderRadius: '2px',
                          padding: '8px 0',
                          boxShadow:
                            '0px 0px 2px 0px rgba(0, 0, 0, 0.17), 0px 4px 5px 0px rgba(0, 0, 0, 0.11)',
                          '& li': {
                            width: 'auto',
                            lineHeight: '20px',
                            '& :hover': {
                              background: theme.palette.semantic.color.commonBorderStrong,
                            },
                          },
                        },
                      }}
                      options={headerMenus
                        .filter((menu) => menu.useYn === 'Y')
                        .filter((menu, index) => index > headerMenusNum - 1)
                        .map((menu) => ({
                          label: menu.pgmName || '',
                          value: menu.pgmId || '',
                        }))}
                      anchorEl={anchorEl}
                      open={Boolean(anchorEl)}
                      type="none"
                      onSelectClick={(value) => {
                        const selectedMenu = headerMenus.find((menu) => menu.pgmId === value);
                        if (selectedMenu) {
                          // 메뉴 선택 후 OptionList 닫기
                          setAnchorEl(null);

                          // 자식 메뉴가 있는지 확인
                          const hasChildren = hasChildMenus(selectedMenu.pgmId);
                          if (typeof setIsSidebarOpen === 'function') {
                            setIsSidebarOpen(true);
                          }
                          // 자식이 있는 경우 사이드 메뉴만 업데이트 (페이지 이동 안함)
                          // 자식이 없는 경우 페이지 이동도 함께 수행
                          menuContext.handleMenuChange({
                            ...menuContext,
                            selectedHeaderMenu: selectedMenu.pgmId,
                            clickedByHeaderMenu: !hasChildren, // 자식이 없을 때만 페이지 이동
                          });
                        }
                      }}
                    />
                  </Popper>
                </Box>
              </ClickAwayListener>
            )}

            {/* 북마크 아이콘 */}
            <CommunicationBookmarkIcon
              appearance={bookmarkOpen ? 'filled' : 'lined'}
              iconSize={24}
              onClick={handleBookmarkClick}
              style={{ cursor: 'pointer' }}
            />

            {/* 북마크 드롭다운 메뉴 */}
            <Popper
              open={bookmarkOpen}
              anchorEl={bookmarkAnchorEl}
              placement="bottom-end"
              style={{ zIndex: 1300 }}
            >
              <ClickAwayListener onClickAway={handleBookmarkClose}>
                <Paper
                  sx={{
                    mt: 1,
                    minWidth: '200px',
                    border: `1px solid ${theme.palette.semantic.color.commonBorderStrong}`,
                    borderRadius: '2px',
                    padding: '8px 0',
                    boxShadow:
                      '0px 0px 2px 0px rgba(0, 0, 0, 0.17), 0px 4px 5px 0px rgba(0, 0, 0, 0.11)',
                  }}
                >
                  <MenuList>
                    {bookMarkMenus.length > 0 ? (
                      bookMarkMenus.map((item) => (
                        <MenuItem
                          key={item.pgmId}
                          onClick={() => handleBookmarkItemClick(item.pgmUrl ?? '')}
                          sx={{
                            '&:hover': {
                              backgroundColor: theme.palette.semantic.color.infoBgSecondary,
                            },
                            pr: 1, // 오른쪽 패딩 줄여서 X 버튼 공간 확보
                          }}
                        >
                          <Box
                            display="flex"
                            alignItems="center"
                            justifyContent="space-between"
                            width="100%"
                          >
                            <Box display="flex" alignItems="center" gap="8px">
                              <CommunicationBookmarkIcon appearance="filled" fontSize="small" />
                              {item.pgmName}
                            </Box>
                            <IconButton
                              size="small"
                              onClick={(event) => handleBookmarkDelete(event, item)}
                              sx={{
                                width: '20px',
                                height: '20px',
                                minWidth: '20px',
                                padding: 0,
                                ml: 1,
                                color: theme.palette.semantic.color.commonTextSecondary,
                                '&:hover': {
                                  backgroundColor: theme.palette.semantic.color.commonBgSecondary,
                                  color: theme.palette.semantic.color.commonBgSecondary,
                                },
                              }}
                            >
                              <CloseIcon />
                            </IconButton>
                          </Box>
                        </MenuItem>
                      ))
                    ) : (
                      <MenuItem disabled>
                        <Box display="flex" alignItems="center" gap="8px">
                          북마크가 없습니다
                        </Box>
                      </MenuItem>
                    )}
                  </MenuList>
                </Paper>
              </ClickAwayListener>
            </Popper>

            {/* 사용자 정보 */}
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                cursor: 'pointer',
              }}
            >
              <Avatar size="xsmall" alt={displayEmpNm} contentType="icon" textAvatar="" />
              <Box fontSize="14px" fontWeight={500}>
                {displayEmpNm}
              </Box>
            </Box>
          </Box>
        </>
      )}
    </Box>
  );
}

export { HeaderMenuBar };
