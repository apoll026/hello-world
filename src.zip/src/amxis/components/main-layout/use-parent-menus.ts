import { useMenuContext } from '@/amxis/components/menu-provider';
import { Menu } from '@/amxis/models/admin/Menu.ts';
import { useCallback, useEffect, useState } from 'react';
import useSessionStore from '@/amxis/stores/useSessionStore.ts';
import { RootPgm } from '@/amxis/models/common/Session';

function useParentMenus() {
  const [parentMenus, setParentMenus] = useState<Menu[]>([]);

  const { menus } = useSessionStore();
  const menuContext = useMenuContext();

  const findParentMenu = useCallback(
    (menu: Menu) => {
      const newParentMenus: Menu[] = [];
      if (menu.pgmUrl === '') {
        menuContext.handleMenuChange({ ...menuContext, selectedHeaderMenu: '' });
        setParentMenus(newParentMenus);
        return;
      }
      let cur = menus.find((item) => item.pgmId === menu.upgmId) as Menu;
      if (cur) {
        while (cur.pgmId !== RootPgm) {
          newParentMenus.unshift(cur);
          cur = menus.find((item) => item.pgmId === cur.upgmId) as Menu;
          if (!cur) break;
        }
        menuContext.handleMenuChange({
          ...menuContext,
          selectedHeaderMenu: newParentMenus?.[0]?.pgmId,
        });
        return newParentMenus;
      }
    },
    [menuContext]
  );

  useEffect(() => {
    const menu = menuContext.currentMenu;
    if (!menu) return;
    setParentMenus(findParentMenu(menu) ?? []);
  }, [menuContext.currentMenu]);

  return { parentMenus };
}

export { useParentMenus };
