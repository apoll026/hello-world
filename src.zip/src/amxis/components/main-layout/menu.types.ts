import { Menu } from '@/amxis/models/admin/Menu.ts';

export type MenuType = {
  menuInfo: Menu;
  children: MenuType[];
};

export type MenuTree = Menu & {
  children?: MenuTree[];
};
