import { useEffect, useState } from 'react';
import { Outlet, useLocation } from 'react-router';
import { Box, useTheme } from '@mui/material';
import { useMenuContext } from '@/amxis/components/menu-provider';
import { SideMenuBar } from './side-menu-bar.tsx';
import { PageHeaderLayout } from './page-header-layout.tsx';
import { NoticePopupModals } from './notice-popup-modals.tsx';
import { usePreventRightClickEffect } from './use-prevent-right-click-effect.ts';
import { usePreventDevToolShortcutEffect } from './use-prevent-dev-tool-shortcut-effect.ts';
import { MenuMenuIcon } from '@/components/icon/menu/menu-menu-icon.tsx';
import { HeaderMenuBar } from './header-menu-bar.tsx'; 
import { Link } from 'react-router-dom';

type MainLayoutProps = {
  noPaddingPage?: boolean;
  noShowPageHeader?: boolean;
  noShowPageHeaderBreadcrumbMenu?: boolean;
};

function MainLayout({
  noPaddingPage = false,
  noShowPageHeader = false,
  noShowPageHeaderBreadcrumbMenu = false,
}: MainLayoutProps) {
  const {
    palette: {
      semantic: { color },
    },
  } = useTheme();
  const location = useLocation();
  const { showMenu } = useMenuContext();

  usePreventRightClickEffect();
  usePreventDevToolShortcutEffect();

  const hasMenuBar = showMenu && location.pathname !== '/errorPage';

  const [isMobile, setIsMobile] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const sidebarWidth = 230;
  const headerHeight = 60;

  const [headerMenusNum, setHeaderMenusNum] = useState(() => {
    if (typeof window !== 'undefined') {
      const width = window.innerWidth;
      if (width <= 833) return 2;
      if (width <= 938) return 3;
      if (width <= 1210) return 4;
      if (width <= 1376) return 6;
      if (width < 1681) return 7;
      if (width >= 1680) return 10;
      return 7;
    }
    return 7;
  });

  useEffect(() => {
    const handleResize = () => {
      const width = window.innerWidth;
      const isNowMobile = window.innerWidth <= 1376;
      setIsMobile(isNowMobile);
      setIsSidebarOpen(!isNowMobile); // 여기서 너비 조건에 따라 true/false 설정
      if (location.pathname == '/') {
        setIsSidebarOpen(false);
      }
      if (width <= 833) {
        setHeaderMenusNum(2);
      } else if (width <= 938) {
        setHeaderMenusNum(3);
      } else if (width <= 1210) {
        setHeaderMenusNum(4);
      } else if (width <= 1376) {
        setHeaderMenusNum(6);
      } else if (width < 1680) {
        setHeaderMenusNum(7);
      } else if (width >= 1680) {
        setHeaderMenusNum(10);
      }
    };

    handleResize(); // 초기 실행
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <>
      <Box width="100%" height="100dvh" display="flex">
        {hasMenuBar && (
          <Box
            width={location.pathname === '/login' ? '0' : isSidebarOpen ? `${sidebarWidth}px` : '0'}
            height="100vh"
            sx={{
              position: isMobile ? 'fixed' : 'relative',
              left: isSidebarOpen ? '0' : `-${sidebarWidth}px`,
              transition: isMobile ? '0.5s all' : '',
              flexShrink: 0,
              background: isMobile ? '' : '#EDF0F3',
              zIndex: 30,
            }}
          >
            <SideMenuBar isSidebarOpen={isSidebarOpen} setIsSidebarOpen={setIsSidebarOpen} />
          </Box>
        )}
        <Box flex="1" display="flex" flexDirection="column" style={{ overflowX: 'hidden' }}>
          {location.pathname !== '/login' && hasMenuBar && (
            <Box position="absolute" top="10px" left="10px" zIndex={20}>
              <Box
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '83px',
                  fontSize: '17px',
                  fontWeight: '700',
                  height: '40px',
                  color: color.navTopTextSysNameLogo,
                  padding: '8px 8px 8px 0',
                }}
              >
                <Link to="/">협력사계좌관리</Link>
                {location.pathname !== '/' && (
                  <MenuMenuIcon
                    sx={{
                      fontSize: '24px',
                      cursor: 'pointer',
                      '& svg': { transform: 'translate(15%, 20%)' },
                    }}
                    onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                  />
                )}
              </Box>
            </Box>
          )}

          {/* 헤더 */}
          <Box height={`${headerHeight}px`} flexShrink={0}>
            <HeaderMenuBar
              headerMenusNum={headerMenusNum}
              isSidebarOpen={isSidebarOpen}
              setIsSidebarOpen={setIsSidebarOpen}
            />
          </Box>

          {/* 콘텐츠 */}
          <Box
            flex="1"
            display="flex"
            flexDirection="column"
            bgcolor={color.commonBgDeeper}
            px={noPaddingPage ? '0' : '20px'}
            py={noPaddingPage ? '0' : '16px'}
            sx={{
              transition: '0.3s',
              overflowY: 'auto',
              overflowX: 'hidden',
            }}
          >
            <Box
              style={
                isMobile && window.innerWidth <= 1210
                  ? {
                      zoom: '0.8',
                    }
                  : { height: 'calc(100% - 40px)' }
              }
            >
              {!noShowPageHeader && (
                <PageHeaderLayout showBreadcrumbMenu={!noShowPageHeaderBreadcrumbMenu} />
              )}
              <Box
                flex="1"
                height="100%"
                sx={{
                  '&.hasInnerNav': { padding: '0 30px 50px 0' },
                }}
              >
                <Outlet />
              </Box>
            </Box>
          </Box>
        </Box>
        <Box
          sx={{
            display: isSidebarOpen && isMobile ? 'block' : 'none',
            position: 'absolute',
            left: 0,
            top: 0,
            right: 0,
            bottom: 0,
            background: 'rgba(0,0,0,0.4)',
            zIndex: 19,
          }}
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
        ></Box>
      </Box>
    </>
  );
}

function PlainMainLayout() {
  return <MainLayout noPaddingPage noShowPageHeader noShowPageHeaderBreadcrumbMenu />;
}

function PlainMainLayoutWithNoticePopups() {
  return (
    <>
      <PlainMainLayout />
      <NoticePopupModals />
    </>
  );
}

function MainLayoutWithNoticePopups() {
  return (
    <>
      <MainLayout />
      <NoticePopupModals />
    </>
  );
}

export { MainLayout, PlainMainLayout, PlainMainLayoutWithNoticePopups, MainLayoutWithNoticePopups };
