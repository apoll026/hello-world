import { useEffect } from 'react';

function usePreventDevToolShortcutEffect() {
  const isLocal = process.env.NODE_ENV === 'local';

  const preventDevToolsShortcuts = (event: KeyboardEvent) => {
    if (isLocal) {
      return;
    }

    // F12, Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+U를 차단
    if (
      event.key === 'F12' ||
      (event.ctrlKey && event.shiftKey && (event.key === 'I' || event.key === 'J')) || // Ctrl+Shift+I / Ctrl+Shift+J
      (event.ctrlKey && event.key === 'U') // Ctrl+U (소스 보기)
    ) {
      event.preventDefault();
      alert('해당 단축키는 사용할 수 없습니다.');
    }
  };

  useEffect(() => {
    window.addEventListener('keydown', preventDevToolsShortcuts);

    return () => {
      window.removeEventListener('keydown', preventDevToolsShortcuts);
    };
  }, []);

  return null;
}

export { usePreventDevToolShortcutEffect };
