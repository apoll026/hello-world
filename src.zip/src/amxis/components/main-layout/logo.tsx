import { Link } from 'react-router-dom';
import { useTheme } from '@amxis/design-system';
import { Box } from '@mui/material';
import { useMenuContext } from '@/amxis/components/menu-provider';
import useSessionStore from '@/amxis/stores/useSessionStore.ts';

function Logo() {
  const { langCd } = useSessionStore();
  const menuContext = useMenuContext();
  const [theme] = useTheme();

  const handleMenuBar = () => {
    menuContext.handleMenuChange({ ...menuContext, selectedHeaderMenu: '' });
  };
  return (
    <Box height="51px" display="flex">
      <Box
        component={Link}
        onClick={handleMenuBar}
        to={'/'}
        display="flex"
        color={theme.palette.semantic.color.navTopTextSysNamePrimary}
        margin="0 12px"
        height="100%"
        flex="0 0 20rem"
        alignItems="center"
        justifyContent="start"
      >
        <Box
          component="span"
          alignSelf="end"
          height="100%"
          display="flex"
          alignItems="flex-start"
          flexDirection="column"
          justifyContent="center"
        >
          <Box
            component="span"
            display="inline-block"
            fontSize="14px"
            fontWeight={400}
            color={theme.palette.greylight[800]}
            whiteSpace={!langCd || langCd === 'ko' ? 'initial' : 'pre-line'}
          >
            {langCd && langCd !== 'ko' ? 'AM Innovation' : 'EAS'}
          </Box>
          <Box
            component="span"
            marginTop="3px"
            display="inline-block"
            fontSize="12px"
            fontWeight={300}
            color={theme.palette.semantic.color.navTopTextSysNamePrimary}
          >
            {langCd && langCd !== 'ko' ? 'EAS' : 'AM Innovation'}
          </Box>
        </Box>
      </Box>
    </Box>
  );
}

export { Logo };
