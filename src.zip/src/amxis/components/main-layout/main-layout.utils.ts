import { Menu } from '@/amxis/models/admin/Menu.ts';
import { RootPgm } from '@/amxis/models/common/Session';

const nest = (menuData: Menu[], pgmId = RootPgm, link = 'upgmId') =>
  menuData
    .filter((item) => item[link] === pgmId)
    .map((item) => ({ ...item, children: nest(menuData, item.pgmId) }));

function toAbsolutePath(path: string) {
  if (path === '') {
    return path;
  }

  return path.startsWith('/') ? path : '/' + path;
}

export { nest, toAbsolutePath };
