import { useEffect, useMemo } from 'react';
import { DropdownField } from '@amxis/design-system';
import { Code } from '@/amxis/models/common/CommonCode.ts';
import useLanguageStore from '@/amxis/stores/useLanguageStore.ts';
import { LangType, LanguageCode } from '@/amxis/models/common/Session.ts';
import { Box } from '@mui/material';
import { useCommonDialogStore } from '@/amxis/stores/useCommonDialogStore.ts';
import { useNavigate } from 'react-router-dom';
import { useMenuContext } from '../menu-provider';
import { useTranslation } from 'react-i18next';

const languages: Code[] = [
  {
    cmnCd: LanguageCode.ko,
    cmnCdNm: 'KOR',
  },
  {
    cmnCd: LanguageCode.en,
    cmnCdNm: 'ENG',
  },
  // {
  //   cmnCd: LanguageCode.pl,
  //   cmnCdNm: 'POL',
  // },
  {
    cmnCd: LanguageCode.zhC,
    cmnCdNm: 'CHN',
  },
  // {
  //   cmnCd: LanguageCode.zhT,
  //   cmnCdNm: 'CHN-TC',
  // },
];

type LangOption = {
  label: string;
  value: LangType;
};
function isLanyType(language: any): language is LangType {
  return Object.keys(LanguageCode).some((langCode) => langCode === language);
}
function isLangOption(arg: any): arg is LangOption {
  return arg.label !== undefined && isLanyType(arg.value);
}

function LanguageButton() {
  const navigate = useNavigate();

  const menuContext = useMenuContext();
  const { t } = useTranslation();
  const { openCommonDialog } = useCommonDialogStore();

  const { initLanguage, currentLanguage, changeLanguage } = useLanguageStore();

  const initialOption = {
    label: languages.find((lang) => lang.cmnCd === LanguageCode.ko),
    value: LanguageCode.ko,
  };

  const value = useMemo(() => {
    const found = languages.find((lang) => lang.cmnCd === currentLanguage);
    if (!found) {
      return initialOption;
    }

    return {
      label: found.cmnCdNm,
      value: found.cmnCd,
    };
  }, [currentLanguage]);

  useEffect(() => {
    initLanguage();
  }, []);

  return (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        '.MuiAutocomplete-root': {
          minWidth: '89px',
          boxShadow: 'none',
          '.MuiOutlinedInput-notchedOutline': {
            border: 0,
          },
        },
        '.MuiFormControl-root': {
          backgroundColor: '#F7F9F8 !important',
        },
      }}
    >
      <DropdownField
        size="large"
        isInput={false}
        options={languages.map((lang) => ({
          label: lang.cmnCdNm,
          value: lang.cmnCd,
        }))}
        value={value}
        onChange={(_, item) => {
          if (isLangOption(item)) {
            // if (['regist', 'modify'].includes(menuContext.currentPage?.pageType ?? '')) {
            //   openCommonDialog({
            //     title: t('com.lbl.chk', '확인'),
            //     modalType: 'confirm',
            //     content: `${t('com.msg.noSave', '작성 중인 내용이 저장되지 않습니다.')}\n${t(
            //       'com.msg.ynMove',
            //       '이동하시겠습니까?'
            //     )}`,
            //     onSubmit: () => {
            //       changeLanguage(item.value, () => navigate('/'));
            //     },
            //   });
            // } else {
            //   changeLanguage(item.value, () => navigate('/'));
            // }

            changeLanguage(item.value);
          }
        }}
      />
    </Box>
  );
}

export { LanguageButton };
