import { useEffect, useState } from 'react';
import useSessionStore from '@/amxis/stores/useSessionStore.ts';

function useDisplayEmpName() {
  const { empName, langCd, empCngNm, empEngNm } = useSessionStore();
  const [displayEmpNm, setDisplayEmpNm] = useState(empName ?? '');

  useEffect(() => {
    let newEmpNm = empName;
    console.log(empName);
    switch (langCd) {
      case 'en':
      case 'pl':
        newEmpNm = empEngNm ?? empName;
        break;
      case 'zhC':
      case 'zhT':
        newEmpNm = empCngNm ?? empName;
        break;
    }
    setDisplayEmpNm(newEmpNm);
  }, [langCd]);

  return {
    displayEmpNm,
  };
}

export { useDisplayEmpName };
