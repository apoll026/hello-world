import { NoticeModal } from '@/amxis/components/notice-modal';
import { useNoticePopupPostQuery } from '@/amxis/hooks/queries/notice/use-notice-popup-post-query.ts';

function NoticePopupModals() {
  // query
  const { data: noticePopupPosts } = useNoticePopupPostQuery();

  return noticePopupPosts?.map((noticePopupPost) => (
    <NoticeModal
      key={noticePopupPost.noticeNo}
      noticeCtn={noticePopupPost.noticeCtn}
      noticeNo={noticePopupPost.noticeNo}
      noticeTitNm={noticePopupPost.noticeTitle}
      poupEpsNuseDdn={Number(noticePopupPost.poupEpsNuseDdn)}
    />
  ));
}
export { NoticePopupModals };
