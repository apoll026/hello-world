function SitemapButton() {
  // not included in std system
  return null;
}

export { SitemapButton };
