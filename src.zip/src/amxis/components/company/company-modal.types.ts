export type CompanyVerifySearchCondition = {
  signValue?: string;
};
