import { Box } from '@mui/material';

type ContainerLayoutProps = {
  children: React.ReactNode;
};

function ContainerLayout({ children }: ContainerLayoutProps) {
  return (
    <Box
      sx={{
        '&.hasInnerNav': {
          padding: '0 30px 50px 0',
        },
      }}
    >
      {children}
    </Box>
  );
}

export { ContainerLayout };
