import { Box, SxProps, Typography } from '@mui/material';
import { Theme } from '@mui/system';
import { ReactNode, useEffect, useRef, useState } from 'react';
import { useTheme } from '@amxis/design-system';

// Spacer 정의
type SpacerProps = {
  type?: 'v' | 'h';
  size?: string;
};

export const Spacer = ({ type, size }: SpacerProps) => {
  let height = '0';
  let width = '0';
  let display = 'inline-block';

  switch (type) {
    case 'v':
      height = '100%';
      width = `${size}px`;
      display = 'inline-block';
      break;
    case 'h':
      width = '100%';
      height = `${size}px`;
      display = 'block';
      break;
  }

  return <div style={{ height: height, width: width, display: display }}></div>;
};

type ButtonGroupProps = {
  children?: ReactNode;
  justifyContent?:
    | 'flex-start'
    | 'center'
    | 'flex-end'
    | 'space-between'
    | 'space-around'
    | 'space-evenly';
};

export const ButtonGroup = ({ children, justifyContent = 'flex-end' }: ButtonGroupProps) => {
  return (
    <Box
      display="flex"
      justifyContent={justifyContent}
      gap="4px"
      sx={{
        width: '100%',
      }}
    >
      {children}
    </Box>
  );
};

type DialogContentContainerProps = {
  children?: ReactNode;
};

export const DialogContentContainer = ({ children }: DialogContentContainerProps) => {
  return <Box sx={{}}>{children}</Box>;
};

type DialogContentProps = {
  children?: ReactNode;
};

export const DialogContent = ({ children }: DialogContentProps) => {
  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        fontSize: '13px',
        fontFamily: 'Spoqa Han Sans Neo',
        lineHeight: '19.5px',
      }}
    >
      {children}
    </div>
  );
};

type DialogButtonGroupProps = {
  children?: ReactNode;
};

export const DialogButtonGroup = ({ children }: DialogButtonGroupProps) => {
  return (
    <>
      <Spacer type="h" size="4" />
      <div
        style={{
          display: 'flex',
          justifyContent: 'flex-end',
          gap: '4px',
          alignItems: 'center',
        }}
      >
        {children}
      </div>
    </>
  );
};

interface ContentFlexProps {
  height?: string | number;
  children?: ReactNode;
}

export const ContentFlex = ({ height = '100%', children }: ContentFlexProps) => {
  return <Box sx={{ display: 'flex', gap: '24px', height: height }}>{children}</Box>;
};

export const GridInfoSection = ({ children }) => {
  return (
    <>
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          height: '28px',
        }}
      >
        <Typography variant="h3">{children}</Typography>
      </Box>
      <Spacer type="h" size="4" />
    </>
  );
};

interface TitleContentsContainerProps {
  flexDirection?: 'column' | 'row';
  children: ReactNode;
}

export const TitleContentsContainer = ({
  flexDirection = 'column',
  children,
}: TitleContentsContainerProps) => {
  const boxRef = useRef<HTMLDivElement | null>(null);
  const [boxHeight, setBoxHeight] = useState<number>(604);
  const baseHeight = 834;

  useEffect(() => {
    if (boxRef.current) {
      const measuredHeight = boxRef.current.scrollHeight;

      // 기준 높이 계산 (100vh - 150px)
      const vh = window.innerHeight;
      const minHeight = vh - 150;

      const finalHeight = Math.max(measuredHeight, minHeight);
      setBoxHeight(finalHeight);
    }
  }, []);

  return (
    <Box
      display="flex"
      flexDirection={flexDirection}
      gap="12px"
      height={window.innerWidth <= 1210 ? 'calc(100vh - 150px)' : '100%'}
    >
      <Box
        ref={boxRef}
        display="flex"
        flexDirection={flexDirection}
        gap="12px"
        //overflow="hidden" /* 스크롤 오류수정 */
        paddingBottom={boxHeight < baseHeight ? '0' : '20px'}
        height={boxHeight > baseHeight ? '-webkit-fill-available' : boxHeight}
      >
        {children}
      </Box>
    </Box>
  );
};

interface TitleContentsProps {
  flexDirection?: 'column' | 'row';
  gap?: string | number;
  width?: string | number;
  height?: string | number;
  minHeight?: string | number;
  sx?: SxProps<Theme>;
  children: ReactNode;
}

export const TitleContents = ({
  flexDirection = 'column',
  gap = '4px',
  width,
  height,
  sx,
  children,
  minHeight,
}: TitleContentsProps) => {
  const [theme] = useTheme();

  return (
    <Box
      display="flex"
      flexDirection={flexDirection}
      gap={gap}
      padding="20px"
      borderRadius="12px"
      bgcolor={theme.palette.semantic.color.commonBgBasic}
      width={width}
      height={height}
      sx={sx}
      minHeight={minHeight}
    >
      {children}
    </Box>
  );
};

interface DialogContentsContainerProps {
  flexDirection?: 'column' | 'row';
  marginTop?: string | number;
  children: ReactNode;
}

export const DialogContentsContainer = ({
  flexDirection = 'column',
  marginTop = '4.5px',
  children,
}: DialogContentsContainerProps) => {
  return (
    <Box display="flex" flexDirection={flexDirection} gap="12px" marginTop={marginTop}>
      {children}
    </Box>
  );
};

interface DialogContentsProps {
  flexDirection?: 'column' | 'row';
  gap?: string | number;
  width?: string | number;
  // height?: string | number;
  sx?: SxProps<Theme>;
  children: ReactNode;
}

export const DialogContents = ({
  flexDirection = 'column',
  gap = '4px',
  width,
  // height,
  sx,
  children,
}: DialogContentsProps) => {
  return (
    <Box
      display="flex"
      flexDirection={flexDirection}
      gap={gap}
      width={width}
      // height={height}
      sx={sx}
    >
      {children}
    </Box>
  );
};
