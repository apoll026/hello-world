import { Box } from '@mui/system';
import { useEffect } from 'react';
import { useLocation, Outlet } from 'react-router-dom';

// PopupLayouts.tsx
function PopupLayouts() {
  const location = useLocation();

  useEffect(() => {
    // 새탭으로 열렸는지 확인 (opener가 있고 window name이 없으면)
    if (window.opener && !window.name) {
      // 새 팝업 창을 열고 현재 창은 닫기
      const popup = window.opener.open(
        window.location.href,
        'popup',
        'width=1200,height=600,scrollbars=yes,resizable=yes,location=no,menubar=no,toolbar=no'
      );

      if (popup) {
        popup.focus();
        window.close(); // 현재 새탭 닫기
      }
    }

    // 이미 팝업인 경우 크기 조정
    if (window.opener && window.name === 'popup') {
      window.resizeTo(1200, 600);
      const left = (screen.width - 1200) / 2;
      const top = (screen.height - 600) / 2;
      window.moveTo(left, top);
    }
  }, [location]);

  return (
    <Box sx={{ height: '100vh', overflowY: 'auto' }}>
      <Outlet />
    </Box>
  );
}

export { PopupLayouts };
