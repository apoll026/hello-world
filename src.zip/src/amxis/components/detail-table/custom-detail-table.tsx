import { DetailTableDataCell, DetailTableHeaderCell } from '@amxis/design-system';

export const CustomDetailTableDataCell = ({ children, sx = {}, ...rest }) => {
  return (
    <DetailTableDataCell
      {...rest}
      sx={{
        fontSize: '13px',
        fontFamily: 'Spoqa Han Sans Neo',
        lineHeight: '19.5px',
        whiteSpace: 'pre-line',
        ...sx,
      }}
    >
      {children}
    </DetailTableDataCell>
  );
};

export const CustomDetailTableHeaderCell = ({ children, sx = {}, ...rest }) => {
  return (
    <DetailTableHeaderCell
      {...rest}
      sx={{
        width: '180px',
        minWidth: '180px',
        ...sx,
      }}
    >
      {children}
    </DetailTableHeaderCell>
  );
};
