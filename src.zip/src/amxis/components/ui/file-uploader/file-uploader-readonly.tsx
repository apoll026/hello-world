import { Box, Tooltip, Typography } from '@mui/material';
import { renderFileIcon } from './file-uploader-utils.tsx';
import { $semantic, useTheme } from '@amxis/design-system';
import { filesize } from 'filesize';

type FileUploaderReadonlyProps = {
  selectedFiles: File[];
};

const FileUploaderReadonly = ({ selectedFiles }: FileUploaderReadonlyProps) => {
  const [theme] = useTheme();
  const { size2 } = $semantic.shared.size.sizesCommon;
  const { spacingSmall, spacingTiny } = $semantic.shared.spacing;

  return (
    <>
      {selectedFiles.map((file, index) => (
        <Box
          key={`${index}_${file.name}`}
          display="flex"
          gap={`${spacingTiny}px`}
          alignItems="center"
          sx={{ cursor: 'pointer' }}
          // onClick={onClick}
          py="6px"
        >
          {renderFileIcon(file.name, 20)}
          <Tooltip
            followCursor
            placement="right-start"
            title={
              <Box
                padding={`${spacingTiny}px ${spacingSmall}px`}
                bgcolor={theme.palette.semantic.color.commonBgInverse}
                borderRadius={`${size2}px`}
              >
                <Typography
                  color={theme.palette.semantic.color.commonTextInverse}
                  variant="bodySmall"
                >
                  {file.name}
                </Typography>
              </Box>
            }
          >
            <Typography
              color={theme.palette.semantic.color.commonTextSecondary}
              variant="bodyBasic"
              sx={{
                maxWidth: '80%',
                width: 'auto',
                overflow: 'hidden',
                whiteSpace: 'nowrap',
                textOverflow: 'ellipsis',
                '&:hover': {
                  textDecoration: 'underline',
                },
              }}
            >
              {file.name}
            </Typography>
          </Tooltip>
          <Typography
            color={theme.palette.semantic.color.commonTextLighter}
            variant="bodySmall"
            textTransform="uppercase"
          >
            {filesize(file.size, { round: 0, spacer: '' })}
          </Typography>
        </Box>
      ))}
    </>
  );
};

export default FileUploaderReadonly;
