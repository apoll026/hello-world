import { loadDext5Scripts } from '@/amxis/utils/loadDext5.ts';
import { Button } from '@amxis/design-system';
import { Box } from '@mui/system';
import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';
import axios from 'axios';
import { v4 as uuidv4 } from 'uuid';
import { FileInfo } from '@/amxis/models/admin/FileInfo.ts';
import { useFilesToUnuseUpdateMutation } from '@/amxis/hooks/queries/file/use-files-update-to-unuse-mutation.ts';
import { FileId } from '@/amxis/models/admin/FileId.ts';

declare const dx5: any;
type FileUploaderDext5Props = {
  initialFiles?: FileInfo[];
  initialGrId?: string;
  isTst?: boolean;
  maxFileCount?: number;
  acceptFileTypes?: string[]; // 추가
};
const FileUploaderDext5 = forwardRef<HTMLDivElement, FileUploaderDext5Props>(
  (props, ref: React.Ref<any>) => {
    const { isTst = false } = props;
    const [initialFiles, setInitialFiles] = useState<FileInfo[]>(props.initialFiles ?? []);
    const { mutateAsync: filesToUnuseUpdateMutationAsync } = useFilesToUnuseUpdateMutation();
    const atchFileGrId = useRef(props.initialGrId || uuidv4()).current;
    let fileSaveResult = '';
    let resolveUpload: (() => void) | null = null;
    const containerRef = useRef<HTMLDivElement>(null);

    const [isDx5Ready, setIsDx5Ready] = useState(false);

    const onDX5Error = (id: string, code: string, msg: string) => {
      console.error('Error occurred in Dext5:', { id, code, msg });
    };

    useEffect(() => {
      if (isDx5Ready && props.initialFiles) {
        const dx = dx5.get('dext5');
        if (dx) {
          dx.clearItems();

          // 새로운 파일들 추가
          props.initialFiles.forEach((file) => {
            dx.addVirtualFile({
              vindex: file.atchFileId,
              name: file.atchFileNm,
              size: file.atchFileSize,
            });
          });
        }
      }
    }, [isDx5Ready, props.initialFiles]);

    useEffect(() => {
      if (isDx5Ready && props.acceptFileTypes && props.acceptFileTypes.length > 0) {

        const dx = dx5.get('dext5');
        if (dx) {
          dx.clearItems();
          const extensions = props.acceptFileTypes.filter((ext) => ext !== '').join(';');

          if (extensions) {
            dx.setExtensionFilter(extensions);
          }
        }
      }
    }, [isDx5Ready, props.acceptFileTypes]);

    const onDX5Created = (id: string) => {
      const dx = dx5.get(id);
      dx.setSplitString('|');
      dx.setMaxTotalSize(1024 * 1024 * 500);
      dx.useProgressDialog(false);
      if (props.maxFileCount !== undefined) {
        dx.setMaxFileCount(props.maxFileCount);
      }

      if (props.acceptFileTypes && props.acceptFileTypes.length > 0) {
        const extensions = props.acceptFileTypes.filter((ext) => ext !== '').join(';');

        if (extensions) {
          dx.setExtensionFilter(extensions);
        }
      }

      setIsDx5Ready(true);

      dx.clearItems();

      if (initialFiles && initialFiles.length > 0) {
        initialFiles.forEach((file) => {
          dx.addVirtualFile({
            vindex: file.atchFileId,
            name: file.atchFileNm,
            size: file.atchFileSize,
          });
        });
      }
    };
    const onDX5ItemsAdded = (id: string, count: number, arr) => {
      const dx = dx5.get(id);
      arr.forEach((id) => {
        dx.setMetaDataById(id, 'name', atchFileGrId);
      });
    };
    const onDX5BeforeItemsAdd = (id: string, arr: any) => {
      if (props.maxFileCount === 1) {
        const dx = dx5.get(id);
        dx.clearItems();
      }
    };
    const onDX4UploadBegin = (id: string) => {};
    const onDX5UploadCompleted = (id: string) => {
      if (resolveUpload) {
        resolveUpload();
        resolveUpload = null;
      }
      const dx = dx5.get(id);
      fileSaveResult = dx.getResponses(0);
      dx.clearItems();
    };
    const removeCheckedItems = (id: string) => {
      const dx = dx5.get(id);
      dx.removeChecked();
    };
    const uploadFrom = async (id: string) => {
      const dx = dx5.get(id);
      const deletedVirtualFiles = dx.getRemovedFiles();
      if (deletedVirtualFiles.length > 0) {
        const deletedFilesId: FileId[] = deletedVirtualFiles.map((file) => ({
          atchFileGrId: atchFileGrId,
          atchFileId: file.vindex,
        }));
        const response = await filesToUnuseUpdateMutationAsync(deletedFilesId);
        if (!response) {
          throw new Error('failed file update');
        }
      }

      if (dx.hasUploadableItems()) {
        const headers = axios.defaults.headers.common;

        Object.keys(headers).forEach((key) => {
          const value = headers[key];
          if (value) {
            dx.setCustomHeader(key, value);
          }
        });
        dx.setUploadURL(`${process.env.API_BASE_URL}/api/v1/dextfile/upload`);
        const uploadCompletedPromise = new Promise<void>((resolve) => {
          resolveUpload = resolve;
        });
        dx.upload('AUTO');
        return {
          atchFileGrId,
          fileSaveResult,
        };
      } else {
        fileSaveResult = 'FAIL';
        return {
          atchFileGrId,
          fileSaveResult,
        };
      }
    };
    useImperativeHandle(ref, () => ({
      uploadFrom: (id) => {
        return uploadFrom(id);
      },
    }));
    useEffect(() => {
      loadDext5Scripts()
        .then(() => {
          if (dx5?.create) {
            dx5.create({
              id: 'dext5',
              parentId: 'dext5-container',
              btnFile: 'btn-add-files',
              btnFolder: 'btn-add-folder',
              events: {
                created: onDX5Created,
                error: onDX5Error,
                itemsAdded: onDX5ItemsAdded,
                beforeItemsAdd: onDX5BeforeItemsAdd,
                uploadBegin: onDX4UploadBegin,
                uploadCompleted: onDX5UploadCompleted,
              },
            });
          } else {
            console.error('dx5 is not defined');
          }
        })
        .catch(console.error);
    }, []);

    return (
      <Box>
        <div id="dext5-container" ref={containerRef} style={{ width: '100%', height: '100%' }} />

        <Box display="flex" justifyContent="flex-end">
          {isTst && <Button onClick={() => uploadFrom('dext5')}>업로드</Button>}
          {isTst && (
            <Button
              onClick={() => {
                console.log(dx5.get('dext5').getItems());
                console.log('atchFileGrId:', atchFileGrId);
                console.log('props.initialGrId:', props.initialGrId);
                console.log('initialFiles:', initialFiles);
              }}
            >
              테스트
            </Button>
          )}
          <Button
            appearance="outlined"
            priority="normal"
            size="large"
            onClick={() => removeCheckedItems('dext5')}
          >
            선택 삭제
          </Button>
        </Box>
      </Box>
    );
  }
);

export default FileUploaderDext5;
