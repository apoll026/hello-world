import { Box, BoxProps, Tooltip, Typography } from '@mui/material';

import { $semantic, useTheme } from '@amxis/design-system';
import { useState } from 'react';

import { filesize } from 'filesize';
import { Accept, useDropzone } from 'react-dropzone';
import ProgressBar from './progress-bar.tsx';
import IconBookPin from '@mui/icons-material/AttachFile';
import IconDelete from '@mui/icons-material/DeleteOutlineOutlined';

type FileUploaderNamoProps = {
  selectedFiles: File[];
  containerBoxProps?: BoxProps;
  acceptFiles: Accept;
  multiple?: boolean;
  onDropHandler: (acceptedFiles: File[]) => void;
  handleDeleteFile: (fileToDelete: File) => void;
};

const FileUploaderNamo = ({
  selectedFiles,
  containerBoxProps,
  acceptFiles,
  multiple = false,
  onDropHandler,
  handleDeleteFile,
}: FileUploaderNamoProps) => {
  const [theme] = useTheme();
  const [fileToDelete, setFileToDelete] = useState<File>();

  const { size2, size3, size5, size40, size6 } = $semantic.shared.size.sizesCommon;
  const minHeightContainerFileUploader = 110;
  const { spacingMedium, spacingSmall, spacingTiny } = $semantic.shared.spacing;

  const { getInputProps, getRootProps, open } = useDropzone({
    accept: acceptFiles,
    multiple,
    onDrop: onDropHandler,
  });

  return (
    <Box
      minHeight={`${minHeightContainerFileUploader}px`}
      width="100%"
      border={`1px solid ${theme.palette.semantic.color.commonBorderBasic}`}
      borderRadius={`${size2}px`}
      bgcolor={'inherit'}
      padding={`${spacingSmall}px`}
      {...containerBoxProps}
    >
      <Box
        width="100%"
        minHeight={`${size40}px`}
        bgcolor={theme.palette.semantic.color.commonBgBasic}
        border="none"
      >
        <Box
          display="flex"
          alignItems="center"
          justifyContent="space-between"
          // pb="5px"
          pb={`${size5}px`}
          borderBottom={`1px solid ${theme.palette.semantic.color.commonBorderBasic}`}
        >
          <Box display="flex" alignItems="center" gap={`${size2}px`}>
            <Box
              {...getRootProps()}
              component="button"
              type="button"
              display="flex"
              alignItems="center"
              gap={`${size2}px`}
              // padding="4px 6px"
              padding={`${spacingTiny}px ${size6}px`}
              sx={{
                '&:hover': {
                  cursor: 'pointer',
                },
                '&:focus': {
                  outline: 'none',
                },
              }}
              onClick={open}
              bgcolor="transparent"
              border="none"
            >
              <IconBookPin
                sx={{
                  width: 16,
                  height: 16,
                  transform: 'rotate(45deg)',
                  color: theme.palette.semantic.color.commonTextLight,
                }}
              />

              <Typography
                color={theme.palette.semantic.color.controlFilledBgInverseHover}
                variant="bodySmallBold"
              >
                추가
              </Typography>
            </Box>

            <Box
              component="button"
              type="button"
              display="flex"
              alignItems="center"
              gap={`${size2}px`}
              padding={`${spacingTiny}px ${size6}px`}
              sx={{
                '&:hover': {
                  cursor: 'pointer',
                },
              }}
              onClick={(e) => {
                e.stopPropagation();

                fileToDelete && handleDeleteFile(fileToDelete);
              }}
              bgcolor="transparent"
              border="none"
            >
              <IconDelete
                sx={{ width: 16, height: 16, color: theme.palette.semantic.color.commonTextLight }}
              />

              <Typography
                color={theme.palette.semantic.color.controlFilledBgInverseHover}
                variant="bodySmallBold"
              >
                삭제
              </Typography>
            </Box>
          </Box>

          <Box display="flex" alignItems="center" gap={`${size3}px`}>
            <Typography
              color={theme.palette.semantic.color.commonTextLighter}
              fontSize={$semantic.shared.typography.fontSizeH6}
              fontWeight={$semantic.shared.typography.fontWeightRegular}
              lineHeight={$semantic.shared.typography.lineHeightBasic}
              textTransform="uppercase"
            >
              {`${selectedFiles.length} 개의  파일 : ${
                selectedFiles.length > 0
                  ? filesize(
                      selectedFiles.reduce((total, item) => item.size + total, 0),
                      { round: 0, spacer: '' }
                    )
                  : '0.00B'
              }`}
            </Typography>
          </Box>
        </Box>

        {selectedFiles?.length > 0 &&
          selectedFiles.map((file, index) => (
            <Box
              key={file.name}
              display="flex"
              alignItems="center"
              justifyContent="space-between"
              height="28px"
              borderRadius={`${size2}px`}
              padding={`${spacingSmall}px`}
              px={`${spacingTiny}px`}
              mt={index === 0 ? `${spacingTiny}px` : `${size2}px`}
              bgcolor={
                file.name === fileToDelete?.name
                  ? theme.palette.semantic.color.commonBgDeeper
                  : theme.palette.semantic.color.commonBgBasic
              }
              sx={{
                '&:hover': {
                  cursor: 'pointer',
                  background: theme.palette.semantic.color.commonBgDeeper,
                },
              }}
              onClick={() => setFileToDelete(file)}
            >
              <Box display="flex" alignItems="center" maxWidth="80%">
                <Tooltip
                  followCursor
                  placement="right-start"
                  title={
                    <Box
                      padding={`${spacingTiny}px ${spacingSmall}px`}
                      bgcolor={theme.palette.semantic.color.commonBgInverse}
                      borderRadius={`${size2}px`}
                    >
                      <Typography
                        color={theme.palette.semantic.color.commonTextInverse}
                        variant="bodySmall"
                      >
                        {file.name}
                      </Typography>
                    </Box>
                  }
                >
                  <Typography
                    color={theme.palette.semantic.color.commonTextBasic}
                    variant="bodyBasic"
                    sx={{
                      pl: `${spacingTiny}px`,
                      width: '100%',
                      overflow: 'hidden',
                      whiteSpace: 'nowrap',
                      textOverflow: 'ellipsis',
                      ':hover': {
                        cursor: 'default',
                      },
                    }}
                  >
                    {file.name}
                  </Typography>
                </Tooltip>
              </Box>

              <Box display="flex" alignItems="center" gap={`${spacingMedium}px`}>
                <Typography
                  color={theme.palette.semantic.color.commonTextLighter}
                  variant="bodySmall"
                  textTransform="uppercase"
                >
                  {filesize(file.size, { round: 0, spacer: '' })}
                </Typography>

                <ProgressBar />
              </Box>
            </Box>
          ))}
      </Box>

      <input {...getInputProps()} hidden style={{ display: 'none' }} type="file" />
    </Box>
  );
};

export default FileUploaderNamo;
