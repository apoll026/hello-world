import { BoxProps } from '@mui/material';
import { CSSProperties, useCallback } from 'react';
import { Accept } from 'react-dropzone';
import { v4 as uuidv4 } from 'uuid';
import FileUploaderDefault from './file-uploader-default.tsx';
import FileUploaderNamo from './file-uploader-namo.tsx';
import FileUploaderReadonly from './file-uploader-readonly.tsx';
import FileUploaderThumbnail from './file-uploader-thumbnail.tsx';
import { handleAcceptFiles } from './file-uploader-utils.tsx';
import { useControllableState } from '@/amxis/hooks/use-controllable-state.ts';
import { translate } from '@/amxis/utils/i18nUtil.ts';

type FileUploaderProps = {
  containerBoxProps?: BoxProps;
  acceptFiles?: string[];
  multiple?: boolean;
  currentSize?: number;
  onFileChange?: (value: File[]) => void;
  renderFooter?: () => JSX.Element;
  placeholder?: string;
  selectedFiles?: File[];
  sxFileName?: CSSProperties;
  variant?: 'default' | 'readonly' | 'thumbnail' | 'namo';
  isRaw?: boolean;
  totalFileSizeLimit?: number;
};

export const FileUploader = ({
  containerBoxProps,
  acceptFiles = ['.pdf'],
  multiple = false,
  onFileChange,
  placeholder = String(translate('첨부할 파일을 선택하거나 여기에 drag & drop 하세요.')),
  selectedFiles: propSelectedFiles,
  variant = 'default',
  isRaw = false,
  totalFileSizeLimit,
}: FileUploaderProps) => {
  // const [selectedFiles, setSelectedFiles] = useState<File[]>(initialFiles || []);
  const [selectedFiles = [], setSelectedFiles] = useControllableState<File[]>({
    prop: propSelectedFiles,
    onChange: onFileChange,
    defaultProp: [],
  });
  const atchFileGrId = uuidv4();

  let mimeTypeAccept: Accept;
  if (acceptFiles && acceptFiles.length > 0) {
    mimeTypeAccept = handleAcceptFiles(acceptFiles);
  }

  const onDropHandler = useCallback(
    (acceptedFiles: File[]) => {
      setSelectedFiles((prev) => {
        if (onFileChange) {
          onFileChange([...acceptedFiles]);
        }
        return [...(prev ?? []), ...acceptedFiles];
      });
    },
    [atchFileGrId]
  );

  const handleDeleteFile = (fileToDelete: File) => {
    setSelectedFiles((prev) => prev?.filter((file) => file !== fileToDelete));
  };

  // useEffect(() => {
  //   if (onFileChange) {
  //     onFileChange(selectedFiles);
  //   }
  // }, [selectedFiles]);

  const renderDefault = () => {
    return (
      <FileUploaderDefault
        acceptFiles={mimeTypeAccept}
        handleDeleteFile={handleDeleteFile}
        onDropHandler={onDropHandler}
        selectedFiles={selectedFiles}
        containerBoxProps={containerBoxProps}
        multiple={multiple}
        placeholder={placeholder}
        totalFileSizeLimit={totalFileSizeLimit}
      />
    );
  };

  const renderReadonly = () => {
    return <FileUploaderReadonly selectedFiles={selectedFiles} />;
  };

  const renderThumbnail = () => {
    return (
      <FileUploaderThumbnail
        acceptFiles={mimeTypeAccept}
        handleDeleteFile={handleDeleteFile}
        onDropHandler={onDropHandler}
        selectedFiles={selectedFiles}
        containerBoxProps={containerBoxProps}
        multiple={multiple}
        placeholder={placeholder}
        isRaw={isRaw}
      />
    );
  };

  const renderNamo = () => {
    return (
      <FileUploaderNamo
        acceptFiles={mimeTypeAccept}
        handleDeleteFile={handleDeleteFile}
        onDropHandler={onDropHandler}
        selectedFiles={selectedFiles}
        containerBoxProps={containerBoxProps}
        multiple={multiple}
      />
    );
  };

  const renderFileUploader = {
    default: renderDefault,
    readonly: renderReadonly,
    thumbnail: renderThumbnail,
    namo: renderNamo,
  };

  return renderFileUploader[variant]();
};
