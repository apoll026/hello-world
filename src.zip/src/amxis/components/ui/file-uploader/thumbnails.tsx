import { $semantic, useTheme } from '@amxis/design-system';
import { Box, SxProps, Theme, Typography } from '@mui/material';
import { filesize } from 'filesize';
import { renderFileIcon } from './file-uploader-utils.tsx';
import IconMisUse from '@mui/icons-material/Cancel';

type ThumbnailProps = {
  deletable?: boolean;
  selectedFiles: File[];
  handleDeleteFile?: (fileToDelete: File) => void;
};

const Thumbnails = ({ deletable = true, selectedFiles, handleDeleteFile }: ThumbnailProps) => {
  const [theme] = useTheme();
  const { size2 } = $semantic.shared.size.sizesCommon;
  const widthSmallFileUploader = 144;
  const heightSmallFileUploader = 96;
  const heightMediumFileUploader = 100;
  const { spacingMedium, spacingSmall, spacingTiny } = $semantic.shared.spacing;

  const styleThumbnail: SxProps<Theme> = {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: `${widthSmallFileUploader}px`,
    maxWidth: '25%',
    height: `${heightSmallFileUploader}px`,
    borderRadius: `${spacingTiny}px`,
    position: 'relative',
    border: `1px solid ${theme.palette.semantic.color.commonBorderBasic}`,
    backgroundRepeat: 'no-repeat',
    backgroundSize: '100% 100%',
    ':hover': {
      border: `1px solid ${theme.palette.semantic.color.commonBorderStronger}`,
      backgroundRepeat: 'no-repeat',
      backgroundSize: '100% 100%',

      '.thunmbnail-delete': {
        color: theme.palette.semantic.color.commonTextBasic,
      },

      '.layout, .info': {
        visibility: 'visible',
      },
    },

    '.thunmbnail-delete': {
      color: theme.palette.semantic.color.commonTextLighter,
    },
  };

  return (
    <Box display="flex" gap={`${spacingTiny}px`} flexWrap="wrap" mt={`${spacingTiny}px`}>
      {selectedFiles.map((file, index) => (
        <Box
          key={`${index}-${file.name}`}
          sx={{
            mt: `${spacingTiny}px`,
            background: ['png', 'jpg', 'jpeg', 'bmp', 'gif'].some(
              (ext) => file.name.indexOf(ext) > -1
            )
              ? `url('${URL.createObjectURL(file)}')`
              : theme.palette.semantic.color.commonBgDeep, //

            '.icon': {
              path: {
                fill: theme.palette.semantic.color.commonTextLighter,
              },
            },

            '&:hover': {
              background: ['png', 'jpg', 'jpeg', 'bmp', 'gif'].some(
                (ext) => file.name.indexOf(ext) > -1
              )
                ? `url('${URL.createObjectURL(file)}'), ${
                    theme.palette.semantic.color.commonBgStronger
                  }`
                : theme.palette.semantic.color.commonBgStronger, //
            },
            ...styleThumbnail,
          }}
        >
          <>
            <Box
              className="layout"
              position="absolute"
              top="0"
              left="0"
              bottom="0"
              right="0"
              bgcolor={theme.palette.semantic.color.commonBgDim}
              sx={{
                opacity: 0.5,
                visibility: 'hidden',
              }}
              zIndex={9}
            ></Box>
            <Box
              position="absolute"
              left={`${spacingSmall}px`}
              bottom={`${spacingTiny}px`}
              display="flex"
              flexDirection="column"
              gap={`${spacingTiny}px`}
              justifyContent="flex-start"
              className="info"
              visibility="hidden"
              zIndex={9999}
            >
              <Typography
                color={theme.palette.semantic.color.commonTextBright}
                variant="bodyXsmall"
                textAlign="start"
                textTransform="uppercase"
              >
                {filesize(file.size, { round: 0, spacer: '' })}
              </Typography>
              <Box display="flex">
                <Typography
                  color={theme.palette.semantic.color.commonTextInverse}
                  variant="bodySmall"
                  textAlign="start"
                  sx={{
                    width: `${heightMediumFileUploader}px`,
                    whiteSpace: 'nowrap',
                    textOverflow: 'ellipsis',
                    overflow: 'hidden',
                  }}
                >
                  {file.name.split('.')[0]}
                </Typography>
                <Typography
                  color={theme.palette.semantic.color.commonTextInverse}
                  variant="bodySmall"
                  textAlign="start"
                  sx={{
                    whiteSpace: 'nowrap',
                    textOverflow: 'ellipsis',
                    overflow: 'hidden',
                  }}
                >
                  {file.name.split('.')[file.name.split('.').length - 1]}
                </Typography>
              </Box>
            </Box>
          </>

          {!['png', 'jpg', 'jpeg', 'bmp', 'gif'].some((ext) => file.name.indexOf(ext) > -1) ? (
            <Box className="icon">{renderFileIcon(file.name, 32)}</Box>
          ) : (
            <></>
          )}
          <Box
            position="absolute"
            top={`${size2}px`}
            right={`${size2}px`}
            borderRadius="50%"
            width={`${spacingMedium}px`}
            height={`${spacingMedium}px`}
            bgcolor={theme.palette.semantic.color.commonBgBasic}
            display={deletable ? 'flex' : 'none'}
            justifyContent="center"
            alignItems="center"
            zIndex={9}
          >
            <IconMisUse
              className="thunmbnail-delete"
              onClick={(e) => {
                e.stopPropagation();
                handleDeleteFile?.(file);
              }}
            />
          </Box>
        </Box>
      ))}
    </Box>
  );
};

export default Thumbnails;
