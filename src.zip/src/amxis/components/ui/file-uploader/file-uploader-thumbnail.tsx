import { Box, BoxProps, Typography } from '@mui/material';
import { $semantic, useTheme } from '@amxis/design-system';
import { filesize } from 'filesize';
import { Accept, useDropzone } from 'react-dropzone';
import Thumbnails from './thumbnails.tsx';
import IconBookPin from '@mui/icons-material/AttachFile';

type FileUploaderThumbnailProps = {
  selectedFiles: File[];
  containerBoxProps?: BoxProps;
  acceptFiles: Accept;
  multiple?: boolean;
  onDropHandler: (acceptedFiles: File[]) => void;
  placeholder?: string;
  handleDeleteFile: (fileToDelete: File) => void;
  isRaw?: boolean;
};

const FileUploaderThumbnail = ({
  selectedFiles,
  acceptFiles,
  multiple = false,
  onDropHandler,
  containerBoxProps,
  placeholder,
  handleDeleteFile,
  isRaw = false,
}: FileUploaderThumbnailProps) => {
  const [theme] = useTheme();

  const { getInputProps, getRootProps, open } = useDropzone({
    accept: acceptFiles,
    multiple,
    onDrop: onDropHandler,
  });

  const { size2, size3, size20, size40 } = $semantic.shared.size.sizesCommon;
  const maxWidthContainerFileUploader = 768;
  const { spacingSmall } = $semantic.shared.spacing;

  return (
    <>
      {isRaw ? (
        <Box
          {...getRootProps()}
          className="thumbnail-container-raw"
          width="100%"
          sx={{
            '&:hover': {
              cursor: 'pointer',
            },
            '&:focus': {
              outline: 'none',
            },
          }}
          {...{ containerBoxProps }}
        >
          <IconBookPin width={size20} height={size20} />
          <input {...getInputProps()} hidden style={{ display: 'none' }} type="file" />
        </Box>
      ) : (
        <Box
          minHeight={`${size40}px`}
          maxWidth={`${maxWidthContainerFileUploader}px`}
          width="100%"
          border={`1px dashed ${theme.palette.semantic.color.commonBorderStrong}`}
          borderRadius={`${size2}px`}
          bgcolor={
            selectedFiles.length > 0 ? theme.palette.semantic.color.commonBgDeeper : 'inherit'
          }
          sx={{
            '&:active': {
              border: `1px solid ${theme.palette.semantic.color.commonBorderBasic}`,
            },
          }}
          {...{ containerBoxProps }}
        >
          <Box
            {...getRootProps()}
            component="button"
            width="100%"
            minHeight={`${size40}px`}
            bgcolor={theme.palette.semantic.color.commonBgBasic}
            border="none"
            onClick={open}
            padding={`${spacingSmall}px`}
            sx={{
              '&:hover': {
                backgroundColor: theme.palette.semantic.color.commonBgDeeper,
                cursor: 'pointer',
              },
              '&:focus': {
                outline: `1px solid ${theme.palette.semantic.color.controlLinedBorderBasicActive}`,
              },
            }}
          >
            <Box display="flex" alignItems="center" justifyContent="space-between">
              <Box display="flex" alignItems="center" gap="3px">
                <IconBookPin />

                <Typography
                  color={theme.palette.semantic.color.commonTextLighter}
                  variant="body1"
                  sx={{
                    '&:hover': {
                      cursor: 'default',
                    },
                  }}
                >
                  {placeholder}
                </Typography>
              </Box>

              <Box display="flex" alignItems="center" gap={`${size3}px`}>
                <Typography
                  color={theme.palette.semantic.color.commonTextBasic}
                  variant="body1"
                  textTransform="uppercase"
                >
                  {selectedFiles.length > 0
                    ? filesize(
                        selectedFiles.reduce((total, item) => item.size + total, 0),
                        { round: 0, spacer: '' }
                      )
                    : '0 KB'}
                </Typography>

                <Typography
                  color={theme.palette.semantic.color.commonTextLighter}
                  variant="body1"
                  textTransform="uppercase"
                >
                  {' / '}
                  {filesize(10000000, { round: 0, spacer: '' })}
                </Typography>
              </Box>
            </Box>
            {selectedFiles?.length > 0 && (
              <Thumbnails selectedFiles={selectedFiles} handleDeleteFile={handleDeleteFile} />
            )}
          </Box>

          <input {...getInputProps()} hidden style={{ display: 'none' }} type="file" />
        </Box>
      )}
    </>
  );
};

export default FileUploaderThumbnail;
