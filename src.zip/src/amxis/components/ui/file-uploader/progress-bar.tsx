import { $semantic, useTheme } from '@amxis/design-system';
import { Box, LinearProgress, Typography } from '@mui/material';
import { useEffect, useState } from 'react';

const ProgressBar = () => {
  const [theme] = useTheme();
  const [progress, setProgress] = useState(0);
  const { size20, size72 } = $semantic.shared.size.sizesCommon;

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((oldProgress) => {
        if (oldProgress === 100) {
          clearInterval(timer);
          return 100;
        }
        const diff = Math.random() * 10;
        return Math.min(oldProgress + diff, 100);
      });
    }, 150);

    return () => {
      clearInterval(timer);
    };
  }, []);

  return (
    <Box
      display="flex"
      justifyContent="center"
      alignItems="center"
      width={`${size72}px`}
      height={`${size20}px`}
      bgcolor={theme.palette.semantic.color.commonBgStronger}
      position="relative"
    >
      {progress >= 1 ? (
        <></>
      ) : (
        <Typography
          color={theme.palette.semantic.color.commonTextLighter}
          variant="bodySmall"
          zIndex={9999}
        >
          대기
        </Typography>
      )}

      {progress === 100 && (
        <Typography
          color={theme.palette.semantic.color.controlLinedBgBasic}
          variant="bodySmall"
          zIndex={9999}
        >
          완료
        </Typography>
      )}

      <LinearProgress
        variant="determinate"
        value={progress}
        sx={{
          position: 'absolute',
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
          width: '100%',
          height: '100%',
          background: theme.palette.semantic.color.commonBgStronger,

          '.MuiLinearProgress-bar, .MuiLinearProgress-barColorPrimary, .MuiLinearProgress-bar1Indeterminate':
            {
              backgroundColor: theme.palette.semantic.color.controlFilledBgPrimaryHover,
            },
        }}
      />
    </Box>
  );
};

export default ProgressBar;
