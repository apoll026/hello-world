import {
  FileDocument2LinedSvg as IconDocument,
  FileExcelLinedSvg as IconExcel,
  FileImgLinedSvg as IconImage,
  FileMarkdownLinedSvg as IconMarkDown,
  FilePptLinedSvg as IconPowerPoint,
  FileWordLinedSvg as IconWord,
  FileZipLinedSvg as IconZip,
  FilePdfLinedSvg as PdfIcon,
} from '@amxis/design-system/icon';
import { Accept } from 'react-dropzone';

type FileIcons = {
  [key: string]: JSX.Element;
};

export const renderFileIcon = (fileName: string, size?: number) => {
  const fileIcons: FileIcons = {
    pdf: <PdfIcon width={size ?? 16} height={size ?? 16} />,
    xls: <IconExcel width={size ?? 16} height={size ?? 16} />,
    xlsx: <IconExcel width={size ?? 16} height={size ?? 16} />,
    doc: <IconWord width={size ?? 16} height={size ?? 16} />,
    docx: <IconWord width={size ?? 16} height={size ?? 16} />,
    png: <IconImage width={size ?? 16} height={size ?? 16} />,
    jpg: <IconImage width={size ?? 16} height={size ?? 16} />,
    jpeg: <IconImage width={size ?? 16} height={size ?? 16} />,
    bmp: <IconImage width={size ?? 16} height={size ?? 16} />,
    gif: <IconImage width={size ?? 16} height={size ?? 16} />,
    zip: <IconZip width={size ?? 16} height={size ?? 16} />,
    ppt: <IconPowerPoint width={size ?? 16} height={size ?? 16} />,
    pptx: <IconPowerPoint width={size ?? 16} height={size ?? 16} />,
    html: <IconMarkDown width={size ?? 16} height={size ?? 16} />,
    js: <IconMarkDown width={size ?? 16} height={size ?? 16} />,
  };

  const extension = Object.keys(fileIcons).find((ext) => fileName.endsWith(`.${ext}`));

  const IconComponent = extension ? fileIcons[extension] : <IconDocument />;

  return IconComponent;
};

const MIME_TYPES_SUPPORT: Accept = {
  'image/*': ['.png', '.jpg', '.bmp', '.gif'],
  'application/msword': ['.doc'],
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
  'application/pdf': ['.pdf'],
  'text/plain': ['.txt'],
  'application/vnd.ms-excel': ['.xls'],
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
  'application/zip': ['.zip'],
  'text/html': ['.html'],
  'text/javascript': ['.js'],
  'application/vnd.openxmlformats-officedocument.presentationml.presentation': ['.pptx'],
  'application/vnd.ms-powerpoint': ['.ppt'],
};
const ALL_MIME_TYPES = Object.values(MIME_TYPES_SUPPORT).flatMap((value) => value);

export const handleAcceptFiles = (listFileAccecpt: string[]) => {
  const accectFiles: Accept = {};
  listFileAccecpt.map((extension: string) => {
    const mimeType = Object.keys(MIME_TYPES_SUPPORT).find((type) =>
      MIME_TYPES_SUPPORT[type].includes(extension)
    );
    if (mimeType) {
      const newMimeTypes = accectFiles[mimeType]
        ? accectFiles[mimeType].concat([extension])
        : [extension];
      accectFiles[mimeType] = [...newMimeTypes];
    }
  });

  return accectFiles;
};

export const getAllAcceptFiles = () => {
  return handleAcceptFiles(ALL_MIME_TYPES);
};
