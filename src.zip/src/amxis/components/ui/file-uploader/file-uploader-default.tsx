import { Box, BoxProps, Tooltip, Typography } from '@mui/material';
import { renderFileIcon } from './file-uploader-utils.tsx';
import { Accept, useDropzone } from 'react-dropzone';

import { $semantic, useTheme } from '@amxis/design-system';
import { filesize } from 'filesize';
import IconBookPin from '@mui/icons-material/AttachFile';
import IconMisUse from '@mui/icons-material/Cancel';

type FileUploaderDefaultProps = {
  selectedFiles: File[];
  containerBoxProps?: BoxProps;
  acceptFiles: Accept;
  multiple?: boolean;
  onDropHandler: (acceptedFiles: File[]) => void;
  placeholder?: string;
  handleDeleteFile: (fileToDelete: File) => void;
  totalFileSizeLimit?: number;
};

const FileUploaderDefault = ({
  selectedFiles,
  containerBoxProps,
  acceptFiles,
  multiple = false,
  onDropHandler,
  placeholder,
  handleDeleteFile,
  totalFileSizeLimit = 500,
}: FileUploaderDefaultProps) => {
  const [theme] = useTheme();
  const { getInputProps, getRootProps, open } = useDropzone({
    accept: acceptFiles,
    multiple,
    onDrop: onDropHandler,
  });

  const { size2, size3, size4, size36, size40 } = $semantic.shared.size.sizesCommon;
  const { spacingSmall, spacingTiny } = $semantic.shared.spacing;

  return (
    <Box
      minHeight={`${size40}px`}
      width="100%"
      border={`1px dashed ${theme.palette.semantic.color.commonBorderStrong}`}
      borderRadius={`${size2}px`}
      bgcolor={selectedFiles.length > 0 ? theme.palette.semantic.color.commonBgDeeper : 'inherit'}
      sx={{
        '&:focus': {
          border: `1px solid ${theme.palette.semantic.color.controlLinedBorderBasicActive}`,
          borderRadius: `${size2}px`,
          outline: 'none',
        },
      }}
      {...containerBoxProps}
    >
      <Box
        {...getRootProps()}
        component="button"
        type="button"
        width="100%"
        minHeight={`${size40}px`}
        bgcolor={theme.palette.semantic.color.commonBgBasic}
        border="none"
        onClick={open}
        padding={`${spacingSmall}px`}
        sx={{
          '&:hover': {
            backgroundColor: theme.palette.semantic.color.commonBgDeeper,
            cursor: 'pointer',
          },
          '&:focus': {
            outline: `1px solid ${theme.palette.semantic.color.controlLinedBorderBasicActive}`,
            borderRadius: `${size2}px`,
          },
        }}
      >
        <Box display="flex" alignItems="center" justifyContent="space-between">
          <Box display="flex" alignItems="center" gap={`${size3}px`}>
            <IconBookPin
              sx={{
                width: '24px',
                height: '24px',
                transform: 'rotate(45deg)',
                color: theme.palette.semantic.color.commonTextLight,
              }}
            />

            <Typography
              color={theme.palette.semantic.color.commonTextLighter}
              variant="body1"
              sx={{
                '&:hover': {
                  cursor: 'default',
                },
              }}
            >
              {placeholder}
            </Typography>
          </Box>

          <Box display="flex" alignItems="center" gap={`${size3}px`}>
            <Typography
              color={theme.palette.semantic.color.commonTextBasic}
              variant="body1"
              textTransform="uppercase"
            >
              {selectedFiles.length > 0
                ? filesize(
                    selectedFiles.reduce((total, item) => item.size + total, 0),
                    { round: 0, spacer: '' }
                  )
                : '0 KB'}
            </Typography>

            <Typography
              color={theme.palette.semantic.color.commonTextLight}
              variant="body1"
              textTransform="uppercase"
            >
              {' / '}
              {filesize(totalFileSizeLimit * 1000000, { round: 0, spacer: '' })}
            </Typography>
          </Box>
        </Box>

        {selectedFiles?.length > 0 &&
          selectedFiles.map((file, index) => (
            <Box
              key={`${index}-${file.name}`}
              display="flex"
              alignItems="center"
              justifyContent="space-between"
              height={`${size36}px`}
              border={`1px solid ${theme.palette.semantic.color.commonBorderBasic}`}
              borderRadius={`${size2}px`}
              padding={`${spacingSmall}px`}
              mt={index === 0 ? `${size4}px` : `${size2}px`}
              bgcolor={theme.palette.semantic.color.commonBgBasic}
              sx={{
                ':hover': {
                  background: theme.palette.semantic.color.commonBgBasic,
                },
              }}
            >
              <Box display="flex" alignItems="center" maxWidth="90%">
                {renderFileIcon(file.name)}

                <Tooltip
                  followCursor
                  placement="right-start"
                  title={
                    <Box
                      padding={`${spacingTiny}px ${spacingSmall}px`}
                      bgcolor={theme.palette.semantic.color.commonBgInverse}
                      borderRadius={`${size2}px`}
                    >
                      <Typography
                        color={theme.palette.semantic.color.commonTextInverse}
                        variant="bodySmall"
                      >
                        {file.name}
                      </Typography>
                    </Box>
                  }
                >
                  <Typography
                    color={theme.palette.semantic.color.commonTextBasic}
                    variant="bodyBasic"
                    sx={{
                      pl: `${spacingTiny}px`,
                      width: '100%',
                      overflow: 'hidden',
                      whiteSpace: 'nowrap',
                      textOverflow: 'ellipsis',
                      ':hover': {
                        cursor: 'default',
                      },
                    }}
                  >
                    {file.name}
                  </Typography>
                </Tooltip>
              </Box>

              <Box display="flex" alignItems="center">
                <Typography
                  color={theme.palette.semantic.color.commonTextLighter}
                  variant="bodySmall"
                  textTransform="uppercase"
                  sx={{ pr: `${spacingTiny}px` }}
                >
                  {filesize(file.size, { round: 0, spacer: '' })}
                </Typography>

                <Box
                  sx={{
                    m: 0,
                    p: 0,
                    outline: 'none',
                    border: 'none',
                    borderRadius: '50%',
                    bgcolor: 'transparent',
                    cursor: 'pointer',
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    color: theme.palette.semantic.color.commonTextLighter,
                    width: '16px',
                    height: '16px',
                  }}
                  onClick={(e) => {
                    e.stopPropagation();

                    handleDeleteFile(file);
                  }}
                >
                  <IconMisUse sx={{ width: '100%', height: '100%' }} />
                </Box>
              </Box>
            </Box>
          ))}
      </Box>

      <input {...getInputProps()} hidden style={{ display: 'none' }} type="file" />
    </Box>
  );
};

export default FileUploaderDefault;
