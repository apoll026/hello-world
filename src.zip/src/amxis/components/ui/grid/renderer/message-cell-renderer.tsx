import { useCallback } from 'react';
import { ICellRendererParams } from 'ag-grid-community';

import { useMessageModalStore } from '@/amxis/stores/useMessageModalStore.ts';

export interface IMessageCellRendererParams extends ICellRendererParams {
  showButton?: (() => boolean) | boolean;
  noCallback?: () => void;
  yesCallback?: (item?: string[]) => void;
  msgCtn?: string;
  koMessage?: string;
}

export const MessageCellRenderer = ({
  noCallback,
  yesCallback,
  msgCtn,
  koMessage,
  ...params
}: IMessageCellRendererParams) => {
  const { setMessageModalStateWhenModalOpen } = useMessageModalStore();
  const cellValue = params.valueFormatted ? params.valueFormatted : params.value;

  const handleButtonClick = useCallback(() => {
    setMessageModalStateWhenModalOpen(
      msgCtn ?? cellValue,
      koMessage ?? '',
      yesCallback,
      noCallback
    );
  }, [cellValue, yesCallback, noCallback]);

  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
      }}
    >
      <div
        style={{
          display: 'inline-block',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
        }}
      >
        <a
          onClick={handleButtonClick}
          style={{
            textDecoration: 'underline',
            cursor: 'pointer',
          }}
        >
          {cellValue}
        </a>
      </div>
    </div>
  );
};
