export type TreeData = {
  id: string;
  deptNm: string;
  checked?: boolean;
  childrens?: TreeData[];
};

export type MenuNode = {
  MNU_ID: string;
  MNU_NM: string;
  MNU_LV_NO: number;
  UPPR_MNU_ID: string | null;
  SORT_ORD: number;
  USE_YN: 'Y' | 'N';
};

export type MenuTree = {
  tree: MenuNode[];
};

export enum TreeType {
  TRIANGLE,
  MENU,
  PLUS_MINUS,
}
