import React, { useEffect, useState } from 'react';
import { Box, Typography, useTheme } from '@mui/material';
import { Checkbox } from '@amxis/design-system';
import { TreeData, TreeType } from './utils.ts';
// import { ChevronIcon, ControlAddIcon, ControlSubtractIcon } from '@/components/icon';
import {
  ChevronRight as ChevronIcon,
  Add as ControlAddIcon,
  Remove as ControlSubtractIcon,
} from '@mui/icons-material';
import { $semantic } from '@amxis/design-system';

type TreeNodeProps = {
  id: string;
  depth: number;
  value: boolean;
  deptNm: string;
  checked: boolean;
  selected: string;
  childrens: TreeData[];
  hasCheckbox: boolean;
  dynamicWidth: number;
  variant?: TreeType;
  onCheck: (label: string, checked: boolean) => void;
  onClick: (item: string) => void;
};

const TreeNode: React.FC<TreeNodeProps> = ({
  id,
  depth,
  value,
  deptNm,
  variant = TreeType.TRIANGLE,
  checked,
  selected,
  childrens,
  hasCheckbox,
  dynamicWidth,
  onCheck,
  onClick,
}) => {
  const { palette } = useTheme();
  const [expanded, setExpanded] = useState<boolean>(false);
  const [backgroundColor, setBackgroundColor] = useState<string>(
    palette.semantic.color.tableBgCellSelected
  );
  const [borderColor, setBorderColor] = useState<string>(
    palette.semantic.color.commonBorderSecondary
  );

  useEffect(() => {
    if (TreeType[variant] !== TreeType[TreeType.MENU]) {
      setBackgroundColor(palette.semantic.color.tableBgCellSelected);
      setBorderColor(palette.semantic.color.commonBorderSecondary);
    } else {
      setBackgroundColor(palette.semantic.color.commonBgDeep);
      setBorderColor('transparent');
    }
  }, [
    variant,
    palette.semantic.color.tableBgCellSelected,
    palette.semantic.color.commonBorderSecondary,
    palette.semantic.color.commonBgDeep,
  ]);

  const handleCheckChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onCheck(id, e.target.checked);
  };

  const handleToggle = (e: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
    if ((e.target as Element).nodeName.toLowerCase() !== 'input') {
      e.stopPropagation();
      // TODO: logic for node clicking is here
      onClick(deptNm);
      if (childrens) {
        setExpanded(!expanded);
      }
    }
  };

  const renderChevron = () => {
    switch (TreeType[variant]) {
      case TreeType[TreeType.PLUS_MINUS]:
        return (
          <Box display="flex" alignItems="center" justifyContent="center">
            {expanded ? (
              <ControlSubtractIcon
                width={'100%'}
                height={'100%'}
                sx={{ width: '100%', height: '100%' }}
              />
            ) : (
              <ControlAddIcon
                width={'100%'}
                height={'100%'}
                sx={{ width: '100%', height: '100%' }}
              />
            )}
          </Box>
        );

      case TreeType[TreeType.MENU]:
        return (
          <Box
            display="flex"
            alignItems="center"
            justifyContent="center"
            sx={{ transform: !expanded ? 'rotate(-90deg)' : 'rotate(0)' }}
          >
            <ChevronIcon width={'100%'} height={'100%'} sx={{ width: '100%', height: '100%' }} />
          </Box>
        );

      // case TreeType[TreeType.TRIANGLE]:
      default:
        return (
          <Box
            display="flex"
            alignItems="center"
            justifyContent="center"
            sx={{ transform: !expanded ? 'rotate(-90deg)' : 'rotate(0)' }}
          >
            <ChevronIcon width={'100%'} height={'100%'} sx={{ width: '100%', height: '100%' }} />
          </Box>
        );
    }
  };

  const renderChildrenNode = () => {
    if (expanded && childrens) {
      return childrens.map((node) => (
        <TreeNode
          childrens={node.childrens ?? []}
          id={node.id}
          deptNm={node.deptNm}
          checked={Boolean(node.checked)}
          depth={depth + 1}
          key={node.id}
          hasCheckbox={hasCheckbox}
          selected={selected}
          dynamicWidth={dynamicWidth}
          variant={variant}
          value={value}
          onCheck={onCheck}
          onClick={onClick}
        />
      ));
    }
    return null;
  };

  const getInitialBorderColor = () => {
    return selected === deptNm ? borderColor : ' none';
  };

  return (
    <Box
      className="tree-node"
      width={`${dynamicWidth}px`}
      sx={{
        cursor: 'pointer',
        whiteSpace: 'nowrap',
      }}
      onClick={handleToggle}
    >
      <Box
        borderLeft={
          TreeType[variant] === TreeType[TreeType.MENU]
            ? 'none'
            : `${$semantic.shared.size.sizesCommon.size4}px solid ${palette.semantic.color.commonBorderInverse}`
        }
        sx={{
          paddingY: `${$semantic.shared.size.sizesCommon.size4}px`,
          backgroundColor:
            selected === deptNm
              ? TreeType[variant] === TreeType[TreeType.MENU]
                ? palette.semantic.color.navLeftBgLastChildSelected
                : backgroundColor
              : 'initial',
          borderColor: getInitialBorderColor(),
          '& > .MuiBox-root > .MuiBox-root': {
            color:
              TreeType[variant] === TreeType[TreeType.MENU]
                ? palette.semantic.color.navLeftTextSelected
                : palette.semantic.color.commonTextBasic,
          },
          '&:hover': {
            '& > .MuiBox-root > .MuiTypography-root': {
              color:
                TreeType[variant] === TreeType[TreeType.MENU]
                  ? palette.semantic.color.commonTextInverse
                  : palette.semantic.color.commonTextBasic,
            },
            '& > .MuiBox-root > .MuiBox-root': {
              color:
                TreeType[variant] === TreeType[TreeType.MENU]
                  ? palette.semantic.color.commonTextInverse
                  : palette.semantic.color.commonTextBasic,
            },
            backgroundColor:
              TreeType[variant] === TreeType[TreeType.MENU]
                ? palette.semantic.color.navLeftBgLastChildSelected
                : backgroundColor,
            borderColor:
              TreeType[variant] === TreeType[TreeType.MENU]
                ? ''
                : selected === deptNm
                ? borderColor
                : backgroundColor,
          },
          display: 'flex',
          justifyContent: 'space-between',
        }}
      >
        <Box
          display="flex"
          alignItems="center"
          height={`${$semantic.shared.size.sizesCommon.size100}%`}
          gap={`${$semantic.shared.size.sizesCommon.size2}px`}
        >
          <Box
            width={`${
              depth * $semantic.shared.size.sizesCommon.size18 +
              $semantic.shared.size.sizesCommon.size8
            }px`}
          >
            {' '}
          </Box>
          <Box
            height={`${
              TreeType[variant] === TreeType[TreeType.PLUS_MINUS]
                ? $semantic.shared.size.sizesCommon.size12
                : $semantic.shared.size.sizesCommon.size16
            }px`}
            width={`${
              TreeType[variant] === TreeType[TreeType.PLUS_MINUS]
                ? $semantic.shared.size.sizesCommon.size12
                : $semantic.shared.size.sizesCommon.size16
            }px`}
            display="flex"
            alignItems="center"
            justifyContent="center"
          >
            {childrens && childrens?.length > 0 && renderChevron()}
          </Box>
          {hasCheckbox ? (
            <Checkbox
              checked={checked}
              size="small"
              color={TreeType[variant] === TreeType[TreeType.MENU] ? 'primary' : 'secondary'}
              sx={{
                padding: '0',
              }}
              onChange={handleCheckChange}
            />
          ) : null}
          <Typography
            variant="body2"
            color={
              selected === deptNm
                ? TreeType[variant] === TreeType[TreeType.MENU]
                  ? palette.semantic.color.commonTextInverse
                  : palette.semantic.color.commonTextBasic
                : TreeType[variant] === TreeType[TreeType.MENU]
                ? palette.semantic.color.navLeftTextSelected
                : palette.semantic.color.commonTextBasic
            }
            sx={{
              fontSize: $semantic.shared.typography.fontSizeBasic,
              lineHeight: $semantic.shared.typography.lineHeightBasic,
            }}
          >
            {deptNm}
          </Typography>
        </Box>
        {value && (
          <Typography
            variant="body2"
            color={
              selected === deptNm
                ? TreeType[variant] === TreeType[TreeType.MENU]
                  ? palette.semantic.color.commonTextInverse
                  : palette.semantic.color.commonTextBasic
                : TreeType[variant] === TreeType[TreeType.MENU]
                ? palette.semantic.color.navLeftTextSelected
                : palette.semantic.color.commonTextBasic
            }
            sx={{
              fontSize: $semantic.shared.typography.fontSizeBasic,
              lineHeight: $semantic.shared.typography.lineHeightBasic,
            }}
          >
            {childrens?.length}
          </Typography>
        )}
      </Box>
      {renderChildrenNode()}
    </Box>
  );
};

export default TreeNode;
