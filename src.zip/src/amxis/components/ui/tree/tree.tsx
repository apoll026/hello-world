import { Box, SxProps, Theme, useTheme } from '@mui/material';
import { useEffect, useState, useRef } from 'react';
import TreeNode from './node.tsx';
import { TreeData, TreeType } from './utils.ts';
import { $semantic } from '@amxis/design-system';

const handleCheckInChildren = (
  children: TreeData[] | undefined,
  checked: boolean
): TreeData[] | undefined => {
  return children?.map((child) => ({
    ...child,
    checked,
    childrens: handleCheckInChildren(child.childrens, checked),
  }));
};

const updateTreeData = (
  data: TreeData[],
  id: string,
  checked: boolean,
  checkChildren: boolean
): TreeData[] => {
  return data.map((node) => {
    if (node.id === id) {
      return {
        ...node,
        checked,
        childrens: checkChildren ? handleCheckInChildren(node.childrens, checked) : node.childrens,
      };
    } else if (node.childrens) {
      // Recursively update the children nodes
      return {
        ...node,
        childrens: updateTreeData(node.childrens, id, checked, checkChildren),
      };
    }
    return node;
  });
};

type Props = {
  data: TreeData[];
  hasCheckBox?: boolean;
  sx?: SxProps<Theme>;
  selectedNode: string;
  variant?: TreeType;
  value?: boolean;
  onClick: (item: string) => void;
  onChange?: (id: string, checked: boolean) => void;
};

const TreeViewComponent = ({
  data,
  hasCheckBox = false,
  sx,
  selectedNode = '',
  onClick,
  onChange,
  variant = TreeType.TRIANGLE,
  value = false,
}: Props) => {
  const defautNodeWidth = 232;
  const { palette } = useTheme();
  const [treeData, setTreeData] = useState<TreeData[]>([]);
  const boxRef = useRef<number>(defautNodeWidth);

  useEffect(() => {
    if (data) {
      setTreeData(data);
    }
  }, [data]);

  useEffect(() => {
    const treeContainer = document.querySelector('.tree-view-container');
    if (treeContainer) {
      boxRef.current = treeContainer.scrollWidth;
    }
  });

  const handleCheck = (id: string, checked: boolean) => {
    onChange && onChange(id, checked);
    setTreeData((prevTreeData) => updateTreeData(prevTreeData, id, checked, true));
  };

  return (
    <Box
      className="tree-view-container"
      border={`${$semantic.shared.size.sizesCommon.size1}px solid ${palette.semantic.color.commonBorderBasic}`}
      pt={`${$semantic.shared.size.sizesCommon.size15}px`}
      height="100%"
      sx={{
        overflowY: 'scroll',
        backgroundColor:
          TreeType[variant] === TreeType[TreeType.MENU]
            ? palette.semantic.color.commonBgDeep
            : palette.semantic.color.commonBgBasic,
        ...sx,
      }}
    >
      {treeData.map((node) => (
        <TreeNode
          id={node.id}
          key={node.id}
          depth={0}
          childrens={node.childrens ?? []}
          deptNm={node.deptNm}
          checked={node.checked || false}
          hasCheckbox={hasCheckBox}
          selected={selectedNode}
          dynamicWidth={boxRef.current}
          variant={variant}
          value={value}
          onCheck={handleCheck}
          onClick={onClick}
        />
      ))}
    </Box>
  );
};

export { TreeViewComponent, TreeType };
export type { TreeData };
