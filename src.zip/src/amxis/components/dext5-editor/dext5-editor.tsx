import { forwardRef, useEffect, useRef, useState } from 'react';
import { mergeRefs } from 'react-merge-refs';
import { Dext5EditorParams } from './dext5-editor.types.ts';
import { DEXT5Editor } from 'dext5editor-react';
import { uploadDextEditorFiles } from '@/amxis/apis/admin/FileUpload.ts';
import { set } from 'lodash';
type Dext5EditorProps = {
  name: string;
  value?: string;
  params?: Dext5EditorParams;
  onLoaded?: (e: Event, editor: React.Ref<HTMLDivElement>) => void;
  onChange?: (value: string) => void;
} & Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange'>;

const Dext5Editor = forwardRef<HTMLDivElement, Dext5EditorProps>(
  ({ name, value, params = {}, onLoaded, onChange, ...props }, forwardedRef) => {
    const appEnv = `${process.env.NODE_ENV}`;
    const containerId = `${name}-dext5-cross-editor-container`;
    const eventFunc = () => {
      if (onChange) {
        const fullContent = DEXT5.getBodyValue('Dext5Editor');
        onChange(fullContent);
      }
    };
    const pasteFunc = (eventParam1, eventParam2) => {
      // 붙여넣기 작업이 완료된 후 실행되도록 지연
      setTimeout(() => {
        if (onChange) {
          const fullContent = DEXT5.getBodyValue('Dext5Editor');
          onChange(fullContent);
        }
      }, 10); // 최소 지연시간으로 설정
    };
    const addFileFunc = async (eventParam1, eventParam2, eventParam3, eventParam4) => {
      // console.log(eventParam1, eventParam2, eventParam3, eventParam4);
      // try {
      //   // 파일 정보 추출 (DEXT5 에디터의 파라미터 구조에 따라 조정 필요)
      //   const file = eventParam1.objFile; // 실제 파일 객체
      //   const fileName = eventParam2.strFileName;
      //   if (!file) {
      //     console.error('파일이 없습니다.');
      //     return false;
      //   }
      //   // FormData 객체 생성
      //   const formData = new FormData();
      //   formData.append('file', file);
      //   formData.append('fileName', fileName);
      //   // 추가 메타데이터가 필요한 경우
      //   formData.append('editorId', name);
      //   formData.append('timestamp', new Date().toISOString());
      //   const response = await uploadDextEditorFiles(formData);
      //   setFilePath(response ?? '');
      //   //const response: CommonResponse<MenuVO> = await callApi(request);
      //   console.log(response);
      //   DEXT5.setToSavePathUrl(response, 'Dext5Editor');
      //   //const result = await response.json();
      //   //console.log('파일 업로드 성공:', result);
      //   // 성공 시 에디터에 파일 정보 반환 (DEXT5 에디터 요구사항에 따라 조정)
      //   return {
      //     success: true,
      //     // fileUrl: result.fileUrl || result.url,
      //     // fileName: result.fileName || fileName,
      //     // fileId: result.fileId || result.id,
      //   };
      // } catch (error) {
      //   console.error('파일 업로드 실패:', error);
      //   // 사용자에게 에러 메시지 표시 (선택사항)
      //   // alert('파일 업로드에 실패했습니다. 다시 시도해주세요.');
      //   return false; // 업로드 실패 시 false 반환
      // }
    };
    const urlFunc = (eventParam1, eventParam2, eventParam3, eventParam4) => {
      console.log(
        'urlFunc called with params:',
        eventParam1,
        eventParam2,
        eventParam3,
        eventParam4
      );
    };
    const defaultCompoentUrl = '/dext5editor/js/dext5editor.js';
    const defaultConfig = {
      ReturnEventInput: '1',
      Width: '100%',
      EditorBodyEditable: '1',
      DragAndDropAllow: '1',
      HandlerUrl: process.env.API_BASE_URL + '/api/aaa',
      SkinName: 'gray',
      AllowInsertFileType: 'docx,pptx,txt,xml',
      DefaultFontFamily: 'Spoqa Han Sans Neo',
      EditorHolder: containerId,
      SaveFileFolderNameRule: appEnv === 'local' ? 'YYYY\\MM\\' : 'YYYY/MM/',
      //ToSavePathURL: 'C:',
      Placeholder: {
        Content: '내용을 입력하세요.',
        FontColor: 'rgb(50,100,140)',
        FontFamily: 'Arial',
        FontSize: '12pt',
      },
      Event: {
        Input: eventFunc,
        BeforeAddFile: addFileFunc,
        BeforeInsertUrl: urlFunc,
        BeforePaste: pasteFunc,
      },
    };
    const containerRef = useRef<HTMLDivElement>(null);

    const [isInitialized, setIsInitialized] = useState(false);
    const [lock, setLock] = useState(false);

    const onInitialized = () => {
      setLock(true);
    };

    useEffect(() => {
      if (!isInitialized) {
        if (!lock) {
          onInitialized();
        }
      }
    }, [isInitialized, lock]);

    return (
      <div ref={mergeRefs([containerRef, forwardedRef])}>
        <DEXT5Editor
          id={'Dext5Editor'}
          config={{
            ...defaultConfig,
          }}
          componentUrl={defaultCompoentUrl}
          initData={value}
        />
      </div>
    );
  }
);
Dext5Editor.displayName = 'Dext5Editor';

export { Dext5Editor };
