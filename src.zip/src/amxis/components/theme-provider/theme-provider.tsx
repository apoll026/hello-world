import { ThemeSwitchProvider } from '@amxis/design-system';

type ThemeProviderProps = {
  children: React.ReactNode;
};

function ThemeProvider({ children }: ThemeProviderProps) {
  return <ThemeSwitchProvider initialThemeMode={'light'}>{children}</ThemeSwitchProvider>;
}

export { ThemeProvider };
