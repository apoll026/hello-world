import { CookiesProvider as Provider } from 'react-cookie';

type CookiesProviderProps = {
  children: React.ReactNode;
};

function CookiesProvider({ children }: CookiesProviderProps) {
  return <Provider>{children}</Provider>;
}

export { CookiesProvider };
