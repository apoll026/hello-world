import { forwardRef, useEffect, useRef, useState } from 'react';
import { mergeRefs } from 'react-merge-refs';
import { NamoCrossEditorParams } from './namo-cross-editor.types.ts';

declare const NamoSE: any;

type NamoCrossEditorProps = {
  name: string;
  value?: string;
  params?: NamoCrossEditorParams;
  onLoaded?: (e: Event, editor: React.Ref<HTMLDivElement>) => void;
  onChange?: (value: string) => void;
} & Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange'>;

const NamoCrossEditor = forwardRef<HTMLDivElement, NamoCrossEditorProps>(
  ({ name, value, params = {}, onLoaded, onChange, ...props }, forwardedRef) => {
    const uploadFileExecutePath = process.env.API_BASE_URL;
    const containerId = `${name}-namo-cross-editor-container`;

    const editorRef = useRef<any>(null);
    const containerRef = useRef<HTMLDivElement>(null);

    const [isInitialized, setIsInitialized] = useState(false);
    const [lock, setLock] = useState(false);

    const observer = new MutationObserver(() => {
      onChange?.(editorRef?.current?.GetBodyValue?.() ?? '');
    });

    const onInitialized = () => {
      if (!containerRef?.current) {
        throw new Error('failed load a Namo CrossEditor');
      }

      setLock(true);

      editorRef.current = new NamoSE();
      const editorInstance = editorRef.current;
      params.event = params.event ? params.event : {};

      const oldOnInitCompleted = params.event.OnInitCompleted;
      const newOnInitCompleted = (e: Event) => {
        try {
          editorInstance.SetBodyValue(value ?? '');

          if (oldOnInitCompleted) {
            oldOnInitCompleted(e);
          }

          if (onLoaded) {
            onLoaded(e, editorInstance);
          }

          setIsInitialized(true);
        } catch (e) {
          console.error('failed initialize a editor: ', e);
        } finally {
          setLock(false);
        }
      };

      params.event.OnInitCompleted = newOnInitCompleted;
      params.ParentEditor = containerRef.current;
      params.UploadFileExecutePath = uploadFileExecutePath + '/api/v1/namoFileUpload'; //이미지 업로드 URL
      params.UploadEtcFileExecutePath = uploadFileExecutePath + '/api/v1/namoFileUpload'; //파일 업로드 URL
      params.DoNotUnescapeUrl = true;
      params.Menu = false;

      params.Css = '/assets/fonts/namo-font.css';

      params.SupportBrowser = 0;

      params.Font = {
        'Spoqa Han Sans Neo': 'Spoqa Han Sans Neo',
        'Lg Smart Font': 'Lg Smart Font',
        '맑은 고딕': '맑은 고딕',
        Dotum: '돋움',
        Gulim: '굴림',
        Batang: '바탕',
        Gungsuh: '궁서',
        David: 'David',
        'MS PGothic': 'MS PGothic',
        'New MingLiu': 'New MingLiu',
        'Simplified Arabic': 'Simplified Arabic',
        simsun: 'simsun',
        Arial: 'Arial',
        'Courier New': 'Courier New',
        Tahoma: 'Tahoma',
        'Times New Roman': 'Times New Roman',
        Verdana: 'Verdana',
      };

      params.DefaultFont = 'Spoqa Han Sans Neo';
      params.NewToolbar = true;
      params.Placeholder = '내용을 입력해주세요.';
      params.HyperLinkDefaultTarget = '_blank';
      params.Width = '100%';
      editorInstance.params = params;
      // editorInstance.pBaseURL = '/crosseditor/'; // default: /crosseditor/

      editorInstance.EditorStart();
    };

    useEffect(() => {
      if (!isInitialized) {
        if (!lock) {
          onInitialized();
        }
      }
    }, [isInitialized, lock]);

    useEffect(() => {
      if (isInitialized) {
        observer.observe(editorRef.current.GetEditorDocument('doc').body, {
          attributes: true,
          childList: true,
          subtree: true,
          characterData: true,
        });
      }

      return () => {
        observer.disconnect();
      };
    }, [isInitialized]);

    return <div id={containerId} ref={mergeRefs([containerRef, forwardedRef])} {...props} />;
  }
);
NamoCrossEditor.displayName = 'NamoCrossEditor';

export { NamoCrossEditor };
