import { useTheme } from '@amxis/design-system';
import { Box } from '@mui/material';
import DOMPurify from 'dompurify';

function NamoCrossEditorViewer({ content }: { content: string }) {
  const [theme] = useTheme();
  const sanitizedContent = DOMPurify.sanitize(content, {
    ADD_ATTR: ['target'],
  });
  return (
    <Box
      component="div"
      dangerouslySetInnerHTML={{
        __html: sanitizedContent,
      }}
      sx={{
        color: theme.palette.semantic.color.commonTextBasic,
        '& h1': {
          fontSize: '24px',
        },
        '& h2': {
          fontSize: '18px',
        },
        '& h3': {
          fontSize: '16px',
        },
        '& h4': {
          fontSize: '15px',
        },
        '& h5': {
          fontSize: '14px',
        },
        '& h6': {
          fontSize: '13px',
        },
        '& p': {
          fontSize: '13px',
        },
        '& img': {
          maxWidth: '100%',
        },
      }}
    />
  );
}

export { NamoCrossEditorViewer };
