import { Button, Dialog } from '@amxis/design-system';
import { Box } from '@mui/system';
import { useTranslation } from 'react-i18next';
import CustomDialogTitle from './CustomDialogTitle.tsx';
import { DefaultTFuncReturn } from 'i18next';

/**
  Component Name : Dialog에 다국어 적용한 Component
  Component ID   : CustomDialog
  Component Desc : 
  Author         : yhjoo
  Create Date    : 2024.04.23
  modify Date    : 2024.04.23
*/

/**
  @param {string} content : Dialog에 들어갈 내용
  @param {string} title : Dialog에 들어갈 제목
  @param {string} type : 1-취소/확인 2-취소 3-x
  @param {string} isOpen
  @param {() => void} onSubmit
  @param {() => void} onClose
*/
interface ChildProps {
  content: JSX.Element | string | DefaultTFuncReturn;
  title?: string | DefaultTFuncReturn;
  type: string;
  isOpen: boolean;
  onSubmit: () => void;
  onClose: () => void;
}
const CustomDialog: React.FC<ChildProps> = ({
  content,
  title,
  type,
  isOpen,
  onSubmit,
  onClose,
}) => {
  const { t } = useTranslation();

  return (
    <Dialog
      position="basic"
      type={'modal'}
      size={400}
      open={isOpen}
      handleClose={() => onClose()}
      customContentArea={
        <>
          {typeof content === 'string' ? (
            <pre
              style={{
                paddingBottom: `12px`,
                fontSize: '13px',
                fontFamily: 'Spoqa Han Sans Neo',
                lineHeight: '19.5px',
                whiteSpace: 'pre-line',
              }}
            >
              {content.split('\\n').map((line, index) => (
                <span key={index}>
                  {line}
                  <br />
                </span>
              ))}
            </pre>
          ) : (
            content
          )}
          <Box display="flex" justifyContent="flex-end" columnGap={`4px`}>
            {type === '1' ? (
              <Button
                appearance="unfilled"
                priority="normal"
                size="medium"
                sx={{
                  minWidth: `56px`,
                  height: `36px`,
                  padding: `8px 12px`,
                }}
                onClick={() => onClose()}
              >
                {t('common.button.취소', '__취소')}
              </Button>
            ) : (
              <></>
            )}
            {type === '1' || type === '2' ? (
              <Button
                appearance="unfilled"
                priority="primary"
                size="medium"
                sx={{
                  minWidth: `56px`,
                  height: `36px`,
                  padding: `8px 12px`,
                }}
                onClick={() => {
                  onSubmit();
                }}
                autoFocus
              >
                {t('common.button.확인', '__확인')}
              </Button>
            ) : (
              <></>
            )}
          </Box>
        </>
      }
      customHeaderTitle={<CustomDialogTitle title={title} />}
    />
  );
};

export default CustomDialog;
