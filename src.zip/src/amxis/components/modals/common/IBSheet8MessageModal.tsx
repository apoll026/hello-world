/** @jsxImportSource @emotion/react */
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import _ from 'lodash';

import { ShowingMessage } from '@/amxis/models/admin/Message.ts';
import { CommonYN } from '@/amxis/models/common/Common.ts';

import { useCommonCodeNamesQuery } from '@/amxis/hooks/queries/common/use-common-code-names-query.ts';

import useLanguageStore from '@/amxis/stores/useLanguageStore.ts';
import { useMessageModalStore } from '@/amxis/stores/useMessageModalStore.ts';

import CustomDialogTitle from '@/amxis/components/modals/common/CustomDialogTitle.tsx';

import {
  DialogContentContainer,
  DialogContent,
  Spacer,
} from '@/amxis/components/layout/layouts.tsx';
import { Dialog, TitleArea } from '@amxis/design-system';
import { MessagePageGrid } from '@/amxis/pages/system/message/message-page-grid';
import { useMessageContext } from '@/amxis/pages/sample/sample-ibsheet/MessageContext';
export const IBSheet8MessageModal = () => {
  const { setSelectedMessage } = useMessageContext();
  const { t } = useTranslation();
  const { currentLanguage } = useLanguageStore();

  const { isOpen, noCallback, setMessageModalStateWhenModalClose } = useMessageModalStore();

  const messageModalSchema = z.object({
    msgCtn: z
      .string()
      .min(
        1,
        `${t(`common.label.{{}}를 입력해 주세요.`, `__{{inputTarget}}를 입력해 주세요.`, {
          inputTarget: `${t('message.label.메시지코드', '메시지코드')}`,
        })}`
      )
      .transform((val) => val.trimEnd())
      .refine((val) => !/^\s/.test(val), {
        message: String(
          t(
            'common.alert.공백으로 시작하는 코드는 등록할 수 없습니다.',
            '__공백으로 시작하는 코드는 등록할 수 없습니다.'
          )
        ),
      }),
    msgTxtCtn1: z.string().min(1),
    msgTxtCtn2: z.string().min(1).optional(),
    msgTxtCtn3: z.string().min(1).optional(),
    msgTxtCtn4: z.string().min(1).optional(),
    msgTxtCtn5: z.string().min(1).optional(),
    rmk: z.string().optional(),
    useYn: z.enum([CommonYN.Y, CommonYN.N]),
  });
  type MessageModalForm = z.infer<typeof messageModalSchema>;

  const {
    data: fetchedLanguageCode,
    isFetched: isLanguageFetched,
    refetch: refetchLanguageCode,
  } = useCommonCodeNamesQuery('LANG_CD');

  useEffect(() => {
    if (isLanguageFetched) {
      refetchLanguageCode();
    }
  }, [currentLanguage]);

  const {
    formState: { errors },

    reset,
  } = useForm<MessageModalForm>({
    resolver: zodResolver(messageModalSchema),
    defaultValues: {
      msgCtn: '',
      msgTxtCtn1: '',
      msgTxtCtn2: '',
      msgTxtCtn3: '',
      msgTxtCtn4: '',
      msgTxtCtn5: '',
      rmk: '',
      useYn: CommonYN.Y,
    },
  });
  const handleRowDoubleClick = (rowData: ShowingMessage) => {
    setSelectedMessage(rowData);

    handleNoButtonClick();
    // 로직 추가 가능
  };
  const handleSearch = useCallback(() => {}, []);
  const handleNoButtonClick = useCallback(async () => {
    setMessageModalStateWhenModalClose();
    if (noCallback) {
      noCallback();
    }
    reset();
  }, [noCallback, setMessageModalStateWhenModalClose]);

  return (
    <>
      {isOpen && (
        <Dialog
          customHeaderTitle={
            <CustomDialogTitle title={t('message-management.title.메시지 관리', '__메시지 관리')} />
          }
          position="basic"
          type={'modal'}
          size={1600}
          open={isOpen}
          handleClose={handleNoButtonClick}
          customContentArea={
            <DialogContentContainer>
              <TitleArea isSubTitle title={t('common.label.메시지등록', '__메시지등록')} />
              <Spacer type="h" size="4" />
              <DialogContent>
                <MessagePageGrid onRowDoubleClick={handleRowDoubleClick} />
              </DialogContent>
            </DialogContentContainer>
          }
        />
      )}
    </>
  );
};
