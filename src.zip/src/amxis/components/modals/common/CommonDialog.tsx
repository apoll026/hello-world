import { Button, Dialog } from '@amxis/design-system';
import { Box } from '@mui/system';
import { useTranslation } from 'react-i18next';
import CustomDialogTitle from './CustomDialogTitle.tsx';
import { useCommonDialogStore } from '@/amxis/stores/useCommonDialogStore.ts';

/**
  Component Name : Dialog에 다국어 적용한 Component
  Component ID   : CustomDialog
  Component Desc : 
  Author         : yhjoo
  Create Date    : 2024.04.23
  modify Date    : 2024.04.23
*/

const CommonDialog = () => {
  const { t } = useTranslation();

  const { isOpen, title, modalType, content, onSubmit, onClose, closeCommonDialog } =
    useCommonDialogStore();

  return (
    <Dialog
      position="basic"
      type={'modal'}
      size={400}
      open={isOpen}
      handleClose={async () => {
        onClose && (await onClose());
        closeCommonDialog();
      }}
      customContentArea={
        <>
          {typeof content === 'string' ? (
            <pre
              style={{
                paddingBottom: `12px`,
                fontSize: '13px',
                fontFamily: 'Spoqa Han Sans Neo',
                lineHeight: '19.5px',
                whiteSpace: 'pre-line',
              }}
            >
              {content.split('\\n').map((line, index) => (
                <span key={index}>
                  {line}
                  <br />
                </span>
              ))}
            </pre>
          ) : (
            content
          )}
          <Box display="flex" justifyContent="flex-end" columnGap={`4px`}>
            {modalType === 'confirm' ? (
              <Button
                appearance="unfilled"
                priority="normal"
                size="medium"
                sx={{
                  minWidth: `56px`,
                  height: `36px`,
                  padding: `8px 12px`,
                }}
                onClick={async () => {
                  onClose && (await onClose());
                  closeCommonDialog();
                }}
              >
                {t('common.button.취소', '__취소')}
              </Button>
            ) : (
              <></>
            )}
            {modalType === 'confirm' || modalType === 'alert' ? (
              <Button
                appearance="unfilled"
                priority="primary"
                size="medium"
                sx={{
                  minWidth: `56px`,
                  height: `36px`,
                  padding: `8px 12px`,
                }}
                onClick={async () => {
                  onSubmit && (await onSubmit());
                  closeCommonDialog();
                }}
                autoFocus
              >
                {t('common.button.확인', '__확인')}
              </Button>
            ) : (
              <></>
            )}
          </Box>
        </>
      }
      customHeaderTitle={<CustomDialogTitle title={title ?? ''} />}
    />
  );
};

export default CommonDialog;
