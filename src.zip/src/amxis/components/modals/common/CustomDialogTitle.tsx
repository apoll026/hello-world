import { Box } from '@mui/system';
import { useTranslation } from 'react-i18next';
import { Typography } from '@mui/material';
import { useTheme } from '@amxis/design-system';

/**
  @param {string} title : Dialog에 들어갈 제목
*/

interface ChildProps {
  title?: string | null;
}
const CustomDialogTitle: React.FC<ChildProps> = ({ title }) => {
  const { t } = useTranslation();
  const [theme] = useTheme();
  const { commonTextPrimary, commonTextPrimaryExtreme } = theme.palette.semantic.color;

  return (
    <Box display="flex" justifyContent="space-between" alignItems="center" columnGap={`8px`}>
      <Box
        sx={{
          width: `8px`,
          height: `8px`,
          borderRadius: '0.5rem',
          backgroundColor: commonTextPrimary,
        }}
      />
      <Typography variant="h2" color={commonTextPrimaryExtreme}>
        {title ?? t('common.title.알림', '__알림')}
      </Typography>
    </Box>
  );
};

export default CustomDialogTitle;
