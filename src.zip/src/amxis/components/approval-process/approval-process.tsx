import React from 'react';
import { Box, Typography, useTheme } from '@mui/material';
import { $semantic, Button, Label, Tag } from '@amxis/design-system';
import { ArrowChevron2Icon } from '@amxis/design-system/icon';

interface ApproverInfo {
  tagLabel?: string;
  tagColor?: 'grey' | 'primary' | 'secondary';
  name: string;
  team?: string;
  disabled?: boolean;
}

interface ApprovalButton {
  label: string;
  onClick?: () => void;
}

interface ApprovalLine {
  label: string;
  approvers: ApproverInfo[];
  buttons?: ApprovalButton[];
}

interface ApprovalProcessProps {
  lines: ApprovalLine[];
}

export const ApprovalProcess: React.FC<ApprovalProcessProps> = ({ lines }) => {
  const {
    palette: {
      semantic: { color },
    },
  } = useTheme();

  return (
    <Box
      display="flex"
      flexDirection="column"
      gap="4px"
      sx={{
        padding: '8px 12px',
        backgroundColor: color.commonBgDeep,
        border: `1px solid ${color.commonBorderStrong}`,
        borderRadius: `${$semantic.shared.radius.radiusSearchArea}px`,
      }}
    >
      {lines.map((line, index) => (
        <Box key={index} display="flex">
          {/* 결재선 라벨 */}
          <Label labelText={line.label} width="88px" />

          {/* 결재선 */}
          <Box display="flex" alignItems="center" flex={1} flexWrap="wrap">
            {line.approvers.map((approver, index) => {
              const tagColorMap = {
                grey: {
                  borderColor: color.commonBorderStronger,
                  color: color.commonTextLight,
                },
                primary: {
                  borderColor: color.commonBorderPrimary,
                  color: color.commonTextPrimaryExtreme,
                },
                secondary: {
                  borderColor: color.commonBorderSecondary,
                  color: color.commonTextSecondary,
                },
              } as const;
              const tagStyle = tagColorMap[approver.tagColor ?? 'grey'];

              return (
                <React.Fragment key={index}>
                  {/* 화살표 아이콘 */}
                  {index > 0 && (
                    <ArrowChevron2Icon
                      direction="right"
                      appearance="single"
                      sx={{ color: color.commonTextLight, marginLeft: '4px' }}
                    />
                  )}

                  {/* 결재자 정보 */}
                  <Box display="flex" alignItems="center" gap="6px" padding="6px">
                    <Tag
                      appearance="boxing"
                      sx={{
                        padding: '2px 10px',
                        backgroundColor: color.commonBgBasic,
                        fontWeight: 500,
                        opacity: approver.disabled ? 0.3 : 1,
                        ...tagStyle,
                      }}
                    >
                      {approver.tagLabel ?? '담당자'}
                    </Tag>
                    <Typography variant="bodySmall">
                      {approver.name}
                      {approver.team ? ` | ${approver.team}` : ''}
                    </Typography>
                  </Box>
                </React.Fragment>
              );
            })}
          </Box>

          {/* 버튼 그룹 */}
          {line.buttons && (
            <Box display="flex" alignItems="center" gap="4px">
              {line.buttons.map((button, index) => (
                <Button
                  key={index}
                  size="small"
                  appearance="outlined"
                  priority="normal"
                  buttonLabel={button.label}
                  onClick={button.onClick}
                />
              ))}
            </Box>
          )}
        </Box>
      ))}
    </Box>
  );
};
