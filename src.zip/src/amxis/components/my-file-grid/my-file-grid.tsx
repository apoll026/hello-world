import { useFindFilesQuery } from '@/amxis/hooks/queries/file/use-find-files-query.ts';
import { FileInfo } from '@/amxis/models/admin/FileInfo.ts';
import { useTranslation } from 'react-i18next';
import axios from 'axios';
import { Box, BoxProps, Typography } from '@mui/material';
import { Button, useTheme } from '@amxis/design-system';
import { FileDownloadIcon } from '@amxis/design-system/icon';
import { renderFileIcon } from '../ui/file-uploader/file-uploader-utils.tsx';
import {
  getDownloadPreSignedUrl,
  getDownloadPreSignedUrlAll,
} from '@/amxis/apis/common/FilePreSignedUrl.ts';

type MyFileGridProps = {
  atchFileGrId: string;
  showAllDownload?: boolean;
} & BoxProps;

function MyFileGrid({ atchFileGrId, showAllDownload = true, sx, ...props }: MyFileGridProps) {
  const { t } = useTranslation();
  const [theme] = useTheme();

  // query
  const { data: files } = useFindFilesQuery(atchFileGrId);
  const onDownloadFile = async (file: FileInfo) => {
    try {
      const response = await axios.get(
        `${process.env.API_BASE_URL}/api/v1/file/download?atchFileGrId=${file.atchFileGrId}&atchFileId=${file.atchFileId}`,
        {
          responseType: 'blob',
        }
      );

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', file.atchFileNm);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error(error);
    }
  };

  const onDownloadAllFiles = async () => {
    try {
      if (files) {
        for (const file of files) {
          const response = await axios.get(
            `${process.env.API_BASE_URL}/api/v1/file/download?atchFileGrId=${file.atchFileGrId}&atchFileId=${file.atchFileId}`,
            {
              responseType: 'blob',
            }
          );
          const url = window.URL.createObjectURL(new Blob([response.data]));
          const link = document.createElement('a');
          link.href = url;
          link.setAttribute('download', file.atchFileNm);
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          URL.revokeObjectURL(url);
        }
      }
    } catch (error) {
      console.error(error);
    }
  };

  if (!files || files.length === 0) {
    return null;
  }

  return (
    <Box
      sx={{
        p: '12px',
        border: `1px solid ${theme.palette.semantic.color.commonBorderBasic}`,
        bgcolor: theme.palette.semantic.color.commonBgDeep,
        ...sx,
      }}
      {...props}
    >
      <Box display="flex" justifyContent="space-between" alignItems="center">
        <Box display="flex" alignItems="center">
          <Typography variant="h3">{t('label.첨부파일', '첨부파일')}</Typography>
          <Box display="flex" alignItems="center" ml="8px">
            <Typography
              variant="bodyBasic"
              sx={{ color: theme.palette.semantic.color.commonTextBasic }}
            >
              {t('common.label.총', '총')}
            </Typography>
            <Typography
              variant="bodyBasic"
              sx={{ color: theme.palette.semantic.color.commonTextPrimary, mx: '2px' }}
            >
              {files.length}
            </Typography>
            <Typography
              variant="bodyBasic"
              sx={{ color: theme.palette.semantic.color.commonTextBasic }}
            >
              {t('common.label.건', '건')}
            </Typography>
          </Box>
        </Box>
        <Box display="flex" alignItems="center">
          {showAllDownload && (
            <Button
              type="submit"
              size="small"
              appearance="outlined"
              priority="normal"
              iconPosition="leading"
              iconComponent={<FileDownloadIcon />}
              onClick={onDownloadAllFiles}
            >
              {t('common.button.다운로드', '다운로드')}
            </Button>
          )}
        </Box>
      </Box>
      <Box component="ul" mt="4px">
        {files.map((file) => (
          <Box
            component="li"
            key={file.atchFileId}
            sx={{
              py: '6px',
              '&:not(:first-of-type)': {
                mt: '4px',
              },
            }}
          >
            <Box
              component="a"
              href="#"
              onClick={() => onDownloadFile(file)}
              sx={{
                display: 'inline-flex',
                alignItems: 'center',
              }}
            >
              {renderFileIcon(file.atchFileNm, 20)}
              <Typography
                variant="bodyBasic"
                sx={{ ml: '4px', color: theme.palette.semantic.color.commonTextSecondary }}
              >
                {file.atchFileNm}
              </Typography>
              <Typography
                variant="bodySmall"
                sx={{ ml: '4px', color: theme.palette.semantic.color.commonTextLighter }}
              >
                {Math.floor(file.atchFileSize).toLocaleString()} B
              </Typography>
            </Box>
          </Box>
        ))}
      </Box>
    </Box>
  );
}

export { MyFileGrid };
