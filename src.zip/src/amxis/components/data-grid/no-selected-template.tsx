import { Box, SxProps, Typography, useTheme } from '@mui/material';

import { $semantic } from '@amxis/design-system';
import { Theme } from '@mui/material';

import EmptyIcon from '@/amxis/assets/icons/DataorMenuEmpty.svg?react';
import { useTranslation } from 'react-i18next';

export type NoSelectedTemplateProps = {
  content?: string;
  sx?: SxProps<Theme>;
};

export const NoSelectedTemplate = ({ content }: NoSelectedTemplateProps) => {
  const theme = useTheme();
  const { t } = useTranslation();

  const noRowLabelStyle = {
    color: theme.palette.semantic.color.commonTextLighter,
    fontSize: '15px',
    fontWeight: $semantic.shared.typography.fontWeightBold,
    lineHeight: '22.5px',
  };

  return (
    <Box
      component="div"
      sx={{
        width: '100%',
        height: '100%',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        textAlign: 'center',
      }}
    >
      <Box padding={'60px 0'}>
        <EmptyIcon />
        <Typography sx={noRowLabelStyle}>
          {content ?? String(t('common.label.데이터를 선택하세요.', '__데이터를 선택하세요.'))}
        </Typography>
      </Box>
    </Box>
  );
};

export default NoSelectedTemplate;
