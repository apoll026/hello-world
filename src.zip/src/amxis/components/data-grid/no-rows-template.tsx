import { DataGridNoRows } from '@amxis/design-system';
import { useTranslation } from 'react-i18next';

const NoRowsTemplate = () => {
  const { t } = useTranslation();

  return (
    <DataGridNoRows
      content={
        t(
          'common.label.조회 가능한 데이터가 없습니다.',
          '__조회 가능한 데이터가 없습니다.'
        ) as string
      }
    />
  );
};
export default NoRowsTemplate;
