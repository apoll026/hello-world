import { mergeSx } from '@/amxis/utils/sx-util';
import { DropdownField, DropdownOption } from '@amxis/design-system';
import { Box, SxProps, Theme, Typography } from '@mui/material';

export type IBSheetGridPageSizeControlProps = {
  currentSize?: number;
  onChangeSize?: (size: number) => void;
  sizeOptions?: DropdownOption[];
  sx?: SxProps<Theme>;
  dropdownSx?: SxProps<Theme>;
  isPageSizeInput?: boolean;
};

const DEFAULT_SIZES = [
  {
    label: '10',
    value: '10',
  },
  {
    label: '15',
    value: '15',
  },
  {
    label: '20',
    value: '20',
  },
  {
    label: '30',
    value: '30',
  },
  {
    label: '40',
    value: '40',
  },
  {
    label: '50',
    value: '50',
  },
];

export const IBSheetGridPageSizeControl = ({
  sizeOptions = DEFAULT_SIZES,
  currentSize = 20,
  onChangeSize,
  sx,
  dropdownSx,
  isPageSizeInput = true,
}: IBSheetGridPageSizeControlProps) => {
  const PageSizeBoxStyle = mergeSx(
    {
      display: 'flex',
      alignItems: 'center',
      gap: '4px',
      mr: '4px',
      '.MuiAutocomplete-root': {
        width: '60px',
        height: '28px',
      },
    },
    sx
  );

  return (
    <Box sx={PageSizeBoxStyle}>
      <DropdownField
        isInput={isPageSizeInput}
        options={sizeOptions}
        value={{ label: currentSize.toString(), value: currentSize.toString() }}
        size="small"
        onChange={(_, value) => {
          const size = value as { value: string };
          onChangeSize?.(Number(size.value));
        }}
        disableClearable={false}
        sx={dropdownSx}
      />
      <Typography typography="body1" color="semantic.color.commonTextBasic">
        /page
      </Typography>
    </Box>
  );
};

export default IBSheetGridPageSizeControl;
