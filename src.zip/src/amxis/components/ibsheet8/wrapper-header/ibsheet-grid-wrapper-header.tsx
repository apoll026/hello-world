import { Box, SxProps } from '@mui/material';
import { Theme } from '@mui/material';
import IBSheetGridWrapperHeaderLeft, {
  IBSheetGridWrapperHeaderLeftProps,
} from './ibsheet-grid-wrapper-header-left';
import {
  IBSheetGridWrapperHeaderRight,
  IBSheetGridWrapperHeaderRightProps,
} from './ibsheet-grid-wrapper-header-right';
import { mergeSx } from '@/amxis/utils/sx-util';

export type IBSheetGridWrapperHeaderProps = {
  left?: IBSheetGridWrapperHeaderLeftProps;
  right?: IBSheetGridWrapperHeaderRightProps;
  sx?: SxProps<Theme>;
};

export const IBSheetGridWrapperHeader = ({ left, right, sx }: IBSheetGridWrapperHeaderProps) => {
  const headerStyle = mergeSx(
    {
      mb: '4px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      height: '28px',
    },
    sx
  );

  return (
    <Box sx={headerStyle}>
      <IBSheetGridWrapperHeaderLeft {...left} />
      <IBSheetGridWrapperHeaderRight {...right} />
    </Box>
  );
};

export default IBSheetGridWrapperHeader;
