import { InputField } from '@amxis/design-system';
import { Box, SxProps, Theme } from '@mui/material';
import { ReactNode } from 'react';
import { GridHeaderButton, GridHeaderButtonType } from './ibsheet-grid-wrapper-header-button';
import { FunctionSearchIcon } from '@amxis/design-system/icon';
import { mergeSx } from '@/amxis/utils/sx-util';

export type IBSheetGridHeaderRightMember = {
  variant: GridHeaderButtonType;
  hide?: boolean;
  label?: string;
  disabled?: boolean;
  customImage?: ReactNode;
  onClick?: React.MouseEventHandler<HTMLButtonElement>;
};

export type IBSheetGridHeaderRightSearchField = {
  placeholder?: string;
  onChange?: (value: string) => void;
  onSubmit?: (value: string) => void;
  sx?: SxProps<Theme>;
};
export type IBSheetGridWrapperHeaderRightProps = {
  buttonFamily?: IBSheetGridHeaderRightMember[];
  headerSearchField?: IBSheetGridHeaderRightSearchField;
  sx?: SxProps<Theme>;
};

export const IBSheetGridWrapperHeaderRight = ({
  buttonFamily,
  headerSearchField,
  sx,
}: IBSheetGridWrapperHeaderRightProps) => {
  const headerRightStyle = mergeSx(
    {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'flex-end',
      gap: '8px',
      overflow: 'hidden',
      whiteSpace: 'nowrap',
    },
    sx
  );

  return (
    <Box sx={headerRightStyle}>
      {headerSearchField && (
        <InputField
          type="text"
          size="small"
          placeholder={headerSearchField.placeholder}
          onChange={(e) => {
            headerSearchField.onChange?.(e.target.value);
          }}
          InputProps={{
            startAdornment: <FunctionSearchIcon appearance="lined" />,
          }}
          sx={{
            '.MuiInputBase-root': {
              alignItems: 'center',
              gap: '4px',
            },
          }}
        />
      )}
      {buttonFamily && (
        <Box display="flex" gap="4px">
          {buttonFamily.map((button, idx) => {
            return (
              <GridHeaderButton
                buttonType={button.variant}
                key={idx}
                label={button.label}
                onClick={button.onClick}
                customImage={button.customImage}
                disabled={button.disabled}
              />
            );
          })}
        </Box>
      )}
    </Box>
  );
};
