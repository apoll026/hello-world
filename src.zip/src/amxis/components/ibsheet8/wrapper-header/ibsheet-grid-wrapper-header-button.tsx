import { Typography, Button, useTheme } from '@mui/material';
import { ReactNode, useMemo } from 'react';
import {
  ControlAddIcon, ControlConfirmIcon,
  ControlRefreshIcon,
  ControlSubstractIcon,
  FileExceldownloadIcon,
  FileExceluploadIcon,
  FunctionSettingIcon,
} from '@amxis/design-system/icon';
import { mergeSx } from '@/amxis/utils/sx-util';

export type GridHeaderButtonType =
  | 'add'
  | 'download'
  | 'refresh'
  | 'delete'
  | 'setting'
  | 'upload'
  | 'save'
  | 'custom';
export type GridHeaderButtonProps = {
  buttonType: GridHeaderButtonType;
  label?: string;
  disabled?: boolean;
  onClick?: React.MouseEventHandler<HTMLButtonElement>;
  customImage?: ReactNode;
  sx?: object;
};

export const GridHeaderButton = ({
  buttonType,
  label,
  disabled,
  onClick,
  customImage,
  sx,
}: GridHeaderButtonProps) => {
  const theme = useTheme();
  const buttonStyle = mergeSx(
    {
      display: 'flex',
      alignItems: 'center',
      padding: '4px 6px',
      minWidth: '16px',
      height: '28px',
      border: `1px solid ${theme.palette.semantic.color.commonBorderBasic}`,
      borderRadius: '2px',
      color: theme.palette.semantic.color.commonTextLight,
      fontSize: '16px',
    },
    sx
  );

  const buttonIcon = useMemo(() => {
    switch (buttonType) {
      case 'add':
        return <ControlAddIcon size="default" />;
      case 'delete':
        return <ControlSubstractIcon size="default" />;
      case 'upload':
        return <FileExceluploadIcon />;
      case 'download':
        return <FileExceldownloadIcon />;
      case 'refresh':
        return <ControlRefreshIcon size="default" />;
      case 'setting':
        return <FunctionSettingIcon appearance="lined" />;
      case 'save':
        return <ControlConfirmIcon size="default" />;
      case 'custom':
        return <>{customImage}</>;
      default:
        return <></>;
    }
  }, [buttonType]); // eslint-disable-line react-hooks/exhaustive-deps

  const defaultLabel = {
    upload: '업로드',
    download: '다운로드',
    refresh: '새로고침',
  } as Record<GridHeaderButtonType, string>;

  return (
    <Button sx={buttonStyle} onClick={onClick} disabled={disabled}>
      {buttonIcon}
      {label && <Typography ml="4px">{label}</Typography>}
      {!label && buttonType in defaultLabel && (
        <Typography ml="4px">{defaultLabel[buttonType]}</Typography>
      )}
    </Button>
  );
};
