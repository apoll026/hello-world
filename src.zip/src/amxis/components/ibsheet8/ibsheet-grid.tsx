import React, { forwardRef, useEffect, useImperativeHandle, useRef } from 'react';
import loader from '@ibsheet/loader';
import { Box } from '@mui/material';
import IBSheetGridWrapperHeader from './wrapper-header/ibsheet-grid-wrapper-header';
import { IBSheetGridHeaderRightMember } from './wrapper-header/ibsheet-grid-wrapper-header-right';
import { Sheet, SheetOptions } from '@/amxis/models/common/Ibsheet';

export interface IBSheetGridProps {
  isHeaderSectionEnabled: boolean;
  id: string;
  el?: string
  options: SheetOptions;
  data?: any[];
  width?: string;
  height?: string;
  title?: string;
  headerButton?: IBSheetGridHeaderRightMember[];
  total?: number;
  hasPageSizeArea?: boolean;
  infoText?: string;
  minHeight?: string | false;
}

export interface IBSheetGridRef {
  getSheet: () => Sheet | null;
}

const IBSheetGrid = forwardRef<IBSheetGridRef, IBSheetGridProps>(
  (
    {
      id,
      options,
      title,
      width = '100%',
      height,
      isHeaderSectionEnabled = true,
      headerButton,
      hasPageSizeArea = false,
      total,
      infoText,
      minHeight,
    },
    ref
  ) => {
    const sheetRef = useRef<Sheet | null>(null);

    useEffect(() => {
      loader.createSheet({ id, el: id, options }).then(() => {
        sheetRef.current = loader.getIBSheetStatic();
      });

      return () => {
        loader.removeSheet(id);
      };
    }, []);

    useImperativeHandle(ref, () => ({
      getSheet: () => sheetRef.current,
    }));

    return (
      <Box
        sx={{
          display: 'flex',
          flexDirection: 'column',
          ...(height
            ? { height }
            : minHeight !== false
              ? { minHeight: minHeight || '300px' }
              : {}),
          flexGrow: 1,
        }}
      >
        {isHeaderSectionEnabled && (
          <IBSheetGridWrapperHeader
            left={{ title, hasPageSizeArea, total, infoText }}
            right={{ buttonFamily: headerButton }}
          />
        )}
        <Box
          sx={{
            width,
            ...(height
              ? { height }
              : minHeight !== false
                ? { minHeight: '300px' }
                : {}),
          }}
        >
          <Box
            id={id}
            sx={{
              ...(height
                ? { height }
                : minHeight !== false
                  ? { minHeight: '300px' }
                  : {}),
              height: '100% !important',
            }}
          />
        </Box>
      </Box>
    );
  }
) as React.FC<IBSheetGridProps & React.RefAttributes<IBSheetGridRef>>;

// displayName 지정 (디버깅용)
IBSheetGrid.displayName = 'IBSheetGrid';

export default IBSheetGrid;
