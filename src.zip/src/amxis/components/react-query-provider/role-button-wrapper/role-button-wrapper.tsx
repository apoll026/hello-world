import { Button } from '@amxis/design-system';
import React, { ReactElement } from 'react';
import useButtonAuth from '../../hooks/use-button-auth';
import { saveButtonClickLog } from '@/amxis/apis/admin/ButtonLog.ts';

type RoleButtonWrapperProps = {
  children: ReactElement<typeof Button>;
  btnKeyCd: string;
  type?: 'display' | 'disabled';
  logClick?: boolean;
};

function AuthButtonWrapper({
  children,
  btnKeyCd,
  type = 'disabled',
  logClick = false,
}: RoleButtonWrapperProps) {
  const { isButtonAuth } = useButtonAuth();

  const setConfig = () => {
    const conf: any = { disabled: false };
    if (type == 'disabled') {
      conf.disabled = !isButtonAuth(btnKeyCd);
    } else if (type == 'display') {
      conf.sx = { display: isButtonAuth(btnKeyCd) ? 'block' : 'none' };
    }
    return conf;
  };

  const clonedChildren = React.Children.map(children, (child) => {
    if (!React.isValidElement(child)) return child;

    const element = child as React.ReactElement<any>; // 타입 명시
    console.log(element.props);
    const originalOnClick = element.props.onClick;

    // const originalOnClick = child.props.onClick;
    const wrppedOnClick = async (...args: any[]) => {
      if (logClick) {
        saveButtonClickLog(btnKeyCd).catch();
      }

      if (originalOnClick) {
        await originalOnClick(...args);
      }
    };

    return React.cloneElement(child, { ...setConfig(), onClick: wrppedOnClick });
  });

  return <>{clonedChildren}</>;
}

export { AuthButtonWrapper };
