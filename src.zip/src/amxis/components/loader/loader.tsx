import { Box } from '@mui/material';
import { useLoading } from './use-loading.ts';
import { ProgressIndicator, useTheme } from '@amxis/design-system';

function Loader() {
  const { isLoading } = useLoading();
  const [theme] = useTheme();

  return (
    <Box
      overflow="hidden"
      position="fixed"
      top="0"
      right="0"
      bottom="0"
      left="0"
      bgcolor={theme.palette.semantic.color.commonBgDim}
      zIndex={isLoading ? 5000 : -5000}
      sx={{
        opacity: isLoading ? 1 : 0,
        transition: 'opacity 0.5s ease-in-out, z-index 0.5s ease-in-out',
      }}
    >
      <Box width="100%" height="100%" display="flex" alignItems="center" justifyContent="center">
        <ProgressIndicator color="primary" shape="circular" />
      </Box>
    </Box>
  );
}

function RelativeLoader({ isLoading }: { isLoading: boolean }) {
  const [theme] = useTheme();

  return (
    <Box
      overflow="hidden"
      position="absolute"
      top="0"
      right="0"
      bottom="0"
      left="0"
      bgcolor={theme.palette.semantic.color.commonBgDim}
      zIndex={isLoading ? 5000 : -5000}
      sx={{
        opacity: isLoading ? 1 : 0,
        transition: 'opacity 0.5s ease-in-out, z-index 0.5s ease-in-out',
      }}
    >
      <Box width="100%" height="100%" display="flex" alignItems="center" justifyContent="center">
        <ProgressIndicator color="primary" shape="circular" />
      </Box>
    </Box>
  );
}

export { Loader, RelativeLoader };
