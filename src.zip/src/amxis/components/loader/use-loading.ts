import { create } from 'zustand';

interface LoadingStore {
  isLoading: boolean;
  openLoading: (isLoading: boolean) => void;
}

const useLoading = create<LoadingStore>((set) => {
  return {
    isLoading: false,
    openLoading: (newIsLoading) => {
      set({ isLoading: newIsLoading });
    },
  };
});

export { useLoading };
