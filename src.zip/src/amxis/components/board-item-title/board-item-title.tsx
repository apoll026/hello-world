import { Badge, Box } from '@mui/material';
import RedDotIcon from '@/amxis/assets/icons/red.svg?react';
import { Typography } from '@mui/material';
import { useTheme, $semantic } from '@amxis/design-system';

type BoardItemTitleProps = {
  title: string;
  commentsCount?: number;
  isUnread?: boolean;
  isImportant?: boolean;
  isNewPost?: boolean;
};

function BoardItemTitle({
  title,
  commentsCount,
  isUnread,
  isImportant,
  isNewPost,
}: BoardItemTitleProps) {
  const [theme] = useTheme();
  return (
    <Box display="flex" alignItems="center">
      {isUnread && (
        <Box display="flex" alignItems="flex-start" height={10}>
          <RedDotIcon width={4} height={4} />
        </Box>
      )}
      <Typography
        color={
          isImportant
            ? theme.palette.semantic.color.commonTextPrimary
            : theme.palette.semantic.color.commonTextBasic
        }
        fontSize={$semantic.shared.typography.fontSizeXlarge}
        fontWeight={
          isUnread
            ? $semantic.shared.typography.fontWeightBold
            : $semantic.shared.typography.fontWeightRegular
        }
        lineHeight={$semantic.shared.typography.lineHeightBasic}
      >
        {title}
      </Typography>

      {isNewPost && (
        <>
          <Badge
            badgeContent="N"
            color="error"
            sx={{
              '& .MuiBadge-badge': {
                right: -14,
                top: 0,
                fontWeight: 400,
                fontSize: 11,
                height: 16,
                width: 16,
                minWidth: 16,
              },
            }}
          />
          <Box width="24px" />
        </>
      )}

      {commentsCount && (
        <Typography
          color={theme.palette.semantic.color.commonTextSecondary}
          fontSize={$semantic.shared.typography.fontSizeH6}
          fontWeight={$semantic.shared.typography.fontWeightRegular}
          lineHeight={$semantic.shared.typography.lineHeightBasic}
          ml={`${$semantic.shared.size.sizesCommon.size4}px`}
          mr={`${$semantic.shared.size.sizesCommon.size4}px`}
        >
          [{commentsCount}]
        </Typography>
      )}
    </Box>
  );
}

export { BoardItemTitle };
