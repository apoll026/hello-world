import React from 'react';
import {
  useMessageBarWithDetails,
  MessageBarWithDetailsInfo,
} from '@/amxis/hooks/useMessageBarWithDetails';
import MessageDetails from './MessageDetails';

interface MessageBarWithDetailsProviderProps {
  children?: React.ReactNode;
}

export function MessageBarWithDetailsProvider({ children }: MessageBarWithDetailsProviderProps) {
  const { showError: baseShowError, hideError, open, error } = useMessageBarWithDetails();

  const showError = React.useCallback(
    (errorInfo: MessageBarWithDetailsInfo) => {
      const messageComponent = (
        <MessageDetails open={true} onClose={hideError} errorInfo={errorInfo} />
      );

      baseShowError(errorInfo, messageComponent);
    },
    [baseShowError, hideError]
  );

  // Context를 통해 showError 함수를 제공할 수도 있습니다
  const contextValue = React.useMemo(
    () => ({
      showError,
      hideError,
      open,
      error,
    }),
    [showError, hideError, open, error]
  );

  return (
    <MessageBarWithDetailsContext.Provider value={contextValue}>
      {children}
    </MessageBarWithDetailsContext.Provider>
  );
}

// Context 생성
const MessageBarWithDetailsContext = React.createContext<{
  showError: (errorInfo: MessageBarWithDetailsInfo) => void;
  hideError: () => void;
  open: boolean;
  error: MessageBarWithDetailsInfo;
} | null>(null);

// Context를 사용하는 커스텀 훅
export function useMessageBarWithDetailsContext() {
  const context = React.useContext(MessageBarWithDetailsContext);
  if (!context) {
    throw new Error(
      'useMessageBarWithDetailsContext must be used within MessageBarWithDetailsProvider'
    );
  }
  return context;
}

// 직접 사용할 수 있는 훅 (Provider 없이도 사용 가능)
export function useMessageBarWithDetailsComponent() {
  const { showError: baseShowError, hideError, open, error } = useMessageBarWithDetails();

  const showError = React.useCallback(
    (errorInfo: MessageBarWithDetailsInfo) => {
      const messageComponent = (
        <MessageDetails open={true} onClose={hideError} errorInfo={errorInfo} />
      );

      baseShowError(errorInfo, messageComponent);
    },
    [baseShowError, hideError]
  );

  return {
    showError,
    hideError,
    open,
    error,
  };
}
