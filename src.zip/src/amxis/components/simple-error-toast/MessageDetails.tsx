import React, { useState } from 'react';
import {
  Snackbar,
  Alert,
  Collapse,
  Box,
  Typography,
  IconButton,
  Stack,
  TextField,
} from '@mui/material';
import { Button, InputField } from '@amxis/design-system';
import { ExpandMore, ExpandLess, Close, ContentCopy, CheckCircle } from '@mui/icons-material';
import { MenuProvider } from '@/amxis/components/menu-provider';
import { CustomTextarea } from '../custom-input';
interface MessageBarWithDetailsInfo {
  message: React.ReactNode;
  details?: React.ReactNode;
  code?: string;
  timestamp?: string;
}

interface MessageBarWithDetailsProps {
  open: boolean;
  onClose: () => void;
  errorInfo: MessageBarWithDetailsInfo;
}

const MessageDetails: React.FC<MessageBarWithDetailsProps> = ({ open, onClose, errorInfo }) => {
  const [expanded, setExpanded] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);

  const handleExpandClick = () => {
    setExpanded(!expanded);
  };

  const handleCopyDetails = async () => {
    const detailsText = `
에러 코드: ${errorInfo.code || 'N/A'}
발생 시간: ${errorInfo.timestamp || 'N/A'}
메시지: ${errorInfo.message}
${errorInfo.details ? `상세: ${errorInfo.details}` : ''}
    `.trim();

    try {
      await navigator.clipboard.writeText(detailsText);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    } catch (err) {
      console.error('Failed to copy to clipboard:', err);
    }
  };

  return (
    <Box sx={{ marginTop: '-3px' }}>
      <Box
        display="flex"
        alignItems="center"
        sx={{
          minWidth: expanded ? '510px' : '0px',
          transition: 'min-width 0.4s ease-in-out',
          overflow: 'hidden',
        }}
      >
        <Box
          onClick={handleExpandClick}
          sx={{
            cursor: 'pointer',
          }}
        >
          <Typography variant="body2" flexGrow={1}>
            {errorInfo.message}
          </Typography>
        </Box>

        {(errorInfo.details || errorInfo.code) && (
          <Button
            size="small"
            appearance="unfilled"
            priority="normal"
            onClick={handleExpandClick}
            iconSize={20}
            iconComponent={expanded ? <ExpandLess /> : <ExpandMore />}
            sx={{
              color: 'inherit',
              textTransform: 'none',
              fontSize: '0.8rem',
              p: 0,
              minWidth: 'auto',
            }}
          />
        )}
      </Box>

      <Collapse in={expanded} timeout="auto" unmountOnExit>
        <Box sx={{ mt: 2, pt: 2, borderTop: '1px solid rgba(255,255,255,0.2)' }}>
          <Stack spacing={1}>
            {errorInfo.code && (
              <Box>
                <Typography variant="caption" sx={{ fontWeight: 'bold' }}>
                  에러 코드:
                </Typography>
                <Typography variant="body2" sx={{ fontSize: '0.8rem', fontFamily: 'monospace' }}>
                  {errorInfo.code}
                </Typography>
              </Box>
            )}

            {errorInfo.timestamp && (
              <Box>
                <Typography variant="caption" sx={{ fontWeight: 'bold' }}>
                  발생 시간:
                </Typography>
                <Typography variant="body2" sx={{ fontSize: '0.8rem' }}>
                  {errorInfo.timestamp}
                </Typography>
              </Box>
            )}

            {errorInfo.details && (
              <Box>
                <Typography variant="caption" sx={{ fontWeight: 'bold', mb: 1 }}>
                  상세 내용:
                </Typography>
                <CustomTextarea value={String(errorInfo.details)} />
              </Box>
            )}

            {/* 복사 버튼 */}
            <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 1 }}>
              <Button
                size="small"
                appearance="unfilled"
                priority="normal"
                iconComponent={copySuccess ? <CheckCircle color="success" /> : <ContentCopy />}
                onClick={handleCopyDetails}
                sx={{
                  color: copySuccess ? 'success.main' : 'inherit',
                  textTransform: 'none',
                  fontSize: '0.8rem',
                }}
              >
                {copySuccess ? '복사됨' : '상세 정보 복사'}
              </Button>
            </Box>
          </Stack>
        </Box>
      </Collapse>
    </Box>
  );
};

export default MessageDetails;
