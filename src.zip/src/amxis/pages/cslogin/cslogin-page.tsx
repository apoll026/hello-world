import { useNavigate } from 'react-router';
import {
  Button,
  HelperText,
  InputField,
  Description,
  useMessageBar,
  useTheme,
} from '@amxis/design-system';
import { useTranslation } from 'react-i18next';
import { useCommonDialogStore } from '@/amxis/stores/useCommonDialogStore';
import { Box, Link } from '@mui/material';

import * as z from 'zod';
import { useOutLoginMutation } from '@/amxis/hooks/queries/outlogin/use-out-login-mutation.ts';
import { useCompanyMutation } from '@/amxis/hooks/queries/company/use-company-mutation.ts';
import { useCheckAdminIpMutation } from '@/amxis/hooks/queries/login/use-check-admin-ip-mutation.ts';
import { useLoading } from '@/amxis/components/loader';
import useLanguageStore from '@/amxis/stores/useLanguageStore.ts';
import useSessionStore from '@/amxis/stores/useSessionStore.ts';
import { LanguageCode } from '@/amxis/models/common/Session.ts';
import { useEffect, useRef, useState } from 'react';
import { Code } from '@/amxis/models/common/CommonCode.ts';

const createLoginSchema = (isPassVerify: boolean) => {
  const baseSchema = {
    cmpnNum: z
      .string({
        required_error: '사용자ID를 반드시 입력하세요.', // non undefined
      })
      .min(1, '사용자ID를 반드시 입력하세요.'), // non empty string
  };

  return z.object({
    ...baseSchema,
    //userPass: z.string().optional(),
    //authCode: z.string().optional(),
  });
};

const loginSchema = createLoginSchema(`${process.env.NODE_ENV}` === 'local');
type LoginForm = z.infer<typeof loginSchema>;

function CsLoginPage() {
  const appEnv = `${process.env.NODE_ENV}`;

  // 인증을 통과할 Env 설정 (임시로 dev 허용)
  const isPassVerify = (appEnv === 'local' || appEnv === 'dev');

  const [isIpVerified, setIsIpVerified] = useState(false);

  // 인증처리 성공 후 hax값
  const [rSerialNumberHex, setRSerialNumberHex] = useState('');
  // 입력된사업자번호
  const [cmpnNum, setCmpnNum] = useState('');

  const [theme] = useTheme();
  const { setSession } = useSessionStore();
  const { changeLanguage } = useLanguageStore();
  const navigate = useNavigate();
  const { openLoading } = useLoading();
  const { mutateAsync: loginAsync } = useOutLoginMutation();
  const { mutateAsync: callCompnaySignVerify } = useCompanyMutation();
  const { mutateAsync: checkAdminIpAsync } = useCheckAdminIpMutation();

  // 공통 다이얼로그
  const { t } = useTranslation();
  const { openCommonDialog } = useCommonDialogStore();
  const { showMessageBar } = useMessageBar();
  const [open, setOpen] = useState(false);
  
  const msgCtn = useRef<String>('');

  const getLanguageCode = (langCd: string) => {
    switch (langCd) {
      case 'ENG':
        return 'en';
      case 'CMN':
        return 'zhC';
      default:
        return 'ko';
    }
  };

  // IP 검증 함수
  const checkAdminIp = async () => {
    try {

      const response = await checkAdminIpAsync();
      
      if (response.successOrNot === 'Y') {
        setIsIpVerified(true);
      } else {
        navigate('/errorPage', { replace: true });
      }
    } catch (error) {
      console.error('IP 검증 중 오류 발생:', error);
      navigate('/errorPage', { replace: true });
    }
  };

  // 컴포넌트 마운트 시 IP 검증 수행
  useEffect(() => {
    checkAdminIp();
  }, []);

  // 인증서 확인
  const pageInit = async (cmpnNum: string, serialNumHex: string) => {
    openLoading(true);
    
    let langCd = "KO";
    let signVerifyData;
    let response;

    try {
      // 인증서 Hax값 확인
      signVerifyData = callCompnaySignVerify({ signValue: serialNumHex });
      console.log("signVerifyData ", signVerifyData);

      if (signVerifyData !== null) {
                                              
        response = await loginAsync({cmpnNum: cmpnNum, serialNumberHex: serialNumHex, langCd: langCd});

        console.log("response ", response.data);
        if (response.successOrNot !== 'Y' || !response?.data) {
          showMessageBar({
            message: '로그인에 실패하였습니다.',
            usecase: 'error',
          });
          return;
        }

        const session = response.data;
        changeLanguage(session.langCd || 'ko');
        setSession(session);
        navigate('/', { replace: false });
      } else {
        showMessageBar({
          message: '사용할 수 없는 인증서 입니다.\\n\\n※잠시후 접속해 주시기 바랍니다.',
          usecase: 'error',
        });
        return;
      }
    } catch (e) {
      console.log({ e });
      showMessageBar({
        message: '로그인에 실패하였습니다.',
        usecase: 'error',
      });
    } finally {
      openLoading(false);
    }
  }

  const validateInputs = () => {
    const cmpnInfo = document.getElementById('cmpnId') as HTMLInputElement;
    let cmpnId = (cmpnInfo.value).replace(/-/gi, "");
  
    let sRand = cmpnId;
    let isValid = true;

    if (!cmpnId) {
      console.log("cmpmId error");
      showMessageBar({
        message: "사업자 번호를 입력해 주세요.",
        usecase: 'error',
      });
    } else {
      console.log("cmpmId init :: ", sRand);
   
      /** 범용공인인증서 호출 S */
      // sign_complete_callback 호출 정상이면 아래 행 실행 실패면 종료처리
      //let res = "";
      //let options = { initPolicy: acceptPolicy, ssn: cmpnId.value };
      //let rst = nxTSPKI.signData(sRand, options, sign_complete_callback);
      /** 범용공인인증서 호출 E */
      let rst = true;
      if (rst) {
        console.log("form init");
        pageInit(cmpnId, "7651ff0");
      } else {
        console.log("form out");
        pageInit(cmpnId, "7651ff0");
        isValid = false;
      }
    }

    return isValid;
  };

  // 범용공인인증서 callback 함수 
  const sign_complete_callback = (res) => {
    if (res.code === 0) {
      $("#<%=txtSignValue.ClientID %>").val(res.data.signedData);
      let cert = res.data.certInfo;
      let rSerialNumberHex = cert.serialNumberHex;
      console.log('rSerialNumberHex :: ', rSerialNumberHex);
      //document.all.hidCertSerial.value = rSerialNumberHex;
      //document.getElementById("btnSave").click();
      //setRSerialNumberHex(rSerialNumberHex);
      return true;
    }
    else if (res.code !== '100') {
        openCommonDialog({
          modalType: 'alert',
          content: t(res.errorMessage+'', res.errorMessage+''),
        });
        return false;
    }
  } 

  return (
    <Box
      display="flex"
      width="100%"
      height="100%"
      justifyContent="center"
      pt="160px"
      bgcolor={theme.palette.semantic.color.commonBgDeeper}
    >
      <Box>
          {/* ID 입력 */}
          <Box display="flex" alignItems="center">
            <Box ml="8px" flex="1">
                  <InputField
                    id="cmpnId"
                    autoComplete={"cmpnId"}
                    size="large"
                    fullWidth
                    placeholder="사업자번호를 입력하세요.000-00-00000"
                  />
            </Box>
          </Box>
          {/* 공인인증서 버튼 */}
          <Box display="flex" alignItems="center" justifyContent="flex-end" mt="12px">
              <Button
                type="button"
                size="large"
                appearance="contained"
                priority="primary"
                iconPosition="leading"
                fullWidth
                onClick={validateInputs}
              >
                공인인증서
              </Button>
          </Box>
          <Box display="flow" alignItems="center">
              <Box mt="100px">
                  <Link
                    component="button"
                    type="button"
                    variant="bodySmall"
                    sx={{ alignSelf: 'center' }}
                  >
                    인증서 발급/등록
                  </Link>
                  &nbsp;&nbsp;|&nbsp;&nbsp;
                  <Link
                    component="button"
                    type="button"
                    variant="bodySmall"
                    sx={{ alignSelf: 'center' }}
                  >
                    협력사 계좌관리 FAQ
                  </Link>
              </Box>
              <Box mt="100px">
                <HelperText
                      infoText="☎ 공인인증서 문의 : 소프트체인(1577-7670), 기타 문의 : IT Help Desk (1544-8337)"
                      usecase="default"
                  />
              </Box>
          </Box>
          <Box width="596px">
            <Description
              listData={[
                {
                  content: '사업자 번호로 발급받은 범용공인인증서로 로그인 가능합니다.'
                },
                {
                  content: '공인인증서 등록 및 신청은 인증서 발급/등록 버튼을 클릭하시기 바랍니다.'
                },
                {
                  content: '인증서 로그인이 안될 경우'
                },
                {
                  content: 'SCORE PKI for OpenWeb 프로그램 버전체크 오류가 발생하는 경우, 주소창에 http://가 없으면 주소에 붙여서\n 다시 진행해보시기 바랍니다. ',
                  textLink: ''
                }
              ]}
              ordered
              usecase="normal"
            />
          </Box>
      </Box>
    </Box>
  );
}

export { CsLoginPage };
