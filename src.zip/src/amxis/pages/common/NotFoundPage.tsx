/** @jsxImportSource @emotion/react */
import { css } from '@emotion/react';
import { Button } from '@amxis/design-system';
import { Box } from '@mui/material';
import IconBan from '@/amxis/assets/icons/ic-ban.svg';

enum ERROR_PAGE {
  NOT_FOUND = 1,
  NOT_ALLOWD = 2,
}

const st = {
  error: css`
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;
    p {
      &.strong {
        font-size: 15px;
        font-weight: 700;
        margin-bottom: 5px;
      }
      color: #979998;
      font-size: 13px;
      line-height: 24px;
    }
    button {
      margin-top: 10px;
    }
  `,
};

export const NotFoundPage = ({ pageType = ERROR_PAGE.NOT_FOUND }) => {
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div css={st.error}>
        <span className="icon">
          <i>
            <img src={IconBan} alt="" />
          </i>
        </span>
        <p className="strong">
          {pageType === ERROR_PAGE.NOT_ALLOWD ? 'Not Allowed To Access' : 'Page Not Found'}
        </p>
        <p>
          {pageType === ERROR_PAGE.NOT_ALLOWD
            ? 'You don\t have permission to access this page'
            : 'Page does not exist or unusable'}
        </p>
        <p>
          {pageType === ERROR_PAGE.NOT_ALLOWD
            ? 'Please request permission and try again'
            : 'Please check if you entered the right page address'}
        </p>
      </div>
    </Box>
  );
};

export default NotFoundPage;
