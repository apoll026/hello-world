import { ButtonGroup, Spacer } from '@/amxis/components/layout';
import {
  Avatar,
  Button,
  DataGridCellLink,
  DetailTableDataCell,
  DetailTableHeaderCell,
  DetailTableLine,
  DetailTableRow,
  Dialog,
  Divider,
  FileUploaderReadonly,
  Label,
  TitleArea,
  useTheme,
} from '@amxis/design-system';
import { Box, Card, CardContent, DialogTitle, Typography } from '@mui/material';
import { t } from 'i18next';
import SampleDummyImage from '@/amxis/pages/sample/popup/__images/sample-dummy-image.png';
import {
  DeviceMobileIcon,
  FunctionCallIcon,
  FunctionMailIcon,
  NotificationLayerIcon,
} from '@amxis/design-system/icon';

interface EmployeeCardProps {
  open: boolean;
  onClose: () => void;
  ofcPhn?: string;
  empHphn?: string;
  emlDmnIfoNm?: string;
  empName?: string;
  deptNm?: string;
  empNo?: string;
}

const EmployeeCard = ({
  open,
  onClose,
  ofcPhn,
  empHphn,
  emlDmnIfoNm,
  empName,
  deptNm,
  empNo,
}: EmployeeCardProps) => {
  const [theme] = useTheme();

  const [
    {
      palette: { semantic },
    },
  ] = useTheme();

  return (
    <Box>
      <Dialog
        position="basic"
        type={'modal'}
        size={400}
        open={open}
        customHeaderTitle={
          <DialogTitle
            sx={{
              position: 'relative',
              fontSize: '18px',
              padding: 0,
            }}
          >
            <Box display="flex" gap="8px" alignContent="center">
              <Typography fontSize="16px" fontWeight={700} color="#1B1D22" lineHeight="24px">
                {empName}
              </Typography>
              <Typography fontSize="13px" fontWeight={400} color="#464C5A" lineHeight="24.5px">
                {deptNm}
              </Typography>
            </Box>
          </DialogTitle>
        }
        customContentArea={
          <Box>
            <Box display="flex">
              <Card
                sx={{
                  width: '136px',
                  height: '100%',
                  backgroundColor: 'transparent',
                  boxShadow: 'none',
                  border: 'none',
                }}
              >
                <CardContent
                  sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    padding: '0 !important',
                  }}
                >
                  <Box
                    width="136px"
                    height="165px"
                    sx={{
                      background: SampleDummyImage,
                      backgroundSize: 'contain',
                      backgroundPosition: 'center',
                    }}
                  />
                </CardContent>
              </Card>
              <Box marginLeft="15px" display="flex" flexDirection="column" gap="8px">
                <Box
                  sx={{
                    padding: '10px',
                    background: '#F7F7F8',
                    borderRadius: '4px',
                    display: 'flex',
                    gap: '5px',
                    width: '200px',
                  }}
                >
                  <FunctionMailIcon
                    appearance="filled"
                    sx={{ color: semantic.color.commonTextBasic }}
                  />
                  <Typography fontSize="13px" fontWeight={400} color="#1B1D22">
                    {emlDmnIfoNm}
                  </Typography>
                </Box>
                <Box
                  sx={{
                    padding: '10px',
                    background: '#F7F7F8',
                    borderRadius: '4px',
                    display: 'flex',
                    gap: '5px',
                    width: '200px',
                  }}
                >
                  <FunctionCallIcon
                    appearance="filled"
                    sx={{ color: semantic.color.commonTextBasic }}
                  />
                  <Typography fontSize="13px" fontWeight={400} color="#1B1D22">
                    {ofcPhn}
                  </Typography>
                </Box>
                <Box
                  sx={{
                    padding: '10px',
                    background: '#F7F7F8',
                    borderRadius: '4px',
                    display: 'flex',
                    gap: '5px',
                    width: '200px',
                  }}
                >
                  <DeviceMobileIcon
                    appearance="filled"
                    sx={{ color: semantic.color.commonTextBasic }}
                  />
                  <Typography fontSize="13px" fontWeight={400} color="#1B1D22">
                    {empHphn}
                  </Typography>
                </Box>
              </Box>
            </Box>
          </Box>
        }
        handleClose={onClose}
      />
    </Box>
  );
};

export default EmployeeCard;
