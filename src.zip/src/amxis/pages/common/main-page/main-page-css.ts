export const cardBackgrounds = {
  ORANGE: `radial-gradient(
    125.79% 170.25% at -4.83% 107.83%, 
    rgba(247, 207, 134, 0.6) 0%,     
    rgba(247, 207, 134, 0.0) 100%  
  ),
  linear-gradient(90deg, #EF4912 0%, #FF853F 100%)`,
  BLUE: `radial-gradient(
    117.97% 153.07% at -5.38% 104.32%,
    rgba(134, 235, 247, 0.8) 0%,  
    rgba(134, 235, 247, 0.0) 99.97% 
  ),
  linear-gradient(90deg, #3B9DA8 0.13%, #50B0E4 100.13%)`,
};
