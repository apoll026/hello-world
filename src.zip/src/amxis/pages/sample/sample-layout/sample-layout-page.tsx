import { ContainerLayout } from '@/amxis/components/container-layout';
import { Box } from '@mui/system';
import { ContainerBox } from '../__components/container-box';
import { DocumentContentH2 } from '../__components/document-content-h2';
import { DocumentContentH3 } from '../__components/document-content-h3';
import { SamplePageTitle } from '../__components/sample-page-title';
import { Button } from '@amxis/design-system';
import OpenInNewRoundedIcon from '@mui/icons-material/OpenInNewRounded';
import { Typography } from '@mui/material';

function SampleLayoutPagePopup() {
  const handleNewWindowOpen = (url: string) => {
    const popup = window.open(
      url,
      'contentPopup',
      `width=1200,
       height=600,
       left=${(screen.width - 1200) / 2},
       top=${(screen.height - 600) / 2},
       location=no,      // 주소창 숨김
       menubar=no,       // 메뉴바 숨김
       toolbar=no,       // 툴바 숨김
       status=no,        // 상태바 숨김
       scrollbars=yes,   // 스크롤바 표시
       resizable=yes,    // 크기 조절 가능
       directories=no,   // 디렉토리 버튼 숨김
       titlebar=no` // 타이틀바 숨김 (일부 브라우저)
    );

    if (popup) {
      popup.focus();
    }
  };

  return (
    <>
      <ContainerBox>
        <ContainerLayout>
          <SamplePageTitle>공통팝업</SamplePageTitle>
          <Box mt="48px">
            <DocumentContentH2 title="전자전표 새탭탭">
              Left, Header를 모두 포함하는 시스템 링크와 동일한 방식이다.
            </DocumentContentH2>
            <Box mt="24px">
              <DocumentContentH3 title="" />
              <Box mt="16px">
                <Button
                  size="large"
                  appearance="contained"
                  priority="normal"
                  iconPosition="trailing"
                  iconComponent={<OpenInNewRoundedIcon />}
                  onClick={() => handleNewWindowOpen('https://deveas.gsenc.com/sample/components')}
                >
                  새 탭
                </Button>
              </Box>
            </Box>
          </Box>
          <Box mt="48px">
            <DocumentContentH2 title="컨텐츠 영역 팝업" />
            <Box mt="16px">
              <Button
                size="large"
                appearance="contained"
                priority="normal"
                iconPosition="trailing"
                iconComponent={<OpenInNewRoundedIcon />}
                onClick={() => handleNewWindowOpen('http://localhost:3000/sample/nolayout')}
              >
                컨텐츠 영역 팝업
              </Button>
            </Box>
            <DocumentContentH3 title="PopLayout" />
            <Typography variant="body2" sx={{ whiteSpace: 'pre-wrap' }}>
              {'헤더와 left 메뉴를 제외,컨텐츠 area만 띄우려면 Router에서 다음과 같은 layout을 사용합니다.' +
                '\n <Route path="/sample" element={<PopupLayouts />}>' +
                '\n     <Route path="nolayout" element={<SampleMenu />} />' +
                '\n </Route>'}
            </Typography>
          </Box>
        </ContainerLayout>
      </ContainerBox>
    </>
  );
}
export { SampleLayoutPagePopup };
