import { Box, Divider, Typography } from '@mui/material';
import { FileInfoType, FileUploader, FileUploaderReadonly } from '@amxis/design-system';
import { useState } from 'react';

export const SampleFileUploader = () => {
  const [selectedFiles1, setSelectedFiles1] = useState<FileInfoType[]>([]);
  const handleFileOnChange1 = (files: FileInfoType[]) => {
    setSelectedFiles1(files);
  };
  const [selectedFiles2, setSelectedFiles2] = useState<FileInfoType[]>([]);
  const handleFileOnChange2 = (files: FileInfoType[]) => {
    setSelectedFiles2(files);
  };
  const [selectedFiles3, setSelectedFiles3] = useState<FileInfoType[]>([]);
  const handleFileOnChange3 = (files: FileInfoType[]) => {
    setSelectedFiles3(files);
  };

  return (
    <Box my="24px">
      <Typography variant="h2">File Uploader - Default</Typography>
      <Box sx={{ my: 1 }} />
      <FileUploader
        variant="default"
        acceptFiles={['.pdf', '.svg', '.png', '.jpg']}
        selectedFiles={selectedFiles1}
        onFileChange={handleFileOnChange1}
      />

      <Divider sx={{ my: 2 }} />
      <Typography variant="h2">File Uploader - Readonly</Typography>
      <Box sx={{ my: 1 }} />
      <FileUploaderReadonly
        onFileClick={(_fileName: string, _fileUrl: string) => {}}
        selectedFiles={[
          { name: 'aaaaaaaaaaa.pdf', size: 12344, url: '' },
          { name: 'bbbbbbbbbbbb.pdf', size: 2345, url: '' },
          { name: 'cccccccccccc.pdf', size: 345636, url: '' },
          { name: 'dddddddddddddd.pdf', size: 234, url: '' },
        ]}
      />

      <Divider sx={{ my: 2 }} />
      <Typography variant="h2">File Uploader - Thumbnail</Typography>
      <Box sx={{ my: 1 }} />
      <FileUploader
        variant="thumbnail"
        acceptFiles={['.pdf', '.svg', '.png', '.jpg']}
        selectedFiles={selectedFiles2}
        onFileChange={handleFileOnChange2}
      />

      <Divider sx={{ my: 2 }} />
      <Typography variant="h2">File Uploader - Namo</Typography>
      <Box sx={{ my: 1 }} />
      <FileUploader
        variant="namo"
        acceptFiles={['.pdf', '.svg', '.png', '.jpg']}
        selectedFiles={selectedFiles3}
        onFileChange={handleFileOnChange3}
      />
    </Box>
  );
};
