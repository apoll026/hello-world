import React, { useEffect, useRef, useState } from 'react';
import { Box, IconButton, Typography, useTheme } from '@mui/material';
import { $scale, $semantic } from '@amxis/design-system/design-token';
import {
  OptionListItemType,
  Card,
  CardContent,
  CardActions,
  CardMedia,
  Button,
  CardHeader,
  Avatar,
  EngagementAction,
  Tag,
  Chip,
  Switch,
  Divider,
  CardListProps,
  CardList,
  OptionListItem,
  KanbanCard,
  KanbanCardTagLabel,
} from '@amxis/design-system';
import {
  CommunicationLikeIcon,
  ControlAddIcon,
  ControlRefreshIcon,
  ControlZoomIcon,
  FileCopyIcon,
  FileShareIcon,
  MenuMoreIcon,
} from '@amxis/design-system/icon';
import avatarSrc from '@/amxis/assets/icons/avatarSingleContents.svg';

export const SampleCard = () => {
  const DUMMY_TEXT = `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eu diam vel felis
              pharetra sagittis. Fusce ultrices sodales eros id feugiat. Integer posuere ex sit amet
              lacus dapibus, sit amet venenatis nisl condimentum. Suspendisse quis sapien id ex
              dapibus commodo. Nullam condimentum ante a ligula aliquam luctus. Cras nec lobortis
              libero. In in neque tincidunt, ultrices urna nec, lacinia justo. Donec eget metus eu
              ex aliquet iaculis in at diam. Nulla eu justo eu est consequat sollicitudin. Sed
              mattis odio sed rutrum condimentum.`;
  const ACTION_MENU_ITMES: OptionListItemType[] = [
    { label: '새로고침', value: '새로고침' },
    { label: '설정', value: '설정' },
  ];
  const CHIP_LABELS: string[] = [
    '기술',
    '트렌트',
    'UX',
    'DataDriven',
    'CX',
    'DesignOps',
    '운영자보세요',
  ];
  const TAG_ITEMS: KanbanCardTagLabel[] = [
    { label: 'keyword', colorType: 'colorA' },
    { label: 'keyword', colorType: 'colorB' },
    { label: 'keyword', colorType: 'colorC' },
  ];
  const sizesCommon = $semantic.shared.size.sizesCommon;
  const theme = useTheme();
  const color = theme.palette.semantic.color;

  // SummaryCard1
  const [selected1, setSelected1] = useState<boolean>(false);
  const mainTextBox = useRef<HTMLParagraphElement>();
  const handleHeaderButtonOnClick = () => {
    navigator.clipboard
      .writeText(`${mainTextBox.current?.textContent}`)
      .then(() => alert('copied!'))
      .catch((e) => console.log(e));
  };

  // SummaryCard2
  const [selected2, setSelected2] = useState<boolean>(false);
  const [value2, setValue2] = useState<number>(12);

  // SummaryCard3
  const [selected3, setSelected3] = useState<boolean>(false);
  const [value3, setValue3] = useState<number>(12);

  // SummaryCard5
  const chipLabels: string[] = [];
  for (let i = 1; i <= 5; i++) {
    chipLabels.push(`Keyword ${i}`);
  }

  // SummaryCard6
  const [switchState, setSwitchState] = useState<boolean>(true);

  // SummaryCard7
  const [selected7, setSelected7] = useState<boolean>(false);
  const [value7, setValue7] = useState<number>(12);

  // ListCard1,2
  const listItems1: CardListProps[] = [];
  for (let i = 0; i < 4; i++) {
    listItems1.push({
      title: `타이틀 영역입니다 ${i + 1}`,
      contents: '컨텐츠 영역입니다. 내용을 입력해주세요.',
      onClick: () => {
        alert(`click ${i + 1}`);
      },
    });
  }

  // ListCard3
  const [listItems2, setListItems] = useState<OptionListItemType[]>([]);
  useEffect(() => {
    const items: OptionListItemType[] = [];
    for (let i = 0; i < 6; i++) {
      items.push({
        label: `Item${i + 1}`,
        value: `${i + 1}`,
        selected: false,
      });
    }
    setListItems(items);
  }, []);
  const handleClickAddItem = () => {
    const newItems: OptionListItemType[] = [];
    const nextIndex = listItems2.length + 1;
    listItems2.forEach((item) => newItems.push({ ...item }));
    newItems.push({ label: `Item${nextIndex}`, value: `${nextIndex}` });
    setListItems(newItems);
  };
  const handleClick = (key: string) => {
    setListItems(
      listItems2.map((item) => (key === item.label ? { ...item, selected: !item.selected } : item))
    );
  };

  return (
    <Box mx="20px" my="10px">
      <Box my="20px" />

      <Typography variant="h4">SummaryCard1</Typography>
      <Box my="20px" />
      <Card sx={{ width: '374px', boxShadow: $semantic.shared.boxShadow.elevationDepth2 }}>
        <CardHeader
          title="Primary Title - Header"
          subheader="Subhead Text"
          language="en"
          listItemsCount={30}
          count={true}
          leadingContainer={true}
          avatar={<Avatar size="large" contentType="image" src={avatarSrc} />}
          button={true}
          buttonIcon={<FileCopyIcon appearance="lined" />}
          function={true}
          functionItems={ACTION_MENU_ITMES}
          buttonOnClick={handleHeaderButtonOnClick}
        />
        <CardMedia component="img" image="/images/card-image-8.jpg" sx={{ height: '160px' }} />
        <CardContent
          sx={{
            display: 'flex',
            margin: `${sizesCommon.size10}px 0`,
            padding: `0 ${sizesCommon.size16}px`,
          }}
        >
          <Box ref={mainTextBox}>
            <Typography typography="bodyBasic">
              Supporting text goes here. Supporting text goes here. Supporting text goes here.
            </Typography>
          </Box>
        </CardContent>
        <CardActions
          sx={{
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'space-between',
            height: `${sizesCommon.size44}px`,
            marginBottom: `${sizesCommon.size4}px`,
            padding: `0 ${sizesCommon.size8}px 0 0`,
          }}
        >
          <Box display="flex" justifyContent="center" alignItems="center" margin={0} padding={0}>
            <Box
              display="flex"
              justifyContent="center"
              alignItems="center"
              height={`${sizesCommon.size44}px`}
              padding={`${sizesCommon.size8}px`}
            >
              <Button appearance="unfilled" sx={{ padding: 0 }}>
                Action 1
              </Button>
            </Box>
            <Box className="button-box">
              <Button appearance="unfilled" sx={{ padding: 0 }}>
                Action 2
              </Button>
            </Box>
          </Box>
          <Box display="flex" justifyContent="center" alignItems="center" margin={0} padding={0}>
            <Box
              display="flex"
              justifyContent="cetner"
              alignItems="cetner"
              width={`${sizesCommon.size44}px`}
              height={`${sizesCommon.size44}px`}
            >
              <IconButton
                onClick={() => {
                  setSelected1(!selected1);
                }}
                sx={{
                  color: selected1 ? color.commonTextColorD : color.commonTextBasic,
                }}
              >
                {selected1 ? (
                  <CommunicationLikeIcon appearance="filled" iconSize={24} />
                ) : (
                  <CommunicationLikeIcon appearance="lined" iconSize={24} />
                )}
              </IconButton>
            </Box>
            <Box
              display="flex"
              justifyContent="cetner"
              alignItems="cetner"
              width={`${sizesCommon.size44}px`}
              height={`${sizesCommon.size44}px`}
            >
              <IconButton sx={{ color: color.commonTextBasic }}>
                <FileShareIcon appearance="lined" iconSize={24} />
              </IconButton>
            </Box>
          </Box>
        </CardActions>
      </Card>
      <Box my="20px" />
      <Typography variant="h4">SummaryCard2</Typography>
      <Box my="20px" />
      <Card sx={{ width: '312px', height: '246px' }}>
        <CardHeader title="카드 타이틀" sx={{ height: `${sizesCommon.size62}px` }} />
        <CardContent
          sx={{
            padding: `0 ${sizesCommon.size20}px`,
            display: 'flex',
            gap: `${sizesCommon.size12}px`,
            flex: 1,
            flexDirection: 'column',
            minHeight: 0,
            color: color.commonTextLight,
            ':last-child': { paddingBottom: `${sizesCommon.size20}px` },
          }}
        >
          <Typography
            sx={{
              display: '-webkit-box',
              textOverflow: 'ellipsis',
              overflow: 'hidden',
              WebkitBoxOrient: 'vertical',
              flexDirection: 'column',
              WebkitLineClamp: '6',
            }}
          >
            {DUMMY_TEXT}
          </Typography>
          <CardActions sx={{ justifyContent: 'space-between', padding: 0 }}>
            <Box display="flex" gap={`${sizesCommon.size10}px`}>
              <EngagementAction
                type="like"
                value={value2}
                selected={selected2}
                onActionClick={(_, newSelected, newValue) => {
                  setSelected2(newSelected);
                  setValue2(newValue);
                }}
              />
              <EngagementAction type="replies" value={103} onActionClick={() => {}} />
            </Box>
            <Box display="flex" gap={`${sizesCommon.size10}px`}>
              <IconButton
                sx={{
                  width: `${sizesCommon.size32}px`,
                  height: `${sizesCommon.size32}px`,
                  padding: `${sizesCommon.size6}px`,
                  alignSelf: 'center',
                  color: color.commonTextLight,
                }}
              >
                <FileShareIcon appearance="lined" iconSize={20} />
              </IconButton>
              <IconButton
                sx={{
                  width: `${sizesCommon.size32}px`,
                  height: `${sizesCommon.size32}px`,
                  padding: `${sizesCommon.size6}px`,
                  alignSelf: 'center',
                  color: color.commonTextLight,
                }}
              >
                <MenuMoreIcon direction="vertical" iconSize={20} />
              </IconButton>
            </Box>
          </CardActions>
        </CardContent>
      </Card>
      <Box my="20px" />
      <Typography variant="h4">SummaryCard3</Typography>
      <Box my="20px" />
      <Card sx={{ width: '316px', borderRadius: $scale.radius.radius100 }}>
        <CardMedia component="img" height="240px" image="/images/card-image-5.jpg" />
        <CardContent
          sx={{
            display: 'flex',
            gap: `${sizesCommon.size4}px`,
            padding: `${sizesCommon.size20}px`,
            flexDirection: 'column',
            ':last-child': { paddingBottom: `${sizesCommon.size20}px` },
          }}
        >
          <Typography
            fontFamily={$semantic.shared.typography.fontFamilyBasic}
            fontWeight={$semantic.shared.typography.fontWeightBold}
            fontSize={$semantic.shared.typography.fontSizeXlarge}
            color={color.commonTextBasic}
          >
            카드 타이틀
          </Typography>
          <Typography
            color={color.commonTextLight}
            sx={{
              display: '-webkit-box',
              textOverflow: 'ellipsis',
              overflow: 'hidden',
              WebkitBoxOrient: 'vertical',
              flexDirection: 'column',
              WebkitLineClamp: '2',
            }}
          >
            {DUMMY_TEXT}
          </Typography>
          <CardActions
            sx={{
              display: 'flex',
              flexDirection: 'row',
              justifyContent: 'space-between',
              padding: 0,
            }}
          >
            <Box display="flex" gap={`${sizesCommon.size10}px`}>
              <EngagementAction
                type="like"
                value={value3}
                selected={selected3}
                onActionClick={(_, newSelected, newValue) => {
                  setSelected3(newSelected);
                  setValue3(newValue);
                }}
              />
              <EngagementAction type="replies" value={103} onActionClick={() => {}} />
            </Box>
            <Box display="flex" gap={`${sizesCommon.size10}px`}>
              <IconButton
                sx={{
                  width: `${sizesCommon.size32}px`,
                  height: `${sizesCommon.size32}px`,
                  padding: `${sizesCommon.size6}px`,
                  alignSelf: 'center',
                  color: color.commonTextLight,
                }}
              >
                <FileShareIcon appearance="lined" iconSize={20} />
              </IconButton>
              <IconButton
                sx={{
                  width: `${sizesCommon.size32}px`,
                  height: `${sizesCommon.size32}px`,
                  padding: `${sizesCommon.size6}px`,
                  alignSelf: 'center',
                  color: color.commonTextLight,
                }}
              >
                <MenuMoreIcon direction="vertical" iconSize={20} />
              </IconButton>
            </Box>
          </CardActions>
        </CardContent>
      </Card>
      <Box my="20px" />
      <Typography variant="h4">SummaryCard4</Typography>
      <Box my="20px" />
      <Card sx={{ width: '316px', borderRadius: $scale.radius.radius50 }}>
        <CardHeader title={'카드 타이틀'} />
        <CardContent
          sx={{
            display: 'flex',
            alignItems: 'flex-end',
            justifyContent: 'flex-end',
            gap: `${sizesCommon.size8}px`,
            padding: `0 ${sizesCommon.size20}px 
              ${sizesCommon.size20}px ${sizesCommon.size20}px`,
            ':last-child': { paddingBottom: `${sizesCommon.size20}px` },
          }}
        >
          <Typography
            display="flex"
            fontSize={$scale.typography.fontSize900}
            fontWeight={$semantic.shared.typography.fontWeightBold}
            lineHeight={$scale.typography.lineHeight100}
            color={color.commonTextPrimary}
          >
            2,148
          </Typography>
          <Typography
            display="flex"
            fontSize={$scale.typography.fontSize400}
            lineHeight={$scale.typography.lineHeight300}
            color={color.commonTextLighter}
          >
            명
          </Typography>
        </CardContent>
      </Card>

      <Box my="20px" />
      <Typography variant="h4">SummaryCard5</Typography>
      <Box my="20px" />

      <Card sx={{ width: '316px' }}>
        <CardContent
          sx={{
            display: 'flex',
            padding: `${sizesCommon.size24}px ${sizesCommon.size20}px`,
            flexDirection: 'column',
            ':last-child': { paddingBottom: `${sizesCommon.size20}px` },
          }}
        >
          <Box
            display="flex"
            flexWrap="nowrap"
            marginBottom={`${sizesCommon.size10}px`}
            alignItems="center"
            justifyContent="space-between"
          >
            <Typography typography="h1" color={color.commonTextBasic}>
              01
            </Typography>
            <Tag colorType="confirmed" appearance="boxing" children="Status" />
          </Box>
          <Box height={`${sizesCommon.size66}px`} marginBottom={`${sizesCommon.size12}px`}>
            <Typography typography="h1" color={color.commonTextBasic}>
              카드 타이틀
            </Typography>
          </Box>
          <Box
            display="flex"
            gap={`${sizesCommon.size8}px ${sizesCommon.size4}px`}
            flexWrap="wrap"
            padding={`${sizesCommon.size2}px 0`}
            marginBottom={`${sizesCommon.size10}px`}
          >
            {chipLabels.map((labelText, index) => (
              <Chip size="small" type="filter" chipText={labelText} key={`${index}_${labelText}`} />
            ))}
          </Box>
          <Box display="flex" minWidth={0} justifyContent="flex-end" gap={`${sizesCommon.size4}px`}>
            <Avatar size="xxsmall" contentType="image" src={avatarSrc} />
            <Typography
              typography="bodySmall"
              color={color.commonTextLight}
              display="flex"
              alignItems="center"
            >
              홍길동 책임
            </Typography>
          </Box>
        </CardContent>
      </Card>

      <Box my="20px" />
      <Typography variant="h4">SummaryCard6</Typography>
      <Box my="20px" />

      <Card
        sx={{
          width: '316px',
          boxShadow: 'none',
          borderRadius: $semantic.shared.radius.radiusRounded,
          background: 'linear-gradient(to right, rgba(45, 155, 178, 1), rgba(62, 194, 207, 1))',
        }}
      >
        <CardContent
          sx={{
            flexDirection: 'column',
            color: $scale.color.white,
            padding: `${sizesCommon.size20}px`,
            ':last-child': { paddingBottom: `${sizesCommon.size20}px` },
          }}
        >
          <Typography
            fontWeight={$semantic.shared.typography.fontWeightMedium}
            height={`${sizesCommon.size20}px`}
          >
            Total Balance
          </Typography>
          <Box
            display="flex"
            gap={`${sizesCommon.size8}px`}
            marginBottom={`${sizesCommon.size32}px`}
          >
            <Typography fontSize={$semantic.shared.typography.fontSizeH2}>$</Typography>
            <Typography
              fontSize={$scale.typography.fontSize900}
              lineHeight={`${sizesCommon.size40}px`}
            >
              912,000.12
            </Typography>
          </Box>
          <CardActions sx={{ display: 'flex', justifyContent: 'space-between', padding: 0 }}>
            <Box
              display="flex"
              alignItems="center"
              gap={`${sizesCommon.size8}px`}
              color={$scale.color.white}
            >
              <Switch
                disableRipple
                checked={switchState}
                onChange={() => setSwitchState(!switchState)}
                sx={{
                  '& > .MuiSwitch-colorPrimary': {
                    '&.MuiSwitch-switchBase.Mui-checked+.MuiSwitch-track': {
                      background: $scale.color.black,
                    },
                    '&.MuiSwitch-switchBase': {
                      '&.Mui-checked .MuiSwitch-thumb': {
                        border: `${sizesCommon.size2}px solid ${$scale.color.white}`,
                      },
                      '.MuiSwitch-thumb': {
                        border: `${sizesCommon.size2}px solid `,
                        background: $scale.color.white,
                      },
                    },
                  },
                  '& > .MuiSwitch-track': {
                    background: $scale.color.black,
                  },
                }}
              />
              <Typography>{switchState ? 'On' : 'Off'}</Typography>
            </Box>
            <Box display="flex" gap={`${sizesCommon.size10}px`}>
              <IconButton
                sx={{
                  width: `${sizesCommon.size32}px`,
                  height: `${sizesCommon.size32}px`,
                  padding: `${sizesCommon.size6}px`,
                  alignSelf: 'center',
                  color: $scale.color.white,
                }}
              >
                <ControlRefreshIcon size="default" iconSize={20} />
              </IconButton>
              <IconButton
                sx={{
                  width: `${sizesCommon.size32}px`,
                  height: `${sizesCommon.size32}px`,
                  padding: `${sizesCommon.size6}px`,
                  alignSelf: 'center',
                  color: $scale.color.white,
                }}
              >
                <ControlZoomIcon type="zoom-in" iconSize={20} />
              </IconButton>
            </Box>
          </CardActions>
        </CardContent>
      </Card>

      <Box my="20px" />
      <Typography variant="h4">SummaryCard7</Typography>
      <Box my="20px" />

      <Card sx={{ width: '701px' }}>
        <CardHeader
          title="홍길동 책임"
          subheader="제조PI 센터"
          leadingContainer={true}
          avatar={<Avatar size="large" contentType="image" src={avatarSrc} />}
          button={true}
          buttonIcon={<FileCopyIcon appearance="lined" />}
          buttonOnClick={() => {}}
          function={true}
          functionItems={ACTION_MENU_ITMES}
        />
        <CardContent
          sx={{
            display: 'flex',
            flexDirection: 'column',
            gap: `${sizesCommon.size4}px`,
            padding: `0 ${sizesCommon.size20}px
              ${sizesCommon.size20}px ${sizesCommon.size20}px`,
            ':last-child': { paddingBottom: `${sizesCommon.size20}px` },
          }}
        >
          <Box
            display="flex"
            marginBottom={`${sizesCommon.size6}px`}
            gap={`${sizesCommon.size4}px`}
            padding={`${sizesCommon.size2}px 0`}
          >
            {CHIP_LABELS.map((label, index) => (
              <Chip type="action" chipText={`#${label}`} key={index} />
            ))}
          </Box>
          <Typography
            typography="h1"
            lineHeight={`${sizesCommon.size33}px`}
            display="-webkit-box"
            textOverflow="ellipsis"
            overflow="hidden"
            sx={{ WebkitBoxOrient: 'vertical', WebkitLineClamp: '2' }}
          >
            최근 발표된 Gartner의 UX/CX/EX Trend를 요약정리해봅니다. 글자가 길어지면 최대 두 줄 까지
            나오고 나머지는 상세에서 볼 수 있도록
          </Typography>
          <Typography
            display="-webkit-box"
            color={color.commonTextLight}
            textOverflow="ellipsis"
            overflow="hidden"
            sx={{ WebkitBoxOrient: 'vertical', WebkitLineClamp: '2', lineBreak: 'break-word' }}
          >
            {DUMMY_TEXT}
          </Typography>
          <CardActions
            sx={{
              display: 'flex',
              flexDirection: 'row',
              justifyContent: 'space-between',
              padding: 0,
            }}
          >
            <Box display="flex" gap={`${sizesCommon.size24}px`}>
              <EngagementAction
                type="like"
                value={value7}
                selected={selected7}
                onActionClick={(_, newSelected, newValue) => {
                  setSelected7(newSelected);
                  setValue7(newValue);
                }}
              />
              <EngagementAction type="replies" value={103} onActionClick={() => {}} />
              <EngagementAction type="viewed" value={112345} onActionClick={() => {}} />
            </Box>
            <Box margin={0}>
              <IconButton
                sx={{
                  width: `${sizesCommon.size32}px`,
                  height: `${sizesCommon.size32}px`,
                  padding: `${sizesCommon.size6}px`,
                  alignSelf: 'center',
                  color: color.commonTextLight,
                }}
              >
                <FileShareIcon appearance="lined" iconSize={20} />
              </IconButton>
            </Box>
          </CardActions>
        </CardContent>
      </Card>

      <Box my="20px" />
      <Typography variant="h4">SummaryCard8</Typography>
      <Box my="20px" />

      <Box display="flex" flexDirection="column" width="428px" gap={`${sizesCommon.size8}px`}>
        <Divider />
        <Card sx={{ boxShadow: 'none', backgroundColor: 'transparent', border: 'none' }}>
          <CardContent
            sx={{
              display: 'flex',
              flexDirection: 'row',
              gap: `${sizesCommon.size16}px`,
              padding: `0 ${sizesCommon.size8}px`,
              ':last-child': { paddingBottom: 0 },
            }}
          >
            <Box
              width={`${sizesCommon.size48}px`}
              height={`${sizesCommon.size48}px`}
              borderRadius={$scale.radius.radius100}
              sx={{ backgroundImage: 'url("/images/card-image-3.jpg")', backgroundSize: 'cover' }}
            />
            <Box
              display="flex"
              gap={`${sizesCommon.size4}px`}
              flexDirection="column"
              justifyContent="center"
              flex="1"
              sx={{
                '.ellipsis': {
                  display: '-webkit-box',
                  textOverflow: 'ellipsis',
                  overflow: 'hidden',
                  WebkitBoxOrient: 'vertical',
                  flexDirection: 'column',
                  WebkitLineClamp: '1',
                },
              }}
            >
              <Typography
                className="ellipsis"
                fontWeight={$semantic.shared.typography.fontWeightBold}
                fontSize={$semantic.shared.typography.fontSizeXlarge}
                color={color.commonTextBasic}
                lineHeight={`${sizesCommon.size20}px`}
              >
                카드타이틀 텍스트 카드타이틀 텍스트 카드타이틀 텍스트
              </Typography>
              <Typography
                className="ellipsis"
                fontSize={$semantic.shared.typography.fontSizeSmall}
                color={color.commonTextLighter}
                lineHeight={`${sizesCommon.size18}px`}
              >
                카드 서브 텍스트 카드 서브 텍스트 카드 서브텍스트 카드 서브 텍스트
              </Typography>
            </Box>
            <IconButton
              sx={{
                width: `${sizesCommon.size32}px`,
                height: `${sizesCommon.size32}px`,
                padding: `${sizesCommon.size6}px`,
                alignSelf: 'center',
                color: color.commonTextLight,
              }}
            >
              <MenuMoreIcon direction="vertical" iconSize={20} />
            </IconButton>
          </CardContent>
        </Card>
        <Divider />
      </Box>

      <Box my="20px" />
      <Typography variant="h4">FilledImageCard1</Typography>
      <Box my="20px" />

      <Card
        sx={{
          width: '248px',
          height: '296px',
          backgroundColor: 'transparent',
          boxShadow: 'none',
          border: 'none',
        }}
      >
        <CardContent
          sx={{
            display: 'flex',
            gap: `${sizesCommon.size8}px`,
            flexDirection: 'column',
            padding: 0,
          }}
        >
          <Box
            width="248px"
            height="248px"
            borderRadius={$semantic.shared.radius.radiusRounded}
            sx={{ backgroundImage: 'url("/images/card-image-3.jpg")' }}
          />
          <Box
            sx={{
              '.ellipsis': {
                display: '-webkit-box',
                textOverflow: 'ellipsis',
                overflow: 'hidden',
                WebkitBoxOrient: 'vertical',
                flexDirection: 'column',
                WebkitLineClamp: '1',
              },
            }}
          >
            <Typography
              className="ellipsis"
              fontWeight={$semantic.shared.typography.fontWeightBold}
              fontSize={$semantic.shared.typography.fontSizeH5}
              color={color.commonTextBasic}
            >
              카드 타이틀 카드 타이틀 카드 타이틀 카드 타이틀
            </Typography>
            <Typography className="ellipsis" color={color.commonTextLighter}>
              카드 서브 텍스트 카드 서브 텍스트 카드 서브 텍스트
            </Typography>
          </Box>
        </CardContent>
      </Card>

      <Box my="20px" />
      <Typography variant="h4">FilledImageCard2</Typography>
      <Box my="20px" />

      <Card
        sx={{
          boxShadow: 'none',
          backgroundColor: 'transparent',
          width: '316px',
          height: '250px',
          border: 'none',
        }}
      >
        <CardContent
          sx={{
            display: 'flex',
            gap: `${sizesCommon.size8}px`,
            flexDirection: 'column',
            padding: 0,
          }}
        >
          <Box>
            <Typography
              typography="h2"
              lineHeight={$scale.typography.lineHeight300}
              color={color.commonTextBasic}
            >
              카드 타이틀
            </Typography>
            <Typography color={color.commonTextLighter}>카드 서브 텍스트</Typography>
          </Box>
          <Box
            display="flex"
            width="316px"
            height="197px"
            borderRadius={`${sizesCommon.size8}px`}
            sx={{ backgroundImage: 'url("/images/card-image-3.jpg")', backgroundSize: 'cover' }}
          >
            <Box
              display="flex"
              alignItems="flex-end"
              marginTop="100px"
              padding={`0 ${sizesCommon.size20}px
                ${sizesCommon.size8}px ${sizesCommon.size20}px`}
              width="100%"
              borderRadius="inherit"
              color={$scale.color.white}
              sx={{
                background:
                  'linear-gradient(to bottom, rgba(0,0,0,0), rgba(0,0,0,0.5), rgba(0,0,0,0.7))',
              }}
            >
              <Typography>
                카드 서브 텍스트 카드 서브 텍스트 카드 서브 텍스트 카드 서브 텍스트
              </Typography>
            </Box>
          </Box>
        </CardContent>
      </Card>

      <Box my="20px" />
      <Typography variant="h4">FilledImageCard3</Typography>
      <Box my="20px" />

      <Card
        sx={{
          width: '316px',
          height: '200px',
          border: 'none',
          borderRadius: $scale.radius.radius100,
          boxShadow: $semantic.shared.boxShadow.elevationDepth1,
          display: 'flex',
          alignItems: 'flex-end',
          backgroundImage: 'url("/images/card-image-7.jpg")',
        }}
      >
        <CardContent
          sx={{
            height: '50%',
            display: 'flex',
            padding: `0 ${sizesCommon.size20}px ${sizesCommon.size20}px ${sizesCommon.size20}px`,
            background:
              'linear-gradient(to bottom, rgba(0,0,0,0), rgba(0,0,0,0.5), rgba(0,0,0,0.7))',
            ':last-child': { paddingBottom: `${sizesCommon.size20}px` },
          }}
        >
          <Box
            display="flex"
            alignSelf="flex-end"
            flexDirection="column"
            gap={$semantic.shared.radius.radiusRounded}
            fontFamily={$semantic.shared.typography.fontFamilyBasic}
            color={$scale.color.white}
          >
            <Typography typography="h2" color={$scale.color.white}>
              카드 타이틀
            </Typography>
            <Typography
              sx={{
                display: '-webkit-box',
                textOverflow: 'ellipsis',
                overflow: 'hidden',
                WebkitBoxOrient: 'vertical',
                flexDirection: 'column',
                WebkitLineClamp: '2',
              }}
            >
              {DUMMY_TEXT}
            </Typography>
          </Box>
        </CardContent>
      </Card>

      <Box my="20px" />
      <Typography variant="h4">ListCard1</Typography>
      <Box my="20px" />

      <Card sx={{ width: '392px', borderRadius: '3px' }}>
        <CardHeader
          title="리스트 타이틀"
          count={true}
          listItemsCount={listItems1.length}
          button={true}
          buttonIcon={<FileCopyIcon appearance="lined" />}
          buttonOnClick={() => {}}
          function={true}
          functionItems={ACTION_MENU_ITMES}
        />
        <CardContent
          sx={{
            display: 'flex',
            padding: 0,
            ':last-child': { paddingBottom: 0 },
            '.MuiDivider-root': {
              borderColor: color.commonBorderLight,
            },
          }}
        >
          <Box display="flex" justifyContent="center" flexDirection="column" width="100%">
            {listItems1.map((item, index) => {
              return (
                <React.Fragment key={index}>
                  <Divider placement="form" />
                  <CardList
                    title={item.title}
                    contents={item.contents}
                    appearance="iconText"
                    icon={<FileShareIcon appearance="lined" />}
                    line="multiLine"
                    button={true}
                    displayButton={
                      <Box display="flex" gap={`${sizesCommon.size4}px`}>
                        <Button
                          size="small"
                          appearance="outlined"
                          priority="normal"
                          buttonLabel="버튼"
                          onClick={(event: React.MouseEvent<HTMLButtonElement>) => {
                            alert('버튼1');
                            event.stopPropagation();
                          }}
                        />
                        <Button
                          size="small"
                          appearance="contained"
                          priority="primary"
                          buttonLabel="버튼"
                          onClick={(event: React.MouseEvent<HTMLButtonElement>) => {
                            alert('버튼2');
                            event.stopPropagation();
                          }}
                        />
                      </Box>
                    }
                    onClick={item.onClick}
                  />
                </React.Fragment>
              );
            })}
          </Box>
        </CardContent>
      </Card>

      <Box my="20px" />
      <Typography variant="h4">ListCard2</Typography>
      <Box my="20px" />

      <Card sx={{ width: '300px', padding: 0 }}>
        <CardHeader
          title="카드 타이틀"
          button={true}
          buttonIcon={<FileCopyIcon appearance="lined" />}
          function={true}
          functionItems={ACTION_MENU_ITMES}
        />
        <CardContent
          sx={{
            display: 'flex',
            padding: 0,
            ':last-child': { paddingBottom: 0 },
            '.MuiDivider-root': {
              borderColor: color.commonBorderLight,
            },
          }}
        >
          <Box display="flex" flexDirection="column" justifyContent="center" width="100%">
            {listItems1.map((item, index) => {
              return (
                <React.Fragment key={index}>
                  <Divider placement="form" />
                  <CardList
                    title={item.title}
                    contents={item.contents}
                    appearance="textOnly"
                    line="multiLine"
                  />
                </React.Fragment>
              );
            })}
          </Box>
        </CardContent>
      </Card>

      <Box my="20px" />
      <Typography variant="h4">ListCard3</Typography>
      <Box my="20px" />

      <Card sx={{ width: '223px' }}>
        <CardHeader
          title="리스트 타이틀"
          button={true}
          buttonIcon={<FileCopyIcon appearance="lined" />}
          function={true}
          functionItems={ACTION_MENU_ITMES}
        />
        <CardContent
          sx={{
            display: 'flex',
            padding: `0 ${sizesCommon.size16}px
                ${sizesCommon.size16}px ${sizesCommon.size16}px`,
            ':last-child': { paddingBottom: `${sizesCommon.size16}px` },
          }}
        >
          <Box
            display="flex"
            flexDirection="column"
            flex={1}
            sx={{
              'li:last-of-type div': {
                gap: `${sizesCommon.size8}px`,
                color: color.commonTextSecondary,
              },
            }}
          >
            {listItems2.map((item) => {
              return (
                <OptionListItem
                  key={item.value}
                  label={item.label}
                  value={item.value}
                  selected={item.selected}
                  multiLine="Yes"
                  usecase="basic"
                  type="multiple"
                  onClick={() => handleClick(item.label)}
                />
              );
            })}
            <OptionListItem
              label="추가하기"
              value="add"
              icon={
                <ControlAddIcon size="default" sx={{ svg: { color: color.commonTextSecondary } }} />
              }
              onClick={handleClickAddItem}
            />
          </Box>
        </CardContent>
      </Card>

      <Box my="20px" />
      <Typography variant="h4">KanbanCard</Typography>
      <Box my="20px" />

      <KanbanCard
        title="Card Title"
        tags={true}
        tagItems={TAG_ITEMS}
        menuItems={[
          { label: '새로고침', value: '새로고침' },
          { label: '설정', value: '설정' },
        ]}
        avatarProps={{ contentType: 'image', src: avatarSrc }}
        name="홍길동 책임"
        dueDate={new Date(2020, 1, 28)}
      />
    </Box>
  );
};
