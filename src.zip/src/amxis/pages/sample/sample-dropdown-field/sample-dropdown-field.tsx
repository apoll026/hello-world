import { DropdownField, DropdownOption } from '@amxis/design-system';
import { $semantic } from '@amxis/design-system/design-token';
import { Box } from '@mui/material';

const ColorType = {
  PRIMARY: `${$semantic.light.color.commonBgPrimary}`,
  SECONDARY: `${$semantic.light.color.commonBgSecondary}`,
  BASIC: `${$semantic.light.color.legendBasicBgColorANormal}`,
  NORMAL: `${$semantic.light.color.legendBasicBgColorCNormal}`,
  LEGEND: `${$semantic.light.color.legendBasicBgColorCNormal}`,
} as const;

import { useState } from 'react';
const MOCK_SELECTIONS_DEFAULT: DropdownOption[] = [
  {
    value: '1',
    label: 'Item1',
    statusColor: ColorType.PRIMARY,
    figures: 8,
  },
  {
    value: '2',
    label: 'Item2',
    statusColor: ColorType.SECONDARY,
    figures: 9,
  },
  {
    value: '3',
    label: 'Item3',
    statusColor: ColorType.BASIC,
    figures: 8,
  },
  {
    value: '4',
    label: 'Item4',
    statusColor: ColorType.NORMAL,
    figures: 2,
  },
];
export const SampleDropdownField = () => {
  const [values, setValues] = useState<DropdownOption[]>([]);
  const [values2, setValues2] = useState<DropdownOption[]>([]);

  const [value, setValue] = useState<DropdownOption | null>(null);
  const [value2, setValue2] = useState<DropdownOption | null>({
    value: '1',
    label: 'Item1',
    statusColor: ColorType.PRIMARY,
    figures: 8,
  });
  const [value3, setValue3] = useState<DropdownOption | null>(null);
  const [value4, setValue4] = useState<DropdownOption | null>(null);
  const [modalValue, setModalValue] = useState<DropdownOption | null>(null);
  return (
    <Box>
      <Box>
        <div>{JSON.stringify(value, null, 2)}</div>
        <Box width={'200px'}>
          <DropdownField
            isInput={false}
            options={MOCK_SELECTIONS_DEFAULT}
            placeholder="Placeholder"
            usecase="recent"
            onChange={(_, value) => {
              setValue(value as DropdownOption);
            }}
            value={value}
            useClearIcon
          />
        </Box>
      </Box>
      <Box>
        <div>{JSON.stringify(values, null, 2)}</div>
        <Box width={'200px'}>
          <DropdownField
            options={MOCK_SELECTIONS_DEFAULT}
            placeholder="Placeholder"
            multiple
            usecase="detailed"
            onChange={(_, value) => {
              setValues(value as DropdownOption[]);
            }}
            value={values}
            useClearIcon
          />
        </Box>
      </Box>
      <Box>
        <div>{JSON.stringify(value2, null, 2)}</div>
        <Box width={'200px'}>
          <DropdownField
            options={MOCK_SELECTIONS_DEFAULT}
            placeholder="Placeholder"
            usecase="detailed"
            onChange={(_, value) => {
              setValue2(value as DropdownOption);
            }}
            value={value2}
            useClearIcon
          />
        </Box>
      </Box>
      <Box>
        <div>{JSON.stringify(value3, null, 2)}</div>
        <Box width={'200px'}>
          <DropdownField
            options={MOCK_SELECTIONS_DEFAULT}
            placeholder="Placeholder"
            usecase="key-in"
            onChange={(_, value) => {
              setValue3(value as DropdownOption);
            }}
            value={value3}
            useClearIcon
            size="medium"
          />
        </Box>
      </Box>
      <Box>
        <div>{JSON.stringify(values2, null, 2)}</div>
        <Box width={'200px'}>
          <DropdownField
            options={MOCK_SELECTIONS_DEFAULT}
            placeholder="Placeholder"
            limitTags={1}
            multiple
            onChange={(_, value) => {
              setValues2(value as DropdownOption[]);
            }}
            value={values2}
            useClearIcon
            size="medium"
          />
        </Box>
      </Box>
      <Box>
        <div>{JSON.stringify(value4, null, 2)}</div>
        <Box width={'200px'}>
          <DropdownField
            options={MOCK_SELECTIONS_DEFAULT}
            placeholder="Placeholder"
            onChange={(_, value) => {
              setValue4(value as DropdownOption);
            }}
            viewAllEvent={() => console.log('전체보기')}
            value={value4}
            mandatory
            usecase="basic"
            useClearIcon
            size="small"
          />
        </Box>
      </Box>
      <Box>
        <div>모달 테스트 : {JSON.stringify(modalValue, null, 2)}</div>
        <Box width={'200px'}>
          <DropdownField
            options={MOCK_SELECTIONS_DEFAULT}
            placeholder="Placeholder"
            value={modalValue}
            isOpenModal={true}
            onClick={() => {
              alert("Open Modal & Close Modal & setValue: Item2");
              setModalValue({ value: '2', label: 'Item2', })
            }}
          />
        </Box>
      </Box>

    </Box>
  );
};
