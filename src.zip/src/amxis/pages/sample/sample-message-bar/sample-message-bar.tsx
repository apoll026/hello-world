import { Button, useMessageBar } from '@amxis/design-system';
import Box from '@mui/material/Box';

export const SampleMessageBar = () => {
  const { showMessageBar, hideMessageBar } = useMessageBar();

  return (
    <Box my="24px" display="flex" gap="8px">
      <Button onClick={() => showMessageBar({ message: 'hello hello', action: true })}>
        show message bar
      </Button>
      <Button onClick={() => showMessageBar({ message: 'error error', usecase: 'error' })}>
        show error message bar
      </Button>
      <Button priority="normal" onClick={() => hideMessageBar()}>
        hide bar
      </Button>
    </Box>
  );
};
