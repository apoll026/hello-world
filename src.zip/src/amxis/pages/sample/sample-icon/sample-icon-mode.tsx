import { ModeLightIcon, ModeDarkIcon } from '@amxis/design-system/icon';
import { useTheme } from '@amxis/design-system/hooks';
import Box from '@mui/material/Box';

export const SampleIconMode = () => {
  const [
    {
      palette: { semantic },
    },
  ] = useTheme();

  return (
    <Box>
      <Box color="violet" fontSize="32px">
        <ModeLightIcon appearance="filled" iconSize={8} />
        <ModeLightIcon appearance="lined" iconSize={16} />
        <ModeLightIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <ModeLightIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <ModeDarkIcon appearance="filled" iconSize={8} />
        <ModeDarkIcon appearance="lined" iconSize={16} />
        <ModeDarkIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <ModeDarkIcon appearance="lined" />
      </Box>
    </Box>
  );
};
