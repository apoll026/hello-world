import {
  CommunicationAgreeIcon,
  CommunicationAnswerboxIcon,
  CommunicationBookmarkIcon,
  CommunicationChatbotIcon,
  CommunicationCommentIcon,
  CommunicationConversationIcon,
  CommunicationDisagreeIcon,
  CommunicationLikeIcon,
  CommunicationMessageIcon,
  CommunicationNoticeIcon,
  CommunicationQuestionboxIcon,
  CommunicationSendIcon,
  CommunicationSendmoreIcon,
} from '@amxis/design-system/icon';
import { useTheme } from '@amxis/design-system/hooks';
import Box from '@mui/material/Box';

export const SampleIconCommunication = () => {
  const [
    {
      palette: { semantic },
    },
  ] = useTheme();

  return (
    <Box>
      <Box color="violet" fontSize="32px">
        <CommunicationBookmarkIcon appearance="filled" iconSize={8} />
        <CommunicationBookmarkIcon appearance="lined" iconSize={16} />
        <CommunicationBookmarkIcon
          appearance="filled"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <CommunicationBookmarkIcon appearance="lined" />
        <CommunicationBookmarkIcon
          appearance="selected"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <CommunicationBookmarkIcon appearance="selected" />
      </Box>
      <Box color="violet" fontSize="32px">
        <CommunicationAnswerboxIcon appearance="filled" iconSize={8} />
        <CommunicationAnswerboxIcon appearance="lined" iconSize={16} />
        <CommunicationAnswerboxIcon
          appearance="filled"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <CommunicationAnswerboxIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <CommunicationQuestionboxIcon appearance="filled" iconSize={8} />
        <CommunicationQuestionboxIcon appearance="lined" iconSize={16} />
        <CommunicationQuestionboxIcon
          appearance="filled"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <CommunicationQuestionboxIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <CommunicationLikeIcon appearance="filled" iconSize={8} />
        <CommunicationLikeIcon appearance="lined" iconSize={16} />
        <CommunicationLikeIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <CommunicationLikeIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <CommunicationNoticeIcon appearance="filled" iconSize={8} />
        <CommunicationNoticeIcon appearance="lined" iconSize={16} />
        <CommunicationNoticeIcon
          appearance="filled"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <CommunicationNoticeIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <CommunicationSendIcon appearance="filled" iconSize={8} />
        <CommunicationSendIcon appearance="lined" iconSize={16} />
        <CommunicationSendIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <CommunicationSendIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <CommunicationSendmoreIcon status="on" appearance="filled" iconSize={8} />
        <CommunicationSendmoreIcon status="on" appearance="lined" iconSize={16} />
        <CommunicationSendmoreIcon
          status="off"
          appearance="filled"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <CommunicationSendmoreIcon status="off" appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <CommunicationDisagreeIcon appearance="filled" iconSize={8} />
        <CommunicationDisagreeIcon appearance="lined" iconSize={16} />
        <CommunicationDisagreeIcon
          appearance="filled"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <CommunicationDisagreeIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <CommunicationAgreeIcon appearance="filled" iconSize={8} />
        <CommunicationAgreeIcon appearance="lined" iconSize={16} />
        <CommunicationAgreeIcon
          appearance="filled"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <CommunicationAgreeIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <CommunicationChatbotIcon appearance="filled" iconSize={8} />
        <CommunicationChatbotIcon appearance="lined" iconSize={16} />
        <CommunicationChatbotIcon
          appearance="filled"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <CommunicationChatbotIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <CommunicationCommentIcon appearance="filled" iconSize={8} />
        <CommunicationCommentIcon appearance="lined" iconSize={16} />
        <CommunicationCommentIcon
          appearance="filled"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <CommunicationCommentIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <CommunicationConversationIcon appearance="filled" iconSize={8} />
        <CommunicationConversationIcon appearance="lined" iconSize={16} />
        <CommunicationConversationIcon
          appearance="filled"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <CommunicationConversationIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <CommunicationMessageIcon appearance="filled" iconSize={8} />
        <CommunicationMessageIcon appearance="lined" iconSize={16} />
        <CommunicationMessageIcon
          appearance="filled"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <CommunicationMessageIcon appearance="lined" />
      </Box>
    </Box>
  );
};
