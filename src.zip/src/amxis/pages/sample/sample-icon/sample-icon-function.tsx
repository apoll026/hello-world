import {
  FunctionCalendarIcon,
  FunctionCallIcon,
  FunctionContactIcon,
  FunctionHomeIcon,
  FunctionImageIcon,
  FunctionLocationIcon,
  FunctionMailIcon,
  FunctionNotificationIcon,
  FunctionSearchIcon,
  FunctionSettingIcon,
  FunctionTimeIcon,
  FunctionGlobeIcon,
  FunctionToolIcon,
  FunctionUrlIcon,
  FunctionLoginIcon,
  FunctionLogoutIcon,
} from '@amxis/design-system/icon';
import { useTheme } from '@amxis/design-system/hooks';
import Box from '@mui/material/Box';

export const SampleIconFunction = () => {
  const [
    {
      palette: { semantic },
    },
  ] = useTheme();

  return (
    <Box>
      <Box color="violet" fontSize="32px">
        <FunctionLoginIcon iconSize={8} />
        <FunctionLoginIcon iconSize={16} />
        <FunctionLoginIcon sx={{ color: semantic.color.commonTextBasic }} />
        <FunctionLoginIcon />
      </Box>
      <Box color="violet" fontSize="32px">
        <FunctionLogoutIcon iconSize={8} />
        <FunctionLogoutIcon iconSize={16} />
        <FunctionLogoutIcon sx={{ color: semantic.color.commonTextBasic }} />
        <FunctionLogoutIcon />
      </Box>
      <Box color="violet" fontSize="32px">
        <FunctionUrlIcon appearance="filled" iconSize={8} />
        <FunctionUrlIcon appearance="lined" iconSize={16} />
        <FunctionUrlIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FunctionUrlIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FunctionGlobeIcon appearance="filled" iconSize={8} />
        <FunctionGlobeIcon appearance="lined" iconSize={16} />
        <FunctionGlobeIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FunctionGlobeIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FunctionCalendarIcon appearance="filled" iconSize={8} />
        <FunctionCalendarIcon appearance="lined" iconSize={16} />
        <FunctionCalendarIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FunctionCalendarIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FunctionLocationIcon appearance="filled" iconSize={8} />
        <FunctionLocationIcon appearance="lined" iconSize={16} />
        <FunctionLocationIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FunctionLocationIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FunctionCallIcon appearance="filled" iconSize={8} />
        <FunctionCallIcon appearance="lined" iconSize={16} />
        <FunctionCallIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FunctionCallIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FunctionImageIcon appearance="filled" iconSize={8} />
        <FunctionImageIcon appearance="lined" iconSize={16} />
        <FunctionImageIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FunctionImageIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FunctionMailIcon appearance="filled" iconSize={8} />
        <FunctionMailIcon appearance="lined" iconSize={16} />
        <FunctionMailIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FunctionMailIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FunctionContactIcon appearance="filled" iconSize={8} />
        <FunctionContactIcon appearance="lined" iconSize={16} />
        <FunctionContactIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FunctionContactIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FunctionTimeIcon appearance="filled" iconSize={8} />
        <FunctionTimeIcon appearance="lined" iconSize={16} />
        <FunctionTimeIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FunctionTimeIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FunctionNotificationIcon status="on" appearance="filled" iconSize={8} />
        <FunctionNotificationIcon status="on" appearance="lined" iconSize={16} />
        <FunctionNotificationIcon
          status="off"
          appearance="filled"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <FunctionNotificationIcon status="off" appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FunctionToolIcon appearance="filled" iconSize={8} />
        <FunctionToolIcon appearance="lined" iconSize={16} />
        <FunctionToolIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FunctionToolIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FunctionSettingIcon appearance="filled" iconSize={8} />
        <FunctionSettingIcon appearance="lined" iconSize={16} />
        <FunctionSettingIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FunctionSettingIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FunctionSearchIcon appearance="filled" iconSize={8} />
        <FunctionSearchIcon appearance="lined" iconSize={16} />
        <FunctionSearchIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FunctionSearchIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FunctionHomeIcon appearance="filled" iconSize={8} />
        <FunctionHomeIcon appearance="lined" iconSize={16} />
        <FunctionHomeIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FunctionHomeIcon appearance="lined" />
      </Box>
    </Box>
  );
};
