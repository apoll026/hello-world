import { MenuMenuIcon, MenuMoreIcon, MenuMoremenuIcon, MenuSwitcherIcon } from '@amxis/design-system/icon';
import { useTheme } from '@amxis/design-system/hooks';
import Box from '@mui/material/Box';

export const SampleIconMenu = () => {
  const [
    {
      palette: { semantic },
    },
  ] = useTheme();

  return (
    <Box>
      <Box color="violet" fontSize="32px">
        <MenuMoreIcon direction="horizontal" iconSize={8} />
        <MenuMoreIcon direction="vertical" iconSize={16} />
        <MenuMoreIcon direction="horizontal" sx={{ color: semantic.color.commonTextBasic }} />
        <MenuMoreIcon direction="vertical" />
      </Box>
      <Box color="violet" fontSize="32px">
        <MenuMoremenuIcon appearance="filled" iconSize={8} />
        <MenuMoremenuIcon appearance="lined" iconSize={16} />
        <MenuMoremenuIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <MenuMoremenuIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <MenuSwitcherIcon iconSize={8} />
        <MenuSwitcherIcon iconSize={16} />
        <MenuSwitcherIcon sx={{ color: semantic.color.commonTextBasic }} />
        <MenuSwitcherIcon />
      </Box>
      <Box color="violet" fontSize="32px">
        <MenuMenuIcon iconSize={8} />
        <MenuMenuIcon iconSize={16} />
        <MenuMenuIcon sx={{ color: semantic.color.commonTextBasic }} />
        <MenuMenuIcon />
      </Box>
    </Box>
  );
};
