import {
  ControlReorderIcon,
  ControlResetIcon,
  ControlSubstractIcon,
  ControlAddIcon,
  ControlReplyIcon,
  ControlEnterIcon,
  ControlCloseIcon,
  ControlMoveIcon,
  ControlConfirmIcon,
  ControlScrollIcon,
  ControlZoomIcon,
  ControlRefreshIcon,
  ControlMaximizeIcon,
  ControlMinimizeIcon,
  ControlScaleIcon,
} from '@amxis/design-system/icon';
import { useTheme } from '@amxis/design-system/hooks';
import Box from '@mui/material/Box';

export const SampleIconControl = () => {
  const [
    {
      palette: { semantic },
    },
  ] = useTheme();
  return (
    <Box>
      <Box color="purple" fontSize="35px">
        <ControlResetIcon size="small" iconSize={8} />
        <ControlResetIcon size="default" iconSize={16} />
        <ControlResetIcon size="small" sx={{ color: semantic.color.commonTextBasic }} />
        <ControlResetIcon size="default" />
      </Box>
      <Box color="purple" fontSize="35px">
        <ControlReorderIcon size="small" iconSize={8} />
        <ControlReorderIcon size="default" iconSize={16} />
        <ControlReorderIcon size="small" />
        <ControlReorderIcon size="default" sx={{ color: semantic.color.commonTextBasic }} />
      </Box>
      <Box color="purple" fontSize="35px">
        <ControlSubstractIcon size="small" iconSize={8} />
        <ControlSubstractIcon size="default" iconSize={16} />
        <ControlSubstractIcon size="small" />
        <ControlSubstractIcon size="default" sx={{ color: semantic.color.commonTextBasic }} />
      </Box>
      <Box color="purple" fontSize="35px">
        <ControlAddIcon size="small" iconSize={8} />
        <ControlAddIcon size="default" iconSize={16} />
        <ControlAddIcon size="small" />
        <ControlAddIcon size="default" sx={{ color: semantic.color.commonTextBasic }} />
      </Box>
      <Box color="purple" fontSize="35px">
        <ControlReplyIcon size="small" iconSize={8} />
        <ControlReplyIcon size="default" iconSize={16} />
        <ControlReplyIcon size="small" />
        <ControlReplyIcon size="default" sx={{ color: semantic.color.commonTextBasic }} />
      </Box>
      <Box color="purple" fontSize="35px">
        <ControlEnterIcon size="small" iconSize={8} />
        <ControlEnterIcon size="default" iconSize={16} />
        <ControlEnterIcon size="small" />
        <ControlEnterIcon size="default" sx={{ color: semantic.color.commonTextBasic }} />
      </Box>
      <Box color="purple" fontSize="35px">
        <ControlCloseIcon size="small" iconSize={8} />
        <ControlCloseIcon size="default" iconSize={16} />
        <ControlCloseIcon size="small" />
        <ControlCloseIcon size="default" sx={{ color: semantic.color.commonTextBasic }} />
      </Box>
      <Box color="purple" fontSize="35px">
        <ControlMoveIcon size="small" iconSize={8} />
        <ControlMoveIcon size="default" iconSize={16} />
        <ControlMoveIcon size="small" />
        <ControlMoveIcon size="default" sx={{ color: semantic.color.commonTextBasic }} />
      </Box>
      <Box color="purple" fontSize="35px">
        <ControlConfirmIcon size="small" iconSize={8} />
        <ControlConfirmIcon size="default" iconSize={16} />
        <ControlConfirmIcon size="small" />
        <ControlConfirmIcon size="default" sx={{ color: semantic.color.commonTextBasic }} />
      </Box>
      <Box color="purple" fontSize="35px">
        <ControlScrollIcon size="small" iconSize={8} />
        <ControlScrollIcon size="default" iconSize={16} />
        <ControlScrollIcon size="small" />
        <ControlScrollIcon size="default" sx={{ color: semantic.color.commonTextBasic }} />
      </Box>
      <Box color="purple" fontSize="35px">
        <ControlZoomIcon type="zoom-in" iconSize={8} />
        <ControlZoomIcon type="zoom-out" iconSize={16} />
        <ControlZoomIcon type="zoom-in" />
        <ControlZoomIcon type="zoom-out" sx={{ color: semantic.color.commonTextBasic }} />
      </Box>
      <Box color="purple" fontSize="35px">
        <ControlRefreshIcon size="small" iconSize={8} />
        <ControlRefreshIcon size="default" iconSize={16} />
        <ControlRefreshIcon size="small" />
        <ControlRefreshIcon size="default" sx={{ color: semantic.color.commonTextBasic }} />
      </Box>
      <Box color="purple" fontSize="35px">
        <ControlMaximizeIcon size="small" iconSize={8} />
        <ControlMaximizeIcon size="default" iconSize={16} />
        <ControlMaximizeIcon size="small" />
        <ControlMaximizeIcon size="default" sx={{ color: semantic.color.commonTextBasic }} />
      </Box>
      <Box color="purple" fontSize="35px">
        <ControlMinimizeIcon size="small" iconSize={8} />
        <ControlMinimizeIcon size="default" iconSize={16} />
        <ControlMinimizeIcon size="small" />
        <ControlMinimizeIcon size="default" sx={{ color: semantic.color.commonTextBasic }} />
      </Box>
      <Box color="purple" fontSize="35px">
        <ControlScaleIcon type="scale-up" appearance="filled" iconSize={8} />
        <ControlScaleIcon type="scale-up" appearance="lined" iconSize={16} />
        <ControlScaleIcon type="scale-down" appearance="filled" />
        <ControlScaleIcon
          type="scale-down"
          appearance="lined"
          sx={{ color: semantic.color.commonTextBasic }}
        />
      </Box>
    </Box>
  );
};
