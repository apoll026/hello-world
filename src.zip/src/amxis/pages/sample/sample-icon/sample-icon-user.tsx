import {
  UserTeamIcon,
  UserBlogIcon,
  UserUserIcon,
  UserUseridIcon,
} from '@amxis/design-system/icon';
import { useTheme } from '@amxis/design-system/hooks';
import Box from '@mui/material/Box';

export const SampleIconUser = () => {
  const [
    {
      palette: { semantic },
    },
  ] = useTheme();

  return (
    <Box>
      <Box color="violet" fontSize="32px">
        <UserTeamIcon appearance="filled" iconSize={8} />
        <UserTeamIcon appearance="lined" iconSize={16} />
        <UserTeamIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <UserTeamIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <UserBlogIcon appearance="filled" iconSize={8} />
        <UserBlogIcon appearance="lined" iconSize={16} />
        <UserBlogIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <UserBlogIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <UserUserIcon appearance="filled" iconSize={8} />
        <UserUserIcon appearance="lined" iconSize={16} />
        <UserUserIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <UserUserIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <UserUseridIcon appearance="filled" iconSize={8} />
        <UserUseridIcon appearance="lined" iconSize={16} />
        <UserUseridIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <UserUseridIcon appearance="lined" />
      </Box>
    </Box>
  );
};
