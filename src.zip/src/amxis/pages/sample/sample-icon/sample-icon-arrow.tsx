import {
  ArrowChevronIcon,
  ArrowChevron2Icon,
  ArrowCircleIcon,
  ArrowDefaultIcon,
  ArrowCondensedIcon,
} from '@amxis/design-system/icon';
import { useTheme } from '@amxis/design-system/hooks';
import Box from '@mui/material/Box';

export const SampleIconArrow = () => {
  const [
    {
      palette: { semantic },
    },
  ] = useTheme();
  return (
    <Box>
      <Box color="red">
        <ArrowChevronIcon direction="down" appearance="single" />
        <ArrowChevronIcon direction="down" appearance="double" />
        <ArrowChevronIcon direction="down-most" appearance="single" />
        <ArrowChevronIcon direction="left" appearance="single" />
        <ArrowChevronIcon direction="left" appearance="double" />
        <ArrowChevronIcon direction="left-most" appearance="single" />
        <ArrowChevronIcon direction="up" appearance="single" />
        <ArrowChevronIcon direction="up" appearance="double" />
        <ArrowChevronIcon direction="up-most" appearance="single" />
        <ArrowChevronIcon direction="right" appearance="single" />
        <ArrowChevronIcon direction="right" appearance="double" />
        <ArrowChevronIcon direction="right-most" appearance="single" />
      </Box>

      {/* Our test */}
      <Box color="tomato" fontSize="35px">
        {/* This would use size prop */}
        <ArrowChevron2Icon appearance="single" direction="down" iconSize={8} />
        <ArrowChevron2Icon
          direction="down"
          appearance="double"
          iconSize={16}
          sx={{ color: semantic.color.commonTextBasic }}
        />

        {/* This would use font size and color from Box */}
        <ArrowChevron2Icon appearance="single" direction="left" />
        <ArrowChevron2Icon direction="left" appearance="double" />
        <ArrowChevron2Icon appearance="single" direction="up" />
        <ArrowChevron2Icon direction="up" appearance="double" />
        <ArrowChevron2Icon appearance="single" direction="right" />
        <ArrowChevron2Icon direction="right" appearance="double" />
      </Box>

      {/* Example with circle icon */}
      <Box color="green" fontSize="35px">
        <ArrowCircleIcon appearance="filled" direction="down" iconSize={8} />
        <ArrowCircleIcon direction="down" appearance="lined" iconSize={16} />
        <ArrowCircleIcon appearance="filled" direction="left" />
        <ArrowCircleIcon direction="left" appearance="lined" />
        <ArrowCircleIcon appearance="filled" direction="up" />
        <ArrowCircleIcon direction="up" appearance="lined" />
        <ArrowCircleIcon appearance="filled" direction="right" />
        <ArrowCircleIcon direction="right" appearance="lined" />
      </Box>

      <Box color="purple" fontSize="35px">
        <ArrowDefaultIcon direction="right" iconSize={8} />
        <ArrowDefaultIcon direction="down" iconSize={16} />
        <ArrowDefaultIcon direction="up" />
        <ArrowDefaultIcon direction="left" />
        <ArrowDefaultIcon direction="up-left" />
        <ArrowDefaultIcon direction="up-right" />
        <ArrowDefaultIcon direction="down-left" />
        <ArrowDefaultIcon direction="down-right" />
        <ArrowDefaultIcon direction="left-most" />
        <ArrowDefaultIcon direction="right-most" />
        <ArrowDefaultIcon direction="down-most" />
        <ArrowDefaultIcon direction="up-most" />
      </Box>

      <Box color="teal" fontSize="35px">
        <ArrowCondensedIcon direction="right" iconSize={8} />
        <ArrowCondensedIcon direction="down" iconSize={16} />
        <ArrowCondensedIcon direction="up" />
        <ArrowCondensedIcon direction="left" />
        <ArrowCondensedIcon direction="up-down" />
        <ArrowCondensedIcon direction="left-right" />
      </Box>

      {/* End Our Test */}

      <Box color="blue">
        <ArrowChevronIcon appearance="single" direction="down" />
        <ArrowChevronIcon appearance="single" direction="down" type="double" />
        <ArrowChevronIcon appearance="single" direction="down-most" />
        <ArrowChevronIcon appearance="single" direction="left" />
        <ArrowChevronIcon appearance="single" direction="left" type="double" />
        <ArrowChevronIcon appearance="single" direction="left-most" />
        <ArrowChevronIcon appearance="single" direction="up" />
        <ArrowChevronIcon appearance="single" direction="up" type="double" />
        <ArrowChevronIcon appearance="single" direction="up-most" />
        <ArrowChevronIcon appearance="single" direction="right" />
        <ArrowChevronIcon appearance="single" direction="right" type="double" />
        <ArrowChevronIcon appearance="single" direction="right-most" />
      </Box>
      <Box color="green">
        <ArrowChevronIcon appearance="single" direction="down" />
        <ArrowChevronIcon appearance="single" direction="down" type="double" />
        <ArrowChevronIcon appearance="single" direction="down-most" />
        <ArrowChevronIcon appearance="single" direction="left" />
        <ArrowChevronIcon appearance="single" direction="left" type="double" />
        <ArrowChevronIcon appearance="single" direction="left-most" />
        <ArrowChevronIcon appearance="single" direction="up" />
        <ArrowChevronIcon appearance="single" direction="up" type="double" />
        <ArrowChevronIcon appearance="single" direction="up-most" />
        <ArrowChevronIcon appearance="single" direction="right" />
        <Box fontSize="40px" display="inline">
          <ArrowChevronIcon appearance="single" direction="right" type="double" />
        </Box>
        <ArrowChevronIcon appearance="single" direction="right-most" sx={{ fontSize: '80px' }} />
      </Box>
      <Box color={semantic.color.commonBgBasic}>
        <ArrowChevronIcon
          appearance="single"
          sx={{ color: semantic.color.commonTextBasic }}
          direction="down"
        />
        <ArrowChevronIcon
          appearance="single"
          sx={{ color: semantic.color.commonTextBasic }}
          direction="down"
          type="double"
        />
        <ArrowChevronIcon
          appearance="single"
          sx={{ color: semantic.color.commonTextBasic }}
          direction="down-most"
        />
        <ArrowChevronIcon
          appearance="single"
          sx={{ color: semantic.color.commonTextBasic }}
          direction="left"
        />
        <ArrowChevronIcon
          appearance="single"
          sx={{ color: semantic.color.commonTextBasic }}
          direction="left"
          type="double"
        />
        <ArrowChevronIcon
          appearance="single"
          sx={{ color: semantic.color.commonTextBasic }}
          direction="left-most"
        />
        <ArrowChevronIcon
          appearance="single"
          sx={{ color: semantic.color.commonTextBasic }}
          direction="up"
        />
        <ArrowChevronIcon
          appearance="single"
          sx={{ color: semantic.color.commonTextBasic }}
          direction="up"
          type="double"
        />
        <ArrowChevronIcon
          appearance="single"
          sx={{ color: semantic.color.commonTextBasic }}
          direction="up-most"
        />
        <ArrowChevronIcon
          appearance="single"
          sx={{ color: semantic.color.commonTextBasic }}
          direction="right"
        />
        <ArrowChevronIcon
          appearance="single"
          sx={{ color: semantic.color.commonTextBasic }}
          direction="right"
          type="double"
        />
        <ArrowChevronIcon
          appearance="single"
          sx={{ color: semantic.color.commonTextBasic }}
          direction="right-most"
        />
      </Box>
    </Box>
  );
};
