import { NotificationLayerIcon } from '@amxis/design-system/icon';
import { useTheme } from '@amxis/design-system/hooks';
import Box from '@mui/material/Box';

export const SampleIconNotificationLayer = () => {
  const [
    {
      palette: { semantic },
    },
  ] = useTheme();

  return (
    <Box>
      <Box color="violet" fontSize="32px">
        <NotificationLayerIcon outlined="default" />
        <NotificationLayerIcon outlined="outline" />
      </Box>
    </Box>
  );
};
