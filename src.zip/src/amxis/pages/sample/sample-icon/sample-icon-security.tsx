import {
  SecurityEyeIcon,
  SecurityFaceidIcon,
  SecurityFingerprintIcon,
  SecurityLockIcon,
  SecurityPatternid4Icon,
  SecurityPatternid9Icon,
  SecurityQrIcon,
  SecurityShieldcheckIcon,
} from '@amxis/design-system/icon';
import { useTheme } from '@amxis/design-system/hooks';
import Box from '@mui/material/Box';

export const SampleIconSecurity = () => {
  const [
    {
      palette: { semantic },
    },
  ] = useTheme();

  return (
    <Box>
      <Box color="violet" fontSize="32px">
        <SecurityShieldcheckIcon appearance="filled" iconSize={8} />
        <SecurityShieldcheckIcon appearance="lined" iconSize={16} />
        <SecurityShieldcheckIcon
          appearance="filled"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <SecurityShieldcheckIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <SecurityQrIcon appearance="filled" iconSize={8} />
        <SecurityQrIcon appearance="lined" iconSize={16} />
        <SecurityQrIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <SecurityQrIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <SecurityPatternid4Icon appearance="filled" iconSize={8} />
        <SecurityPatternid4Icon appearance="lined" iconSize={16} />
        <SecurityPatternid4Icon
          appearance="filled"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <SecurityPatternid4Icon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <SecurityPatternid9Icon appearance="filled" iconSize={8} />
        <SecurityPatternid9Icon appearance="lined" iconSize={16} />
        <SecurityPatternid9Icon
          appearance="filled"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <SecurityPatternid9Icon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <SecurityFaceidIcon appearance="filled" iconSize={8} />
        <SecurityFaceidIcon appearance="lined" iconSize={16} />
        <SecurityFaceidIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <SecurityFaceidIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <SecurityFingerprintIcon appearance="filled" iconSize={8} />
        <SecurityFingerprintIcon appearance="lined" iconSize={16} />
        <SecurityFingerprintIcon
          appearance="filled"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <SecurityFingerprintIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <SecurityEyeIcon status="hide" appearance="filled" iconSize={8} />
        <SecurityEyeIcon status="show" appearance="filled" iconSize={16} />
        <SecurityEyeIcon
          status="hide"
          appearance="lined"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <SecurityEyeIcon status="show" appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <SecurityLockIcon status="lock" appearance="filled" iconSize={8} />
        <SecurityLockIcon status="lock" appearance="lined" iconSize={16} />
        <SecurityLockIcon
          status="unlock"
          appearance="filled"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <SecurityLockIcon status="unlock" appearance="lined" />
        <SecurityLockIcon status="unlock" appearance="filled" iconSize={8} />
        <SecurityLockIcon status="lock" appearance="lined" iconSize={16} />
      </Box>
    </Box>
  );
};
