import {
  StatusBanIcon,
  StatusConfirmedIcon,
  StatusHelpIcon,
  StatusInfoIcon,
  StatusMisuseIcon,
  StatusWarningIcon,
} from '@amxis/design-system/icon';
import { useTheme } from '@amxis/design-system/hooks';
import Box from '@mui/material/Box';

export const SampleIconStatus = () => {
  const [
    {
      palette: { semantic },
    },
  ] = useTheme();

  return (
    <Box>
      <Box color="violet" fontSize="32px">
        <StatusMisuseIcon appearance="filled" iconSize={8} />
        <StatusMisuseIcon appearance="lined" iconSize={16} />
        <StatusMisuseIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <StatusMisuseIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <StatusConfirmedIcon appearance="filled" iconSize={8} />
        <StatusConfirmedIcon appearance="lined" iconSize={16} />
        <StatusConfirmedIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <StatusConfirmedIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <StatusInfoIcon appearance="filled" iconSize={8} />
        <StatusInfoIcon appearance="lined" iconSize={16} />
        <StatusInfoIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <StatusInfoIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <StatusWarningIcon appearance="filled" iconSize={8} />
        <StatusWarningIcon appearance="lined" iconSize={16} />
        <StatusWarningIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <StatusWarningIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <StatusHelpIcon appearance="filled" iconSize={8} />
        <StatusHelpIcon appearance="lined" iconSize={16} />
        <StatusHelpIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <StatusHelpIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <StatusBanIcon appearance="filled" iconSize={8} />
        <StatusBanIcon appearance="lined" iconSize={16} />
        <StatusBanIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <StatusBanIcon appearance="lined" />
      </Box>
    </Box>
  );
};
