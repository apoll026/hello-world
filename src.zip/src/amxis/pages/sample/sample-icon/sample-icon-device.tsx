import {
  DeviceCameraIcon,
  DeviceMobileIcon,
  DevicePcIcon,
  DevicePrintIcon,
  DeviceProjectorIcon,
  DeviceVideoIcon,
} from '@amxis/design-system/icon';
import { useTheme } from '@amxis/design-system/hooks';
import Box from '@mui/material/Box';

export const SampleIconDevice = () => {
  const [
    {
      palette: { semantic },
    },
  ] = useTheme();

  return (
    <Box>
      <Box color="violet" fontSize="32px">
        <DevicePcIcon appearance="filled" iconSize={8} />
        <DevicePcIcon appearance="lined" iconSize={16} />
        <DevicePcIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <DevicePcIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <DeviceVideoIcon appearance="filled" iconSize={8} />
        <DeviceVideoIcon appearance="lined" iconSize={16} />
        <DeviceVideoIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <DeviceVideoIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <DeviceProjectorIcon appearance="filled" iconSize={8} />
        <DeviceProjectorIcon appearance="lined" iconSize={16} />
        <DeviceProjectorIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <DeviceProjectorIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <DevicePrintIcon appearance="filled" iconSize={8} />
        <DevicePrintIcon appearance="lined" iconSize={16} />
        <DevicePrintIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <DevicePrintIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <DeviceCameraIcon appearance="filled" iconSize={8} />
        <DeviceCameraIcon appearance="lined" iconSize={16} />
        <DeviceCameraIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <DeviceCameraIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <DeviceMobileIcon appearance="filled" iconSize={8} />
        <DeviceMobileIcon appearance="lined" iconSize={16} />
        <DeviceMobileIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <DeviceMobileIcon appearance="lined" />
      </Box>
    </Box>
  );
};
