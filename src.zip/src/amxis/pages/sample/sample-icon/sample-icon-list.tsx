import {
  List2linedlistIcon,
  List3linedlistIcon,
  ListControlIcon,
  ListFunnelIcon,
  ListListIcon,
  ListPagefillIcon,
  ListPageseperatelrIcon,
  ListPinIcon,
  ListThumbnailcardIcon,
  ListThumbnaillistIcon,
  ListTimelineIcon,
  ListTodoIcon,
  ListPageseperateudIcon,
} from '@amxis/design-system/icon';
import { useTheme } from '@amxis/design-system/hooks';
import Box from '@mui/material/Box';

export const SampleIconList = () => {
  const [
    {
      palette: { semantic },
    },
  ] = useTheme();

  return (
    <Box>
      <Box color="violet" fontSize="32px">
        <ListPageseperatelrIcon iconSize={8} />
        <ListPageseperatelrIcon iconSize={16} />
        <ListPageseperatelrIcon sx={{ color: semantic.color.commonTextBasic }} />
        <ListPageseperatelrIcon />
      </Box>
      <Box color="violet" fontSize="32px">
        <ListPageseperateudIcon iconSize={8} />
        <ListPageseperateudIcon iconSize={16} />
        <ListPageseperateudIcon sx={{ color: semantic.color.commonTextBasic }} />
        <ListPageseperateudIcon />
      </Box>
      <Box color="violet" fontSize="32px">
        <ListPagefillIcon iconSize={8} />
        <ListPagefillIcon iconSize={16} />
        <ListPagefillIcon sx={{ color: semantic.color.commonTextBasic }} />
        <ListPagefillIcon />
      </Box>
      <Box color="violet" fontSize="32px">
        <ListThumbnailcardIcon iconSize={8} />
        <ListThumbnailcardIcon iconSize={16} />
        <ListThumbnailcardIcon sx={{ color: semantic.color.commonTextBasic }} />
        <ListThumbnailcardIcon />
      </Box>
      <Box color="violet" fontSize="32px">
        <List3linedlistIcon iconSize={8} />
        <List3linedlistIcon iconSize={16} />
        <List3linedlistIcon sx={{ color: semantic.color.commonTextBasic }} />
        <List3linedlistIcon />
      </Box>
      <Box color="violet" fontSize="32px">
        <List2linedlistIcon iconSize={8} />
        <List2linedlistIcon iconSize={16} />
        <List2linedlistIcon sx={{ color: semantic.color.commonTextBasic }} />
        <List2linedlistIcon />
      </Box>
      <Box color="violet" fontSize="32px">
        <ListThumbnaillistIcon iconSize={8} />
        <ListThumbnaillistIcon iconSize={16} />
        <ListThumbnaillistIcon sx={{ color: semantic.color.commonTextBasic }} />
        <ListThumbnaillistIcon />
      </Box>
      <Box color="violet" fontSize="32px">
        <ListTodoIcon iconSize={8} />
        <ListTodoIcon iconSize={16} />
        <ListTodoIcon sx={{ color: semantic.color.commonTextBasic }} />
        <ListTodoIcon />
      </Box>
      <Box color="violet" fontSize="32px">
        <ListListIcon iconSize={8} />
        <ListListIcon iconSize={16} />
        <ListListIcon sx={{ color: semantic.color.commonTextBasic }} />
        <ListListIcon />
      </Box>
      <Box color="violet" fontSize="32px">
        <ListPinIcon status="pin" appearance="filled" iconSize={8} />
        <ListPinIcon status="pin" appearance="lined" iconSize={16} />
        <ListPinIcon
          status="pin"
          appearance="filled"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <ListPinIcon status="pin" appearance="lined" />
        <ListPinIcon status="pin" appearance="selected" />
        <ListPinIcon status="unpin" appearance="filled" iconSize={8} />
        <ListPinIcon status="unpin" appearance="lined" iconSize={16} />
        <ListPinIcon
          status="unpin"
          appearance="filled"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <ListPinIcon status="unpin" appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <ListFunnelIcon appearance="filled" iconSize={8} />
        <ListFunnelIcon appearance="lined" iconSize={16} />
        <ListFunnelIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <ListFunnelIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <ListControlIcon appearance="filled" iconSize={8} />
        <ListControlIcon appearance="lined" iconSize={16} />
        <ListControlIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <ListControlIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <ListTimelineIcon appearance="filled" iconSize={8} />
        <ListTimelineIcon appearance="lined" iconSize={16} />
        <ListTimelineIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <ListTimelineIcon appearance="lined" />
      </Box>
    </Box>
  );
};
