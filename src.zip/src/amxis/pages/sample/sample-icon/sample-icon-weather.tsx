import {
  WeatherCloudyIcon,
  WeatherLighteningIcon,
  WeatherPartlycloudyIcon,
  WeatherRainyIcon,
  WeatherSnowyIcon,
  WeatherSunnyIcon,
  WeatherThunderIcon,
} from '@amxis/design-system/icon';
import { useTheme } from '@amxis/design-system/hooks';
import Box from '@mui/material/Box';

export const SampleIconWeather = () => {
  const [
    {
      palette: { semantic },
    },
  ] = useTheme();

  return (
    <Box>
      <Box color="violet" fontSize="32px">
        <WeatherLighteningIcon appearance="filled" iconSize={8} />
        <WeatherLighteningIcon appearance="lined" iconSize={16} />
        <WeatherLighteningIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <WeatherLighteningIcon appearance="colored" />
      </Box>
      <Box color="violet" fontSize="32px">
        <WeatherRainyIcon appearance="filled" iconSize={8} />
        <WeatherRainyIcon appearance="lined" iconSize={16} />
        <WeatherRainyIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <WeatherRainyIcon appearance="colored" />
      </Box>
      <Box color="violet" fontSize="32px">
        <WeatherSnowyIcon appearance="filled" iconSize={8} />
        <WeatherSnowyIcon appearance="lined" iconSize={16} />
        <WeatherSnowyIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <WeatherSnowyIcon appearance="colored" />
      </Box>
      <Box color="violet" fontSize="32px">
        <WeatherThunderIcon appearance="filled" iconSize={8} />
        <WeatherThunderIcon appearance="lined" iconSize={16} />
        <WeatherThunderIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <WeatherThunderIcon appearance="colored" />
      </Box>
      <Box color="violet" fontSize="32px">
        <WeatherPartlycloudyIcon appearance="filled" iconSize={8} />
        <WeatherPartlycloudyIcon appearance="lined" iconSize={16} />
        <WeatherPartlycloudyIcon
          appearance="filled"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <WeatherPartlycloudyIcon appearance="colored" />
      </Box>
      <Box color="violet" fontSize="32px">
        <WeatherCloudyIcon appearance="filled" iconSize={8} />
        <WeatherCloudyIcon appearance="lined" iconSize={16} />
        <WeatherCloudyIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <WeatherCloudyIcon appearance="colored" />
      </Box>
      <Box color="violet" fontSize="32px">
        <WeatherSunnyIcon appearance="filled" iconSize={8} />
        <WeatherSunnyIcon appearance="lined" iconSize={16} />
        <WeatherSunnyIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <WeatherSunnyIcon appearance="colored" />
      </Box>
    </Box>
  );
};
