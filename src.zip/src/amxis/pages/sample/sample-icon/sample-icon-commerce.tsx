import {
  CommerceHelpdeskIcon,
  CommerceShoppingbagIcon,
  CommerceCreditcardIcon,
  CommerceCouponIcon,
  CommerceCartIcon,
} from '@amxis/design-system/icon';
import { useTheme } from '@amxis/design-system/hooks';
import Box from '@mui/material/Box';

export const SampleIconCommerce = () => {
  const [
    {
      palette: { semantic },
    },
  ] = useTheme();

  return (
    <Box>
      <Box color="violet" fontSize="32px">
        <CommerceHelpdeskIcon appearance="filled" iconSize={8} />
        <CommerceHelpdeskIcon appearance="lined" iconSize={16} />
        <CommerceHelpdeskIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <CommerceHelpdeskIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <CommerceCouponIcon appearance="filled" iconSize={8} />
        <CommerceCouponIcon appearance="lined" iconSize={16} />
        <CommerceCouponIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <CommerceCouponIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <CommerceCartIcon appearance="filled" iconSize={8} />
        <CommerceCartIcon appearance="lined" iconSize={16} />
        <CommerceCartIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <CommerceCartIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <CommerceCreditcardIcon appearance="filled" iconSize={8} />
        <CommerceCreditcardIcon appearance="lined" iconSize={16} />
        <CommerceCreditcardIcon
          appearance="filled"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <CommerceCreditcardIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <CommerceShoppingbagIcon appearance="filled" iconSize={8} />
        <CommerceShoppingbagIcon appearance="lined" iconSize={16} />
        <CommerceShoppingbagIcon
          appearance="filled"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <CommerceShoppingbagIcon appearance="lined" />
      </Box>
    </Box>
  );
};
