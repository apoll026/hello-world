import { KeylineIcon } from '@amxis/design-system/icon';
import { useTheme } from '@amxis/design-system/hooks';
import Box from '@mui/material/Box';

export const SampleIconKeyline = () => {
  const [
    {
      palette: { semantic },
    },
  ] = useTheme();

  return (
    <Box>
      <Box color="violet" fontSize="32px">
        <KeylineIcon />
        <KeylineIcon iconSize={16} />
      </Box>
    </Box>
  );
};
