import { MediaMicIcon, MediaPlayIcon, MediaVideoIcon, MediaVolumeIcon } from '@amxis/design-system/icon';
import { useTheme } from '@amxis/design-system/hooks';
import Box from '@mui/material/Box';

export const SampleIconMedia = () => {
  const [
    {
      palette: { semantic },
    },
  ] = useTheme();

  return (
    <Box>
      <Box color="violet" fontSize="32px">
        <MediaMicIcon status="on" appearance="filled" iconSize={8} />
        <MediaMicIcon status="off" appearance="lined" iconSize={16} />
        <MediaMicIcon
          status="on"
          appearance="lined"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <MediaMicIcon status="off" appearance="filled" />
      </Box>
      <Box color="violet" fontSize="32px">
        <MediaVideoIcon appearance="filled" iconSize={8} />
        <MediaVideoIcon appearance="lined" iconSize={16} />
        <MediaVideoIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <MediaVideoIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <MediaPlayIcon appearance="filled" iconSize={8} />
        <MediaPlayIcon appearance="lined" iconSize={16} />
        <MediaPlayIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <MediaPlayIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <MediaVolumeIcon status="on" appearance="filled" iconSize={8} />
        <MediaVolumeIcon status="on" appearance="lined" iconSize={16} />
        <MediaVolumeIcon
          status="off"
          appearance="filled"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <MediaVolumeIcon status="off" appearance="lined" />
        <MediaVolumeIcon status="up" appearance="filled" iconSize={8} />
        <MediaVolumeIcon status="up" appearance="lined" iconSize={16} />
        <MediaVolumeIcon
          status="down"
          appearance="filled"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <MediaVolumeIcon status="down" appearance="lined" />
      </Box>
    </Box>
  );
};
