import {
  EditAlignIcon,
  EditDeleteIcon,
  EditEdit1Icon,
  EditEdit2Icon,
  EditTypefaceIcon,
} from '@amxis/design-system/icon';
import { useTheme } from '@amxis/design-system/hooks';
import Box from '@mui/material/Box';

export const SampleIconEdit = () => {
  const [
    {
      palette: { semantic },
    },
  ] = useTheme();

  return (
    <Box>
      <Box color="violet" fontSize="32px">
        <EditTypefaceIcon iconSize={8} />
        <EditTypefaceIcon iconSize={16} />
        <EditTypefaceIcon sx={{ color: semantic.color.commonTextBasic }} />
        <EditTypefaceIcon />
      </Box>
      <Box color="violet" fontSize="32px">
        <EditAlignIcon type="left" iconSize={8} />
        <EditAlignIcon type="center" iconSize={16} />
        <EditAlignIcon type="right" sx={{ color: semantic.color.commonTextBasic }} />
        <EditAlignIcon type="left" />
        <EditAlignIcon type="center" />
        <EditAlignIcon type="right" />
      </Box>
      <Box color="violet" fontSize="32px">
        <EditDeleteIcon appearance="filled" iconSize={8} />
        <EditDeleteIcon appearance="lined" iconSize={16} />
        <EditDeleteIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <EditDeleteIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <EditEdit1Icon appearance="filled" iconSize={8} />
        <EditEdit1Icon appearance="lined" iconSize={16} />
        <EditEdit1Icon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <EditEdit1Icon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <EditEdit2Icon appearance="filled" iconSize={8} />
        <EditEdit2Icon appearance="lined" iconSize={16} />
        <EditEdit2Icon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <EditEdit2Icon appearance="lined" />
      </Box>
    </Box>
  );
};
