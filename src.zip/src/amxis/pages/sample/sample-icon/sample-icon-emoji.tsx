import { EmojiFaceIcon } from '@amxis/design-system/icon';
import { useTheme } from '@amxis/design-system/hooks';
import Box from '@mui/material/Box';

export const SampleIconEmoji = () => {
  const [
    {
      palette: { semantic },
    },
  ] = useTheme();

  return (
    <Box>
      <Box color="violet" fontSize="32px">
        <EmojiFaceIcon appearance="filled" face="bad" iconSize={16} />
        <EmojiFaceIcon appearance="lined" face="bad" iconSize={16} />
        <EmojiFaceIcon
          appearance="filled"
          face="good"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <EmojiFaceIcon
          appearance="lined"
          face="good"
          sx={{ color: semantic.color.commonTextBasic }}
        />
        <EmojiFaceIcon appearance="filled" face="normal" />
        <EmojiFaceIcon appearance="lined" face="normal" />
      </Box>
    </Box>
  );
};
