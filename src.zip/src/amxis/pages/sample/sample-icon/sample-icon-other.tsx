import {
  OtherIdeaIcon,
  OtherLinechartIcon,
  OtherOrgIcon,
  OtherPiechartIcon,
  OtherPlatformIcon,
  OtherProductIcon,
  OtherServiceIcon,
  OtherSuitcaseIcon,
} from '@amxis/design-system/icon';
import { useTheme } from '@amxis/design-system/hooks';
import Box from '@mui/material/Box';

export const SampleIconOther = () => {
  const [
    {
      palette: { semantic },
    },
  ] = useTheme();

  return (
    <Box>
      <Box color="violet" fontSize="32px">
        <OtherIdeaIcon appearance="filled" iconSize={8} />
        <OtherIdeaIcon appearance="lined" iconSize={16} />
        <OtherIdeaIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <OtherIdeaIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <OtherLinechartIcon appearance="filled" iconSize={8} />
        <OtherLinechartIcon appearance="lined" iconSize={16} />
        <OtherLinechartIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <OtherLinechartIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <OtherOrgIcon appearance="filled" iconSize={8} />
        <OtherOrgIcon appearance="lined" iconSize={16} />
        <OtherOrgIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <OtherOrgIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <OtherPiechartIcon appearance="filled" iconSize={8} />
        <OtherPiechartIcon appearance="lined" iconSize={16} />
        <OtherPiechartIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <OtherPiechartIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <OtherPlatformIcon appearance="filled" iconSize={8} />
        <OtherPlatformIcon appearance="lined" iconSize={16} />
        <OtherPlatformIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <OtherPlatformIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <OtherProductIcon appearance="filled" iconSize={8} />
        <OtherProductIcon appearance="lined" iconSize={16} />
        <OtherProductIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <OtherProductIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <OtherServiceIcon appearance="filled" iconSize={8} />
        <OtherServiceIcon appearance="lined" iconSize={16} />
        <OtherServiceIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <OtherServiceIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <OtherSuitcaseIcon appearance="filled" iconSize={8} />
        <OtherSuitcaseIcon appearance="lined" iconSize={16} />
        <OtherSuitcaseIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <OtherSuitcaseIcon appearance="lined" />
      </Box>
    </Box>
  );
};
