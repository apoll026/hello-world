import {
  FileExceldownloadIcon,
  FileExcelnewIcon,
  FileExceluploadIcon,
  FileFolderIcon,
  FileApprovalIcon,
  FileCopyIcon,
  FileDocument1Icon,
  FileDocument2Icon,
  FileShareIcon,
  FileMarkdownIcon,
  FileExternallinkIcon,
  FileAttatchIcon,
  FileChainlinkIcon,
  FileImgIcon,
  FileZipIcon,
  FilePdfIcon,
  FileExcelIcon,
  FilePptIcon,
  FileWordIcon,
  FileDownloadIcon,
  FileUploadIcon,
  FilePdfcolorIcon,
  FileExcelcolorIcon,
  FilePptcolorIcon,
  FileWordcolorIcon,
} from '@amxis/design-system/icon';
import { useTheme } from '@amxis/design-system/hooks';
import Box from '@mui/material/Box';

export const SampleIconFile = () => {
  const [
    {
      palette: { semantic },
    },
  ] = useTheme();

  return (
    <Box>
      <Box color="violet" fontSize="32px">
        <FileExternallinkIcon appearance="filled" iconSize={8} />
        <FileExternallinkIcon appearance="lined" iconSize={16} />
        <FileExternallinkIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FileExternallinkIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FileWordcolorIcon appearance="filled" iconSize={8} />
        <FileWordcolorIcon appearance="lined" iconSize={16} />
        <FileWordcolorIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FileWordcolorIcon appearance="lined" />
        <FileWordcolorIcon appearance="filled" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FilePptcolorIcon appearance="filled" iconSize={8} />
        <FilePptcolorIcon appearance="lined" iconSize={16} />
        <FilePptcolorIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FilePptcolorIcon appearance="lined" />
        <FilePptcolorIcon appearance="filled" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FileExcelcolorIcon appearance="filled" iconSize={8} />
        <FileExcelcolorIcon appearance="lined" iconSize={16} />
        <FileExcelcolorIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FileExcelcolorIcon appearance="lined" />
        <FileExcelcolorIcon appearance="filled" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FilePdfcolorIcon appearance="filled" iconSize={8} />
        <FilePdfcolorIcon appearance="lined" iconSize={16} />
        <FilePdfcolorIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FilePdfcolorIcon appearance="lined" />
        <FilePdfcolorIcon appearance="filled" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FileUploadIcon iconSize={8} />
        <FileUploadIcon iconSize={16} />
        <FileUploadIcon sx={{ color: semantic.color.commonTextBasic }} />
        <FileUploadIcon />
      </Box>
      <Box color="violet" fontSize="32px">
        <FileDownloadIcon iconSize={8} />
        <FileDownloadIcon iconSize={16} />
        <FileDownloadIcon sx={{ color: semantic.color.commonTextBasic }} />
        <FileDownloadIcon />
      </Box>
      <Box color="violet" fontSize="32px">
        <FileWordIcon appearance="filled" iconSize={8} />
        <FileWordIcon appearance="lined" iconSize={16} />
        <FileWordIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FileWordIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FilePptIcon appearance="filled" iconSize={8} />
        <FilePptIcon appearance="lined" iconSize={16} />
        <FilePptIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FilePptIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FileExcelIcon appearance="filled" iconSize={8} />
        <FileExcelIcon appearance="lined" iconSize={16} />
        <FileExcelIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FileExcelIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FileExcelnewIcon iconSize={8} />
        <FileExcelnewIcon iconSize={16} />
        <FileExcelnewIcon sx={{ color: semantic.color.commonTextBasic }} />
        <FileExcelnewIcon />
      </Box>
      <Box color="violet" fontSize="32px">
        <FilePdfIcon appearance="filled" iconSize={8} />
        <FilePdfIcon appearance="lined" iconSize={16} />
        <FilePdfIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FilePdfIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FileZipIcon appearance="filled" iconSize={8} />
        <FileZipIcon appearance="lined" iconSize={16} />
        <FileZipIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FileZipIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FileImgIcon appearance="filled" iconSize={8} />
        <FileImgIcon appearance="lined" iconSize={16} />
        <FileImgIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FileImgIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FileChainlinkIcon iconSize={8} />
        <FileChainlinkIcon iconSize={16} />
        <FileChainlinkIcon sx={{ color: semantic.color.commonTextBasic }} />
        <FileChainlinkIcon />
      </Box>
      <Box color="violet" fontSize="32px">
        <FileAttatchIcon iconSize={8} />
        <FileAttatchIcon iconSize={16} />
        <FileAttatchIcon sx={{ color: semantic.color.commonTextBasic }} />
        <FileAttatchIcon />
      </Box>
      <Box color="violet" fontSize="32px">
        <FileExceluploadIcon iconSize={8} />
        <FileExceluploadIcon iconSize={16} />
        <FileExceluploadIcon sx={{ color: semantic.color.commonTextBasic }} />
        <FileExceluploadIcon />
      </Box>
      <Box color="violet" fontSize="32px">
        <FileExceldownloadIcon iconSize={8} />
        <FileExceldownloadIcon iconSize={16} />
        <FileExceldownloadIcon sx={{ color: semantic.color.commonTextBasic }} />
        <FileExceldownloadIcon />
      </Box>
      <Box color="violet" fontSize="32px">
        <FileMarkdownIcon appearance="filled" iconSize={8} />
        <FileMarkdownIcon appearance="lined" iconSize={16} />
        <FileMarkdownIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FileMarkdownIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FileCopyIcon appearance="filled" iconSize={8} />
        <FileCopyIcon appearance="lined" iconSize={16} />
        <FileCopyIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FileCopyIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FileApprovalIcon appearance="filled" iconSize={8} />
        <FileApprovalIcon appearance="lined" iconSize={16} />
        <FileApprovalIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FileApprovalIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FileDocument2Icon appearance="filled" iconSize={8} />
        <FileDocument2Icon appearance="lined" iconSize={16} />
        <FileDocument2Icon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FileDocument2Icon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FileShareIcon appearance="filled" iconSize={8} />
        <FileShareIcon appearance="lined" iconSize={16} />
        <FileShareIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FileShareIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FileFolderIcon appearance="filled" iconSize={8} />
        <FileFolderIcon appearance="lined" iconSize={16} />
        <FileFolderIcon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FileFolderIcon appearance="lined" />
      </Box>
      <Box color="violet" fontSize="32px">
        <FileDocument1Icon appearance="filled" iconSize={8} />
        <FileDocument1Icon appearance="lined" iconSize={16} />
        <FileDocument1Icon appearance="filled" sx={{ color: semantic.color.commonTextBasic }} />
        <FileDocument1Icon appearance="lined" />
      </Box>
      <Box color="red" fontSize="24px">
        <FileExceldownloadIcon />
        <FileExcelnewIcon />
        <FileExceluploadIcon />
      </Box>
      <Box color="blue" fontSize="40px">
        <FileExceldownloadIcon />
        <FileExcelnewIcon />
        <FileExceluploadIcon />
      </Box>
      <Box color="green" fontSize="80px">
        <FileExceldownloadIcon />
        <FileExcelnewIcon />
        <FileExceluploadIcon />
      </Box>
      <Box color={semantic.color.commonBgBasic} fontSize="120px">
        <FileExceldownloadIcon sx={{ color: semantic.color.commonTextBasic }} />
        <FileExcelnewIcon sx={{ color: semantic.color.commonTextBasic }} />
        <FileExceluploadIcon sx={{ color: semantic.color.commonTextBasic }} />
      </Box>
    </Box>
  );
};
