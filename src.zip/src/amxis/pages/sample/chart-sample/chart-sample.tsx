import { Chart, draw } from '@amxis/design-system';
import { Box, useTheme } from '@mui/material';
export const ChartSample = () => {
  const {
    palette: { semantic },
  } = useTheme();

  const barChartData0 = {
    labels: ['영업', '제조', ' 재무', '물류', '인사'],
    datasets: [
      {
        label: '아이템1',
        data: [35, 52, 15, 28, 16],
        barThickness: 23.09,
        backgroundColor: [
          semantic.color.legendBasicBgColorCNormal,
          semantic.color.legendBasicBgColorAStrong,
          semantic.color.legendBasicBgColorCNormal,
          semantic.color.legendBasicBgColorCNormal,
          semantic.color.legendBasicBgColorCNormal,
        ],
        hoverBackgroundColor: [
          semantic.color.legendBasicBgColorCNormal,
          semantic.color.legendBasicBgColorAStrong,
          semantic.color.legendBasicBgColorCNormal,
          semantic.color.legendBasicBgColorCNormal,
          semantic.color.legendBasicBgColorCNormal,
        ],
      },
    ],
  };
  const barChartDataStacked = {
    labels: ['영업', '제조', ' 재무', '물류', '인사'],
    datasets: [
      {
        label: '아이템1',
        barThickness: 23.09,
        data: [6, 9.5, 5, 5, 3],
        backgroundColor: semantic.color.legendBasicBgColorAStrong,
        hoverBackgroundColor: semantic.color.legendBasicBgColorAStrong,
      },
      {
        label: '아이템2',
        barThickness: 23.09,
        data: [9, 19, 3, 10, 6],
        backgroundColor: semantic.color.legendBasicBgColorCNormal,
        hoverBackgroundColor: semantic.color.legendBasicBgColorCNormal,
      },
      {
        label: '아이템2',
        barThickness: 23.09,
        data: [15, 24, 6, 14, 6],
        backgroundColor: semantic.color.legendBasicBgColorDNormal,
        hoverBackgroundColor: semantic.color.legendBasicBgColorDNormal,
      },
    ],
  };
  const barChartData1 = {
    labels: ['영업', '제조', ' 재무', '물류', '인사'],
    datasets: [
      {
        label: '아이템1',
        data: [35, 52, 15, 28, 16],
        backgroundColor: draw('typeA', semantic.color.legendBasicBgColorANormal),
        hoverBackgroundColor: draw('typeA', semantic.color.legendBasicBgColorANormal),
        legendColor: semantic.color.legendBasicBgColorANormal,
      },
      {
        label: '아이템2',
        data: [35, 52, 15, 28, 16],
        backgroundColor: draw('typeB', semantic.color.legendBasicBgColorCNormal),
        hoverBackgroundColor: draw('typeB', semantic.color.legendBasicBgColorCNormal),
        legendColor: semantic.color.legendBasicBgColorCNormal,
      },
    ],
  };
  const barChartData2 = {
    labels: ['영업', '제조', '재무', '물류', '인사'],
    datasets: [
      {
        label: '아이템1',
        data: [35, 52, 15, 28, 16],
        backgroundColor: draw('typeC', semantic.color.legendBasicBgColorANormal),
        hoverBackgroundColor: draw('typeC', semantic.color.legendBasicBgColorANormal),
        legendColor: semantic.color.legendBasicBgColorANormal,
      },
      {
        label: '아이템2',
        data: [35, 52, 15, 28, 16],
        backgroundColor: draw('typeD', semantic.color.legendBasicBgColorCNormal),
        hoverBackgroundColor: draw('typeD', semantic.color.legendBasicBgColorCNormal),
        legendColor: semantic.color.legendBasicBgColorCNormal,
      },
    ],
  };
  const barChartData3 = {
    labels: ['영업', '제조', '재무', '물류', '인사'],
    datasets: [
      {
        label: '아이템1',
        data: [35, 52, 15, 28, 16],
        backgroundColor: draw('typeE', semantic.color.legendBasicBgColorANormal),
        hoverBackgroundColor: draw('typeE', semantic.color.legendBasicBgColorANormal),
        legendColor: semantic.color.legendBasicBgColorANormal,
      },
      {
        label: '아이템2',
        data: [35, 52, 15, 28, 16],
        backgroundColor: draw('typeF', semantic.color.legendBasicBgColorCNormal),
        hoverBackgroundColor: draw('typeF', semantic.color.legendBasicBgColorCNormal),
        legendColor: semantic.color.legendBasicBgColorCNormal,
      },
    ],
  };
  const barChartData4 = {
    labels: ['영업', '제조', '재무', '물류', '인사'],
    datasets: [
      {
        label: '아이템1',
        data: [35, 52, 15, 28, 16],
        backgroundColor: draw('typeG', semantic.color.legendBasicBgColorANormal),
        hoverBackgroundColor: draw('typeG', semantic.color.legendBasicBgColorANormal),
        legendColor: semantic.color.legendBasicBgColorANormal,
      },
      {
        label: '아이템2',
        data: [35, 52, 15, 28, 16],
        backgroundColor: draw('typeH', semantic.color.legendBasicBgColorCNormal),
        hoverBackgroundColor: draw('typeH', semantic.color.legendBasicBgColorCNormal),
        legendColor: semantic.color.legendBasicBgColorCNormal,
      },
    ],
  };
  const barChartData5 = {
    labels: ['영업', '제조', '재무', '물류', '인사'],
    datasets: [
      {
        label: '아이템1',
        data: [35, 52, 15, 28, 16],
        backgroundColor: draw('typeI', semantic.color.legendBasicBgColorANormal),
        hoverBackgroundColor: draw('typeI', semantic.color.legendBasicBgColorANormal),
        legendColor: semantic.color.legendBasicBgColorANormal,
      },
      {
        label: '아이템2',
        data: [35, 52, 15, 28, 16],
        backgroundColor: draw('typeJ', semantic.color.legendBasicBgColorCNormal),
        hoverBackgroundColor: draw('typeJ', semantic.color.legendBasicBgColorCNormal),
        legendColor: semantic.color.legendBasicBgColorCNormal,
      },
    ],
  };
  const barChartData6 = {
    labels: ['영업', '제조', '재무', '물류', '인사'],
    datasets: [
      {
        label: '아이템1',
        data: [35, 52, 15, 28, 16],
        backgroundColor: draw('typeK', semantic.color.legendBasicBgColorANormal),
        hoverBackgroundColor: draw('typeK', semantic.color.legendBasicBgColorANormal),
        legendColor: semantic.color.legendBasicBgColorANormal,
      },
      {
        label: '아이템2',
        data: [35, 52, 15, 28, 16],
        backgroundColor: draw('typeL', semantic.color.legendBasicBgColorCNormal),
        hoverBackgroundColor: draw('typeL', semantic.color.legendBasicBgColorCNormal),
        legendColor: semantic.color.legendBasicBgColorCNormal,
      },
    ],
  };

  const barChartData7 = {
    labels: ['영업', '제조', '재무', '물류', '인사'],
    datasets: [
      {
        label: '아이템1',
        barThickness: 23.85,
        data: [33, null, null, null, null],
        backgroundColor: semantic.color.legendBasicBgColorANormal,
        hoverBackgroundColor: semantic.color.legendBasicBgColorANormal,
      },
      {
        label: '아이템2',
        barThickness: 23.85,
        data: [null, 52, null, null, null],
        hoverBackgroundColor: semantic.color.legendBasicBgColorAStrong,
        backgroundColor: semantic.color.legendBasicBgColorAStrong,
      },
      {
        label: '아이템3',
        barThickness: 23.85,
        data: [null, null, 14, null, null],
        hoverBackgroundColor: semantic.color.legendBasicBgColorCNormal,
        backgroundColor: semantic.color.legendBasicBgColorCNormal,
      },
      {
        label: '아이템4',
        barThickness: 23.85,
        data: [null, null, null, 28, null],
        hoverBackgroundColor: semantic.color.legendBasicBgColorCStrong,
        backgroundColor: semantic.color.legendBasicBgColorCStrong,
      },
      {
        label: '아이템5',
        barThickness: 23.85,
        data: [null, null, null, null, 16],
        hoverBackgroundColor: semantic.color.legendBasicBgColorDNormal,
        backgroundColor: semantic.color.legendBasicBgColorDNormal,
      },
    ],
  };

  const donutChartData1 = {
    labels: ['아이템1', '아이템2', '아이템3', '아이템4'],
    datasets: [
      {
        data: [58, 18, 9, 2],
        backgroundColor: [
          semantic.color.legendBasicBgColorAStrong,
          semantic.color.legendBasicBgColorCStrong,
          semantic.color.legendBasicBgColorDStrong,
          semantic.color.legendBasicBgColorBStrong,
        ],
        hoverBackgroundColor: [
          semantic.color.legendBasicBgColorAStrong,
          semantic.color.legendBasicBgColorCStrong,
          semantic.color.legendBasicBgColorDStrong,
          semantic.color.legendBasicBgColorBStrong,
        ],
      },
    ],
  };

  const statusDonutChartData = {
    labels: ['Confirmed', 'Warning', 'Error', 'Done'],
    datasets: [
      {
        data: [58, 18, 9, 2],
        backgroundColor: [
          semantic.color.legendStatusBgConfirmedLight,
          semantic.color.legendStatusBgWarningMinorLight,
          semantic.color.legendStatusBgErrorLight,
          semantic.color.legendStatusBgDoneLight,
        ],
        hoverBackgroundColor: [
          semantic.color.legendStatusBgConfirmedLight,
          semantic.color.legendStatusBgWarningMinorLight,
          semantic.color.legendStatusBgErrorLight,
          semantic.color.legendStatusBgDoneLight,
        ],
      },
    ],
  };

  const statusBarChartData = {
    labels: ['1월', '2월', '3월', '4월', '5월'],
    datasets: [
      {
        label: 'Error',
        data: [18, 28, 8, 15, 8.5],
        barThickness: 23.85,
        backgroundColor: semantic.color.legendStatusBgErrorLight,
        hoverBackgroundColor: semantic.color.legendStatusBgErrorLight,
      },
      {
        label: 'Confirmed',
        data: [18, 28, 8, 15, 8.5],
        barThickness: 23.85,
        backgroundColor: semantic.color.legendStatusBgConfirmedLight,
        hoverBackgroundColor: semantic.color.legendStatusBgConfirmedLight,
      },
    ],
  };

  const statusLineChartData = {
    labels: ['1월', '2월', '3월', '4월', '5월', '6월'],
    datasets: [
      {
        label: '상태1',
        data: [15, 10, 16, 17, 10, 8],
        borderColor: semantic.color.legendStatusBorderColorConfirmedNormal,
      },
      {
        label: '상태3',
        data: [31, 35, 37, 44, 32, 28],
        borderColor: semantic.color.legendStatusBorderColorWarningMinorNormal,
      },
      {
        label: '상태2',
        data: [21, 23, 42, 25, 19, 21],
        borderColor: semantic.color.legendStatusBorderColorErrorNormal,
      },
      {
        label: '상태4',
        data: [9.8, 18, 8, 7.5, 6.5, 12.5],
        borderColor: semantic.color.legendStatusBorderColorDoneNormal,
      },
    ],
  };
  const donutChartData = {
    labels: ['아이템1', '아이템2', '아이템3', '아이템4'],
    datasets: [
      {
        data: [58, 18, 9, 2],
        backgroundColor: [
          semantic.color.legendBasicBgColorANormal,
          semantic.color.legendBasicBgColorCNormal,
          semantic.color.legendBasicBgColorDLight,
          semantic.color.legendBasicBgColorBNormal,
        ],
        hoverBackgroundColor: [
          semantic.color.legendBasicBgColorANormal,
          semantic.color.legendBasicBgColorCNormal,
          semantic.color.legendBasicBgColorDLight,
          semantic.color.legendBasicBgColorBNormal,
        ],
      },
    ],
  };

  const lineChartData = {
    labels: ['1월', '2월', '3월', '4월', '5월', '6월'],
    datasets: [
      {
        label: '아이템1',
        data: [31, 35, 37, 44, 32, 28],
        borderColor: semantic.color.legendBasicBgColorDStrong,
      },
      {
        label: '아이템2',
        data: [21, 23, 42, 25, 19, 21],
        borderColor: semantic.color.legendBasicBgColorCStrong,
      },
      {
        label: '아이템3',
        data: [15, 10, 16, 17, 10, 8],
        borderColor: semantic.color.legendBasicBgColorAStrong,
      },
      {
        label: '아이템4',
        data: [9.8, 18, 8, 7.5, 6.5, 12.5],
        borderColor: semantic.color.legendBasicBgColorBStrong,
      },
    ],
  };
  const lineChartData1 = {
    labels: ['1월', '2월', '3월', '4월', '5월', '6월'],
    datasets: [
      {
        label: '아이템1',
        data: [15, 10, 16, 17, 10, 8],
        borderColor: semantic.color.legendBasicBgColorAStrong,
        backgroundColor: 'rgba(216, 217, 249, 0.2)',
        fill: true,
      },
      {
        label: '아이템2',
        data: [21, 23, 42, 25, 19, 21],
        borderColor: semantic.color.legendBasicBgColorCStrong,
        fill: true,
        backgroundColor: 'rgba(218, 240, 136, 0.2)',
      },
      {
        label: '아이템3',
        data: [31, 35, 37, 44, 32, 28],
        borderColor: semantic.color.legendBasicBgColorDStrong,
        fill: true,
        backgroundColor: 'rgba(253, 212, 218, 0.2)',
      },
    ],
  };

  const patternBarChartData = {
    labels: ['영업', '제조', ' 재무', '물류', '인사'],
    datasets: [
      {
        label: '아이템1',
        data: [35, 52, 15, 28, 16],
        barThickness: 23.09,
        backgroundColor: [
          draw('typeA', semantic.color.legendBasicBgColorANormal),
          draw('typeC', semantic.color.legendBasicBgColorDNormal),
          draw('typeE', semantic.color.legendBasicBgColorCNormal),
          draw('typeG', semantic.color.legendBasicBgColorBStrong),
          draw('typeI', semantic.color.legendBasicBgColorDNormal),
        ],
        hoverBackgroundColor: [
          draw('typeA', semantic.color.legendBasicBgColorANormal),
          draw('typeC', semantic.color.legendBasicBgColorDNormal),
          draw('typeE', semantic.color.legendBasicBgColorCNormal),
          draw('typeG', semantic.color.legendBasicBgColorBStrong),
          draw('typeI', semantic.color.legendBasicBgColorDNormal),
        ],
      },
    ],
  };
  const patternDonutChartData = {
    labels: ['아이템1', '아이템2', '아이템3', '아이템4'],
    datasets: [
      {
        data: [58, 18, 9, 2],
        backgroundColor: [
          draw('typeL', semantic.color.legendBasicBgColorANormal),
          draw('typeE', semantic.color.legendBasicBgColorCNormal),
          draw('typeG', semantic.color.legendBasicBgColorDNormal),
          draw('typeI', semantic.color.legendBasicBgColorBNormal),
        ],
        hoverBackgroundColor: [
          draw('typeL', semantic.color.legendBasicBgColorANormal),
          draw('typeE', semantic.color.legendBasicBgColorCNormal),
          draw('typeG', semantic.color.legendBasicBgColorDNormal),
          draw('typeI', semantic.color.legendBasicBgColorBNormal),
        ],
      },
    ],
  };

  const donutChartLegendData = {
    labels: [
      '아이템1',
      '아이템2',
      '아이템3',
      '아이템4',
      '아이템5',
      '아이템6',
      '아이템7',
      '아이템8',
    ],
    datasets: [
      {
        data: [40, 30, 12, 7, 5, 3, 2, 1],
        backgroundColor: [
          semantic.color.legendBasicBgColorANormal,
          semantic.color.legendBasicBgColorCNormal,
          semantic.color.legendBasicBgColorDNormal,
          semantic.color.legendBasicBgColorBNormal,
          semantic.color.legendBasicBgColorAStrong,
          semantic.color.legendBasicBgColorCStrong,
          semantic.color.legendBasicBgColorDStrong,
          semantic.color.legendBasicBgColorBStrong,
        ],
        hoverBackgroundColor: [
          semantic.color.legendBasicBgColorANormal,
          semantic.color.legendBasicBgColorCNormal,
          semantic.color.legendBasicBgColorDNormal,
          semantic.color.legendBasicBgColorBNormal,
          semantic.color.legendBasicBgColorAStrong,
          semantic.color.legendBasicBgColorCStrong,
          semantic.color.legendBasicBgColorDStrong,
          semantic.color.legendBasicBgColorBStrong,
        ],
      },
    ],
  };
  return (
    <Box>
      <Box
        display="flex"
        justifyContent="center"
        height="290px"
        gap={'24px'}
        bgcolor={semantic.color.commonBgDeep}
      >
        <Box width={341} height={280}>
          <Chart
            appearance="bar"
            labels={barChartData0.labels}
            datasets={barChartData0.datasets}
            tooltip={false}
            legend={false}
            stacked
          />
        </Box>
        <Box width={341} height={280}>
          <Chart
            appearance="bar"
            labels={barChartData0.labels}
            datasets={barChartData0.datasets}
            tooltip={false}
            direction="horizontal"
            legend={false}
          />
        </Box>
        <Box width={341} height={280}>
          <Chart
            appearance="bar"
            labels={barChartDataStacked.labels}
            datasets={barChartDataStacked.datasets}
            legend={false}
            tooltip={false}
            stacked
          />
        </Box>
      </Box>
      <Box
        display="flex"
        justifyContent="center"
        height="350px"
        gap={'24px'}
        bgcolor={semantic.color.commonBgDeep}
      >
        <Box width={341} height={320}>
          <Chart
            appearance="pie"
            labels={donutChartData.labels}
            datasets={donutChartData.datasets}
            legend={false}
            legendType="button"
            labelFormater={(value) => `${value}%`}
          />
        </Box>
        <Box width={341} height={320}>
          <Chart
            appearance="donut"
            legendType="button"
            labels={donutChartData.labels}
            datasets={donutChartData.datasets}
          />
        </Box>
        <Box width={341} height={320}>
          <Chart
            appearance="donut"
            legend={false}
            labels={donutChartLegendData.labels}
            datasets={donutChartLegendData.datasets}
          />
        </Box>
      </Box>
      <Box
        display="flex"
        justifyContent="center"
        height="325px"
        gap={'24px'}
        bgcolor={semantic.color.commonBgDeep}
      >
        <Box width={341} height={318}>
          <Chart
            appearance="line"
            labels={lineChartData.labels}
            datasets={lineChartData.datasets}
          />
        </Box>
        <Box width={341} height={318}>
          <Chart
            appearance="curve"
            labels={lineChartData.labels}
            datasets={lineChartData.datasets}
          />
        </Box>
      </Box>

      <Box
        display="flex"
        justifyContent="center"
        height="325px"
        gap={'24px'}
        bgcolor={semantic.color.commonBgDeep}
      >
        <Box width={341} height={318}>
          <Chart
            appearance="line"
            labels={lineChartData1.labels}
            datasets={lineChartData1.datasets}
          />
        </Box>
        <Box width={341} height={318}>
          <Chart
            appearance="curve"
            labels={lineChartData1.labels}
            datasets={lineChartData1.datasets}
          />
        </Box>
      </Box>
      <Box
        display="flex"
        justifyContent="center"
        height="325px"
        gap={'24px'}
        bgcolor={semantic.color.commonBgDeep}
      >
        <Box width={341} height={318}>
          <Chart appearance="bar" labels={barChartData7.labels} datasets={barChartData7.datasets} />
        </Box>
        <Box width={341} height={318}>
          <Chart
            appearance="donut"
            labels={donutChartData1.labels}
            datasets={donutChartData1.datasets}
          />
        </Box>
      </Box>
      <Box
        display="flex"
        justifyContent="center"
        height="325px"
        gap={'24px'}
        bgcolor={semantic.color.commonBgDeep}
      >
        <Box width={341} height={318}>
          <Chart
            appearance="bar"
            labels={statusBarChartData.labels}
            datasets={statusBarChartData.datasets}
            stacked
          />
        </Box>
        <Box width={341} height={318}>
          <Chart
            appearance="donut"
            labels={statusDonutChartData.labels}
            datasets={statusDonutChartData.datasets}
          />
        </Box>
        <Box width={341} height={318}>
          <Chart
            appearance="line"
            labels={statusLineChartData.labels}
            datasets={statusLineChartData.datasets}
          />
        </Box>
      </Box>
      <Box
        display="flex"
        justifyContent="center"
        height="325px"
        gap={'24px'}
        bgcolor={semantic.color.commonBgDeep}
      >
        <Box width={341} height={278}>
          <Chart
            appearance="bar"
            labels={patternBarChartData.labels}
            datasets={patternBarChartData.datasets}
            legend={false}
          />
        </Box>
        <Box width={341} height={278}>
          <Chart
            appearance="donut"
            labels={patternDonutChartData.labels}
            datasets={patternDonutChartData.datasets}
            legend={false}
          />
        </Box>
      </Box>

      <Box
        display="flex"
        justifyContent="center"
        height="325px"
        gap={'24px'}
        bgcolor={semantic.color.commonBgDeep}
      >
        <Box width={341} height={280}>
          <Chart
            appearance="bar"
            labels={barChartData1.labels}
            datasets={barChartData1.datasets}
            tooltip={false}
          />
        </Box>
        <Box width={341} height={280}>
          <Chart
            appearance="bar"
            labels={barChartData2.labels}
            datasets={barChartData2.datasets}
            tooltip={false}
          />
        </Box>
        <Box width={341} height={280}>
          <Chart
            appearance="bar"
            labels={barChartData3.labels}
            datasets={barChartData3.datasets}
            tooltip={false}
          />
        </Box>
      </Box>

      <Box
        display="flex"
        justifyContent="center"
        height="290px"
        gap={'24px'}
        bgcolor={semantic.color.commonBgDeep}
      >
        <Box width={341} height={280}>
          <Chart
            appearance="bar"
            labels={barChartData4.labels}
            datasets={barChartData4.datasets}
            tooltip={false}
          />
        </Box>
        <Box width={341} height={280}>
          <Chart
            appearance="bar"
            labels={barChartData5.labels}
            datasets={barChartData5.datasets}
            tooltip={false}
          />
        </Box>
        <Box width={341} height={280}>
          <Chart
            appearance="bar"
            labels={barChartData6.labels}
            datasets={barChartData6.datasets}
            tooltip={false}
          />
        </Box>
      </Box>
    </Box>
  );
};
