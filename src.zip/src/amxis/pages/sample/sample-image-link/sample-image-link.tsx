import { ImageLink } from '@amxis/design-system';
import { Box } from '@mui/material';

export const SampleImageLink = () => {
  return (
    <Box display={'flex'} flexDirection="column" gap={4}>
      <Box display={'flex'} flexDirection="row" gap={4}>
        <ImageLink
          titleText="Title"
          backgroundColor="bgA"
          leadingGraphicSymbol={'/images/pyramid.png'}
          symbolSxProps={{ width: '34px', height: '34px' }}
        />
        <ImageLink
          titleText="Title"
          subText="Subtext"
          backgroundColor="bgA"
          leadingGraphicSymbol={'/images/manufacturing.svg'}
          subTextSxProps={{ letterSpacing: '-0.04em' }}
        />
        <ImageLink
          titleText="Title"
          backgroundColor="bgB"
          leadingGraphicSymbol={'/images/pyramid.png'}
          symbolSxProps={{ width: '34px', height: '34px' }}
        />
      </Box>
      <Box display={'flex'} flexDirection="row" gap={4}>
        <ImageLink
          titleText="Title"
          subText="Subtext"
          backgroundColor="bgB"
          leadingGraphicSymbol={'/images/elearning.png'}
          symbolSxProps={{ width: '34px', height: '34px' }}
          subTextSxProps={{ width: '190px' }}
        />
        <ImageLink
          titleText="Title"
          subText="Subtext"
          backgroundColor="bgC"
          leadingGraphicSymbol={'/images/card-image-8.jpg'}
          symbolSxProps={{ borderRadius: '8.57px', width: '36px', height: '36px' }}
        />
        <ImageLink
          titleText="Title"
          subText="Subtext"
          backgroundColor="bgD"
          leadingGraphicSymbol={'/images/billAGE.svg'}
        />
      </Box>
      <Box display={'flex'} flexDirection="row" gap={4}>
        <ImageLink
          titleText="Title"
          subText="Subtext"
          backgroundColor="bgE"
          leadingGraphicSymbol={'/images/thankyou.png'}
          symbolSxProps={{ width: '32px', height: '32px' }}
        />
        <ImageLink
          titleText="Title"
          backgroundColor="bgE"
          leadingGraphicSymbol={'/images/thankyou.png'}
          symbolSxProps={{ width: '32px', height: '32px' }}
        />
        <ImageLink
          titleText="Title"
          backgroundColor="bgF"
          leadingGraphicSymbol={'/images/kpi.png'}
          symbolSxProps={{ height: '33.6px', borderRadius: '5.25px' }}
        />
      </Box>
      <Box display={'flex'} flexDirection="row" gap={4}>
        <ImageLink
          titleText="Title"
          backgroundColor="bgG"
          subText="Subtext"
          leadingGraphicSymbol={'/images/kpi.png'}
          symbolSxProps={{ borderRadius: '8.57px', width: '36px', height: '36px' }}
        />
        <ImageLink
          titleText="Title"
          subText="Subtext"
          backgroundColor="bgH"
          leadingGraphicSymbol={'/images/kpi.png'}
          symbolSxProps={{ borderRadius: '8.57px', width: '36px', height: '36px' }}
        />
      </Box>
    </Box>
  );
};
