export { EmployeeModal as SampleEmployeeDialog } from '@/amxis/components/employee-modal';
