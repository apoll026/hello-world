import { useState } from 'react';
import { FormControlLabel, IconButton } from '@mui/material';
import { useTheme } from '@amxis/design-system';
import { Box } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { Button } from '@amxis/design-system';
import { Checkbox } from '@amxis/design-system';
import { Dialog, DialogActions, DialogContent, DialogTitle } from '@/amxis/components/ui/dialog';

import SampleDummyImage from '../__images/sample-dummy-image.png';

type SampleNoticeDialogProps = {
  open: boolean;
  onClose: () => void;
};

function SampleNoticeDialog({ open, onClose }: SampleNoticeDialogProps) {
  const [theme] = useTheme();
  const [checked, setChecked] = useState(false);

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="md">
      <DialogTitle
        sx={{
          position: 'relative',
          p: '24px',
          fontSize: '18px',
          fontWeight: 700,
          color: theme.palette.semantic.color.commonTextPrimaryExtreme,
          '&:before': {
            content: '""',
            display: 'inline-block',
            verticalAlign: 'middle',
            mr: '8px',
            width: '8px',
            height: '8px',
            borderRadius: '50%',
            bgcolor: theme.palette.semantic.color.commonTextPrimary,
          },
        }}
      >
        공지사항 타이틀
        <IconButton
          onClick={onClose}
          sx={{
            position: 'absolute',
            top: '50%',
            right: '18px',
            transform: 'translateY(-50%)',
            width: '32px',
            height: '32px',
            minWidth: '20px',
            svg: {
              color: theme.palette.semantic.color.commonTextLight,
              fontSize: '1.5rem',
            },
          }}
        >
          <CloseIcon fontSize="large" />
        </IconButton>
      </DialogTitle>
      <DialogContent sx={{ p: '0 24px' }}>
        <Box
          sx={{
            '& img': {
              maxWidth: '100%',
            },
            '& h2': {
              color: theme.palette.semantic.color.commonTextBasic,
              fontSize: '15px',
              fontWeight: 700,
              lineHeight: '150%',
              my: '24px',
            },
            '& p': {
              my: '24px',
            },
          }}
        >
          <img src={SampleDummyImage} alt="A dummy image" width="300px" />
          <h2>본문내용의 타이틀입니다.</h2>
          <p>
            목록의 본문 텍스트 입니다. 목록의 본문 텍스트 입니다. 목록의 본문 텍스트 입니다.목록의
            본문 텍스트 입니다.목록의 본문 텍스트 입니다.목록의 본문 텍스트 입니다.목록의 본문
            텍스트 입니다. 목록의 본문 텍스트 입니다. 목록의 본문 텍스트 입니다. 목록의 본문 텍스트
            입니다. 목록의 본문 텍스트 입니다.목록의 본문 텍스트 입니다.목록의 본문 텍스트
            입니다.목록의 본문 텍스트 입니다.목록의 본문 텍스트 입니다.목록의 본문 텍스트
            입니다.목록의 본문 텍스트 입니다.목록의 본문 텍스트 입니다.목록의 본문 텍스트
            입니다.목록의 본문 텍스트 입니다.목록의 본문 텍스트 입니다.목록의 본문 텍스트
            입니다.목록의 본문 텍스트 입니다.목록의 본문 텍스트 입니다.
          </p>
          <p>
            목록의 본문 텍스트 입니다. 목록의 본문 텍스트 입니다. 목록의 본문 텍스트 입니다.목록의
            본문 텍스트 입니다.목록의 본문 텍스트 입니다.목록의 본문 텍스트 입니다.목록의 본문
            텍스트 입니다. 목록의 본문 텍스트 입니다. 목록의 본문 텍스트 입니다. 목록의 본문 텍스트
            입니다. 목록의 본문 텍스트 입니다.목록의 본문 텍스트 입니다.목록의 본문 텍스트
            입니다.목록의 본문 텍스트 입니다.목록의 본문 텍스트 입니다.목록의 본문 텍스트
            입니다.목록의 본문 텍스트 입니다.목록의 본문 텍스트 입니다.목록의 본문 텍스트
            입니다.목록의 본문 텍스트 입니다.목록의 본문 텍스트 입니다.목록의 본문 텍스트
            입니다.목록의 본문 텍스트 입니다.목록의 본문 텍스트 입니다.
          </p>
        </Box>
      </DialogContent>
      <DialogActions sx={{ padding: '12px 24px' }}>
        <Box display="flex" justifyContent="space-between" alignItems="center" width="100%">
          <FormControlLabel
            control={<Checkbox />}
            onChange={() => setChecked(!checked)}
            checked={checked}
            value={checked}
            label="10일 동안 보지 않기"
            sx={{ ml: 0 }}
          />
          <Button size="medium" appearance="contained" priority="primary" onClick={onClose}>
            확인
          </Button>
        </Box>
      </DialogActions>
    </Dialog>
  );
}

export { SampleNoticeDialog };
