import { ButtonGroup, Spacer } from '@/amxis/components/layout';
import {
  Button,
  DatePickerCalendar,
  Description,
  DescriptionItem,
  DetailTableDataCell,
  DetailTableHeaderCell,
  DetailTableLine,
  DetailTableRow,
  Dialog,
  Label,
  TitleArea,
  useTheme,
} from '@amxis/design-system';
import { Box, DialogTitle, Typography } from '@mui/material';
import { t } from 'i18next';

const CustomDetailTablHeaderCell = ({ children, ...rest }) => {
  return (
    <DetailTableHeaderCell
      {...rest}
      sx={{
        width: '180px',
      }}
    >
      {children}
    </DetailTableHeaderCell>
  );
};

const SamplePublDialog = ({ open, onClose }) => {
  const [theme] = useTheme();

  const sample1: DescriptionItem[] = [
    {
      content: '요청한 검수일의 7일전에 검수 요청 ToDo가 발송됩니다.',
    },
    {
      content: '개발화면 검수 요청에 필요한 자료는 개발화면 URL입니다.',
    },
  ];

  return (
    <Box>
      <Dialog
        position="basic"
        type={'modal'}
        size={1200}
        open={open}
        customHeaderTitle={
          <DialogTitle
            sx={{
              position: 'relative',
              fontSize: '18px',
              fontWeight: 700,
              padding: 0,
              color: theme.palette.semantic.color.commonTextPrimaryExtreme,
              '&:before': {
                content: '""',
                display: 'inline-block',
                verticalAlign: '3px',
                mr: '8px',
                width: '8px',
                height: '8px',
                borderRadius: '50%',
                bgcolor: theme.palette.semantic.color.commonTextPrimary,
              },
            }}
          >
            {t('department-choice-popup.title.개발화면 검수 일정 요청', '개발화면 검수 일정 요청')}
          </DialogTitle>
        }
        customContentArea={
          <Box>
            <Box>
              <TitleArea title={t('', '__프로젝트 정보') ?? ''} isSubTitle />
              <Spacer type="h" size="4" />
              <DetailTableLine>
                <DetailTableRow>
                  <CustomDetailTablHeaderCell>
                    <Label labelText={t('', '__프로젝트 명') ?? ''} />
                  </CustomDetailTablHeaderCell>
                  <DetailTableDataCell colSpan={3}>
                    <Typography component="p" variant="bodyBasic">
                      웹 개발 플랫폼 프로젝트
                    </Typography>
                  </DetailTableDataCell>
                </DetailTableRow>
                <DetailTableRow>
                  <CustomDetailTablHeaderCell>
                    <Label labelText={t('', '__PI 담당자') ?? ''} />
                  </CustomDetailTablHeaderCell>
                  <DetailTableDataCell>
                    <Typography component="p" variant="bodyBasic">
                      조장은 책임
                    </Typography>
                  </DetailTableDataCell>
                  <CustomDetailTablHeaderCell>
                    <Label labelText={t('', '__PI 팀') ?? ''} />
                  </CustomDetailTablHeaderCell>
                  <DetailTableDataCell>
                    <Typography component="p" variant="bodyBasic">
                      업무혁신기획팀
                    </Typography>
                  </DetailTableDataCell>
                </DetailTableRow>
                <DetailTableRow>
                  <CustomDetailTablHeaderCell>
                    <Label labelText={t('', '__PM') ?? ''} />
                  </CustomDetailTablHeaderCell>
                  <DetailTableDataCell>
                    <Typography component="p" variant="bodyBasic">
                      윤형노 책임
                    </Typography>
                  </DetailTableDataCell>
                  <CustomDetailTablHeaderCell>
                    <Label labelText={t('', '__업체명') ?? ''} />
                  </CustomDetailTablHeaderCell>
                  <DetailTableDataCell>
                    <Typography component="p" variant="bodyBasic">
                      AMI
                    </Typography>
                  </DetailTableDataCell>
                </DetailTableRow>
                <DetailTableRow>
                  <CustomDetailTablHeaderCell>
                    <Label labelText={t('', '__프로젝트 기간') ?? ''} />
                  </CustomDetailTablHeaderCell>
                  <DetailTableDataCell sx={{ width: '394px' }}>
                    <Typography component="p" variant="bodyBasic">
                      2024.08.01 ~ 2024.11.30
                    </Typography>
                  </DetailTableDataCell>
                  <CustomDetailTablHeaderCell>
                    <Label labelText={t('', '__디자인 검수 확인일') ?? ''} />
                  </CustomDetailTablHeaderCell>
                  <DetailTableDataCell>
                    <Typography component="p" variant="bodyBasic">
                      2024.09.30
                    </Typography>
                  </DetailTableDataCell>
                </DetailTableRow>
              </DetailTableLine>
            </Box>
            <Spacer type="h" size="12" />
            <Box>
              <TitleArea title={t('', '__개발화면 검수 일정') ?? ''} isSubTitle />
              <Spacer type="h" size="4" />
              <DetailTableLine>
                <DetailTableRow>
                  <CustomDetailTablHeaderCell>
                    <Label labelText={t('', '__검수 요청일') ?? ''} />
                  </CustomDetailTablHeaderCell>
                  <DetailTableDataCell>
                    <Box>
                      <DatePickerCalendar
                        elevation
                        onChange={function Ua() {}}
                        size="medium"
                        usecase="date"
                        value={null}
                        sx={{ width: '250px', '> div': { width: '100%' } }}
                      />
                    </Box>
                  </DetailTableDataCell>
                </DetailTableRow>
              </DetailTableLine>
            </Box>
            <Spacer type="h" size="4" />
            <Description
              title="개발화면 검수 일정 요청"
              usecase="normal"
              ordered={false}
              listData={sample1}
            />
            <Spacer type="h" size="4" />
            <ButtonGroup>
              <Button size="medium" appearance="outlined" priority="normal" onClick={onClose}>
                {t('common.button.취소', '취소')}
              </Button>
              <Button
                size="medium"
                appearance="contained"
                priority="primary"
                iconPosition="leading"
              >
                {t('common.button.요청', '요청')}
              </Button>
            </ButtonGroup>
          </Box>
        }
        handleClose={onClose}
      />
    </Box>
  );
};

export default SamplePublDialog;
