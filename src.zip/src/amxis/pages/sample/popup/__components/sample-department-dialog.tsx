export { DepartmentModal as SampleDepartmentDialog } from '@/amxis/components/department-modal';
