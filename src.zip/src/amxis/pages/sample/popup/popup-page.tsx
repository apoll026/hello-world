import { ContainerLayout } from '@/amxis/components/container-layout';
import DepartmentSinglePopup from '@/amxis/components/department/department-single-popup.tsx';
import EmployeeSinglePopup from '@/amxis/components/employee/employee-single-popup.tsx';
import { Button, useMessageBar, useTheme } from '@amxis/design-system';
import OpenInNewRoundedIcon from '@mui/icons-material/OpenInNewRounded';
import { Box } from '@mui/material';
import { useState } from 'react';
import { ContainerBox } from '../__components/container-box.tsx';
import { DocumentContentH2 } from '../__components/document-content-h2.tsx';
import { DocumentContentH3 } from '../__components/document-content-h3.tsx';
import { SamplePageTitle } from '../__components/sample-page-title.tsx';
import { SampleNoticeDialog } from './__components/sample-notice-dialog.tsx';
import SamplePublDialog from './__components/sample-publ-dialog.tsx';
import SamplePopupDemo1Image from './__images/sample-popup-demo-1.png';
import SamplePopupDemo2Image from './__images/sample-popup-demo-2.png';
import SamplePopupDemo3Image from './__images/sample-popup-demo-3.png';

function SamplePopupPage() {
  const [theme] = useTheme();
  const { showMessageBar } = useMessageBar();

  const [isOpenSampleEmployeeDialog, setIsOpenSampleEmployeeDialog] = useState(false);
  const [isOpenSampleDepartmentDialog, setIsOpenSampleDepartmentDialog] = useState(false);
  const [isOpenSampleNoticeDialog, setIsOpenSampleNoticeDialog] = useState(false);
  const [isOpenSamplePublDialog, setIsOpenSamplePublDialog] = useState(false);

  return (
    <>
      <ContainerBox>
        <ContainerLayout>
          <SamplePageTitle>공통팝업</SamplePageTitle>
          <Box mt="48px">
            <DocumentContentH2 title="사용자조회 팝업">
              조직도 트리 검색 후 조직 선택 시 조직에 속한 사용자를 조회하는 팝업이다. 사용방법에
              따라 단건인 경우 라디오 버튼으로, 다건 선택 시 체크박스로 컴포넌트를 구성한다.
            </DocumentContentH2>
            <Box mt="24px">
              <DocumentContentH3 title="1. Demo" />
              <Box mt="16px">
                <Button
                  size="large"
                  appearance="contained"
                  priority="normal"
                  iconPosition="trailing"
                  iconComponent={<OpenInNewRoundedIcon />}
                  onClick={() => setIsOpenSampleEmployeeDialog(true)}
                >
                  사용자조회 팝업
                </Button>
              </Box>
              <Box mt="16px">
                <Box
                  component="img"
                  src={SamplePopupDemo1Image}
                  alt="A snapshot for a popup demo1"
                  width="100%"
                  maxWidth="1216px"
                />
              </Box>
            </Box>
            <Box mt="24px">
              <DocumentContentH3 title="2. 화면구성" />
              <Box
                component="ul"
                pl="10px"
                ml="12px"
                mt="8px"
                color={theme.palette.semantic.color.commonTextLight}
                fontSize="16px"
                fontWeight={400}
                lineHeight="150%"
                letterSpacing="-0.16px"
                sx={{
                  listStyle: 'disc',
                }}
              >
                <Box component="li">검색어는 이름, 부서명, 이메일 검색어를 입력한다.</Box>
                <Box component="li">
                  부서목록은 LG 에너지솔루션의 조직도를 검색해 트리로 구성한다.
                </Box>
                <Box component="li">
                  조직도 &gt; 부서 선택 시, 부서에 속한 사용자 목록이 좌측 목록에 조회된다.
                </Box>
                <Box component="li">
                  좌측 목록의 선택 방식은 화면 사용방법에 따라 단건(라디오버튼), 다건(체크박스)로
                  제공한다.
                </Box>
              </Box>
            </Box>
          </Box>
          <Box mt="48px">
            <DocumentContentH2 title="부서조회 팝업" />
            <Box mt="16px">
              <Button
                size="large"
                appearance="contained"
                priority="normal"
                iconPosition="trailing"
                iconComponent={<OpenInNewRoundedIcon />}
                onClick={() => setIsOpenSampleDepartmentDialog(true)}
              >
                부서조회 팝업
              </Button>
            </Box>
            <Box mt="16px">
              <Box
                component="img"
                src={SamplePopupDemo2Image}
                alt="A snapshot for a popup demo2"
                width="100%"
                maxWidth="800px"
              />
            </Box>
          </Box>

          <Box mt="48px">
            <DocumentContentH2 title="공지사항 팝업" />
            <Box mt="16px">
              <Button
                size="large"
                appearance="contained"
                priority="normal"
                iconPosition="trailing"
                iconComponent={<OpenInNewRoundedIcon />}
                onClick={() => setIsOpenSampleNoticeDialog(true)}
              >
                공지사항 팝업
              </Button>
            </Box>
            <Box mt="16px">
              <Box
                component="img"
                src={SamplePopupDemo3Image}
                alt="A snapshot for a popup demo3"
                width="100%"
                maxWidth="800px"
              />
            </Box>
          </Box>

          <Box mt="48px">
            <DocumentContentH2 title="퍼블 샘플 팝업" />
            <Box mt="16px">
              <Button
                size="large"
                appearance="contained"
                priority="normal"
                iconPosition="trailing"
                iconComponent={<OpenInNewRoundedIcon />}
                onClick={() => setIsOpenSamplePublDialog(true)}
              >
                샘플팝업
              </Button>
            </Box>
          </Box>
        </ContainerLayout>
      </ContainerBox>

      {isOpenSampleEmployeeDialog && (
        <EmployeeSinglePopup
          open={isOpenSampleEmployeeDialog}
          setOpen={(open: boolean) => setIsOpenSampleEmployeeDialog(open)}
          onSave={(employee) => {
            // handleChangeEmp(employee, false);
            setIsOpenSampleEmployeeDialog(false);
            showMessageBar({
              message: `${employee.map((employee) => employee.empName).join(',')} 선택되었습니다.`,
              usecase: 'success',
            });
          }}
          // selectedEmployee={empList}
        />
      )}

      {isOpenSampleDepartmentDialog && (
        <DepartmentSinglePopup
          open={isOpenSampleDepartmentDialog}
          setOpen={(open: boolean) => setIsOpenSampleDepartmentDialog(open)}
          onSave={(dept) => {
            showMessageBar({
              message: `${dept.map((department) => department.deptNm).join(',')} 선택되었습니다.`,
              usecase: 'success',
            });
          }}
          // selectedDept={deptList}
        />
      )}

      {isOpenSampleNoticeDialog && (
        <SampleNoticeDialog
          open={isOpenSampleNoticeDialog}
          onClose={() => setIsOpenSampleNoticeDialog(false)}
        />
      )}

      {isOpenSamplePublDialog && (
        <SamplePublDialog
          open={isOpenSamplePublDialog}
          onClose={() => setIsOpenSamplePublDialog(false)}
        />
      )}
    </>
  );
}

export { SamplePopupPage };
