import { useState } from 'react';
import { Box, Typography } from '@mui/material';
import { v4 as uuidv4 } from 'uuid';
import {
  CommentArea,
  CommentUser,
  InputComment,
  Comment,
  CommentReaction,
} from '@amxis/design-system';
import dayjs from 'dayjs';
import 'dayjs/locale/ko';

dayjs.locale('ko');

const MOCK_CURRENT_USER: CommentUser = {
  id: 2,
  name: '장AMI 책임',
  department: '스마트팩토리 제조설비관리팀',
  avatar: '/src/assets/icons/avatarSingleContents.svg',
  avatarContentType: 'icon',
  avatarOnClick: (user: CommentUser) => {
    alert(user?.name);
  },
};

const MOCK_COMMENT: Comment[] = [
  {
    id: uuidv4(),
    userId: MOCK_CURRENT_USER.id,
    userName: MOCK_CURRENT_USER.name,
    userPermissions: ['edit', 'delete'],
    userDepartment: MOCK_CURRENT_USER.department,
    reactions: { agreedBy: [], disAgreedBy: [] },
    content: '댓글의 답글내용입니다. 댓글의 내용입니다.',
    date: dayjs().format('YYYY-MM-DD A hh:mm'),
    userAvatar: '/src/assets/icons/avatarSingleContents.svg',
    userAvatarContentType: 'icon',
    userAvatarOnClick: (user: Comment) => {
      alert(user?.userName);
    },
    replies: [
      {
        id: uuidv4(),
        userId: MOCK_CURRENT_USER.id,
        userName: MOCK_CURRENT_USER.name,
        userPermissions: ['edit'],
        userDepartment: MOCK_CURRENT_USER.department,
        reactions: { agreedBy: [], disAgreedBy: [] },
        content: '댓글의 답글내용입니다. 댓글의 내용입니다.',
        date: dayjs().format('YYYY-MM-DD A hh:mm'),
        userAvatar: '/src/assets/icons/avatarSingleContents.svg',
        replies: [
          {
            id: uuidv4(),
            userId: MOCK_CURRENT_USER.id,
            userName: MOCK_CURRENT_USER.name,
            userPermissions: ['delete'],
            userDepartment: MOCK_CURRENT_USER.department,
            reactions: { agreedBy: [], disAgreedBy: [] },
            content: '댓글의 답글내용입니다. 댓글의 내용입니다.',
            date: dayjs().format('YYYY-MM-DD A hh:mm'),
            userAvatar: '/src/assets/icons/avatarSingleContents.svg',
            replies: [
              {
                id: uuidv4(),
                userId: MOCK_CURRENT_USER.id,
                userName: MOCK_CURRENT_USER.name,
                userDepartment: MOCK_CURRENT_USER.department,
                reactions: { agreedBy: [], disAgreedBy: [] },
                content: '댓글의 답글내용입니다. 댓글의 내용입니다.',
                date: dayjs().format('YYYY-MM-DD A hh:mm'),
                userAvatar: '/src/assets/icons/avatarSingleContents.svg',
              },
            ],
          },
        ],
      },
    ],
  },
  {
    id: uuidv4(),
    userId: MOCK_CURRENT_USER.id,
    userName: MOCK_CURRENT_USER.name,
    userDepartment: MOCK_CURRENT_USER.department,
    reactions: { agreedBy: [], disAgreedBy: [] },
    content: '댓글의 답글내용입니다. 댓글의 내용입니다.',
    date: dayjs().format('YYYY-MM-DD A hh:mm'),
    userAvatar: '/src/assets/icons/avatarSingleContents.svg',
  },
  {
    id: uuidv4(),
    userId: MOCK_CURRENT_USER.id,
    userName: MOCK_CURRENT_USER.name,
    userDepartment: MOCK_CURRENT_USER.department,
    reactions: { agreedBy: [], disAgreedBy: [] },
    content: '박AMI 님이 가지고 계실거에요.',
    date: dayjs().format('YYYY-MM-DD A hh:mm'),
    userAvatar: '/src/assets/icons/avatarSingleContents.svg',
  },
  {
    id: uuidv4(),
    userId: MOCK_CURRENT_USER.id,
    userName: MOCK_CURRENT_USER.name,
    userDepartment: MOCK_CURRENT_USER.department,
    reactions: { agreedBy: [], disAgreedBy: [] },
    content: '감사합니다.',
    date: dayjs().format('YYYY-MM-DD A hh:mm'),
    userAvatar: '/src/assets/icons/avatarSingleContents.svg',
  },
];

export const SampleCommentArea = () => {
  const [comments, setComments] = useState<Comment[]>([]);

  const handleAddNewComment = (detail: InputComment, anonymous: boolean) => {
    const newComment: Comment = {
      id: uuidv4(),
      content: detail.content,
      attachedFiles: detail.attachedFiles,
      userPermissions: ['edit', 'delete'],
      userId: MOCK_CURRENT_USER.id,
      userName: MOCK_CURRENT_USER.name,
      userDepartment: MOCK_CURRENT_USER.department,
      userAvatar: MOCK_CURRENT_USER.avatar,
      anonymous: anonymous,
      reactions: { agreedBy: [], disAgreedBy: [] },
      date: dayjs().format('YYYY-MM-DD A hh:mm'),
    };
    setComments((prev) => [newComment, ...prev]);
  };

  const handleDeleteComment = (id: number | string) => {
    setComments((prev) => deleteCommentById(id, prev));
  };

  const handleEditComment = (id: number | string, detail: InputComment) => {
    setComments((prev) => editCommentById(id, detail, prev));
  };

  // Recursive function to delete a comment or reply by ID
  const deleteCommentById = (commentId: number | string, commentsArray: Comment[]): Comment[] => {
    return commentsArray.reduce((acc, comment) => {
      if (comment.id === commentId) {
        // Comment found, skip it to exclude it from the result array
        return acc;
      }

      if (comment.replies && comment.replies.length > 0) {
        // Check and recursively delete in sub-comments
        comment.replies = deleteCommentById(commentId, comment.replies);

        // If there are no more sub-comments after deletion, remove the 'replies' property
        if (comment.replies.length === 0) {
          delete comment.replies;
        }
      }

      return [...acc, comment];
    }, [] as Comment[]);
  };

  const editCommentById = (
    commentId: number | string,
    newContent: InputComment,
    commentsArray: Comment[]
  ): Comment[] => {
    return commentsArray.map((comment) => {
      if (comment.id === commentId) {
        return {
          ...comment,
          content: newContent.content,
          attachedFiles: newContent.attachedFiles,
          date: newContent.date,
        };
      }

      if (comment.replies && comment.replies.length > 0) {
        comment.replies = editCommentById(commentId, newContent, comment.replies);
      }

      return comment;
    });
  };

  // Recursive function to do operation by ID
  const operateOnCommentById = (
    commentId: number | string,
    commentsArray: Comment[],
    operation: (comment: Comment) => Comment
  ): Comment[] => {
    return commentsArray.map((comment) => {
      if (comment.id === commentId) {
        // Perform the specified operation on the comment
        return operation(comment);
      }

      if (comment.replies && comment.replies.length > 0) {
        // Check and recursively operate in sub-comments
        comment.replies = operateOnCommentById(commentId, comment.replies, operation);
      }

      return comment;
    });
  };

  // Function to handle adding a reply to a comment
  const addReplyToComment = (commentId: number | string, detail: InputComment) => {
    const reply: Comment = {
      id: uuidv4(),
      content: detail.content,
      attachedFiles: detail.attachedFiles,
      userId: MOCK_CURRENT_USER.id,
      userName: MOCK_CURRENT_USER.name,
      userDepartment: MOCK_CURRENT_USER.department,
      userAvatar: MOCK_CURRENT_USER.avatar,
      reactions: { agreedBy: [], disAgreedBy: [] },
    };
    setComments((prevComments) =>
      operateOnCommentById(commentId, prevComments, (comment) => ({
        ...comment,
        replies: [reply, ...(comment.replies || [])],
      }))
    );
  };

  const handleReactComment = (commentId: string | number, actionType: CommentReaction) => {
    if (actionType === 'AGREED') {
      setComments((prevComments) =>
        operateOnCommentById(commentId, prevComments, handleAgreedEvent)
      );
    }
    if (actionType === 'DISAGREED') {
      setComments((prevComments) =>
        operateOnCommentById(commentId, prevComments, handleDisagreedEvent)
      );
    }
  };

  const handleAgreedEvent = (comment: Comment) => {
    const didThisPersonAlreadyAgree = comment.reactions.agreedBy.includes(MOCK_CURRENT_USER.id);
    if (didThisPersonAlreadyAgree) {
      return {
        ...comment,
        reactions: {
          ...comment.reactions,
          agreedBy: comment.reactions.agreedBy.filter(
            (agreement) => agreement !== MOCK_CURRENT_USER.id
          ),
          disAgreedBy: comment.reactions.disAgreedBy.filter(
            (disagreement) => disagreement !== MOCK_CURRENT_USER.id
          ),
        },
      };
    }
    return {
      ...comment,
      reactions: {
        ...comment.reactions,
        agreedBy: [...comment.reactions.agreedBy, MOCK_CURRENT_USER.id],
        disAgreedBy: comment.reactions.disAgreedBy.filter(
          (disagree) => disagree !== MOCK_CURRENT_USER.id
        ),
      },
    };
  };

  const handleDisagreedEvent = (comment: Comment) => {
    const didThisPersonAlreadyDisagree = comment.reactions.disAgreedBy.includes(
      MOCK_CURRENT_USER.id
    );
    if (didThisPersonAlreadyDisagree) {
      return {
        ...comment,
        reactions: {
          ...comment.reactions,
          agreedBy: comment.reactions.agreedBy.filter(
            (agreement) => agreement !== MOCK_CURRENT_USER.id
          ),
          disAgreedBy: comment.reactions.disAgreedBy.filter(
            (disagreement) => disagreement !== MOCK_CURRENT_USER.id
          ),
        },
      };
    }
    return {
      ...comment,
      reactions: {
        ...comment.reactions,
        disAgreedBy: [...comment.reactions.disAgreedBy, MOCK_CURRENT_USER.id],
        agreedBy: comment.reactions.agreedBy.filter((agree) => agree !== MOCK_CURRENT_USER.id),
      },
    };
  };

  return (
    <Box display="flex" gap="150px" p="20px">
      <Box width="700px">
        <Typography variant="h1" mb="20px">
          Basic Comment Area
        </Typography>
        <CommentArea
          language="en"
          maxlength={1300}
          anonymousUserLabel={'익명'}
          user={MOCK_CURRENT_USER}
          comments={comments}
          allowUploaded={['.pdf', '.jpg', '.png']}
          reactionVariant="agreement"
          addNewComment={handleAddNewComment}
          deleteComment={handleDeleteComment}
          editComment={handleEditComment}
          replyComment={addReplyToComment}
          reactComment={handleReactComment}
        />
      </Box>
      <Box width="700px">
        <Typography variant="h1" mb="20px">
          Basic Comment With Comments
        </Typography>
        <CommentArea
          user={MOCK_CURRENT_USER}
          comments={MOCK_COMMENT}
          isAttachButton={false}
          maxDepthForReply={2}
          replyLabel="Reply"
          allowUploaded={['.pdf', '.jpg', '.png']}
          reactionVariant="like"
          addNewComment={() => {}}
          deleteComment={() => {}}
          editComment={() => {}}
          replyComment={() => {}}
          reactComment={() => {}}
        />
      </Box>
    </Box>
  );
};
