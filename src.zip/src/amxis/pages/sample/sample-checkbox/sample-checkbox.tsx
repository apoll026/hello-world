import { useEffect, useState } from 'react';
import { Box, Typography } from '@mui/material';
import { $semantic } from '@amxis/design-system/design-token';
import { Checkbox, CheckboxProps } from '@amxis/design-system';

const SAMPLE_CHECKBOX_ITEMS: CheckboxProps[] = [
  {
    id: 'checkBox1',
    labelText: 'option1',
    value: 'option1',
  },
  {
    id: 'checkBox2',
    labelText: 'option2',
    value: 'option2',
  },
  {
    id: 'checkBox3',
    labelText: 'option3',
    value: 'option3',
  },
];

export const SampleCheckbox = () => {
  const [checkboxItems, setCheckboxItems] = useState<CheckboxProps[]>(SAMPLE_CHECKBOX_ITEMS);
  const [headerChecked, setHeaderChecked] = useState<boolean>();
  const [selectedValue, setSelectedValue] = useState<string>();

  const handleOnChange = (id: string, checked: boolean) => {
    setCheckboxItems(
      checkboxItems.map((item) => (item.id === id ? { ...item, checked: checked } : item))
    );
  };
  const handleHeaderOnChange = (checked: boolean) => {
    setCheckboxItems(checkboxItems.map((item) => ({ ...item, checked: checked })));
  };

  useEffect(() => {
    const checkedItems = checkboxItems
      .filter((item) => {
        return item.checked;
      })
      .map((item) => {
        return item.value;
      });
    setHeaderChecked(checkedItems.length === checkboxItems.length);
    setSelectedValue(checkedItems.join(', '));
  }, [checkboxItems]);

  return (
    <>
      <Typography>{`[${selectedValue}]`}</Typography>
      <Box display="flex" gap={`${$semantic.shared.size.sizesCommon.size12}px`}>
        <Checkbox
          labelText="전체"
          checked={headerChecked}
          indeterminate={
            !checkboxItems.every((item) => item.checked) &&
            !checkboxItems.every((item) => !item.checked)
          }
          onChange={handleHeaderOnChange}
        />
        {checkboxItems.map((item) => {
          return (
            <Checkbox
              key={item.id}
              value={item.value}
              labelText={item.labelText}
              checked={item.checked}
              onChange={(checkedStatus) => handleOnChange(item.id ?? '', checkedStatus)}
            />
          );
        })}
      </Box>
    </>
  );
};
