import { BreadCrumbDetail,OptionListItemType  } from '@amxis/design-system';

export const SAMPLE_BREADCRUMB_DATA: BreadCrumbDetail[] = [
  {
    label: 'Home',
    url: '/home',
    onClick: () => alert('home'),
  },
  {
    label: 'Child1',
    url: '/child1',
    onClick: () => alert('child1'),
  },
  {
    label: 'Child2',
    url: '/child2',
    onClick: () => alert('child2'),
  },
  {
    label: 'Child3',
    url: '/child3',
    onClick: () => alert('child3'),
  },
  {
    label: 'Child4',
    url: '/child4',
    onClick: () => alert('child4'),
  },
  {
    label: 'Page Name',
  },
];

export const CASCADING_DATA: OptionListItemType[] = [
  {
    label: '경기도',
    value: '경기도',
  },
  {
    label: '서울특별시',
    value: '서울특별시',
    children: [
      {
        label: '광진구',
        value: '광진구',
      },
      {
        label: '마포구',
        value: '마포구',
        children: [
          {
            label: '공덕동',
            value: '공덕동',
          },
          {
            label: '구수동',
            value: '구수동',
          },
          {
            label: '노고산동',
            value: '노고산동',
          },
          {
            label: '당인동',
            value: '당인동',
          },
        ],
      },
      {
        label: '성동구',
        value: '성동구',
      },
      {
        label: '용산구',
        value: '용산구',
      },
      {
        label: '서대문구',
        value: '서대문구',
      },
    ],
  },
  {
    label: '인천광역시',
    value: '인천광역시',
  },
  {
    label: '강원도',
    value: '강원도',
  },
];

export const SAMPLE_BREADCRUMB_DATA_FOR_HANDLE_CLICK: BreadCrumbDetail[] = [
  {
    label: 'url',
    url: '/url',
  },
  {
    label: 'url',
    url: '/url',
  },
  {
    label: 'onclick',
    onClick: () => alert('onclick'),
  },
  {
    label: 'url with onclick',
    url: '/url-with-onclick',
    onClick: () => alert('url with onclick'),
  },
  {
    label: 'onclick',
    onClick: () => alert('onclick'),
  },
  {
    label: 'url with onclick',
    url: '/url-with-onclick',
    onClick: () => alert('url with onclick'),
  },
];

// option list with scroll
export const SAMPLE_SCROLL: OptionListItemType[] = [
  {
    label: 'option1',
    value: 'option1',
  },
  {
    label: 'option2',
    value: 'option2',
    disabled: true,
    figures: 999,
  },
  {
    label: 'option3',
    value: 'option3',
    figures: 999,
  },
  {
    label: 'option4',
    value: 'option4',
  },
  {
    label: 'option5',
    value: 'option5',
    figures: 999,
  },
  {
    label: 'option6',
    value: 'option6',
    figures: 999,
  },
  {
    label: 'option7',
    value: 'option7',
  },
  {
    label: 'option8',
    value: 'option8',
    disabled: true,
    figures: 999,
  },
  {
    label: 'option9',
    value: 'option9',
    figures: 999,
  },
  {
    label: 'option10',
    value: 'option10',
  },
  {
    label: 'option11',
    value: 'option11',
    disabled: true,
    figures: 999,
  },
  {
    label: 'option12',
    value: 'option12',
    figures: 999,
  },
  {
    label: 'option13',
    value: 'option13',
  },
  {
    label: 'option14',
    value: 'option14',
    figures: 999,
  },
];
