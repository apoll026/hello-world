import React from 'react';
import { Box, Button, Typography } from '@mui/material';

import { Breadcrumb, OptionList, OptionListItem } from '@amxis/design-system';
import Time from '@/amxis/assets/icons/time.svg?react';
import {
  CASCADING_DATA,
  SAMPLE_BREADCRUMB_DATA,
  SAMPLE_BREADCRUMB_DATA_FOR_HANDLE_CLICK,
  SAMPLE_SCROLL,
} from './sample-option-list-data.ts';

export const SampleOptionList = () => {
  // cascading menu single selection
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(anchorEl ? null : event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const [selectedValue, setSelectedValue] = React.useState('');
  const onSelectedClick = (value?: string) => {
    handleClose();
    setSelectedValue(value ?? '');
  };

  // option List With Scroll
  const [anchorEl2, setAnchorEl2] = React.useState<null | HTMLElement>(null);
  const open2 = Boolean(anchorEl2);
  const handleClick2 = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl2(anchorEl2 ? null : event.currentTarget);
  };
  const handleClose2 = () => {
    setAnchorEl2(null);
  };

  return (
    <Box my="24px">
      <Box>
        <Box sx={{ height: 8 }}></Box>
        <Typography variant="h4">BreadCrumbs</Typography>
        <Breadcrumb data={SAMPLE_BREADCRUMB_DATA} />
      </Box>
      <Box>
        <Box sx={{ height: 8 }}></Box>
        <Typography variant="h4">BreadCrumbs without Collaspe</Typography>
        <Breadcrumb data={SAMPLE_BREADCRUMB_DATA} maxLength={6} />
      </Box>
      <Box>
        <Box sx={{ height: 8 }}></Box>
        <Typography variant="h4">BreadCrumbs handle click event</Typography>
        <Breadcrumb data={SAMPLE_BREADCRUMB_DATA_FOR_HANDLE_CLICK} />
      </Box>
      <Box>
        <Box sx={{ height: 8 }}></Box>
        <Typography variant="h4">Cascading Select</Typography>
        <Box display={'flex'}>
          <Button onClick={handleClick}>지역선택</Button>
          <Typography>{selectedValue}</Typography>
        </Box>
        <OptionList
          anchorEl={anchorEl}
          open={open}
          onMouseLeave={handleClose}
          onSelectClick={onSelectedClick}
          options={CASCADING_DATA}
          type="single"
        />
      </Box>
      <Box>
        <Box sx={{ height: 8 }}></Box>
        <Typography variant="h4">Option List With Scroll</Typography>
        <Button onClick={handleClick2}>Open Option List</Button>
        <OptionList
          anchorEl={anchorEl2}
          open={open2}
          onMouseLeave={handleClose2}
          options={SAMPLE_SCROLL}
          type="single"
          usecase="basic"
        />
      </Box>

      <Box>
        <Box sx={{ height: 8 }}></Box>
        <Typography variant="h4">Option Item With Long Label(ellipsis) & icon</Typography>
        <OptionListItem
          // usecase="basic"
          width={200}
          label="testtesttesttesttesttesttesttesttesttest"
          value="test"
          multiLine="No"
          figures={999}
          icon={<Time />}
          selected
        />
      </Box>
    </Box>
  );
};
