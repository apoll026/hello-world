import { Avatar, AvatarGroup, Divider } from '@amxis/design-system';
import { Box, Typography } from '@mui/material';
import { AvatarSingleContents } from '@amxis/design-system/icon';

export const SampleAvatar = () => {
  return (
    <>
      <Typography variant="h1">Single Avatar</Typography>
      <Box sx={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
        <Avatar
          size="xxlarge"
          contentType="image"
          src={AvatarSingleContents}
          isStatus
          statusBadge="online"
        />
        <Avatar
          size="xxlarge"
          contentType="image"
          src={AvatarSingleContents}
          isStatus
          countBadge={10}
          statusBadge="dot"
        />
        <Avatar size="xlarge" contentType="initial" />
        <Avatar size="xlarge" contentType="initial" countBadge={1} border />
        <Avatar size="large" contentType="initial-inversed" isStatus />
        <Avatar
          size="medium"
          contentType="icon"
          isStatus
          statusBadge="time"
          countBadge={9999}
          border
        />
        <Avatar size="medium" contentType="icon" />
        <Avatar
          size="small"
          contentType="image"
          src={AvatarSingleContents}
          isStatus
          countBadge={100}
          statusBadge="online"
        />
        <Avatar size="xsmall" contentType="initial" isStatus countBadge={10} statusBadge="ban" />
        <Avatar size="xxsmall" contentType="icon" isStatus countBadge={1} statusBadge="dot" />
      </Box>
      <Divider placement="content" sx={{ my: '12px' }} />
      <Typography variant="h1">Avatar Group</Typography>
      <AvatarGroup max={20} size="xxlarge">
        <Avatar border contentType="icon" />
        <Avatar border src={AvatarSingleContents} />
        <Avatar border contentType="image" src={AvatarSingleContents} alt="avatar 3" />
        <Avatar border alt="avatar 4" />
        <Avatar border alt="avatar 5" />
        <Avatar border alt="avatar 6" />
        <Avatar border alt="avatar 7" />
        <Avatar border alt="avatar 8" />
        <Avatar border alt="avatar 9" />
        <Avatar border alt="avatar 10" />
        <Avatar border alt="avatar 11" />
        <Avatar border alt="avatar 12" />
        <Avatar border alt="avatar 13" />
        <Avatar border alt="avatar 14" />
        <Avatar border alt="avatar 15" />
        <Avatar border alt="avatar 16" />
        <Avatar border alt="avatar 17" />
        <Avatar border alt="avatar 18" />
        <Avatar border alt="avatar 19" />
        <Avatar border alt="avatar 20" />
      </AvatarGroup>
    </>
  );
};
