import { AnimatedLikeIcon, Button, EngagementAction } from '@amxis/design-system';
import Box from '@mui/material/Box';
import { useState } from 'react';

export const SampleEngagementAction = () => {
  const [selected1, setSelected1] = useState<boolean>(false);
  const [value1, setValue1] = useState<number>(123123);

  const [selected2, setSelected2] = useState<boolean>(false);
  const [value2, setValue2] = useState<number>(123123);

  const [selected3, setSelected3] = useState<boolean>(false);
  const [value3, setValue3] = useState<number>(123123);

  const [likeOn, setLikeOn] = useState<boolean>(false);

  return (
    <Box my="24px">
      <Box display="flex" alignItems="center">
        <Button
          onClick={() => {
            setLikeOn((on) => !on);
          }}
          sx={{
            margin: '5px',
            svg: {
              width: '20px',
              height: '20px',
            },
          }}
        >
          toggle
        </Button>
        <Box>
          <AnimatedLikeIcon on={likeOn} />
        </Box>
      </Box>

      <EngagementAction
        type={'like'}
        value={value1}
        selected={selected1}
        onActionClick={(_, newSelected, newValue) => {
          setSelected1(newSelected);
          setValue1(newValue);
        }}
        sx={{
          margin: '5px',
        }}
      />
      <EngagementAction
        type={'agree'}
        value={value2}
        selected={selected2}
        onActionClick={(_, newSelected, newValue) => {
          setSelected2(newSelected);
          setValue2(newValue);
        }}
      />
      <EngagementAction
        type={'disAgree'}
        value={value3}
        selected={selected3}
        onActionClick={(_, newSelected, newValue) => {
          setSelected3(newSelected);
          setValue3(newValue);
        }}
      />
      <EngagementAction
        type={'replies'}
        value={value3}
        onActionClick={() => alert('replies clicked')}
      />
      <EngagementAction
        type={'addReply'}
        buttonLabel="댓글쓰기"
        onActionClick={() => alert('addReply clicked')}
      />
      <EngagementAction
        type={'viewed'}
        value={value3}
        onActionClick={() => alert('viewed clicked')}
      />
    </Box>
  );
};
