import { Label } from '@amxis/design-system';
import { Box } from '@mui/material';

export const SampleLabel = () => {
  return (
    <Box my="24px">
      <Box width={140}>
        <Label isRequired labelText="Label" textAlign={'right'} />
      </Box>
      <Label labelText="Label" tooltipIcon tooltipTitle="Label Info" />
      <Label isRequired labelText="Label" tooltipIcon tooltipTitle="Label Info" depth="sub" />
      <Label labelText="Label" tooltipIcon tooltipTitle="Label Info" depth="sub" />
      <Box width={140}>
        <Label labelText="Label의 텍스트가 길어질 때 줄바꿈이 됩니다." isRequired />
      </Box>
    </Box>
  );
};
