import {
  Button,
  Chip,
  ChipAvatar,
  Counter,
  Tree,
  TreeData,
  findTreeParentIds,
} from '@amxis/design-system';
import Box from '@mui/material/Box';
import { useState } from 'react';

export const SampleCounter = () => {
  const [value, setValue] = useState<string | number>(1.0);
  const [value2, setValue2] = useState<string | number>('1.0');

  return (
    <Box my="24px">
      <Box mb="10px">{JSON.stringify(value, null, 2)}</Box>
      <Counter value={value} onChange={(value) => setValue(value)} />
      <Box m="10px 0 10px 0">{JSON.stringify(value2, null, 2)}</Box>
      <Counter value={value2} onChange={(value) => setValue2(value)} stepValue={0.5} />
      {/* chip ---> */}
      <Box mt="10px">
        <Chip
          chipText={'large'}
          size="large"
          type="action"
          onClick={function Ga() {}}
          onDelete={function Ga() {}}
          leadingContents={
            <ChipAvatar
              border
              contentType="icon-inversed"
              countBadge={0}
              src="http://devwdg.lgensol.com/assets/avatarSingleContents-CEw_TwZ9.svg"
              statusBadge="online"
              // textAvatar="ami client"
              size={'large'}
            />
          }
        />
        <Chip
          chipText={'medium'}
          size="medium"
          type="action"
          onClick={function Ga() {}}
          onDelete={function Ga() {}}
          leadingContents={
            <ChipAvatar
              border
              contentType="icon-inversed"
              countBadge={0}
              src="http://devwdg.lgensol.com/assets/avatarSingleContents-CEw_TwZ9.svg"
              statusBadge="online"
              // textAvatar="ami client"
              size={'medium'}
            />
          }
        />
        <Chip
          chipText={'small'}
          size="small"
          type="action"
          onClick={function Ga() {}}
          onDelete={function Ga() {}}
          leadingContents={
            <ChipAvatar
              border
              contentType="icon-inversed"
              countBadge={0}
              src="http://devwdg.lgensol.com/assets/avatarSingleContents-CEw_TwZ9.svg"
              statusBadge="online"
              // textAvatar="ami client"
              size={'small'}
            />
          }
        />
        <Chip
          chipText={'xsmall'}
          size="xsmall"
          type="action"
          onClick={function Ga() {}}
          onDelete={function Ga() {}}
          leadingContents={
            <ChipAvatar
              border
              contentType="icon-inversed"
              countBadge={0}
              src="http://devwdg.lgensol.com/assets/avatarSingleContents-CEw_TwZ9.svg"
              statusBadge="online"
              // textAvatar="ami client"
              size={'xsmall'}
            />
          }
        />
      </Box>

      {/* <--- chip> */}
    </Box>
  );
};
