import {
  Accordion,
  AccordionBody,
  AccordionHeader,
  AccordionProps,
  AccordionSubtitle,
} from '@amxis/design-system';
import { AccordionHeaderProps, Divider } from '@amxis/design-system';
import { Box, useTheme } from '@mui/material';
import React, { useState } from 'react';
import { ControlResetIcon } from '@amxis/design-system/icon';

type AccordionItemType = {
  id: string;
  contents: React.ReactNode;
  children?: AccordionItemType[];
  headerProps?: AccordionHeaderProps;
} & Pick<AccordionProps, 'status' | 'depth'>;

export const SampleAccordion = () => {
  const [accordionItems, setAccordionItems] = useState<AccordionItemType[]>([
    {
      id: '1',
      status: 'closed',
      contents: <Box>contents 1</Box>,
      headerProps: { arrowPosition: 'rear' },
    },
    {
      id: '2',
      status: 'closed',
      contents: <Box>contents 2</Box>,
      headerProps: {
        rightButtons: [
          {
            priority: 'normal',
            appearance: 'unfilled',
            buttonLabel: 'Button',
            onClick: (e) => {
              e.stopPropagation();
              console.log('Button clicked');
            },
          },
          {
            priority: 'normal',
            appearance: 'unfilled',
            iconComponent: <ControlResetIcon size="default" iconSize={16} />,
            onClick: (e) => {
              e.stopPropagation();
              console.log('Reset Button clicked');
            },
          },
        ],
      },
      children: [
        {
          id: '2-1',
          status: 'closed',
          contents: <Box>contents 2-1</Box>,
          depth: '2Depth',
        },
        { id: '2-2', status: 'closed', contents: <Box>contents 2-2</Box>, depth: '2Depth' },
      ],
    },
    {
      id: '3',
      status: 'closed',
      contents: <Box>contents 3</Box>,
      headerProps: { title: 'custom title' },
      children: [
        {
          id: '3-1',
          status: 'closed',
          contents: <Box>contents 3-1</Box>,
          depth: '2Depth',
          children: [
            { id: '3-1-1', status: 'closed', contents: <Box>contents 3-1-1</Box>, depth: '3Depth' },
            { id: '3-1-2', status: 'closed', contents: <Box>contents 3-1-2</Box>, depth: '3Depth' },
          ],
        },
      ],
    },
  ]);

  function toggleStatus(items: AccordionItemType[], id: string): AccordionItemType[] {
    return items.map((item) => {
      if (item.id === id) {
        return {
          ...item,
          status: item.status === 'opened' ? 'closed' : 'opened',
        };
      }
      if (item.children) {
        return {
          ...item,
          children: toggleStatus(item.children, id),
        };
      }
      return item;
    });
  }

  const handleExpandCollapse = (id: string) => {
    setAccordionItems((prevItems) => toggleStatus(prevItems, id));
  };

  function setAllItemStatus(
    items: AccordionItemType[],
    status: AccordionProps['status']
  ): AccordionItemType[] {
    return items.map((item) => {
      const newItem = { ...item, status: status };
      if (item.children) {
        newItem.children = setAllItemStatus(item.children, status);
      }
      return newItem;
    });
  }

  const handleExpandAll = () => {
    setAccordionItems((prevItems) => setAllItemStatus(prevItems, 'opened'));
  };

  const handleCollapseAll = () => {
    setAccordionItems((prevItems) => setAllItemStatus(prevItems, 'closed'));
  };

  return (
    <Box width={'1000px'}>
      <AccordionSubtitle
        subtitle="서브타이틀"
        onCollapseAllBtnClick={handleCollapseAll}
        onExpandAllBtnClick={handleExpandAll}
      />
      {accordionItems.map((item) => (
        <AccordionItem key={item.id} item={item} onClick={handleExpandCollapse} />
      ))}
    </Box>
  );
};

const AccordionItem = (props: { item: AccordionItemType; onClick: (id: string) => void }) => {
  const { item, onClick } = props;
  const theme = useTheme();
  const { commonBgDeep } = theme.palette.semantic.color;

  return (
    <Accordion
      status={item.status}
      depth={item.depth ?? '1Depth'}
      onChange={() => onClick(item.id)}
    >
      <AccordionHeader
        aria-controls={`${item.id}-content`}
        id={`${item.id}-header`}
        title={`Accordion Item  ${item.id}`}
        {...item.headerProps}
      />
      <AccordionBody sx={{ backgroundColor: commonBgDeep }}>
        {item.contents}
        {item.children && <Divider sx={{ my: '6px', opacity: '0' }} />}
        {item.children?.map((child) => (
          <AccordionItem key={child.id} item={child} onClick={onClick} />
        ))}
      </AccordionBody>
    </Accordion>
  );
};
