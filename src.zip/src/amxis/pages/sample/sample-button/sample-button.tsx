import { Button, Divider, SegmentedButton, SegmentedOptionType } from '@amxis/design-system';
import { Box, Typography } from '@mui/material';
import CheckIcon from '@/amxis/assets/icons/check.svg?react';
import { useState } from 'react';
import { EmojiFaceIcon } from '@amxis/design-system/icon';

export const ButtonSample = () => {
  const [value1, setValue1] = useState<SegmentedOptionType>();
  const [value2, setValue2] = useState<SegmentedOptionType>();
  const [value3, setValue3] = useState<SegmentedOptionType>();

  const handleOnChange1 = (_: React.MouseEvent<HTMLElement>, option: SegmentedOptionType) => {
    setValue1(option);
  };
  const handleOnChange2 = (_: React.MouseEvent<HTMLElement>, option: SegmentedOptionType) => {
    setValue2(option);
  };
  const handleOnChange3 = (_: React.MouseEvent<HTMLElement>, option: SegmentedOptionType) => {
    setValue3(option);
  };

  return (
    <Box my="24px">
      <Typography variant="h4">large</Typography>
      <Box>
        <Box sx={{ height: 8 }}></Box>
        <Button appearance="unfilled" size="large">
          this is primary
        </Button>
        <Button appearance="contained" size="large" buttonLabel="">
          this is primary
        </Button>
        <Button appearance="outlined" size="large">
          this is primary
        </Button>
      </Box>
      <Box>
        <Box sx={{ height: 8 }}></Box>
        <Button appearance="unfilled" priority="normal" size="large">
          this is normal
        </Button>
        <Button appearance="contained" priority="normal" size="large">
          this is normal
        </Button>
        <Button appearance="outlined" priority="normal" size="large">
          this is normal
        </Button>
      </Box>
      <Box sx={{ height: 24 }}></Box>
      <Typography variant="h4">medium</Typography>
      <Box>
        <Box sx={{ height: 8 }}></Box>
        <Button appearance="unfilled" size="medium">
          this is primary
        </Button>
        <Button appearance="contained" size="medium">
          this is primary
        </Button>
        <Button appearance="outlined" size="medium">
          this is primary
        </Button>
      </Box>
      <Box>
        <Box sx={{ height: 8 }}></Box>
        <Button appearance="unfilled" priority="normal" size="medium">
          this is normal
        </Button>
        <Button appearance="contained" priority="normal" size="medium">
          this is normal
        </Button>
        <Button appearance="outlined" priority="normal" size="medium">
          this is normal
        </Button>
      </Box>
      <Box sx={{ height: 24 }}></Box>
      <Typography variant="h4">small</Typography>
      <Box>
        <Box sx={{ height: 8 }}></Box>
        <Button appearance="unfilled" size="small">
          this is primary
        </Button>
        <Button appearance="contained" size="small">
          this is primary
        </Button>
        <Button appearance="outlined" size="small">
          this is primary
        </Button>
      </Box>
      <Box>
        <Box sx={{ height: 24 }}></Box>
        <Button appearance="unfilled" priority="normal" size="small">
          this is normal
        </Button>
        <Button appearance="contained" priority="normal" size="small">
          this is normal
        </Button>
        <Button appearance="outlined" priority="normal" size="small">
          this is normal
        </Button>
      </Box>
      <Box sx={{ height: 24 }}></Box>
      <Typography variant="h4">icon</Typography>
      <Box>
        <Box sx={{ height: 8 }}></Box>
        <Button appearance="unfilled" iconComponent={<CheckIcon />}>
          this is primary
        </Button>
        <Button appearance="contained" iconComponent={<CheckIcon />} buttonLabel="">
          this is primary
        </Button>
        <Button appearance="outlined" iconComponent={<CheckIcon />}>
          this is primary
        </Button>
      </Box>
      <Box>
        <Box sx={{ height: 8 }}></Box>
        <Button appearance="unfilled" priority="normal" iconComponent={<CheckIcon />}>
          this is normal
        </Button>
        <Button appearance="contained" priority="normal" iconComponent={<CheckIcon />}>
          this is normal
        </Button>
        <Button appearance="outlined" priority="normal" iconComponent={<CheckIcon />}>
          this is normal
        </Button>
        <Button
          appearance="contained"
          priority="normal"
          iconComponent={<CheckIcon />}
          buttonLabel=""
        ></Button>
      </Box>
      <Box>
        <Box sx={{ height: 8 }}></Box>
        <Button appearance="unfilled" iconPosition="trailing" iconComponent={<CheckIcon />}>
          asdfasdf
        </Button>
        <Button appearance="contained" iconPosition="trailing" iconComponent={<CheckIcon />}>
          this is primary
        </Button>
        <Button appearance="outlined" iconPosition="trailing" iconComponent={<CheckIcon />}>
          this is primary
        </Button>
      </Box>
      <Box>
        <Box sx={{ height: 8 }}></Box>
        <Button
          appearance="unfilled"
          priority="normal"
          iconPosition="trailing"
          iconComponent={<CheckIcon />}
        >
          this is normal
        </Button>
        <Button
          appearance="contained"
          priority="normal"
          iconPosition="trailing"
          iconComponent={<CheckIcon />}
        >
          this is normal
        </Button>
        <Button
          appearance="outlined"
          priority="normal"
          iconPosition="trailing"
          iconComponent={<CheckIcon />}
        >
          this is normal
        </Button>
      </Box>
      <Divider sx={{ margin: '20px 0' }} />
      <Typography variant="h1">Segmented Button</Typography>
      <Typography variant="h4">Default(Label Only)</Typography>
      <Typography variant="bodySmall">{`[${value1 ?? ''}]`}</Typography>
      <Box marginBottom="3px">
        <SegmentedButton
          options={[
            { label: 'good', value: 'good' },
            { label: 'normal', value: 'normal' },
            { label: 'bad', value: 'bad' },
          ]}
          size="small"
          value={value1}
          onChange={handleOnChange1}
        />
      </Box>
      <Box marginBottom="3px">
        <SegmentedButton
          options={[
            { label: 'good', value: 'good' },
            { label: 'normal', value: 'normal' },
            { label: 'bad', value: 'bad' },
          ]}
          value={value1}
          onChange={handleOnChange1}
        />
      </Box>
      <Box marginBottom="3px">
        <SegmentedButton
          options={[
            { label: 'good', value: 'good' },
            { label: 'normal', value: 'normal' },
            { label: 'bad', value: 'bad' },
          ]}
          size="large"
          value={value1}
          onChange={handleOnChange1}
        />
      </Box>
      <Typography variant="h4">Label+Icon</Typography>
      <Typography variant="bodySmall">{`[${value2 ?? ''}]`}</Typography>
      <Box marginBottom="3px">
        <SegmentedButton
          options={[
            {
              label: 'good',
              icon: <EmojiFaceIcon appearance="lined" face="good" />,
              value: 'good',
            },
            {
              label: 'normal',
              icon: <EmojiFaceIcon appearance="lined" face="normal" />,
              value: 'normal',
            },
            {
              label: 'bad',
              icon: <EmojiFaceIcon appearance="lined" face="bad" />,
              value: 'bad',
            },
          ]}
          size="small"
          value={value2}
          onChange={handleOnChange2}
        />
      </Box>
      <Box marginBottom="3px">
        <SegmentedButton
          options={[
            {
              label: 'good',
              icon: <EmojiFaceIcon appearance="lined" face="good" />,
              value: 'good',
            },
            {
              label: 'normal',
              icon: <EmojiFaceIcon appearance="lined" face="normal" />,
              value: 'normal',
            },
            {
              label: 'bad',
              icon: <EmojiFaceIcon appearance="lined" face="bad" />,
              value: 'bad',
            },
          ]}
          value={value2}
          onChange={handleOnChange2}
        />
      </Box>
      <Box>
        <SegmentedButton
          options={[
            {
              label: 'good',
              icon: <EmojiFaceIcon appearance="lined" face="good" />,
              value: 'good',
            },
            {
              label: 'normal',
              icon: <EmojiFaceIcon appearance="lined" face="normal" />,
              value: 'normal',
            },
            {
              label: 'bad',
              icon: <EmojiFaceIcon appearance="lined" face="bad" />,
              value: 'bad',
            },
          ]}
          size="large"
          value={value2}
          onChange={handleOnChange2}
        />
      </Box>
      <Typography variant="h4">Icon Only</Typography>
      <Typography variant="bodySmall">{`[${value3 ?? ''}]`}</Typography>
      <Box marginBottom="3px">
        <SegmentedButton
          options={[
            {
              icon: <EmojiFaceIcon appearance="lined" face="good" />,
              value: 'good',
            },
            {
              icon: <EmojiFaceIcon appearance="lined" face="normal" />,
              value: 'normal',
            },
            {
              icon: <EmojiFaceIcon appearance="lined" face="bad" />,
              value: 'bad',
            },
          ]}
          size="small"
          value={value3}
          onChange={handleOnChange3}
        />
      </Box>
      <Box marginBottom="3px">
        <SegmentedButton
          options={[
            {
              icon: <EmojiFaceIcon appearance="lined" face="good" />,
              value: 'good',
            },
            {
              icon: <EmojiFaceIcon appearance="lined" face="normal" />,
              value: 'normal',
            },
            {
              icon: <EmojiFaceIcon appearance="lined" face="bad" />,
              value: 'bad',
            },
          ]}
          value={value3}
          onChange={handleOnChange3}
        />
      </Box>
      <Box marginBottom="3px">
        <SegmentedButton
          options={[
            {
              icon: <EmojiFaceIcon appearance="lined" face="good" />,
              value: 'good',
            },
            {
              icon: <EmojiFaceIcon appearance="lined" face="normal" />,
              value: 'normal',
            },
            {
              icon: <EmojiFaceIcon appearance="lined" face="bad" />,
              value: 'bad',
            },
          ]}
          size="large"
          value={value3}
          onChange={handleOnChange3}
        />
      </Box>
    </Box>
  );
};
