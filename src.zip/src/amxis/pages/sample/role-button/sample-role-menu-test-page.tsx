import { ContainerLayout } from '@/amxis/components/container-layout';
import { SamplePageTitle } from '@/amxis/pages/sample/__components/sample-page-title.tsx';
import { Box, Typography } from '@mui/material';
import { DocumentContentH2 } from '@/amxis/pages/sample/__components/document-content-h2.tsx';
import { Button, useTheme } from '@amxis/design-system';
import { ContainerBox } from '@/amxis/pages/sample/__components/container-box.tsx';

import { AuthButtonWrapper } from '@/amxis/components/role-button-wrapper';
import { Spacer } from '@/amxis/components/layout';
import useSessionStore from '@/amxis/stores/useSessionStore';
import { MenuAuth } from '@/amxis/models/common/MenuAuth';
import { DocumentContentH3 } from '../__components/document-content-h3';

const SampleAuthMenuTestPage = () => {
  const [theme] = useTheme();
  const { menus } = useSessionStore();
  const menu = menus?.find((menu) => menu.pgmId === 'EAS_AM000135');
  const pgmAuth = menu?.pgmAuth;
  return (
    <ContainerBox>
      <ContainerLayout>
        <SamplePageTitle>화면권한테스트샘플</SamplePageTitle>
        <Box mt="48px" />
        <DocumentContentH2 title="화면권한테스트샘플" />
        <DocumentContentH3 title="AuthButtonWrapper 설명" />
        <Typography
          variant="body2"
          sx={{ color: theme.palette.semantic.color.commonTextBasic, whiteSpace: 'pre-line' }}
        >
          {'<AuthButtonWrapper>로 디자인 시스템의 <Button> 컴포넌트를 감싸서 사용합니다.' +
            '\n props btnKeyCd 는 버튼로그의 key값 입니다.' +
            '\n props type에 "disabled"와 "display"를 사용할 수 있습니다.' +
            '\n props pgmAuth 는 사용자 혹은 권한 그룹이 해당 페이지에 대한 권한 등급입니다.' +
            '\n props requiredAuth 는 해당 버튼의 최소 필요 화면 권한(pgmAuth와 비교) 등급입니다.'}
        </Typography>
        <Spacer type="v" size="16" />
        <DocumentContentH3 title="AuthButtonWrapper 샘플" />
        <Typography
          variant="body2"
          sx={{ color: theme.palette.semantic.color.commonTextBasic, whiteSpace: 'pre-line' }}
        >
          {"해당 프로그램'화면권한테스트샘플'은 프로그램'화면권한관리샘플'에서 페이지 권한 등급 제어를 받습니다." +
            '\n아래 3개의 버튼의 requiredAuth가 상이하므로 변경된 화면 등급에 따라서 버튼의 제어가 이루어집니다.'}
        </Typography>
        <AuthButtonWrapper
          pgmAuth={pgmAuth}
          pgmName={menu?.pgmName}
          requiredAuth={MenuAuth.THREE}
          btnKeyCd="sampleTest1"
          type="disabled"
          logClick={true}
        >
          <Button size="large" appearance="contained" priority="normal" onClick={() => {}}>
            조회
          </Button>
        </AuthButtonWrapper>
        <Spacer type="v" size="16" />
        <AuthButtonWrapper
          pgmAuth={pgmAuth}
          pgmName={menu?.pgmName}
          requiredAuth={MenuAuth.TWO}
          btnKeyCd="sampleTest2"
          type="disabled"
          logClick={true}
        >
          <Button size="large" appearance="contained" priority="normal" onClick={() => {}}>
            Excel
          </Button>
        </AuthButtonWrapper>
        <Spacer type="v" size="16" />
        <AuthButtonWrapper
          pgmAuth={pgmAuth}
          pgmName={menu?.pgmName}
          requiredAuth={MenuAuth.ONE}
          btnKeyCd="sampleTest3"
          type="disabled"
          logClick={true}
        >
          <Button size="large" appearance="contained" priority="normal" onClick={() => {}}>
            출력
          </Button>
        </AuthButtonWrapper>
      </ContainerLayout>
    </ContainerBox>
  );
};

export default SampleAuthMenuTestPage;
