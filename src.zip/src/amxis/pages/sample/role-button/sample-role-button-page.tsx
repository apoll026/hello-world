import { CommonResponse } from '@/amxis/models/common/RestApi.ts';
import { ContainerLayout } from '@/amxis/components/container-layout';
import { SamplePageTitle } from '@/amxis/pages/sample/__components/sample-page-title.tsx';
import { Box, Typography } from '@mui/material';
import { DocumentContentH2 } from '@/amxis/pages/sample/__components/document-content-h2.tsx';
import { Button, useTheme } from '@amxis/design-system';
import { ContainerBox } from '@/amxis/pages/sample/__components/container-box.tsx';
import { useEffect } from 'react';
import {
  saveSampleTest1,
  saveSampleTest2,
  saveSampleTest3,
} from '@/amxis/apis/sample/RoleButtonSampleApi.ts';
import { AuthButtonWrapper } from '@/amxis/components/role-button-wrapper';
import useButtonAuth from '@/amxis/hooks/use-button-auth.ts';
import { Spacer } from '@/amxis/components/layout';

const SampleRoleButtonPage = () => {
  const [theme] = useTheme();
  const { isButtonAuth } = useButtonAuth();

  useEffect(() => {}, []);

  return (
    <ContainerBox>
      <ContainerLayout>
        <SamplePageTitle>버튼권한샘플</SamplePageTitle>
        <Box mt="48px" />
        <DocumentContentH2 title="버튼권한샘플" />
        <Typography
          variant="body2"
          sx={{ color: theme.palette.semantic.color.commonTextBasic, whiteSpace: 'pre-line' }}
        >
          {'프론트 처리 방법' +
            '\n <AuthButtonWrapper>로 디자인 시스템의 <Button> 컴포넌트를 감싸서 사용합니다.' +
            '\n props btnKeyCd 는 버튼별 역할관리 페이지에서 등록한 "btnGrCd" + "."+ "btnCd"를 사용합니다 .' +
            '\n props type에 "disabled"와 "display"를 사용할 수 있습니다.' +
            '\n 코드가 존재하지 않은 경우를 권한이 없다는 것으로 판단합니다'}
        </Typography>
        <Box mt="24px">
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'flex-start',
              gap: '4px',
            }}
          >
            <AuthButtonWrapper btnKeyCd={'샘플화면.reg001'} type={'display'}>
              <Button
                size="large"
                appearance="contained"
                priority="normal"
                onClick={async () => {
                  const response: CommonResponse | null = await saveSampleTest1();
                  console.log(response);
                  if (response) {
                    alert('success');
                  } else {
                    alert('fail');
                  }
                }}
              >
                샘플테스트버튼1
              </Button>
            </AuthButtonWrapper>
            {isButtonAuth('샘플화면.reg002') ? null : (
              <div style={{ fontSize: '12px', width: '130px', alignContent: 'center' }}>
                샘플테스트버튼2는 CMN 권한만 볼 수 있습니다.
              </div>
            )}
            <AuthButtonWrapper btnKeyCd={'샘플화면.reg002'} type={'display'}>
              <Button
                size="large"
                appearance="contained"
                priority="normal"
                onClick={async () => {
                  const response: CommonResponse | null = await saveSampleTest1();
                  if (response) {
                    alert('success');
                  } else {
                    alert('fail');
                  }
                }}
              >
                샘플테스트버튼2
              </Button>
            </AuthButtonWrapper>
            <AuthButtonWrapper btnKeyCd={'샘플화면.reg001_test'} type={'disabled'}>
              <Button
                size="large"
                appearance="contained"
                priority="normal"
                onClick={async () => {
                  const response: CommonResponse | null = await saveSampleTest2();
                  if (response) {
                    alert('success');
                  } else {
                    alert('fail');
                  }
                }}
              >
                샘플테스트버튼3
              </Button>
            </AuthButtonWrapper>
          </Box>
        </Box>
        <Box mt="48px" />
        <Typography
          variant="body2"
          sx={{ color: theme.palette.semantic.color.commonTextBasic, whiteSpace: 'pre-line' }}
        >
          {'백엔드에서도 처리하는 방법' +
            '\n 버튼 클릭시 API 호출하는 경우 서버에서도 동일하게 처리하여 보안을 강화합니다.' +
            '\n 백엔드에서 호출하는 메서드에 @RequiresRoles(value = "샘플화면.reg001", type = "BTN_KEY") 을 사용합니다.' +
            '\n type은 "ROLE"과 "BTN_KEY"를 사용할 수 있습니다. 기본값은 "ROLE" 입니다' +
            '\n value는 type에 따라 역할코드 or btnKeyCd가 사용됩니다. {"ADM", "CMN"} 으로 표현 가능합니다.'}
        </Typography>
        <AuthButtonWrapper btnKeyCd={'샘플화면.reg001'} type={'disabled'}>
          <Button
            size="large"
            appearance="contained"
            priority="normal"
            onClick={async () => {
              const response: CommonResponse | null = await saveSampleTest3();
              console.log(response);
              if (response) {
                alert('success');
              } else {
                alert('fail');
              }
            }}
          >
            샘플테스트버튼4
          </Button>
        </AuthButtonWrapper>
        <Spacer type="h" size="80" />
        <Box>
          <DocumentContentH2 title="버튼로그 테스트" />
          <Typography
            variant="body2"
            sx={{ color: theme.palette.semantic.color.commonTextBasic, whiteSpace: 'pre-line' }}
          >
            {'프론트 처리 방법' +
              '\n <AuthButtonWrapper>로 디자인 시스템의 <Button> 컴포넌트를 감싸서 사용합니다.' +
              '\n props logClick = {true}로 선언 시 버튼 로그에 남깁니다'}
          </Typography>
          <Spacer type="h" size="32" />
          <Typography
            variant="body2"
            sx={{ color: theme.palette.semantic.color.commonTextBasic, whiteSpace: 'pre-line' }}
          >
            {'버튼키 : 샘플화면.reg001'}
          </Typography>
          <Box sx={{ display: 'flex', justifyContent: 'flex-start', gap: '4px' }}>
            <AuthButtonWrapper btnKeyCd={'샘플화면.reg001'} type={'disabled'} logClick={true}>
              <Button size="large" appearance="contained" priority="normal">
                버튼로그O
              </Button>
            </AuthButtonWrapper>
            <Spacer type="v" size="24" />
            <AuthButtonWrapper btnKeyCd={'샘플화면.reg001'} type={'disabled'}>
              <Button size="large" appearance="contained" priority="normal">
                버튼로그X
              </Button>
            </AuthButtonWrapper>
          </Box>
          <Spacer type="h" size="32" />
          <Typography
            variant="body2"
            sx={{ color: theme.palette.semantic.color.commonTextBasic, whiteSpace: 'pre-line' }}
          >
            {'버튼키 : 샘플화면.reg002'}
          </Typography>
          <Box sx={{ display: 'flex', justifyContent: 'flex-start', gap: '4px' }}>
            <AuthButtonWrapper btnKeyCd={'샘플화면.reg002'} type={'display'} logClick={true}>
              <Button size="large" appearance="contained" priority="normal">
                버튼로그O
              </Button>
            </AuthButtonWrapper>
            <Spacer type="v" size="24" />
            <AuthButtonWrapper btnKeyCd={'샘플화면.reg002'} type={'display'}>
              <Button size="large" appearance="contained" priority="normal">
                버튼로그X
              </Button>
            </AuthButtonWrapper>
          </Box>
        </Box>
      </ContainerLayout>
    </ContainerBox>
  );
};

export default SampleRoleButtonPage;
