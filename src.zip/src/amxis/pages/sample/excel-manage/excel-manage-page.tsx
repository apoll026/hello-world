import { useRef, useState } from 'react';
import { readExcelFile } from '@/amxis/utils/excel-utils.ts';
import { Box } from '@mui/material';
import { ContainerLayout } from '@/amxis/components/container-layout';
import { Button } from '@amxis/design-system';
import OpenInNewRoundedIcon from '@mui/icons-material/OpenInNewRounded';
import { ContainerBox } from '../__components/container-box.tsx';
import { SamplePageTitle } from '../__components/sample-page-title.tsx';
import { DocumentContentH2 } from '../__components/document-content-h2.tsx';
import { useTheme } from '@amxis/design-system';
import { useTranslation } from 'react-i18next';
import { getExcelSample } from '@/amxis/apis/common/Excel.ts';

function SampleExcelManagePage() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [excelData, setExcelData] = useState<string[][]>([]);

  const [theme] = useTheme();
  const { t } = useTranslation();

  const handleExcelUpload = async (files: FileList | null) => {
    try {
      if (!files || !files?.[0]) {
        return;
      }
      const targetFile = files[0];

      const data = await readExcelFile(targetFile);

      setExcelData(data);
    } catch (e) {
      console.error(e);
    }
  };

  const handleExcelDownload = async () => {
    getExcelSample();
  };

  return (
    <ContainerBox>
      <ContainerLayout>
        <SamplePageTitle>
          {t('common.label.엑셀업로드/다운로드', '엑셀업로드/다운로드')}
        </SamplePageTitle>
        <Box mt="48px">
          <DocumentContentH2
            title={t('common.label.엑셀업로드(브라우저)', '엑셀업로드(브라우저)')}
          />
          <Box mt="24px">
            <Box>
              <Button
                size="large"
                appearance="contained"
                priority="normal"
                iconPosition="trailing"
                iconComponent={<OpenInNewRoundedIcon />}
                onClick={() => {
                  inputRef.current?.click();
                }}
              >
                {t('common.label.엑셀업로드(브라우저)', '엑셀업로드(브라우저)')}
              </Button>
              <input
                ref={inputRef}
                type="file"
                id="excel-upload-input"
                style={{ display: 'none' }}
                onChange={(e) => {
                  handleExcelUpload(e.target.files);
                }}
              />
            </Box>
            {excelData.length > 0 && (
              <Box
                mt="16px"
                p="24px"
                borderRadius="3px"
                border={`1px solid ${theme.palette.semantic.color.commonBorderStrong}`}
                bgcolor={theme.palette.semantic.color.commonBgBasic}
              >
                <Box
                  component="p"
                  sx={{
                    position: 'relative',
                    fontSize: '18px',
                    fontWeight: 700,
                    color: theme.palette.semantic.color.commonTextPrimaryExtreme,
                    '&:before': {
                      content: '""',
                      display: 'inline-block',
                      verticalAlign: 'middle',
                      mr: '8px',
                      width: '8px',
                      height: '8px',
                      borderRadius: '50%',
                      bgcolor: theme.palette.semantic.color.commonTextPrimary,
                    },
                  }}
                >
                  Result
                </Box>
                <Box mt="10px">
                  <table>
                    <thead>
                      <tr>
                        {excelData[0].map((cell, index) => (
                          <th key={index}>{cell}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {excelData.slice(1).map((row, rowIndex) => (
                        <tr key={rowIndex}>
                          {row.map((cell, cellIndex) => (
                            <td key={cellIndex}>{cell}</td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </Box>
              </Box>
            )}
          </Box>
        </Box>
        <Box mt="48px">
          <DocumentContentH2 title={t('common.label.엑셀 다운로드', '엑셀 다운로드')} />
          <Box mt="24px">
            <Box>
              <Button
                size="large"
                appearance="contained"
                priority="normal"
                iconPosition="trailing"
                iconComponent={<OpenInNewRoundedIcon />}
                onClick={handleExcelDownload}
              >
                {t('common.label.엑셀 다운로드', '엑셀 다운로드')}
              </Button>
            </Box>
          </Box>
        </Box>
      </ContainerLayout>
    </ContainerBox>
  );
}

export { SampleExcelManagePage };
