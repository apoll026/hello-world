import { HelperText } from '@amxis/design-system';
import { Box } from '@mui/material';

export const SampleHelperText = () => {
  return (
    <Box my="24px">
      <HelperText infoText={'default helper text'} usecase="default" leadingIcon />
      <HelperText infoText={'error helper text'} usecase="error" leadingIcon />
      <HelperText infoText={'warning helper text'} usecase="warning" leadingIcon />
      <HelperText infoText={'confirm helper text'} usecase="confirmed" leadingIcon />
      <HelperText infoText={'primary helper text'} usecase="primary" leadingIcon />
      <HelperText infoText={'Title default helper text'} usecase="default" leadingIcon isTitle />
      <HelperText infoText={'Title error helper text'} usecase="error" leadingIcon isTitle />
      <HelperText infoText={'Title warning helper text'} usecase="warning" leadingIcon isTitle />
      <HelperText infoText={'Title confirm helper text'} usecase="confirmed" leadingIcon isTitle />
      <HelperText infoText={'Title primary helper text'} usecase="primary" leadingIcon isTitle />
    </Box>
  );
};
