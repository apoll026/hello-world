import {
  BoardLayoutType,
  BoardList,
  BoardListItem,
  BoardListItemDetails,
  BoardViewType,
  EngagementAction,
  SortControlOption,
  DataGridNoRows,
  Button,
  DropdownField,
  DropdownOption,
} from '@amxis/design-system';
import { Box, useTheme } from '@mui/material';
import { AgGridReact } from 'ag-grid-react';
import dayjs, { Dayjs } from 'dayjs';
import { useEffect, useRef, useState } from 'react';
import { SampleColumn } from './data/sample-column.tsx';
import { BulletinItem, generateSampleData } from './data/sample-data.ts';
import { EditEdit2Icon } from '@amxis/design-system/icon';

export function paginate(items: BulletinItem[], pageNumber: number, itemsPerPage: number) {
  const startIndex = (pageNumber - 1) * itemsPerPage;
  return items.slice(startIndex, startIndex + itemsPerPage);
}

const data = generateSampleData();

export const SampleBoardList = () => {
  const gridRef = useRef<AgGridReact<BulletinItem>>(null);
  const theme = useTheme();
  const [rowData, setRowData] = useState<BulletinItem[]>(data);
  const [pageSize, setPageSize] = useState<number>(10);
  const [sortingState, setSortingState] = useState<number | string>('최신순');
  const [viewType, setViewType] = useState<BoardViewType>('basic');
  const [layoutType, setLayoutType] = useState<BoardLayoutType>('basic');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [currrentRowData, setCurrentRowData] = useState<BulletinItem[]>([]);
  const [isUnread, setIsUnread] = useState<boolean>(false);

  const handleSearch = (field: string, keyword: string, _optionalField?: string) => {
    // alert(_optionalField);

    const newData = rowData.filter((data: BulletinItem) => {
      if (field === 'name') {
        return data.writer?.name?.includes(keyword);
      } else {
        return (data[field] as string).includes(keyword);
      }
    });
    setCurrentRowData(newData);
  };

  useEffect(() => {
    const sortedData = rowData.sort((a, b) => {
      const dateA = dayjs(a.createdDate);
      const dateB = dayjs(b.createdDate);
      if (dateA.isBefore(dateB)) {
        return sortingState === '오래된순' ? -1 : 1;
      }
      if (dateA.isAfter(dateB)) {
        return sortingState === '오래된순' ? 1 : -1;
      }
      return 0;
    });
    setRowData(sortedData);
    setCurrentRowData(paginate(sortedData, currentPage, Number(pageSize)));
  }, [sortingState]);

  useEffect(() => {
    setCurrentRowData(paginate(rowData, currentPage, Number(pageSize)));
  }, [pageSize, currentPage]);

  useEffect(() => {
    if (isUnread) {
      const filteredData = data.filter((item) => item.isUnread);
      setRowData(filteredData);
      setCurrentRowData(paginate(filteredData, currentPage, Number(pageSize)));
    } else {
      setRowData(data);
      setCurrentRowData(paginate(data, currentPage, Number(pageSize)));
    }
  }, [isUnread]);

  const handleItemClick = (item: BulletinItem) => {
    console.log(item);
  };
  return (
    <Box
      width="1100px"
      ml="100px"
      padding="24px"
      sx={{ backgroundColor: theme.palette.semantic.color.commonBgDeep }}
    >
      <Box width="940px" bgcolor={theme.palette.semantic.color.commonBgElevation}>
        <BoardList
          footerButton={[
            <Button
              appearance="outlined"
              buttonLabel="신규"
              iconComponent={<EditEdit2Icon appearance="lined" />}
              iconPosition="leading"
              onClick={function Ga() {}}
              priority="normal"
              size="large"
            />,
          ]}
          emptyContent={'데이터가 없는 경우 메시지'}
          basicViewProps={{
            gridRef,
            rowData: currrentRowData,
            columnDefs: SampleColumn,
            pageSize,
            onChangePageSize: setPageSize,
            noRowsOverlayComponent: DataGridNoRows,
            rowSelection: 'multiple',
            onRowClicked: (event: { data: BulletinItem }) => {
              handleItemClick(event.data);
            },
          }}
          viewType={viewType}
          layoutType={layoutType}
          isHeaderSectionEnabled={true}
          headerProps={{
            totalCount: rowData.length,
            language: 'en',
            // hasTotalCountArea: false,
            hasViewSwitch: true,
            hasLayoutSwitch: true,
            hasCategoryArea: true,
            categoryAreaProps: {
              options: [
                {
                  value: 'title',
                  label: '제목',
                },
                {
                  value: 'name',
                  label: '작성자 ',
                },
              ],
              optionValue: { label: '제목', value: 'title' },
              placeholder: '',
              isInput: false,
              onCategoryChange: (_option?: DropdownOption) => {
                // console.log(option);
              },
            },
            viewSwitchProps: {
              view: viewType,
              onChangeView: setViewType,
            },
            layoutSwitchProps: {
              layout: layoutType,
              onChangeLayout: setLayoutType,
            },
            hasPageSizeArea: true,
            pageSizeControlProps: {
              isPageSizeInput: false,
              currentSize: pageSize,
              onChangeSize: setPageSize,
            },
            hasFilterArea: true,
            filterAreaProps: {
              useClearIcon: false,
              isInput: false,
              onSearch: handleSearch,
              // optionValue: { label: '제목', value: 'title' },
              // optionalOptionValue: { label: '이름', value: '1' },
              // inputValue: '1234',
              // optionalOptions: [
              //   {
              //     value: '1',
              //     label: '이름',
              //   },
              //   {
              //     value: '2',
              //     label: '내용',
              //   },
              // ],
              options: [
                {
                  value: 'title',
                  label: '제목',
                },
                {
                  value: 'name',
                  label: '작성자 ',
                },
              ],
            },
            hasSortingArea: true,
            sortAreaControlProps: {
              currentSort: { label: sortingState, value: sortingState },
              onChangeSorting: (value: SortControlOption) => setSortingState(value.value),
              sortOptions: [
                {
                  label: '최신순',
                  value: '최신순',
                },
                {
                  label: '오래된순',
                  value: '오래된순',
                },
              ],
            },
            hasFilterSwitch: true,
            filterSwitchProps: {
              label: 'Unread',
              checked: isUnread,
              onChange: (checked) => {
                setIsUnread(checked);
              },
            },
          }}
          paginationProps={{
            currentPage,
            onPageChange: setCurrentPage,
            totalCount: rowData.length / Number(pageSize),
          }}
        >
          {viewType !== 'basic' &&
            currrentRowData.map((item, index) => (
              <BoardListItem
                title={item.title}
                // imageUrl='http://10.94.57.6:8081/static/rapture/resources/icons/x32/sonatype-repository-icon-reverse.svg'
                // imageHeight={30}
                // imageWidth={30}
                content={item.content}
                isImportant={index === 0}
                isUnread={item.isUnread}
                isNewPost={index == 2}
                comments={item.comments}
                key={index}
                variant={viewType}
                onClick={() => handleItemClick(item)}
              >
                <BoardListItemDetails
                  avatarUrl={item.writer?.avatarUrl}
                  title={item.writer?.name}
                  avatarContentType='initial'
                  description={item.writer?.role}
                  hasAttachment={item.hasAttachedFile}
                  tags={item.tags}
                  createdDate={item.createdDate as Dayjs}
                  variant={viewType}
                  rightArea={
                    <Box display="flex" alignItems="center" gap="12px" pr="12px">
                      <EngagementAction
                        onActionClick={() => {}}
                        type="viewed"
                        value={item.views as number}
                      />
                      <EngagementAction
                        selected
                        onActionClick={() => {}}
                        type="agree"
                        value={item.recommended as number}
                      />
                      <EngagementAction
                        selected
                        onActionClick={() => {}}
                        type="disAgree"
                        value={item.notRecommended as number}
                      />
                    </Box>
                  }
                />
              </BoardListItem>
            ))}
        </BoardList>
      </Box>
    </Box>
  );
};
