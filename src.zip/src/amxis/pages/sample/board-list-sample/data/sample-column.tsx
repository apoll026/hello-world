import Attach from '@/amxis/assets/icons/attach.svg';
import { ColDef, ICellRendererParams } from 'ag-grid-community';
import { BoardListItemTitle } from '@amxis/design-system';
import { SampleWriterCell } from './sample-writer-cell.tsx';

export const SampleColumn: ColDef[] = [
  {
    width: 16,
    sortable: false,
    resizable: false,
    cellClass: 'placeholder',
  },
  {
    flex: 1,
    sortable: false,
    resizable: false,
    cellStyle: { textAlign: 'center' },
    headerClass: 'checkbox',
    checkboxSelection: true,
    headerCheckboxSelection: true,
  },
  {
    headerName: 'No',
    resizable: false,
    sortable: false,
    unSortIcon: false,
    flex: 1,
    cellStyle: { textAlign: 'center' },
    cellRenderer: (params: ICellRendererParams) => {
      return (params.node.rowIndex ?? 0) + 1;
    },
  },
  {
    field: 'hasAttachedFile',
    headerName: '첨부',
    flex: 1, 
    minWidth: 50,
    sortable: false,
    cellStyle: { textAlign: 'center' },
    cellRenderer: (params: ICellRendererParams) => {
      return params.data.hasAttachedFile ? <img src={Attach} /> : null;
    },
  },
  {
    field: 'title',
    headerName: '제목',
    flex: 9,
    minWidth: 145,
    sortable: false,
    cellRenderer: (params: ICellRendererParams) => {
      return (
        <BoardListItemTitle
          title={params.data.title}
          comments={params.data.comments}
          isImportant={Math.random() > 0.5}
          isNewPost={Math.random() > 0.5}
          isUnread={params.data.isUnread}
          type="basic"
        />
      );
    },
  },
  {
    field: 'author', 
    headerName: '작성자',
    flex: 3,
    minWidth: 100,
    sortable: false,
    cellRenderer: (params: ICellRendererParams) => {
      return <SampleWriterCell {...params.data.writer}/>;
    },
  },
  {
    field: 'createdDate',
    headerName: '작성일',
    flex: 2.5,
    cellStyle: { textAlign: 'center' },
  },
  {
    field: 'views',
    headerName: '조회수',
    flex: 2,
    sortable: true,
    cellStyle: { textAlign: 'right' },
  },
  {
    field: 'recommended',
    headerName: '추천',
    flex: 2,
    cellStyle: { textAlign: 'right' },
  },
  {
    width: 16,
    sortable: false,
    resizable: false,
    cellClass: 'placeholder',
  },
];
