import { Avatar } from '@amxis/design-system';
import { Box, Typography } from '@mui/material';
import { Writer } from './sample-data.ts';

export const SampleWriterCell = (props: Writer) => {
  return (
    <Box display="flex" alignItems="center" gap="4px">
      <Box maxWidth={'20px'}>
        <Avatar size="xxsmall" src={props.avatarUrl}/> 
      </Box>
      <Typography variant="bodyBasic" color="semantic.color.commonTextBasic">
        {props.name}
      </Typography>
    </Box>
  );
};
