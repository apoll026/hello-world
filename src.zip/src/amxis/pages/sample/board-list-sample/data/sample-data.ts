import dayjs, { Dayjs } from 'dayjs';
import avatarSrc from '@/amxis/assets/icons/avatarSingleContents.svg';
//import { AvatarContentType } from '../../avatar/avatar-utils';

interface Base {
  [key: string]: string | number | Date | Dayjs | Writer | undefined | string[] | boolean;
}
export interface BulletinItem extends Base {
  bulletinId: string;
  title: string;
  content?: string;
  comments?: number;
  hasAttachedFile?: boolean;
  tags?: string[];
  createdDate: Date | Dayjs | string;
  views?: number;
  recommended?: number;
  notRecommended?: number;
  writer?: Writer;
  imageThumbnail?: string;
  isUnread?: boolean;
}
export type Writer = {
  name?: string;
  avatarUrl?: string;
  role?: string;
};

function getRandomDate() {
  const start = dayjs('2022-01-01'); // Define your start date
  const end = dayjs('2025-01-01'); // Use current date as end date
  const randomDate = start.add(Math.floor(Math.random() * end.diff(start, 'day')), 'day');
  return randomDate;
}

export const generateSampleData = (length = 100) => {
  const sampleData: BulletinItem[] = [];

  for (let i = 1; i <= length; i++) {
    const bulletin: BulletinItem = {
      bulletinId: `bulletin${i}`,
      title: `타이틀텍스트 영역입니다 ${i}.`,
      content:
        '목록의 본문 미리보기 텍스트입니다. 이 형식의 목록에선 미리보기 텍스트는 최대 2줄까지 Display 됩니다 / 목록의 본문 미리보기 텍스트입니다. 지금 이 형식의 목록에선 미리보기 텍스트는 최대 2줄까지 Display 됩니다 / 목록의 본문 미리보기 텍스트입니다. 이 형식의 목록에선 미리보기 텍스트는 최대 2줄까지 Display 됩니다 / 목록의 본문 미리보기 텍스트입니다. 이 형식의 목록에선 미리보기 텍스트는 최대 2줄까지 Display 됩니다 / 목록의 본문 미리보기 텍스트입니다. 이 형식의 목록에선 미리보기 텍스트는 최대 2줄까지 Display 됩니다 / 목록의 본문 미리보기 텍스트입니다. 이 형식의 목록에선 미리보기 텍스트는 최대 2줄까지 Display 됩니다 / 목록의 본문 미리보기 텍스트입니다. 이 형식의 목록에선 미리보기 텍스트는 최대 2줄까지 Display 됩니다 / ',
      comments: 15,
      hasAttachedFile: true,
      createdDate: getRandomDate().format('YYYY.MM.DD'),
      views: Math.floor(Math.random() * 900000 + 100000),
      recommended: Math.floor(Math.random() * 900 + 100),
      notRecommended: 10,
      writer: {
        name: `홍길동 책임 ${i + 1}`,
        avatarUrl: avatarSrc,
        role: '스마트팩토리 제조설비관리팀',
      },
      tags: ['R&D', '기술', '생산'],
      isUnread: i % 2 === 0,
    };
    sampleData.push(bulletin);
  }

  return sampleData;
};


export const generateSampleData1 = () => {
  const sampleData: BulletinItem[] = [];

  return sampleData;
};
