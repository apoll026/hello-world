export interface AutoCompleteSampleType {
  code: string;
  fvalue: string;
}

export const AutoCompleteSampleDatas: AutoCompleteSampleType[] = [
  { code: 'apple', value: '과일1-사과' },
  { code: 'banana', value: '과일2-바나나' },
  { code: 'orange', value: '과일3-오렌지' },
  { code: 'grape', value: '과일4-포도' },
  { code: 'peach', value: '과일5-복숭아' },
  { code: 'plum', value: '과일6-자두' },
  { code: 'kiwi', value: '과일7-키위' },
  { code: 'mango', value: '과일8-망고' },
  { code: 'pineapple', value: '과일9-파인애플' },
  { code: 'cherry', value: '과일10-체리' },
  { code: 'strawberry', value: '과일11-딸기' },
  { code: 'blueberry', value: '과일12-블루베리' },
  { code: 'watermelon', value: '과일13-수박' },
  { code: 'melon', value: '과일14-멜론' },
  { code: 'lemon', value: '과일15-레몬' },
  { code: 'lime', value: '과일16-라임' },
  { code: 'grapefruit', value: '과일17-자몽' },
  { code: 'pomegranate', value: '과일18-석류' },
  { code: 'coconut', value: '과일19-코코넛' },
  { code: 'avocado', value: '과일20-아보카도' },
  { code: 'tangerine', value: '과일21-귤' },
  { code: 'pear', value: '과일22-배' },
  { code: 'persimmon', value: '과일23-감' },
  { code: 'chestnut', value: '과일24-밤' },
  { code: 'jujube', value: '과일25-대추' },
  { code: 'fig', value: '과일26-무화과' },
  { code: 'dragonfruit', value: '과일27-용과' },
  { code: 'guava', value: '과일28-구아바' },
  { code: 'passionfruit', value: '과일29-패션프루트' },
  { code: 'cranberry', value: '과일30-크랜베리' },
  { code: 'raspberry', value: '과일31-라즈베리' },
  { code: 'blackberry', value: '과일32-블랙베리' },
  { code: 'starfruit', value: '과일33-카람볼라' },
  { code: 'mangosteen', value: '과일34-망고스틴' },
  { code: 'durian', value: '과일35-두리안' },
  { code: 'jackfruit', value: '과일36-잭프루트' },
  { code: 'papaya', value: '과일37-파파야' },
  { code: 'kiwiberry', value: '과일38-키위베리' },
  { code: 'gooseberry', value: '과일39-구즈베리' },
  { code: 'mulberry', value: '과일40-오디' },
  { code: 'apricot', value: '과일41-살구' },
  { code: 'quince', value: '과일42-모과' },
  { code: 'olive', value: '과일43-올리브' },
  { code: 'date', value: '과일44-대추야자' },
  { code: 'currant', value: '과일45-커런트' },
  { code: 'elderberry', value: '과일46-엘더베리' },
  { code: 'boysenberry', value: '과일47-보이즌베리' },
  { code: 'longan', value: '과일48-용안' },
  { code: 'lychee', value: '과일49-리치' },
  { code: 'sapodilla', value: '과일50-사포딜라' },
];

export function getAutoCompleteSampleDatas(
  keyword: string
): Promise<{ dataList: AutoCompleteSampleType[] }> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const filtered = AutoCompleteSampleDatas.filter((fruit) => fruit.fvalue.includes(keyword));
      resolve({ dataList: filtered });
    }, 100);
  });
}
