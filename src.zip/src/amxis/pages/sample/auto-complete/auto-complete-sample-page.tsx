import { useState } from 'react';
import { ContainerLayout } from '@/amxis/components/container-layout';
import { SamplePageTitle } from '@/amxis/pages/sample/__components/sample-page-title.tsx';
import { Box, Typography } from '@mui/material';
import { DocumentContentH2 } from '@/amxis/pages/sample/__components/document-content-h2.tsx';
import { useTheme } from '@amxis/design-system';
import { ContainerBox } from '@/amxis/pages/sample/__components/container-box.tsx';
import { Spacer } from '@/amxis/components/layout';
import AutoCompleteInput from './auto-complete.tsx';
import { AutoCompleteSampleType, AutoCompleteSampleDatas } from './auto-complete-mock.ts';

const AutoCompleteSamplePage = () => {
  const [theme] = useTheme();
  const [basicData, setBasicData] = useState<AutoCompleteSampleType[]>([]);
  const [singleSelectData, setSingleSelectData] = useState<AutoCompleteSampleType[]>([]);
  const [readOnlyData, setReadOnlyData] = useState<AutoCompleteSampleType[]>([
    { code: 'readonly1', fvalue: '읽기전용 예시 데이터' },
  ]);
  const [disabledData, setDisabledData] = useState<AutoCompleteSampleType[]>([
    { code: 'disabled1', fvalue: '비활성화 예시 데이터' },
  ]);

  return (
    <ContainerBox>
      <ContainerLayout>
        <SamplePageTitle>자동완성 입력 컴포넌트 샘플</SamplePageTitle>
        <Box mt="48px" />

        <DocumentContentH2 title="Mock Data 정보" />
        <Typography
          variant="body2"
          sx={{ color: theme.palette.semantic.color.commonTextBasic, whiteSpace: 'pre-line' }}
        >
          {'현재 사용 중인 Mock Data (auto-complete-mock.ts):' +
            '\n • 총 14개의 과일 데이터 사용' +
            '\n • 인터페이스: { code: string, value: string }' +
            '\n • 검색 함수: getAutoCompleteSampleDatas(keyword: string)' +
            '\n • 검색어 포함된 항목만 필터링하여 반환'}
        </Typography>
        <Box
          mt="16px"
          sx={{
            backgroundColor: theme.palette.semantic.color.commonBackgroundLighter,
            padding: '16px',
            borderRadius: '8px',
            fontFamily: 'monospace',
            fontSize: '12px',
            overflow: 'auto',
          }}
        >
          <Typography variant="body2" sx={{ whiteSpace: 'pre-wrap' }}>
            {`// Mock Data 예시
${JSON.stringify(AutoCompleteSampleDatas.slice(0, 5), null, 2)}
... 총 ${AutoCompleteSampleDatas.length}개`}
          </Typography>
        </Box>

        <Spacer type="h" size="48" />

        <DocumentContentH2 title="실제 사용 코드 예시" />
        <Typography
          variant="body2"
          sx={{ color: theme.palette.semantic.color.commonTextBasic, whiteSpace: 'pre-line' }}
        >
          {'실제 프로젝트에서 사용할 때의 코드 예시입니다:'}
        </Typography>
        <Box
          mt="16px"
          sx={{
            backgroundColor: theme.palette.semantic.color.commonBackgroundLighter,
            padding: '16px',
            borderRadius: '8px',
            fontFamily: 'monospace',
            fontSize: '12px',
            overflow: 'auto',
          }}
        >
          <Typography variant="body2" sx={{ whiteSpace: 'pre-wrap' }}>
            {`// 1. 상태 정의
const [selectedData, setSelectedData] = useState<AutoCompleteSampleType[]>([]);

// 2. 기본 사용
<AutoCompleteInput
  size="medium"
  width="400px"
  onChange={(dataList) => {
    setSelectedData(dataList);
    console.log('선택된 데이터:', dataList);
  }}
  height="40px"
  placeholder="검색어를 입력하세요"
/>

// 3. 단일 선택 모드
<AutoCompleteInput
  singleSelect={true}
  onChange={(dataList) => {
    // dataList는 최대 1개 항목만 포함
    const selectedItem = dataList[0];
    console.log('선택된 항목:', selectedItem?.value);
  }}
/>

// 4. 초기값 설정
const initialData = [{ code: 'apple', value: '사과' }];
<AutoCompleteInput
  onInit={initialData}
  onChange={(dataList) => setSelectedData(dataList)}
/>

// 5. 상태별 사용
<AutoCompleteInput
  status="error"
  helperText="필수 입력 항목입니다"
  readonly={false}
  disabled={false}
  onChange={(dataList) => setSelectedData(dataList)}
/>`}
          </Typography>
        </Box>

        <Spacer type="h" size="48" />

        <DocumentContentH2 title="기본 자동완성 입력" />
        <Typography
          variant="body2"
          sx={{ color: theme.palette.semantic.color.commonTextBasic, whiteSpace: 'pre-line' }}
        >
          {'기본 자동완성 입력 컴포넌트 사용법' +
            '\n • 텍스트 입력 시 0.7초 후 자동으로 검색됩니다' +
            '\n • 검색 아이콘을 클릭하여 팝업으로 검색할 수 있습니다' +
            '\n • Enter키로 첫 번째 옵션을 선택할 수 있습니다' +
            '\n • 다중 선택이 가능하며 Chip 형태로 표시됩니다' +
            '\n • 현재 "사과", "바나나", "포도" 등의 과일명으로 테스트 가능'}
        </Typography>
        <Box mt="24px">
          <AutoCompleteInput
            size="medium"
            width="400px"
            onChange={(dataList) => {
              // setBasicData(dataList);
              console.log('Basic AutoComplete Data:', dataList);
            }}
            height="40px"
            placeholder="과일명을 입력해보세요 (예: 사과, 바나나)"
            helperText="기본 자동완성 입력 예시"
          />
        </Box>

        <Spacer type="h" size="48" />

        <DocumentContentH2 title="단일 선택 모드" />
        <Typography
          variant="body2"
          sx={{ color: theme.palette.semantic.color.commonTextBasic, whiteSpace: 'pre-line' }}
        >
          {'단일 선택만 가능한 자동완성 입력' +
            '\n • singleSelect={true} 옵션 사용' +
            '\n • 하나의 항목만 선택 가능합니다' +
            '\n • 새로운 항목 선택 시 기존 선택이 대체됩니다'}
        </Typography>
        <Box mt="24px">
          <AutoCompleteInput
            size="medium"
            width="400px"
            singleSelect={true}
            onChange={(dataList) => {
              setSingleSelectData(dataList);
              console.log('Single Select Data:', dataList);
            }}
            height="40px"
            placeholder="하나의 과일만 선택 가능 (예: 포도)"
            helperText="단일 선택 모드 예시"
          />
        </Box>

        <Spacer type="h" size="48" />

        <DocumentContentH2 title="다양한 크기 옵션" />
        <Typography
          variant="body2"
          sx={{ color: theme.palette.semantic.color.commonTextBasic, whiteSpace: 'pre-line' }}
        >
          {'크기 옵션: small, medium, large' +
            '\n • size 속성으로 컴포넌트 크기를 조절할 수 있습니다'}
        </Typography>
        <Box mt="24px" sx={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <Typography sx={{ width: '100px', fontSize: '14px' }}>Small:</Typography>
            <AutoCompleteInput
              size="small"
              width="300px"
              onChange={() => {}}
              height="32px"
              placeholder="Small 크기 (예: 수박)"
            />
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <Typography sx={{ width: '100px', fontSize: '14px' }}>Medium:</Typography>
            <AutoCompleteInput
              size="medium"
              width="300px"
              onChange={() => {}}
              height="40px"
              placeholder="Medium 크기 (예: 멜론)"
            />
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <Typography sx={{ width: '100px', fontSize: '14px' }}>Large:</Typography>
            <AutoCompleteInput
              size="large"
              width="300px"
              onChange={() => {}}
              height="48px"
              placeholder="Large 크기 (예: 복숭아)"
            />
          </Box>
        </Box>

        <Spacer type="h" size="48" />

        <DocumentContentH2 title="상태별 표시" />
        <Typography
          variant="body2"
          sx={{ color: theme.palette.semantic.color.commonTextBasic, whiteSpace: 'pre-line' }}
        >
          {'readonly, disabled 상태 표시' +
            '\n • readonly: 읽기 전용 상태' +
            '\n • disabled: 비활성화 상태'}
        </Typography>
        <Box mt="24px" sx={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <Typography sx={{ width: '100px', fontSize: '14px' }}>ReadOnly:</Typography>
            <AutoCompleteInput
              size="medium"
              width="300px"
              readonly={true}
              onInit={readOnlyData}
              onChange={() => {}}
              height="40px"
              placeholder="읽기 전용"
            />
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <Typography sx={{ width: '100px', fontSize: '14px' }}>Disabled:</Typography>
            <AutoCompleteInput
              size="medium"
              width="300px"
              disabled={true}
              onInit={disabledData}
              onChange={() => {}}
              height="40px"
              placeholder="비활성화"
            />
          </Box>
        </Box>

        <Spacer type="h" size="48" />

        <DocumentContentH2 title="상태별 스타일" />
        <Typography
          variant="body2"
          sx={{ color: theme.palette.semantic.color.commonTextBasic, whiteSpace: 'pre-line' }}
        >
          {'status 속성으로 다양한 상태를 표현할 수 있습니다' +
            '\n • default, error, warning, confirm'}
        </Typography>
        <Box mt="24px" sx={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <Typography sx={{ width: '100px', fontSize: '14px' }}>Default:</Typography>
            <AutoCompleteInput
              size="medium"
              width="300px"
              status="default"
              onChange={() => {}}
              height="40px"
              placeholder="기본 상태 (예: 체리)"
            />
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <Typography sx={{ width: '100px', fontSize: '14px' }}>Error:</Typography>
            <AutoCompleteInput
              size="medium"
              width="300px"
              status="error"
              onChange={() => {}}
              height="40px"
              placeholder="에러 상태 (예: 딸기)"
              helperText="에러 메시지 예시"
            />
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <Typography sx={{ width: '100px', fontSize: '14px' }}>Warning:</Typography>
            <AutoCompleteInput
              size="medium"
              width="300px"
              status="warning"
              onChange={() => {}}
              height="40px"
              placeholder="경고 상태 (예: 오렌지)"
              helperText="경고 메시지 예시"
            />
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <Typography sx={{ width: '100px', fontSize: '14px' }}>Confirm:</Typography>
            <AutoCompleteInput
              size="medium"
              width="300px"
              status="confirm"
              onChange={() => {}}
              height="40px"
              placeholder="확인 상태 (예: 망고)"
              helperText="확인 메시지 예시"
            />
          </Box>
        </Box>

        <Spacer type="h" size="48" />

        <DocumentContentH2 title="API 연동 방법" />
        <Typography
          variant="body2"
          sx={{ color: theme.palette.semantic.color.commonTextBasic, whiteSpace: 'pre-line' }}
        >
          {'실제 API와 연동할 때는 auto-complete.tsx의 다음 부분을 수정하세요:'}
        </Typography>
        <Box
          mt="16px"
          sx={{
            backgroundColor: theme.palette.semantic.color.commonBackgroundLighter,
            padding: '16px',
            borderRadius: '8px',
            fontFamily: 'monospace',
            fontSize: '12px',
            overflow: 'auto',
          }}
        >
          <Typography variant="body2" sx={{ whiteSpace: 'pre-wrap' }}>
            {`// auto-complete.tsx 파일의 useEffect 부분을 수정
useEffect(() => {
  if (textValue?.length > 1) {
    const timer = setTimeout(() => {
      setLoading(true);
      setOpen(true);
      
      // 현재 mock 함수 대신 실제 API 호출
      // getAutoCompleteSampleDatas(textValue).then((data) => {
      
      // 실제 API 호출 예시:
      yourApiFunction(textValue).then((response) => {
        // API 응답을 AutoCompleteSampleType[] 형태로 변환
        const formattedData = response.data.map(item => ({
          code: item.id,           // API의 ID 필드
          value: item.name         // API의 이름 필드
        }));
        setOptions(formattedData);
        setLoading(false);
      }).catch(() => {
        setOptions([]);
        setLoading(false);
      });
    }, 700);
    
    return () => clearTimeout(timer);
  }
}, [textValue]);`}
          </Typography>
        </Box>

        <Spacer type="h" size="80" />

        <DocumentContentH2 title="현재 선택된 데이터" />
        <Typography
          variant="body2"
          sx={{ color: theme.palette.semantic.color.commonTextBasic, whiteSpace: 'pre-line' }}
        >
          {'각 컴포넌트에서 선택된 데이터 확인 (개발자 도구 콘솔도 확인해보세요)'}
        </Typography>
        <Box
          mt="24px"
          sx={{
            display: 'flex',
            flexDirection: 'column',
            gap: '8px',
            backgroundColor: theme.palette.semantic.color.commonBackgroundLighter,
            padding: '16px',
            borderRadius: '8px',
          }}
        >
          <Typography variant="body2" sx={{ fontFamily: 'monospace' }}>
            <strong>기본 자동완성:</strong>{' '}
            {JSON.stringify(
              basicData.map((item) => item.value),
              null,
              2
            )}
          </Typography>
          <Typography variant="body2" sx={{ fontFamily: 'monospace' }}>
            <strong>단일 선택:</strong>{' '}
            {JSON.stringify(
              singleSelectData.map((item) => item.value),
              null,
              2
            )}
          </Typography>
          <Typography
            variant="body2"
            sx={{ fontSize: '12px', color: theme.palette.semantic.color.commonTextLight }}
          >
            * 콘솔에서 더 자세한 데이터 구조를 확인할 수 있습니다
          </Typography>
        </Box>

        <Spacer type="h" size="80" />
      </ContainerLayout>
    </ContainerBox>
  );
};

export default AutoCompleteSamplePage;
