import { InputChipBoxProps } from './auto-complete.tsx';
import styled from '@emotion/styled';

export const HelperText = styled.span<InputChipBoxProps>`
  font-family: Spoqa Han Sans Neo;
  font-size: 12px;
  font-weight: 400;
  line-height: 150%;
  color: #979998;

  margin-top: 4px;
  width: auto;
  height: auto;

  ${(props) =>
    props.status === 'error' &&
    `
    color: #f94b50;
    `}

  ${(props) =>
    props.status === 'warning' &&
    `
    color: #ff9322;
    `}
    
    ${(props) =>
    props.status === 'confirm' &&
    `
    color: #00806a;
  `}
`;

// 따로 추가한 CSS
export const StyledInputWrapper = styled.div<InputChipBoxProps>`
  display: flex;
  flex-direction: column;
  width: ${(props) => props.width || '100%'};
`;

export const Container = styled.div<InputChipBoxProps>`
  z-index: 10;
  position: relative;
  width: ${(props) => props.width};
  height: ${(props) => props.height};
  ${(props) => (props.disabled ? `opacity: 0.6; pointer-events: none;` : `opacity: 1;`)};
  ${(props) => (props.readonly ? `pointer-events: none;` : ``)};

  &::after {
    // position: absolute;
    top: 50%;
    right: 8px;
    transform: translate(0, -50%);
    width: 16px;
    height: 16px;
    background-color: #fff;
    cursor: pointer;
  }

  .MuiAutocomplete-root {
    .MuiTextField-root {
      .MuiOutlinedInput-root {
        ${(props) =>
          props.type === '1' ? 'padding: 6px 50px 6px 30px;' : 'padding: 6px 50px 6px 8px;'}
        display: flex;
        gap: 4px 2px;
        ${(props) => (props.readonly ? `background-color: #f1f4f3` : `background-color: #fff`)};
        .MuiAutocomplete-input {
          min-width: 0;
          // width: auto;
          height: 24px;
          margin-left: 2px;
          padding: 0;
          &::placeholder {
            color: #979998;
            opacity: 1;
          }
        }

        .MuiButtonBase-root.MuiChip-root > .MuiChip-deleteIcon {
          z-index: 100;
        }

        .MuiAutocomplete-input:focus {
          flex-shrink: 1;
          min-width: 0;
        }
        .MuiAutocomplete-endAdornment {
          top: 50%;
          transform: translate(0, -50%);
          ${(props) => (props.type === '1' ? `display:flex; flex-direction: row-reverse;` : ``)}
          .MuiButtonBase-root-MuiIconButton-root-MuiAutocomplete-clearIndicator {
            width: 14px;
            height: 14px;
            margin-right: 0;
            background-color: #5b5c5b;
            .MuiSvgIcon-root {
              padding: 2px 2px 2px 4px;
              color: #fff;
            }
          }
          .MuiButtonBase-root-MuiIconButton-root-MuiAutocomplete-popupIndicator {
            ${(props) => (props.type === '1' ? `width: 0; height: 0; padding: 0;` : ``)}
            .MuiSvgIcon-root {
              ${(props) => (props.type === '1' ? `width: 0;` : ``)}
            }
          }
          .MuiButtonBase-root-MuiIconButton-root-MuiAutocomplete-popupIndicator {
            ${(props) => (props.type === '1' ? `width: 0; height: 0; padding: 0;` : ``)}
            .MuiSvgIcon-root {
              ${(props) => (props.type === '1' ? `width: 0;` : ``)}
            }
          }
        }
        .MuiOutlinedInput-notchedOutline {
          top: 0;
          width: 100%;
          padding: 0;
          border-radius: 2px;
          ${(props) => props.isInGrid && `border: none;`}
          ${(props) =>
            !props.isInGrid && props.status === 'default' && `border: 1px solid #b9bcbb;`}
          ${(props) => !props.isInGrid && props.status === 'error' && `border: 1px solid #fda293;`}
          ${(props) =>
            !props.isInGrid && props.status === 'warning' && `border: 1px solid #FF9322;`}
          ${(props) =>
            !props.isInGrid && props.status === 'confirm' && `border: 1px solid #00806A;`}
        }
      }
    }
  }

  .MuiOutlinedInput-root {
    padding-right: 30px;
  }

  .MuiOutlinedInput-notchedOutline {
    border: none;
  }

  .Mui-focused .MuiOutlinedInput,
  .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline {
    ${(props) => (!props.isInGrid ? 'border: 1px solid #5b5c5d !important;' : '')}
  }

  /* chip tag */
  .MuiAutocomplete-root .MuiAutocomplete-tag {
    margin: auto 0;
    margin-left: 2px;
    max-width: 145px;
    height: 20px;

    & > span {
      overflow: hidden;
      text-overflow: ellipsis;
      height: 20px;
      color: #1f1f1f;
      font-size: 13px;
      font-weight: 400;
      line-height: 150%;
      ${(props) =>
        props.chipType === 'default' ? `padding: 0 16px 0 8px;` : `padding: 0 16px 0 26px;`}
      position: relative;
    }
    & > svg {
      width: 14px;
    }
  }

  .MuiAutocomplete-popupIndicator {
    display: none;
  }
`;
/* 툴팁 */
export const Tip = styled.span`
  font-family: 'Spoqa Han Sans Neo';
  color: #fff;
  font-weight: 300;
  font-size: 12px;
`;
