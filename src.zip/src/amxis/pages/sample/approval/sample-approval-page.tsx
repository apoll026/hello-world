import { getApprovalRuleLines } from '@/amxis/apis/admin/ApprovalRule.ts';
import {
  requestApproval,
  requestCancelApproval,
  retrieveApproval,
  saveApprovalLine,
} from '@/amxis/apis/sample/ApprovalApi.ts';
import { CustomSelect } from '@/amxis/components/custom-select';
import DepartmentSearchInput from '@/amxis/components/department/department-search-input.tsx';
import EmployeeSearchInput from '@/amxis/components/employee/employee-search-input.tsx';
import { ButtonGroup, Spacer } from '@/amxis/components/layout';
import { useCommonCodeNamesQuery } from '@/amxis/hooks/queries/common/use-common-code-names-query.ts';
import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { Department } from '@/amxis/models/admin/Department.ts';
import { Employee } from '@/amxis/models/admin/Employee.ts';
import { ApprovalLine, ApprovalMasterLineRequestVO } from '@/amxis/models/common/Approver.ts';
import { CmnGrCdEnum } from '@/amxis/models/common/CommonCode.ts';
import { CrudCode } from '@/amxis/models/common/Edit.ts';
import { useCommonDialogStore } from '@/amxis/stores/useCommonDialogStore.ts';
import useLanguageStore from '@/amxis/stores/useLanguageStore.ts';
import { zodResolver } from '@hookform/resolvers/zod';
import {
  AgGridReact,
  Button,
  ColDef,
  DataGrid,
  FormItem,
  ICellRendererParams,
  InputField,
  SearchArea,
} from '@amxis/design-system';
import { Box, Grid, Typography } from '@mui/material';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { z } from 'zod';

const SampleApprovalPage = () => {
  const gridRef = useRef<AgGridReact | null>(null);
  const { currentLanguage } = useLanguageStore();
  const { openCommonDialog } = useCommonDialogStore();
  const { t } = useTranslation();

  const [approvalLineList, setApprovalLineList] = useState<ApprovalLine[]>([]);
  const [approvalReviewEmployeeList, setApprovalReviewEmployeeList] = useState<Employee[]>([]);
  const [approvalReviewDepartmentList, setApprovalReviewDepartmentList] = useState<Department[]>(
    []
  );

  //결재 라인관리 규칙을 사용했을 때 초기 결재라인 설정하는 부분 start
  //샘플이기 때문에 초기데이터가 이 내용 뿐이라 프론트에서 api를 불렀습니다.
  const { data: fetchedApprovalRuleLineList } = useReactQuery({
    queryKey: ['getApprovalRuleLines', 'AR-000'],
    queryFn: () => {
      return getApprovalRuleLines('AR-000');
    },
  });

  useEffect(() => {
    if (fetchedApprovalRuleLineList) {
      //기본 결재라인
      const defaultApprovalLine = fetchedApprovalRuleLineList.filter(
        (fetchedApprovalRuleLine) => fetchedApprovalRuleLine.aprLnDivsCd === 'APPD'
      );

      //기본 통보자
      const defaultReadUserList = fetchedApprovalRuleLineList.filter(
        (fetchedApprovalRuleLine) => fetchedApprovalRuleLine.aprLnDivsCd === 'INFR'
      );

      //기본 공개부서
      const defaultReadDeptList = fetchedApprovalRuleLineList.filter(
        (fetchedApprovalRuleLine) => fetchedApprovalRuleLine.aprLnDivsCd === 'NOGR'
      );

      setApprovalLineList(
        defaultApprovalLine?.map((fetchedApprovalRuleLine) => ({
          reqNo: '',
          apprLnSeq: String(fetchedApprovalRuleLine.apprLnSeq),
          nextApprSeq: String(fetchedApprovalRuleLine.nextApprSeq),
          nextApprType: fetchedApprovalRuleLine.nextApprType,

          nextApprJpsNm: fetchedApprovalRuleLine.jpsNm,
          deptNm: fetchedApprovalRuleLine.deptNm,
          nextApprUserNm: fetchedApprovalRuleLine.empName,
          nextApprUserId: fetchedApprovalRuleLine.userId,

          nextApprEmpNo: fetchedApprovalRuleLine.nextApprEmpNo,
          prlYn: fetchedApprovalRuleLine.prlYn,
          apprStatus: '',
          apprMessage: '',
          apprDate: '',
          crudKey: CrudCode.CREATE,
        }))
      );

      setApprovalReviewEmployeeList(
        defaultReadUserList.map((readUser) => ({
          userId: readUser.userId,
          empName: readUser.empName,
        }))
      );

      setApprovalReviewDepartmentList(
        defaultReadDeptList.map((readDept) => ({
          deptCd: readDept.deptCd,
          deptNm: readDept.deptNm,
        }))
      );
    }
  }, [fetchedApprovalRuleLineList]);
  //결재 라인관리 규칙을 사용했을 때 초기 결재라인 설정하는 부분 end

  console.log(approvalReviewEmployeeList, approvalReviewDepartmentList);
  const { data: aprTpDivsCdList } = useCommonCodeNamesQuery(CmnGrCdEnum.APR_TP_DIVS_CD);

  const approvalRequestColumnDefs: ColDef[] = [
    {
      colId: 'checkColumn',
      headerCheckboxSelection: true,
      checkboxSelection: true,
      showDisabledCheckboxes: true,
      headerClass: 'checkbox',
      width: 30,
      sortable: false,
    },
    {
      headerName: t('', '구분') as string,
      field: 'nextApprType',
      width: 100,
      cellStyle: { textAlign: 'center', justifyContent: 'center' },
      cellRenderer: (params: ICellRendererParams) => {
        return (
          <CustomSelect
            height="24px"
            value={params.value ?? ''}
            onChange={(e) => params.node.setDataValue('nextApprType', e.target.value)}
          >
            <option key="" value="">
              선택
            </option>
            {aprTpDivsCdList?.map((code) => (
              <option key={code.cmnCd} value={code.cmnCd}>
                {code.cmnCdNm}
              </option>
            ))}
          </CustomSelect>
        );
      },
    },
    {
      headerName: t('', '승인자') as string,
      field: 'nextApprEmpNo',
      width: 200,
      cellRenderer: (params) => {
        return (
          <EmployeeSearchInput
            onChange={(empList: Employee[]) => {
              params.data.nextApprJpsNm = empList.length > 0 ? empList?.[0].jpsNm : '';
              params.data.deptNm = empList.length > 0 ? empList?.[0].deptNm : '';
              params.data.nextApprUserNm = empList.length > 0 ? empList?.[0].empName : '';
              params.data.nextApprUserId = empList.length > 0 ? empList?.[0].userId : '';
              params.node.setDataValue(
                'nextApprEmpNo',
                empList.length > 0 ? empList?.[0].empNo : ''
              );
            }}
            onInit={
              params.data.nextApprEmpNo
                ? [{ userId: params.data.nextApprUserId, empName: params.data.nextApprUserNm }]
                : []
            }
            height="24px"
            isInGrid
            singleSelect
          />
        );
      },
    },
    {
      headerName: t('', '직책/직위') as string,
      field: 'nextApprJpsNm',
      width: 160,
      cellStyle: { textAlign: 'center' },
    },

    {
      headerName: t('', '부서') as string,
      field: 'deptNm',
      width: 160,
      cellStyle: { textAlign: 'center' },
    },
    {
      headerName: t('', '처리상태') as string,
      field: 'apprStatus',
      width: 160,
      cellStyle: { textAlign: 'center' },
    },
    {
      headerName: t('', '결재일시') as string,
      field: 'apprDate',
      width: 200,
      cellStyle: { textAlign: 'center' },
    },
    {
      headerName: t('', '결재의견') as string,
      field: 'apprMessage',
      width: 100,
      flex: 1,
      cellStyle: { textAlign: 'center' },
    },
  ];

  const handleAddButtonClick = () => {
    const newRecord = {
      reqNo: '', //결재요청번호
      apprLnSeq: '', //결재라인순번
      nextApprSeq: '', //결재선 순서
      nextApprType: '', //결재타입
      nextApprEmpNo: '', //결재 유저 사번
      prlYn: '', //병렬 유무
      apprStatus: '', //결재 상태
      apprMessage: '', //의견
      apprDate: '', //결재시간
      crudKey: CrudCode.CREATE,
    };

    setApprovalLineList((prev) => [...prev, newRecord]);
  };

  const handleRemoveButtonClick = useCallback(() => {
    const selectedRowNodes = gridRef.current!.api.getSelectedNodes();
    if (selectedRowNodes.length == 0) {
      openCommonDialog({
        modalType: 'alert',
        content: t('common.alert.선택된 행이 없습니다.', '선택된 행이 없습니다.'),
      });
      return false;
    }

    const selectedIds = selectedRowNodes
      .map((rowNode) => {
        return parseInt(rowNode.id!);
      })
      .reverse();

    selectedIds.forEach((item) => {
      if (approvalLineList[item]?.crudKey === CrudCode.CREATE) {
        delete approvalLineList[item];
      } else {
        approvalLineList[item].crudKey = CrudCode.DELETE;
      }
    });

    const filteredData = approvalLineList.filter((element) => element !== undefined);
    setApprovalLineList(filteredData);
  }, [approvalLineList, gridRef]);

  const handleClickApprovalRequest = () => {
    if (
      approvalLineList.length === 0 ||
      approvalLineList.find(
        (approvalLine) => !approvalLine.nextApprEmpNo || !approvalLine.nextApprType
      )
    ) {
      openCommonDialog({
        modalType: 'alert',
        content: '결재선을 입력해주세요.',
      });
      return;
    }

    openCommonDialog({
      modalType: 'confirm',
      content: '결재 요청 하시겠습니까?',
      onSubmit: () => {
        const approvalMasterLineRequestVO: ApprovalMasterLineRequestVO = {
          approvalMasterVO: {
            formId: 'APR-FORM-TEST-01', //포탈에서 제공하는 결재 양식 코드
            reqEmpNo: '56200',
            apprTitle: '제목',
            formEditorData: '<p>결재 본문 입니다.</p>',
            apprPeriodCd: 'APPRCODE_2Y',
            readUser: approvalReviewEmployeeList.map((reviewEmp) => reviewEmp.empNo).join(';'),
            readDept: approvalReviewDepartmentList.map((reviewDept) => reviewDept.deptCd).join(';'),
          },
          approvalLineVOList: approvalLineList.filter(
            (approvalLine) => approvalLine.crudKey !== CrudCode.DELETE
          ),
        };

        saveApprovalLine(approvalMasterLineRequestVO).then((result) => {
          if (result) {
            requestApproval(result).then((commonReturnData) => {
              if (commonReturnData.result === 'success') {
                console.log('result : ', commonReturnData);
                openCommonDialog({
                  modalType: 'alert',
                  content: `결재 요청 되었습니다. 결재요청번호는 ${result} 입니다.`,
                });
              } else {
                openCommonDialog({
                  modalType: 'alert',
                  content: commonReturnData.message,
                });
              }
            });
          } else {
            openCommonDialog({
              modalType: 'alert',
              content: '결재 중 오류가 발생하였습니다.',
            });
          }
        });
      },
    });
  };

  //==========================================
  //결재 결과

  const [searchCondition, setSearchCondition] = useState<{ reqNo: string; apprMessage: string }>({
    reqNo: '',
    apprMessage: '',
  });
  const { handleSubmit, control } = useForm<{ reqNo: string; apprMessage: string }>({
    resolver: zodResolver(
      z.object({
        reqNo: z.string().optional(),
        apprMessage: z.string().optional(),
      })
    ),
    defaultValues: { reqNo: '', apprMessage: '' },
  });

  const { data: fetchedApprovalMasterLine, refetch } = useReactQuery({
    queryKey: ['retrieveApproval', searchCondition.reqNo],
    queryFn: () => {
      return searchCondition.reqNo ? retrieveApproval(searchCondition.reqNo) : null;
    },
  });

  const approvalResponseColumnDefs: ColDef[] = [
    {
      headerName: t('', '구분') as string,
      field: 'nextApprTypeCdNm',
      width: 100,
      cellStyle: { textAlign: 'center', justifyContent: 'center' },
    },
    {
      headerName: t('', '결재라인순번') as string,
      field: 'apprLnSeq',
      width: 100,
      cellStyle: { textAlign: 'center', justifyContent: 'center' },
    },
    {
      headerName: t('', '결재선순서') as string,
      field: 'nextApprSeq',
      width: 100,
      cellStyle: { textAlign: 'center', justifyContent: 'center' },
    },
    {
      headerName: t('', '승인자') as string,
      field: 'nextApprEmpNm',
      width: 100,
      cellStyle: { textAlign: 'left', justifyContent: 'center' },
      valueGetter: (params) => {
        if (params.data.dlgtEmpNo) {
          return `${params.data.nextApprEmpNm} (위임) ${params.data.dlgtEmpNm}`;
        } else {
          return params.data.nextApprEmpNm;
        }
      },
    },
    {
      headerName: t('', '직책/직급') as string,
      field: 'nextApprJpsNm',
      width: 160,
      cellStyle: { textAlign: 'center' },
      valueGetter: (params) => {
        if (params.data.dlgtEmpNo) {
          return params.data.dlgtJpsNm;
        } else {
          return params.data.nextApprJpsNm;
        }
      },
    },

    {
      headerName: t('', '부서') as string,
      field: 'nextApprDeptNm',
      width: 160,
      cellStyle: { textAlign: 'center' },
      valueGetter: (params) => {
        if (params.data.dlgtEmpNo) {
          return params.data.dlgtDeptNm;
        } else {
          return params.data.nextApprDeptNm;
        }
      },
    },
    {
      headerName: t('', '처리상태') as string,
      field: 'apprStatusCdNm',
      width: 160,
      cellStyle: { textAlign: 'center' },
    },
    {
      headerName: t('', '결재일시') as string,
      field: 'apprDate',
      width: 200,
      cellStyle: { textAlign: 'center' },
    },
    {
      headerName: t('', '결재의견') as string,
      field: 'apprMessage',
      width: 100,
      flex: 1,
      cellStyle: { textAlign: 'center' },
    },
  ];

  const handleSearch = handleSubmit(async (condition) => {
    if (searchCondition.reqNo === condition.reqNo) {
      refetch();
    } else {
      setSearchCondition({
        ...searchCondition,
        ...condition,
      });
    }
  });

  const handleClickApprovalCancel = () => {
    console.log(searchCondition);
    requestCancelApproval(searchCondition.reqNo, '').then((commonReturnData) => {
      if (commonReturnData) {
        console.log('result : ', commonReturnData);
        if (commonReturnData.result === 'success') {
          openCommonDialog({
            modalType: 'alert',
            content: `결재 취소 되었습니다.`,
          });
        } else {
          openCommonDialog({
            modalType: 'alert',
            content: commonReturnData.message,
          });
        }
        refetch();
      } else {
        openCommonDialog({
          modalType: 'alert',
          content: '결재 취소 중 오류가 발생하였습니다.',
        });
      }
    });
  };

  return (
    <Box sx={{ paddingLeft: '32px', paddingRight: '32px' }}>
      <Spacer type="h" size="12" />
      <DataGrid
        hasTotalCountArea={false}
        defaultColDef={{ sortable: false }}
        gridRef={gridRef}
        columnDefs={approvalRequestColumnDefs}
        isHeaderSectionEnabled
        rowData={approvalLineList}
        rowHeight={25}
        rowSelection="multiple"
        suppressRowClickSelection
        animateRows
        stopEditingWhenCellsLoseFocus
        headerButton={[
          {
            variant: 'add',
            label: `${t('common.label.행추가', '행추가')}`,
            onClick: () => handleAddButtonClick(),
          },
          {
            variant: 'delete',
            label: `${t('common.label.행삭제', '행삭제')}`,
            onClick: () => handleRemoveButtonClick(),
          },
        ]}
        sxOfWrapper={{
          display: 'flex',
          flexDirection: 'column',
          flexGrow: '1',
        }}
        sxOfGrid={{
          display: 'flex',
          flexDirection: 'column',
          height: '200px',
          flexGrow: '1',
        }}
        title={'결재요청라인'}
        language={currentLanguage}
        emptyLabel={
          t('common.label.조회 가능한 데이터가 없습니다.', '조회 가능한 데이터가 없습니다.') ??
          undefined
        }
        reactiveCustomComponents={true}
      />
      <Spacer type="h" size="12" />
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          height: '28px',
        }}
      >
        <Typography variant="h3">{t('', '통보자 정보')}</Typography>
      </Box>
      <Spacer type="h" size="4" />
      <EmployeeSearchInput
        onInit={approvalReviewEmployeeList ?? []}
        height="32px"
        onChange={(empList) => setApprovalReviewEmployeeList(empList)}
        limitTags={5}
      />
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          height: '28px',
        }}
      >
        <Typography variant="h3">{t('', '공개부서 정보')}</Typography>
      </Box>
      <Spacer type="h" size="4" />
      <DepartmentSearchInput
        onInit={approvalReviewDepartmentList ?? []}
        height="32px"
        onChange={(deptList) => setApprovalReviewDepartmentList(deptList)}
        limitTags={5}
      />
      <Spacer type="h" size="4" />
      <ButtonGroup>
        <Button
          size="medium"
          appearance="contained"
          priority="normal"
          onClick={handleClickApprovalRequest}
        >
          결재요청
        </Button>
      </ButtonGroup>
      <Spacer type="h" size="12" />
      <Typography variant="h3">결재 결과 조회</Typography>
      <Spacer type="h" size="4" />
      <SearchArea
        conditions={
          <>
            <Grid item xs={4}>
              <FormItem
                label={'결재요청번호'}
                labelAlign="right"
                render={() => (
                  <>
                    <Controller
                      control={control}
                      name="reqNo"
                      render={({ field: { ref, ...field } }) => (
                        <InputField
                          {...field}
                          ref={undefined}
                          size="medium"
                          variant="outlined"
                          placeholder={t('code.label.입력하세요', '입력하세요') ?? '입력하세요'}
                          fullWidth={true}
                          autoComplete="off"
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleSearch();
                          }}
                        />
                      )}
                    />
                  </>
                )}
              />
            </Grid>
          </>
        }
        onSearch={handleSearch}
      />
      <Spacer type="h" size="12" />
      <DataGrid
        hasTotalCountArea={false}
        defaultColDef={{ sortable: false }}
        columnDefs={approvalResponseColumnDefs}
        isHeaderSectionEnabled
        rowData={fetchedApprovalMasterLine?.approvalLineResponseVOList ?? []}
        rowHeight={25}
        rowSelection="multiple"
        suppressRowClickSelection
        animateRows
        stopEditingWhenCellsLoseFocus
        sxOfWrapper={{
          display: 'flex',
          flexDirection: 'column',
          flexGrow: '1',
        }}
        sxOfGrid={{
          display: 'flex',
          flexDirection: 'column',
          height: '300px',
          flexGrow: '1',
        }}
        title={'결재결과라인'}
        language={currentLanguage}
        emptyLabel={
          t('common.label.조회 가능한 데이터가 없습니다.', '조회 가능한 데이터가 없습니다.') ??
          undefined
        }
        reactiveCustomComponents={true}
      />
      <Spacer type="h" size="4" />
      <ButtonGroup>
        <Button
          size="medium"
          appearance="contained"
          priority="normal"
          onClick={handleClickApprovalCancel}
        >
          결재취소
        </Button>
      </ButtonGroup>
    </Box>
  );
};

export default SampleApprovalPage;
