import { Box, FormControl, Typography } from '@mui/material';
import { ContainerLayout } from '@/amxis/components/container-layout';
import { ContainerBox } from '../__components/container-box.tsx';
import { SamplePageTitle } from '../__components/sample-page-title.tsx';
import { DocumentContentH2 } from '../__components/document-content-h2.tsx';
import { useTranslation } from 'react-i18next';
import { InputField, useTheme, useMessageBar, HelperText } from '@amxis/design-system';
import { Button } from '@amxis/design-system';
import * as z from 'zod';
import { Controller, useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useLoading } from '@/amxis/components/loader';
import { Label } from '@amxis/design-system';
import { useMailTemplatesQuery } from '@/amxis/hooks/queries/sample/use-email-templates-query.ts';
import { useSendMailMutate } from '@/amxis/hooks/queries/sample/use-send-mail-mutate.ts';
import { useMailBatchTestQuery } from '@/amxis/hooks/queries/sample/use-mail-batch-test-query.ts';
import styled from '@emotion/styled';
import { BorderColor, BgColor, FontColor } from '@/amxis/ui/theme/Color.ts';

const ViewTable = styled.table`
  width: 100%;
  min-width: 500px;
  border: 1px solid ${BorderColor.Primary};
  table-layout: fixed;
  line-height: 1.4;

  th,
  td {
    height: 38px;
    padding: 3px 8px;
    vertical-align: middle;
    font-size: 13px;
    border-right: 1px solid ${BorderColor.Primary};
    border-bottom: 1px solid ${BorderColor.Primary};

    &.borderR0 {
      border-right: 0;
    }
  }

  th {
    text-align: left;
    font-weight: 500;
    background-color: ${BgColor.White100};
  }

  thead th,
  .alignC {
    text-align: center;
  }
  .alignR {
    text-align: right;
  }

  td {
    color: ${FontColor.Default};
  }

  &.width300 {
    width: 300px;
  }

  .heightAuto {
    height: auto;
  }

  & + & {
    margin-top: 20px;
  }

  & + .contentEnd {
    margin-top: 10px;
  }

  .padding0 {
    padding: 0;
  }

  .margin0 {
    margin: 0;
  }

  .marginT15 {
    margin-top: 15px;
  }
`;

function SampleEmailSendPage() {
  const { t } = useTranslation();
  const { openLoading } = useLoading();
  const { showMessageBar } = useMessageBar();
  const [theme] = useTheme();

  const { mutate: sendMail } = useSendMailMutate();

  const emailSendSchema = z.object({
    toAddress: z.string().min(
      1,
      `${t(`common.label.{{}}를 입력하세요.`, `__{{inputTarget}}를 입력하세요.`, {
        inputTarget: `${t('email-send.수신자(메일 주소)', '__수신자(메일 주소)')}`,
      })}`
    ),
    ccAddress: z.string().optional(),
    bccAddress: z.string().optional(),
    subject: z.string().min(
      1,
      `${t(`common.label.{{}}를 입력하세요.`, `__{{inputTarget}}를 입력하세요.`, {
        inputTarget: `${t('email-send.메일 제목', '__메일 제목')}`,
      })}`
    ),
    content: z.string().optional(),
  });
  type MessageSearchForm = z.infer<typeof emailSendSchema>;

  const { data: testEmailTempate, refetch: refetchMailTemplate } =
    useMailTemplatesQuery('test-template');

  const { refetch: mailBatchTest } = useMailBatchTestQuery();

  const {
    handleSubmit,
    control,
    formState: { errors },
  } = useForm<MessageSearchForm>({
    resolver: zodResolver(emailSendSchema),
    defaultValues: {
      toAddress: '',
      ccAddress: '',
      bccAddress: '',
      subject: '',
      content: '',
    },
  });

  const handleEmailSend = handleSubmit(
    async ({ toAddress, ccAddress, bccAddress, subject, content }) => {
      try {
        openLoading(true);
        sendMail(
          {
            subject: subject,
            toAddress: toAddress,
            ccAddress: ccAddress,
            bccAddress: bccAddress,
            content: content,
          },
          {
            onSuccess: () => {
              showMessageBar({
                message: t('common.confirm.저장되었습니다', '저장되었습니다.'),
                usecase: 'success',
              });
            },
            onError: () => {
              showMessageBar({
                message: t(
                  'common.alert.저장 중 오류가 발생했습니다.',
                  '저장 중 오류가 발생했습니다.'
                ),
                usecase: 'error',
              });
            },
          }
        );
      } catch (e) {
        showMessageBar({
          message: t('common.alert.저장에 실패하였습니다.'),
          usecase: 'error',
        });
      } finally {
        openLoading(false);
      }
    }
  );

  const mailSendTest = () => {
    mailBatchTest().then((result) => {
      if (result.isSuccess) {
        showMessageBar({
          message: t('common.confirm.저장되었습니다', '저장되었습니다.'),
          usecase: 'success',
        });
      } else {
        showMessageBar({
          message: t('common.alert.저장에 실패하였습니다.'),
          usecase: 'error',
        });
      }
    });
  };

  return (
    <ContainerBox>
      <ContainerLayout>
        <SamplePageTitle>{t('com.menu.000028', '메일발송')}</SamplePageTitle>
        <Box mt="48px">
          <DocumentContentH2 title={t('com.menu.000028', '메일발송')} />
          <Box mt="24px" />
          <Typography variant="body2" sx={{ color: theme.palette.semantic.color.commonTextBasic }}>
            {
              '메일 \n발송 시 sendMail메서드를 호출하여 메일 발송 Que테이블에 발송 대상 메일을 저장하고, 배치를 통해 Que테이블에 저장된 메일을 발송하고 있습니다.'
            }
          </Typography>
          <Typography variant="body2" sx={{ color: theme.palette.semantic.color.commonTextBasic }}>
            {
              '아래 메일 발송 샘플은 Que테이블에 발송 대상 메일을 저장하는 기능(메일발송대상 저장하기)과 Que테이블에 저장된 메일을 발송하는 기능(메일발송하기)을 테스트할 수 있습니다.'
            }
          </Typography>
          <Box mt="24px">
            <form onSubmit={handleEmailSend}>
              <FormControl fullWidth>
                <ViewTable>
                  <tbody>
                    <tr>
                      <th scope="row" colSpan={2}>
                        <Label
                          labelText={`${t('email-send.수신자(메일 주소)', '__수신자(메일 주소)')}`}
                          isRequired
                        />
                      </th>
                      <td colSpan={10}>
                        <Box
                          sx={{ width: '100% !important', display: 'flex', alignItems: 'center' }}
                        >
                          <Controller
                            control={control}
                            name="toAddress"
                            render={({ field }) => (
                              <InputField
                                {...field}
                                id="toAddress"
                                size="small"
                                fullWidth
                                placeholder={`${t(
                                  `common.label.{{}}를 입력해 주세요.`,
                                  `__{{inputTarget}}를 입력해 주세요.`,
                                  {
                                    inputTarget: t(
                                      'email-send.수신자(메일 주소)',
                                      '__수신자(메일 주소)'
                                    ),
                                  }
                                )}`}
                              />
                            )}
                          />
                        </Box>
                        {errors.toAddress && (
                          <Box mt="4px">
                            <HelperText
                              infoText={(errors?.toAddress?.message as string) ?? ''}
                              usecase="error"
                            />
                          </Box>
                        )}
                      </td>
                    </tr>
                    <tr>
                      <th scope="col" colSpan={2}>
                        <Label
                          labelText={`${t('email-send.참조자(메일 주소)', '__참조자(메일 주소)')}`}
                        />
                      </th>
                      <td colSpan={4}>
                        <Controller
                          control={control}
                          name="ccAddress"
                          render={({ field }) => (
                            <InputField
                              {...field}
                              id="ccAddress"
                              size="small"
                              fullWidth
                              placeholder={`${t(
                                `common.label.{{}}를 입력해 주세요.`,
                                `__{{inputTarget}}를 입력해 주세요.`,
                                {
                                  inputTarget: t(
                                    'email-send.참조자(메일 주소)',
                                    '__참조자(메일 주소)'
                                  ),
                                }
                              )}`}
                            />
                          )}
                        />
                      </td>
                      <th scope="col" colSpan={2}>
                        <Label
                          labelText={`${t(
                            'email-send.숨김 참조자(메일 주소)',
                            '__숨김 참조자(메일 주소)'
                          )}`}
                        />
                      </th>
                      <td colSpan={4}>
                        <Controller
                          control={control}
                          name="bccAddress"
                          render={({ field }) => (
                            <InputField
                              {...field}
                              id="bccAddress"
                              size="small"
                              fullWidth
                              placeholder={`${t(
                                `common.label.{{}}를 입력해 주세요.`,
                                `__{{inputTarget}}를 입력해 주세요.`,
                                {
                                  inputTarget: t(
                                    'email-send.숨김 참조자(메일 주소)',
                                    '__숨김 참조자(메일 주소)'
                                  ),
                                }
                              )}`}
                            />
                          )}
                        />
                      </td>
                    </tr>
                    <tr>
                      <th scope="row" colSpan={2}>
                        <Label
                          labelText={`${t('email-send.메일 제목', '__메일 제목')}`}
                          isRequired
                        />
                      </th>
                      <td colSpan={10}>
                        <Box
                          sx={{ width: '100% !important', display: 'flex', alignItems: 'center' }}
                        >
                          <Controller
                            control={control}
                            name="subject"
                            render={({ field }) => (
                              <InputField
                                {...field}
                                id="subject"
                                size="small"
                                fullWidth
                                placeholder={`${t(
                                  `common.label.{{}}을 입력해 주세요.`,
                                  `{{inputTarget}}을 입력해 주세요.`,
                                  {
                                    inputTarget: t('email-send.메일 제목', '__메일 제목'),
                                  }
                                )}`}
                              />
                            )}
                          />
                        </Box>
                        {errors.subject && (
                          <Box mt="4px">
                            <HelperText
                              infoText={(errors?.subject?.message as string) ?? ''}
                              usecase="error"
                            />
                          </Box>
                        )}
                      </td>
                    </tr>
                  </tbody>
                </ViewTable>
                <Box
                  component="ul"
                  pl="10px"
                  ml="12px"
                  mt="8px"
                  color={theme.palette.semantic.color.commonTextLight}
                  fontSize="16px"
                  fontWeight={400}
                  lineHeight="150%"
                  letterSpacing="-0.16px"
                  sx={{
                    listStyle: 'disc',
                  }}
                >
                  <Box component="li">
                    {'메일 발송 시, 수신자(메일 주소)와 제목은 필수 입력값입니다.'}
                  </Box>
                  <Box component="li">
                    {
                      "메일 발송 시, ','(콤마)로 구분하여 메일 주소를 입력할 경우 여러 명의 수신자(또는 참조자)에게 메일 발송이 가능합니다."
                    }
                  </Box>
                </Box>
                <Box
                  sx={{
                    display: 'flex',
                    justifyContent: 'flex-start',
                    gap: '20px',
                  }}
                >
                  <Button type="submit" size="large" appearance="contained" priority="normal">
                    {t('email-send.STEP1. 메일발송대상 저장하기', '__STEP1. 메일발송대상 저장하기')}
                  </Button>
                  <Button
                    size="large"
                    appearance="contained"
                    priority="normal"
                    onClick={mailSendTest}
                  >
                    {t('email-send.STEP2. 메일발송하기', '__STEP2. 메일발송하기')}
                  </Button>
                </Box>
              </FormControl>
            </form>
          </Box>
        </Box>
        <Box mt="48px">
          <DocumentContentH2 title={t('email-send.메일 템플릿', '__메일 템플릿')} />
          <Box mt="24px">
            <Box
              sx={{
                display: 'flex',
                justifyContent: 'flex-start',
                gap: '4px',
              }}
            >
              <Button
                size="large"
                appearance="contained"
                priority="normal"
                onClick={() => refetchMailTemplate()}
              >
                {t('email-send.메일 템플릿 불러오기', '__메일 템플릿 불러오기')}
              </Button>
            </Box>
            {testEmailTempate && (
              <Box
                mt={'10px'}
                borderRadius={'3px'}
                border={`1px solid ${BorderColor.Form}`}
                px={'20px'}
                py={'15px'}
              >
                <div dangerouslySetInnerHTML={{ __html: testEmailTempate }} />
              </Box>
            )}
          </Box>
        </Box>
      </ContainerLayout>
    </ContainerBox>
  );
}

export { SampleEmailSendPage };
