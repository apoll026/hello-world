import { useState } from 'react';
import dayjs, { Dayjs } from 'dayjs';
import {
  DateRangePickerValueType,
  DropdownOption,
  HelperText,
  InputField,
} from '@amxis/design-system';
import Box from '@mui/material/Box';
import { Typography } from '@mui/material';

const SEARCH_OPTIONS = [
  { label: 'Keyword', value: 'Keyword' },
  { label: 'Keyword1', value: 'Keyword1' },
  { label: 'Keyword2', value: 'Keyword2' },
  { label: 'Keyword3', value: 'Keyword3' },
  { label: '4', value: '4' },
];

export const SampleInputField = () => {
  const [date, setDate] = useState<Dayjs | null>(null);

  const [dates, setDates] = useState<DateRangePickerValueType>([
    dayjs('2018-04-04T16:00:00.000Z'),
    dayjs('2018-04-13 19:18'),
  ]);

  const handleChange = (dates: DateRangePickerValueType) => {
    console.log({ dates });
    setDates(dates);
  };

  const [text, setText] = useState<string>('this is some text');

  const handleChange2 = (event: React.ChangeEvent<HTMLInputElement>) => {
    console.log(event?.target?.value);
    setText(event?.target?.value);
  };

  const [text2, setText2] = useState<string>('0123456789');

  const handleChange3 = (event: React.ChangeEvent<HTMLInputElement>) => {
    console.log(event?.target?.value);
    setText2(event?.target?.value);
  };

  const [password, setPassword] = useState<string>('');
  const handleChange4 = (event: React.ChangeEvent<HTMLInputElement>) => {
    console.log(event?.target?.value);
    setPassword(event?.target?.value);
  };

  const [time, setTime] = useState<string>('오후 11 : 15');
  const [time2, setTime2] = useState<string>('11:15');
  const [time3, setTime3] = useState<string>('11:15');

  const handleTimeChange = (value: string) => {
    console.log(value);
    setTime(value);
  };

  const handleTimeChange2 = (value: string) => {
    console.log(value);
    setTime2(value);
  };

  const handleTimeChange3 = (value: string) => {
    console.log(value);
    setTime3(value);
  };

  const [value, setValue] = useState<DropdownOption | null>(null);
  const [values, setValues] = useState<DropdownOption[]>([]);
  const [values2, setValues2] = useState<DropdownOption[]>([]);

  return (
    <Box my="24px">
      <Typography variant="h4">Text Type</Typography>
      <div>{JSON.stringify(text, null, 2)}</div>
      <Box width={500}>
        <InputField
          fullWidth
          type="text"
          size="small"
          value={text}
          onChange={handleChange2}
          status="error"
        />
        <HelperText infoText={'error helper text'} usecase="error" />
      </Box>
      <div>{JSON.stringify(password, null, 2)}</div>
      <Box width={210}>
        <InputField fullWidth size="small" value={password} onChange={handleChange4} isPassword />
      </Box>
      <Typography variant="h4">Textarea Type</Typography>
      <div>{JSON.stringify(text2, null, 2)}</div>
      <Box width={300}>
        <InputField
          fullWidth
          type="textarea"
          value={text2}
          textLimit
          limited={300}
          onChange={handleChange3}
          height={200}
        />
      </Box>
      <Typography variant="h4">Search Type</Typography>
      <div>{JSON.stringify(value, null, 2)}</div>
      <Box width={200}>
        <InputField
          type="search"
          usecase="text"
          options={SEARCH_OPTIONS}
          value={value}
          onChange={(_, value) => {
            setValue(value as DropdownOption);
          }}
          onSearchClick={() => console.log('search Clicked')}
        />
      </Box>
      <div>{JSON.stringify(values2, null, 2)}</div>
      <Box width={200}>
        <InputField
          type="search"
          usecase="chip-single"
          options={SEARCH_OPTIONS}
          value={values2}
          onChange={(_, value) => {
            setValues2(value as DropdownOption[]);
          }}
          size="medium"
          onSearchClick={() => console.log('search Clicked')}
        />
      </Box>
      <div>{JSON.stringify(values, null, 2)}</div>
      <Box width={400}>
        <InputField
          type="search"
          usecase="chips-multi"
          options={SEARCH_OPTIONS}
          value={values}
          limitTags={1}
          onChange={(_, value) => {
            setValues(value as DropdownOption[]);
          }}
          size="small"
          onSearchClick={() => console.log('search Clicked')}
        />
      </Box>
      <Typography variant="h4">Date Type</Typography>
      <InputField
        type="date"
        size="small"
        value={date}
        onChange={(date: Dayjs | null) => {
          console.log(date?.toString());
          setDate(date);
        }}
      />
      <Typography variant="h4">Date Range Type</Typography>
      <div>{JSON.stringify(dates, null, 2)}</div>
      <InputField type="date-range" size="large" value={dates} onChange={handleChange} />
      <Typography variant="h4">Time Type</Typography>
      <div>{JSON.stringify(time, null, 2)}</div>
      <Box width={300}>
        <InputField type="time" usecase="single-12h" onChange={handleTimeChange} value={time} />
      </Box>
      <div>{JSON.stringify(time2, null, 2)}</div>
      <Box width={300}>
        <InputField
          type="time"
          usecase="single-24h"
          onChange={handleTimeChange2}
          value={time2}
          size="small"
          timeInterval={5}
        />
      </Box>
      <div>{JSON.stringify(time3, null, 2)}</div>
      <Box width={300}>
        <InputField
          type="time"
          usecase="multi"
          onChange={handleTimeChange3}
          value={time3}
          minuteOptions={['00', '15', '30', '45']}
        />
      </Box>
    </Box>
  );
};
