import {
  DropdownOption,
  InputGroup,
  InputGroupArrow,
  InputGroupButton,
  InputGroupDropdown,
  InputGroupSearch,
  InputGroupTextField,
} from '@amxis/design-system';
import { Box } from '@mui/material';
import { useState } from 'react';

const options = [
  {
    value: 'title',
    label: '제목',
  },
  {
    value: 'name',
    label: '작성자',
  },
];

const translateOptions = [
  {
    value: 'kr',
    label: '한국어',
  },
  {
    value: 'en',
    label: '영어',
  },
];

export const SampleInputGroup = () => {
  const [dataSearch, setDataSearch] = useState<{ field: DropdownOption | null; keyword?: string }>({
    field: null,
  });

  const [translateOption, setTranslateOption] = useState<{
    option1: DropdownOption | null;
    option2: DropdownOption | null;
  }>({ option1: null, option2: null });

  return (
    <Box display="flex" rowGap={5} flexDirection={'column'} >
      <InputGroup
        size="medium"
        render={(props) => (
          <>
            <InputGroupDropdown
              {...props}
              isFirst
              options={options ?? []}
              value={dataSearch.field}
              onChange={(_, data) => {
                setDataSearch((oldData) => {
                  return {
                    ...oldData,
                    field: data as DropdownOption,
                  };
                });
              }}
            />

            <InputGroupTextField
              {...props}
              isLast
              value={dataSearch.keyword}
              onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                setDataSearch((oldData) => {
                  return {
                    ...oldData,
                    keyword: event?.target?.value,
                  };
                });
              }}
            />
          </>
        )}
      />

      <InputGroup
        size="small"
        render={(props) => (
          <>
            <InputGroupDropdown
              {...props}
              isFirst
              options={translateOptions ?? []}
              value={translateOption.option1}
              onChange={(_, data) => {
                setTranslateOption((oldData) => {
                  return {
                    ...oldData,
                    option1: data as DropdownOption,
                  };
                });
              }}
            />
            <InputGroupArrow />
            <InputGroupDropdown
              {...props}
              options={translateOptions ?? []}
              value={translateOption.option2}
              onChange={(_, data) => {
                setTranslateOption((oldData) => {
                  return {
                    ...oldData,
                    option2: data as DropdownOption,
                  };
                });
              }}
            />

            <InputGroupButton {...props} isLast onClick={() => console.log('button clicked')}>
              번역
            </InputGroupButton>
          </>
        )}
      />
      <InputGroup
        size="small"
        render={(props) => (
          <>
            <InputGroupSearch options={[]} type={'search'} usecase={'text'} {...props} isFirst />
            <InputGroupTextField {...props} isLast readOnly value={'AMI팀'} />
          </>
        )}
      />
      <InputGroup
        size="small"
        render={(props) => (
          <>
            <InputGroupDropdown options={options} value={options[0]} {...props} isFirst readOnly />
            <InputGroupSearch<DropdownOption>
              options={[]}
              type={'search'}
              usecase={'text'}
              {...props}
              isLast
              inputWidth={209}
              placeholder="찾으실 단어를 입력해주세요"
            />
          </>
        )}
      />
      <InputGroup
        size="small"
        render={(props) => (
          <>
            <InputGroupDropdown options={[options]} {...props} isFirst />
            <InputGroupTextField {...props} disabled />
            <InputGroupButton
              {...props}
              isLast
              buttonLabel="Button"
              onClick={() => console.log('button clicked')}
            />
          </>
        )}
      />
    </Box>
  );
};
