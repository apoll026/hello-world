import { useState } from 'react';
import { Box, Typography, SxProps, Theme, useTheme } from '@mui/material';
import {
  DetailTableBox,
  DetailTableLine,
  FormItem,
  InputField,
  DropdownField,
  Chip,
  Switch,
  Counter,
  Label,
  Radio,
  RadioGroup,
  Checkbox,
  FileUploaderReadonly,
  DateRangePickerValueType,
  DetailTableDataCell,
  DetailTableHeaderCell,
  DetailTableRow,
} from '@amxis/design-system';
import { $semantic } from '@amxis/design-system/design-token';
import mergeSx from '@amxis/design-system/';
import { Dayjs } from 'dayjs';

const SAMPLE_DATA = [
  { label: 'sample1', value: 'sample1' },
  { label: 'sample2', value: 'sample2' },
];

export const SampleDetailTable = () => {
  const commonStyle: SxProps<Theme> = {
    display: 'flex',
    flexDirection: 'column',
    gap: '20px',
  };

  return (
    <Box padding="20px">
      <Box width="1216px" sx={commonStyle}>
        <Typography variant="h1">Sample Detail Table Box type</Typography>
        <SampleDetailTableBox />
      </Box>
      <Box width="800px" sx={commonStyle}>
        <Typography variant="h1">Sample Detail Table Line type</Typography>
        <SampleDetailTableLine />
      </Box>
      <Box width="800px" sx={commonStyle}>
        <Typography variant="h1">Sample Detail Table Line type with merged cell</Typography>
        <SampleDetailTableLineMergedCell />
      </Box>
      <Box width="1069px" sx={commonStyle}>
        <Typography variant="h1">Sample Detail Table Line type with merged header</Typography>
        <SampleDetailTableLineMergedHeader />
      </Box>
    </Box>
  );
};

const SampleDetailTableBox = () => {
  const [date, setDate] = useState<Dayjs | null>(null);
  const [dates, setDates] = useState<DateRangePickerValueType>([]);
  const [chip1, setChip1] = useState<boolean>(false);
  const [chip2, setChip2] = useState<boolean>(false);
  const [chip3, setChip3] = useState<boolean>(false);
  const [chip4, setChip4] = useState<boolean>(false);

  const rowStyle = {
    display: 'grid',
    gridAutoColumns: 'minmax(0, 1fr)',
    gridAutoFlow: 'column',
    columnGap: '24px',
  };

  return (
    <DetailTableBox>
      <Box sx={{ ...rowStyle }}>
        <FormItem
          label="검색입력"
          required={true}
          render={({ status }) => (
            <InputField
              placeholder="입력하세요"
              size="medium"
              status={status}
              type="search"
              fullWidth={true}
              options={SAMPLE_DATA}
              usecase="text"
            />
          )}
        />
        <FormItem
          label="검색입력"
          required={true}
          render={() => (
            <DropdownField
              placeholder="선택하세요"
              options={SAMPLE_DATA}
              fullWidth={true}
              size="medium"
            />
          )}
        />

        <FormItem
          label="선택입력비활성"
          required={false}
          render={() => (
            <DropdownField
              placeholder="Selected Option"
              options={SAMPLE_DATA}
              disabled={true}
              fullWidth={true}
              size="medium"
            />
          )}
        />
      </Box>
      <Box sx={{ ...rowStyle }}>
        <FormItem
          label="기본정보입력"
          helperText="Helper Text"
          flex={1}
          required={true}
          render={() => (
            <InputField type="text" size="medium" placeholder="입력하세요" fullWidth={true} />
          )}
        />
      </Box>
      <Box sx={{ ...rowStyle }}>
        <FormItem
          flex={1}
          label="기간"
          required={true}
          render={() => (
            <InputField
              size="medium"
              status="default"
              type="date-range"
              sx={{ height: '32px', width: '100%', boxSizing: 'border-box' }}
              value={dates}
              onChange={(dates: DateRangePickerValueType) => {
                setDates(dates);
              }}
            />
          )}
        />
        <FormItem
          flex={1}
          label="날짜"
          required={true}
          render={() => (
            <InputField
              size="medium"
              status="default"
              type="date"
              value={date}
              onChange={(date: Dayjs | null) => {
                setDate(date);
              }}
            />
          )}
        />
        <FormItem
          flex={1}
          label="Counter"
          required={true}
          render={() => <Counter size="medium" />}
        />
      </Box>
      <Box sx={{ ...rowStyle }}>
        <FormItem
          label="Switch선택"
          required={true}
          render={() => (
            <Box height="32px" display="flex" alignItems="center">
              <Switch type="basic" />
            </Box>
          )}
        />
        <FormItem
          label="Chip선택"
          required={true}
          render={() => (
            <Box display="flex" alignItems="center" gap="4px" flexWrap="wrap">
              <Chip
                type="choice"
                chipText="Chip"
                size="medium"
                selected={chip1}
                onClick={() => setChip1(!chip1)}
              />
              <Chip
                type="choice"
                chipText="Chip"
                size="medium"
                selected={chip2}
                onClick={() => setChip2(!chip2)}
              />
              <Chip
                type="choice"
                chipText="Chip"
                size="medium"
                selected={chip3}
                onClick={() => setChip3(!chip3)}
              />
              <Chip
                type="choice"
                chipText="Chip"
                size="medium"
                selected={chip4}
                onClick={() => setChip4(!chip4)}
              />
            </Box>
          )}
        />
        <FormItem
          label="입력오류"
          required={true}
          render={() => (
            <InputField
              placeholder="입력하세요"
              size="medium"
              status="default"
              type="text"
              fullWidth={true}
            />
          )}
        />
      </Box>
    </DetailTableBox>
  );
};

const SampleDetailTableLine = () => {
  const [checkbox1, setCheckbox1] = useState<boolean>(false);
  const [checkbox2, setCheckbox2] = useState<boolean>(false);
  const [checkbox3, setCheckbox3] = useState<boolean>(false);
  const [checkbox4, setCheckbox4] = useState<boolean>(false);
  const [checkbox5, setCheckbox5] = useState<boolean>(false);
  const [value, setValue] = useState<string>('option1');

  const handleOnChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setValue(event?.target.value);
  };

  return (
    <Box width="800px">
      <DetailTableLine>
        <DetailTableRow>
          <DetailTableHeaderCell>
            <Label labelText="Label" isRequired={false} />
          </DetailTableHeaderCell>
          <DetailTableDataCell colSpan={3}>
            <Typography variant="bodyBasic" py={'6px'}>
              데이터 텍스트 길이가 길어서 넘치는 경우, 데이터 텍스트 길이가 길어서 넘치는 경우,
              데이터 텍스트 길이가 길어서 넘치는 경우, 데이터 텍스트 길이가 길어서 넘치는 경우
            </Typography>
          </DetailTableDataCell>
        </DetailTableRow>
        <DetailTableRow>
          <DetailTableHeaderCell>
            <Label labelText="Label" isRequired={true} />
          </DetailTableHeaderCell>
          <DetailTableDataCell>
            <DropdownField size="medium" options={[]} fullWidth={true} placeholder="Placeholder" />
          </DetailTableDataCell>
          <DetailTableHeaderCell>
            <Label labelText="Label" isRequired={true} />
          </DetailTableHeaderCell>
          <DetailTableDataCell>
            <InputField
              placeholder="검색어 입력후 엔터"
              type="search"
              status="default"
              size="medium"
              fullWidth={true}
              usecase="text"
              options={[]}
            />
          </DetailTableDataCell>
        </DetailTableRow>
        <DetailTableRow>
          <DetailTableHeaderCell>
            <Label labelText="Label" isRequired={true} />
          </DetailTableHeaderCell>
          <DetailTableDataCell>
            <InputField
              placeholder="Placeholder"
              size="medium"
              textAlign="left"
              type="text"
              fullWidth={true}
            />
          </DetailTableDataCell>
          <DetailTableHeaderCell>
            <Label labelText="Label" isRequired={false} />
          </DetailTableHeaderCell>
          <DetailTableDataCell>
            <Typography variant="bodyBasic">결재규칙명</Typography>
          </DetailTableDataCell>
        </DetailTableRow>
        <DetailTableRow>
          <DetailTableHeaderCell>
            <Label labelText="Label" isRequired={false} />
          </DetailTableHeaderCell>
          <DetailTableDataCell colSpan={3}>
            <Box display="flex" alignItems="centers" gap="12px">
              <RadioGroup
                value={value}
                onChange={handleOnChange}
                sx={{
                  display: 'flex',
                  flexDirection: 'row',
                  gap: '12px',
                }}
              >
                <Radio labelText="선택옵션1" value="option1" />
                <Radio labelText="선택옵션2" value="option2" />
                <Radio labelText="선택옵션3" value="option3" />
              </RadioGroup>
            </Box>
          </DetailTableDataCell>
        </DetailTableRow>
        <DetailTableRow>
          <DetailTableHeaderCell>
            <Label labelText="Label" isRequired={false} />
          </DetailTableHeaderCell>
          <DetailTableDataCell>
            <Box display="flex" flexDirection="column" gap="12px" py="6px">
              <Checkbox
                labelText="Text"
                value="option1"
                name="option1"
                checked={checkbox1}
                onChange={(checked) => setCheckbox1(checked)}
              />
              <Checkbox
                labelText="Text"
                value="option2"
                name="option2"
                checked={checkbox2}
                onChange={(checked) => setCheckbox2(checked)}
              />
              <Checkbox
                labelText="Text"
                value="option3"
                name="option3"
                checked={checkbox3}
                onChange={(checked) => setCheckbox3(checked)}
              />
              <Checkbox
                labelText="Text"
                value="option4"
                name="option4"
                checked={checkbox4}
                onChange={(checked) => setCheckbox4(checked)}
              />
              <Checkbox
                labelText="Text"
                value="option5"
                name="option5"
                checked={checkbox5}
                onChange={(checked) => setCheckbox5(checked)}
              />
            </Box>
          </DetailTableDataCell>
          <DetailTableHeaderCell>
            <Label labelText="Label" isRequired={false} />
          </DetailTableHeaderCell>
          <DetailTableDataCell style={{ paddingTop: '2px', paddingBottom: '2px' }}>
            <InputField fullWidth type="textarea" textLimit limited={300} />
          </DetailTableDataCell>
        </DetailTableRow>
        <DetailTableRow>
          <DetailTableHeaderCell>
            <Label labelText="Label" isRequired={false} />
          </DetailTableHeaderCell>
          <DetailTableDataCell colSpan={3}>
            <FileUploaderReadonly
              selectedFiles={[
                { name: 'aaaaaaaaaaa.pdf', size: 12344, url: '' },
                { name: 'bbbbbbbbbbbb.pdf', size: 2345, url: '' },
                { name: 'cccccccccccc.pdf', size: 345636, url: '' },
                { name: 'dddddddddddddd.pdf', size: 234, url: '' },
              ]}
            />
          </DetailTableDataCell>
        </DetailTableRow>
      </DetailTableLine>
    </Box>
  );
};

const SampleDetailTableLineMergedCell = () => {
  const [value, setValue] = useState<string>('option1');

  const handleOnChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setValue(event?.target.value);
  };

  return (
    <Box width="800px">
      <DetailTableLine>
        <DetailTableRow>
          <DetailTableHeaderCell>
            <Label labelText="Label" isRequired={false} />
          </DetailTableHeaderCell>
          <DetailTableDataCell colSpan={3}>
            <Typography component="p" variant="bodyBasic" py="6px">
              데이터 텍스트 길이가 길어서 넘치는 경우, 데이터 텍스트 길이가 길어서 넘치는 경우,
              데이터 텍스트 길이가 길어서 넘치는 경우, 데이터 텍스트 길이가 길어서 넘치는 경우
            </Typography>
          </DetailTableDataCell>
        </DetailTableRow>
        <DetailTableRow>
          <DetailTableHeaderCell>
            <Label labelText="Label" isRequired={true} />
          </DetailTableHeaderCell>
          <DetailTableDataCell>
            <InputField
              placeholder="Placeholder"
              size="medium"
              textAlign="left"
              type="text"
              fullWidth={true}
            />
          </DetailTableDataCell>
          <DetailTableHeaderCell>
            <Label labelText="Label" isRequired={true} />
          </DetailTableHeaderCell>
          <DetailTableDataCell>
            <Typography variant="bodyBasic" py="6px">
              데이터 텍스트
            </Typography>
          </DetailTableDataCell>
        </DetailTableRow>
        <DetailTableRow>
          <DetailTableHeaderCell rowSpan={2}>
            <Label labelText="Label" isRequired={true} />
          </DetailTableHeaderCell>
          <DetailTableDataCell rowSpan={2} colSpan={1}>
            <InputField fullWidth type="textarea" textLimit limited={300} height={70} />
          </DetailTableDataCell>
          <DetailTableHeaderCell>
            <Label labelText="Label" isRequired={true} />
          </DetailTableHeaderCell>
          <DetailTableDataCell colSpan={1}>
            <InputField
              placeholder="Placeholder"
              size="medium"
              textAlign="left"
              type="text"
              fullWidth={true}
            />
          </DetailTableDataCell>
        </DetailTableRow>
        <DetailTableRow>
          <DetailTableHeaderCell>
            <Label labelText="Label" isRequired={true} />
          </DetailTableHeaderCell>
          <DetailTableDataCell colSpan={1}>
            <InputField
              placeholder="Placeholder"
              size="medium"
              textAlign="left"
              type="text"
              fullWidth={true}
            />
          </DetailTableDataCell>
        </DetailTableRow>
        <DetailTableRow>
          <DetailTableHeaderCell>
            <Label labelText="Label" isRequired={false} />
          </DetailTableHeaderCell>
          <DetailTableDataCell colSpan={3}>
            <Box display="flex" alignItems="centers" gap="12px">
              <RadioGroup
                value={value}
                onChange={handleOnChange}
                sx={{
                  display: 'flex',
                  flexDirection: 'row',
                  gap: '12px',
                }}
              >
                <Radio labelText="선택옵션1" value="option1" />
                <Radio labelText="선택옵션2" value="option2" />
                <Radio labelText="선택옵션3" value="option3" />
              </RadioGroup>
            </Box>
          </DetailTableDataCell>
        </DetailTableRow>
      </DetailTableLine>
    </Box>
  );
};

const SampleDetailTableLineMergedHeader = () => {
  const { palette } = useTheme();
  const [value, setValue] = useState<string>('option1');
  const { size } = $semantic.shared;
  const { size1 } = size.sizesCommon;
  const { commonTextBasic, commonBorderBasic } = palette.semantic.color;

  const handleOnChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setValue(event?.target.value);
  };

  return (
    <Box width="1069px">
      <DetailTableLine>
        <DetailTableRow>
          <DetailTableHeaderCell
            rowSpan={2}
            sx={{
              borderRight: `${size1}px solid ${commonBorderBasic}`,
            }}
          >
            <Label labelText="대 분류" isRequired={false} />
          </DetailTableHeaderCell>
          <DetailTableHeaderCell>
            <Label labelText="중 분류" isRequired={false} />
          </DetailTableHeaderCell>
          <DetailTableDataCell>
            <Typography py={`6px`} component="p" variant="bodyBasic" color={commonTextBasic}>
              데이터 텍스트 길이가 길어서 넘치는 경우, 데이터 텍스트 길이가 길어서 넘치는 경우,
              데이터 텍스트 길이가 길어서 넘치는 경우, 데이터 텍스트 길이가 길어서 넘치는 경우
            </Typography>
          </DetailTableDataCell>
        </DetailTableRow>
        <DetailTableRow>
          <DetailTableHeaderCell>
            <Label labelText="중 분류" isRequired={false} />
          </DetailTableHeaderCell>
          <DetailTableDataCell sx={{ paddingTop: 0, paddingBottom: 0 }}>
            <InputField
              placeholder="Placeholder"
              size="medium"
              textAlign="left"
              type="text"
              fullWidth={true}
            />
          </DetailTableDataCell>
        </DetailTableRow>
        <DetailTableRow>
          <DetailTableHeaderCell colSpan={2}>
            <Label labelText="Label" isRequired={false} />
          </DetailTableHeaderCell>
          <DetailTableDataCell>
            <Box display="flex" alignItems="centers" gap="12px">
              <RadioGroup
                value={value}
                onChange={handleOnChange}
                sx={{
                  display: 'flex',
                  flexDirection: 'row',
                  gap: '12px',
                }}
              >
                <Radio labelText="선택옵션1" value="option1" />
                <Radio labelText="선택옵션2" value="option2" />
                <Radio labelText="선택옵션3" value="option3" />
              </RadioGroup>
            </Box>
          </DetailTableDataCell>
        </DetailTableRow>
      </DetailTableLine>
    </Box>
  );
};
