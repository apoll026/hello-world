import { TagColorType } from '@amxis/design-system';

export type SampleGrid = {
  no: number;
  userId: string;
  empName: string;
  jtiNm: string;
  deptNm: string;
  link: string;
  gender: string;
  dotTag: string;
  tag: string;
  tagColor: TagColorType;
  age: number;
  number: string;
  buttonLabel: string;
  switchOn: boolean;
};

const sampleDotTag = ['green', 'yellow', 'red', 'grey', 'white'];
const sampleTagLabel = ['일정준수', '지연주의', '지연', '종료', '계획중'];
const sampleTagColor: TagColorType[] = ['confirmed', 'warning-minor', 'error', 'done', 'colorA'];

export const generateSampleData = (start = 0, pageSize = 10) => {
  const sampleData: SampleGrid[] = [];

  for (let i = 0; i < 250; i++) {
    const employee: SampleGrid = {
      no: i + 1,
      userId: `user${i}`,
      empName: `Employee ${i}`,
      gender: i % 2 === 0 ? 'male' : 'female',
      jtiNm: `직책이 엄청 길다 ${i} 이건 길어 엄청 길지 히히 되게 길지요?`,
      deptNm: `deptNm ${i}`,
      link: `http://gportalapp.lgensol.com/portal/main/portalMain.do`,
      dotTag: sampleDotTag[i % 5],
      tag: sampleTagLabel[i % 5],
      tagColor: sampleTagColor[i % 5],
      age: Math.floor(Math.random() * 100) + 1,
      number: Math.floor(Math.random() * 10000000000000).toLocaleString(),
      buttonLabel: `Button ${i + 1}`,
      switchOn: Number(Math.random()) >= 0.5,
    };
    sampleData.push(employee);
  }

  return sampleData.slice(start * pageSize, start * pageSize + pageSize);
};
