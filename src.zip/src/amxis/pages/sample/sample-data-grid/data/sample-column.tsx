import { $semantic } from '@amxis/design-system/design-token';
import {
  DataGridCellRadio,
  DataGridCellTooltip,
  DataGridCellEditableRenderer,
  DataGridCellLink,
  DataGridCellDotTag,
  ColDef,
  ICellRendererParams,
  DataGridCellHeaderRadio,
  DataGridCellTag,
  DataGridCellButton,
  DataGridCellSwitch,
} from '@amxis/design-system';
import {
  ControlConfirmIcon,
  FunctionCallIcon,
  FunctionSearchIcon,
} from '@amxis/design-system/icon';

export const sampleColumn1: ColDef[] = [
  {
    width: 30,
    sortable: false,
    resizable: false,
    lockPinned: true,
    pinned: 'left',
    headerComponent: () => <DataGridCellHeaderRadio />,
    cellRenderer: DataGridCellRadio,
  },
  {
    field: 'no',
    headerName: 'No',
    resizable: false,
    unSortIcon: false,
    width: 50,
    cellStyle: { textAlign: 'center' },
    lockPinned: true,
    pinned: 'left',
  },
  {
    field: 'userId',
    headerName: '아이디' as string,
    width: 100,
    tooltipComponent: DataGridCellTooltip,
    tooltipField: 'userId',
  },
  {
    field: 'empName',
    headerName: '이름',
    width: 100,
    tooltipComponent: DataGridCellTooltip,
    tooltipField: 'empName',
    editable: true,
    filter: 'agTextColumnFilter',
    headerComponentParams: {
      enableOption: true,
      isActiveOption: false,
      onOptionClicked: () => {
        alert('option clicked');
      },
    },
  },
  {
    field: 'age',
    headerName: '나이',
    // headerComponentParams: {
    //   enableOption: true,
    //   isActiveOption: ageOptionEnable,
    //   isActiveOption: false,
    //   onOptionClicked: () => {
    //   setAgeOptionEnable(!ageOptionEnable);
    //   alert('option clicked');
    // },
    width: 60,
  },
  {
    field: 'jtiNm',
    headerName: '직책/직급 호칭',
    width: 100,
    tooltipComponent: DataGridCellTooltip,
    tooltipField: 'jtiNm',
    editable: true,
  },
  {
    field: 'deptNm',
    headerName: '부서',
    editable: true,
    cellRenderer: (params: ICellRendererParams) => {
      return (
        <DataGridCellEditableRenderer
          {...params}
          startIcon={<FunctionSearchIcon appearance="lined" iconSize={16} />}
        />
      );
    },
    width: 100,
    tooltipComponent: DataGridCellTooltip,
    tooltipField: 'deptNm',
    filter: 'agTextColumnFilter',
  },
  {
    field: 'link',
    headerName: '링크텍스트',
    width: 120,
    cellStyle: { textAlign: 'center' },
    cellRenderer: (params: ICellRendererParams) => {
      return <DataGridCellLink url={`${params.data.link}`} target="_blank" value="링크텍스트" />;
    },
    sortable: false,
  },
  {
    field: 'gender',
    headerName: '성별' as string,
    width: 110,
    editable: true,
    cellEditor: 'agSelectCellEditor',
    cellEditorParams: {
      values: ['male', 'female'],
    },
    singleClickEdit: true,
  },
  {
    field: 'dotTag',
    headerName: 'Dot',
    width: 60,
    cellRenderer: (params: ICellRendererParams) => {
      return <DataGridCellDotTag {...params} value={params.value} />;
    },
  },
  {
    field: 'tag',
    headerName: '태그',
    width: 90,
    cellRenderer: (params: ICellRendererParams) => {
      return (
        <DataGridCellTag
          appearance="boxing"
          colorType={params.data.tagColor}
          children={params.data.tag}
        />
      );
    },
  },
  {
    field: 'button',
    headerName: '버튼',
    width: 100,
    cellRenderer: (params: ICellRendererParams) => {
      return (
        <DataGridCellButton
          buttonLabel={params.data.buttonLabel}
          onClick={() => {
            alert('[' + params.data.buttonLabel + '] clicked');
          }}
        />
      );
    },
    sortable: false,
  },
  {
    field: 'button',
    headerName: '버튼',
    width: 60,
    cellRenderer: () => {
      return (
        <DataGridCellButton
          iconComponent={<FunctionCallIcon appearance="filled" color="secondary" />}
        />
      );
    },
    sortable: false,
  },
  {
    field: 'button',
    headerName: '버튼',
    width: 110,
    cellRenderer: (params: ICellRendererParams) => {
      return (
        <DataGridCellButton
          buttonLabel={params.data.buttonLabel}
          iconComponent={<FunctionCallIcon appearance="filled" color="secondary" />}
        />
      );
    },
    sortable: false,
  },
  {
    field: 'number',
    headerName: '연봉(원)',
    width: 140,
    cellStyle: { textAlign: 'right' },
  },
  {
    field: 'switch',
    headerName: '스위치',
    width: 60,
    cellRenderer: (params: ICellRendererParams) => {
      return <DataGridCellSwitch checked={params.data.switchOn} />;
    },
    sortable: false,
  },
  {
    field: 'index',
    headerName: '비고',
    width: 80,
    cellStyle: { textAlign: 'center' },
    editable: true,
    cellEditorParams: {
      placeholder: 'Enter a value',
    },
    cellRenderer: (params: ICellRendererParams) => {
      return <DataGridCellEditableRenderer {...params} defaultValue="-" isCenter={true} />;
    },
    sortable: false,
  },
];

export const sampleColumn2: ColDef[] = [
  {
    width: 50,
    sortable: false,
    resizable: false,
    headerClass: 'checkbox',
    checkboxSelection: true,
    headerCheckboxSelection: true,
  },
  {
    headerName: 'No',
    resizable: false,
    unSortIcon: false,
    flex: 0.5,
    cellStyle: { textAlign: 'center' },
    cellRenderer: (params: ICellRendererParams) => {
      return (params.node.rowIndex ?? 0) + 1;
    },
  },
  {
    field: 'userId',
    headerName: '아이디',
    flex: 0.5,
    tooltipComponent: DataGridCellTooltip,
    tooltipField: 'userId',
  },
  {
    field: 'empName',
    headerName: '이름',
    flex: 0.5,
    tooltipComponent: DataGridCellTooltip,
    tooltipField: 'empName',
    editable: true,
    sortable: false,
    filter: 'agTextColumnFilter',
  },
  {
    field: 'deptNm',
    headerName: '부서',
    editable: true,
    cellRenderer: (params: ICellRendererParams) => {
      return (
        <DataGridCellEditableRenderer
          {...params}
          startIcon={<FunctionSearchIcon appearance="lined" iconSize={16} />}
        />
      );
    },
    flex: 0.7,
    tooltipComponent: DataGridCellTooltip,
    tooltipField: 'deptNm',
  },
  {
    field: 'dotTag',
    headerName: 'Dot',
    flex: 0.5,
    cellRenderer: (params: ICellRendererParams) => {
      return <DataGridCellDotTag {...params} value={params.value} />;
    },
  },
  {
    field: 'tag',
    headerName: '태그',
    flex: 0.5,
    cellRenderer: (params: ICellRendererParams) => {
      return (
        <DataGridCellTag
          appearance="boxing"
          colorType={params.data.tagColor}
          children={params.data.tag}
        />
      );
    },
  },
  {
    field: 'button',
    headerName: '버튼',
    width: 110,
    cellRenderer: (params: ICellRendererParams) => {
      return (
        <DataGridCellButton
          buttonLabel={params.data.buttonLabel}
          gridCellHeight={$semantic.shared.size.heightGridBasic}
          onClick={() => {
            alert('[' + params.data.buttonLabel + '] clicked');
          }}
        />
      );
    },
    sortable: false,
  },
  {
    field: 'button',
    headerName: '버튼',
    width: 60,
    cellRenderer: () => {
      return (
        <DataGridCellButton
          gridCellHeight={$semantic.shared.size.heightGridBasic}
          iconComponent={<ControlConfirmIcon size="small" color="secondary" />}
        />
      );
    },
    sortable: false,
  },
  {
    field: 'button',
    headerName: '버튼',
    width: 120,
    cellRenderer: (params: ICellRendererParams) => {
      return (
        <DataGridCellButton
          gridCellHeight={$semantic.shared.size.heightGridBasic}
          buttonLabel={params.data.buttonLabel}
          iconComponent={<FunctionCallIcon appearance="filled" color="secondary" />}
        />
      );
    },
    sortable: false,
  },
];

export const sampleColumnEn: ColDef[] = [
  {
    width: 50,
    sortable: false,
    resizable: false,
    headerClass: 'checkbox',
    checkboxSelection: true,
    headerCheckboxSelection: true,
  },
  {
    headerName: 'No',
    resizable: false,
    unSortIcon: false,
    flex: 0.5,
    cellStyle: { textAlign: 'center' },
    cellRenderer: (params: ICellRendererParams) => {
      return (params.node.rowIndex ?? 0) + 1;
    },
  },
  {
    field: 'userId',
    headerName: 'ID',
    flex: 0.5,
    tooltipComponent: DataGridCellTooltip,
    tooltipField: 'userId',
  },
  {
    field: 'empName',
    headerName: 'Name',
    flex: 0.5,
    tooltipComponent: DataGridCellTooltip,
    tooltipField: 'empName',
    editable: true,
    sortable: false,
    filter: 'agTextColumnFilter',
  },
  {
    field: 'deptNm',
    headerName: 'Department',
    editable: true,
    cellRenderer: (params: ICellRendererParams) => {
      return (
        <DataGridCellEditableRenderer
          {...params}
          startIcon={<FunctionSearchIcon appearance="lined" iconSize={16} />}
        />
      );
    },
    flex: 0.7,
    tooltipComponent: DataGridCellTooltip,
    tooltipField: 'deptNm',
  },
  {
    field: 'dotTag',
    headerName: 'Dot',
    flex: 0.5,
    cellRenderer: (params: ICellRendererParams) => {
      return <DataGridCellDotTag {...params} value={params.value} />;
    },
  },
  {
    field: 'tag',
    headerName: 'Tag',
    flex: 0.5,
    cellRenderer: (params: ICellRendererParams) => {
      return (
        <DataGridCellTag
          appearance="boxing"
          colorType={params.data.tagColor}
          children={params.data.tag}
        />
      );
    },
  },
  {
    field: 'button',
    headerName: 'Button',
    width: 110,
    cellRenderer: (params: ICellRendererParams) => {
      return (
        <DataGridCellButton
          buttonLabel={params.data.buttonLabel}
          gridCellHeight={$semantic.shared.size.heightGridBasic}
          onClick={() => {
            alert('[' + params.data.buttonLabel + '] clicked');
          }}
        />
      );
    },
    sortable: false,
  },
];
