import { AgGridReact } from 'ag-grid-react';
import { useRef, useState } from 'react';
import { SampleGrid, generateSampleData } from './data/sample-data.ts';

import { $semantic } from '@amxis/design-system/design-token';
import { Box, Divider } from '@mui/material';
import { DataGrid, GridDot } from '@amxis/design-system';
import { sampleColumn1, sampleColumn2 } from './data/sample-column.tsx';

export const GridSample = () => {
  // const [isKo, setIsKO] = useState(true); // 다국어 처리용
  const gridRef = useRef<AgGridReact<SampleGrid>>(null);
  const gridRef2 = useRef<AgGridReact<SampleGrid>>(null);

  const [rowData, setRowData] = useState<SampleGrid[]>(generateSampleData());
  const [pageSize, setPageSize] = useState<number>(10);
  const [currentPage, setCurrentPage] = useState(1);
  const onChangePageSize = (size: number) => {
    setPageSize(size);
    setCurrentPage(1);
    setRowData(generateSampleData(0, size));
  };
  const onChangePage = (page: number) => {
    const row = generateSampleData(page - 1, pageSize);
    setRowData(row);
    setCurrentPage(page);
  };

  const [rowData2, setRowData2] = useState<SampleGrid[]>(generateSampleData());
  const [pageSize2, setPageSize2] = useState<number>(10);
  const [currentPage2, setCurrentPage2] = useState(1);
  const onChangePageSize2 = (size: number) => {
    setPageSize2(size);
    setCurrentPage2(1);
    setRowData2(generateSampleData(0, size));
  };
  const onChangePage2 = (page: number) => {
    const row = generateSampleData(page - 1, pageSize2);
    setRowData2(row);
    setCurrentPage2(page);
  };

  return (
    <>
      <Divider sx={{ my: 2 }} />
      <Box width="80%">
        <DataGrid
          title="서브타이틀(h3)"
          hasTotalCountArea={false}
          pageSizeOptions={[
            {
              label: '10',
              value: '10',
            },
            {
              label: '15',
              value: '15',
            },
          ]}
          isPageSizeInput={false}
          infoText="Info Text (optional)"
          rowSelection="single"
          hasPaginationArea
          isHeaderSectionEnabled
          hasPageSizeArea
          animateRows
          totalCount={250}
          dotTagInfo={{
            dots: [
              { icon: <GridDot dotColor="green" dotSize={12} />, label: '일정준수' },
              { icon: <GridDot dotColor="yellow" dotSize={12} />, label: '지연주의' },
              { icon: <GridDot dotColor="red" dotSize={12} />, label: '지연' },
              { icon: <GridDot dotColor="grey" dotSize={12} />, label: '종료' },
              { icon: <GridDot dotColor="white" dotSize={12} />, label: '계획중' },
            ],
          }}
          headerButton={[
            { variant: 'download', onClick: () => {} },
            { variant: 'refresh', onClick: () => {} },
          ]}
          pagination
          rowHeight={$semantic.shared.size.heightGridAnalytical}
          singleClickEdit={false}
          currentPage={currentPage}
          onChangePage={onChangePage}
          gridRef={gridRef}
          pageSize={pageSize}
          onChangePageSize={onChangePageSize}
          rowData={rowData}
          columnDefs={sampleColumn1}
          sxOfWrapper={{ width: '987px' }}
        />
      </Box>
      <Divider sx={{ my: 2 }} />
      <Box width="80%">
        <DataGrid
          totalCount={250}
          currentPage={currentPage2}
          onChangePage={onChangePage2}
          gridRef={gridRef2}
          title={'서브타이틀(h3)'}
          isHeaderSectionEnabled={true}
          hasPageSizeArea={true}
          pageSize={pageSize2}
          singleClickEdit={true}
          stopEditingWhenCellsLoseFocus={true}
          infoText="Info Text (optional)"
          onChangePageSize={onChangePageSize2}
          dotTagInfo={{
            dots: [
              { icon: <GridDot dotColor="green" dotSize={12} />, label: '일정준수' },
              { icon: <GridDot dotColor="yellow" dotSize={12} />, label: '지연주의' },
              { icon: <GridDot dotColor="red" dotSize={12} />, label: '지연' },
              { icon: <GridDot dotColor="grey" dotSize={12} />, label: '종료' },
              { icon: <GridDot dotColor="white" dotSize={12} />, label: '계획중' },
            ],
          }}
          headerButton={[
            { variant: 'upload', onClick: () => {} },
            { variant: 'refresh', onClick: () => {} },
          ]}
          hasPaginationArea={true}
          paginationButtonType={'simple'}
          rowData={rowData2}
          columnDefs={sampleColumn2}
          rowSelection={'multiple'}
          animateRows={true}
          sxOfWrapper={{ width: '900px' }}
        />
      </Box>
    </>
  );
};
