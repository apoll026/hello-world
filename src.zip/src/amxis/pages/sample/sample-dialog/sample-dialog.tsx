import { useState } from 'react';
import { Box, Typography } from '@mui/material';
import {
  Dialog,
  Button,
  RadioGroup,
  Radio,
  DialogNavigationSize,
  DialogNavigationType,
} from '@amxis/design-system';

export const SampleDialog = () => {
  const [value, setValue] = useState<DialogNavigationSize>(400);
  const [modalType, setModalType] = useState<DialogNavigationType>('modal');
  const [isOutBound, setIsOutBound] = useState(false);
  const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);
  const [anchorElChild, setAnchorElChild] = useState<HTMLButtonElement | null>(null);
  const isOpen = Boolean(anchorEl);
  const isOpenChild = Boolean(anchorElChild);

  const openDialog = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
    if (window.innerHeight - event.currentTarget.getBoundingClientRect().bottom < 200) {
      setIsOutBound(true);
      return;
    }
    setIsOutBound(false);
  };

  const closeDialog = () => {
    setAnchorEl(null);
  };

  const handleOnChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setValue(event?.target.value as unknown as DialogNavigationSize);
  };

  const handleChangeModalType = (event: React.ChangeEvent<HTMLInputElement>) => {
    setModalType(event?.target.value as unknown as DialogNavigationType);
  };

  const openChildDialog = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorElChild(event.currentTarget);
    if (window.innerHeight - event.currentTarget.getBoundingClientRect().bottom < 200) {
      setIsOutBound(true);
      return;
    }
    setIsOutBound(false);
  };

  const closeChildDialog = () => {
    setAnchorElChild(null);
  };

  return (
    <Box padding="20px" display="flex" flexDirection="column" gap="20px" alignItems="flex-start">
      <Typography variant="h1">Basic Nested Modal</Typography>
      <Box display="flex" alignItems="center" gap="20px">
        <Typography variant="h3">Select modal sizes: </Typography>
        <RadioGroup
          value={value}
          onChange={handleOnChange}
          sx={{
            display: 'flex',
            flexDirection: 'row',
            gap: '12px',
          }}
        >
          <Radio labelText="400" value={400} />
          <Radio labelText="600" value={600} />
          <Radio labelText="800" value={800} />
          <Radio labelText="1000" value={1000} />
          <Radio labelText="1200" value={1200} />
          <Radio labelText="1400" value={1400} />
          <Radio labelText="1600" value={1600} />
        </RadioGroup>
      </Box>
      <Box display="flex" alignItems="center" gap="20px">
        <Typography variant="h3">Select modal types: </Typography>
        <RadioGroup
          value={modalType}
          onChange={handleChangeModalType}
          sx={{
            display: 'flex',
            flexDirection: 'row',
            gap: '12px',
          }}
        >
          <Radio labelText="Modal" value="modal" />
          <Radio labelText="Modaless" value="modaless" />
        </RadioGroup>
      </Box>
      <Box>
        <Button onClick={openDialog}>Open Dialog</Button>
        <Dialog
          position="basic"
          type={modalType}
          size={value}
          open={isOpen}
          isOutBound={isOutBound}
          customContentArea={
            <Box>
              <Typography variant="h3">Click this button to open nested dialog</Typography>
              <Button sx={{ marginY: '20px' }} onClick={openChildDialog}>
                Open Dialog
              </Button>
              <Dialog
                position="basic"
                type={modalType}
                size={800}
                open={isOpenChild}
                isOutBound={isOutBound}
                handleClose={closeChildDialog}
                contentArea="nested dialog"
              />
            </Box>
          }
          handleClose={closeDialog}
        />
      </Box>
    </Box>
  );
};
