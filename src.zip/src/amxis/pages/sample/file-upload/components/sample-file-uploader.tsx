import * as z from 'zod';
import {FileUploader} from '@/amxis/components/ui/file-uploader';
import {Controller, useForm} from 'react-hook-form';
import {zodResolver} from '@hookform/resolvers/zod';
import {Button, HelperText} from '@amxis/design-system';
import {useCommonDialogStore} from '@/amxis/stores/useCommonDialogStore.ts';
import {Box} from '@mui/material';
import {t} from 'i18next';
import {FileSaveResult} from '@/amxis/models/admin/FileInfo.ts';
import {v4 as uuidv4} from 'uuid';
import {getUploadPreSignedUrl} from '@/amxis/apis/common/FilePreSignedUrl.ts';
import axios from "axios";

const formSchema = z.object({
    files: z
        .array(z.instanceof(File))
        .min(
            1,
            String(t('common.alert.최소 1개 이상 파일이 필요합니다.', '최소 1개 이상 파일이 필요합니다.')),
        ),
});

type FormSchema = z.infer<typeof formSchema>;

type SampleFileUploaderProps = {
    variant?: React.ComponentProps<typeof FileUploader>['variant'];
};

function SampleFileUploader({variant = 'default'}: SampleFileUploaderProps) {
    const {openCommonDialog} = useCommonDialogStore();
    const {
        handleSubmit,
        control,
        formState: {errors},
    } = useForm<FormSchema>({
        resolver: zodResolver(formSchema),
        defaultValues: {
            files: [],
        },
    });

    const uploadFiles = async (files: File[] = []) => {

        try {
            if (files.length === 0) {
                return {
                    atchFileGrId: '',
                    fileSaveResult: FileSaveResult.NONE,
                };
            }
            const atchFileGrId = uuidv4();
            const atchFileTpCd: string = '';
            const fileSizeArr: number[] = [];
            const fileNameArr: String[] = [];
            const fileTypeArr: String[] = [];

            for (const idx in files) {
                fileSizeArr.push(files[idx].size);
                fileNameArr.push(files[idx].name);
                fileTypeArr.push(files[idx].type);
            }

            // preSignedUrl 발급 (upload 전용)
            const preSignedUrlResponse = await getUploadPreSignedUrl(atchFileGrId, fileSizeArr.join(','), fileNameArr.join(','), fileTypeArr.join(','), atchFileTpCd);

            if (preSignedUrlResponse) {
                for (const idx in preSignedUrlResponse) {

                    await axios.put(preSignedUrlResponse[idx].preSignedUrl + "", files[idx], {
                        headers: {
                            'Content-Type': files[idx].type
                        }
                    });
                }

            }

            return {
                atchFileGrId,
                fileSaveResult: FileSaveResult.SUCCESS,
            };
        } catch
            (e) {
            console.error(e);

            return {
                atchFileGrId: '',
                fileSaveResult: FileSaveResult.FAIL,
            };
        }
    };

    const onSubmit = handleSubmit((data) => {
        openCommonDialog({
            modalType: 'confirm',
            content: t('common.alert.파일 업로드 하시겠습니까?', '파일 업로드 하시겠습니까?'),
            onSubmit() {
                uploadFiles(data.files);
            },
        });
    });

    return (
        <form onSubmit={onSubmit}>
            <Controller
                control={control}
                name="files"
                render={({field: {value, onChange}}) => (
                    <FileUploader
                        variant={variant}
                        acceptFiles={['.png', '.jpg', '.xlsx', '.pdf']}
                        selectedFiles={value}
                        onFileChange={(files) => {
                            onChange(files);
                        }}
                    />
                )}
            />
            <Box mt="4px">
                <HelperText infoText={errors?.files?.message ?? ''} usecase="error"/>
            </Box>

            <Button type="submit" appearance="contained" priority="primary" sx={{mt: '10px'}}>
                {t('common.button.저장', '저장')}
            </Button>
        </form>

    );
}

export {SampleFileUploader};
