import { ContainerLayout } from '@/amxis/components/container-layout';
import { ContainerBox } from '../__components/container-box.tsx';
import { Box, Typography } from '@mui/material';
import { SamplePageTitle } from '../__components/sample-page-title.tsx';
import { DocumentContentH2 } from '../__components/document-content-h2.tsx';
import { SampleFileUploader } from './components/sample-file-uploader.tsx';
import { useTranslation } from 'react-i18next';
import { MyFileGrid } from '@/amxis/components/my-file-grid';
import FileUploaderDext5 from '@/amxis/components/ui/file-uploader/file-uploader-dext5.tsx';
import { useRef } from 'react';

function SampleFileUploadPage() {
  const { t } = useTranslation();
  const attachRef = useRef<any>(null);
  return (
    <ContainerBox>
      <ContainerLayout>
        <SamplePageTitle>{t('common.labael.파일첨부', '파일첨부')}</SamplePageTitle>
        <Box mt="48px">
          <DocumentContentH2 title="Dext Uploader" />
          <Typography>
            {t(
              'common.labael.isTst props를 통해 커스텀한 디버깅이 가능합니다.',
              'isTst props를 통해 커스텀한 디버깅이 가능합니다.'
            )}
          </Typography>
          <Box mt="24px">
            {
              <FileUploaderDext5
                isTst={true}
                initialGrId={'tst-gr-id'}
                initialFiles={[]}
                ref={attachRef}
              />
            }
          </Box>
        </Box>
        <Box mt="48px">
          <DocumentContentH2 title="Download" />
          <Box mt="24px">
            <MyFileGrid atchFileGrId="tst-gr-id" />
          </Box>
        </Box>
      </ContainerLayout>
    </ContainerBox>
  );
}

export { SampleFileUploadPage };
