import {
  Button,
  FloatingButton,
  Tab,
  TabDataProps,
  makeDeletedNewTabs,
  makeSelectedNewTabs,
} from '@amxis/design-system';
import { Box, Typography } from '@mui/material';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-quartz.css';
import 'slick-carousel/slick/slick-theme.css';
import 'slick-carousel/slick/slick.css';
import { ButtonSample } from '../sample-button/sample-button.tsx';
import { GridSample } from '../sample-data-grid/sample-grid.tsx';
import { SampleOptionList } from '../sample-option-list/sample-option-list.tsx';
import { useEffect, useState } from 'react';
import { SampleBoardList } from '../board-list-sample/sample-board-list.tsx';
import { ChartSample } from '../chart-sample/chart-sample.tsx';
import { SampleAccordion } from '../sample-accordion/sample-accordion.tsx';
import { SampleAvatar } from '../sample-avatar/sample-avatar.tsx';
import { SampleCard } from '../sample-card/sample-card.tsx';
import { SampleCheckbox } from '../sample-checkbox/sample-checkbox.tsx';
import { SampleCommentArea } from '../sample-comment-area/sample-comment-area.tsx';
import { SampleCounter } from '../sample-counter/sample-counter.tsx';
import { SampleDatePickerCalendar } from '../sample-date-picker-calendar/sample-date-picker-calendar.tsx';
import { SampleDetailTable } from '../sample-detail-table/sample-detail-table.tsx';
import { SampleDropdownField } from '../sample-dropdown-field/sample-dropdown-field.tsx';
import { SampleEngagementAction } from '../sample-engagement-action/sample-engagement-action.tsx';
import { SampleFileUploader } from '../sample-file-uploader/sample-file-uploader.tsx';
import { SampleHelperText } from '../sample-helper-text/sample-helper-text.tsx';
import { SampleIconArrow } from '../sample-icon/sample-icon-arrow.tsx';
import { SampleIconCommerce } from '../sample-icon/sample-icon-commerce.tsx';
import { SampleIconCommunication } from '../sample-icon/sample-icon-communication.tsx';
import { SampleIconControl } from '../sample-icon/sample-icon-control.tsx';
import { SampleIconDevice } from '../sample-icon/sample-icon-device.tsx';
import { SampleIconEdit } from '../sample-icon/sample-icon-edit.tsx';
import { SampleIconEmoji } from '../sample-icon/sample-icon-emoji.tsx';
import { SampleIconFile } from '../sample-icon/sample-icon-file.tsx';
import { SampleIconFunction } from '../sample-icon/sample-icon-function.tsx';
import { SampleIconKeyline } from '../sample-icon/sample-icon-keyline.tsx';
import { SampleIconList } from '../sample-icon/sample-icon-list.tsx';
import { SampleIconMedia } from '../sample-icon/sample-icon-media.tsx';
import { SampleIconMenu } from '../sample-icon/sample-icon-menu.tsx';
import { SampleIconMode } from '../sample-icon/sample-icon-mode.tsx';
import { SampleIconNotificationLayer } from '../sample-icon/sample-icon-notificationlayer.tsx';
import { SampleIconOther } from '../sample-icon/sample-icon-other.tsx';
import { SampleIconSecurity } from '../sample-icon/sample-icon-security.tsx';
import { SampleIconStatus } from '../sample-icon/sample-icon-status.tsx';
import { SampleIconUser } from '../sample-icon/sample-icon-user.tsx';
import { SampleIconWeather } from '../sample-icon/sample-icon-weather.tsx';
import { SampleImageLink } from '../sample-image-link/sample-image-link.tsx';
import { SampleInputField } from '../sample-input-field/sample-input-field.tsx';
import { SampleInputGroup } from '../sample-input-group/sample-input-group.tsx';
import { SampleLabel } from '../sample-label/sample-label.tsx';
import { SampleMessageBar } from '../sample-message-bar/sample-message-bar.tsx';
import { ProcessTabSample } from '../sample-process-tab/sample-process-tab.tsx';
import { SampleRadio } from '../sample-radio/sample-radio.tsx';
import { SampleSlider } from '../sample-slider/sample-slider.tsx';
import { SampleSwitch } from '../sample-switch/sample-switch.tsx';
import { SampleTag } from '../sample-tag/sample-tag.tsx';
import { SampleTooltip } from '../sample-tooltip/sample-tooltip.tsx';
import { SampleTree } from '../sample-tree/sample-tree.tsx';

import { SampleCarousel } from '../sample-carousel/sample-carousel.tsx';
import { SampleDescription } from '../sample-description/sample-description.tsx';
import { SampleDialog } from '../sample-dialog/sample-dialog.tsx';
import { SampleFormItem } from '../sample-form-item/sample-form-item.tsx';
import { SampleProgressIndicator } from '../sample-progress-indicator/sample-progress-indicator.tsx';
import { SampleTitleArea } from '../sample-title-area/sample-title-area.tsx';
import { SampleSearchArea } from '../sample-search-area/sample-search-area.tsx';
import { SamplePageTitle } from '../__components/sample-page-title.tsx';
import { ContainerLayout } from '@/amxis/components/container-layout';
import { ContainerBox } from '../__components/container-box.tsx';
import { DocumentContentH2 } from '../__components/document-content-h2.tsx';
import { sample } from 'lodash';
import { DocumentContentH3 } from '../__components/document-content-h3.tsx';
export const SampleMenu = () => {
  const [selectedButton, setSelectedButton] = useState(0);
  const handleButtonSelect = (id) => {
    setSelectedButton(id);
  };
  const IconTab = () => {
    const iconTabs: TabDataProps[] = [
      {
        id: 1,
        item: { tabName: 'Menu' },
        contents: <SampleIconMenu />,
      },
      {
        id: 2,
        item: { tabName: 'KeyLine' },
        contents: <SampleIconKeyline />,
      },
      {
        id: 3,
        item: { tabName: 'NotificationLayer' },
        contents: <SampleIconNotificationLayer />,
      },
      {
        id: 4,
        item: { tabName: 'User' },
        contents: <SampleIconUser />,
      },
      {
        id: 5,
        item: { tabName: 'Other' },
        contents: <SampleIconOther />,
      },
      {
        id: 6,
        item: { tabName: 'Emoji' },
        contents: <SampleIconEmoji />,
      },
      {
        id: 7,
        item: { tabName: 'Mode' },
        contents: <SampleIconMode />,
      },
      {
        id: 8,
        item: { tabName: 'Commerce' },
        contents: <SampleIconCommerce />,
      },
      {
        id: 9,
        item: { tabName: 'Device' },
        contents: <SampleIconDevice />,
      },
      {
        id: 10,
        item: { tabName: 'Status' },
        contents: <SampleIconStatus />,
      },
      {
        id: 11,
        item: { tabName: 'List' },
        contents: <SampleIconList />,
      },
      {
        id: 12,
        item: { tabName: 'Weather' },
        contents: <SampleIconWeather />,
      },
      {
        id: 13,
        item: { tabName: 'Security' },
        contents: <SampleIconSecurity />,
      },
      {
        id: 14,
        item: { tabName: 'Communication' },
        contents: <SampleIconCommunication />,
      },
      {
        id: 15,
        item: { tabName: 'Edit' },
        contents: <SampleIconEdit />,
      },
      {
        id: 16,
        item: { tabName: 'Media' },
        contents: <SampleIconMedia />,
      },
      {
        id: 17,
        item: { tabName: 'Function' },
        contents: <SampleIconFunction />,
      },
      {
        id: 18,
        item: { tabName: 'Control' },
        contents: <SampleIconControl />,
      },
      {
        id: 19,
        item: { tabName: 'Arrow' },
        contents: <SampleIconArrow />,
      },
      {
        id: 20,
        item: { tabName: 'File' },
        contents: <SampleIconFile />,
      },
    ];
    const [data, setData] = useState(iconTabs);
    const handleSelect = (selectingIndex: number) => {
      setData(makeSelectedNewTabs(data, selectingIndex));
    };

    const handleDelete = (deletingIndex: number) => {
      setData(makeDeletedNewTabs(data, deletingIndex));
    };
    return <Tab data={data} isTabInTab onSelect={handleSelect} onClose={handleDelete} />;
  };
  const [selectedComponents, setSelectedComponents] = useState<TabDataProps[]>([]);
  const sampleArr = [
    {
      id: 1,
      item: { tabName: 'EngagementAction' },
      contents: <SampleEngagementAction />,
    },
    {
      id: 2,
      item: { tabName: 'MessageBar' },
      contents: <SampleMessageBar />,
    },
    {
      id: 3,
      item: { tabName: 'Counter' },
      contents: <SampleCounter />,
    },
    {
      id: 4,
      item: { tabName: 'InputField' },
      contents: <SampleInputField />,
    },
    {
      id: 5,
      item: { tabName: 'DatePickerCalendar' },
      contents: <SampleDatePickerCalendar />,
    },
    {
      id: 6,
      item: { tabName: 'Icon' },
      contents: (
        <Box sx={{ overflowX: 'auto' }}>
          <IconTab />
        </Box>
      ),
    },
    {
      id: 7,
      item: { tabName: 'Grid' },
      contents: <GridSample />,
    },
    {
      id: 8,
      item: { tabName: 'Button' },
      contents: (
        <>
          <FloatingButton title="this is long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long long title" />
          <ButtonSample />
        </>
      ),
    },
    {
      id: 9,
      item: { tabName: 'OptionList' },
      contents: <SampleOptionList />,
    },
    {
      id: 10,
      item: { tabName: 'Slider' },
      contents: <SampleSlider />,
    },
    {
      id: 11,
      item: { tabName: 'ProcessTab' },
      contents: <ProcessTabSample />,
    },
    {
      id: 12,
      item: { tabName: 'Checkbox' },
      contents: <SampleCheckbox />,
    },
    {
      id: 13,
      item: { tabName: 'Radio' },
      contents: <SampleRadio />,
    },
    {
      id: 14,
      item: { tabName: 'Typography' },
      contents: (
        <>
          <Typography variant="h1">h1</Typography>
          <Typography variant="h2">h2</Typography>
          <Typography variant="h3">h3</Typography>
          <Typography variant="h4">h4</Typography>
          <Typography variant="h5">h5</Typography>
          <Typography variant="h6">h6</Typography>
          <Typography paragraph variant="bodyBasic">
            bodyBasic
          </Typography>
          <Typography paragraph variant="bodyBasicBold">
            bodyBasicBold
          </Typography>
          <Typography paragraph variant="bodyXlarge">
            bodyXlarge
          </Typography>
          <Typography paragraph variant="bodyXlargeBold">
            bodyXlargeBold
          </Typography>
          <Typography paragraph variant="bodyLarge">
            bodyLarge
          </Typography>
          <Typography paragraph variant="bodyLargeBold">
            bodyLargeBold
          </Typography>
          <Typography paragraph variant="bodySmall">
            bodySmall
          </Typography>
          <Typography paragraph variant="bodySmallBold">
            bodySmallBold
          </Typography>
          <Typography paragraph variant="bodyXsmall">
            bodyXsmall
          </Typography>
          <Typography paragraph variant="bodyXsmallBold">
            bodyXsmallBold
          </Typography>
          <Typography paragraph variant="headerArea1LevelMenu">
            headerArea1LevelMenu
          </Typography>
          <Typography paragraph variant="sysNameFull">
            sysNameFull
          </Typography>
          <Typography paragraph variant="headerAreaSysNameFull">
            headerAreaSysNameFull
          </Typography>
          <Typography paragraph variant="headerAreaUtilMenu">
            headerAreaUtilMenu
          </Typography>
          <Typography paragraph variant="leftArea1LevelMenu">
            leftArea1LevelMenu
          </Typography>
          <Typography paragraph variant="leftArea2LevelMenu">
            leftArea2LevelMenu
          </Typography>
          <Typography paragraph variant="leftArea2LevelMenuSelected">
            leftArea2LevelMenuSelected
          </Typography>
          <Typography paragraph variant="leftArea3LevelMenu">
            leftArea3LevelMenu
          </Typography>
          <Typography paragraph variant="leftArea3LevelMenuSelected">
            leftArea3LevelMenuSelected
          </Typography>
        </>
      ),
    },
    {
      id: 15,
      item: { tabName: 'BoardList' },
      contents: <SampleBoardList />,
    },
    {
      id: 16,
      item: { tabName: 'Chart' },
      contents: <ChartSample />,
    },
    {
      id: 17,
      item: { tabName: 'InputGroup' },
      contents: <SampleInputGroup />,
    },
    {
      id: 18,
      item: { tabName: 'DropdownField' },
      contents: <SampleDropdownField />,
    },
    {
      id: 19,
      item: { tabName: 'Label / Tooltip' },
      contents: (
        <>
          <SampleLabel />
          <SampleTooltip />
        </>
      ),
    },
    {
      id: 20,
      item: { tabName: 'Tag' },
      contents: <SampleTag />,
    },
    {
      id: 21,
      item: { tabName: 'Avatar' },
      contents: <SampleAvatar />,
    },
    {
      id: 22,
      item: { tabName: 'Card' },
      contents: <SampleCard />,
    },
    {
      id: 23,
      item: { tabName: 'Helper Text' },
      contents: <SampleHelperText />,
    },
    {
      id: 24,
      item: { tabName: 'Switch' },
      contents: <SampleSwitch />,
    },
    {
      id: 25,
      item: { tabName: 'File Uploader' },
      contents: <SampleFileUploader />,
    },
    {
      id: 26,
      item: { tabName: 'Comment Area' },
      contents: <SampleCommentArea />,
    },
    {
      id: 27,
      item: { tabName: 'Accordion' },
      contents: <SampleAccordion />,
    },
    {
      id: 28,
      item: { tabName: 'ImageLink' },
      contents: <SampleImageLink />,
    },
    {
      id: 29,
      item: { tabName: 'ProgressIndicator' },
      contents: <SampleProgressIndicator />,
    },
    {
      id: 30,
      item: { tabName: 'Detail Table' },
      contents: <SampleDetailTable />,
    },
    {
      id: 31,
      item: { tabName: 'Tree' },
      contents: <SampleTree />,
    },
    {
      id: 32,
      item: { tabName: 'Description' },
      contents: <SampleDescription />,
    },
    {
      id: 33,
      item: { tabName: 'Dialog' },
      contents: <SampleDialog />,
    },
    {
      id: 34,
      item: { tabName: 'Form Item' },
      contents: <SampleFormItem />,
    },
    {
      id: 35,
      item: { tabName: 'TitleArea' },
      contents: <SampleTitleArea />,
    },
    {
      id: 36,
      item: { tabName: 'Carousel' },
      contents: <SampleCarousel />,
    },
    {
      id: 37,
      item: { tabName: 'SearchArea' },
      contents: <SampleSearchArea />,
    },
  ];
  const Tabs: TabDataProps[] = [
    {
      id: 100,
      item: { tabName: 'UI' },
      contents: <>UI</>,
    },
    {
      id: 101,
      item: { tabName: 'Source' },
      contents: <>Source</>,
    },
  ];
  const [tab, setTab] = useState<TabDataProps[]>(Tabs);
  const handleTabSelect = (selectingIndex: number) => {
    setTab(makeSelectedNewTabs(tab, selectingIndex));
  };
  const updateUIContents = (newTab: TabDataProps) => {
    const updatedTabs = [
      {
        id: 100,
        item: { tabName: 'UI' },
        contents: newTab.contents,
      },
      // {
      //   id: 101,
      //   item: { tabName: 'Source' },
      //   contents: newTab.item.tabName,
      // }, 소스코드 미사용
    ];
    setTab(makeSelectedNewTabs(updatedTabs, 0));
  };
  useEffect(() => {
    setSelectedComponents(
      sampleArr.sort((a, b) => {
        if (a.item.tabName < b.item.tabName) {
          return -1;
        }
        if (a.item.tabName > b.item.tabName) {
          return 1;
        }
        return 0;
      })
    );
  }, []);
  useEffect(() => {
    const selectedComponent = selectedComponents.find(
      (component) => component.id === selectedButton
    );
    if (selectedComponent) {
      updateUIContents(selectedComponent);
      //updateSourceContents(selectedComponent.item.tabName);
    }
  }, [selectedButton]);
  return (
    <ContainerBox>
      <ContainerLayout>
        <SamplePageTitle>컴포넌트 샘플</SamplePageTitle>
        <Box mt="48px" />
        <DocumentContentH2 title="컴포넌트">
          <Box display="grid" gridTemplateColumns="repeat(10, 1fr)">
            {selectedComponents.map((component) => (
              <Button
                key={component.id}
                sx={{
                  margin: '5px',
                  svg: {
                    width: '20px',
                    height: '20px',
                  },
                }}
                onClick={() => handleButtonSelect(component.id)}
              >
                {component.item.tabName}
              </Button>
            ))}
          </Box>
        </DocumentContentH2>
        <Box mt="48px" />

        {selectedComponents.map((component) => {
          if (component.id === selectedButton) {
            return (
              <>
                <Box m="0 0 5px 0">
                  <DocumentContentH3 title={component.item.tabName}></DocumentContentH3>
                </Box>
                <Tab
                  data={tab}
                  onSelect={handleTabSelect}
                  onClose={() => {}}
                  variant="scrollable"
                  visibleScrollbar
                />
              </>
            );
          }
          return null;
        })}
      </ContainerLayout>
    </ContainerBox>
  );
};
