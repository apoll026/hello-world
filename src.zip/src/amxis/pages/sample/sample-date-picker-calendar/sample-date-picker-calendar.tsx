import { DatePickerCalendar, DateRangePickerValueType, InputField } from '@amxis/design-system';
import { Box, Typography } from '@mui/material';
import dayjs, { Dayjs } from 'dayjs';
import { useState } from 'react';

export const SampleDatePickerCalendar = () => {
  const [date, setDate] = useState<Dayjs | null>(null);
  const [dates, setDates] = useState<DateRangePickerValueType>([]);
  const [dates2, setDates2] = useState<DateRangePickerValueType>([]);
  const [month, setMonth] = useState<Dayjs | null>(null);
  const [year, setYear] = useState<Dayjs | null>(null);

  const [date2, setDate2] = useState<Dayjs | null>(null);
  const [dates3, setDates3] = useState<DateRangePickerValueType>([]);
  const [dates4, setDates4] = useState<DateRangePickerValueType>([]);
  const [month2, setMonth2] = useState<Dayjs | null>(null);
  const [year2, setYear2] = useState<Dayjs | null>(null);
  return (
    <Box>
      <Typography variant="h2">Elevation Type</Typography>
      <div>{JSON.stringify(date)}</div>
      <DatePickerCalendar
        elevation
        usecase="date"
        value={date}
        status="default"
        onChange={(date: Dayjs) => {
          console.log(date.toString());
          setDate(date);
        }}
      />
      <div>{JSON.stringify(dates, null, 2)}</div>
      <DatePickerCalendar
        elevation
        usecase="date-range-single"
        value={dates}
        status="default"
        onChange={(date: DateRangePickerValueType) => {
          console.log('onInputChange: ' + date[0]?.toString() + '-' + date[1]?.toString());
          setDates(date);
        }}
      />
      <div>{JSON.stringify(dates2, null, 2)}</div>
      <DatePickerCalendar
        elevation
        usecase="date-range-multi"
        value={dates2}
        status="default"
        onChange={(date: DateRangePickerValueType) => {
          console.log('onInputChange: ' + date[0]?.toString() + '-' + date[1]?.toString());
          setDates2(date);
        }}
      />
      <div>{JSON.stringify(month)}</div>
      <DatePickerCalendar
        elevation
        usecase="month"
        value={month}
        size="large"
        status="default"
        onChange={(date: Dayjs) => {
          console.log('onInputChange: ' + `${date.month() + 1}`);
          setMonth(date);
        }}
      />
      <div>{JSON.stringify(year)}</div>
      <DatePickerCalendar
        elevation
        usecase="year"
        value={year}
        size="large"
        status="default"
        onChange={(date: Dayjs) => {
          console.log('onInputChange: ' + date.year());
          setYear(date);
        }}
      />
      <Typography variant="h2">Embed Type</Typography>
      <div>{JSON.stringify(date2)}</div>
      <DatePickerCalendar
        value={date2}
        usecase="date"
        onChange={(date: Dayjs | null) => {
          console.log('onChange: ' + date?.toString());
          setDate2(date);
        }}
      />
      <div>{JSON.stringify(dates3, null, 2)}</div>
      <DatePickerCalendar
        value={dates3}
        usecase="date-range-single"
        onChange={(date: DateRangePickerValueType) => {
          console.log('onInputChange: ' + date[0]?.toString() + '-' + date[1]?.toString());
          setDates3(date);
        }}
      />
      <div>{JSON.stringify(dates4, null, 2)}</div>
      <DatePickerCalendar
        value={dates4}
        usecase="date-range-multi"
        onChange={(date: DateRangePickerValueType) => {
          console.log('onInputChange: ' + date[0]?.toString() + '-' + date[1]?.toString());
          setDates4(date);
        }}
      />
      <div>{JSON.stringify(month2)}</div>
      <DatePickerCalendar
        value={month2}
        usecase="month"
        onChange={(date: Dayjs) => {
          console.log('onInputChange: ' + `${date.month() + 1}`);
          setMonth2(date);
        }}
      />
      <div>{JSON.stringify(year2)}</div>
      <DatePickerCalendar
        value={year2}
        usecase="year"
        onChange={(date: Dayjs) => {
          console.log('onInputChange: ' + date.year());
          setYear2(date);
        }}
      />
      <Typography variant="h2">Input Field Date Picker</Typography>
      <InputField
        type="date"
        autoFocus
        size="large"
        value={null}
        status="default"
        onChange={(date: Dayjs | null) => console.log('onChange: ' + date?.toString())}
      />
      <Typography variant="h2">Input Field Date Range Picker</Typography>
      <InputField
        type="date-range"
        size="small"
        value={null}
        status="default"
        onChange={(date: DateRangePickerValueType) =>
          'onInputChange: ' + date[0]?.toString() + '-' + date[1]?.toString()
        }
      />
    </Box>
  );
};
