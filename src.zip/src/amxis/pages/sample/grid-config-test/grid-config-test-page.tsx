import React, { useRef, useEffect, useState, useMemo } from 'react';
import { Box, Typography, Button } from '@mui/material';
import IBSheetGrid, { IBSheetGridRef } from '@/amxis/components/ibsheet8/ibsheet-grid';
import { useGridConfigTestQuery } from './hooks/use-grid-config-test-query';
import { SheetOptions } from '@/amxis/models/common/Ibsheet';

const GridConfigTestPage = () => {
  const gridRef = useRef<IBSheetGridRef>(null);
  const [isGridReady, setIsGridReady] = useState(false);
  
  const { data: gridConfigData, isLoading, refetch } = useGridConfigTestQuery('EAS_AM000001', 'sheet1');

  const gridOptions = useMemo((): SheetOptions => {
    if (!gridConfigData?.cols || gridConfigData.cols.length === 0) {
      return {
        Cfg: {
          SearchMode: 2,
          Page: 10,
        },
        Events: {
          onRenderFirstFinish: () => {
            console.log('그리드 준비 완료');
            setIsGridReady(true);
          },
        },
        Cols: [
          { Header: '로딩중', Name: 'loading', Type: 'Text', Width: 200 }
        ],
      };
    }

    return {
      Cfg: {
        HeaderMerge: 3,
        SearchMode: 2,
        Page: 10,
        AutoFitColWidth: 'search|resize|init|colhidden|rowhidden',
        ...(gridConfigData.MainCol ? { MainCol: gridConfigData.MainCol } : {}),
      },
      Def: {
        Row: {
          CanFormula: true,
        },
      },
      Events: {
        onRenderFirstFinish: () => {
          console.log('그리드 준비 완료');
          setIsGridReady(true);
        },
        onRowSelect: (evtParam: any) => {
          console.log('행 선택:', evtParam);
        },
      },
      Cols: gridConfigData.cols,
    };
  }, [gridConfigData]);

  useEffect(() => {
    if (isGridReady && gridConfigData?.cols) {
      const sheet = gridRef.current?.getSheet();
      if (sheet) {
        const sampleData = Array.from({ length: 5 }, (_, index) => {
          const rowData: any = {};
          gridConfigData.cols.forEach((col) => {
            switch (col.Type?.toLowerCase()) {
              case 'int':
              case 'float':
                rowData[col.Name] = (index + 1) * 10;
                break;
              case 'date':
                rowData[col.Name] = new Date().toISOString().split('T')[0];
                break;
              case 'bool':
                rowData[col.Name] = index % 2 === 0 ? 1 : 0;
                break;
              default:
                rowData[col.Name] = `샘플데이터${index + 1}`;
            }
          });
          return rowData;
        });

        console.log('샘플 데이터 로드:', sampleData);
        sheet['sheet1'].loadSearchData(sampleData, 0);
      }
    }
  }, [isGridReady, gridConfigData]);

  const handleRefresh = async () => {
    console.log('새로고침 시작');
    await refetch();
  };

  const handleDebugInfo = () => {
    console.log('=== 그리드 설정 디버그 정보 ===');
    console.log('API 데이터:', gridConfigData);
    console.log('그리드 준비 상태:', isGridReady);
    
    const sheet = gridRef.current?.getSheet();
    if (sheet) {
      console.log('그리드 행 수:', sheet['sheet1']?.getRowCount?.() || 0);
      console.log('그리드 컬럼 정보:', sheet['sheet1']?.getCols?.() || []);
    }
  };

  if (isLoading) {
    return (
      <Box sx={{ p: 2 }}>
        <Typography>그리드 설정을 불러오는 중...</Typography>
      </Box>
    );
  }

  if (!gridConfigData?.cols) {
    return (
      <Box sx={{ p: 2 }}>
        <Typography color="error">
          그리드 설정을 불러올 수 없습니다. (PGM_ID: AM000001, GRID_ID: sheet1)
        </Typography>
        <Button onClick={handleRefresh} sx={{ mt: 1 }}>
          다시 시도
        </Button>
      </Box>
    );
  }

  return (
    <Box sx={{ p: 2 }}>
      <Typography variant="h4" sx={{ mb: 2 }}>
        그리드 설정 테스트 페이지
      </Typography>

      <Typography variant="h6" sx={{ mb: 1 }}>
        PGM_ID: AM000001, GRID_ID: sheet1
      </Typography>

      <Typography variant="body2" sx={{ mb: 2, color: 'text.secondary' }}>
        설정된 컬럼 수: {gridConfigData.cols.length}개
      </Typography>

      <Box sx={{ mb: 2 }}>
        <Button onClick={handleRefresh} sx={{ mr: 1 }}>
          새로고침
        </Button>
        <Button onClick={handleDebugInfo} variant="outlined">
          디버그 정보
        </Button>
      </Box>

      <IBSheetGrid
        ref={gridRef}
        id="sheet1"
        el="config-test-grid"
        options={gridOptions}
        title="설정 기반 그리드 테스트"
        isHeaderSectionEnabled={false}
        height="500px"
      />
    </Box>
  );
};

export default GridConfigTestPage;