import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { CommonRequest, CommonResponse, Method, ServiceName } from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';
import { IbSheetInitVo } from '@/amxis/pages/sample/sample-grid-manage/types/grid-manage.types.ts';

const mockGridConfigData: IbSheetInitVo = {
  cols: [
    {
      "Header": ['empId'],
      "Type": "Text",
      "Visible": 1,
      "Name": "empId",
      "Width": 60,
      "MinWidth": null,
      "CanEdit": 0,
      "AddEdit": null,
      "Format": null,
      "Align": "right",
      "Enum": null,
      "EnumKeys": null,
      "FormulaRow": null,
      "Required": 0,
    },
    {
      "Header": [
        "분류",
        "사장"
      ],
      "Type": "Text",
      "Visible": 1,
      "Name": "textColumn",
      "Width": 100,
      "MinWidth": null,
      "CanEdit": 0,
      "AddEdit": null,
      "Format": null,
      "Align": "left",
      "Enum": null,
      "EnumKeys": null,
      "FormulaRow": null,
      "Required": 1,
      "ColMerge": 1,
      "RowMerge": 1,
    },
    {
      "Header": [
        "분류",
        "사원"
      ],
      "Type": "Lines",
      "Visible": 1,
      "Name": "linesColumn",
      "Width": 200,
      "MinWidth": null,
      "CanEdit": 0,
      "AddEdit": null,
      "Format": null,
      "Align": "left",
      "Enum": null,
      "EnumKeys": null,
      "FormulaRow": null,
      "Required": 0,
      "ColMerge": 1,
      "RowMerge": 1,
    },
    {
      "Header": [
        "CEO",
        "CEO"
      ],
      "Type": "Int",
      "Visible": 1,
      "Name": "intColumn",
      "Width": 80,
      "MinWidth": null,
      "CanEdit": 0,
      "AddEdit": null,
      "Format": "#,##0",
      "Align": "right",
      "Enum": null,
      "EnumKeys": null,
      "FormulaRow": null,
      "Required": 0,
    },
    {
      "Header": [
        "전무"
      ],
      "Type": "Float",
      "Visible": 1,
      "Name": "floatColumn",
      "Width": 100,
      "MinWidth": null,
      "CanEdit": 0,
      "AddEdit": null,
      "Format": "#,##0.00",
      "Align": "right",
      "Enum": null,
      "EnumKeys": null,
      "FormulaRow": null,
      "Required": 0
    },
    {
      "Header": [
        "상무"
      ],
      "Type": "Date",
      "Visible": 1,
      "Name": "dateColumn",
      "Width": 100,
      "MinWidth": null,
      "CanEdit": 0,
      "AddEdit": null,
      "Format": "yyyy-MM-dd",
      "Align": "right",
      "Enum": null,
      "EnumKeys": null,
      "FormulaRow": null,
      "Required": 0
    },
    {
      "Header": [
        "이사"
      ],
      "Type": "Button",
      "Visible": 1,
      "Name": "buttonColumn",
      "Width": 80,
      "MinWidth": null,
      "CanEdit": 1,
      "AddEdit": null,
      "Format": "버튼",
      "Align": "center",
      "Enum": null,
      "EnumKeys": null,
      "FormulaRow": null,
      "Required": 0
    },
    {
      "Header": [
      ],
      "Type": "Enum",
      "Visible": 1,
      "Name": "enumColumn",
      "Width": 80,
      "MinWidth": null,
      "CanEdit": 1,
      "AddEdit": null,
      "Format": "버튼",
      "Align": "center",
      "Enum": "|CEO|담당|담당(예비)|사업본부장|사업부장",
      "EnumKeys": "|5|1|2|4|3",
      "FormulaRow": null,
      "Required": 0
    }
  ]
};

const fetchGridConfigMock = async (pgmId: string, gridId: string) => {
  await new Promise(resolve => setTimeout(resolve, 300));
  console.log('[Mock] Grid config 데이터 반환:', { pgmId, gridId });
  return mockGridConfigData;
};

const fetchGridConfigApi = async (pgmId: string, gridId: string) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/ibsheet/grid-configs/${pgmId}/${gridId}`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };
  const response: CommonResponse<IbSheetInitVo> = await callApi(request);

  if (response.successOrNot === 'Y') return response.data;
  throw new Error(response.statusCode);
};

const USE_MOCK_DATA = false;

export const useGridConfigTestQuery = (pgmId: string, gridId: string) => {
  return useReactQuery({
    queryKey: ['gridConfigTest', pgmId, gridId],
    queryFn: () => USE_MOCK_DATA ? fetchGridConfigMock(pgmId, gridId) : fetchGridConfigApi(pgmId, gridId),
    enabled: !!pgmId && !!gridId,
    staleTime: 5 * 60 * 1000, // 5분
  });
};