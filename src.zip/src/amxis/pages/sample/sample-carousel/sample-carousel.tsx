import { Carousel } from '@amxis/design-system';
import { Box, Divider, Typography } from '@mui/material';

const MOCK_CAROUSEL_DATA = [
  {
    id: 1,
    title: '카드 타이틀 1',
    description:
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eu diam vel felis pharetra sagittis. Fusce ultrices sodales eros id feugiat. Integer posuere ex sit amet lacus dapibus, sit amet venenatis nisl condimentum. Suspendisse quis sapien id ex dapibus commodo. Nullam condimentum ante a ligula aliquam luctus. Cras nec lobortis libero. In in neque tincidunt, ultrices urna nec, lacinia justo. Donec eget metus eu ex aliquet iaculis in at diam. Nulla eu justo eu est consequat sollicitudin. Sed mattis odio sed rutrum condimentum.',
    img: '/images/carousel-sample-1.jpg',
  },
  {
    id: 2,
    title: '카드 타이틀 2',
    description:
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eu diam vel felis pharetra sagittis. Fusce ultrices sodales eros id feugiat. Integer posuere ex sit amet lacus dapibus, sit amet venenatis nisl condimentum. Suspendisse quis sapien id ex dapibus commodo. Nullam condimentum ante a ligula aliquam luctus. Cras nec lobortis libero. In in neque tincidunt, ultrices urna nec, lacinia justo. Donec eget metus eu ex aliquet iaculis in at diam. Nulla eu justo eu est consequat sollicitudin. Sed mattis odio sed rutrum condimentum.',
    img: '/images/carousel-sample-2.jpg',
  },
  {
    id: 3,
    title: '카드 타이틀 3',
    description:
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eu diam vel felis pharetra sagittis. Fusce ultrices sodales eros id feugiat. Integer posuere ex sit amet lacus dapibus, sit amet venenatis nisl condimentum. Suspendisse quis sapien id ex dapibus commodo. Nullam condimentum ante a ligula aliquam luctus. Cras nec lobortis libero. In in neque tincidunt, ultrices urna nec, lacinia justo. Donec eget metus eu ex aliquet iaculis in at diam. Nulla eu justo eu est consequat sollicitudin. Sed mattis odio sed rutrum condimentum.',
    img: '/images/carousel-sample-3.jpg',
  },
  {
    id: 4,
    title: '카드 타이틀 4',
    description:
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eu diam vel felis pharetra sagittis. Fusce ultrices sodales eros id feugiat. Integer posuere ex sit amet lacus dapibus, sit amet venenatis nisl condimentum. Suspendisse quis sapien id ex dapibus commodo. Nullam condimentum ante a ligula aliquam luctus. Cras nec lobortis libero. In in neque tincidunt, ultrices urna nec, lacinia justo. Donec eget metus eu ex aliquet iaculis in at diam. Nulla eu justo eu est consequat sollicitudin. Sed mattis odio sed rutrum condimentum.',
    img: '/images/carousel-sample-4.jpg',
  },
  {
    id: 5,
    title: '카드 타이틀 5',
    description:
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eu diam vel felis pharetra sagittis. Fusce ultrices sodales eros id feugiat. Integer posuere ex sit amet lacus dapibus, sit amet venenatis nisl condimentum. Suspendisse quis sapien id ex dapibus commodo. Nullam condimentum ante a ligula aliquam luctus. Cras nec lobortis libero. In in neque tincidunt, ultrices urna nec, lacinia justo. Donec eget metus eu ex aliquet iaculis in at diam. Nulla eu justo eu est consequat sollicitudin. Sed mattis odio sed rutrum condimentum.',
    img: '/images/carousel-sample-5.jpg',
  },
  {
    id: 6,
    title: '카드 타이틀 6',
    description:
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eu diam vel felis pharetra sagittis. Fusce ultrices sodales eros id feugiat. Integer posuere ex sit amet lacus dapibus, sit amet venenatis nisl condimentum. Suspendisse quis sapien id ex dapibus commodo. Nullam condimentum ante a ligula aliquam luctus. Cras nec lobortis libero. In in neque tincidunt, ultrices urna nec, lacinia justo. Donec eget metus eu ex aliquet iaculis in at diam. Nulla eu justo eu est consequat sollicitudin. Sed mattis odio sed rutrum condimentum.',
    img: '/images/carousel-sample-6.jpg',
  },
  {
    id: 7,
    title: '카드 타이틀 7',
    description:
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eu diam vel felis pharetra sagittis. Fusce ultrices sodales eros id feugiat. Integer posuere ex sit amet lacus dapibus, sit amet venenatis nisl condimentum. Suspendisse quis sapien id ex dapibus commodo. Nullam condimentum ante a ligula aliquam luctus. Cras nec lobortis libero. In in neque tincidunt, ultrices urna nec, lacinia justo. Donec eget metus eu ex aliquet iaculis in at diam. Nulla eu justo eu est consequat sollicitudin. Sed mattis odio sed rutrum condimentum.',
    img: '/images/carousel-sample-7.jpg',
  },
];

export const SampleCarousel = () => {
  return (
    <Box my="24px">
      <Typography variant="h2">Carousel - Multiple</Typography>
      <Box width="800px" mx="auto">
        <Carousel
          data={MOCK_CAROUSEL_DATA}
          itemType="multiple"
          slidesToShow={3}
          slidesToScroll={3}
        />
      </Box>

      <Divider sx={{ my: 5 }} />
      <Typography variant="h2">Carousel - Single</Typography>
      <Box width="800px" mx="auto">
        <Carousel data={MOCK_CAROUSEL_DATA} />
      </Box>

      <Divider sx={{ my: 5 }} />
      <Typography variant="h2">Carousel - Full-Bleed</Typography>
      <Box width="800px" mx="auto">
        <Carousel data={MOCK_CAROUSEL_DATA} itemType="multiple" layout="full-bleed" />
      </Box>

      <Divider sx={{ my: 5 }} />
      <Typography variant="h2">Carousel - Number Indicator</Typography>
      <Box width="800px" mx="auto">
        <Carousel data={MOCK_CAROUSEL_DATA} playControl="number" />
      </Box>

      <Divider sx={{ my: 5 }} />
      <Typography variant="h2">Carousel - Cropped</Typography>
      <Box width="800px" mx="auto">
        <Carousel data={MOCK_CAROUSEL_DATA} isCropped />
      </Box>

      <Divider sx={{ my: 5 }} />
      <Typography variant="h2">Carousel - Is Uneven Sets Finite</Typography>
      <Box width="800px" mx="auto">
        <Carousel
          data={MOCK_CAROUSEL_DATA}
          isUnevenSetsFinite
          itemType="multiple"
          slidesToShow={3}
          slidesToScroll={1}
        />
      </Box>
    </Box>
  );
};
