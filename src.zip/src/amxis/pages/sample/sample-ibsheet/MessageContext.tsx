import { ShowingMessage } from '@/amxis/models/admin/Message.ts';
import React, { createContext, useContext, useState } from 'react';

type MessageContextType = {
  selectedMessage: ShowingMessage | null;
  setSelectedMessage: (msg: ShowingMessage) => void;
};

const MessageContext = createContext<MessageContextType | undefined>(undefined);

export const MessageProvider = ({ children }: { children: React.ReactNode }) => {
  const [selectedMessage, setSelectedMessage] = useState<ShowingMessage | null>(null);

  return (
    <MessageContext.Provider value={{ selectedMessage, setSelectedMessage }}>
      {children}
    </MessageContext.Provider>
  );
};

export const useMessageContext = () => {
  const context = useContext(MessageContext);
  if (!context) throw new Error('useMessageContext must be used within a MessageProvider');
  return context;
};
