import React, { useEffect, useRef } from 'react';
import { Button, SearchArea } from '@amxis/design-system';
import { Box, Grid } from '@mui/material';
import { ControlConfirmIcon } from '@amxis/design-system/icon';
import { ButtonGroup, Spacer } from '@/amxis/components/layout';
import IBSheetGrid, { IBSheetGridRef } from '@/amxis/components/ibsheet8/ibsheet-grid.tsx';
import { SheetOptions } from '@/amxis/models/common/Ibsheet.ts';
import { IBSheet8MessageModal } from '@/amxis/components/modals/common/IBSheet8MessageModal.tsx';
import { MessageProvider } from './MessageContext.tsx';
import { IBSheetColsMockSample, IBSheetTreeSampleData } from './sheetOption.ts';

const DataGridSampleMockPageInner = () => {
  const gridRef = useRef<IBSheetGridRef>(null);
  const modify = [...IBSheetColsMockSample, { Header: 'data5', Type: 'Text', RelWidth: 1 }];

  const sheetOptions: SheetOptions = {
    Cfg: {
      CustomScroll: 1,
      HeaderMerge: 4, //헤더 병합 기능
    },
    Def: {
      Row: { CanEdit: 1 },
    },

    Foot: {},

    Cols: modify,

    Events: {
      onRenderFirstFinish: function (evt) {
        evt.sheet.loadSearchData(IBSheetTreeSampleData);
      },
    },
  };

  useEffect(() => {
    console.log(modify);
  }, []);

  // 컴포넌트 unmount 시 React root 정리

  return (
    <>
      <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
        <IBSheet8MessageModal />
        <Box width="100%">
          <SearchArea
            searchButtonLabel="조회"
            conditions={
              <>
                <>
                  <Grid item xs={6}></Grid>
                  <Grid item xs={6}></Grid>
                </>
              </>
            }
          />
        </Box>
        <Spacer type="h" size="12" />
        <IBSheetGrid
          ref={gridRef}
          id="sheet1"
          el="sheet1-el"
          options={sheetOptions}
          data={[IBSheetTreeSampleData]}
          total={10}
          isHeaderSectionEnabled={true}
          title="테스트 그리드1"
          headerButton={[
            {
              variant: 'add',
              label: '행추가',
              onClick: () => function ga() {},
            },
            {
              variant: 'delete',
              label: '행삭제',
              onClick: () => function ga() {},
            },
            {
              label: '다운로드',
              variant: 'download',
              onClick: () => function ga() {},
            },
            {
              label: '새로고침',
              variant: 'refresh',
              onClick: () => function ga() {},
            },
          ]}
        />
        <Spacer type="h" size="4" />
        <ButtonGroup>
          <Button
            id="save"
            appearance="contained"
            priority="primary"
            size="medium"
            iconPosition="leading"
            iconComponent={<ControlConfirmIcon size="small" />}
            onClick={() => {
              console.log('저장');
            }}
          >
            저장
          </Button>

          <Button
            appearance="outlined"
            size="medium"
            onClick={() => {
              console.log('디버깅');
            }}
          >
            디버그 정보
          </Button>
        </ButtonGroup>
      </Box>
    </>
  );
};

const DataGridSampleMockPage = () => {
  return (
    <>
      <MessageProvider>
        <DataGridSampleMockPageInner />
      </MessageProvider>
    </>
  );
};
export default DataGridSampleMockPage;
