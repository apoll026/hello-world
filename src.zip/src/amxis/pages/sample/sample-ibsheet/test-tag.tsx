import { ThemeProvider } from '@/amxis/components/theme-provider';
import { DataGridCellTag } from '@amxis/design-system';

const TestTag = () => {
  return (
    <ThemeProvider>
      <DataGridCellTag appearance="boxing" colorType="error">
        삭제
      </DataGridCellTag>
    </ThemeProvider>
  );
};

export default TestTag;
