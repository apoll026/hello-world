export const IBSheetCols = [
  {
    Header: 'SID',
    Type: 'Text',
    Name: 'sId',
    Width: 60,
    AddEdit: 1,
    Visible: 0,
  },
  {
    Header: { HeaderCheck: 1 },
    Type: 'Bool',
    Name: 'sCheck',
    Width: 60,
    AddEdit: 1,
    NoChanged: true,
  },
  {
    Header: '상태',
    Type: 'Html',
    Name: 'sState',
    Width: 60,
  },
  {
    Header: 'Radio',
    Type: 'Bool',
    Name: 'radio1',
    BoolGroup: 1,
  },

  //데이터
  {
    Header: '회사',
    Type: 'Text',
    Name: 'sCompany',
    Width: 150,
    AddEdit: 1,
    TrueValue: 'Y',
  },
  {
    Header: '판매 국가',
    Type: 'Text',
    Name: 'sCountry',
    Width: 150,
    AddEdit: 1,
  },
  {
    Header: '판매 수량',
    Type: 'Int',
    Name: 'sSaleQuantity',
    Width: 100,
    AddEdit: 1,
  },
  {
    Header: '판매 증가량',
    Type: 'Int',
    Name: 'sSaleIncrease',
    Width: 100,
    AddEdit: 1,
    FormulaRow: 'Sum',
  },
  {
    Header: '가격',
    Type: 'Int',
    Name: 'sPrice',
    Format: '#,### \\원',
    Width: 180,
    AddEdit: 1,
  },
  {
    Header: '만족도',
    Type: 'Int',
    Required: 1,
    Name: 'sSatisfaction',
    Format: '# \\%',
    Width: 180,
    AddEdit: 1,
  },
  {
    Header: '코멘트',
    Type: 'Enum',
    Name: 'sComment',
    CanEdit: 1,
    Align: 'center',
    Enum: '|A|B|C|D',
    EnumKeys: '|01|02|03|04',
  },
];

export const IBSheetColsMockSample = [
  {
    Header: { HeaderCheck: 1 },
    Type: 'Bool',
    Width: 60,
    AddEdit: 1,
    NoChanged: true,
  },
  {
    Header: { Value: '체크', HeaderCheck: 1 },
    Type: 'Bool',
    Width: 60,
    AddEdit: 1,
    NoChanged: true,
  },

  { Header: ['treekey'], Type: 'Date', Name: 'treekey', Width: 150 },
  { Header: ['treekey', 'treekey'], Type: 'Int', Name: 'data1', Width: 150, FormulaRow: 'Sum' },
  { Header: ['data2', 'data2'], Type: 'Text', Name: 'data2', Width: 150 },
  { Header: ['data2', 'data3'], Type: 'Text', Name: 'data3', Width: 150 },
  { Header: 'data4', Type: 'Text', Name: 'data4', Width: 100, EditMask: '^\\d*$' },
  {
    Header: ['기타정보', '우편번호'],
    Name: 'sPostNo',
    Type: 'Text',
    Width: 120,
    EditMask: '^\\d*$',
    Size: 6,
    CustomFormat: 'PostNo',
  },
  { Header: ['기타정보', '주소'], Name: 'sAddr', Type: 'Text', Width: 80 },
  {
    Header: ['기타정보', '카드번호'],
    Name: 'sCard',
    Type: 'Text',
    Width: 250,
    Align: 'Left',
    EditMask: '^\\d*$',
    CustomFormat: '[General] ####-####-####-####|[ Amex ] ####-######-#####',
    Size: 16,
  },
];

export const IBSheetTreeSampleData = [
  {
    treekey: 'treekey',
    data1: 1000001,
    data2: 10000012,
    data3: 1000003,
    Items: [
      {
        treekey: 'depth1',
        data1: 1000004,
        data2: 10000015,
        data3: 1000006,
        Items: [
          {
            treekey: 'depth2',
            data1: 1000007,
            data2: 10000018,
            data3: 1000009,
            Items: [
              {
                treekey: 'depth3',
                data1: 100000,
                data2: 1000001,
                data3: 100000,
              },
            ],
          },
        ],
      },
    ],
  },

  {
    treekey: 'treekey',
    data1: 1000001,
    data2: 10000012,
    data3: 1000003,
    Items: [
      {
        treekey: 'depth1',
        data1: 1000004,
        data2: 10000015,
        data3: 1000006,
        Items: [
          {
            treekey: 'depth2',
            data1: 1000007,
            data2: 10000018,
            data3: 1000009,
            Items: [
              {
                treekey: 'depth3',
                data1: 100000,
                data2: 1000001,
                data3: 100000,
              },
            ],
          },
        ],
      },
      { treekey: 'depth1', data1: 1000004, data2: 10000015, data3: 1000006 },
    ],
  },
];
