export interface IbSheetColProperty {
  Header?: string; //칼럼이름
  Type?:
    | 'Text'
    | 'Lines'
    | 'Int'
    | 'Float'
    | 'Date'
    | 'Button'
    | 'Link'
    | 'Html'
    | 'Img'
    | 'Enum'
    | 'Radio'
    | 'Bool'
    | 'Pass'
    | 'File'
    | 'Drag';
  Visible?: number;
  Name?: string; //칼럼명
  Width?: number;
  MinWidth?; //최소 너비
  CanEdit?: number; // 0 readonly, 1 편집가능
  AddEdit?: number; // 추가행만 없으면 기존 행의 속성을 따라감
  Format?: string; //데이터 포맷
  Align?: 'left' | 'center' | 'right';
  Enum?: string; // code value
  EnumKeys?: string; // code
  FormulaRow?: string;
}
