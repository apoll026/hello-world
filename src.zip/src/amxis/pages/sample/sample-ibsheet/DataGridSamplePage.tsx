import React, { useCallback, useEffect, useRef, useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import {
  Button,
  DataGridCellTag,
  FormItem,
  InputField,
  SearchArea,
  useMessageBar,
} from '@amxis/design-system';
import { Box, Grid } from '@mui/material';
import { ControlConfirmIcon } from '@amxis/design-system/icon';
import { keepPreviousData } from '@tanstack/react-query';
import { Controller, useForm } from 'react-hook-form';
import { ButtonGroup, Spacer } from '@/amxis/components/layout';
import { useIBSheetSampleQuery } from '@/amxis/hooks/queries/sample/use-ibsheet--sample-query.ts';
import { createRoot } from 'react-dom/client';
import { ThemeProvider } from '@/amxis/components/theme-provider';
import { useCommonDialogStore } from '@/amxis/stores/useCommonDialogStore.ts';
import { useSaveIBSheetSampleDataMutate } from '@/amxis/hooks/queries/sample/use-ibsheet-sample-mutate.ts';
import { useTranslation } from 'react-i18next';
import { CrudCode } from '@/amxis/models/common/Edit.ts';
import IBSheetGrid, { IBSheetGridRef } from '@/amxis/components/ibsheet8/ibsheet-grid.tsx';
import {
  IBSheetSampleConditionVO,
  IBSheetSampleRequestVO,
} from '@/amxis/models/models/sample/Ibsheet-sample.ts';
import { SheetOptions } from '@/amxis/models/common/Ibsheet.ts';
import { useMessageModalStore } from '@/amxis/stores/useMessageModalStore.ts';
import { IBSheet8MessageModal } from '@/amxis/components/modals/common/IBSheet8MessageModal.tsx';
import { MessageProvider, useMessageContext } from './MessageContext.tsx';
import { useGridConfigTestQuery } from '@/amxis/pages/sample/grid-config-test/hooks/use-grid-config-test-query.ts';

const DataGridSamplePageInner = () => {
  const { selectedMessage } = useMessageContext();

  const [searchCondition, setSearchCondition] = useState<IBSheetSampleConditionVO>({
    sPriceFrom: '100',
    sPriceTo: '10000000',
    searchItem: '',
  });

  const { data: fetchedIBSheetSampleData, refetch } = useIBSheetSampleQuery(searchCondition, {
    placeholderData: keepPreviousData,
  });

  const gridRef = useRef<IBSheetGridRef>(null);
  const [sheetReady, setSheetReady] = useState(false);
  const { openCommonDialog } = useCommonDialogStore();
  const { mutate: saveIBSheetSampleData } = useSaveIBSheetSampleDataMutate();
  const { setMessageModalStateWhenModalOpen } = useMessageModalStore();
  const { showMessageBar } = useMessageBar();
  const { t } = useTranslation();

  // 행 상태를 저장하는 Map (rowId -> state)
  const rowStatesRef = useRef<Map<string, string>>(new Map());
  // React roots를 추적하는 Map
  const reactRootsRef = useRef<Map<string, any>>(new Map());

  const handleMessageCellClick = useCallback(() => {
    setMessageModalStateWhenModalOpen('', undefined, () => {});
  }, []);

  // 상태 태그를 렌더링하는 공통 함수
  const renderStateTag = (sheet: any, row: any, state: string) => {
    if (!sheet || !row) return;

    const cell = sheet.getCell(row, 'sState');
    if (!cell) return;

    const innerDiv = cell.querySelector('div');
    if (!innerDiv) return;

    const rowId = row.id;

    // 기존 React root 정리
    if (reactRootsRef.current.has(rowId)) {
      try {
        const existingRoot = reactRootsRef.current.get(rowId);
        existingRoot.unmount();
        reactRootsRef.current.delete(rowId);
      } catch (error) {
        console.warn('React root 정리 중 오류:', error);
      }
    }

    // DOM 정리
    innerDiv.innerHTML = '';

    // 새로운 마운트 포인트 생성
    const mountPoint = document.createElement('div');
    innerDiv.appendChild(mountPoint);

    try {
      const root = createRoot(mountPoint);
      reactRootsRef.current.set(rowId, root);

      let tagElement: JSX.Element | null = null;
      switch (state) {
        case CrudCode.CREATE:
          tagElement = (
            <ThemeProvider>
              <DataGridCellTag appearance="boxing" colorType="confirmed">
                추가
              </DataGridCellTag>
            </ThemeProvider>
          );
          break;
        case CrudCode.UPDATE:
          tagElement = (
            <ThemeProvider>
              <DataGridCellTag appearance="boxing" colorType="warning-minor">
                수정
              </DataGridCellTag>
            </ThemeProvider>
          );
          break;
        case CrudCode.DELETE:
          tagElement = (
            <ThemeProvider>
              <DataGridCellTag appearance="boxing" colorType="error">
                삭제
              </DataGridCellTag>
            </ThemeProvider>
          );
          break;
        default:
          // 기본 상태일 때는 태그를 표시하지 않음
          return;
      }

      if (tagElement) {
        root.render(tagElement);
      }
    } catch (error) {
      console.error('상태 태그 렌더링 오류:', error);
    }
  };

  // 특정 행의 상태 태그 제거
  const removeStateTag = (sheet: any, rowId: string) => {
    if (reactRootsRef.current.has(rowId)) {
      try {
        const root = reactRootsRef.current.get(rowId);
        root.unmount();
        reactRootsRef.current.delete(rowId);
      } catch (error) {
        console.warn('상태 태그 제거 중 오류:', error);
      }
    }

    rowStatesRef.current.delete(rowId);
  };

  // 모든 상태 태그를 다시 렌더링하는 함수
  const reRenderAllStateTags = (sheet: any) => {
    if (!sheet) return;

    // 기존 React roots 정리
    reactRootsRef.current.forEach((root, rowId) => {
      try {
        root.unmount();
      } catch (error) {
        console.warn(`React root 정리 오류 (rowId: ${rowId}):`, error);
      }
    });
    reactRootsRef.current.clear();

    // 상태가 있는 행들만 다시 렌더링
    rowStatesRef.current.forEach((state, rowId) => {
      try {
        const row = sheet.getRowById(rowId);
        if (row) {
          renderStateTag(sheet, row, state);
        }
      } catch (error) {
        console.warn(`행 ${rowId} 상태 태그 재렌더링 오류:`, error);
      }
    });
  };

  // 행 상태 설정 및 UI 업데이트
  const setRowState = (sheet: any, rowId: string, state: string) => {
    console.log('rowId', rowId);
    rowStatesRef.current.set(rowId, state);
    const row = sheet.getRowById(rowId);
    console.log('row', row);
    if (row) {
      renderStateTag(sheet, row, state);
    }
  };

  const addRowPage = (id: string) => {
    const sheet = gridRef.current?.getSheet();
    try {
      if (sheet) {
        const newRow = sheet[id].addRow({ next: sheet[id].getFirstRow() });
        const rowId = newRow.id;

        // 상태 저장 및 태그 렌더링
        setRowState(sheet[id], rowId, CrudCode.CREATE);

        console.log(`새 행 추가: ${rowId}`);
      } else {
        console.warn('시트를 찾을 수 없습니다.');
      }
    } catch (err) {
      console.error('시트 접근 실패:', err);
    }
  };

  const deleteRowPage = (id: string) => {
    try {
      const sheet = gridRef.current?.getSheet();
      if (sheet) {
        const rows = sheet[id].getRowsByChecked('sCheck');

        for (let i = 0; i < rows.length; i++) {
          const row = rows[i];
          const rowId = row.id;
          const isNewlyAdded = row.Added;

          if (isNewlyAdded) {
            // 새로 추가된 행은 완전히 삭제
            sheet[id].deleteRow({
              row: row,
              del: 1,
              visible: 0,
            });
            removeStateTag(sheet[id], rowId);
            console.log(`새 행 완전 삭제: ${rowId}`);
          } else {
            // 기존 행은 삭제 표시만
            sheet[id].deleteRow({
              row: row,
              del: 1,
              visible: 1,
            });
            setRowState(sheet[id], rowId, CrudCode.DELETE);
            console.log(`기존 행 삭제 표시: ${rowId}`);
          }
        }
      } else {
        console.warn('시트를 찾을 수 없습니다.');
      }
    } catch (err) {
      console.error('시트 접근 실패:', err);
    }
  };

  const reloadPage = (id: string) => {
    const sheet = gridRef.current?.getSheet();
    if (!sheet) {
      console.warn('시트를 찾을 수 없습니다.');
      return;
    }

    // 변경된 데이터가 있는지 확인
    const hasChanges = rowStatesRef.current.size > 0;

    if (hasChanges) {
      openCommonDialog({
        modalType: 'confirm',
        content: '초기화하시겠습니까?(입력하신 정보는 복구가 불가능합니다.)',
        onSubmit: () => {
          // 모든 React roots 정리
          reactRootsRef.current.forEach((root) => {
            try {
              root.unmount();
            } catch (error) {
              console.warn('React root 정리 오류:', error);
            }
          });
          reactRootsRef.current.clear();

          // 상태 초기화
          rowStatesRef.current.clear();

          // IBSheet의 모든 변경사항 취소하고 원본 데이터로 복원
          sheet[id].removeAll();

          // 원본 데이터로 다시 로드
          if (fetchedIBSheetSampleData?.list) {
            sheet[id].loadSearchData(fetchedIBSheetSampleData.list, 0);
          }

          showMessageBar({
            message: '초기화되었습니다.',
            usecase: 'success',
          });

          console.log('데이터 초기화 완료');
        },
        onClose: () => {
          return false;
        },
      });
    } else {
      openCommonDialog({
        modalType: 'alert',
        content: '변경된 내용이 없습니다.',
      });
    }
  };

  const handleSave = async () => {
    const sheet = gridRef.current?.getSheet();
    if (!sheet) {
      console.error('시트를 찾을 수 없습니다.');
      return;
    }

    const hasChanges = rowStatesRef.current.size > 0;

    if (!hasChanges) {
      openCommonDialog({
        modalType: 'alert',
        content: '변경된 내용이 없습니다.',
      });
      return;
    }
    // 변경된 데이터 파싱
    const saveDataList: IBSheetSampleRequestVO[] = [];

    // rowStatesRef에서 변경된 행들을 순회
    rowStatesRef.current.forEach((state, rowId) => {
      const row = sheet['sheet1'].getRowById(rowId);
      if (row) {
        // 가격 데이터 정리 (콤마, 원 문자 제거)
        const priceString = sheet['sheet1'].getString(row, 'sPrice') || '0';
        const cleanedPrice = priceString.replace(/[,원\s]/g, ''); // 콤마, '원', 공백 제거

        // 만족도 데이터 정리 (% 문자 제거)
        const satisfactionString = sheet['sheet1'].getString(row, 'sSatisfaction') || '0';
        const cleanedSatisfaction = satisfactionString.replace(/[%\s]/g, ''); // '%', 공백 제거

        const rowData: IBSheetSampleRequestVO = {
          sId: sheet['sheet1'].getString(row, 'sId') || '',
          sCompany: sheet['sheet1'].getString(row, 'sCompany') || '',
          sCountry: sheet['sheet1'].getString(row, 'sCountry') || '',
          sSaleQuantity: parseInt(sheet['sheet1'].getString(row, 'sSaleQuantity') || '0', 10) || 0,
          sSaleIncrease: parseInt(sheet['sheet1'].getString(row, 'sSaleIncrease') || '0', 10) || 0,
          sPrice: parseInt(cleanedPrice, 10) || 0,
          sSatisfaction: parseInt(cleanedSatisfaction, 10) || 0,
          sComment: sheet['sheet1'].getString(row, 'sComment') || '',
          sState: state, // CREATE, UPDATE, DELETE
          sColMsgCode: sheet['sheet1'].getString(row, 'sColMsgCode') || '',
          sColMsgCtnKR: sheet['sheet1'].getString(row, 'sColMsgCtnKR') || '',
          sColMsgCtnEN: sheet['sheet1'].getString(row, 'sColMsgCtnEN') || '',
        };
        saveDataList.push(rowData);
      }
    });

    console.log('저장할 데이터:', saveDataList);

    openCommonDialog({
      modalType: 'confirm',
      content: '저장하시겠습니까?',
      onSubmit: async () => {
        saveIBSheetSampleData(saveDataList, {
          onSuccess: async (response) => {
            if (response) {
              // 모든 React roots 정리
              reactRootsRef.current.forEach((root) => {
                try {
                  root.unmount();
                } catch (error) {
                  console.warn('React root 정리 오류:', error);
                }
              });
              reactRootsRef.current.clear();

              // 상태 초기화
              rowStatesRef.current.clear();

              showMessageBar({
                message: t('common.alert.저장되었습니다.', '저장되었습니다.'),
                usecase: 'success',
              });

              // 데이터 새로고침 후 IBSheet 갱신
              const refreshedData = await refetch();

              // IBSheet의 데이터를 완전히 새로고침
              const sheet = gridRef.current?.getSheet();
              if (sheet && refreshedData.data?.list) {
                sheet['sheet1'].removeAll();
                sheet['sheet1'].loadSearchData(refreshedData.data.list, 0);
                console.log('저장 후 데이터 갱신 완료');
              }
            }
          },
          onError: () => {
            showMessageBar({
              message: t('role.alert.저장에 실패하였습니다.', '저장에 실패하였습니다.'),
              usecase: 'error',
            });
            return false;
          },
        });
      },
      onClose: () => {
        return false;
      },
    });
  };

  const { data: gridConfigData, isLoading: isGridConfigLoading } = useGridConfigTestQuery(
    'EAS_AM000080',
    'sheet1'
  );

  const sheetOptions: SheetOptions = {
    Cfg: {
      CustomScroll: 1,
      InfoRowConfig: {
        Visible: false,
      },
      MainCol: gridConfigData?.MainCol,
      HeaderMerge: 3,
      IgnoreHeaderColMerge: 0,
      SearchProgress: 1,
    },
    Def: {
      Row: { CanEdit: 1 },
      FormulaRow: {
        // FormulaRow 설정 (row property)
        Spanned: true,
      },
    },

    // Cols: IBSheetCols || [],
    Cols: gridConfigData?.cols || [],

    Events: {
      onClick: function (evtParam: any) {
        if (evtParam.col == 'sColMsgCode') handleMessageCellClick();
      },
      onRowAdd: function (evtParam: any) {
        evtParam.row['sState'] = CrudCode.CREATE;
        console.log('행 추가 이벤트:', evtParam.row.id);
      },

      onAfterChange: function (paramObject: any) {
        console.log('데이터 변경 이벤트 발생');
        const sheet = paramObject.sheet;

        // Changed 상태의 행들을 찾아서 수정 태그 렌더링
        const rows = sheet.getRowsByStatus('Changed');
        for (let i = 0; i < rows.length; i++) {
          const row = rows[i];
          const rowId = row.id;

          // Added가 아니고 Delete 상태가 아닌 경우에만 수정 상태로 변경
          if (!row.Added && !row.Deleted && rowStatesRef.current.get(rowId) !== CrudCode.DELETE) {
            setRowState(sheet, rowId, CrudCode.UPDATE);
            console.log(`행 수정 상태 적용: ${rowId}`);
          }
        }
      },
      // 정렬 후 상태 태그 재렌더링
      onAfterSort: function (evtParam: any) {
        console.log('정렬 완료, 태그 재렌더링');
        const sheet = evtParam.sheet;
        setTimeout(() => {
          reRenderAllStateTags(sheet);
        }, 100);
      },

      onRenderFirstFinish: function () {
        console.log('초기 렌더링 완료');
        setSheetReady(true);
      },

      onRenderFinish: function (paramObject: any) {
        console.log('렌더링 완료');
        // 렌더링 완료 후에도 태그 재렌더링 (페이징 등의 경우 대비)
        const sheet = paramObject.sheet;
        setTimeout(() => {
          reRenderAllStateTags(sheet);
        }, 50);
      },
    },
  };

  useEffect(() => {
    if (selectedMessage && gridRef.current) {
      const sheet = gridRef.current?.getSheet();
      if (!sheet) return;
      const focusedRow = sheet['sheet1'].getFocusedRow(); // 현재 선택된 row 객체
      if (!focusedRow) return;
      // 기존 row 값을 가져오고, 덮어쓸 필드만 변경
      const newRowData = {
        ...focusedRow, // 기존 row 값 유지
        sColMsgCode: selectedMessage.msgCtn ?? '',
        sColMsgCtnKR: selectedMessage.msgTxtCtn1 ?? '',
        sColMsgCtnEN: selectedMessage.msgTxtCtn2 ?? '',
      };
      if (focusedRow.sState == 'C') {
        setRowState(sheet['sheet1'], focusedRow.id, CrudCode.CREATE);
      } else {
        setRowState(sheet['sheet1'], focusedRow.id, CrudCode.UPDATE);
      }
      sheet['sheet1'].setRowValue(focusedRow, newRowData);
    }
  }, [selectedMessage]);

  const { handleSubmit, control } = useForm<IBSheetSampleConditionVO>({
    defaultValues: {
      sPriceFrom: '-1',
      searchItem: '',
    },
  });

  const handleSearch = handleSubmit(async ({ searchItem }) => {
    // 검색 전 모든 상태 정리
    reactRootsRef.current.forEach((root) => {
      try {
        root.unmount();
      } catch (error) {
        console.warn('React root 정리 오류:', error);
      }
    });
    reactRootsRef.current.clear();
    rowStatesRef.current.clear();

    setSearchCondition({
      ...searchCondition,
      searchItem: searchItem || '',
    });
  });

  const addSubtotalWithMakeSubTotal = (sheetId: string) => {
    const sheet = gridRef.current?.getSheet();
    if (!sheet || !sheet[sheetId]) return;

    // 국가별 소계 + 전체 합계
    sheet[sheetId].makeSubTotal([
      {
        stdCol: 'sCompany',
        sumCols: 'sPrice', // 합계 컬럼
        position: 'bottom', // 각 그룹 하단에 표시
        color: '#E3F2FD', // 소계 행 배경색 (파란색)
        showCumulate: true, // 누계 표시
        mode: 0,
        sort: 'asc', // 자동 정렬
        captionCol: [
          {
            // E셀에 포뮬러 연산 동작
            col: 'sSatisfaction',
            val: function (fr) {
              const val = (fr.Row['sPrice'] + fr.Row['sPrice']) * 10;
              return val;
            },
          },
          {
            col: 'sComment',
            val: function (fr) {
              return '1,000,000'; // 숫자 데이터의 경우, 구분자를 붙여서 리턴해야함.
            },
          },
        ],
      },
    ]);
  };

  useEffect(() => {
    if (!sheetReady || !fetchedIBSheetSampleData?.list) return;
    const sheet = gridRef.current?.getSheet();
    if (sheet) {
      // 데이터 로드 전 상태 초기화
      reactRootsRef.current.forEach((root) => {
        try {
          root.unmount();
        } catch (error) {
          console.warn('React root 정리 오류:', error);
        }
      });
      reactRootsRef.current.clear();
      rowStatesRef.current.clear();

      sheet['sheet1'].loadSearchData(fetchedIBSheetSampleData.list, 0);
      console.log('데이터 로드 완료');

      //소계
      // setTimeout(() => {
      //   addSubtotalWithMakeSubTotal('sheet1');
      // }, 100);
    }
  }, [sheetReady, fetchedIBSheetSampleData]);

  // 컴포넌트 unmount 시 React root 정리
  useEffect(() => {
    return () => {
      reactRootsRef.current.forEach((root) => {
        try {
          root.unmount();
        } catch (error) {
          console.warn('컴포넌트 unmount 시 React root 정리 오류:', error);
        }
      });
      reactRootsRef.current.clear();
      rowStatesRef.current.clear();
    };
  }, []);

  const excelDownload = (id: string) => {
    try {
      const sheet = gridRef.current?.getSheet();
      if (sheet) {
        const param = {
          fileName: uuidv4() + '.xlsx',
          downCols: 'Visible',
          downRows: 'Visible',
        };
        sheet[id].down2Excel(param);
      } else {
        console.warn('시트를 찾을 수 없습니다.');
      }
    } catch (err) {
      console.error('시트 접근 실패:', err);
    }
  };

  return (
    <>
      <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
        <IBSheet8MessageModal />
        <Box width="100%">
          <SearchArea
            searchButtonLabel="조회"
            conditions={
              <>
                <>
                  <Grid item xs={6}></Grid>
                  <Grid item xs={6}>
                    <FormItem
                      label="조건2"
                      labelAlign="right"
                      render={() => (
                        <Controller
                          control={control}
                          name="searchItem"
                          render={({ field }) => (
                            <InputField
                              fullWidth
                              value={field.value}
                              onChange={field.onChange}
                              size="medium"
                            />
                          )}
                        />
                      )}
                    />
                  </Grid>
                </>
              </>
            }
            onSearch={handleSearch}
          />
        </Box>
        <Spacer type="h" size="12" />
        {isGridConfigLoading ? (
          <div>Loading grid configuration...</div>
        ) : (
          <IBSheetGrid
            ref={gridRef}
            id="sheet1"
            el="sheet1-el"
            options={sheetOptions}
            data={fetchedIBSheetSampleData?.list}
            total={fetchedIBSheetSampleData?.totalCount}
            isHeaderSectionEnabled={true}
            title="테스트 그리드1"
            headerButton={[
              {
                variant: 'add',
                label: '행추가',
                onClick: () => addRowPage('sheet1'),
              },
              {
                variant: 'delete',
                label: '행삭제',
                onClick: () => deleteRowPage('sheet1'),
              },
              {
                label: '다운로드',
                variant: 'download',
                onClick: () => excelDownload('sheet1'),
              },
              {
                label: '새로고침',
                variant: 'refresh',
                onClick: () => reloadPage('sheet1'),
              },
            ]}
          />
        )}
        <Spacer type="h" size="4" />
        <ButtonGroup>
          <Button
            id="save"
            appearance="contained"
            priority="primary"
            size="medium"
            iconPosition="leading"
            iconComponent={<ControlConfirmIcon size="small" />}
            onClick={() => {
              const sheet = gridRef.current?.getSheet();
              if (sheet) {
                console.log('전체 행 수:', sheet['sheet1'].getTotalRowCount());
                const changeData = JSON.parse(
                  sheet['sheet1'].getChangedData({
                    attrs: [
                      'sId',
                      'sCompany',
                      'sCountry',
                      'sSaleQuantity',
                      'sSaleIncrease',
                      'sPrice',
                      'sSatisfaction',
                      'sComment',
                      'sColMsgCode',
                      'sColMsgCtnKR',
                      'sColMsgCtnEN',
                    ],
                  })
                );

                console.log('IBSheet 변경 데이터:', changeData.Changes);
                console.log('사용자 정의 상태 맵:', Array.from(rowStatesRef.current.entries()));
                void handleSave();
              }
            }}
          >
            저장
          </Button>

          <Button
            appearance="outlined"
            size="medium"
            onClick={() => {
              console.log('dfdf');
              const sheet = gridRef.current?.getSheet();
              if (sheet) {
                console.log('=== 디버깅 정보 ===');
                console.log('전체 행 수:', sheet['sheet1'].getTotalRowCount());
                console.log('데이터 행:', sheet['sheet1'].getDataRows().length);
                console.log('변경된 상태 맵:', Array.from(rowStatesRef.current.entries()));
                console.log('활성 React roots:', Array.from(reactRootsRef.current.keys()));

                // 변경된 행들의 상태 확인
                const changedRows = sheet['sheet1'].getRowsByStatus('Changed');
                console.log('IBSheet Changed 행들:', changedRows.length);

                const addedRows = sheet['sheet1'].getRowsByStatus('Added');
                console.log('IBSheet Added 행들:', addedRows.length);

                const deletedRows = sheet['sheet1'].getRowsByStatus('Deleted');
                console.log('IBSheet Deleted 행들:', deletedRows.length);

                // 모든 행 데이터 출력
                const allRowsData = sheet['sheet1'].getDataRows();
                console.log(allRowsData);
                console.log('모든 행 데이터:');
                allRowsData.forEach((row: any, index: number) => {
                  const rowState = rowStatesRef.current.get(row.id);
                  const priceString = sheet['sheet1'].getString(row, 'sPrice') || '0';
                  const cleanedPrice = priceString.replace(/[,원\s]/g, ''); // 콤마, '원', 공백 제거

                  console.log(`행 ${index}:`, {
                    id: row.id,
                    sCompany: sheet['sheet1'].getString(row, 'sCompany'),
                    sCountry: sheet['sheet1'].getString(row, 'sCountry'),
                    sPrice: priceString, // 원본 표시값
                    sPriceClean: cleanedPrice, // 정리된 값
                    sPriceParsed: parseInt(cleanedPrice, 10) || 0, // 파싱된 숫자
                    sColMsgCode: sheet['sheet1'].getString(row, 'sColMsgCode'),
                    sColMsgCtnKR: sheet['sheet1'].getString(row, 'sColMsgCtnKR'),
                    sColMsgCtnEN: sheet['sheet1'].getString(row, 'sColMsgCtnEN'),

                    Added: row.Added,
                    Changed: row.Changed,
                    Deleted: row.Deleted,
                    CustomState: rowState,
                    sComment: sheet['sheet1'].getString(row, 'sComment'),
                  });
                });
              }
            }}
          >
            디버그 정보
          </Button>
        </ButtonGroup>
      </Box>
    </>
  );
};

const DataGridSamplePage = () => {
  return (
    <>
      <MessageProvider>
        <DataGridSamplePageInner />
      </MessageProvider>
    </>
  );
};
export default DataGridSamplePage;
