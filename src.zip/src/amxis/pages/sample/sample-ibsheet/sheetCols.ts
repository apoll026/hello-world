export interface IbSheetColumns {
  pgmId: string;
  gridId: string;
  columnId?: string;
  columnMsgCd?: string;
  description?: string;
  display?: boolean;
  order?: number;
  readonly?: boolean;
  align?: 'left' | 'center' | 'right';
  dataType?:
    | 'Text'
    | 'Lines'
    | 'Int'
    | 'Float'
    | 'Date'
    | 'Button'
    | 'Link'
    | 'Html'
    | 'Img'
    | 'Enum'
    | 'Radio'
    | 'Bool'
    | 'Pass'
    | 'File'
    | 'Drag';
  format?: string;
  isRequired?: string;
  comboCd?: string;
  width?: string;
  isMergeYn?: boolean;
  treeKeyYn?: boolean;
  etc?: string;
}
