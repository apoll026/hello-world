import { SheetOptions } from '@/amxis/models/common/Ibsheet';

export const createMenuGridOptions = (
  onRowSelect: (menu: any) => void,
  onRenderFirstFinish?: () => void,
  reRenderAllStateTags?: (sheet: any) => void,
): SheetOptions => ({
  Cfg: {
    SearchMode: 2,
    HeaderCheck: 1,
    MessageWidth: 300,
    InfoRowConfig: {
      Visible: false,
    },
  },
  Events: {
    onRenderFirstFinish: () => {
      onRenderFirstFinish?.();
    },
    onAfterClick: ({row}) => {
      onRowSelect(row.pgmId);
    },
    onAfterSort: (evtParam: any) => {
      const sheet = evtParam.sheet;
      if (reRenderAllStateTags) {
        setTimeout(() => {
          reRenderAllStateTags(sheet);
        }, 100);
      }
    },
    onRenderFinish: (paramObject: any) => {
      const sheet = paramObject.sheet;
      if (reRenderAllStateTags) {
        setTimeout(() => {
          reRenderAllStateTags(sheet);
        }, 50);
      }
    },
  },
  Cols: [
    {
      Header: '프로그램 ID',
      Name: 'pgmId',
      Type: 'Text',
      Width: 100,
      Align: 'Center',
      CanEdit: 0,
    },
    {
      Header: '프로그램 명',
      Name: 'pgmName',
      Type: 'Text',
      RelWidth: 1,
      Align: 'Left',
      CanEdit: 0,
    },
    {
      Header: '프로그램 URL',
      Type: 'Text',
      Name: 'pgmUrl',
      RelWidth: 1,
      CanEdit: 0,
    },
    {
      Header: '상위 ID',
      Name: 'upgmId',
      Type: 'Text',
      Width: 100,
      Align: 'Center',
      CanEdit: 0,
    },
    {
      Header: '순번',
      Name: 'seq',
      Type: 'Text',
      Width: 60,
      Align: 'Center',
      CanEdit: 0,
    },
    {
      Header: '프로그램 메뉴 구분',
      Name: 'pmFlag',
      Type: 'Enum',
      Enum: '|P|M',
      Width: 60,
      Align: 'Center',
      CanEdit: 0,
    },
    {
      Header: '사용여부',
      Name: 'useYn',
      Type: 'Enum',
      Enum: '|Y|N',
      Width: 60,
      Align: 'Center',
      CanEdit: 0,
    },
  ],
});
