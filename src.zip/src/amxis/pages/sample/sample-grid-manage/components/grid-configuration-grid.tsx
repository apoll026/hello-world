import React, { useRef, useEffect, useMemo, forwardRef, useImperativeHandle, useCallback } from 'react';
import IBSheetGrid, { IBSheetGridRef } from '@/amxis/components/ibsheet8/ibsheet-grid';
import { useGridManageStore } from '@/amxis/stores/useGridManageStore';
import { createConfigGridOptions } from '../constants/config-grid-options';
import { GridConfigInfo } from '../types/grid-manage.types';
import { Box } from '@mui/material';
import { GridManageUtility } from '../utils/grid-manage-utility';
import { useGridConfigGrid } from '../hooks/use-grid-config-grid';
import { useMessageBar } from '@amxis/design-system';
import { useCommonDialogStore } from '@/amxis/stores/useCommonDialogStore';
import { useTranslation } from 'react-i18next';
import { useMessageModalStore } from '@/amxis/stores/useMessageModalStore.ts';
import { openMessageCodePicker } from '../utils/popup-util';

interface GridConfigurationGridProps {
  data: GridConfigInfo[];
}

const GridConfigurationGrid = forwardRef<IBSheetGridRef, GridConfigurationGridProps>(({ data }, ref) => {
  const gridRef = useRef<IBSheetGridRef>(null);
  const { t } = useTranslation();
  const { showMessageBar } = useMessageBar();
  const { openCommonDialog } = useCommonDialogStore();
  
  const { 
    isConfigGridReady, 
    setConfigGridReady,
    selectedMenu 
  } = useGridManageStore();

  const { saveConfigData, hasSelectedMenu } = useGridConfigGrid();

  const rowStatesRef = useRef<Map<string, string>>(new Map());
  const reactRootsRef = useRef<Map<string, any>>(new Map());
  const gridUtility = useRef(new GridManageUtility(rowStatesRef, reactRootsRef)).current;

  const { setMessageModalStateWhenModalOpen } = useMessageModalStore();

  const handleMessageCellClick = useCallback(() => {
    setMessageModalStateWhenModalOpen('', undefined, () => {});
  }, []);

  const handleOpenMessageCodePicker = useCallback(() => {
    const popup = openMessageCodePicker();
    if (!popup) {
      showMessageBar({
        message: '팝업이 차단되었습니다. 브라우저의 팝업 차단 설정을 확인해주세요.',
        usecase: 'warning',
      });
    }
  }, [showMessageBar]);

  useImperativeHandle(ref, () => ({
    getSheet: () => gridRef.current?.getSheet() || null,
  }));

  const gridOptions = useMemo(() =>
    createConfigGridOptions(
      () => setConfigGridReady(true),
      handleMessageCellClick,
      gridUtility.setRowState,
      gridUtility.reRenderAllStateTags,
      rowStatesRef
    ),
    [setConfigGridReady, gridUtility]
  );

  const addNewRow = () => {
    if (!selectedMenu) {
      showMessageBar({
        message: '메뉴를 먼저 선택해주세요.',
        usecase: 'warning',
      });
      return;
    }
    gridUtility.addRow(gridRef.current?.getSheet(), 'configGrid');
  };

  const deleteSelectedRows = () => {
    gridUtility.deleteRow(gridRef.current?.getSheet(), 'configGrid');
  };

  const copySelectedRows = () => {
    if (!selectedMenu) {
      showMessageBar({
        message: '메뉴를 먼저 선택해주세요.',
        usecase: 'warning',
      });
      return;
    }

    const sheet = gridRef.current?.getSheet();
    if (!sheet) {
      showMessageBar({
        message: '시트를 찾을 수 없습니다.',
        usecase: 'error',
      });
      return;
    }

    const selectedRows = sheet['configGrid'].getRowsByChecked('sCheck');
    if (selectedRows.length === 0) {
      showMessageBar({
        message: '복사할 행을 선택해주세요.',
        usecase: 'warning',
      });
      return;
    }

    gridUtility.copySelectedRows(sheet, 'configGrid');
    
    showMessageBar({
      message: `${selectedRows.length}개 행이 복사되었습니다.`,
      usecase: 'success',
    });
  };

  const downloadExcel = () => {
    gridUtility.excelDownload(gridRef.current?.getSheet(), 'configGrid');
  };

  const refreshGrid = () => {
    const sheet = gridRef.current?.getSheet();
    if (!sheet) return;

    gridUtility.cleanup();
    sheet['configGrid'].removeAll();
    if (data) {
      sheet['configGrid'].loadSearchData(data, 0);
    }
  };

  const handleSaveConfig = async () => {
    if (!hasSelectedMenu) {
      showMessageBar({
        message: '메뉴를 먼저 선택해주세요.',
        usecase: 'warning',
      });
      return;
    }

    const configSheet = gridRef.current?.getSheet();
    if (!configSheet) {
      showMessageBar({
        message: '설정 그리드를 찾을 수 없습니다.',
        usecase: 'error',
      });
      return;
    }

    if (!GridManageUtility.hasChanges(configSheet, 'configGrid')) {
      showMessageBar({
        message: '변경된 그리드 설정이 없습니다.',
        usecase: 'warning',
      });
      return;
    }

    const changedConfigData = GridManageUtility.getChangedConfigData(configSheet, 'configGrid');
    
    const validation = GridManageUtility.validateConfigData(changedConfigData);
    if (!validation.isValid) {
      showMessageBar({
        message: `입력 오류: ${validation.errors.join(', ')}`,
        usecase: 'error',
      });
      return;
    }
    
    openCommonDialog({
      modalType: 'confirm',
      content: `${changedConfigData.length}개의 그리드 설정을 저장하시겠습니까?`,
      onSubmit: async () => {
        const result = await saveConfigData(changedConfigData);
        if (result) {
          showMessageBar({
            message: t('common.alert.저장되었습니다.', '저장되었습니다.'),
            usecase: 'success',
          });
        } else {
          showMessageBar({
            message: t('common.alert.저장에 실패하였습니다.', '저장에 실패하였습니다.'),
            usecase: 'error',
          });
        }
      },
    });
  };

  useEffect(() => {
    if (!isConfigGridReady) return;
    
    const sheet = gridRef.current?.getSheet();
    if (sheet) {
      gridUtility.cleanup();

      sheet['configGrid'].removeAll();
      if (data && data.length > 0) {
        sheet['configGrid'].loadSearchData(data, 0);
      }
    }
  }, [isConfigGridReady, data, gridUtility]);

  useEffect(() => {
    return () => {
      gridUtility.cleanup();
    };
  }, [gridUtility]);

  return (
    <IBSheetGrid
      ref={gridRef}
      id="configGrid"
      el="config-grid-el"
      options={gridOptions}
      total={data.length}
      title="Grid 정보"
      isHeaderSectionEnabled={true}
      headerButton={[
        {
          variant: 'search',
          label: '메시지 코드 조회',
          onClick: handleOpenMessageCodePicker,
        },
        {
          variant: 'add',
          label: '행추가',
          onClick: addNewRow,
        },
        {
          variant: 'delete',
          label: '행삭제',
          onClick: deleteSelectedRows,
        },
        {
          variant: 'copy',
          label: '행복사',
          onClick: copySelectedRows,
        },
        {
          label: '다운로드',
          variant: 'download',
          onClick: downloadExcel,
        },
        {
          label: '새로고침',
          variant: 'refresh',
          onClick: refreshGrid,
        },
        {
          label: '저장',
          variant: 'save',
          onClick: handleSaveConfig,
        },
      ]}
      height="400px"
    />
  );
});

GridConfigurationGrid.displayName = 'GridConfigurationGrid';

export default GridConfigurationGrid;