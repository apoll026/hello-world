import { useCallback } from 'react';
import { MenuInfo } from '../types/grid-manage.types';
import { useGridManageStore } from '@/amxis/stores/useGridManageStore';
import { useMenuAllQuery } from '@/amxis/hooks/queries/menu/use-menu-query';
import { MenuVO } from '@/amxis/models/admin/Menu';

export const useMenuListGrid = () => {
  const { 
    setSelectedMenu, 
    clearConfigGrid,
    searchCondition
  } = useGridManageStore();

  const mapMenuData = useCallback((data: MenuVO[]): MenuInfo[] => {
    return data?.map((menu): MenuInfo => ({
      pgmId: menu.pgmId,
      pgmName: menu.pgmName || '',
      pgmUrl: menu.pgmUrl || '',
      upgmId: menu.upgmId || '',
      seq: menu.sortOrd?.toString() || '',
      pmFlag: menu.mnuLvNo === 1 ? 'M' : 'P',
      useYn: (menu.useYn as 'Y' | 'N') || 'Y',
    })) || [];
  }, []);

  const {
    data: menuData,
    isLoading,
  } = useMenuAllQuery<MenuInfo[]>(
    { ...searchCondition },
    {
      select: mapMenuData,
    }
  );

  const handleMenuSelect = useCallback((pgmId: string) => {
    const { selectedMenu } = useGridManageStore.getState();

    if (selectedMenu !== pgmId) {
      clearConfigGrid();
    }

    setSelectedMenu(pgmId);
  }, [setSelectedMenu, clearConfigGrid]);

  return {
    menuData: menuData || [],
    loading: isLoading,
    handleMenuSelect,
  };
};