import { useCallback, useEffect, useRef } from 'react';
import { GridConfigInfo } from '../types/grid-manage.types';
import { useGridManageStore } from '@/amxis/stores/useGridManageStore';
import { useGridConfigQuery } from '@/amxis/hooks/queries/grid-config/use-grid-config-query';
import { useGridConfigMutation } from '@/amxis/hooks/queries/grid-config/use-grid-config-mutaion.ts';

export const useGridConfigGrid = () => {
  const { 
    selectedMenu, 
    gridConfigurations,
    gridConfigLoading,
    setGridConfigurations,
    setGridConfigLoading 
  } = useGridManageStore();

  const prevSelectedMenuRef = useRef<string | null>(null);

  const {
    data: gridConfigApiData, 
    isLoading: isGridConfigLoading, 
    refetch: refetchGridConfig 
  } = useGridConfigQuery(selectedMenu || '');

  const saveConfigMutation = useGridConfigMutation();

  const fetchGridConfig = useCallback(
    async () => {
      if (!selectedMenu) {
        setGridConfigurations([]);
        return;
      }

      setGridConfigLoading(true);

      try {
        const { data: freshData } = await refetchGridConfig();
        setGridConfigurations(freshData || []);
      } catch (error) {
        console.error('그리드 설정 조회 실패:', error);
        setGridConfigurations([]);
      } finally {
        setGridConfigLoading(false);
      }
    },
    [selectedMenu, refetchGridConfig, setGridConfigurations, setGridConfigLoading]
  );

  const saveConfigData = useCallback(
    async (configList: GridConfigInfo[]) => {
      if (!selectedMenu) {
        console.error('선택된 메뉴가 없습니다.');
        return false;
      }

      try {
        await saveConfigMutation.mutateAsync(configList);
        await fetchGridConfig();
        return true;
      } catch (error) {
        console.error('그리드 설정 저장 실패:', error);
        return false;
      }
    },
    [selectedMenu, saveConfigMutation, fetchGridConfig]
  );

  // API 데이터 변경 시에만 상태 업데이트
  useEffect(() => {
    if (gridConfigApiData && !isGridConfigLoading) {
      setGridConfigurations(gridConfigApiData);
    }
  }, [gridConfigApiData, isGridConfigLoading, setGridConfigurations]);

  // 선택된 메뉴가 변경될 때만 데이터 조회
  useEffect(() => {
    if (selectedMenu !== prevSelectedMenuRef.current) {
      prevSelectedMenuRef.current = selectedMenu;
      
      if (selectedMenu) {
        fetchGridConfig();
      } else {
        setGridConfigurations([]);
      }
    }
  }, [selectedMenu, fetchGridConfig, setGridConfigurations]);

  return {
    configData: gridConfigurations,
    loading: gridConfigLoading || isGridConfigLoading,
    fetchGridConfig,
    saveConfigData,
    hasSelectedMenu: !!selectedMenu,
  };
};