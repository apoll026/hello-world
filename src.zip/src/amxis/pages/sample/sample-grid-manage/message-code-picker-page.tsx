import React, { useCallback, useEffect, useState, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { Controller, useForm } from 'react-hook-form';
import { Box, Grid, Typography } from '@mui/material';
import {
  Button,
  FormItem,
  InputField,
  SearchArea,
  BoardList,
  useMessageBar,
  ColDef,
  ICellRendererParams,
} from '@amxis/design-system';
import { useMessagesQuery } from '@/amxis/hooks/queries/message/use-messages-query';
import { useCommonCodeNamesQuery } from '@/amxis/hooks/queries/common/use-common-code-names-query';
import { Message, MessageCondition, ShowingMessage } from '@/amxis/models/admin/Message';
import { CommonYN } from '@/amxis/models/common/Common';
import { Code } from '@/amxis/models/common/CommonCode';
import { CrudCode } from '@/amxis/models/common/Edit';
import { v4 as uuid } from 'uuid';
import { DefaultCellTooltip } from '@/amxis/components/data-grid/default-cell-tooltip';
import { Spacer } from '@/amxis/components/layout';

interface MessageSearchForm {
  msgCtn: string;
  msgTxtCtn: string;
}

const MessageCodePickerPage: React.FC = () => {
  const { t } = useTranslation();
  const { showMessageBar } = useMessageBar();
  const [fetchEnabled, setFetchEnabled] = useState(false);
  const [viewingMessages, setViewingMessages] = useState<ShowingMessage[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);

  const [searchCondition, setSearchCondition] = useState<MessageCondition>({
    msgCtn: '',
    msgTxtCtn: '',
    useYn: CommonYN.Y,
    pageSize: '20',
    start: '0',
  });

  const { data: fetchedMessageData } = useMessagesQuery(searchCondition, fetchEnabled);
  const { data: fetchedLanguageCode } = useCommonCodeNamesQuery('LANG_CD');
  const totalCount = fetchedMessageData?.totalCount ?? 0;

  const { handleSubmit, control, reset } = useForm<MessageSearchForm>({
    defaultValues: {
      msgCtn: '',
      msgTxtCtn: '',
    },
  });

  const convertMessagesToShowingMessages = useCallback(
    (messages: Message[], languageCodes: Code[]): ShowingMessage[] => {
      if (messages.length === 0 || languageCodes.length === 0) {
        return [];
      }

      const showingMessages: ShowingMessage[] = [];
      for (const message of messages) {
        let showingMessage: ShowingMessage = {
          msgCtn: null,
          msgTxtCtn1: null,
          msgTxtCtn2: null,
          msgTxtCtn3: null,
          msgTxtCtn4: null,
          msgTxtCtn5: null,
          rmk: null,
          optValCtn1: null,
          optValCtn2: null,
          optValCtn3: null,
          useYn: null,
          dataInsUserId: null,
          dataInsUserIp: null,
          dataInsDtm: null,
          dataUpdUserId: null,
          dataUpdUserIp: null,
          dataUpdDtm: null,
        };

        const fields = [
          'msgTxtCtnList',
          'langCdList',
          'dataUpdDtmList',
          'dataUpdUserIdList',
          'useYnList',
        ];

        const splitByDoublePipe = (str: any) => str?.split(/\|\|/) ?? [];
        const parsed = Object.fromEntries(
          fields.map((field) => [field, splitByDoublePipe(message[field])])
        );

        const maxLength = Math.max(...fields.map((field) => parsed[field].length));
        const mergedList = Array.from({ length: maxLength }, (_, i) => ({
          msgTxtCtn: parsed.msgTxtCtnList[i] ?? '',
          langCd: parsed.langCdList[i] ?? '',
          dataUpdDtm: parsed.dataUpdDtmList[i] ?? '',
          dataUpdUserId: parsed.dataUpdUserIdList[i] ?? '',
          useYn: parsed.useYnList[i] ?? '',
        }));

        const langOrderMap = Object.fromEntries(
          languageCodes.map((code, index) => [code.cmnCdNm, index])
        );

        mergedList.sort((a, b) => {
          const aOrder = langOrderMap[a.langCd] ?? Number.MAX_SAFE_INTEGER;
          const bOrder = langOrderMap[b.langCd] ?? Number.MAX_SAFE_INTEGER;
          return aOrder - bOrder;
        });

        for (let i = 0; i < mergedList.length; i++) {
          showingMessage = {
            ...showingMessage,
            msgCtn: message.msgCtn,
            [`msgTxtCtn${i + 1}`]: mergedList[i].msgTxtCtn,
            useYn: mergedList[i].useYn,
            dataUpdDtm: mergedList[i].dataUpdDtm ?? '19000101000000',
            dataUpdUserId: mergedList[i].dataUpdUserId,
          };
        }
        showingMessages.push({ ...showingMessage, crudKey: CrudCode.READ, uuid: uuid() });
      }
      return showingMessages;
    },
    []
  );

  const handleSearchClick = handleSubmit(async ({ msgCtn, msgTxtCtn }) => {
    setFetchEnabled(true);
    setCurrentPage(1);
    setSearchCondition({
      msgCtn: msgCtn || '',
      msgTxtCtn: msgTxtCtn || '',
      useYn: CommonYN.Y,
      pageSize: String(pageSize),
      start: '0',
    });
  });

  const handleCopyToClipboard = useCallback(async (msgCode: string) => {
    try {
      await navigator.clipboard.writeText(msgCode);
      showMessageBar({
        message: `메시지 코드 "${msgCode}"가 클립보드에 복사되었습니다.`,
        usecase: 'success',
      });
      
      // 부모 창에 메시지 전달 (선택사항)
      if (window.opener) {
        window.opener.postMessage({
          type: 'MESSAGE_CODE_COPIED',
          data: msgCode
        }, '*');
      }
    } catch (error) {
      showMessageBar({
        message: '클립보드 복사에 실패했습니다.',
        usecase: 'error',
      });
    }
  }, [showMessageBar]);

  const columnDefs = useMemo(() => {
    const columns: ColDef<ShowingMessage>[] = [
      {
        headerName: '메시지코드',
        field: 'msgCtn',
        width: 240,
        tooltipField: 'msgCtn',
        tooltipComponent: DefaultCellTooltip,
        sortable: false,
        cellStyle: { cursor: 'pointer' },
        cellRenderer: (params: ICellRendererParams) => {
          return (
            <div 
              style={{ 
                padding: '4px 8px', 
                borderRadius: '4px',
                border: '1px solid #e1e5e9',
                fontWeight: '500',
                color: '#1976d2'
              }}
              title="더블클릭하여 복사"
            >
              {params.value}
            </div>
          );
        },
        onCellDoubleClicked: (params) => {
          if (params.value) {
            handleCopyToClipboard(params.value);
          }
        },
      },
      {
        headerName: '메시지 내용 (한국어)',
        field: 'msgTxtCtn1',
        flex: 1,
        minWidth: 200,
        tooltipField: 'msgTxtCtn1',
        tooltipComponent: DefaultCellTooltip,
        sortable: false,
      },
      {
        headerName: '사용여부',
        field: 'useYn',
        width: 80,
        sortable: false,
        cellStyle: { textAlign: 'center' },
        cellRenderer: (params: ICellRendererParams) => {
          return (
            <span style={{ 
              color: params.value === 'Y' ? '#2e7d32' : '#d32f2f',
              fontWeight: '500'
            }}>
              {params.value === 'Y' ? '사용' : '사용'}
            </span>
          );
        },
      },
      {
        headerName: '수정일시',
        field: 'dataUpdDtm',
        width: 140,
        sortable: false,
        cellStyle: { textAlign: 'center', fontSize: '12px' },
        cellRenderer: (params: ICellRendererParams) => {
          const updateDateTime = params.value;
          if (!updateDateTime || updateDateTime === '19000101000000') return '';
          const year = updateDateTime.substring(0, 4);
          const month = updateDateTime.substring(4, 6);
          const day = updateDateTime.substring(6, 8);
          const hour = updateDateTime.substring(8, 10);
          const minute = updateDateTime.substring(10, 12);
          return `${year}.${month}.${day} ${hour}:${minute}`;
        },
      },
    ];

    return columns;
  }, [handleCopyToClipboard]);

  const handleChangePage = (page: number) => {
    setCurrentPage(page);
    setSearchCondition(prev => ({
      ...prev,
      start: String(pageSize * (page - 1)),
    }));
  };

  const handleChangePageSize = (newPageSize: number) => {
    setPageSize(newPageSize);
    setCurrentPage(1);
    setSearchCondition(prev => ({
      ...prev,
      pageSize: String(newPageSize),
      start: '0',
    }));
  };

  const handleCloseWindow = () => {
    window.close();
  };

  useEffect(() => {
    if (fetchedMessageData && fetchedLanguageCode) {
      setViewingMessages(
        convertMessagesToShowingMessages(fetchedMessageData.list, fetchedLanguageCode)
      );
    }
  }, [fetchedMessageData, fetchedLanguageCode, convertMessagesToShowingMessages]);

  useEffect(() => {
    // 페이지 로드 시 자동으로 전체 메시지 조회
    setFetchEnabled(true);
    setSearchCondition({
      msgCtn: '',
      msgTxtCtn: '',
      useYn: CommonYN.Y,
      pageSize: '20',
      start: '0',
    });
  }, []);

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        minHeight: '100vh',
        padding: '16px',
        backgroundColor: '#fafafa',
        overflowY: 'auto',
      }}
    >
      {/* 제목 영역 */}
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '16px',
          padding: '12px 16px',
          backgroundColor: '#fff',
          borderRadius: '8px',
          boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
        }}
      >
        <Typography variant="h5">
          {String(t('', '__메시지 코드 조회'))}
        </Typography>
        <Button
          appearance="outlined"
          size="medium"
          onClick={handleCloseWindow}
          sx={{ minWidth: '80px' }}
        >
          닫기
        </Button>
      </Box>

      {/* 검색 영역 */}
      <Box
        sx={{ backgroundColor: '#fff', borderRadius: '8px', padding: '16px', marginBottom: '16px' }}
      >
        <SearchArea
          searchButtonLabel="조회"
          conditions={
            <>
              <Grid item xs={6}>
                <FormItem
                  label="메시지 코드"
                  labelAlign="right"
                  render={() => (
                    <Controller
                      control={control}
                      name="msgCtn"
                      render={({ field }) => (
                        <InputField
                          {...field}
                          fullWidth
                          size="medium"
                          placeholder="메시지 코드를 입력하세요"
                          onKeyUp={(e) => {
                            if (e.key === 'Enter') handleSearchClick();
                          }}
                        />
                      )}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={6}>
                <FormItem
                  label="메시지 내용"
                  labelAlign="right"
                  render={() => (
                    <Controller
                      control={control}
                      name="msgTxtCtn"
                      render={({ field }) => (
                        <InputField
                          {...field}
                          fullWidth
                          size="medium"
                          placeholder="메시지 내용을 입력하세요"
                          onKeyUp={(e) => {
                            if (e.key === 'Enter') handleSearchClick();
                          }}
                        />
                      )}
                    />
                  )}
                />
              </Grid>
            </>
          }
          onSearch={handleSearchClick}
        />
      </Box>

      {/* 목록 영역 */}
      <Box
        sx={{
          flex: 1,
          backgroundColor: '#fff',
          borderRadius: '8px',
          padding: '16px',
          boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        <BoardList
          basicViewProps={{
            emptyLabel: '조회 가능한 데이터가 없습니다.',
            columnDefs: columnDefs,
            rowData: viewingMessages,
            rowHeight: 32,
          }}
          headerProps={{
            totalCount: totalCount,
            hasPageSizeArea: true,
            pageSizeControlProps: {
              sizeOptions: [
                { label: '20', value: '20' },
                { label: '50', value: '50' },
                { label: '100', value: '100' },
              ],
              currentSize: pageSize,
              isPageSizeInput: false,
              onChangeSize: handleChangePageSize,
            },
          }}
          hasPagination={true}
          paginationProps={{
            currentPage: currentPage,
            onPageChange: handleChangePage,
            totalCount: Math.ceil(totalCount / pageSize),
          }}
          isHeaderSectionEnabled={true}
          title="메시지 목록 (메시지 코드 더블클릭으로 복사)"
        />
      </Box>
    </Box>
  );
};

export default MessageCodePickerPage;