// 메뉴 정보 타입 (그리드 컬럼 기준)
export interface MenuInfo {
  pgmId: string;         // 프로그램 ID
  pgmName: string;       // 프로그램 명
  pgmUrl: string;        // 프로그램 URL
  upgmId?: string;       // 상위 ID
  seq: string;           // 순번
  pmFlag: 'P' | 'M' | ''; // 프로그램 메뉴 구분 (P: 프로그램, M: 메뉴)
  useYn: 'Y' | 'N';      // 사용여부
}

// 삭제 작업에 필요한 최소한의 정보
export interface GridConfigBase {
  sState: string;
  pgmId: string;        // 프로그램 ID
  gridId: string;       // 그리드 ID
  columnId: string;     // 컬럼 ID
}

// 전체 그리드 설정 정보 (기존 속성 유지)
export interface GridConfigInfo extends GridConfigBase {
  columnMsgCd?: string;      // 컬럼명 메시지 코드
  columnMsgCont?: string;    // 컬럼명 메시지 내용-한국어
  description?: string;      // 컬럼 설명
  display?: string;         // 표시 여부 (1/0)
  orderNo?: string;          // 순번
  readonly?: string;        // 읽기 전용 여부 (1/0)
  align?: string;            // 정렬 (left/center/right)
  dataType?: string;         // 데이터 타입
  format?: string;           // 데이터 포맷
  comboCd?: string;          // 콤보 코드
  width?: string;            // 컬럼 너비
  isMergeYn?: string;       // 병합 여부 (1/0)
  treeKeyYn?: string;       // TreeGrid Key 여부 (1/0)
  isRequired?: string;       // 필수여부 (1/0)
  maxLength?: string;       // 입력 최대길이
}

// 검색 조건 타입
export interface MenuSearchCondition {
  pgmId?: string;
  pgmName?: string;
  useYn?: string;
}

export interface IbSheetInitColsVo {
  Header: string[];
  Type: string;
  Visible: number;
  Name: string;
  Width: number;
  MinWidth: number;
  CanEdit: number;
  Format: string;
  Align: string;
  Enum: string;
  EnumKeys: string;
  FormulaRow: string;
  Required: number;
}

export interface IbSheetInitVo {
  cols: IbSheetInitColsVo[];
  MainCol: string;
}