/**
 * 팝업 창을 화면 중앙에 열기 위한 유틸리티 함수
 */

interface PopupCenterOptions {
  url: string;
  title: string;
  w?: number;
  h?: number;
}

export const popupCenter = ({ url, title, w = 900, h = 650 }: PopupCenterOptions): Window | null => {
  // 듀얼 스크린 위치 계산 (대부분의 브라우저 및 Firefox 지원)
  const dualScreenLeft = window.screenLeft !== undefined ? window.screenLeft : window.screenX;
  const dualScreenTop = window.screenTop !== undefined ? window.screenTop : window.screenY;

  const width = window.innerWidth
    ? window.innerWidth
    : document.documentElement.clientWidth
    ? document.documentElement.clientWidth
    : screen.width;
    
  const height = window.innerHeight
    ? window.innerHeight
    : document.documentElement.clientHeight
    ? document.documentElement.clientHeight
    : screen.height;

  const systemZoom = width / window.screen.availWidth;
  const left = (width - w) / 2 / systemZoom + dualScreenLeft;
  const top = (height - h) / 2 / systemZoom + dualScreenTop;

  const newWindow = window.open(
    url,
    title,
    `
    scrollbars=yes,
    width=${w / systemZoom}, 
    height=${h / systemZoom}, 
    top=${top}, 
    left=${left},
    resizable=yes,
    toolbar=no,
    menubar=no,
    location=no,
    directories=no,
    status=no
    `
  );

  if (newWindow) {
    newWindow.focus();
  }

  return newWindow;
};

/**
 * 메시지 코드 선택 팝업을 여는 함수
 */
export const openMessageCodePicker = (): Window | null => {
  return popupCenter({
    url: '/system/message-picker',
    title: 'MessageCodePicker',
    w: 1000,
    h: 700
  });
};