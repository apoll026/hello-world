import { DropdownField, FormItem, InputField, Checkbox, CheckboxProps } from '@amxis/design-system';
import { Box, Typography } from '@mui/material';
import { useState } from 'react';

const EMAIL_OPTION = [
  { label: '직접입력', value: '직접입력' },
  { label: 'lgcns.com', value: 'lgcns.com' },
  { label: 'gmail.com', value: 'gmail.com' },
];

const PHONE_OPTION = [
  { label: '010', value: '010' },
  { label: '02', value: '02' },
];

const SAMPLE_CHECKBOX_ITEMS: CheckboxProps[] = [
  {
    id: 'checkBox1',
    labelText: 'option1',
    value: 'option1',
  },
  {
    id: 'checkBox2',
    labelText: 'option2',
    value: 'option2',
  },
  {
    id: 'checkBox3',
    labelText: 'option3',
    value: 'option3',
  },
];

export const SampleFormItem = () => {
  const [email, setEmail] = useState('lgcns.com');
  const [checkboxItems, setCheckboxItems] = useState<CheckboxProps[]>(SAMPLE_CHECKBOX_ITEMS);
  const [phone, setPhone] = useState('010');
  const handleOnChange = (id: string, checked: boolean) => {
    setCheckboxItems(
      checkboxItems.map((item) => (item.id === id ? { ...item, checked: checked } : item))
    );
  };
  return (
    <Box pt={'10px'}>
      <Box width="600px">
        <FormItem
          label="Label"
          required
          render={({ status }) => (
            <InputField
              placeholder="이메일아이디"
              size="medium"
              textAlign="left"
              type="text"
              fullWidth={true}
              status={status}
            />
          )}
          helperText="Info Text(Optional)"
          showHelperTextIcon
          labelSize="long"
        />
      </Box>
      <Box width="600px">
        <FormItem
          label=""
          // required
          render={({ status }) => (
            <InputField
              placeholder="이메일아이디"
              size="medium"
              textAlign="left"
              type="text"
              fullWidth={true}
              status={status}
            />
          )}
          helperText="Info Text(Optional)"
          showHelperTextIcon
          labelSize="long"
        />
      </Box>
      <Box width="600px" pt={'10px'}>
        <FormItem
          label="Label"
          required
          render={({ status }) => (
            <InputField
              placeholder="이메일아이디"
              size="medium"
              textAlign="left"
              type="text"
              fullWidth={true}
              status={status}
            />
          )}
          helperText="Info Text(Optional)"
          showHelperTextIcon
          labelSize="long"
          variant="vertical"
        />
      </Box>
      <Box width={'fit-content'} pt={'10px'}>
        <FormItem
          label="Label"
          required
          render={({ status }) => (
            <Box display="flex" alignItems="center" gap="4px">
              <InputField
                status={status}
                type="text"
                size="large"
                placeholder="이메일아이디"
                sx={{
                  minWidth: 'initial',
                  '& .MuiInputBase-root': {
                    width: '145px',
                  },
                }}
              />
              <Typography>@</Typography>
              <DropdownField
                options={EMAIL_OPTION}
                sx={{ width: '145px' }}
                value={{ label: email, value: email }}
                placeholder="lgcns.com" 
                size="large"
                onChange={(_e, value) => {
                  const emailValue = value as { value: string };
                  setEmail(emailValue.value);
                }}
                onKeyDown={(e) => e.preventDefault()}
              />
              <InputField
                type="text"
                size="large"
                placeholder="직접입력"
                sx={{
                  minWidth: 'initial',
                  '& .MuiInputBase-root, .MuiFormControl-root': {
                    width: '145px',
                  },
                  '.MuiFormHelperText-root': {
                    display: 'none',
                  },
                }}
                disabled={email !== '직접입력'}
              />
            </Box>
          )}
          helperText="Info Text(Optional)"
        />
      </Box>
      <Box width="600px" pt={'10px'}>
        <FormItem
          label="Label"
          required
          render={({ status }) => (
            <InputField
              textAlign="left"
              type="textarea"
              fullWidth={true}
              status={status}
              height={200}
            />
          )}
          helperText="Info Text(Optional)"
          showHelperTextIcon
          labelSize="short"
          status="error"
        />
      </Box>
      <Box width="600px" pt={'10px'}>
        <FormItem
          label="Label"
          required
          render={({ status }) => (
            <DropdownField
              options={EMAIL_OPTION}
              fullWidth
              value={{ label: email, value: email }}
              placeholder="lgcns.com"
              size="small"
              onKeyDown={(e) => e.preventDefault()}
              status={status}
              onChange={(_e, value) => {
                const emailValue = value as { value: string };
                setEmail(emailValue.value);
              }}
            />
          )}
          helperText="Info Text(Optional)"
          labelSize="short"
          status="confirmed"
        />
      </Box>
      <Box width="600px" pt={'10px'}>
        <FormItem
          label="Label"
          render={() => (
            <Box display="flex" flexDirection="column" gap={`12px`}>
              {checkboxItems.map((item) => (
                <Checkbox
                  key={item.id}
                  value={item.value}
                  labelText={item.labelText}
                  checked={item.checked}
                  onChange={(checkedStatus) => handleOnChange(item.id ?? '', checkedStatus)}
                />
              ))}
            </Box>
          )}
          labelSize="short"
        />
      </Box>
      <Box width={'fit-content'} pt={'10px'}>
        <FormItem
          label="Label"
          required
          render={({ status }) => (
            <Box display="flex" alignItems="center" gap="4px">
              <DropdownField
                options={PHONE_OPTION}
                sx={{ width: '80px' }}
                value={{ label: phone, value: phone }}
                size="medium"
                onChange={(_e, value) => {
                  const phoneValue = value as { value: string };
                  setPhone(phoneValue.value);
                }}
                onKeyDown={(e) => e.preventDefault()}
              />

              <Typography>-</Typography>
              <InputField
                status={status}
                type="text"
                size="medium"
                placeholder="####"
                sx={{
                  minWidth: 'initial',
                  '& .MuiInputBase-root': {
                    width: '80px',
                  },
                }}
              />
              <Typography>-</Typography>
              <InputField
                type="text"
                size="medium"
                placeholder="####"
                sx={{
                  minWidth: 'initial',
                  '& .MuiInputBase-root, .MuiFormControl-root': {
                    width: '80px',
                  },
                }}
              />
            </Box>
          )}
        />
      </Box>
    </Box>
  );
};
