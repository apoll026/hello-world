import { DataGrid, DataGridCellTooltip, Tag, Button } from '@amxis/design-system';
import { AgGridReact } from 'ag-grid-react';
import {
  CellClickedEvent,
  CellValueChangedEvent,
  ColDef,
  EditableCallbackParams,
  ICellRendererParams,
  IRowNode,
  IsRowSelectable,
} from 'ag-grid-community';
import { useEffect, useMemo, useRef, useState } from 'react';
import { CrudCode } from '@/amxis/models/common/Edit.ts';
import { t } from 'i18next';
import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { getLargeData } from '@/amxis/apis/admin/LargeData.ts';
import { grid } from '@mui/system';
const start = performance.now();
const LargeDataGrid = () => {
  const [rowData, setRowData] = useState<any[]>([]);
  const [columnDefs, setColumnDefs] = useState<ColDef[]>([]);
  const gridRef = useRef<AgGridReact<any>>(null);
  const createDynamicColumnDefs = (data: any[]): ColDef[] => {
    if (!data || data.length === 0) return [];

    return Object.keys(data[0]).map((key) => ({
      headerName: key, // 헤더 이름은 key 값 사용
      field: key, // 필드는 key 값과 매칭
      minWidth: 150, // 최소 너비 설정
      flex: 1, // 유연한 크기 설정
      editable: true, // 편집 가능 여부
      tooltipComponent: DataGridCellTooltip, // 툴팁 컴포넌트 설정
      tooltipField: key, // 툴팁 값 설정
    }));
  };
  const [data, setData] = useState<string[]>([]);
  useEffect(() => {
    setColumnDefs(createDynamicColumnDefs(data));
    setRowData(data);

    console.log(`실행 시간: ${(performance.now() - start).toFixed(2)}ms`);
  }, [data]);
  const fetchData = async () => {
    const eventSource = new EventSource('http://localhost:7070/api/v1/largedata');

    eventSource.onmessage = (event) => {
      const cleanedData = event.data.replace(/^data:\s*/, '').trim();
      const newData = JSON.parse(cleanedData);
      setData((prevData) => prevData.concat(newData));
    };

    eventSource.onerror = (err) => {
      console.error('Error fetching data:', err);
      eventSource.close();
    };

    return () => {
      eventSource.close();
    };
  };
  const fetchDataResultHandlerOnly = async () => {
    const eventSource = new EventSource(
      'http://localhost:7070/api/v1/largedata-resulthandler-only'
    );

    eventSource.onmessage = (event) => {
      const cleanedData = event.data.replace(/^data:\s*/, '').trim();
      const newData = JSON.parse(cleanedData);
      setData((prevData) => prevData.concat(newData));
    };

    eventSource.onerror = (err) => {
      console.error('Error fetching data:', err);
      eventSource.close();
    };

    return () => {
      eventSource.close();
    };
  };
  useEffect(() => {
    //fetchData();
  }, []);
  const isRowSelectable = useMemo<IsRowSelectable>(() => {
    return (node: IRowNode) => {
      return !!node.data && node.data.crudKey === CrudCode.CREATE;
    };
  }, []);
  const defaultColDef: ColDef = {
    resizable: true,
  };
  // useEffect(() => {
  //   console.log('data', data);
  // }, [data]);
  return (
    <>
      <DataGrid
        //minGridHeight={GridHeight.VerticalHalf.SearchArea.Line1}
        // minGridHeight={GridHeight.VerticalHalf.SearchArea.Line1}
        // gridHeight={'calc(50vh - 10px)'}
        minGridHeight={'calc(50vh - 180px)'}
        gridRef={gridRef}
        rowHeight={25}
        rowData={rowData}
        title={t('code.label.그룹코드목록', '그룹코드목록') ?? ''}
        infoText={
          t(
            'code.label.저장된 그룹코드는 삭제가 불가능합니다',
            '저장된 그룹코드는 삭제가 불가능합니다'
          ) ?? ''
        }
        columnDefs={columnDefs}
        defaultColDef={defaultColDef}
        animateRows={true}
        // suppressRowClickSelection={true}
        stopEditingWhenCellsLoseFocus={true}
        isRowSelectable={isRowSelectable}
        singleClickEdit={true}
        rowSelection="multiple"
        suppressScrollOnNewData={true}
        headerButton={[
          {
            onClick: () => {
              console.log('GRE');
            },
            variant: 'download',
          },
          {
            onClick: () => {
              console.log('re');
            },
            variant: 'refresh',
          },
          {
            onClick: () => {
              console.log('se');
            },
            variant: 'setting',
          },
        ]}
        onCellClicked={() => {}}
        onCellValueChanged={() => {}}
        emptyLabel={
          t('common.label.조회 가능한 데이터가 없습니다.', '__조회 가능한 데이터가 없습니다.') ?? ''
        }
        language={'ko'}
      ></DataGrid>
      <Button onClick={fetchData}>fetchData</Button>
      <Button onClick={fetchDataResultHandlerOnly}>fetchDataResultHandlerOnly</Button>
    </>
  );
};

export default LargeDataGrid;
