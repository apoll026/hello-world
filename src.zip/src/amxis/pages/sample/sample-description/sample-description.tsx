import { Description, DescriptionItem } from '@amxis/design-system';
import { Box } from '@mui/material';

const sample1: DescriptionItem[] = [
  {
    content: '리스트 내용이 출력되는 영역입니다.',
    textLink: 'listitem/detail',
  },
  {
    content:
      '타인으로부터 받은 Energy는 원하는 시기에 현금/복지포인트로 정산할 수 있습니다. 타인으로부터 받은 Energy는 원하는 시기에 현금/복지포인트로 정산할 수 있습니다.',
  },
  {
    content:
      '정산하지 않은 Energy는 연내에 타인에게 발송 가능합니다. 단, 연초에 부여받은 12개의 Energy를 모두 소진한 후에, 타인에게 받은 Energy 발송이 가능합니다.',
  },
  {
    content: '12월 31일까지 정산하지 않은 Energy는 익년 1월 10일 ± 2일에 일괄 정산됩니다.',
  },
];

const sample2: DescriptionItem[] = [
  {
    content:
      '리스트 내용이 출력되는 영역입니다. 내용이 길어질 경우에는 이렇게 줄바꿈되어 보여집니다.',
  },
  {
    content:
      '리스트 내용이 출력되는 영역입니다. 내용이 길어질 경우에는 이렇게 줄바꿈되어 보여집니다.',
  },
  {
    content: '리스트 내용이 출력되는 영역입니다.',
  },
  {
    content:
      '리스트 내용이 출력되는 영역입니다. 내용이 길어질 경우에는 이렇게 줄바꿈되어 보여집니다.',
  },
  {
    content:
      '리스트 내용이 출력되는 영역입니다. 내용이 길어질 경우에는 이렇게 줄바꿈되어 보여집니다.',
  },
  {
    content: '리스트 내용이 출력되는 영역입니다.',
  },
  {
    content:
      '리스트 내용이 출력되는 영역입니다. 내용이 길어질 경우에는 이렇게 줄바꿈되어 보여집니다.',
  },
];

export const SampleDescription = () => {
  return (
    <Box display={'flex'} flexDirection={'column'} gap={'10px'}>
      <Box display={'flex'} flexDirection={'row'} gap={'10px'}>
        <Box width={'596px'}>
          <Description
            title="Description"
            usecase="normal"
            ordered={false}
            listData={sample1}
            textLink="link/detail"
          />
        </Box>
        <Box width={'596px'}>
          <Description
            title="Description"
            usecase="confirm"
            ordered={false}
            listData={sample1}
            textLink="link/detail"
          />
        </Box>
        <Box width={'596px'}>
          <Description
            title="Description"
            usecase="warning"
            ordered={false}
            listData={sample1}
            textLink="link/detail"
          />
        </Box>
      </Box>
      <Box display={'flex'} flexDirection={'row'} gap={'10px'}>
        <Box width={'596px'}>
          <Description
            title="Description"
            usecase="error"
            ordered={false}
            listData={sample1}
            textLink="link/detail"
          />
        </Box>
        <Box width={'596px'}>
          <Description
            title="Description"
            usecase="normal"
            ordered={false}
            listData={[sample1[1]]}
          />
        </Box>
        <Box width={'596px'}>
          <Description usecase="normal" ordered={false} listData={sample1} />
        </Box>
      </Box>
      <Box display={'flex'} flexDirection={'row'} gap={'10px'}>
        <Box width={'596px'}>
          <Description
            title="Description"
            usecase="normal"
            ordered={true}
            listData={sample1}
            textLink="/link/detail"
          />
        </Box>
        <Box width={'420px'}>
          <Description title="Description" usecase="normal" listData={sample2} limitContent={3} />
        </Box>
      </Box>
      <Box
        display={'flex'}
        flexDirection={'row'}
        gap={'20px'}
        justifyContent={'center'}
        height={500}
      >
        <Description
          title="Description"
          usecase="normal"
          ordered={false}
          listData={sample1}
          dialog
          dialogWidth={330}
        />
        <Description
          usecase="confirm"
          ordered={false}
          listData={sample1}
          dialog
          dialogWidth={330}
          popperProps={{
            placement: 'left-end',
            modifiers: [
              {
                name: 'offset',
                options: {
                  offset: [30, 13],
                },
              },
            ],
          }}
        />
        <Description
          title="Description"
          usecase="warning"
          ordered
          listData={sample1}
          dialog
          dialogWidth={330}
          textLink="link/detail"
          popperProps={{
            placement: 'right-start',
          }}
        />
        <Description
          title="Description"
          usecase="error"
          ordered={false}
          listData={sample1}
          dialog
          limitContent={3}
          dialogWidth={552}
          popperProps={{
            placement: 'top-start',
          }}
        />
      </Box>
    </Box>
  );
};
