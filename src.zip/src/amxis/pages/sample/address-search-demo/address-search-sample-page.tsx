import React, { useState } from 'react';
import { ContainerLayout } from '@/amxis/components/container-layout';
import { SamplePageTitle } from '@/amxis/pages/sample/__components/sample-page-title.tsx';
import { Box, Typography, Alert, AlertTitle } from '@mui/material';
import { DocumentContentH2 } from '@/amxis/pages/sample/__components/document-content-h2.tsx';
import { useTheme } from '@amxis/design-system';
import { ContainerBox } from '@/amxis/pages/sample/__components/container-box.tsx';
import { Spacer } from '@/amxis/components/layout';
import AddressSearchForm from './address-search-form.tsx';
import { SelectedAddress } from './address-search-types.ts';

const AddressSearchSamplePage = () => {
  const [theme] = useTheme();
  const [address1, setAddress1] = useState<SelectedAddress | null>(null);
  const [address2, setAddress2] = useState<SelectedAddress | null>(null);

  return (
    <ContainerBox>
      <ContainerLayout>
        <SamplePageTitle>주소 검색 컴포넌트 샘플 (Daum 연동)</SamplePageTitle>
        <Box mt="48px" />
        
        <Alert severity="info" sx={{ mb: 3 }}>
          <AlertTitle>주소 검색 컴포넌트</AlertTitle>
          <Typography variant="body2">
            • <strong>Daum 우편번호:</strong> Daum 우편번호 서비스 직접 사용 (팝업 방식)<br/>
            • 선택된 주소에 상세주소를 추가할 수 있습니다<br/>
            • 실시간으로 전체 주소가 조합됩니다
          </Typography>
        </Alert>
        
        <DocumentContentH2 title="API 정보 및 Fallback 구조" />
        <Typography
          variant="body2"
          sx={{ color: theme.palette.semantic.color.commonTextBasic, whiteSpace: 'pre-line' }}
        >
          {'주소 검색 서비스 이중화 구조:' +
            '\n 1. Fallback 서비스: Daum 우편번호 서비스' +
            '\n\nAPI 응답 형태:'}
        </Typography>
        <Box mt="16px" sx={{ 
          backgroundColor: theme.palette.semantic.color.commonBgBasic,
          padding: '16px',
          borderRadius: '8px',
          fontFamily: 'monospace',
          fontSize: '12px',
          overflow: 'auto'
        }}>
          <Typography variant="body2" sx={{ whiteSpace: 'pre-wrap' }}>
{`// Daum 우편번호 서비스 Data
{
  "zonecode": "06142",
  "address": "서울 강남구 테헤란로 123",
  "roadAddress": "서울 강남구 테헤란로 123", 
  "jibunAddress": "서울 강남구 역삼동 123-45",
  "buildingName": "삼성빌딩",
  "addressType": "R",
  "userSelectedType": "R"
}`}
          </Typography>
        </Box>

        <Spacer type="h" size="48" />

        <DocumentContentH2 title="기본 주소 입력 폼" />
        <Typography
          variant="body2"
          sx={{ color: theme.palette.semantic.color.commonTextBasic, whiteSpace: 'pre-line' }}
        >
          {'기본 주소 검색 컴포넌트 사용법' +
            '\n • Daum 우편번호: Daum 서비스 직접 사용 (팝업 열림)' +
            '\n • 우편번호 필드 클릭으로 통합 검색 모달 열기' +
            '\n • 모달에서 키워드 검색 (도로명, 지번, 건물명 등)' +
            '\n • 상세주소 입력으로 완전한 주소 구성'}
        </Typography>
        <Box mt="24px">
          <AddressSearchForm
            title="기본 주소 입력"
            onAddressChange={(address) => {
              setAddress1(address);
              console.log('주소 1 변경:', address);
            }}
          />
        </Box>

        <Spacer type="h" size="48" />

        <DocumentContentH2 title="배송지 주소 입력" />
        <Typography
          variant="body2"
          sx={{ color: theme.palette.semantic.color.commonTextBasic, whiteSpace: 'pre-line' }}
        >
          {'다른 용도로 사용하는 주소 입력 폼 예시' +
            '\n • 제목만 변경하여 다양한 용도로 활용 가능' +
            '\n • 배송지, 사업장주소, 거주지 등'}
        </Typography>
        <Box mt="24px">
          <AddressSearchForm
            title="배송지 주소 입력"
            onAddressChange={(address) => {
              setAddress2(address);
              console.log('주소 2 변경:', address);
            }}
          />
        </Box>

        <Spacer type="h" size="48" />

        <DocumentContentH2 title="현재 선택된 주소 정보" />
        <Typography
          variant="body2"
          sx={{ color: theme.palette.semantic.color.commonTextBasic, whiteSpace: 'pre-line' }}
        >
          {'각 폼에서 선택된 주소 정보 확인 (개발자 도구 콘솔도 확인해보세요)'}
        </Typography>
        <Box mt="24px" sx={{
          display: 'flex',
          flexDirection: 'column',
          gap: '16px',
        }}>
          {/* 주소 1 정보 */}
          <Box sx={{
            backgroundColor: theme.palette.semantic.color.commonBgBasic,
            padding: '16px',
            borderRadius: '8px'
          }}>
            <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 'bold' }}>
              기본 주소 입력 결과:
            </Typography>
            {address1 ? (
              <Box sx={{ fontFamily: 'monospace', fontSize: '0.875rem' }}>
                <Typography variant="body2" sx={{ mb: 0.5 }}>
                  <strong>우편번호:</strong> {address1.zipCode}
                </Typography>
                <Typography variant="body2" sx={{ mb: 0.5 }}>
                  <strong>도로명주소:</strong> {address1.roadAddress}
                </Typography>
                <Typography variant="body2" sx={{ mb: 0.5 }}>
                  <strong>지번주소:</strong> {address1.jibunAddress}
                </Typography>
                {address1.detailAddress && (
                  <Typography variant="body2" sx={{ mb: 0.5 }}>
                    <strong>상세주소:</strong> {address1.detailAddress}
                  </Typography>
                )}
                <Typography variant="body2" sx={{ fontWeight: 'bold', color: theme.palette.primary.main }}>
                  <strong>전체주소:</strong> {address1.fullAddress}
                </Typography>
              </Box>
            ) : (
              <Typography variant="body2" sx={{ color: theme.palette.text.secondary, fontStyle: 'italic' }}>
                주소가 선택되지 않았습니다.
              </Typography>
            )}
          </Box>

          {/* 주소 2 정보 */}
          <Box sx={{
            backgroundColor: theme.palette.semantic.color.commonBgBasic,
            padding: '16px',
            borderRadius: '8px'
          }}>
            <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 'bold' }}>
              배송지 주소 입력 결과:
            </Typography>
            {address2 ? (
              <Box sx={{ fontFamily: 'monospace', fontSize: '0.875rem' }}>
                <Typography variant="body2" sx={{ mb: 0.5 }}>
                  <strong>우편번호:</strong> {address2.zipCode}
                </Typography>
                <Typography variant="body2" sx={{ mb: 0.5 }}>
                  <strong>도로명주소:</strong> {address2.roadAddress}
                </Typography>
                <Typography variant="body2" sx={{ mb: 0.5 }}>
                  <strong>지번주소:</strong> {address2.jibunAddress}
                </Typography>
                {address2.detailAddress && (
                  <Typography variant="body2" sx={{ mb: 0.5 }}>
                    <strong>상세주소:</strong> {address2.detailAddress}
                  </Typography>
                )}
                <Typography variant="body2" sx={{ fontWeight: 'bold', color: theme.palette.primary.main }}>
                  <strong>전체주소:</strong> {address2.fullAddress}
                </Typography>
              </Box>
            ) : (
              <Typography variant="body2" sx={{ color: theme.palette.text.secondary, fontStyle: 'italic' }}>
                주소가 선택되지 않았습니다.
              </Typography>
            )}
          </Box>
          
          <Typography variant="caption" sx={{ color: theme.palette.text.secondary, textAlign: 'center' }}>
            * 콘솔에서 더 자세한 데이터 구조를 확인할 수 있습니다<br/>
          </Typography>
        </Box>
        
        <Spacer type="h" size="80" />
      </ContainerLayout>
    </ContainerBox>
  );
};

export default AddressSearchSamplePage;