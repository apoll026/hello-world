// Daum 우편번호 서비스 응답 타입
export interface DaumAddressData {
  zonecode: string;              // 우편번호
  address: string;               // 기본 주소
  addressEnglish: string;        // 영문 기본 주소
  addressType: 'R' | 'J';        // 주소 타입 (R: 도로명, J: 지번)
  userSelectedType: 'R' | 'J';   // 사용자 선택 타입
  roadAddress: string;           // 도로명 주소
  roadAddressEnglish: string;    // 영문 도로명 주소
  jibunAddress: string;          // 지번 주소
  jibunAddressEnglish: string;   // 영문 지번 주소
  autoRoadAddress: string;       // 자동 매핑 도로명 주소
  autoJibunAddress: string;      // 자동 매핑 지번 주소
  buildingCode: string;          // 건물 관리번호
  buildingName: string;          // 건물명
  apartment: 'Y' | 'N';          // 공동주택 여부
  sido: string;                  // 시도명
  sigungu: string;               // 시군구명
  bname: string;                 // 법정동명
  query: string;                 // 검색어
}

// 폼에서 사용할 주소 정보 타입
export interface SelectedAddress {
  zipCode: string;
  roadAddress: string;
  jibunAddress: string;
  detailAddress?: string;
  fullAddress: string;
}

// 주소 검색 서비스 타입
export type AddressSearchService = 'server' | 'daum';

// 통합 주소 검색 결과
export interface UnifiedAddressSearchResult {
  service: AddressSearchService;
  totalCount: number;
  addresses: SelectedAddress[];
  hasMore: boolean;
}