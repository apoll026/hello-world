import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  Box,
  CircularProgress,
} from '@mui/material';
import { useTheme } from '@amxis/design-system';
import { SelectedAddress } from './address-search-types.ts';
import { searchAddress } from './address-search-api.ts';

interface AddressSearchModalProps {
  open: boolean;
  onClose: () => void;
  onSelectAddress: (address: SelectedAddress) => void;
}

const AddressSearchModal: React.FC<AddressSearchModalProps> = ({
  open,
  onClose,
  onSelectAddress,
}) => {
  const [theme] = useTheme();
  const [loading, setLoading] = useState(false);

  // 모달이 열릴 때 바로 Daum 주소 검색 실행
  useEffect(() => {
    if (open) {
      handleDaumSearch();
    }
  }, [open]);

  // Daum 주소 검색 함수
  const handleDaumSearch = async () => {
    setLoading(true);

    try {
      const result = await searchAddress(); // keyword는 사용하지 않음
      if (result.addresses.length > 0) {
        onSelectAddress(result.addresses[0]);
        onClose();
      }
    } catch (error) {
      console.error('주소 검색 오류:', error);
      alert('주소 검색 중 오류가 발생했습니다.');
      onClose();
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="sm"
      fullWidth
      PaperProps={{
        sx: {
          minHeight: '200px',
        },
      }}
    >
      <DialogTitle sx={{ pb: 1 }}>
        <Typography variant="h6" component="div">
          주소 검색
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
          Daum 우편번호 서비스를 사용합니다.
        </Typography>
      </DialogTitle>

      <DialogContent sx={{ pt: 1 }}>
        {loading ? (
          <Box sx={{ 
            display: 'flex', 
            flexDirection: 'column',
            alignItems: 'center', 
            py: 4 
          }}>
            <CircularProgress sx={{ mb: 2 }} />
            <Typography variant="body2" color="text.secondary">
              주소 검색 창을 여는 중입니다...
            </Typography>
          </Box>
        ) : (
          <Box sx={{ 
            textAlign: 'center', 
            py: 2,
            color: theme.palette.text.secondary,
          }}>
            <Typography variant="body2">
              주소 검색을 준비 중입니다.
            </Typography>
          </Box>
        )}
      </DialogContent>

      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={onClose} color="inherit">
          닫기
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default AddressSearchModal;