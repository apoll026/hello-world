import {
  SelectedAddress,
  DaumAddressData,
  UnifiedAddressSearchResult,
} from './address-search-types.ts';

// Daum 우편번호 서비스를 통한 주소 검색 (fallback)
export const searchAddressFromDaum = (): Promise<SelectedAddress> => {
  return new Promise((resolve, reject) => {
    // Daum 우편번호 서비스 스크립트가 로드되어 있는지 확인
    if (typeof window.daum === 'undefined' || typeof window.daum.Postcode === 'undefined') {
      // 스크립트 동적 로드
      const script = document.createElement('script');
      script.src = 'https://t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js';
      script.onload = () => {
        openDaumPostcode(resolve, reject);
      };
      script.onerror = () => {
        reject(new Error('Failed to load Daum Postcode service'));
      };
      document.head.appendChild(script);
    } else {
      openDaumPostcode(resolve, reject);
    }
  });
};

// Daum 우편번호 서비스 팝업 열기
const openDaumPostcode = (resolve: (address: SelectedAddress) => void, reject: (error: Error) => void) => {
  new window.daum.Postcode({
    oncomplete: (data: DaumAddressData) => {
      const selectedAddress = convertDaumAddressToSelected(data);
      resolve(selectedAddress);
    },
    onclose: (state: 'FORCE_CLOSE' | 'COMPLETE_CLOSE') => {
      if (state === 'FORCE_CLOSE') {
        reject(new Error('Address search was cancelled'));
      }
    },
    width: '100%',
    height: '100%'
  }).open();
};

// Daum 단일 주소 검색
export const searchAddress = async (): Promise<UnifiedAddressSearchResult> => {
  try {
    // Daum 우편번호 서비스 직접 사용
    const daumAddress = await searchAddressFromDaum();
    return {
      service: 'daum',
      totalCount: 1,
      addresses: [daumAddress],
      hasMore: false
    };
  } catch (daumError) {
    console.error('Daum address search failed:', daumError);
    throw new Error('Address search failed');
  }
};

// Daum API 응답을 SelectedAddress로 변환
const convertDaumAddressToSelected = (data: DaumAddressData): SelectedAddress => {
  const roadAddress = data.roadAddress || data.autoRoadAddress || '';
  const jibunAddress = data.jibunAddress || data.autoJibunAddress || '';
  
  return {
    zipCode: data.zonecode,
    roadAddress,
    jibunAddress,
    detailAddress: '',
    fullAddress: data.address
  };
};

// 타입 확장을 위한 global 선언
declare global {
  interface Window {
    daum: {
      Postcode: new (options: {
        oncomplete: (data: DaumAddressData) => void;
        onclose?: (state: 'FORCE_CLOSE' | 'COMPLETE_CLOSE') => void;
        onresize?: (size: { width: number; height: number }) => void;
        onsearch?: (data: { q: string; count: number }) => void;
        width?: number | string;
        height?: number | string;
        animation?: boolean;
        focusInput?: boolean;
        autoMapping?: boolean;
        autoMappingRoad?: boolean;
        autoMappingJibun?: boolean;
        shorthand?: boolean;
        pleaseReadGuide?: number;
        pleaseReadGuideTimer?: number;
        maxSuggestItems?: number;
        showMoreHName?: boolean;
        hideMapBtn?: boolean;
        hideEngBtn?: boolean;
        alwaysShowEngAddr?: boolean;
        submitMode?: boolean;
        useBannerLink?: boolean;
        hideOldPostcode?: boolean;
        theme?: object;
      }) => {
        open: (options?: {
          q?: string;
          left?: number;
          top?: number;
          popupTitle?: string;
          popupKey?: string;
          autoClose?: boolean;
        }) => void;
        embed: (element: HTMLElement, options?: {
          q?: string;
          autoClose?: boolean;
        }) => void;
      };
    };
  }
}