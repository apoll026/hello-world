import React, { useState } from 'react';
import {
  Box,
  TextField,
  Button,
  Typography,
  Paper,
  Grid,
  InputAdornment,
  IconButton,
  Divider,
} from '@mui/material';
import { 
  Search as SearchIcon, 
  LocationOn as LocationIcon, 
  Public as PublicIcon,
  Clear as ClearIcon 
} from '@mui/icons-material';
import { useTheme } from '@amxis/design-system';
import { SelectedAddress } from './address-search-types.ts';
import { searchAddressFromDaum } from './address-search-api.ts';

interface AddressSearchFormProps {
  title?: string;
  onAddressChange?: (address: SelectedAddress | null) => void;
}

const AddressSearchForm: React.FC<AddressSearchFormProps> = ({
  title = "주소 입력",
  onAddressChange,
}) => {
  const [theme] = useTheme();
  const [selectedAddress, setSelectedAddress] = useState<SelectedAddress | null>(null);
  const [detailAddress, setDetailAddress] = useState('');
  const [daumLoading, setDaumLoading] = useState(false);

  // 주소 선택 핸들러
  const handleAddressSelect = (address: SelectedAddress) => {
    setSelectedAddress(address);
    
    // 상세주소가 있다면 포함하여 전체 주소 업데이트
    const fullAddress = address.roadAddress + (detailAddress ? ` ${detailAddress}` : '');
    const updatedAddress = {
      ...address,
      detailAddress,
      fullAddress,
    };
    
    onAddressChange?.(updatedAddress);
  };

  // 상세주소 변경 핸들러
  const handleDetailAddressChange = (detail: string) => {
    setDetailAddress(detail);
    
    if (selectedAddress) {
      const fullAddress = selectedAddress.roadAddress + (detail ? ` ${detail}` : '');
      const updatedAddress = {
        ...selectedAddress,
        detailAddress: detail,
        fullAddress,
      };
      
      onAddressChange?.(updatedAddress);
    }
  };

  // 주소 초기화
  const handleClearAddress = () => {
    setSelectedAddress(null);
    setDetailAddress('');
    onAddressChange?.(null);
  };

  // Daum 우편번호 서비스 직접 호출
  const handleDaumSearch = async () => {
    setDaumLoading(true);
    try {
      const address = await searchAddressFromDaum();
      handleAddressSelect(address);
    } catch (error) {
      console.error('Daum 주소 검색 오류:', error);
      // 사용자가 취소한 경우는 알림을 표시하지 않음
      if (error instanceof Error && error.message !== 'Address search was cancelled') {
        alert('Daum 주소 검색 중 오류가 발생했습니다.');
      }
    } finally {
      setDaumLoading(false);
    }
  };

  return (
    <Paper sx={{ p: 3, mb: 3 }}>
      <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
        <LocationIcon color="primary" />
        {title}
      </Typography>

      <Grid container spacing={2}>
        {/* 우편번호 */}
        <Grid item xs={12} sm={4}>
          <TextField
            fullWidth
            label="우편번호"
            value={selectedAddress?.zipCode || ''}
            placeholder="우편번호"
            size="small"
            InputProps={{
              readOnly: true,
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton
                    onClick={handleDaumSearch}
                    size="small"
                    color="primary"
                  >
                    <SearchIcon />
                  </IconButton>
                </InputAdornment>
              ),
            }}
            sx={{
              '& .MuiInputBase-input': {
                cursor: 'pointer',
              },
            }}
            onClick={handleDaumSearch}
          />
        </Grid>

        {/* 주소 검색 버튼 */}
        <Grid item xs={12} sm={8}>
          <Box sx={{ display: 'flex', gap: 1, height: '100%' }}>
            <Button
              variant="contained"
              startIcon={<PublicIcon />}
              onClick={handleDaumSearch}
              disabled={daumLoading}
              sx={{ flex: 1, height: '40px' }}
            >
              {daumLoading ? '검색 중...' : '주소 검색'}
            </Button>
            {selectedAddress && (
              <IconButton
                onClick={handleClearAddress}
                color="error"
                sx={{ height: '40px', width: '40px' }}
              >
                <ClearIcon />
              </IconButton>
            )}
          </Box>
        </Grid>
      </Grid>

      {/* 도로명주소 */}
      <Box sx={{ mt: 2 }}>
        <TextField
          fullWidth
          label="도로명주소"
          value={selectedAddress?.roadAddress || ''}
          placeholder="주소를 검색해주세요"
          size="small"
          InputProps={{
            readOnly: true,
          }}
          sx={{
            '& .MuiInputBase-input': {
              cursor: 'pointer',
              backgroundColor: selectedAddress 
                ? theme.palette.action.selected 
                : 'transparent',
            },
          }}
          onClick={handleDaumSearch}
        />
      </Box>

      {/* 지번주소 */}
      {selectedAddress?.jibunAddress && (
        <Box sx={{ mt: 2 }}>
          <TextField
            fullWidth
            label="지번주소"
            value={selectedAddress.jibunAddress}
            size="small"
            InputProps={{
              readOnly: true,
            }}
            sx={{
              '& .MuiInputBase-input': {
                backgroundColor: theme.palette.action.disabled,
                color: theme.palette.text.secondary,
              },
            }}
          />
        </Box>
      )}

      {/* 상세주소 */}
      <Box sx={{ mt: 2 }}>
        <TextField
          fullWidth
          label="상세주소"
          value={detailAddress}
          onChange={(e) => handleDetailAddressChange(e.target.value)}
          placeholder="상세주소를 입력하세요 (선택사항)"
          size="small"
          disabled={!selectedAddress}
        />
      </Box>

      {/* 전체주소 미리보기 */}
      {selectedAddress && (
        <Box sx={{ 
          mt: 2, 
          p: 2, 
          backgroundColor: theme.palette.background.default,
          borderRadius: 1,
        }}>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.5 }}>
            전체 주소
          </Typography>
          <Typography variant="body2" sx={{ fontWeight: 'medium' }}>
            ({selectedAddress.zipCode}) {selectedAddress.roadAddress}
            {detailAddress && ` ${detailAddress}`}
          </Typography>
        </Box>
      )}

      {/* 설명 */}
      <Divider sx={{ my: 2 }} />
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
        <Typography variant="caption" color="text.secondary">
          <strong>주소 검색:</strong> Daum 우편번호 서비스를 사용합니다 (팝업 방식)
        </Typography>
      </Box>
    </Paper>
  );
};

export default AddressSearchForm;