import useSessionStore from '@/amxis/stores/useSessionStore.ts';

const useButtonAuth = () => {
  const { roleButtonCodes } = useSessionStore();

  const isButtonAuth = (requiredAuth: string, pgmAuth: string) => {
    return requiredAuth > pgmAuth || requiredAuth == pgmAuth;
  };

  return { isButtonAuth };
};

export default useButtonAuth;
