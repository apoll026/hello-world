import { useEffect } from 'react';
import { useNavigate } from 'react-router';
import { useTranslation } from 'react-i18next';
import { useLocation } from 'react-router-dom';
import { useCommonDialogStore } from '@/amxis/stores/useCommonDialogStore.ts';

const usePreventRefresh = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { state } = useLocation();

  const { openCommonDialog } = useCommonDialogStore();

  const handleBeforeunload = (event) => {
    state?.content && sessionStorage.setItem('pageState', JSON.stringify(state?.content));
    event.preventDefault();
    event.returnValue = '';
  };

  const handlePopstate = (e) => {
    history.pushState(null, '', location.href);
    openCommonDialog({
      title: t('common.button.확인', '확인') ?? '',
      modalType: 'confirm',
      content: t(
        'bbs.confirm.작성을 취소하시겠습니까? 작성된 내용이 사라집니다.',
        '작성을 취소하시겠습니까? 작성된 내용이 사라집니다.'
      ),
      onSubmit: () => {
        navigate(-2);
      },
    });
  };

  useEffect(() => {
    window.addEventListener('beforeunload', handleBeforeunload);
    history.pushState(null, '', location.href);
    window.addEventListener('popstate', handlePopstate);
    // beforeunload 이벤트는 리소스가 사라지기 전 window 자체에서 발행한다.
    // window의 이벤트를 감지하여 beforunload 이벤트 발생 시 handleBeforeunload 함수가 실행된다.

    return () => {
      window.removeEventListener('beforeunload', handleBeforeunload);
      window.removeEventListener('popstate', handlePopstate);
      //해당 이벤트 실행 후, beforeunload를 감지하는 것을 제거한다.
    };
  }, []);
};

export default usePreventRefresh;
