import { useState, useCallback } from 'react';

interface SimpleErrorInfo {
  message: string;
  details?: string;
  code?: string;
  timestamp?: string;
}

export const useSimpleErrorToast = () => {
  const [open, setOpen] = useState(false);
  const [error, setError] = useState<SimpleErrorInfo | null>(null);

  const showError = useCallback((errorInfo: SimpleErrorInfo) => {
    setError({
      ...errorInfo,
      timestamp: errorInfo.timestamp || new Date().toLocaleString('ko-KR')
    });
    setOpen(true);
  }, []);

  const hideError = useCallback(() => {
    setOpen(false);
  }, []);

  const showSimpleError = useCallback((message: string, details?: string) => {
    showError({
      message,
      details,
      timestamp: new Date().toLocaleString('ko-KR')
    });
  }, [showError]);

  return {
    open,
    error,
    showError,
    hideError,
    showSimpleError,
  };
};
