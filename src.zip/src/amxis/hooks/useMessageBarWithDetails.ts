import { useMessageBar } from '@amxis/design-system';
import React, { useCallback, useState } from 'react';

export interface MessageBarWithDetailsInfo {
  message: React.ReactNode;
  details?: React.ReactNode;
  code?: string;
  timestamp?: string;
}

export function useMessageBarWithDetails() {
  const { showMessageBar, hideMessageBar } = useMessageBar();
  const [open, setOpen] = useState(false);
  const [error, setError] = useState<MessageBarWithDetailsInfo>({ message: '' });

  const hideError = useCallback(() => {
    setOpen(false);
    hideMessageBar();
  }, [hideMessageBar]);

  const showError = useCallback(
    (errorInfo: MessageBarWithDetailsInfo, messageComponent: React.ReactNode) => {
      const enrichedError = {
        ...errorInfo,
        timestamp: errorInfo.timestamp || new Date().toLocaleString('ko-KR'),
      };

      setOpen(true);
      setError(enrichedError);

      // 외부에서 전달받은 컴포넌트를 MessageBar를 통해 표시
      showMessageBar({
        message: messageComponent,
        multipleLines: true,
        usecase: 'error',
      });
    },
    [showMessageBar]
  );

  return {
    open,
    error,
    hideError,
    showError,
  };
}
