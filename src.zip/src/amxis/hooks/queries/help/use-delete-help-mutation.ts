import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { deleteHelp } from '@/amxis/apis/admin/help.ts';

export const useDeleteHelpMutation = () => {
  return useReactMutation((pgmId: string) => {
    return deleteHelp(pgmId);
  });
};
