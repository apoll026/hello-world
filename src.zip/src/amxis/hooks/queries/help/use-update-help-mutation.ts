import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import type { Help } from '@/amxis/models/admin/Help.ts';
import { updateHelp } from '@/amxis/apis/admin/help.ts';

export const useUpdateHelpMutation = () => {
  return useReactMutation((help: Help) => {
    return updateHelp(help);
  });
};
