import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { HelpQueryKeys } from './help-query-keys.ts';
import { findHelp } from '@/amxis/apis/admin/help.ts';

export const useHelpQuery = (pgmId: string) => {
  return useReactQuery({
    queryKey: HelpQueryKeys.help(pgmId),
    queryFn: () => {
      return findHelp(pgmId);
    },
    enabled: !!pgmId?.trim(),
  });
};
