// import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
// import { HelpQueryKeys } from './help-query-keys.ts';
// import { findHelpByUrl } from '@/amxis/apis/admin/help.ts';

// export const useHelpUrlQuery = (pathname: string) => {
//   return useReactQuery({
//     queryKey: HelpQueryKeys.helpUrl(pathname),
//     queryFn: () => {
//       return findHelpByUrl(pathname);
//     },
//     enabled: !!pathname?.trim(),
//   });
// };
