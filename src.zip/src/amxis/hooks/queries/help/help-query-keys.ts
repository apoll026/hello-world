import { HelpCondition } from '@/amxis/models/admin/Help.ts';

export const HelpQueryKeys = {
  key: ['help'] as const,
  helps: ({ helpNm, useYn }: HelpCondition) =>
    [...HelpQueryKeys.key, 'helps', { helpNm, useYn }] as const,
  help: (pgmId: string) => [...HelpQueryKeys.key, 'help', pgmId] as const,
};
