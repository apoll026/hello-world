import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import type { HelpCondition } from '@/amxis/models/admin/Help.ts';
import { HelpQueryKeys } from './help-query-keys.ts';
import { findHelps } from '@/amxis/apis/admin/help.ts';

export const useHelpsQuery = ({ helpNm, useYn }: HelpCondition) => {
  return useReactQuery({
    queryKey: HelpQueryKeys.helps({ helpNm, useYn }),
    queryFn: () => {
      return findHelps({ helpNm, useYn });
    },
  });
};
