import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import type { Help } from '@/amxis/models/admin/Help.ts';
import { saveHelps } from '@/amxis/apis/admin/help.ts';

export const useCreateHelpMutation = () => {
  return useReactMutation((help: Help) => {
    return saveHelps(help);
  });
};
