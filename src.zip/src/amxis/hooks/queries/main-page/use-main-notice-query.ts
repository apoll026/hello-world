import { findMainNoticeData } from '@/amxis/apis/main-page/main-page';
import { MainPageQueryKeys } from './main-page-query-keys';
import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';

export const useMainNoticeQuery = () => {
  return useReactQuery({
    queryKey: MainPageQueryKeys.mainNotice(),
    queryFn: () => {
      return findMainNoticeData();
    },
  });
};
