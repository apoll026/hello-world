import { findMainBbsData } from '@/amxis/apis/main-page/main-page';
import { MainPageQueryKeys } from './main-page-query-keys';
import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';

export const useMainBbsQuery = () => {
  return useReactQuery({
    queryKey: MainPageQueryKeys.mainBbs(),
    queryFn: () => {
      return findMainBbsData();
    },
  });
};
