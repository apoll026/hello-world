export const MainPageQueryKeys = {
  key: ['main'] as const,
  mainCount: (empNo: string) => [...MainPageQueryKeys.key, 'count', empNo] as const,
  mainNotice: () => [...MainPageQueryKeys.key, 'notice'] as const,
  mainBbs: () => [...MainPageQueryKeys.key, 'bbs'] as const,
};
