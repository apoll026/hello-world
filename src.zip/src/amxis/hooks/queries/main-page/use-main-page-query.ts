import { findMainCountData } from '@/amxis/apis/main-page/main-page';
import { MainPageQueryKeys } from './main-page-query-keys';
import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';

export const useMainPageQuery = (empNo: string) => {
  return useReactQuery({
    queryKey: MainPageQueryKeys.mainCount(empNo),
    queryFn: () => {
      return findMainCountData(empNo);
    },
  });
};
