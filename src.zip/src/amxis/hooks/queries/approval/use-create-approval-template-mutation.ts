import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { createApprovalTemplate } from '@/amxis/apis/admin/Approval.ts';
import { ApprovalTemplate } from '@/amxis/models/admin/ApprovalTemplate.ts';

export const useCreateApprovalTemplateMutation = () => {
  return useReactMutation((approvalTemplate: ApprovalTemplate) => {
    return createApprovalTemplate(approvalTemplate);
  });
};
