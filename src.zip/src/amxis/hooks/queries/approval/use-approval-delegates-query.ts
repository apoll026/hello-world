import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { getApprovalDelegates } from '@/amxis/apis/admin/Approval.ts';
import { ApprovalQueryKeys } from '@/amxis/hooks/queries/approval/approval-query-keys.ts';

export type DelegateSearchParam = {
  dlgtUserId?: string;
  searchStatus?: string;
};

export const useApprovalDelegatesQuery = (searchParams: DelegateSearchParam) => {
  return useReactQuery({
    queryKey: ApprovalQueryKeys.approvalDelegates(searchParams),
    queryFn: () => {
      return getApprovalDelegates(searchParams.dlgtUserId ?? '', searchParams.searchStatus ?? '');
    },
  });
};
