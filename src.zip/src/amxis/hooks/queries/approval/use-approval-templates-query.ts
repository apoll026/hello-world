import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { getApprovalTemplate } from '@/amxis/apis/admin/Approval.ts';
import { ApprovalQueryKeys } from '@/amxis/hooks/queries/approval/approval-query-keys.ts';

export const useApprovalTemplatesQuery = (aprTplNm: string) => {
  return useReactQuery({
    queryKey: ApprovalQueryKeys.approvalTemplates(aprTplNm),
    queryFn: () => {
      return getApprovalTemplate(aprTplNm);
    },
  });
};
