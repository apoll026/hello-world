import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { saveApprovalDelegates } from '@/amxis/apis/admin/Approval.ts';
import { ApprovalDelegate } from '@/amxis/models/admin/Approval.ts';

export const useApprovalDelegateMutation = () => {
  return useReactMutation((approvalDelegates: ApprovalDelegate[]) => {
    return saveApprovalDelegates(approvalDelegates);
  });
};
