import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { modifyApprovalTemplate } from '@/amxis/apis/admin/Approval.ts';
import { ApprovalTemplate } from '@/amxis/models/admin/ApprovalTemplate.ts';

export const useUpdateApprovalTemplateMutation = () => {
  return useReactMutation((approvalTemplate: ApprovalTemplate) => {
    return modifyApprovalTemplate(approvalTemplate);
  });
};
