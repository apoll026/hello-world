import { ApiUrlCondition } from '@/amxis/models/admin/ApiUrl.ts';

export const ApiQueryKeys = {
  key: ['api'] as const,
  apiUrls: ({ apiNm, apiUrl, useYn }: ApiUrlCondition) =>
    [...ApiQueryKeys.key, 'apiUrls', { apiNm, apiUrl, useYn }] as const,
};
