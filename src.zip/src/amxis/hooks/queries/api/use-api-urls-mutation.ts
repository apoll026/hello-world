import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { saveApiUrls } from '@/amxis/apis/admin/ApiUrl.ts';
import { ApiUrl } from '@/amxis/models/admin/ApiUrl.ts';

export const useApiUrlsMutation = () => {
  return useReactMutation((apiUrls: ApiUrl[]) => {
    return saveApiUrls(apiUrls);
  });
};
