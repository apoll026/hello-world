import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { findApiUrls } from '@/amxis/apis/admin/ApiUrl.ts';
import { ApiQueryKeys } from '@/amxis/hooks/queries/api/api-query-keys.ts';
import { ApiUrlCondition } from '@/amxis/models/admin/ApiUrl.ts';

export const useApiUrlsQuery = ({ apiNm, apiUrl, useYn }: ApiUrlCondition) => {
  return useReactQuery({
    queryKey: ApiQueryKeys.apiUrls({ apiNm, apiUrl, useYn }),
    queryFn: () => {
      return findApiUrls({ apiNm, apiUrl, useYn });
    },
  });
};
