import { NotificationDeptCondition } from '@/amxis/models/admin/NotificationDept.ts';

export const NotificationDeptQueryKeys = {
  key: ['notification-dept'] as const,
  notificationDeptGroups: ({ ntdkDeptNm, ntdkDeptId, useYn }: NotificationDeptCondition) =>
    [...NotificationDeptQueryKeys.key, 'notificationDeptGroups', { ntdkDeptNm, ntdkDeptId, useYn }] as const,
  notificationDeptGroupDivisions: () =>
    [...NotificationDeptQueryKeys.key, 'notificationDeptGroupDivisions'] as const,
  notificationDeptGroupUsers: (ntdkId: string) =>
    [...NotificationDeptQueryKeys.key, 'notificationDeptGroupUsers', ntdkId] as const,
};
