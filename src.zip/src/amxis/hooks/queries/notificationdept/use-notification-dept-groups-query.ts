import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { getNotificationDeptGroups } from '@/amxis/apis/admin/NotificationDept.ts';
import { NotificationDeptQueryKeys } from '@/amxis/hooks/queries/notificationdept/notification-dept-query-keys.ts';
import { NotificationDeptCondition } from '@/amxis/models/admin/NotificationDept.ts';

export const useNotificationDeptGroupsQuery = ({ ntdkDeptNm, ntdkDeptId, useYn }: NotificationDeptCondition) => {
  return useReactQuery({
    queryKey: NotificationDeptQueryKeys.notificationDeptGroups({ ntdkDeptNm, ntdkDeptId, useYn }),
    queryFn: () => {
      return getNotificationDeptGroups({ ntdkDeptNm, ntdkDeptId, useYn });
    },
  });
};
