import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { getNotificationDeptGroupUsers } from '@/amxis/apis/admin/NotificationDept.ts';
import { NotificationDeptQueryKeys } from '@/amxis/hooks/queries/notificationdept/notification-dept-query-keys.ts';

export const useNotificationDeptGroupUsersQuery = (ntdkDeptId: string) => {
  return useReactQuery({
    queryKey: NotificationDeptQueryKeys.notificationDeptGroupUsers(ntdkDeptId),
    queryFn: () => {
      return getNotificationDeptGroupUsers(ntdkDeptId);
    },
    enabled: Boolean(ntdkDeptId),
  });
};
