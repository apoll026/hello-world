import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { getNotificationDeptGroupDivisions } from '@/amxis/apis/admin/NotificationDept.ts';
import { NotificationDeptQueryKeys } from '@/amxis/hooks/queries/notificationdept/notification-dept-query-keys.ts';

export const useNotificationDeptGroupDivisionsQuery = () => {
  return useReactQuery({
    queryKey: NotificationDeptQueryKeys.notificationDeptGroupDivisions(),
    queryFn: () => {
      return getNotificationDeptGroupDivisions();
    },
  });
};
