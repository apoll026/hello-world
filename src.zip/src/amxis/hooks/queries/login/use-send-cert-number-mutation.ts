import { sendCertNumber } from '@/amxis/apis/Session.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';

type SendCertNumberParams = {
  mailId: string;
  userPass: string;
  langCd: string;
};

function useSendCertNumberMutation() {
  return useReactMutation(({ mailId, userPass, langCd }: SendCertNumberParams) => {
    return sendCertNumber(mailId, userPass, langCd);
  });
}

export { useSendCertNumberMutation };
