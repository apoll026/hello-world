import { checkAdminIp } from '@/amxis/apis/Session.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';

function useCheckAdminIpMutation() {
  return useReactMutation(() => {
    return checkAdminIp();
  });
}

export { useCheckAdminIpMutation };
