import { devLogin } from '@/amxis/apis/Session.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';

type LoginParams = {
  mailId: string;
  langCd: string;
};

function useLoginMutation() {
  return useReactMutation(({ mailId, langCd }: LoginParams) => {
    return devLogin(mailId, langCd);
  });
}

export { useLoginMutation };
