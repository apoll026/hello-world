import { checkCertNumber } from '@/amxis/apis/Session.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';

type CheckCertNumberParams = {
  mailId: string;
  authCode: string;
  langCd: string;
};

function useCheckCertNumberMutation() {
  return useReactMutation(({ mailId, authCode, langCd }: CheckCertNumberParams) => {
    return checkCertNumber(mailId, authCode, langCd);
  });
}

export { useCheckCertNumberMutation };
