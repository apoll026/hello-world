import { findFiles } from '@/amxis/apis/admin/FileUpload.ts';
import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { FileQueryKeys } from './file-query-keys.ts';

function useFindFilesQuery(atchFileGrId?: string) {
  return useReactQuery({
    queryKey: FileQueryKeys.findFiles(atchFileGrId!),
    queryFn: () => {
      return findFiles(atchFileGrId!);
    },
    enabled: Boolean(atchFileGrId),
  });
}

export { useFindFilesQuery };
