import { uploadFiles } from '@/amxis/apis/admin/FileUpload.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';

function useFilesUploadMutation() {
  return useReactMutation((formData: FormData) => {
    return uploadFiles(formData);
  });
}

export { useFilesUploadMutation };
