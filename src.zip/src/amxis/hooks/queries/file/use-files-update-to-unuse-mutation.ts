import { modifyFiles } from '@/amxis/apis/admin/FileUpload.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { FileId } from '@/amxis/models/admin/FileId.ts';

function useFilesToUnuseUpdateMutation() {
  return useReactMutation((idList: FileId[]) => {
    return modifyFiles(idList);
  });
}

export { useFilesToUnuseUpdateMutation };
