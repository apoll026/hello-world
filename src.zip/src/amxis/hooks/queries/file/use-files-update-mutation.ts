import { modifyFiles } from '@/amxis/apis/admin/FileUpload.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { FileInfo } from '@/amxis/models/admin/FileInfo.ts';

function useFilesUpdateMutation() {
  return useReactMutation((files: FileInfo[]) => {
    return modifyFiles(files);
  });
}

export { useFilesUpdateMutation };
