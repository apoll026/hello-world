import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { sendMail } from '@/amxis/apis/admin/Mail.ts';
import { MailSendRequest } from '@/amxis/models/admin/Mail.ts';

export const useSendMailMutate = () => {
  return useReactMutation((emailRequest: MailSendRequest) => {
    return sendMail(emailRequest);
  });
};
