import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { SampleQueryKeys } from '@/amxis/hooks/queries/sample/sample-query-keys.ts';
import { getMailTemplate } from '@/amxis/apis/admin/Mail.ts';

export const useMailTemplatesQuery = (templateType: string) => {
  return useReactQuery({
    queryKey: SampleQueryKeys.mailTemplates(templateType),
    queryFn: () => {
      return getMailTemplate(templateType);
    },
    enabled: false,
  });
};
