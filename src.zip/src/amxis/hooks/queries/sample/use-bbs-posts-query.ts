import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { SampleQueryKeys } from '@/amxis/hooks/queries/sample/sample-query-keys.ts';
import { BbsCondition } from '@/amxis/models/admin/Bbs.ts';
import { findBbsPosts } from '@/amxis/apis/admin/Bbs.ts';

export const useBbsPostsQuery = (bbsCondition: BbsCondition) => {
  return useReactQuery({
    queryKey: SampleQueryKeys.bbsPosts(bbsCondition),
    queryFn: () => {
      return findBbsPosts(bbsCondition);
    },
  });
};
