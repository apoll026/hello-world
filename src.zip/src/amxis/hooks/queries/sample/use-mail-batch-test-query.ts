import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { SampleQueryKeys } from '@/amxis/hooks/queries/sample/sample-query-keys.ts';
import { mailBatchTest } from '@/amxis/apis/admin/Mail.ts';

export const useMailBatchTestQuery = () => {
  return useReactQuery({
    queryKey: SampleQueryKeys.mailBatchTest(),
    queryFn: () => {
      return mailBatchTest();
    },
    enabled: false,
  });
};
