import { QueryKey, UseQueryOptions } from '@tanstack/react-query';
import { IBSheetSampleConditionVO, IBSheetSampleResponseVO } from '@/models/sample/Ibsheet-sample';
import { SampleQueryKeys } from './sample-query-keys';
import { CommonError } from '@/amxis/models/common/APIError';
import { PaginationResponse } from '@/amxis/models/common/Pagination';
import { useReactQuery } from '../../use-react-query';
import {findIBSheetSamples} from "@/amxis/apis/Ibsheet-sample.ts";

export const useIBSheetSampleQuery = (
  condition: IBSheetSampleConditionVO,
  options?: Omit<
    UseQueryOptions<
      PaginationResponse<IBSheetSampleResponseVO>,
      CommonError,
      PaginationResponse<IBSheetSampleResponseVO>,
      QueryKey
    >,
    'queryKey'
  >
) => {
  return useReactQuery({
    queryKey: SampleQueryKeys.ibSheetSamples(condition),
    queryFn: () => {
      return findIBSheetSamples(condition);
    },
    ...options,
  });
};
