import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import {IBSheetSampleRequestVO} from "@/models/sample/Ibsheet-sample.ts";
import {saveIBSheetSampleData} from "@/amxis/apis/Ibsheet-sample.ts";

export const useSaveIBSheetSampleDataMutate = () => {
  return useReactMutation((datas: IBSheetSampleRequestVO[]) => {
    return saveIBSheetSampleData(datas);
  });
};
