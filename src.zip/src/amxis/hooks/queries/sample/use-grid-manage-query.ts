import { QueryKey, UseQueryOptions } from '@tanstack/react-query';
import { SampleQueryKeys } from './sample-query-keys';
import { CommonError } from '@/amxis/models/common/APIError';
import { PaginationResponse } from '@/amxis/models/common/Pagination';
import { useReactQuery } from '../../use-react-query';
import {
  GridManageConditionVO,
  GridManageResponseVO,
} from '@/amxis/models/models/sample/grid-manage';
import { findGridManage } from '@/amxis/apis/sample/GridManage';

export const useGridManageQuery = (
  condition: GridManageConditionVO,
  options?: Omit<
    UseQueryOptions<
      PaginationResponse<GridManageResponseVO>,
      CommonError,
      PaginationResponse<GridManageResponseVO>,
      QueryKey
    >,
    'queryKey'
  >
) => {
  return useReactQuery({
    queryKey: SampleQueryKeys.ibSheetSamples(condition),
    queryFn: () => {
      return findGridManage(condition);
    },
    ...options,
  });
};