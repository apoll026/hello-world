import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { createBbsPost } from '@/amxis/apis/sample/BbsApi.ts';
import { BbsPostDetail } from '@/amxis/models/admin/Bbs.ts';

export const useCreateBbsPostMutate = () => {
  return useReactMutation((bbs: BbsPostDetail) => {
    return createBbsPost(bbs);
  });
};
