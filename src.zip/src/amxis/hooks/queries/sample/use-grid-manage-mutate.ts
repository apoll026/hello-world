import { saveGridManageData } from '@/amxis/apis/sample/GridManage';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { GridManageRequestVO } from '@/amxis/models/models/sample/grid-manage';

export const useSaveGridManageDataMutate = () => {
  return useReactMutation((datas: GridManageRequestVO[]) => {
    return saveGridManageData(datas);
  });
};