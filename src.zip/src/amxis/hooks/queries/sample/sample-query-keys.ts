import { BbsCondition } from '@/amxis/models/admin/Bbs.ts';
import { IBSheetSampleConditionVO } from '@/models/sample/Ibsheet-sample';

export const SampleQueryKeys = {
  key: ['sample'] as const,
  bbsPosts: (bbsCondition: BbsCondition) =>
    [...SampleQueryKeys.key, 'bbsPosts', bbsCondition] as const,
  mailTemplates: (templateType: string) =>
    [...SampleQueryKeys.key, 'mailTemplates', templateType] as const,
  mailBatchTest: () => [...SampleQueryKeys.key, 'mailBatchTest'] as const,
  ibSheetSamples: (condition: IBSheetSampleConditionVO) =>
    [...SampleQueryKeys.key, 'ibSheetSamples', condition] as const,
};
