import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { updateBbsPost } from '@/amxis/apis/sample/BbsApi.ts';
import { BbsPostDetail } from '@/amxis/models/admin/Bbs.ts';

export const useUpdateBbsPostMutate = () => {
  return useReactMutation((bbs: BbsPostDetail) => {
    return updateBbsPost(bbs);
  }, {});
};
