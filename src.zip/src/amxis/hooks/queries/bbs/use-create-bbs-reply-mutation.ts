import { createBbsReply } from '@/amxis/apis/admin/BbsReply.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { BbsReplyRequest } from '@/amxis/models/admin/BbsReply.ts';

function useCreateBbsReplyMutation() {
  return useReactMutation((bbsReplyRequest: BbsReplyRequest) => {
    return createBbsReply(bbsReplyRequest);
  });
}

export { useCreateBbsReplyMutation };
