import { BbsCondition } from '@/amxis/models/admin/Bbs.ts';

export const BbsQueryKeys = {
  key: ['relse'] as const,
  Posts: (condition: BbsCondition) => [...BbsQueryKeys.key, 'Posts', condition] as const,
  Post: (bbsNo: string) => [...BbsQueryKeys.key, 'Post', bbsNo] as const,
  CmnCds: (codeGropWords: string) => [...BbsQueryKeys.key, codeGropWords] as const,
  Reply: (bbsNo: string) => [...BbsQueryKeys.key, 'Reply', bbsNo] as const,
};
