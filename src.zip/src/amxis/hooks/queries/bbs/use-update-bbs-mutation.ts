import { modifyBbs } from '@/amxis/apis/admin/Bbs.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { BbsPostUpdateRequest } from '@/amxis/models/admin/Bbs.ts';

function useUpdateBbsMutation() {
  return useReactMutation((bbs: BbsPostUpdateRequest) => {
    return modifyBbs(bbs);
  });
}

export { useUpdateBbsMutation };
