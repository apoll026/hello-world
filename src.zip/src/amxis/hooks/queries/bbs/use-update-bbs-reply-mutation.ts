import { modifyBbsReply } from '@/amxis/apis/admin/BbsReply.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { BbsReplyUpdateRequest } from '@/amxis/models/admin/BbsReply.ts';

function useUpdateBbsReplyMutation() {
  return useReactMutation((replyUpdateRequest: BbsReplyUpdateRequest) => {
    return modifyBbsReply(replyUpdateRequest);
  });
}

export { useUpdateBbsReplyMutation };
