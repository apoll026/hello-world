import { createBbs } from '@/amxis/apis/admin/Bbs.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { BbsPostRequest } from '@/amxis/models/admin/Bbs.ts';

function useCreateBbsMutation() {
  return useReactMutation((bbs: BbsPostRequest) => {
    return createBbs(bbs);
  });
}

export { useCreateBbsMutation };
