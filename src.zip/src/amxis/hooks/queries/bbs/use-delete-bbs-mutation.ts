import { deleteBbs } from '@/amxis/apis/admin/Bbs.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';

function useDeleteBbsMutation() {
  return useReactMutation((No: string) => {
    return deleteBbs(No);
  });
}

export { useDeleteBbsMutation };
