import { removeBbsReply } from '@/amxis/apis/admin/BbsReply.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';

function useDeleteBbsReplyMutation() {
  return useReactMutation(({ bbsNo, bbsReNo }: { bbsNo: string; bbsReNo: number | string }) => {
    return removeBbsReply(bbsNo, bbsReNo);
  });
}

export { useDeleteBbsReplyMutation };
