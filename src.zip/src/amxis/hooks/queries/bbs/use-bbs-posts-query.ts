import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { NoticeCondition } from '@/amxis/models/admin/Notice.ts';
import { BbsQueryKeys } from './bbs-query-keys.ts';
import { getFilterCodes } from '@/amxis/apis/admin/Bbs.ts';
import { findBbsPosts } from '@/amxis/apis/admin/Bbs.ts';

function useBbsPostsQuery(condition: NoticeCondition = {}) {
  return useReactQuery({
    queryKey: BbsQueryKeys.Posts(condition),
    queryFn: () => {
      return findBbsPosts(condition);
    },
  });
}

export { useBbsPostsQuery };
// /* 목록 DropDown Filter조건 조회 */
export function useBbsFilterQuery(codeGropWords: string) {
  return useReactQuery({
    queryKey: BbsQueryKeys.CmnCds(codeGropWords),
    queryFn: () => {
      return getFilterCodes(codeGropWords);
    },
  });
}
