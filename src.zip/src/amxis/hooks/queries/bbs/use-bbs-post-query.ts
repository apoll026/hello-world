import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { BbsQueryKeys } from './bbs-query-keys.ts';
import { findBbsPost } from '@/amxis/apis/admin/Bbs.ts';

function useBbsPostDetailQuery(bbsNo: string) {
  return useReactQuery({
    queryKey: BbsQueryKeys.Post(bbsNo),
    queryFn: () => {
      return findBbsPost(bbsNo);
    },
  });
}

export { useBbsPostDetailQuery };
