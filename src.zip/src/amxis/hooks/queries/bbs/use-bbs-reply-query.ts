import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { BbsQueryKeys } from './bbs-query-keys.ts';
import { useLoading } from '@/amxis/components/loader';
import { getBbsReplyList } from '@/amxis/apis/admin/BbsReply.ts';

/* 댓글 목록 조회 조회 */
export function useBbsReplyQuery(No: string) {
  const { openLoading } = useLoading();
  return useReactQuery({
    queryKey: BbsQueryKeys.Reply(No),
    queryFn: async () => {
      openLoading(true);
      const result = await getBbsReplyList(No);
      openLoading(false);
      return result;
    },
  });
}
