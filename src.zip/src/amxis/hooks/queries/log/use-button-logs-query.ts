import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { LogQueryKeys } from './log-query-keys.ts';
import { QueryKey, UseQueryOptions } from '@tanstack/react-query';
import { PaginationResponse } from '@/amxis/models/common/Pagination.ts';
import { CommonError } from '@/amxis/models/common/APIError.ts';
import { ButtonLogRequestVo, ButtonLogResponseVo } from '@/amxis/models/admin/ButtonLog.ts';
import { findButtonLogs } from '@/amxis/apis/admin/ButtonLog.ts';

export const useButtonLogsQuery = (
  condition: ButtonLogRequestVo,
  options?: Omit<
    UseQueryOptions<
      PaginationResponse<ButtonLogResponseVo>,
      CommonError,
      PaginationResponse<ButtonLogResponseVo>,
      QueryKey
    >,
    'queryKey'
  >
) => {
  return useReactQuery({
    queryKey: LogQueryKeys.ButtonLogs(condition),
    queryFn: () => {
      return findButtonLogs(condition);
    },
    ...options,
  });
};
