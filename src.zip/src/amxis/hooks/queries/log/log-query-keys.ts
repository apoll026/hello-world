import { MenuLogRequest } from '@/amxis/models/admin/MenuLog.ts';
import { LoginLogRequest } from '@/amxis/models/admin/LoginLog.ts';
import { IfLogRequest } from '@/amxis/models/admin/IfLog.ts';
import { BatchLogRequest } from '@/amxis/models/admin/BatchLog.ts';
import { EmailLogRequest } from '@/amxis/models/admin/EmailLog.ts';
import { ButtonLogRequestVo } from '@/amxis/models/admin/ButtonLog.ts';
export const LogQueryKeys = {
  key: ['log'] as const,
  menuLogs: (condition: MenuLogRequest) => [...LogQueryKeys.key, 'menuLogs', condition] as const,
  LoginLogs: (condition: LoginLogRequest) => [...LogQueryKeys.key, 'LoginLogs', condition] as const,
  IfLogs: (condition: IfLogRequest) => [...LogQueryKeys.key, 'IfLogs', condition] as const,
  BatchLogs: (condition: BatchLogRequest) => [...LogQueryKeys.key, 'BatchLogs', condition] as const,
  EmailLogs: (condition: EmailLogRequest) => [...LogQueryKeys.key, 'EmailLogs', condition] as const,
  ButtonLogs:(condition: ButtonLogRequestVo) => [...LogQueryKeys.key, 'ButtonLogs', condition] as const,
};
