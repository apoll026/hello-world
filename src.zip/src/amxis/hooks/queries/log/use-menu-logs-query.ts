import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { MenuLog, MenuLogRequest } from '@/amxis/models/admin/MenuLog.ts';
import { findMenuLogs } from '@/amxis/apis/admin/MenuLog.ts';
import { LogQueryKeys } from './log-query-keys.ts';
import { QueryKey, UseQueryOptions } from '@tanstack/react-query';
import { PaginationResponse } from '@/amxis/models/common/Pagination.ts';
import { CommonError } from '@/amxis/models/common/APIError.ts';

export const useMenuLogsQuery = (
  condition: MenuLogRequest,
  options?: Omit<
    UseQueryOptions<
      PaginationResponse<MenuLog>,
      CommonError,
      PaginationResponse<MenuLog>,
      QueryKey
    >,
    'queryKey'
  >
) => {
  return useReactQuery({
    queryKey: LogQueryKeys.menuLogs(condition),
    queryFn: () => {
      return findMenuLogs(condition);
    },
    ...options,
  });
};
