import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { EmailLog, EmailLogRequest } from '@/amxis/models/admin/EmailLog.ts';
import { findEmailLogs } from '@/amxis/apis/admin/EmailLog.ts';
import { LogQueryKeys } from './log-query-keys.ts';
import { QueryKey, UseQueryOptions } from '@tanstack/react-query';
import { PaginationResponse } from '@/amxis/models/common/Pagination.ts';
import { CommonError } from '@/amxis/models/common/APIError.ts';

export const useEmailLogsQuery = (
  condition: EmailLogRequest,
  options?: Omit<
    UseQueryOptions<
      PaginationResponse<EmailLog>,
      CommonError,
      PaginationResponse<EmailLog>,
      QueryKey
    >,
    'queryKey'
  >
) => {
  return useReactQuery({
    queryKey: LogQueryKeys.EmailLogs(condition),
    queryFn: () => {
      return findEmailLogs(condition);
    },
    ...options,
  });
};
