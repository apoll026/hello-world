import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { BatchLog, BatchLogRequest } from '@/amxis/models/admin/BatchLog.ts';
import { findBatchLogs } from '@/amxis/apis/admin/batchLog.ts';
import { LogQueryKeys } from './log-query-keys.ts';
import { QueryKey, UseQueryOptions } from '@tanstack/react-query';
import { PaginationResponse } from '@/amxis/models/common/Pagination.ts';
import { CommonError } from '@/amxis/models/common/APIError.ts';

export const useBatchLogsQuery = (
  condition: BatchLogRequest,
  options?: Omit<
    UseQueryOptions<PaginationResponse<BatchLog>, CommonError, PaginationResponse<BatchLog>, QueryKey>,
    'queryKey'
  >
) => {
  return useReactQuery({
    queryKey: LogQueryKeys.BatchLogs(condition),
    queryFn: () => {
      return findBatchLogs(condition);
    },
    ...options,
  });
};
