import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { LoginLog, LoginLogRequest } from '@/amxis/models/admin/LoginLog.ts';
import { findLoginLogs } from '@/amxis/apis/admin/LoginLog.ts';
import { LogQueryKeys } from './log-query-keys.ts';
import { QueryKey, UseQueryOptions } from '@tanstack/react-query';
import { PaginationResponse } from '@/amxis/models/common/Pagination.ts';
import { CommonError } from '@/amxis/models/common/APIError.ts';

export const useLoginLogsQuery = (
  condition: LoginLogRequest,
  options?: Omit<
    UseQueryOptions<
      PaginationResponse<LoginLog>,
      CommonError,
      PaginationResponse<LoginLog>,
      QueryKey
    >,
    'queryKey'
  >
) => {
  return useReactQuery({
    queryKey: LogQueryKeys.LoginLogs(condition),
    queryFn: () => {
      return findLoginLogs(condition);
    },
    ...options,
  });
};
