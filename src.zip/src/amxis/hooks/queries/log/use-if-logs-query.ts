import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { IfLog, IfLogRequest } from '@/amxis/models/admin/IfLog.ts';
import { findIfLogs } from '@/amxis/apis/admin/ifLog.ts';
import { LogQueryKeys } from './log-query-keys.ts';
import { QueryKey, UseQueryOptions } from '@tanstack/react-query';
import { PaginationResponse } from '@/amxis/models/common/Pagination.ts';
import { CommonError } from '@/amxis/models/common/APIError.ts';

export const useIfLogsQuery = (
  condition: IfLogRequest,
  options?: Omit<
    UseQueryOptions<PaginationResponse<IfLog>, CommonError, PaginationResponse<IfLog>, QueryKey>,
    'queryKey'
  >
) => {
  return useReactQuery({
    queryKey: LogQueryKeys.IfLogs(condition),
    queryFn: () => {
      return findIfLogs(condition);
    },
    ...options,
  });
};
