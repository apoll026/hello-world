import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { MessageQueryKeys } from './message-query-keys.ts';
import { deployTranslatedMessages } from '@/amxis/apis/admin/TranslatedMessage.ts';

export const useDeployTranslatedMessagesQuery = (enabled = false) => {
  return useReactQuery({
    queryKey: MessageQueryKeys.deployTranslatedMessages(),
    queryFn: () => {
      return deployTranslatedMessages();
    },
    enabled: enabled,
  });
};
