import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { MessageQueryKeys } from './message-query-keys.ts';
import { MessageCondition } from '@/amxis/models/admin/Message.ts';
import { findMessagesMsgCtn } from '@/amxis/apis/admin/Message.ts';

export const useMessagesMsgCtnQuery = (condition: MessageCondition, enabled?: boolean) => {
  return useReactQuery({
    queryKey: MessageQueryKeys.messagesMsgCtn(condition),
    queryFn: () => {
      if (!condition || !condition.msgCtn) {
        return [];
      }
      return findMessagesMsgCtn(condition);
    },
    enabled: enabled,
  });
};
