import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { saveMessages } from '@/amxis/apis/admin/Message.ts';
import { Message } from '@/amxis/models/admin/Message.ts';

export const useSaveMessagesMutate = () => {
  return useReactMutation((messages: Message[]) => {
    return saveMessages(messages);
  });
};
