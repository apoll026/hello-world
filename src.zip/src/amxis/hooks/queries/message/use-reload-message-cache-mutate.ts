import { reloadMessages } from '@/amxis/apis/admin/Message.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';

export const useReloadMessageCacheMutate = () => {
  return useReactMutation(() => {
    return reloadMessages();
  });
};
