import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { MessageQueryKeys } from './message-query-keys.ts';
import { MessageCondition } from '@/amxis/models/admin/Message.ts';
import { findMessages } from '@/amxis/apis/admin/Message.ts';

export const useMessagesQuery = (condition: MessageCondition, enabled?: boolean) => {
  return useReactQuery({
    queryKey: MessageQueryKeys.messages(condition),
    queryFn: () => {
      return findMessages(condition);
    },
    enabled: enabled,
  });
};
