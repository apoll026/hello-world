import { modifyNoticeReply } from '@/amxis/apis/admin/NoticeReply.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { NoticeReplyUpdateRequest } from '@/amxis/models/admin/NoticeReply.ts';

function useUpdateNoticeReplyMutation() {
  return useReactMutation((replyUpdateRequest: NoticeReplyUpdateRequest) => {
    return modifyNoticeReply(replyUpdateRequest);
  });
}

export { useUpdateNoticeReplyMutation };
