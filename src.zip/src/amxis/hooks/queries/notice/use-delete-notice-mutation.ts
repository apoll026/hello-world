import { deleteNotice } from '@/amxis/apis/admin/Notice.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';

function useDeleteNoticeMutation() {
  return useReactMutation((No: string) => {
    return deleteNotice(No);
  });
}

export { useDeleteNoticeMutation };
