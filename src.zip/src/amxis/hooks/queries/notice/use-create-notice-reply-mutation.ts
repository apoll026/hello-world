import { createNoticeReply } from '@/amxis/apis/admin/NoticeReply.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { NoticeReplyRequest } from '@/amxis/models/admin/NoticeReply.ts';

function useCreateNoticeReplyMutation() {
  return useReactMutation((bbsReplyRequest: NoticeReplyRequest) => {
    return createNoticeReply(bbsReplyRequest);
  });
}

export { useCreateNoticeReplyMutation };
