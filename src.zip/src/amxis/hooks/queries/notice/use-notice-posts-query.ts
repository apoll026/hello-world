import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { NoticeCondition } from '@/amxis/models/admin/Notice.ts';
import { NoticeQueryKeys } from './notice-query-keys.ts';
import { findNoticePosts } from '@/amxis/apis/admin/Notice.ts';

function useNoticePostsQuery(condition: NoticeCondition = {}) {
  return useReactQuery({
    queryKey: NoticeQueryKeys.Posts(condition),
    queryFn: () => {
      return findNoticePosts(condition);
    },
  });
}

export { useNoticePostsQuery };
// /* 목록 DropDown Filter조건 조회 */
// export function useBbsFilterQuery(codeGropWords: string) {
//   return useReactQuery({
//     queryKey: NoticeQueryKeys.CmnCds(codeGropWords),
//     queryFn: () => {
//       return getFilterCodes(codeGropWords);
//     },
//   });
// }
