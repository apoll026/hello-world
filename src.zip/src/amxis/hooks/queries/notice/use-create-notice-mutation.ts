import { createNotice } from '@/amxis/apis/admin/Notice.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { NoticePostRequest } from '@/amxis/models/admin/Notice.ts';

function useCreateNoticeMutation() {
  return useReactMutation((notice: NoticePostRequest) => {
    return createNotice(notice);
  });
}

export { useCreateNoticeMutation };
