import { findNoticePopupPost } from '@/amxis/apis/admin/Notice.ts';
import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { NoticeQueryKeys } from './notice-query-keys.ts';

function useNoticePopupPostQuery() {
  return useReactQuery({
    queryKey: NoticeQueryKeys.PopupPost(),
    queryFn: () => findNoticePopupPost(),
  });
}

export { useNoticePopupPostQuery };
