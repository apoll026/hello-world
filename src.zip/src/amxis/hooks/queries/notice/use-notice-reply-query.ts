import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { NoticeQueryKeys } from './notice-query-keys.ts';
import { useLoading } from '@/amxis/components/loader';
import { getNoticeReplyList } from '@/amxis/apis/admin/NoticeReply.ts';

/* 댓글 목록 조회 조회 */
export function useNoticeReplyQuery(No: string) {
  const { openLoading } = useLoading();
  return useReactQuery({
    queryKey: NoticeQueryKeys.Reply(No),
    queryFn: async () => {
      openLoading(true);
      const result = await getNoticeReplyList(No);
      openLoading(false);
      return result;
    },
  });
}
