import { removeNoticeReply } from '@/amxis/apis/admin/NoticeReply.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';

function useDeleteNoticeReplyMutation() {
  return useReactMutation(
    ({ noticeNo, noticeReNo }: { noticeNo: string; noticeReNo: number | string }) => {
      return removeNoticeReply(noticeNo, noticeReNo);
    }
  );
}

export { useDeleteNoticeReplyMutation };
