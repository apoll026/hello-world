import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { NoticeQueryKeys } from './notice-query-keys.ts';
import { findNoticePost } from '@/amxis/apis/admin/Notice.ts';

function useNoticePostDetailQuery(bbmNo: string) {
  return useReactQuery({
    queryKey: NoticeQueryKeys.Post(bbmNo),
    queryFn: () => {
      return findNoticePost(bbmNo);
    },
  });
}

export { useNoticePostDetailQuery };
