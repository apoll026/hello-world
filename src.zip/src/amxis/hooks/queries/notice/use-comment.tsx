import { useState } from 'react';
import useSessionStore from '@/amxis/stores/useSessionStore.ts';
import { Comment, CommentUser, CommentPermission } from '@amxis/design-system';
import { userLangDept, userLangEmp } from '@/amxis/utils/lang-code-util.ts';

const useComment = () => {
  const session = useSessionStore(); //세션
  //comment State
  const [comments, setComments] = useState<Comment[]>([]);
  const commentUser: CommentUser = {
    // 현재 사용자 정보
    id: session.mailId,
    name: userLangEmp(session), //session.empName + ' ' + session.jpsNm,
    department: userLangDept(session),
    avatarContentType: 'icon-inversed',
    avatarOnClick: (e) => handleClickAvatar(session.mailId),
  };

  // Recursive function to delete a comment or reply by ID
  const operateOnCommentById = (
    commentId: number | string,
    commentsArray: Comment[],
    operation: (comment: Comment) => Comment
  ): Comment[] => {
    return commentsArray.map((comment) => {
      if (comment.id === commentId) {
        // Perform the specified operation on the comment
        return operation(comment);
      }

      if (comment.replies && comment.replies.length > 0) {
        // Check and recursively operate in sub-comments
        comment.replies = operateOnCommentById(commentId, comment.replies, operation);
      }

      return comment;
    });
  };

  /**
   * 대댓글 작성화면 제거 함수
   *
   * @param {number | string} commentId
   * @param {Comment[]} commentsArray
   * @returns {booleam}
   */
  const deleteCommentById = (commentId: number | string, commentsArray: Comment[]): Comment[] => {
    return commentsArray.reduce((acc, comment) => {
      if (comment.id === commentId) {
        // Comment found, skip it to exclude it from the result array
        return acc;
      }

      if (comment.replies && comment.replies.length > 0) {
        // Check and recursively delete in sub-comments
        comment.replies = deleteCommentById(commentId, comment.replies);
        // If there are no more sub-comments after deletion, remove the 'replies' property
        if (comment.replies.length === 0) {
          delete comment.replies;
        }
      }
      return [...acc, comment];
    }, [] as Comment[]);
  };

  /**
   * 아바타 클릭시 팝업 함수
   *
   * @param {any} e
   * @param {any} userId
   * @returns {void}
   */
  const handleClickAvatar = (mailId) => {
    if (mailId) {
      return <></>;
    }
  };
  const popupCenter = ({ url, title, w, h }) => {
    // Fixes dual-screen position                             Most browsers      Firefox
    const dualScreenLeft = window.screenLeft !== undefined ? window.screenLeft : window.screenX;
    const dualScreenTop = window.screenTop !== undefined ? window.screenTop : window.screenY;

    const width = window.innerWidth
      ? window.innerWidth
      : document.documentElement.clientWidth
      ? document.documentElement.clientWidth
      : screen.width;
    const height = window.innerHeight
      ? window.innerHeight
      : document.documentElement.clientHeight
      ? document.documentElement.clientHeight
      : screen.height;

    const systemZoom = width / window.screen.availWidth;
    const left = (width - w) / 2 / systemZoom + dualScreenLeft;
    const top = (height - h) / 2 / systemZoom + dualScreenTop;

    const newWindow = window.open(
      url,
      title,
      `
      scrollbars=yes,
      width=${w / systemZoom}, 
      height=${h / systemZoom}, 
      top=${top}, 
      left=${left}
      `
    );

    if (newWindow) newWindow.focus();
  };

  /**
   * 대댓글 작성화면이 이미 있는지 확인하는 함수
   *
   * @param {Comment[]} commentList
   * @returns {boolean}
   */
  function hasReplyComment(commentList: Comment[]): boolean {
    let hasReComment = false;
    commentList.map((comment) => {
      comment.replies?.map((reply) => {
        if (reply.date === undefined) {
          hasReComment = true;
        }
      });
    });
    return hasReComment;
  }

  /**
   * 댓글 수정, 삭제 버튼 권한 함수
   * 사용자의 댓글 수정, 삭제 버튼 권한에 맞춰 버튼을 보여주는 함수
   * @param {boolean} isReEditBtnAuth
   * @param {boolean} isReDeltBtnAuth
   * @returns {CommentPermission[]}
   */
  function RePermissionsAuth(
    isReEditBtnAuth: boolean,
    isReDeltBtnAuth: boolean
  ): CommentPermission[] {
    if (isReEditBtnAuth === true && isReDeltBtnAuth === true) {
      return ['edit', 'delete']; //모든 권한 있음
    } else if (isReEditBtnAuth === false && isReDeltBtnAuth === true) {
      return ['delete']; //수정권한만 있음
    } else if (isReEditBtnAuth === true && isReDeltBtnAuth === false) {
      return ['edit']; //삭제권한만 있음
    } else {
      return [];
    }
  }

  return {
    comments,
    commentUser,
    setComments,
    handleClickAvatar,
    deleteCommentById,
    hasReplyComment,
    operateOnCommentById,
    RePermissionsAuth,
    userLangEmp,
    userLangDept,
  };
};
export default useComment;
