import { modifyNotice } from '@/amxis/apis/admin/Notice.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { NoticePostUpdateRequest } from '@/amxis/models/admin/Notice.ts';

function useUpdateNoticeMutation() {
  return useReactMutation((bbs: NoticePostUpdateRequest) => {
    return modifyNotice(bbs);
  });
}

export { useUpdateNoticeMutation };
