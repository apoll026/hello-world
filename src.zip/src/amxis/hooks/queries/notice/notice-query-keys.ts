import { NoticeCondition } from '@/amxis/models/admin/Notice.ts';

export const NoticeQueryKeys = {
  key: ['notice'] as const,
  Posts: (condition: NoticeCondition) => [...NoticeQueryKeys.key, 'Posts', condition] as const,
  Post: (bbmNo: string) => [...NoticeQueryKeys.key, 'Post', bbmNo] as const,
  CmnCds: (codeGropWords: string) => [...NoticeQueryKeys.key, codeGropWords] as const,
  Reply: (bbmNo: string) => [...NoticeQueryKeys.key, 'Reply', bbmNo] as const,
  PopupPost: () => [...NoticeQueryKeys.key, 'PopupPost'] as const,
};
