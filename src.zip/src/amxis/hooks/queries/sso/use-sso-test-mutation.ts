import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { testSsoToken } from '@/amxis/apis/Sso.ts';

export const useSsoTestMutation = () => {
  return useReactMutation((token: string) => {
    return testSsoToken(token);
  });
};
