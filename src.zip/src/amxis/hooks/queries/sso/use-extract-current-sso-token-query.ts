import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { extractCurrentSsoToken } from '@/amxis/apis/Sso.ts';

export const useExtractCurrentSsoTokenQuery = (enabled: boolean = false) => {
  return useReactQuery({
    queryKey: ['sso', 'current-token'],
    queryFn: () => extractCurrentSsoToken(),
    enabled,
    staleTime: 0,
  });
};
