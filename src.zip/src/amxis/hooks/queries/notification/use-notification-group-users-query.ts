import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { getNotificationGroupUsers } from '@/amxis/apis/admin/Notification.ts';
import { NotificationQueryKeys } from '@/amxis/hooks/queries/notification/notification-query-keys.ts';

export const useNotificationGroupUsersQuery = (ntdkId: string) => {
  return useReactQuery({
    queryKey: NotificationQueryKeys.notificationGroupUsers(ntdkId),
    queryFn: () => {
      return getNotificationGroupUsers(ntdkId);
    },
    enabled: Boolean(ntdkId),
  });
};
