import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { getNotificationGroupDivisions } from '@/amxis/apis/admin/Notification.ts';
import { NotificationQueryKeys } from '@/amxis/hooks/queries/notification/notification-query-keys.ts';

export const useNotificationGroupDivisionsQuery = () => {
  return useReactQuery({
    queryKey: NotificationQueryKeys.notificationGroupDivisions(),
    queryFn: () => {
      return getNotificationGroupDivisions();
    },
  });
};
