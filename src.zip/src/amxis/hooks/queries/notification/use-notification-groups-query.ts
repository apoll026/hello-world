import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { getNotificationGroups } from '@/amxis/apis/admin/Notification.ts';
import { NotificationQueryKeys } from '@/amxis/hooks/queries/notification/notification-query-keys.ts';
import { NotificationCondition } from '@/amxis/models/admin/Notification.ts';

export const useNotificationGroupsQuery = ({ ntdkNm, ntdkId, useYn }: NotificationCondition) => {
  return useReactQuery({
    queryKey: NotificationQueryKeys.notificationGroups({ ntdkNm, ntdkId, useYn }),
    queryFn: () => {
      return getNotificationGroups({ ntdkNm, ntdkId, useYn });
    },
  });
};
