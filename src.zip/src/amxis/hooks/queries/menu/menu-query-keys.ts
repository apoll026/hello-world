import { MenuSearchCondition } from '@/amxis/pages/sample/sample-grid-manage/types/grid-manage.types.ts';

export const MenuQueryKeys = {
  key: ['menu'] as const,
  menuAll: (searchCondition?: MenuSearchCondition) => [...MenuQueryKeys.key, 'menuAll', ...(searchCondition ? [searchCondition] : [])] as const,
};
