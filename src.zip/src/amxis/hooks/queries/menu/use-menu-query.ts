import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { MenuQueryKeys } from './menu-query-keys.ts';
import { getAllMenus } from '@/amxis/apis/admin/MenuApi.ts';
import { MenuSearchCondition } from '@/amxis/pages/sample/sample-grid-manage/types/grid-manage.types.ts';
import { UseQueryOptions, QueryKey } from '@tanstack/react-query';
import { ErrorResponse } from '@/amxis/models/common/APIError.ts';

export const useMenuAllQuery = <TData = any>(
  searchCondition?: MenuSearchCondition,
  options?: Omit<UseQueryOptions<any, ErrorResponse, TData, QueryKey>, 'queryKey' | 'queryFn'>
) => {
  return useReactQuery({
    queryKey: MenuQueryKeys.menuAll(searchCondition),
    queryFn: () => {
      return getAllMenus(searchCondition);
    },
    ...options,
  });
};
