import { devOutLogin } from '@/amxis/apis/Session.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';

type OutLoginParams = {
  cmpnNum: string;
  serialNumberHex: string;
  langCd: string
};

function useOutLoginMutation() {
  return useReactMutation(({ cmpnNum, serialNumberHex, langCd }: OutLoginParams) => {
    console.log("useOutLoginMutation ", serialNumberHex);
    return devOutLogin(cmpnNum, serialNumberHex, langCd);
  });
}

export { useOutLoginMutation };

