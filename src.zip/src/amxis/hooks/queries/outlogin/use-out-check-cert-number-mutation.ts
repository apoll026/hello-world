import { checkCmpnNumber } from '@/amxis/apis/Session.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';

type CheckOutCertNumberParams = {
  cmpnId: string;
};

function useCheckOutCertNumberMutation() {
  return useReactMutation(({ cmpnId }: CheckOutCertNumberParams) => {
    return checkCmpnNumber(cmpnId);
  });
}

export { useCheckOutCertNumberMutation };
