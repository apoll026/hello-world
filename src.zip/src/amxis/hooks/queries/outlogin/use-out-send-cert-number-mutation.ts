import { sendCmpnNumber } from '@/amxis/apis/Session.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';

type SendOutCertNumberParams = {
  cmpnId: string;
};

function useOutSendCertNumberMutation() {
  return useReactMutation(({ cmpnId }: SendOutCertNumberParams) => {
    return sendCmpnNumber(cmpnId);
  });
}

export { useOutSendCertNumberMutation };
