import { insertRoleDepartment } from '@/amxis/apis/admin/RoleDepartment.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { RoleDepartmentMutateRequest } from '@/amxis/models/admin/Role.ts';

export const usePostRoleDepartmentMutate = () => {
  return useReactMutation((roleDepartmentMutateRequest: RoleDepartmentMutateRequest) => {
    return insertRoleDepartment(roleDepartmentMutateRequest);
  });
};
