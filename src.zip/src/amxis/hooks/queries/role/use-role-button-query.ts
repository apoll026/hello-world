import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { RoleQueryKeys } from '@/amxis/hooks/queries/role/role-query-keys.ts';
import { getRoleButtonCodes } from '@/amxis/apis/admin/RoleButton.ts';

export type CommonCodeSearchParams = {
  btnGrCd: string;
  btnCd: string;
  useYn: string;
};

export const useRoleButtonCodesQuery = ({ btnGrCd, btnCd, useYn }: CommonCodeSearchParams) => {
  return useReactQuery({
    queryKey: RoleQueryKeys.roleButtonCodes({ btnGrCd, btnCd, useYn }),
    queryFn: () => {
      return getRoleButtonCodes(btnGrCd, btnCd, useYn);
    },
  });
};