import { deleteRoleDepartment } from '@/amxis/apis/admin/RoleDepartment.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { RoleDepartmentMutateRequest } from '@/amxis/models/admin/Role.ts';

export const useDeleteRoleDepartmentMutate = () => {
  return useReactMutation((roleDepartmentMutateRequest: RoleDepartmentMutateRequest) => {
    return deleteRoleDepartment(roleDepartmentMutateRequest);
  });
};
