import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { RoleQueryKeys } from './role-query-keys.ts';
import { getRoles } from '@/amxis/apis/admin/Role.ts';
import { UseQueryOptions } from '@tanstack/react-query';
import { Role } from '@/amxis/models/admin/Role.ts';

export const useRolesQuery = (condition: string, options?: Omit<UseQueryOptions<Role[], Error>, 'queryKey'>) => {
  return useReactQuery({
    queryKey: RoleQueryKeys.roles(condition),
    queryFn: () => {
      return getRoles(condition);
    },
    ...options,
  });
};
