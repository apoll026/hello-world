import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { RoleButtonCode } from '@/amxis/models/admin/RoleButtonCode.ts';
import { isDuplicatedRoleButtonCodes, setRoleButtonCds } from '@/amxis/apis/admin/RoleButton.ts';

export const useRoleButtonCodesMutation = () => {
  return useReactMutation((roleButtons: RoleButtonCode[]) => {
    return setRoleButtonCds(roleButtons);
  });
};

export const useRoleButtonDuplicate = () => {
  return useReactMutation((roleButtons: RoleButtonCode[]) => {
    return isDuplicatedRoleButtonCodes(roleButtons);
  });
}