import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { RoleQueryKeys } from './role-query-keys.ts';
import { UseQueryOptions } from '@tanstack/react-query';
import { getRoleEmps } from '@/amxis/apis/admin/RoleEmployee.ts';

export const useRoleEmployeesQuery = (
  condition: string,
  options?: Omit<UseQueryOptions, 'queryKey'>
) => {
  return useReactQuery({
    queryKey: RoleQueryKeys.roleEmployees(condition),
    queryFn: () => {
      return getRoleEmps(condition);
    },
    ...options,
  });
};
