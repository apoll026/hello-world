import { setRoles } from '@/amxis/apis/admin/Role.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { Role } from '@/amxis/models/admin/Role.ts';

export const useSaveRolesMutate = () => {
  return useReactMutation((roles: Role[]) => {
    return setRoles(roles);
  });
};
