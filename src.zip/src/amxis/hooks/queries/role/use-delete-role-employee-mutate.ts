import { deleteRoleEmps } from '@/amxis/apis/admin/RoleEmployee.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { RoleEmployeeMutateRequest } from '@/amxis/models/admin/Role.ts';

export const useDeleteRoleEmployeeMutate = () => {
  return useReactMutation((roleEmployeeMutateRequest: RoleEmployeeMutateRequest) => {
    return deleteRoleEmps(roleEmployeeMutateRequest);
  });
};
