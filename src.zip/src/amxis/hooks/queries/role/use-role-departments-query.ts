import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { RoleQueryKeys } from './role-query-keys.ts';
import { UseQueryOptions } from '@tanstack/react-query';
import { getRoleDepartment } from '@/amxis/apis/admin/RoleDepartment.ts';

export const useRoleDepartmentsQuery = (
  condition: string,
  options?: Omit<UseQueryOptions, 'queryKey'>
) => {
  return useReactQuery({
    queryKey: RoleQueryKeys.roleDepartments(condition),
    queryFn: () => {
      return getRoleDepartment(condition);
    },
    ...options,
  });
};
