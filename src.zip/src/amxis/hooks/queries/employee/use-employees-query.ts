import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { EmployeeQueryKeys } from './employee-query-keys.ts';
import { getEmployeeBySearchCondition } from '@/amxis/apis/admin/Employee.ts';

type UseEmployeesQueryProps = {
  searchItem?: string;
  deptCd?: string;
  deptNm?: string;
  empName?: string;
};

function useEmployeesQuery({
  searchItem = '',
  deptCd = '',
  deptNm = '',
  empName = '',
}: UseEmployeesQueryProps) {
  return useReactQuery({
    queryKey: EmployeeQueryKeys.employees({ searchItem, deptCd, deptNm, empName }),
    queryFn: () => getEmployeeBySearchCondition(searchItem, deptCd, deptNm, empName),
    // enabled: Boolean(deptCd),
  });
}

export { useEmployeesQuery };
