export const EmployeeQueryKeys = {
  key: ['employee'] as const,
  employees: (params: { searchItem: string; deptCd: string; deptNm: string; empName: string }) =>
    [...EmployeeQueryKeys.key, { ...params }] as const,
};
