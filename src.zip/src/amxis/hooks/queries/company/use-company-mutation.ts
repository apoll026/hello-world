import { devCompanyVerify } from '@/amxis/apis/Session.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';

type CompanyParams = {
  signValue: string;
};

function useCompanyMutation() {
  return useReactMutation(({ signValue }: CompanyParams) => {
    return devCompanyVerify(signValue);
  });
}

export { useCompanyMutation };

