export const CompanyQueryKeys = {
  key: ['company'] as const,
  company: (params: { signValue: string; }) =>
    [...CompanyQueryKeys.key, { ...params }] as const,
};
