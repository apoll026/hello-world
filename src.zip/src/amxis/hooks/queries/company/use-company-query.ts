import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { CompanyQueryKeys } from './company-query-keys.ts';
import { getCompanyBySearchCondition } from '@/amxis/apis/admin/Company.ts';

type UseCompanyQueryProps = {
  signValue?: string;
};

function useCompanyQuery({
  signValue = '',
}: UseCompanyQueryProps) {
  return useReactQuery({
    queryKey: CompanyQueryKeys.company({ signValue }),
    queryFn: () => getCompanyBySearchCondition(signValue),
    // enabled: Boolean(deptCd),
  });
}

export { useCompanyQuery };
