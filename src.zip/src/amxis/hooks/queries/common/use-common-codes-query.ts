import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { getCommonCodes } from '@/amxis/apis/admin/CommonCode.ts';
import { CommonQueryKeys } from '@/amxis/hooks/queries/common/common-query-keys.ts';
import { QueryKey, UseQueryOptions } from '@tanstack/react-query';
import { CommonError } from '@/amxis/models/common/APIError.ts';
import { CommonResponse } from '@/amxis/models/common/RestApi.ts';
import { CommonCode } from '@/amxis/models/admin/CommonCode.ts';

export const useCommonCodesQuery = (
  cmnGrCd: string,
  options?: UseQueryOptions<
    CommonResponse<CommonCode[]>,
    CommonError,
    CommonResponse<CommonCode[]>,
    QueryKey
  >
) => {
  return useReactQuery({
    queryKey: CommonQueryKeys.commonCode(cmnGrCd),
    queryFn: () => {
      return getCommonCodes(cmnGrCd);
    },
    ...{ options },
  });
};
