import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { CommonQueryKeys } from '@/amxis/hooks/queries/common/common-query-keys.ts';
import { getCommonCodeNames } from '@/amxis/apis/common/CommonApi.ts';

export const useCommonCodeNamesQuery = (cmnGrCd: string) => {
  return useReactQuery({
    queryKey: CommonQueryKeys.commonCodeNames(cmnGrCd),
    queryFn: () => {
      return getCommonCodeNames(cmnGrCd);
    },
  });
};
