import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { getCommonCodeGroups, getCommonCodeGroupsPersonalSearch } from '@/amxis/apis/admin/CommonCode.ts';
import { CommonQueryKeys } from '@/amxis/hooks/queries/common/common-query-keys.ts';

export type CommonCodeSearchParams = {
  cmnGrCd: string;
  cmnCd: string;
  useYn: string;
  COMMON_PERSONAL_SEARCH_YN?: string;
  searchFormId?: string;
};

export const useCommonCodeGroupsQuery = ({ cmnGrCd, cmnCd, useYn }: CommonCodeSearchParams) => {
  return useReactQuery({
    queryKey: CommonQueryKeys.commonCodeGroups({ cmnGrCd, cmnCd, useYn }),
    queryFn: () => {
      return getCommonCodeGroups(cmnGrCd, cmnCd, useYn);
    },
  });
};

export const useCommonCodeGroupsPersonalSearchQuery = ({ cmnGrCd, cmnCd, useYn, COMMON_PERSONAL_SEARCH_YN, searchFormId }: CommonCodeSearchParams) => {
  return useReactQuery({
    queryKey: CommonQueryKeys.commonCodeGroups({ cmnGrCd, cmnCd, useYn, COMMON_PERSONAL_SEARCH_YN, searchFormId }),
    queryFn: () => {
      return getCommonCodeGroupsPersonalSearch(cmnGrCd, cmnCd, useYn, COMMON_PERSONAL_SEARCH_YN, searchFormId);
    },
  });
};
