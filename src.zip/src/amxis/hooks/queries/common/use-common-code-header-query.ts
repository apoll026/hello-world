import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { getCommonCodeHeader } from '@/amxis/apis/admin/CommonCode.ts';
import { CommonQueryKeys } from '@/amxis/hooks/queries/common/common-query-keys.ts';

export const useCommonCodeHeaderQuery = (cmnGrCd: string) => {
  return useReactQuery({
    queryKey: CommonQueryKeys.commonCodeHeader(cmnGrCd),
    queryFn: () => {
      return getCommonCodeHeader(cmnGrCd);
    },
  });
};
