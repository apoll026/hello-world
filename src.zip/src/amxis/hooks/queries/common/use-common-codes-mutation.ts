import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { setCommonCodes } from '@/amxis/apis/admin/CommonCode.ts';
import { CommonCode } from '@/amxis/models/admin/CommonCode.ts';

export const useCommonCodesMutation = () => {
  return useReactMutation((commonCodes: CommonCode[]) => {
    return setCommonCodes(commonCodes);
  });
};
