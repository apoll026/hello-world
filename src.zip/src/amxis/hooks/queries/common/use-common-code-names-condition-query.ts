import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { getCommonCodeNamesCondition } from '@/amxis/apis/admin/CommonCode.ts';
import { CommonQueryKeys } from '@/amxis/hooks/queries/common/common-query-keys.ts';
import { CommonCodeCondition } from '@/amxis/models/common/CommonCode.ts';

export function useCommonCodeNamesConditionQuery(condition: CommonCodeCondition) {
  return useReactQuery({
    queryKey: CommonQueryKeys.commonCodeNamesCondition(condition),
    queryFn: () => {
      return getCommonCodeNamesCondition(condition);
    },
  });
}
