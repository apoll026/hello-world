import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { setCommonCodeGroups } from '@/amxis/apis/admin/CommonCode.ts';
import { CommonCodeGroup } from '@/amxis/models/admin/CommonCode.ts';

export const useCommonCodeGroupsMutation = () => {
  return useReactMutation((codeGroups: CommonCodeGroup[]) => {
    return setCommonCodeGroups(codeGroups);
  });
};
