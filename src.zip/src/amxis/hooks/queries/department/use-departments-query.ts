import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { DepartmentQueryKeys } from './department-query-keys.ts';
import { getDepartments } from '@/amxis/apis/admin/Department.ts';

type UseDepartmentsQueryProps = {
  searchItem?: string;
  deptName?: string;
};

function useDepartmentsQuery({ searchItem = '', deptName = '' }: UseDepartmentsQueryProps) {
  return useReactQuery({
    queryKey: DepartmentQueryKeys.departments({ searchItem, deptName }),
    queryFn: () => getDepartments(searchItem, deptName),
  });
}

export { useDepartmentsQuery };
