export const DepartmentQueryKeys = {
  key: ['department'] as const,
  departments: (params: { searchItem: string; deptName: string }) =>
    [...DepartmentQueryKeys.key, { ...params }] as const,
};
