import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { saveGridConfig } from '@/amxis/apis/admin/GridConfigApi.ts';
import {
  GridConfigInfo,
} from '@/amxis/pages/sample/sample-grid-manage/types/grid-manage.types.ts';

function useGridConfigMutation() {
  return useReactMutation((configList: GridConfigInfo[]) => {
    return saveGridConfig(configList);
  })
}

export { useGridConfigMutation };