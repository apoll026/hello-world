import { useReactQuery } from '@/amxis/hooks/use-react-query.ts';
import { GridConfigQueryKeys } from '@/amxis/hooks/queries/grid-config/grid-config-query-keys.ts';
import { findGridConfigs } from '@/amxis/apis/admin/GridConfigApi.ts';

function useGridConfigQuery(
  pgmId: string,
) {
  return useReactQuery({
    queryKey: GridConfigQueryKeys.gridConfigByPgmId(pgmId),
    queryFn: () => {
      return findGridConfigs(pgmId);
    },
    enabled: !!pgmId,
  });
}

export { useGridConfigQuery };