export const GridConfigQueryKeys = {
  key: ['gridConfig'] as const,
  gridConfigByPgmId: (pgmId: string) => [GridConfigQueryKeys.key, 'byPgmId', pgmId] as const,
};
