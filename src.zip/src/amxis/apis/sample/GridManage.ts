import { PaginationResponse } from '@/amxis/models/common/Pagination';
import {
  CommonRequest,
  Method,
  ServiceName,
  CommonResponse,
  DmlResponse,
} from '@/amxis/models/common/RestApi';
import {
  GridManageConditionVO,
  GridManageRequestVO,
  GridManageResponseVO,
} from '@/amxis/models/models/sample/grid-manage';
import { callApi } from '@/amxis/utils/ApiUtil';

export const findGridManage = async (condition: GridManageConditionVO) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/sample/grid-manage`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({ ...condition }),
  };
  const response: CommonResponse<PaginationResponse<GridManageResponseVO>> = await callApi(request);

  return (
    response.successOrNot === 'Y' ? response.data : null
  ) as PaginationResponse<GridManageResponseVO>;
};

export const saveGridManageData = async (saveData: GridManageRequestVO[]) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/sample/grid-manage`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: saveData,
  };
  const response: CommonResponse<DmlResponse> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as DmlResponse;
};
