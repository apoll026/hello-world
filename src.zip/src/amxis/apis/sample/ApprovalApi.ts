import {
  ApprovalMasterLineRequestVO,
  ApprovalMasterLineResponseVo,
  CommonReturnData,
} from '@/amxis/models/common/Approver.ts';
import { CommonRequest, CommonResponse, Method, ServiceName } from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';

export const saveApprovalLine = async (
  approvalMasterLine: ApprovalMasterLineRequestVO
): Promise<string> => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/approval-sample/save`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: approvalMasterLine,
  };
  const response: CommonResponse<string> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as string;
};

export const requestApproval = async (reqNo: string): Promise<CommonReturnData> => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/approval/request`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({ reqNo: reqNo }),
  };
  const response: CommonResponse<CommonReturnData> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as CommonReturnData;
};

export const retrieveApproval = async (reqNo: string): Promise<ApprovalMasterLineResponseVo> => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/approval-sample/retrieve`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({ reqNo: reqNo }),
  };
  const response: CommonResponse<ApprovalMasterLineResponseVo> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as ApprovalMasterLineResponseVo;
};

export const requestCancelApproval = async (
  reqNo: string,
  apprMessage: string
): Promise<CommonReturnData> => {
  const request: CommonRequest = {
    method: Method.PUT,
    url: `/v1/approval/cancel?reqNo=${reqNo}&apprMessage=${apprMessage}`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };
  const response: CommonResponse<CommonReturnData> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as CommonReturnData;
};
