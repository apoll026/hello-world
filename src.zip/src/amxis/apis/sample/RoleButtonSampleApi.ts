import { CommonRequest, CommonResponse, Method, ServiceName } from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';

export const saveSampleTest1 = async () => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/sample/role-button1`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };
  const response: CommonResponse = await callApi(request);

  return response.successOrNot == 'Y' ? response : null;
};

export const saveSampleTest2 = async () => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/sample/role-button2`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };
  const response: CommonResponse = await callApi(request);

  return response.successOrNot == 'Y' ? response : null;
};

export const saveSampleTest3 = async () => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/sample/role-button3`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };
  const response: CommonResponse = await callApi(request);

  return response.successOrNot == 'Y' ? response : null;
};