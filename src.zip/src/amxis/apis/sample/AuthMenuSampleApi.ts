import { AuthMenuRequest } from '@/amxis/models/admin/Menu';
import {
  CommonRequest,
  CommonResponse,
  DmlResponse,
  Method,
  ServiceName,
} from '@/amxis/models/common/RestApi';
import { callApi } from '@/amxis/utils/ApiUtil';

export const upsertAuthMenu = async (authMenuRequest: AuthMenuRequest) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/sample/auth-menu`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: authMenuRequest,
  };

  const response: CommonResponse<Number> = await callApi(request);

  return response;
};
