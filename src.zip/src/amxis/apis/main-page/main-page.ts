import { CommonRequest, CommonResponse, Method, ServiceName } from '@/amxis/models/common/RestApi';
import {
  MainBbsDataResponse,
  MainNoticeDataResponse,
  MainPageCountDataResponse,
} from '@/amxis/models/main-page/main-page';
import { callApi } from '@/amxis/utils/ApiUtil';

export const findMainCountData = async (empNo: string) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/main/count`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({ empNo: empNo }),
  };

  const response: CommonResponse<MainPageCountDataResponse> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as MainPageCountDataResponse;
};

export const findMainNoticeData = async () => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/main/notice`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };

  const response: CommonResponse<MainNoticeDataResponse[]> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as MainNoticeDataResponse[];
};

export const findMainBbsData = async () => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/main/bbs`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };

  const response: CommonResponse<MainBbsDataResponse[]> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as MainBbsDataResponse[];
};
