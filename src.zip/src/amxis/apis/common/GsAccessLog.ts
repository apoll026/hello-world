import { CommonRequest, CommonResponse, Method, ServiceName } from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';

export const callGsAccessLog = async (
  prevUrl?: string,
  currentUrl?: string,
) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/log/gs-menu-access`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: {
      prevUrl: prevUrl ?? '',
      currentUrl: currentUrl ?? '',
    },
  };
  const response: CommonResponse<any> = await callApi(request);

  return response;
};
