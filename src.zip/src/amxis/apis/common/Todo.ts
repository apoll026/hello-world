import {CommonRequest, CommonResponse, Method, ServiceName} from '@/amxis/models/common/RestApi.ts';
import {callApi} from '@/amxis/utils/ApiUtil.ts';
import {IFResult} from "@/amxis/models/common/IFResult.ts";

export const sendPostTodo = async (
    userId?: string,
    title?: string,
    workerId?: string,
    dueDate?: string,
    isTermless?: string,
    url?: string,
    systemCode?: string,
    subworkCode?: string,
    itemId?: string
) => {
    const request: CommonRequest = {
        method: Method.POST,
        url: `/v1/todo/insertExternalTodo`,
        serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
        bodyParams: {
            userId: userId ?? '',
            title: title ?? '',
            workerId: workerId ?? '',
            dueDate: dueDate ?? '',
            isTermless: isTermless ?? '',
            url: url ?? '',
            systemCode: systemCode ?? '',
            subworkCode: subworkCode ?? '',
            itemId: itemId ?? '',
        },
    };
    const response: CommonResponse<IFResult> = await callApi(request);

    return response;
};
