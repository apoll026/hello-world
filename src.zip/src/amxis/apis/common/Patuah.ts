import {CommonRequest, CommonResponse, Method, ServiceName} from 'amxis/models/common/RestApi';
import {callApi} from 'amxis/utils/ApiUtil';
import { PatuahResult } from '@/amxis/models/common/PatuahResult.ts';

export const callPatuahApi = async (
    reqCorpNum?: string,
) => {
    const request: CommonRequest = {
        method: Method.POST,
        url: `/v1/sample/patuahTest`,
        serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
        bodyParams: {
          reqCorpNum: reqCorpNum ?? '',
        },
    };
    const response: CommonResponse<PatuahResult> = await callApi(request);

    return response;
};
