import { CommonRequest, CommonResponse, Method, ServiceName } from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';
import { FilePreSignedUrl } from '@/amxis/models/common/FilePreSignedUrl.ts';

export const getUploadPreSignedUrl = async (
    atchFileGrId?: string,
    fileSize?: string,
    originalFileName?: string,
    fileType?: string,
    atchFileTpCd?: string
) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/file/preSignedUploadUrl`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({
      atchFileGrId: atchFileGrId ?? '',
      fileSize: fileSize ?? '',
      originalFileName: originalFileName ?? '',
      fileType: fileType ?? '',
      atchFileTpCd: atchFileTpCd ?? '',
    }),
  };
  const response: CommonResponse<any> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as FilePreSignedUrl[];
};

export const getDownloadPreSignedUrl = async (
    atchFileGrId?: string,
    atchFileId?: string
) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/file/preSignedDownloadUrl`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({
      atchFileGrId: atchFileGrId ?? '',
      atchFileId: atchFileId ?? '',
    }),
  };
  const response: CommonResponse<any> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as FilePreSignedUrl;
};

export const getDownloadPreSignedUrlAll = async (
    atchFileGrId?: string,
) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/file/preSignedDownloadUrlAll`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({
      atchFileGrId: atchFileGrId ?? '',
    }),
  };
  const response: CommonResponse<any> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as FilePreSignedUrl[];
};
