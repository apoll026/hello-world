import {CommonRequest, CommonResponse, Method, ServiceName} from '@/amxis/models/common/RestApi.ts';
import {callApi} from '@/amxis/utils/ApiUtil.ts';
import {IFResult} from "@/amxis/models/common/IFResult.ts";

export const sendPostTalkSms = async (
    transferType?: string,
    systemName?: string,
    tranMsg?: string,
    tranPhone?: string,
    tranCallback?: string,
    tranDate?: string,
    attribute1?: string,
    attribute2?: string,
    attribute3?: string,
    attribute4?: string,
    attribute5?: string,
    attribute6?: string,
    attribute7?: string,
    attribute8?: string,
    attribute9?: string
) => {
    const request: CommonRequest = {
        method: Method.POST,
        url: `/v1/talk/sendTalkSms`,
        serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
        bodyParams: {
            transfer_type: transferType ?? '',
            system_name: systemName ?? '',
            tran_msg: tranMsg ?? '',
            tran_phone: tranPhone ?? '',
            tran_callback: tranCallback ?? '',
            tran_date: tranDate ?? '',
            attribute1: attribute1 ?? '',
            attribute2: attribute2 ?? '',
            attribute3: attribute3 ?? '',
            attribute4: attribute4 ?? '',
            attribute5: attribute5 ?? '',
            attribute6: attribute6 ?? '',
            attribute7: attribute7 ?? '',
            attribute8: attribute8 ?? '',
            attribute9: attribute9 ?? '',
        },
    };
    const response: CommonResponse<IFResult> = await callApi(request);

    return response;
};

export const sendPostTalkLms = async (
    transferTypeLms?: string,
    subject?: string,
    msg?: string,
    phone?: string,
    callback?: string,
    regdate?: string,
    id?: string,
    post?: string,
    etc1?: string,
    etc2?: string,
    etc3?: string,
    etc4?: string,
    etc5?: string,
) => {
    const request: CommonRequest = {
        method: Method.POST,
        url: `/v1/talk/sendTalkLms`,
        serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
        bodyParams: {
            transfer_type_lms: transferTypeLms ?? '',
            subject: subject ?? '',
            msg: msg ?? '',
            phone: phone ?? '',
            callback: callback ?? '',
            regdate: regdate ?? '',
            id: id ?? '',
            post: post ?? '',
            etc1: etc1 ?? '',
            etc2: etc2 ?? '',
            etc3: etc3 ?? '',
            etc4: etc4 ?? '',
            etc5: etc5 ?? '',
        },
    };
    const response: CommonResponse<IFResult> = await callApi(request);

    return response;
};
