import { PaginationResponse } from '@/amxis/models/common/Pagination';
import {
  CommonRequest,
  Method,
  ServiceName,
  CommonResponse,
  DmlResponse,
} from '@/amxis/models/common/RestApi';
import { callApi } from '@/amxis/utils/ApiUtil';
import {
  IBSheetSampleConditionVO, IBSheetSampleRequestVO,
  IBSheetSampleResponseVO,
} from '@/amxis/models/models/sample/Ibsheet-sample.ts';

export const findIBSheetSamples = async (condition: IBSheetSampleConditionVO) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/sample/ibsheet`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({ ...condition }),
  };
  const response: CommonResponse<PaginationResponse<IBSheetSampleResponseVO>> = await callApi(
    request
  );

  return (
    response.successOrNot === 'Y' ? response.data : null
  ) as PaginationResponse<IBSheetSampleResponseVO>;
};

export const saveIBSheetSampleData = async (saveData: IBSheetSampleRequestVO[]) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/sample/ibsheet`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: saveData,
  };
  const response: CommonResponse<DmlResponse> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as DmlResponse;
};
