import { CommonRequest, CommonResponse, Method, ServiceName } from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';

export interface SsoTestRequest {
  token: string;
}

export interface SsoTestResponse {
  isValid: boolean;
  userInfo?: {
    uid?: string;
    userId?: string;
    empNo?: string;
    userType?: string;
    locale?: string;
  };
  errorCode?: string;
  errorMessage?: string;
}

export const testSsoToken = async (token: string): Promise<CommonResponse<SsoTestResponse>> => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/sso/test`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: { token },
  };
  
  const response: CommonResponse<SsoTestResponse> = await callApi(request);
  return response;
};

export const extractCurrentSsoToken = async (): Promise<CommonResponse<{token: string}>> => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/sso/current-token`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };
  
  const response: CommonResponse<{token: string}> = await callApi(request);
  return response;
};
