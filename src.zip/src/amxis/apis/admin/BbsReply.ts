import {
  BbsReplyRequest,
  BbsReplyUpdateRequest,
  BbsReply,
} from '@/amxis/models/admin/BbsReply.ts';
import { CommonRequest, CommonResponse, Method, ServiceName } from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';
/* 댓글 목록 조회 */
export const getBbsReplyList = async (bbsNo: string) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/bbs/reply/${bbsNo}`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };
  const response = await callApi(request);
  return (
    response.successOrNot === 'Y' && response.data ? response.data : null
  ) as BbsReply[];
  //return response.successOrNot === 'Y' ? response.data : null;
};
export const createBbsReply = async (replyRequest: BbsReplyRequest) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/bbs/reply`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: replyRequest,
  };
  const response: CommonResponse = await callApi(request);

  return response.successOrNot === 'Y' ? true : false;
};

export const removeBbsReply = async (bbsNo: string, bbsReNo: number | string) => {
  const request: CommonRequest = {
    method: Method.DELETE,
    url: `/v1/bbs/reply/${bbsNo}/${bbsReNo}`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };
  const response: CommonResponse = await callApi(request);

  return response.successOrNot === 'Y' ? true : false;
};

export const modifyBbsReply = async (
  bbsReplyUpdateRequest: BbsReplyUpdateRequest
) => {
  const request: CommonRequest = {
    method: Method.PUT,
    url: `/v1/bbs/reply`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: bbsReplyUpdateRequest,
  };
  const response: CommonResponse = await callApi(request);

  return response.successOrNot === 'Y' ? true : false;
};
