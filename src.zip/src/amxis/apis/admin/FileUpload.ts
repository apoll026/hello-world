import {
  CommonRequest,
  CommonResponse,
  Method,
  ServiceName,
} from '@/amxis/models/common/RestApi.ts';
import { FileInfo, FileUploadResponse } from '@/amxis/models/admin/FileInfo.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';
import axios from 'axios';
import { FileId } from '@/amxis/models/admin/FileId.ts';

export const findFiles = async (atchFileGrId: string) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/files`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    headers: {},
    queryParams: new URLSearchParams({ atchFileGrId: atchFileGrId }),
  };
  const response: CommonResponse<FileInfo[]> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as FileInfo[];
};

export const uploadFiles = async (formData: FormData) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/file/upload`,
    headers: {
      'Content-Type': 'multipart/form-data',
    },
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: formData,
  };

  const response: CommonResponse<FileUploadResponse> = await callApi(request);

  return response.successOrNot === 'Y' ? response.data : null;
};

export const uploadFileWithNewGroupId = async (formData: FormData) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/file/upload/new`,
    headers: {
      'Content-Type': 'multipart/form-data',
    },
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: formData,
  };

  const response: CommonResponse<any> = await callApi(request);

  return response.successOrNot === 'Y' ? response.data : null;
};

export const modifyFiles = async (files: FileInfo[]) => {
  const request: CommonRequest = {
    method: Method.PUT,
    url: `/v1/files`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: files,
  };

  const response: CommonResponse<any> = await callApi(request);

  return response.successOrNot === 'Y' ? response.data : null;
};

export const modifyFilesToUnuseByGrIdAndFileId = async (files: FileId[]) => {
  const request: CommonRequest = {
    method: Method.PUT,
    url: `/v1/files/unuse`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: files,
  };

  const response: CommonResponse<any> = await callApi(request);

  return response.successOrNot === 'Y' ? response.data : null;
};

export const modifyFilesWithNewGroupId = async (atchFileGrId: string, files: FileInfo[]) => {
  const request: CommonRequest = {
    method: Method.PUT,
    url: `/v1/files/new`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: {
      atchFileGrId: atchFileGrId,
      files: files,
    },
  };

  const response: CommonResponse<any> = await callApi(request);

  return response.successOrNot === 'Y' ? response.data : null;
};

export const downloadFile = async (atchFileGrId: string, atchFileId: string) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/file/download`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({ atchFileGrId: atchFileGrId, atchFileId: atchFileId }),
  };

  const response = await callApi(request);

  return response.data;
};

export const downloadAllFiles = async (atchFileGrId: string) => {
  try {
    const response = await axios.get(
      `${process.env.API_BASE_URL}/api/v1/file/download/all?atchFileGrId=${atchFileGrId}`,
      {
        responseType: 'blob',
      }
    );

    const url = window.URL.createObjectURL(new Blob([response.data]));
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', atchFileGrId + '.zip');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  } catch (error) {
    console.log(error);
  }
};

export const uploadDextEditorFiles = async (formData: FormData) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/files/dext5editor-upload`,
    headers: {
      'Content-Type': 'multipart/form-data',
    },
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: formData,
  };

  const response: CommonResponse<string> = await callApi(request);

  return response; // 전체 response 객체 반환
};
