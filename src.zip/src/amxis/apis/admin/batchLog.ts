import { CommonRequest, CommonResponse, Method, ServiceName } from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';
import { PaginationResponse } from '@/amxis/models/common/Pagination.ts';
import { BatchLogRequest, BatchLog } from '@/amxis/models/admin/BatchLog.ts';

export const findBatchLogs = async (condition: BatchLogRequest) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/admin/batch-log`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({ ...condition }),
  };
  const response: CommonResponse<PaginationResponse<BatchLog>> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : []) as PaginationResponse<BatchLog>;
};
