import {
  NotificationDeptCondition,
  NotificationDeptGroup,
  NotificationDeptGroupDivision,
  NotificationDeptGroupUser,
} from '@/amxis/models/admin/NotificationDept.ts';
import { CommonRequest, CommonResponse, Method, ServiceName } from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';

export const getNotificationDeptGroups = async (
  NotificationDeptCondition: NotificationDeptCondition
) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/notificationDeptGroups`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({ ntdkDeptNm: NotificationDeptCondition.ntdkDeptNm ?? '' }),
  };
  const response: CommonResponse<NotificationDeptGroup[]> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as NotificationDeptGroup[];
};

export const getNotificationDeptGroupDivisions = async () => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/notificationDeptGroup/divisions`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };
  const response: CommonResponse<NotificationDeptGroupDivision[]> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as NotificationDeptGroupDivision[];
};

export const getNotificationDeptGroupUsers = async (ntdkDeptId: string) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/notificationDeptGroup/${ntdkDeptId}/users`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };
  const response: CommonResponse<NotificationDeptGroupUser[]> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as NotificationDeptGroupUser[];
};

export const saveNotificationDeptGroups = async (
  NotificationDeptGroups: NotificationDeptGroup[]
) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/notificationDeptGroups`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: NotificationDeptGroups,
  };
  const response: CommonResponse<any> = await callApi(request);

  return response.successOrNot === 'Y' ? response.data : null;
};

export const deleteNotificationDeptGroup = async (ntdkId: string) => {
  const request: CommonRequest = {
    method: Method.PUT,
    url: `/v1/notificationDeptGroup/${ntdkId}`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };

  const response: CommonResponse<any> = await callApi(request);

  return response.successOrNot === 'Y' ? response.data : null;
};

export const saveNotificationDeptGroupUsers = async (
  NotificationDeptGroupUsers: NotificationDeptGroupUser[]
) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/notificationDeptGroup/users`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: NotificationDeptGroupUsers,
  };
  const response: CommonResponse<any> = await callApi(request);

  return response.successOrNot === 'Y' ? response.data : null;
};

export const getApprovalNotificationDeptGroups = async (ntdkDeptId: string) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/NotificationDeptGroup/${ntdkDeptId}/approvals`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };
  const response: CommonResponse<NotificationDeptGroup[]> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as NotificationDeptGroup[];
};
