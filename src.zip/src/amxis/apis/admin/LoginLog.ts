// import { ApiUrl, ApiUrlCondition } from 'models/admin/ApiUrl';
import { CommonRequest, CommonResponse, Method, ServiceName } from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';
// import { MenuLog, MenuLogRequest } from 'models/admin/MenuLog';
import { PaginationResponse } from '@/amxis/models/common/Pagination.ts';
import { LoginLog, LoginLogRequest } from '@/amxis/models/admin/LoginLog.ts';

export const findLoginLogs = async (condition: LoginLogRequest) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/admin/login-log`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({ ...condition }),
  };
  const response: CommonResponse<PaginationResponse<LoginLog>> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : []) as PaginationResponse<LoginLog>;
};
