import { CommonRequest, CommonResponse, Method, ServiceName } from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';
import { PaginationResponse } from '@/amxis/models/common/Pagination.ts';
import { ButtonLogRequestVo, ButtonLogResponseVo } from '@/amxis/models/admin/ButtonLog.ts';

export const findButtonLogs = async (condition: ButtonLogRequestVo) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/admin/button-log`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({ ...condition }),
  };
  const response: CommonResponse<PaginationResponse<ButtonLogResponseVo>> = await callApi(request);

  return (
    response.successOrNot === 'Y' ? response.data : []
  ) as PaginationResponse<ButtonLogResponseVo>;
};

export const saveButtonClickLog = async (btnKeyCd: string) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/admin/button-log`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: { btnKeyCd: btnKeyCd },
  };
  const response: CommonResponse<string> = await callApi(request);

  return response.successOrNot === 'Y' ? response.data : null;
};
