import { CommonRequest, CommonResponse, Method, ServiceName } from '@/amxis/models/common/RestApi.ts';
import { MenuRequest, MenuVO } from '@/amxis/models/admin/Menu.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';
import { Role } from '@/amxis/models/admin/Role.ts';
import { Employee } from '@/amxis/models/admin/Employee.ts';
import { Department } from '@/amxis/models/admin/Department.ts';
import { MenuSearchCondition } from '@/amxis/pages/sample/sample-grid-manage/types/grid-manage.types.ts';

export const getAllMenus = async (searchCondition?: MenuSearchCondition) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/menus`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams(searchCondition+''),
  };
  const response: CommonResponse<MenuVO[]> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as MenuVO[];
};

export const getAllMenusSearch = async () => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/menus/search`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };
  const response: CommonResponse<MenuVO[]> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as MenuVO[];
};

export const getMenu = async (pgmId: string) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/menu/${pgmId}`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };
  const response: CommonResponse<MenuVO> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as MenuVO;
};

export const getMenusByRole = async (roleCd: string) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/role/${roleCd}/menus`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    // queryParams: new URLSearchParams({ roleCd: roleCd }),
  };
  const response: CommonResponse<MenuVO[]> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as MenuVO[];
};

export const saveMenusByRole = async (roleCd: string, mnuIdList: string[]) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/role/${roleCd}/menus`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: mnuIdList,
  };
  const response: CommonResponse = await callApi(request);

  return response.successOrNot === 'Y' ? response : null;
};

export const getRolesByMenu = async (pgmId: string) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/menu/${pgmId}/roles`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    // queryParams: new URLSearchParams({ pgmId: pgmId }),
  };
  const response: CommonResponse<Role[]> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as Role[];
};

export const getEmployeesByMenu = async (pgmId: string) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/menu/${pgmId}/employees`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    // queryParams: new URLSearchParams({ pgmId: pgmId }),
  };
  const response: CommonResponse<Employee[]> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as Employee[];
};

export const getDepartmentsByMenu = async (pgmId: string) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/menu/${pgmId}/departments`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    // queryParams: new URLSearchParams({ pgmId: pgmId }),
  };
  const response: CommonResponse<Department[]> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as Department[];
};

export const deleteMenus = async (pgmId: string) => {
  const request: CommonRequest = {
    method: Method.DELETE,
    url: `/v1/menu/${pgmId}`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    // queryParams: new URLSearchParams({ pgmId: pgmId }),
  };
  const response: CommonResponse<number> = await callApi(request);

  return response.successOrNot === 'Y' ? response.data : null;
};

export const createMenu = async (menu: MenuRequest) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/menu`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: menu,
  };
  const response: CommonResponse<MenuVO> = await callApi(request);

  return response.successOrNot === 'Y' ? response.data : null;
};

export const changeSessionMenus = async () => {
  const request: CommonRequest = {
    method: Method.PUT,
    url: `/v1/session/menus`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };
  const response: CommonResponse = await callApi(request);

  return response.successOrNot === 'Y';
};
