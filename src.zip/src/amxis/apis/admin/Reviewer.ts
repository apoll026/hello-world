import {
  CommonRequest,
  CommonResponse,
  Method,
  ServiceName,
} from '@/amxis/models/common/RestApi.ts';
import { reviewerContent } from '@/amxis/models/admin/Reviewer.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';

export const getReviewers = async (empName?: string, deptCd?: string) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/contract/review/reviewer`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({
      empName: empName ? empName : '',
      deptCd: deptCd ? deptCd : '',
    }),
  };
  const response: CommonResponse<any> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as reviewerContent[];
};
