import { CommonCode } from '@/amxis/models/admin/CommonCode.ts';
import { BbsCondition, BbsPost, BbsPostDetail, BbsPostRequest } from '@/amxis/models/admin/Bbs.ts';
import { PaginationResponse } from '@/amxis/models/common/Pagination.ts';
import {
  CommonRequest,
  CommonResponse,
  DmlResponse,
  Method,
  ServiceName,
} from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';

export const findBbsPosts = async (Condition?: BbsCondition) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/bbs/posts`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({ ...Condition }),
  };
  const response: CommonResponse<PaginationResponse<BbsPost>> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as PaginationResponse<BbsPost>;
};

export const findBbsPost = async (bbsNo: string) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/bbs/post/${bbsNo}`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };
  const response: CommonResponse<BbsPostDetail> = await callApi(request);
  return response.successOrNot === 'Y' ? response.data : null;
};

export const createBbs = async (bbs: BbsPostRequest) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/bbs/post`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: bbs,
  };

  const response: CommonResponse<DmlResponse> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as DmlResponse;
};

export const modifyBbs = async (bbs: BbsPostRequest) => {
  const request: CommonRequest = {
    method: Method.PUT,
    url: `/v1/bbs/post`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: bbs,
  };

  const response: CommonResponse<DmlResponse> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as DmlResponse;
};

export const deleteBbs = async (bbsNo: string) => {
  const request: CommonRequest = {
    method: Method.PATCH,
    url: `/v1/bbs/post`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: new Number(bbsNo),
  };

  const response: CommonResponse<any> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as DmlResponse;
};

/* 필터 목록 조회 */
export const getFilterCodes = async (cmnGrCd: string) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/filterCodes`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({ cmnGrCd: cmnGrCd }),
  };
  const response: CommonResponse<CommonCode[]> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as CommonCode[];
};
