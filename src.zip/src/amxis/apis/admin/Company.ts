import { Company } from '@/amxis/models/admin/Company.ts';
import {
  CommonRequest,
  CommonResponse,
  Method,
  ServiceName,
} from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';

export const getCompanyBySearchCondition = async (
    signValue?: string
) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/company-verify`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({
      signValue: signValue ?? '',
    }),
  };
  const response: CommonResponse<any> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as Company[];
};