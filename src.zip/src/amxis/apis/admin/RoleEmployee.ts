import { RoleEmployee, RoleEmployeeMutateRequest } from '@/amxis/models/admin/Role.ts';
import {
  CommonRequest,
  CommonResponse,
  DmlResponse,
  Method,
  ServiceName,
} from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';

export const getRoleEmps = async (typeCode: string) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/role/${typeCode}/employees`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };
  const response: CommonResponse<RoleEmployee[]> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as RoleEmployee[];
};

export const setRoleEmps = async (roleEmployeeMutateRequest: RoleEmployeeMutateRequest) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/role/${roleEmployeeMutateRequest.roleCd}/employees`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: roleEmployeeMutateRequest.mailIdList,
  };
  const response: CommonResponse<DmlResponse> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as DmlResponse;
};

export const deleteRoleEmps = async (roleEmployeeMutateRequest: RoleEmployeeMutateRequest) => {
  const queryParams = new URLSearchParams();
  roleEmployeeMutateRequest.mailIdList.forEach((mailId) => {
    queryParams.append('mailIdList', mailId);
  });

  const request: CommonRequest = {
    method: Method.DELETE,
    url: `/v1/role/${roleEmployeeMutateRequest.roleCd}/employees`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: queryParams,
  };
  const response: CommonResponse<DmlResponse> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as DmlResponse;
};
