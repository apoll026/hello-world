import { CommonRequest, CommonResponse, Method, ServiceName } from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';
import { PaginationResponse } from '@/amxis/models/common/Pagination.ts';
import { EmailLogRequest, EmailLog } from '@/amxis/models/admin/EmailLog.ts';

export const findEmailLogs = async (condition: EmailLogRequest) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/admin/email-log`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({ ...condition }),
  };
  const response: CommonResponse<PaginationResponse<EmailLog>> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : []) as PaginationResponse<EmailLog>;
};
