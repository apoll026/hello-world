import { CommonRequest, CommonResponse, Method, ServiceName } from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';
import { MenuLog, MenuLogRequest } from '@/amxis/models/admin/MenuLog.ts';
import { PaginationResponse } from '@/amxis/models/common/Pagination.ts';

export const findMenuLogs = async (condition: MenuLogRequest) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/admin/menu-log`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({ ...condition }),
  };
  const response: CommonResponse<PaginationResponse<MenuLog>> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : []) as PaginationResponse<MenuLog>;
};
