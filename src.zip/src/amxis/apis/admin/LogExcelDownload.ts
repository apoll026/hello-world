import { ExcelDownloadRequest } from '@/amxis/models/common/Excel.ts';
import { CommonRequest, CommonResponse, Method, ServiceName } from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';
import { downloadFile } from '@/amxis/apis/common/Excel.ts';
import { LoginLogRequest } from '@/amxis/models/admin/LoginLog.ts';
import { EmailLogRequest } from '@/amxis/models/admin/EmailLog.ts';
import { MenuLogRequest } from '@/amxis/models/admin/MenuLog.ts';
import { IfLogRequest } from '@/amxis/models/admin/IfLog.ts';
import {BatchLog, BatchLogRequest} from "@/amxis/models/admin/BatchLog.ts";

export const downLoadLogInLogListExcel = async (
  condition: ExcelDownloadRequest<LoginLogRequest>
) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/login/list/excel-download`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: condition,
    headers: {
      Accept: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Type': 'application/json',
    },
    responseType: 'blob',
  };
  const response: CommonResponse<Blob> = await callApi(request);
  if (response?.data) downloadFile(response.data, `${condition.fileName}`);
};

export const downLoadEmailLogListExcel = async (
  condition: ExcelDownloadRequest<EmailLogRequest>
) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/email/list/excel-download`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: condition,
    headers: {
      Accept: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Type': 'application/json',
    },
    responseType: 'blob',
  };
  const response: CommonResponse<Blob> = await callApi(request);
  if (response?.data) downloadFile(response.data, `${condition.fileName}`);
};

export const downLoadMenuAccessLogListExcel = async (
  condition: ExcelDownloadRequest<MenuLogRequest>
) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/menu/list/excel-download`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: condition,
    headers: {
      Accept: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Type': 'application/json',
    },
    responseType: 'blob',
  };
  const response: CommonResponse<Blob> = await callApi(request);
  if (response?.data) downloadFile(response.data, `${condition.fileName}`);
};

export const downLoadIFLogListExcel = async (condition: ExcelDownloadRequest<IfLogRequest>) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/if/list/excel-download`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: condition,
    headers: {
      Accept: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Type': 'application/json',
    },
    responseType: 'blob',
  };
  const response: CommonResponse<Blob> = await callApi(request);
  if (response?.data) downloadFile(response.data, `${condition.fileName}`);
};

export const downLoadBatchLogListExcel = async (condition: ExcelDownloadRequest<BatchLogRequest>) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/batch/list/excel-download`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: condition,
    headers: {
      Accept: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Type': 'application/json',
    },
    responseType: 'blob',
  };
  const response: CommonResponse<Blob> = await callApi(request);
  if (response?.data) downloadFile(response.data, `${condition.fileName}`);
};
