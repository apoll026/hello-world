import { CommonRequest, CommonResponse, Method, ServiceName } from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';
import { PaginationResponse } from '@/amxis/models/common/Pagination.ts';
import { IfLogRequest, IfLog } from '@/amxis/models/admin/IfLog.ts';

export const findIfLogs = async (condition: IfLogRequest) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/admin/if-log`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({ ...condition }),
  };
  const response: CommonResponse<PaginationResponse<IfLog>> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : []) as PaginationResponse<IfLog>;
};
