
import {
  GridConfigInfo,
} from '@/amxis/pages/sample/sample-grid-manage/types/grid-manage.types.ts';
import {
  CommonRequest,
  type CommonResponse,
  type DmlResponse,
  Method,
  ServiceName,
} from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';

export const findGridConfigs = async (pgmId: string) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/ibsheet/grid-configs/${pgmId}`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };
  const response: CommonResponse<GridConfigInfo[]> = await callApi(request);

  if(response.successOrNot === 'Y') return response.data;
  throw new Error(response.statusCode);
};

export const saveGridConfig = async (configs: GridConfigInfo[]) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/ibsheet/grid-configs`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: configs,
  };
  const response: CommonResponse<DmlResponse> = await callApi(request);

  if(response.successOrNot === 'Y') return response.data;
  throw new Error(response.statusCode);
};
