import { Employee, TeamLeaderInfo } from '@/amxis/models/admin/Employee.ts';
import {
  CommonRequest,
  CommonResponse,
  Method,
  ServiceName,
} from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';

export const getEmployeeBySearchCondition = async (
  searchItem?: string,
  deptCd?: string,
  deptNm?: string,
  empName?: string
) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/employees`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({
      searchItem: searchItem ?? '',
      deptCode: deptCd ?? '',
      deptName: deptNm ?? '',
      empName: empName ?? '',
    }),
  };
  const response: CommonResponse<any> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as Employee[];
};

export const getTeamLeaderIdByDeptCd = async (deptCd: string) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/employee/teamLeaderId`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({ deptCd }),
  };
  const response: CommonResponse<TeamLeaderInfo> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as TeamLeaderInfo;
};

export const getEmployeeByUserId = async (userId: string) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/employee/userId`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({ userId }),
  };
  const response: CommonResponse<Employee> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as Employee;
};

export const getEmployeeByEmpNo = async (empNo: string) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/employee/empNo`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({ empNo }),
  };
  const response: CommonResponse<Employee> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as Employee;
};
