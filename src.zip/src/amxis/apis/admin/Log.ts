import { CommonRequest, Method, ServiceName } from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';

export const createMenuAccessLog = async (pgmId: string) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/log/menu-access`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: { pgmId: pgmId },
  };
  callApi(request);
};
