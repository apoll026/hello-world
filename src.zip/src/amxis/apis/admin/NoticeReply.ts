import {
  NoticeReplyRequest,
  NoticeReplyUpdateRequest,
  NoticeReply,
} from '@/amxis/models/admin/NoticeReply.ts';
import { CommonRequest, CommonResponse, Method, ServiceName } from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';
/* 댓글 목록 조회 */
export const getNoticeReplyList = async (noticeNo: string) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/notice/reply/${noticeNo}`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };
  const response = await callApi(request);
  return (
    response.successOrNot === 'Y' && response.data ? response.data : null
  ) as NoticeReply[];
  //return response.successOrNot === 'Y' ? response.data : null;
};
export const createNoticeReply = async (replyRequest: NoticeReplyRequest) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/notice/reply`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: replyRequest,
  };
  const response: CommonResponse = await callApi(request);

  return response.successOrNot === 'Y' ? true : false;
};

export const removeNoticeReply = async (noticeNo: string, noticeReNo: number | string) => {
  const request: CommonRequest = {
    method: Method.DELETE,
    url: `/v1/notice/reply/${noticeNo}/${noticeReNo}`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };
  const response: CommonResponse = await callApi(request);

  return response.successOrNot === 'Y' ? true : false;
};

export const modifyNoticeReply = async (
  bbsReplyUpdateRequest: NoticeReplyUpdateRequest
) => {
  const request: CommonRequest = {
    method: Method.PUT,
    url: `/v1/notice/reply`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: bbsReplyUpdateRequest,
  };
  const response: CommonResponse = await callApi(request);

  return response.successOrNot === 'Y' ? true : false;
};
