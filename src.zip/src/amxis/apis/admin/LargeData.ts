import { CommonRequest, CommonResponse, Method, ServiceName } from '@/amxis/models/common/RestApi.ts';
import { callApi } from "@/amxis/utils/ApiUtil.ts";

export const getLargeData = async () => {
    const request: CommonRequest = {
      method: Method.GET,
      url: `/v1/largedata`,
      serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
      //queryParams: new URLSearchParams({ }),
    };
    const response: CommonResponse<Object> = await callApi(request);
  
    return (response.successOrNot === 'Y' ? response.data : null) as Object;
  };
  