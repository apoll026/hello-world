import { CommonRequest, CommonResponse, Method, ServiceName } from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';
import { RoleButtonCode } from '@/amxis/models/admin/RoleButtonCode.ts';
import { Session } from '@/amxis/models/common/Session.ts';

export const getRoleButtonCodes = async (
  searchBtnGrCd: string,
  searchBtnCd: string,
  searchUseYn: string
) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/role/button`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({
      searchBtnGrCd: searchBtnGrCd,
      searchBtnCd: searchBtnCd,
      searchUseYn: searchUseYn,
    }),
  };
  const response: CommonResponse<RoleButtonCode[]> = await callApi(request);

  return (response.successOrNot === 'Y' ? response.data : null) as RoleButtonCode[];
};

export const setRoleButtonCds = async (saveData: RoleButtonCode[]) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/role/button`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: saveData,
  };
  const response: CommonResponse<Session> = await callApi(request);
  return response;
};

export const isDuplicatedRoleButtonCodes = async (saveData: RoleButtonCode[]) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/role/button/duplicate`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: saveData,
  };
  const response: CommonResponse<boolean> = await callApi(request);

  return response.successOrNot === 'Y' ? response.data : null;
};
