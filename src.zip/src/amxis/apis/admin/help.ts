import type { Help, HelpCondition } from '@/amxis/models/admin/Help.ts';
import {
  Method,
  ServiceName,
  type CommonRequest,
  type CommonResponse,
  type DmlResponse,
} from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';

export const findHelps = async (helpCondition: HelpCondition) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/helps`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({ ...helpCondition }),
  };
  const response: CommonResponse<Help[]> = await callApi(request);

  if (response.successOrNot === 'Y') return response.data;
  throw new Error(response.statusCode);
};

export const findHelp = async (pgmId: string) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/helps/${pgmId}`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };
  const response: CommonResponse<Help> = await callApi(request);

  if (response.successOrNot === 'Y') return response.data;
  throw new Error(response.statusCode);
};

export const findHelpByUrl = async (pathname: string) => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/helps/by-url`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    queryParams: new URLSearchParams({ pathname }),
  };
  const response: CommonResponse<Help> = await callApi(request);

  if (response.successOrNot === 'Y') return response.data;
  throw new Error(response.statusCode);
};

export const saveHelps = async (help: Help) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/helps`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: help,
  };
  const response: CommonResponse<DmlResponse> = await callApi(request);

  if (response.successOrNot === 'Y') return response.data;
  throw new Error(response.statusCode);
};

export const updateHelp = async (help: Help) => {
  const request: CommonRequest = {
    method: Method.PUT,
    url: `/v1/helps/${help.pgmId}`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: help,
  };
  const response: CommonResponse<DmlResponse> = await callApi(request);

  if (response.successOrNot === 'Y') return response.data;
  throw new Error(response.statusCode);
};

export const deleteHelp = async (pgmId: string) => {
  const request: CommonRequest = {
    method: Method.DELETE,
    url: `/v1/helps/${pgmId}`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };
  const response: CommonResponse<DmlResponse> = await callApi(request);

  if (response.successOrNot === 'Y') return response.data;
  throw new Error(response.statusCode);
};
