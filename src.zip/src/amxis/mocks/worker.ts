import { setupWorker } from 'msw';
import { basicHandlers, basicHandlerUrls } from '@/amxis/mocks/handlers.ts';
import { roleHandlers, roleHandlerUrls } from '@/amxis/mocks/roleHandlers.ts';
import { employeeHandlers, employeeHandlerUrls } from './employeeHandlers.ts';
import { departmentsHandlers, departmentsHandlerUrls } from './departmentHandlers.ts';
import { messageHandlers, messageHandlerUrls } from '@/amxis/mocks/messageHandlers.ts';
import { codeHandlers, codeHandlerUrls } from '@/amxis/mocks/codeHandlers.ts';
import { menuHandlers, menuHandlerUrls } from '@/amxis/mocks/menuHandlers.ts';
import { menuLogHandlers, menuLogHandlerUrls } from '@/amxis/mocks/menuLogHandlers.ts';
import { loginLogHandlers, loginLogHandlerUrls } from '@/amxis/mocks/loginLogHandlers.ts';
import { ifLogHandlers, ifLogHandlerUrls } from '@/amxis/mocks/ifLogHandlers.ts';
import { emailLogHandlers, emailLogHandlerUrls } from '@/amxis/mocks/emailLogHandlers.ts';
import { apiHandlers, apiHandlerUrls } from '@/amxis/mocks/apiHandlers.ts';
import {
  approvalTemplateHandlers,
  approvalTemplateHandlerUrls,
} from '@/amxis/mocks/approvalTemplateHandlers.ts';
import { noticeHandlers, noticeHandlerUrls } from './noticeHandlers.ts';
import { notificationHandlers, notificationHandlerUrls } from '@/amxis/mocks/notificationHandlers.ts';
import { approvalLineHandlers, approvalLineHandlerUrls } from '@/amxis/mocks/approvalLineHandlers.ts';
import { approvalExcludeHandlers, approvalExcludeHandlerUrls } from '@/amxis/mocks/approvalExcludeHandlers.ts';

export const worker = setupWorker(
  ...basicHandlers,
  ...roleHandlers,
  ...employeeHandlers,
  ...departmentsHandlers,
  ...messageHandlers,
  ...codeHandlers,
  ...menuHandlers,
  ...menuLogHandlers,
  ...loginLogHandlers,
  ...ifLogHandlers,
  ...emailLogHandlers,
  ...approvalTemplateHandlers,
  ...apiHandlers,
  ...noticeHandlers,
  ...notificationHandlers,
  ...approvalLineHandlers,
  ...approvalExcludeHandlers
);
export const handlerUrls = [
  ...basicHandlerUrls,
  ...roleHandlerUrls,
  ...employeeHandlerUrls,
  ...departmentsHandlerUrls,
  ...messageHandlerUrls,
  ...codeHandlerUrls,
  ...menuHandlerUrls,
  ...menuLogHandlerUrls,
  ...loginLogHandlerUrls,
  ...ifLogHandlerUrls,
  ...emailLogHandlerUrls,
  ...approvalTemplateHandlerUrls,
  ...apiHandlerUrls,
  ...noticeHandlerUrls,
  ...notificationHandlerUrls,
  ...approvalLineHandlerUrls,
  ...approvalExcludeHandlerUrls,
];
