/usr/lib/sendmail -t < /app/acct/fb/card_mail/mail/TEST
