/*----------------------
   Y2KCOM 
   swcho 1999/01/11
-----------------------*/
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include <varargs.h>




/****************************************************************************/
/*   Function Name :                                                        */
/* ------------------------------------------------------------------------ */
/*   Function :                                                             */
/*   Argument :                                                             */
/*   Return   :                                                             */
/*   Edition history                                                        */
/* - No. - -- Date -- ----------- Comments ----------------------- -- By -- */
/* (    )  (  .  .  ) (                                          )          */
/* (    )  (  .  .  ) (                                          )          */
/****************************************************************************/

char*   TimeString()
{
    static  char    szTime[20];
    time_t          timeval;
    struct  tm* nt;

    timeval = time((time_t *)0);
    nt = localtime( &timeval );

    sprintf( szTime, "%04d%02d%02d-%02d:%02d:%02d", nt->tm_year+1900,
             nt->tm_mon+1, nt->tm_mday, nt->tm_hour, nt->tm_min, nt->tm_sec );

    return szTime;
}

/****************************************************************************/
/*   Function Name :                                                        */
/* ------------------------------------------------------------------------ */
/*   Function :                                                             */
/*   Argument :                                                             */
/*   Return   :                                                             */
/*   Edition history                                                        */
/* - No. - -- Date -- ----------- Comments ----------------------- -- By -- */
/* (    )  (  .  .  ) (                                          )          */
/* (    )  (  .  .  ) (                                          )          */
/****************************************************************************/

int     CheckCurrentLog( pzLogFileName )
char*   pzLogFileName;
{
    time_t          timeval;
    struct  stat    FileInfo;
    struct  tm*     GetTime;
    int             nCurrentYear;
    int             nCurrentMon;
    int             nCurrentDay;
    int             nLastModifiedYear;
    int             nLastModifiedMon;
    int             nLastModifiedDay;
    char 	*timey2kbuf;

    if ( stat( pzLogFileName, &FileInfo ) ) return 1;

    timeval = time( (time_t *)0 );
    GetTime      = localtime( &timeval );

/*----------------------
   Y2KMOD 
   GetTime->tm_year+1900
   Y2KREP 
   GetTime->tm_year
------------------------*/
    nCurrentYear = GetTime->tm_year+1900;
    nCurrentMon  = GetTime->tm_mon;
    nCurrentDay  = GetTime->tm_mday;

    GetTime = localtime( &FileInfo.st_mtime );

/*----------------------
   Y2KMOD
   GetTime->tm_year+1900
   Y2KREP
   GetTime->tm_year
------------------------*/
    nLastModifiedYear = GetTime->tm_year+1900;
    nLastModifiedMon  = GetTime->tm_mon;
    nLastModifiedDay  = GetTime->tm_mday;

    if ( nCurrentYear != nLastModifiedYear ||
         nCurrentMon  != nLastModifiedMon  ||
         nCurrentDay  != nLastModifiedDay     )  return 0;

    return 1;
}

/****************************************************************************/
/*   Function Name :                                                        */
/* ------------------------------------------------------------------------ */
/*   Function :                                                             */
/*   Argument :                                                             */
/*   Return   :                                                             */
/*   Edition history                                                        */
/* - No. - -- Date -- ----------- Comments ----------------------- -- By -- */
/* (    )  (  .  .  ) (                                          )          */
/* (    )  (  .  .  ) (                                          )          */
/****************************************************************************/

void    AdjustPrevLog( pzLogFileName, nKeepLogNo )
char*   pzLogFileName;
int     nKeepLogNo;
{
    FILE*   TempFp;
    char    szTempName1[256];
    char    szTempName2[256];
    char    szCommand[256];
    int     nInx;

    for ( nInx = nKeepLogNo - 2 ; nInx >= 0 ; nInx -- ) {
        if ( nInx != 0 ) {
            sprintf( szTempName1, "%s.%d", pzLogFileName, nInx );
        } else {
            strcpy( szTempName1, pzLogFileName );
        }
        sprintf( szTempName2, "%s.%d", pzLogFileName, nInx + 1 );

        if ( !access( szTempName1, F_OK ) ) {
            sprintf( szCommand, "mv %s %s", szTempName1, szTempName2 );
            system( szCommand );
        }
    }
}


/****************************************************************************/
/*   Function Name :                                                        */
/* ------------------------------------------------------------------------ */
/*   Function :                                                             */
/*   Argument :                                                             */
/*   Return   :                                                             */
/*   Edition history                                                        */
/* - No. - -- Date -- ----------- Comments ----------------------- -- By -- */
/* (    )  (  .  .  ) (                                          )          */
/* (    )  (  .  .  ) (                                          )          */
/****************************************************************************/

char*   ezEDIGetFileName( pzFullName )
char*   pzFullName;
{
    char*   pzTemp;
    char*   pzSearchTemp;

    pzSearchTemp = pzFullName;

    while ( ( pzTemp = strchr( pzSearchTemp, '/' ) ) != NULL ) {
        pzSearchTemp = pzTemp + 1;
    }

    return  pzSearchTemp;
}

/****************************************************************************/
/*   Function Name :                                                        */
/* ------------------------------------------------------------------------ */
/*   Function :                                                             */
/*   Argument :                                                             */
/*   Return   :                                                             */
/*   Edition history                                                        */
/* - No. - -- Date -- ----------- Comments ----------------------- -- By -- */
/* (    )  (  .  .  ) (                                          )          */
/* (    )  (  .  .  ) (                                          )          */
/****************************************************************************/

FILE*   InitLog( pzPgmName )
char*   pzPgmName;
{
    FILE*   LogFp;
    int     nLen;
    int     nKeepLogNo;
    char    szLogPath[256];
    char    szLogFileName[256];

    GetProfileString( "LOG", "PATH", "./", szLogPath );
    GetProfileInt( "LOG", "KEEPLOGNO", 7, &nKeepLogNo );

    nLen = strlen( szLogPath );

    if ( szLogPath[nLen - 1] == '/' ) szLogPath[nLen - 1] = '\0';

    if ( strchr( pzPgmName, '/' ) )  pzPgmName = ezEDIGetFileName( pzPgmName );

    sprintf( szLogFileName, "%s/%s.log", szLogPath, pzPgmName );

    if ( !CheckCurrentLog( szLogFileName ) )
        AdjustPrevLog( szLogFileName, nKeepLogNo );

    LogFp = fopen( szLogFileName, "a" );

    return LogFp;
}

/****************************************************************************/
/*   Function Name :                                                        */
/* ------------------------------------------------------------------------ */
/*   Function :                                                             */
/*   Argument :                                                             */
/*   Return   :                                                             */
/*   Edition history                                                        */
/* - No. - -- Date -- ----------- Comments ----------------------- -- By -- */
/* (    )  (  .  .  ) (                                          )          */
/* (    )  (  .  .  ) (                                          )          */
/****************************************************************************/

void    WriteLog( va_alist )
va_dcl
{
    va_list     args;
    char*       pzFormat;
    FILE*       Fp;

    va_start( args );

    Fp = (FILE *)va_arg( args, char* );         /* get file pointer         */
    pzFormat = va_arg( args, char* );           /* get format string        */
    vfprintf( Fp, pzFormat, args );
    fflush( Fp );

    va_end( args );
}
