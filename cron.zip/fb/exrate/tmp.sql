select * from fatx920
--where user_id = 'jdko'
--or user_id = 'hslee4'
--or user_id = 'lgeds'
--or user_id = 'choiyj'
/
