/*****************************************************************************

 tcpsend.c    (c)Copyright Systems Technology Management Co., 1994-1995
              All rights reserved.

              TCP/IP File send program for message switching system
	      attach xmtcprecvd and xmsh and xmorign and TCP/IP ftp send

******************************************************************************/

#include "tcp_remote.h"



#define         TS                ( TimeString() )


extern  char*   sys_errlist[];


char*   _pzProFile = "TCPCLIENT.CFG";
char    szIPAddr[68];
int     nPortNo;
FILE*   LogFp;

/************************************************/
/*  Cho S.W : XMORIGN.SCR UPDATE                */
/*  argument ---> writed  in file               */
/************************************************/
FILE	     *fp;
int	Pre_Scrread();
int	Scr_Write();
char	Arg_buf[100];       /* temp buf */
char	FnameS[100];        /* file name */
char    rnameS[100];        /* receive name */
char    fnameS[100];        /* type P(N):E(Y) translator */
char    tnameS[100];        /* title name */
char    pnameS[100];        /* protocol : TCP/IP */
char    Update_Buf[200];

char	token1[100];        /* xmorign : command */
char	token2[100];        /* receive 	        */
char	token3[100];        /* type : P ( E )    */
char	token4[100];        /* title             */
char	token5[100];        /* protocol          */

FILE	*msg_f;
char	msg_fbuf[100];
/************************************************/

/****************************************************************************/
/*   Function Name :                                                        */
/* ------------------------------------------------------------------------ */
/*   Function :                                                             */
/*   Argument :                                                             */
/*   Return   :                                                             */
/*   Edition history                                                        */
/* - No. - -- Date -- ----------- Comments ----------------------- -- By -- */
/* (    )  (  .  .  ) (                                          )          */
/* (    )  (  .  .  ) (                                          )          */
/****************************************************************************/

void    InitProc( pzPgmName )
char*   pzPgmName;
{
    LogFp = (FILE *)InitLog( pzPgmName );

    GetProfileString( "EDISVR", "IPADDR", "127.0.0.1", szIPAddr );
    GetProfileInt( "EDISVR", "PORTNO", 7000, &nPortNo );
}

/****************************************************************************/
/*   Function Name :                                                        */
/* ------------------------------------------------------------------------ */
/*   Function :                                                             */
/*   Argument :                                                             */
/*   Return   :                                                             */
/*   Edition history                                                        */
/* - No. - -- Date -- ----------- Comments ----------------------- -- By -- */
/* (    )  (  .  .  ) (                                          )          */
/* ( 02 )  (98.05.15) ( Add InitProc() Function                  ) Cho, H C */
/* (    )  (  .  .  ) ( EDI Server Connection �ϴ� �κ� ����     ) Cho, H C */
/* (    )  (  .  .  ) (                                          )          */
/****************************************************************************/

main(argc, argv)
int	argc;
char	*argv[];
{
    int		sockfd;
    int		fd;
    struct	sockaddr_in	serv_addr;

    int		rc, len, nbytes, i,j;
    char	filename[128];
    char    szCommand[256];

    /* =======   [S]  EDIT  002   ======= */

    InitProc( argv[0] );

    /* =======   [E]  EDIT  002   ======= */

    WriteLog( LogFp, "%s - =====  << SENDING JOB  --->  START  >>  =====\n",
              TS );

    if ( argc > 1 ) {
	if ( argv[1][0] != '-' ) {
            WriteLog( LogFp, "%s - ERROR : Invalid Command Line Argument\n",
                      TS );
            exit( -1 );
	}
    }

    if ( argc > 1 ) {
    	rc = Pre_Scrread();
    }
    if ( argc > 1 ) {
        if ( argc > 1 ) {
		if ( FnameS[0] == NULL || FnameS[0] == 0x20 ) {
			memset(FnameS, 0x00, sizeof(FnameS));
			strcpy(FnameS, xcmd_parm[1]);
		}
		if ( rnameS[0] == NULL || rnameS[0] == 0x20 ) {
			strcpy(rnameS, token2);
		}
		if ( tnameS[0] == NULL || tnameS[0] == 0x20 ) {
			strcpy(tnameS, token4);
		}
		if ( fnameS[0] == NULL || fnameS[0] == 0x20 ) {
			strcpy(fnameS, token3);
		}
		if ( pnameS[0] == NULL || pnameS[0] == 0x20 ) {
			strcpy(pnameS, token5);
		}
    	}
        i = 0;
        while( i < argc ) { 
	  	strcpy(Arg_buf, argv[i]);
	  	if ( strncmp("-F:", Arg_buf, 3) == 0 ) {	
			memset(FnameS, 0x00, sizeof(FnameS));
			strcpy(FnameS, Arg_buf);
	  	}
	  	if ( strncmp("-r:", Arg_buf, 3) == 0 ) {	
			memset(rnameS, 0x00, sizeof(rnameS));
			strcpy(rnameS, Arg_buf);
	  	}
	  	if ( strncmp("-t:", Arg_buf, 3) == 0 ) {	
			memset(tnameS, 0x00, sizeof(tnameS));
			strcpy(tnameS, Arg_buf);
/*  from added by a h s 0423 : title allowd space and double quotation  */
			j=i;
			for(j=j+1;j<argc;j++){
				strcpy(Arg_buf,argv[j]);
				if (strncmp("-",Arg_buf,1) != 0 ){
					strncat(tnameS," ",1);
					strcat(tnameS,Arg_buf);
				}
			}
/*  to   added by a h s 0423 : title allowd space and double quotation  */
	  	}
	  	if ( strncmp("-f:", Arg_buf, 3) == 0 ) {	
			memset(fnameS, 0x00, sizeof(fnameS));
			strcpy(fnameS, Arg_buf);
	  	}
	  	if ( strncmp("-p:", Arg_buf, 3) == 0 ) {	
			memset(pnameS, 0x00, sizeof(pnameS));
			strcpy(pnameS, Arg_buf);
	  	}
		i++;
 	} 
	memset(Update_Buf, 0x00, sizeof(Update_Buf));
       	sprintf(Update_Buf, "%cxmorign %s %s %s -P:ITCP/IP%c # send command",0x22, rnameS,fnameS,tnameS, 0x22);
    	rc = Scr_Write();
        system("cp XTCPORIG.SCR XTCPORIG.bak");
        system("cp XTCPORIG.tmp XTCPORIG.SCR");
    }
    /*
     * Fill the structure "serv_addr" with the addres of the
     * server that we want to connect with.
     */
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family	= AF_INET;

    /* =======   [S]  EDIT  002   ======= */

    serv_addr.sin_addr.s_addr = inet_addr( szIPAddr );
    serv_addr.sin_port        = htons( nPortNo );

    /* =======   [E]  EDIT  002   ======= */

    /*
     * Open a TCP socket (an Internet stream socket).
     */

    if ((sockfd = socket(AF_INET, SOCK_STREAM,0)) < 0) {
        WriteLog( LogFp, "%s - ERROR : NOT CREAT SOCKET - %s\n",
                  TS, sys_errlist[errno] );
        exit(1);
    }

    /*
     * Connect to the server.
     */

    if (connect(sockfd, (struct sockaddr *) &serv_addr,sizeof(serv_addr)) <0) {
        WriteLog( LogFp, "%s - ERROR : NOT CONNECT TO EDI SERVER - %s\n",
                  TS, sys_errlist[errno] );
        exit( 1 );
    }

    WriteLog( LogFp, "%s - CONNECT TO EDI SERVER FOR SENDING DATA\n", TS );

    /*
     * Script file open and read.
     * user group, login id, passwd, command line, file path
     */
    if ((scr_fd = open(_TCP_ORIGSCR_, O_RDONLY, 0)) < 0) {
        WriteLog( LogFp, "%s - ERROR : NOT OPEN SCRIPT FILE - %s\n",
                  TS, sys_errlist[errno] );
        exit( 1 );
    }

    /* read tcp/ip user group */
    rc = Read_Scrfile(scr_fd);			/* read user group */
    if (rc == 0) {
        WriteLog( LogFp, "%s - ERROR : NOT READ USER GROUP IN SCRIPT FILE\n",
                  TS );
        exit( 1 );
    }

    rc = Xcmd_Exect(xcmd_parm);			/* extract user group */
    strcpy(tcpuser_group, xcmd_parm[0]);

    /* receive host command (request tcp user group) */
    rc = TCP_data_recv(sockfd);
    if (rc <= 0) TCP_exit(_TCP_SEND_, rc, -1);
    
    if (strcmp(tcp_rbuf, _TCP_REQGRP_) != 0) {
        WriteLog( LogFp, "%s - ERROR : NOT HOST USER GROUP REQUEST\n", TS );
        exit( 1 );
    }

    strcpy(tcp_sbuf, tcpuser_group);
    rc = TCP_data_send(sockfd, strlen(tcp_sbuf));
    if (rc <= 0) TCP_exit(_TCP_SEND_, rc, -2);

    /*
     * receive host command (request ID and passwd)
     */
    rc = TCP_data_recv(sockfd);
    if (rc <= 0) TCP_exit(_TCP_SEND_, rc, -3);
    if (strcmp(tcp_rbuf, _TCP_REQLOGIN_) != 0) {
        WriteLog( LogFp, "%s - ERROR : NOT HOST USER ID REQUEST\n", TS );
        exit( 1 );
    }

    /* read tcp/ip user ID and passwd */
    rc = Read_Scrfile(scr_fd);			/* read user ID and passwd */
    if (rc == 0) {
        WriteLog( LogFp, "%s - ERROR : READ USER ID IN SCRIPT FILE\n", TS );
        exit( 1 );
    }

    rc = Xcmd_Exect(xcmd_parm);			/* extract user ID */
    rc = TCP_data_send(sockfd, strlen(tcp_sbuf)); 
    if (rc <= 0) TCP_exit(_TCP_SEND_, rc, -4);

    /* 
     * Read command line (multi command and destination)
     */

    for ( ; ; ) {			/* start of command loop */
        rc = TCP_data_recv(sockfd);		/* receive host rew cmd */
        if (rc <= 0) TCP_exit(_TCP_SEND_, rc, -5);
        
        if (strcmp(tcp_rbuf, _TCP_REQCMD_) != 0) {
            WriteLog( LogFp, "%s - ERROR : NOT HOST COMMAND REQUEST\n", TS );
            exit( 1 );
        }
        /*
         * Read command line in script file
         */
        len = Read_Scrfile(scr_fd);
        if (len <= 0) {
            strcpy(tcp_sbuf, _TCP_CMDEXIT_); 

            rc = TCP_data_send(sockfd, strlen(tcp_sbuf));
            if (rc <= 0) TCP_exit(_TCP_SEND_, rc, -6);
            break;
        }

        rc = Xcmd_Exect(xcmd_parm);     /* only use check Script file syntax */
        strcpy( szCommand, tcp_sbuf );

        len = strlen(tcp_sbuf);
        rc = TCP_data_send(sockfd, len);     /* Send Command Line */
        if (rc <= 0) TCP_exit(_TCP_SEND_, rc, -7);

        WriteLog( LogFp, "%s - SEND COMMAND : %s\n",
                  TS, strtok( szCommand, "#\n" ) );

        /*
         * receive host command (request send sending filename)
         */
	rc = TCP_data_recv(sockfd);		/* Receive host request cmd */
	if (rc <= 0) TCP_exit(_TCP_SEND_, rc, -8);

 	len = Read_Scrfile(scr_fd);/* Script send file read */
 	if (len == 0) {
            WriteLog( LogFp, "%s - ERROR : NO FILE NAME IN SCRIPT FILE\n",
                      TS );
 	    exit( 1 );
 	}
 	rc = Xcmd_Exect(xcmd_parm);     /* extract send file name */
 	strcpy(tcp_sbuf, xcmd_parm[1]);
 	strcpy(filename, tcp_sbuf);
 	len = strlen(tcp_sbuf);

        rc = TCP_data_send(sockfd, len);        /* Send sending file name */
        if (rc <= 0) TCP_exit(_TCP_SEND_, rc, -9);

       
        rc = TCP_data_recv( sockfd );           /* Receive host request cmd */
        if ( rc <= 0 ) {
            WriteLog( LogFp, "%s - ERROR : RECV HOST REQ COMMAND - %s\n",
                      TS, sys_errlist[errno] );
            TCP_exit( _TCP_SEND_, rc, -11 );
        }

        /*
         * Argument filename C.S.W 
         */

        WriteLog( LogFp, "%s - SEND DATA - FILE NAME : %s\n", TS, filename );

	if((fd = open(filename, O_RDONLY, 0)) < 0) {
            WriteLog( LogFp, "%s - ERROR : NOT OPEN SEND FILE [%s] - %s\n",
                      TS, filename, sys_errlist[errno] );
            exit( 1 );
	}

	nbytes = 0;
	for (;;) {
	    if ((len = read(fd, tcp_sbuf, sizeof(tcp_sbuf))) < 0) {
		exit(1);
	    }
            if (len == 0) break;

	    rc = TCP_data_send(sockfd, len);	/* Sending read data */
	    if (rc <= 0) TCP_exit(_TCP_SEND_, rc, -12);
	    rc = TCP_data_recv(sockfd);
	    if (rc <= 0) TCP_exit(_TCP_SEND_, rc, -13);
	    if (strcmp(tcp_rbuf, _TCP_ACKOK_) != 0) {
		break;
	    }
	    nbytes += len;
        }					/* end for statement */
        strcpy(tcp_sbuf, _TCP_FEOF_);
	sprintf(&tcp_sbuf[11], "%010d", nbytes);
	rc = TCP_data_send(sockfd, 30);	/* Sending eof data */
	if (rc <= 0) TCP_exit(_TCP_SEND_, rc, -14);

	close(fd);

    } 					/* end of  command loop */
    
    close(fd);
    close(sockfd);

    WriteLog( LogFp, "%s - =====  << SENDING JOB ---> ALL DONE >>  =====\n\n",
              TS );
    exit(0);
}

/*
 * file 1 line read and data send
 */
int     Read_Scrfile(fd)
int     fd;
{
    int     len = 0;
    int     rc;

    for (;;) {
        rc = read(fd, &tcp_sbuf[len], 1);
        if (rc == 0) break;
        if (rc == -1) {
            WriteLog( LogFp, "%s - ERROR : READ SCRIPT - %s\n",
                      TS, sys_errlist[errno] );
            exit(1);
        }
        if (tcp_sbuf[len] == 0x0a) {
            tcp_sbuf[len] == 0x00;
            break;
        }
        len++;
    }
    return(len);
}

/*
 * extract script command line
 */
int     Xcmd_Exect(xcmd_parm)
char    xcmd_parm[5][80];
{
    int     i, j, k, sw;

    i = j = k = sw = 0;

    for (i = 0; i < sizeof(tcp_sbuf); i++) {
        if (tcp_sbuf[i] == '#') break;
        if (tcp_sbuf[i] == '\"') {
            if (sw == 0) {
                sw = 1;
                k = 0;
                i++;
            } else {
                sw =0;
                xcmd_parm[j][k] = 0x00;
                j++;
            }
        }
        if (sw == 1) {
            xcmd_parm[j][k] = tcp_sbuf[i];
            k++;
        }
    }
    if (sw == 1) {
        WriteLog( LogFp, "%s - ERROR : WRONG SCRIPT SYNTEX\n", TS );
        exit (1);
    }

    return(j);
}

int     Scr_Write()
{
    FILE    *fd;
    char    scrbuf[100];
    int     rc, i;

    if ((fd = fopen(_TCP_ORIGSCR_, "r")) == NULL) {
        WriteLog( LogFp, "%s - ERROR : OPEN SCRIPT FILE - %s\n",
                  TS, sys_errlist[errno] );
        exit(1);
    }

    memset(scrbuf, 0x00, sizeof(scrbuf));

    if ((fp=fopen("XTCPORIG.tmp", "w"))==NULL) {
        WriteLog( LogFp, "%s - ERROR : OPEN TEMP SCRIPT FILE - %s\n",
                  TS, sys_errlist[errno] );
        exit(-1);
    }

    i = 0;
    while (fgets(scrbuf, sizeof(scrbuf), fd), !feof(fd)) {
        fprintf( fp, "%s", scrbuf);
        i++;
        if ( i > 1 ) break;
    }

    fprintf( fp, "%s\n", Update_Buf);

    if ( FnameS[0] == '-' )  strcpy(FnameS, &FnameS[3]);

    fprintf( fp, "%c%s%c,%c%s%c # send file path\n",
             0x22, xcmd_parm[0],0x22, 0x22, FnameS, 0x22);
    fclose(fp);
    fclose (fd);
    return 0;
}

int	Pre_Scrread()
{
    int rc, i, j, count_tt ;
    int sab_count = 0;  /* start end  count */

    memset(token1, 0x00, sizeof(token1));
    memset(token2, 0x00, sizeof(token2));
    memset(token3, 0x00, sizeof(token3));
    memset(token4, 0x00, sizeof(token4));
    memset(token5, 0x00, sizeof(token5));

    if ((scr_fd = open(_TCP_ORIGSCR_, O_RDONLY, 0)) < 0) {
        WriteLog( LogFp, "%s - ERROR : OPEN SCRIPT FILE [%s] - %s\n",
                  TS, _TCP_ORIGSCR_, sys_errlist[errno] );
        exit(1);
    }

    rc = Read_Scrfile(scr_fd);                  /* read user group */
    if (rc == 0) {
        WriteLog( LogFp, "%s - ERROR : READ USER GROUP IN SCRIPT FILE\n", TS );
        exit(1);
    }
    rc = Read_Scrfile(scr_fd);                  
    rc = Read_Scrfile(scr_fd);                  /* xmorign read */ 

    i = 0; count_tt = 1; sab_count = 0; j = 0; 
    while( 1 ) {
/*  from added by a h s 0423 : title allowd space and double quotation  */
        if ( tcp_sbuf[i] == '#' || i > 250 || sab_count >= 4) break;
/*  to   added by a h s 0423 : title allowd space and double quotation  */
  	if ( tcp_sbuf[i] == '"') { 
		i++;
                sab_count++;
                continue;
	}

        if ( tcp_sbuf[i] == 0x20 && tcp_sbuf[i+1] == '-') {
		j = 0;
		count_tt++;

	} else {
		if ( count_tt == 1 ) {
			token1[j++] = tcp_sbuf[i];
		}
		if ( count_tt == 2 ) {
			token2[j++] = tcp_sbuf[i];
		}
		if ( count_tt == 3 ) {
			token3[j++] = tcp_sbuf[i];
		}
		if ( count_tt == 4 ) {
			token4[j++] = tcp_sbuf[i];
		}
		if ( count_tt == 5 ) {
			token5[j++] = tcp_sbuf[i];
		}
	}
        i++;
    }
    rc = Read_Scrfile(scr_fd);                  /* xmorign read */ 
    rc = Xcmd_Exect(xcmd_parm);			/* extract user group */
    memset(FnameS, 0x00, sizeof(FnameS));
    strcpy( FnameS, xcmd_parm[1]);
    close(scr_fd);
    return 0;
}
