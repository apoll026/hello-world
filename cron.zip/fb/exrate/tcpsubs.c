/*
 * Subroutines for TCP client/ server programs
 */

#include	<stdio.h>
#include	<sys/types.h>
#include	<sys/socket.h>
#include	<netinet/in.h>
#include	<arpa/inet.h>
#include	<sys/signal.h>
#include	<sys/errno.h>

#include	"xmsg_env.h"
 
extern	char	tcp_rbuf[128];
extern	char	tcp_sbuf[128];
extern	int	errno;
extern	int	sockfd;

int	irc;
int	TCP_recv_alarmHandler();
int	TCP_send_alarmHandler();

/*
 * tcp buffer data receive
 */
int	TCP_data_recv(sockfd)
int	sockfd;
{
    int	rc;

    signal(SIGALRM, TCP_recv_alarmHandler);
    alarm(_TCP_RCV_TIMEOUT_);		

    bzero(tcp_rbuf, sizeof(tcp_rbuf));

    irc = 0; rc = 0;
    rc = recv(sockfd, tcp_rbuf, sizeof(tcp_rbuf), 0);
    if (rc == _ERR_TIMEOUT_) return(rc);
/*  ==  receive data error : empty data case 
    if (rc < 0) { 
        printf("TCP_data_recv : Receve error return [%d].\n",rc);
        perror("TCP_data_recv : Error Receive data at subroutine");
    }
*/
    alarm(0);
    return(rc);
}

/*
 * TCP receive alarm signal handler
 */
int	TCP_recv_alarmHandler()
{
    printf("TCP Data receive Timeout.\n");
    return(_ERR_TIMEOUT_);
}

/*
 * TCP buffer data send
 */
int	TCP_data_send(sockfd, len)
int	sockfd, len;
{
    int	rc;

    signal(SIGALRM, TCP_send_alarmHandler);
    alarm(_TCP_SND_TIMEOUT_);

    irc = 0; rc = 0;
    rc = write(sockfd, tcp_sbuf, len);
    if (irc == _ERR_TIMEOUT_) return(irc);
    if (rc < 0) {
        printf("TCP_data_send : Send error return value [%d].\n", rc);
        perror("TCP_data_send : Error send data at subroutine");
    }

    bzero(tcp_sbuf, sizeof(tcp_sbuf));
    alarm(0);

    return(rc);
}

/*
 * TCP send alarm signalHandler
 */
int	TCP_send_alarmHandler()
{
    printf("TCP_send_alarmHandler : TCP data send timeout.\n");
    return(_ERR_TIMEOUT_);
}

/*
 * TCP/IP network timeout posion display
 */
void	TCP_timeout(fun_name, rc)
char	*fun_name;
int	rc;
{
    rc = abs(rc);
    printf("TCP_timeout : Time-out [%s] : rtn [%d]\n", fun_name, rc);
    exit(rc);
}
/*
 * network time-out position display
 */
void	TCP_exit(fun_name, rc,  rtn )
	char	*fun_name;
	int	rc;
	int	rtn;
{
	rtn = abs(rtn);

	if( rc == _ERR_TIMEOUT_ ) {
		printf("TCP_exit : [%s] TCP Time-out rtn [%d]\n", fun_name, rtn);
	}
	else {
		printf("TCP_exit : [%s] Error rtn[%d] where[%d]\n", fun_name, rc, rtn);
	}
	exit(rtn);
}

/* End of File */
