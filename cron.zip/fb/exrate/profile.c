/****************************************************************************/
/*                                                                          */
/*  system      : Profile Handling Library                                  */
/*  subsystem   :                                                           */
/*                                                                          */
/*  function    :                                                           */
/*  attribute   : file name   task id.    priority    stack    ver          */
/*               [profile.c]  [      ]    [      ]    [   ]  [ 0.8]         */
/*                                                                          */
/*  ---- name ---- ------------ function -------------   -- date -- - ver - */
/*  (            ) ( GetProfileString                 )  ( 95.06.07)(  .  ) */
/*  (            ) ( WriteProfileString               )  ( 95.06.07)(  .  ) */
/*  (            ) ( GetProfileInt                    )  ( 97.02.04)(  .  ) */
/*  (            ) ( WriteProfileInt                  )  ( 97.02.04)(  .  ) */
/*  (            ) ( CheckConfigFile                  )  ( 97.03.12)(  .  ) */
/*  (            ) (                                  )  (   .  .  )(  .  ) */
/*                                                                          */
/*                                                     created  Kim,haksoo  */
/*                                                     update   97.03.12    */
/*                                                                          */
/****************************************************************************/
/**/
/****************************************************************************/
/*                                                                          */
/* [ Edition history ]                                                      */
/*                                                                          */
/* - no. - -- date -- ----- comments ----------------------------- -- by -- */
/* ( 01 )  (95.06.07) ( First build for DSI project              ) Kim,hs   */
/* ( 02 )  (97.02.04) ( porting for RTFB(K&R C)                  ) Kim,hs   */
/* ( 03 )  (97.03.12) ( add CheckConfigFile                      ) Kim,hs   */
/* ( 04 )  (  .  .  ) (                                          )          */
/*                                                                          */
/****************************************************************************/

#include <stdio.h>
#include <string.h>
#include <unistd.h>

extern  char*    _pzProFile;
char    back_file[50];

char    szWork[81];                             /* work area            */

/****************************************************************************/
/*  check configuration file                                                */
/*      return   1 : OK                                                     */
/*              -1 : not found                                              */
/****************************************************************************/
int     CheckConfigFile( sFileName )
char*   sFileName;
{
    if( access( sFileName, R_OK|W_OK ) ) {
        fprintf( stderr,
                 "Configuration file %s is not found or can\'t readable\n",
                 sFileName );
        return -1;
    }
    return 1;
}

/************************************************************************/
/*  search section proc                                                 */
/*      return   line # : OK                                            */
/*                   -1 : none                                          */
/************************************************************************/
int     SearchSection( szSec, fp )
char*   szSec;
FILE*   fp;
{
    int     r, n;
    char    s[50];

    sprintf( s, "[%s]", szSec );

    r = n = 0;
    while( fgets( szWork, 80, fp ) ) {
        if( strncmp( szWork, s, strlen(s) ) == 0 ) {
            r = 1;
            break;
        }
        n++;
    }
    if( r == 0 )    n = -1;
    return n;
}

/************************************************************************/
/*  search entry proc                                                   */
/*      return   line # : OK                                            */
/*                   -1 : none                                          */
/************************************************************************/
int     SearchEntry( szEntry, fp )
char*   szEntry;
FILE*   fp;
{
    int     r, n;
    char    s[40];

    r = n = 0;
    while( fgets( szWork, 80, fp ) ) {
        sscanf( szWork, "%s", s );
        if( strcmp( s, szEntry ) == 0 ) {
            r = 1;
            break;
        }
        if( szWork[0] == '[' )  break;          /* another section ?    */
        n++;
    }
    if( r == 0 )    n = -1;
    return n;
}

/************************************************************************/
/*  Get Value Start Index                                               */
/************************************************************************/
int     GetStartIndex( szStr )
char*   szStr;
{
    int     i;

    szStr[strlen(szStr)-1] = '\0';              /* remove LF            */
    i = strlen(szStr);
    while( szStr[i] != '=' && i >= 0 )    i--;

    if( i > 0 ) i++;                            /* skip =               */
    while( szStr[i] == ' ' ) i++;

    if( szStr[i] == '\0' )  i = 0;

    return i;
}

/************************************************************************/
/*  read profile string proc.                                           */
/*      return   above 1 : OK                                           */
/*                     0 : No Profile                                   */
/*                    -1 : No Section                                   */
/*                    -2 : No Entry                                     */
/*                    -3 : No Value                                     */
/************************************************************************/
int     GetProfileString( szSection, szEntry, szDefault, szBuf )
char*   szSection;
char*   szEntry;
char*   szDefault;
char*   szBuf;
{
    int     r;
    int     p;
    FILE    *fp;

    strcpy( szBuf, szDefault );                 /* set default string   */

    if( (fp = fopen( _pzProFile, "r" )) == NULL )
        return 0;                               /* no profile           */

    r = SearchSection( szSection, fp );         /* search section name  */
    if( r != -1 ) {
        r = SearchEntry( szEntry, fp );         /* search entry name    */
        if( r != -1 ) {
            r = 1;
            p = GetStartIndex( szWork );
            if( p > 0 ) strcpy( szBuf, &szWork[p] );
            else        r = -3;                 /* no value             */
        }
        else    r = -2;
    }
    else    r = -1;

    fclose( fp );
    return r;
}


/**/
FILE    *FileHeadCopy( line )
int     line;
{
    int     i;
    FILE    *fs, *fd;

    unlink( back_file );
    rename( _pzProFile, back_file );

    fd = fopen( _pzProFile, "w" );
    fs = fopen( back_file, "r" );

    if( line == -1 ) {
        while( fgets( szWork, 80, fs ) ) {
            fprintf( fd, szWork );
        }
    }
    else {
        for( i = 0 ; i < line ; i++ ) {
            fgets( szWork, 80, fs );
            fprintf( fd, szWork );
        }
    }
    fclose( fs );

    return fd;
}

/**/
void    FileRestCopy( line, r, fp )
int     line;
int     r;
FILE*   fp;
{
    int     i;
    FILE    *fb;

    fb = fopen( back_file, "r" );
    for( i = 0 ; i < line ; i++ )
        fgets( szWork, 80, fb );

    if( r == 1 || r == -3 ) fgets( szWork, 80, fb );

    while( fgets( szWork, 80, fb ) )
        fprintf( fp, szWork );

    fclose( fb );
}

/************************************************************************/
/*  write profile string proc.                                          */
/*      return   1 : OK                                                 */
/*               0 : No Profile                                         */
/************************************************************************/
int     WriteProfileString( szSection, szEntry, szBuf )
char*   szSection;
char*   szEntry;
char*   szBuf;
{
    int     r;
    int     line;
    FILE    *fp;

    r = GetProfileString( szSection, szEntry, "", szWork );
    if( r == 0 )    return 0;                   /* no profile           */

    fp = fopen( _pzProFile, "r" );
    if( r > 1 ) r = 1;
    switch( r ) {
        case  1 :
        case -3 : line = SearchSection( szSection, fp );
                  line += SearchEntry( szEntry, fp ) + 1;
                  break;
        case -2 : line = SearchSection( szSection, fp ) + 1;
                  break;
        case -1 : line = -1;
    }
    fclose( fp );

    strcpy( back_file, _pzProFile );
    strcat( back_file, ".bak" );

    fp = FileHeadCopy( line );

    if( line == -1 )
        fprintf( fp, "[%s]\n", szSection );

    fprintf( fp, "%s = %s\n", szEntry, szBuf );

    if( line != -1 )    FileRestCopy( line, r, fp );

    fclose( fp );

    return 1;
}


/************************************************************************/
/*  read profile integer proc.                                          */
/*      return   above 1 : OK                                           */
/*                     0 : No Profile                                   */
/*                    -1 : No Section                                   */
/*                    -2 : No Entry                                     */
/*                    -3 : No Value                                     */
/************************************************************************/
int     GetProfileInt( szSection, szEntry, nDefault, nNum )
char*   szSection;
char*   szEntry;
int     nDefault;
int*    nNum;
{
    int     r;
    char    szDefault[10];
    char    szNum[10];

    sprintf( szDefault, "%d", nDefault );
    r = GetProfileString( szSection, szEntry, szDefault, szNum );
    *nNum = atoi( szNum );

    return r;
}


/************************************************************************/
/*  write profile integer proc.                                         */
/*      return   1 : OK                                                 */
/*               0 : No Profile                                         */
/************************************************************************/
int     WriteProfileInt( szSection, szEntry, nNum )
char*   szSection;
char*   szEntry;
int     nNum;
{
    int     r;
    char    szBuf[10];

    sprintf( szBuf, "%d", nNum );
    r = WriteProfileString( szSection, szEntry, szBuf );
    return r;
}

/************************************************************************/
/*  read profile long integer proc.                                     */
/*      return   above 1 : OK                                           */
/*                     0 : No Profile                                   */
/*                    -1 : No Section                                   */
/*                    -2 : No Entry                                     */
/*                    -3 : No Value                                     */
/************************************************************************/
int     GetProfileLong( szSection, szEntry, nDefault, nNum )
char*   szSection;
char*   szEntry;
long    nDefault;
long*   nNum;
{
    int     r;
    char    szDefault[10];
    char    szNum[10];

    sprintf( szDefault, "%d", nDefault );
    r = GetProfileString( szSection, szEntry, szDefault, szNum );
    *nNum = atol( szNum );

    return r;
}


/************************************************************************/
/*  write profile long integer proc.                                    */
/*      return   1 : OK                                                 */
/*               0 : No Profile                                         */
/************************************************************************/
int     WriteProfileLong( szSection, szEntry, nNum )
char*   szSection;
char*   szEntry;
long    nNum;
{
    int     r;
    char    szBuf[10];

    sprintf( szBuf, "%d", nNum );
    r = WriteProfileString( szSection, szEntry, szBuf );
    return r;
}
