select dept_code ,incm_rate,befr_adj_sale, rece_remd_amt, tax_sale_amt, tot_plan_amt from fatc400
where year = '1999'
and month = '12'
order by dept_code
/
