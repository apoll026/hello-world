##/fund/fb_data/cash/tcpsend
date >> /app1/fund/fb/cash_rt/CASHBACK.dat
cat /app1/fund/fb/cash/CASH.dat >> /app1/fund/fb/cash_rt/CASHBACK.dat
rm /app1/fund/fb/cash/CASH.dat
