/****************************************************************************/
/*                                                                          */
/*  System      : XMSG System                                               */
/*  Subsystem   : Batch Firm Banking - TCP/IP Receiving Process             */
/*                                                                          */
/*  Function    : Message Receiving Process Using TCP/IP Protocol.          */
/*                                                                          */
/*  Attribute   :  file  name     task id.    priority    stack    ver      */
/*               [ tcprecv.c  ]   [      ]    [      ]    [   ]  [ 1.2 ]    */
/*                                                                          */
/*  ---- name ---- ------------ function -------------   -- date -- - ver - */
/*  (            ) (                                  )  (   .  .  )(  .  ) */
/*  (            ) (                                  )  (   .  .  )(  .  ) */
/*  (            ) (                                  )  (   .  .  )(  .  ) */
/*                                                                          */
/*                                                Updated By Hyun chul, Cho */
/*                                                Last Update : 98.05.15    */
/*                                                     Time   : 09:00       */
/****************************************************************************/
/**/
/****************************************************************************/
/*                                                                          */
/* [ Edition history ]                                                      */
/*                                                                          */
/* - no. - -- date -- ----- comments ----------------------------- -- by -- */
/* ( 01 )  (  .  .  ) (                                          )          */
/* ( 02 )  (98.05.15) ( stdout, stderr�� message�� ����ϴ� ���� ) Cho, H C */
/* (    )  (  .  .  ) ( log file�� ���, log file�� cfg file��   )          */
/* (    )  (  .  .  ) ( ����� ������ŭ ����                     )          */
/* ( 03 )  (98.05.15) ( EDI Server�� IP Address �� Port�� cfg    ) Cho, H C */
/* (    )  (  .  .  ) ( file���� �����ϰ� ��                     )          */
/*                                                                          */
/****************************************************************************/
/**/
/*****************************************************************************

 tcplstmsg.c (c)Copyright Systems Technology Management Co., 1994-1995
              All rights reserved.

              TCP File list receive program for message switching system
	      attach xmtcprecvd and xmsh and xmlstmsg and tcpftp

******************************************************************************/

#include "tcp_remote.h"

#define         TS       ( TimeString() )

extern  char*   sys_errlist[];


char*   _pzProFile = "TCPCLIENT.CFG";
char    szIPAddr[68];
int     nPortNo;
FILE*   LogFp;




/****************************************************************************/
/*   Function Name :                                                        */
/* ------------------------------------------------------------------------ */
/*   Function :                                                             */
/*   Argument :                                                             */
/*   Return   :                                                             */
/*   Edition history                                                        */
/* - No. - -- Date -- ----------- Comments ----------------------- -- By -- */
/* (    )  (  .  .  ) (                                          )          */
/* (    )  (  .  .  ) (                                          )          */
/****************************************************************************/

void    InitProc( pzPgmName )
char*   pzPgmName;
{
    LogFp = (FILE *)InitLog( pzPgmName );

    GetProfileString( "EDISVR", "IPADDR", "127.0.0.1", szIPAddr );
    GetProfileInt( "EDISVR", "PORTNO", 7000, &nPortNo );
}

/****************************************************************************/
/*   Function Name :                                                        */
/* ------------------------------------------------------------------------ */
/*   Function :                                                             */
/*   Argument :                                                             */
/*   Return   :                                                             */
/*   Edition history                                                        */
/* - No. - -- Date -- ----------- Comments ----------------------- -- By -- */
/* (    )  (  .  .  ) (                                          )          */
/* ( 02 )  (98.05.15) ( Add InitProc() Function                  ) Cho, H C */
/* (    )  (  .  .  ) ( EDI Server Connection �ϴ� �κ� ����     ) Cho, H C */
/* (    )  (  .  .  ) (                                          )          */
/****************************************************************************/

main(argc, argv)
	int             argc;
	char           *argv[];
{

    int         sockfd;
    int         fd, sfd;
    struct      sockaddr_in     serv_addr;

    int         rc, len, nbytes;
    int         exit_sw;
    char        rCmd[80];
    char        filename[128];
    mode_t      SavedFileMask;

    /* =======   [S]  EDIT  002   ======= */
    InitProc( argv[0] );
    /* =======   [E]  EDIT  002   ======= */

    WriteLog( LogFp, "%s - =====  <<  XMLISTMSG JOB ---> START    >>  =====\n",
              TS );

    /*
     * Fill the structure "serv_addr" with the addres of the
     * server that we want to connect with.
     */

    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family        = AF_INET;
    serv_addr.sin_addr.s_addr   = inet_addr( szIPAddr );
    serv_addr.sin_port          = htons( nPortNo );

    /*
     * Open a TCP socket (an Internet stream socket).
     */

    if ((sockfd = socket(AF_INET, SOCK_STREAM,0)) < 0) {
        WriteLog( LogFp, "%s - ERROR : CREATE SOCKET - %s\n",
                  TS, sys_errlist[errno] );
        exit( 1 );
    }

    /*
     * Connect to the server.
     */

    if (connect(sockfd, (struct sockaddr *) &serv_addr,sizeof(serv_addr)) <0) {
        WriteLog( LogFp, "%s - ERROR : CONNECT TO EDI SERVER - %s\n",
                  TS, sys_errlist[errno] );
        exit(1);
    }

    WriteLog( LogFp, "%s - CONNECT TO EDI SERVER FOR LIST MSG\n", TS );

    /*
     * Script file open and read.
     * user group, login id, passwd, command line, file path
     */
    if ((scr_fd = open(_TCP_LSTSCR_, O_RDONLY, 0)) < 0) {
        WriteLog( LogFp, "%s - ERROR : OPEN SCRIPT FILE - %s\n",
                  TS, sys_errlist[errno] );
        exit(1);
    }

    /* read tcp/ip user group */
    rc = Read_Scrfile(scr_fd);                  /* read user group */
    if (rc == 0) {
        WriteLog( LogFp, "%s - ERROR : READ USER GROUP IN SCRIPT FILE\n", TS );
        exit( 1 );
    }

    rc = Xcmd_Exect(xcmd_parm);                 /* extract user group */
    strcpy(tcpuser_group, xcmd_parm[0]);

    /* receive host command (request tcp user group) */
    rc = TCP_data_recv(sockfd);
    if (rc <= 0) TCP_exit(_TCP_LSTMSG_, rc, -1);
    
    if (strcmp(tcp_rbuf, _TCP_REQGRP_) != 0) {
        WriteLog( LogFp, "%s - ERROR : NOT HOST USER GROUP REQUEST\n", TS );
        exit( 1 );
    }

    strcpy(tcp_sbuf, tcpuser_group);
    rc = TCP_data_send(sockfd, strlen(tcp_sbuf));
    if (rc <= 0) TCP_exit(_TCP_LSTMSG_, rc, -2);

    /*
     * receive host command (request ID and passwd)
     */
    rc = TCP_data_recv(sockfd);
    if (rc <= 0) TCP_exit(_TCP_LSTMSG_, rc, -3);
    
    if (strcmp(tcp_rbuf, _TCP_REQLOGIN_) != 0) {
        WriteLog( LogFp, "%s - ERROR : NOT HOST USER ID REQUEST\n", TS );
        exit( 1 );
    }

    /* read tcp/ip user ID and passwd */
    rc = Read_Scrfile(scr_fd);                  /* read user ID and passwd */
    if (rc == 0) {
        WriteLog( LogFp, "%s - ERROR : READ USER ID IN SCRIPT FILE\n", TS );
        exit( 1 );
    }

    rc = Xcmd_Exect(xcmd_parm);                 /* extract user ID */
    /* tcp_sbuf set data send */

    rc = TCP_data_send(sockfd, strlen(tcp_sbuf));
    if (rc <= 0) TCP_exit(_TCP_LSTMSG_, rc, -4);

    /*
     * read Command line (loop command multi destination)
     */
    for (;;) {		/* start of command loop for xmsh */

	len = Read_Scrfile(scr_fd);		/* Script file 1 line read */
	if (len <= 0) {			/* command line in script file */
            exit_sw = 1;
	}

	rc = Xcmd_Exect(xcmd_parm);	/* only use check Script file syntex */
	strcpy(rCmd, tcp_sbuf);

        rc = TCP_data_recv(sockfd);		/* Receive host request cmd */
	if (rc <= 0) TCP_exit(_TCP_LSTMSG_, rc, -5);

        if (strcmp(tcp_rbuf, _TCP_REQCMD_) != 0) {
            WriteLog( LogFp, "%s - ERROR : NOT HOST COMMAND REQUEST\n", TS );
            exit( 1 );
        }

        if (exit_sw == 1)  strcpy(tcp_sbuf, _TCP_CMDEXIT_);

        if (exit_sw == 0) {
            strcpy(tcp_sbuf, rCmd);

            WriteLog( LogFp, "%s - SEND COMMAND : %s\n",
                  TS, strtok( rCmd, "#\n" ) );
        }

        len = strlen(tcp_sbuf) + 1;
        rc = TCP_data_send(sockfd, len);        /* Send Command Line */
        if (rc <= 0) TCP_exit(_TCP_LSTMSG_, rc, -6);

	if (exit_sw == 1) break;	/* Cmd line end PGM. end */

	len = Read_Scrfile(scr_fd);	/* Script file read recv filename */
	if (len == 0) {			/* receive file full path */
            WriteLog( LogFp, "%s - ERROR : NO FILE NAME IN SCRIPT FILE\n",
                      TS );
            exit( 1 );
	}

	rc = Xcmd_Exect(xcmd_parm);	/* extract receive file name */
	strcpy(filename, xcmd_parm[1]);

        /*
         * open receive file and data read
         */

        SavedFileMask = umask( 0 );

        if((sfd = open(filename, O_RDWR | O_CREAT | O_APPEND, 0660)) < 0) {
            WriteLog( LogFp, "%s - ERROR : OPEN LIST FILE - %s\n", TS,
                      sys_errlist[errno] );
            exit( 1 );
        }   

        umask( SavedFileMask );

        /*
         * receive host command (request send sending filename)
         */
        for (;;) {				/* receive multimessage loop */

            rc = TCP_data_recv(sockfd);		/* Receive host request cmd */
	    if (rc <= 0) TCP_exit(_TCP_LSTMSG_, rc, -7);

                                                /* end of msg loop */
            if (strcmp(tcp_rbuf, _TCP_REQMSGE_) == 0){
                 strcpy (tcp_sbuf, _TCP_ACKOK_);
                 rc = TCP_data_send(sockfd, 11);
                 if (rc <= 0) TCP_exit(_TCP_LSTMSG_, rc, -8);
		 break;
	    }
                                                /* request receive */
            if (strcmp(tcp_rbuf, _TCP_REQFTPR_) != 0) {
                WriteLog( LogFp, "%s - ERROR : NO LIST OR INVALID COMMAND\n",
                          TS ); 
                exit( 1 );
            }

            strcpy (tcp_sbuf, _TCP_ACKOK_);
            rc = TCP_data_send(sockfd, 11);
            if (rc <= 0) TCP_exit(_TCP_LSTMSG_, rc, -8);

            /*
             * receive host command (request data receive command)
             */
            rc = TCP_data_recv(sockfd);     /* Receive host request cmd */
            if (rc <= 0) TCP_exit(_TCP_LSTMSG_, rc, -9);
                                            /* request data receive ? */
            if (strcmp(tcp_rbuf, _TCP_REQFTPD_) != 0) {
                WriteLog( LogFp, "%s - ERROR : NOT HOST REQUEST[%s]\n",
                          TS, _TCP_REQFTPD_ );
                exit( 1 );
            }

            strcpy (tcp_sbuf, _TCP_ACKOK_);
            rc = TCP_data_send(sockfd, 11);
            if (rc <= 0) TCP_exit(_TCP_LSTMSG_, rc, -10);

            /*
             * receive data from remote host
             */
            nbytes = 0;
            for(;;) {

                len = rc = TCP_data_recv(sockfd);
                if (rc <= 0) TCP_exit(_TCP_LSTMSG_, rc, -11);

                if(len <= 0) break;

                if (strcmp(tcp_rbuf, _TCP_FEOF_) == 0) {
                    if ((strlen(&tcp_rbuf[11]) == 10)
                    && (atoi(&tcp_rbuf[11]) == nbytes)) break;
                }

                if (write (sfd, tcp_rbuf, len) < 0) {
                    WriteLog( LogFp, "%s - ERROR : WRITE LIST DATA - %s\n",
                              TS, sys_errlist[errno] );
                    close(sfd);
                    close(fd);
                    close(sockfd);
                    exit(1);
                }

                strcpy (tcp_sbuf, _TCP_ACKOK_);
                rc = TCP_data_send(sockfd, 11);
                if (rc <= 0) TCP_exit(_TCP_LSTMSG_, rc, -12);

                nbytes += len;

            }                                       /* end of for */

            strcpy (tcp_sbuf, _TCP_ACKOK_);
            rc = TCP_data_send(sockfd, 11);
            if (rc <= 0) TCP_exit(_TCP_LSTMSG_, rc, -13);

        }                                       /* end of multi message loop */
        close(sfd);
    }                           /* end of  command loop for xmsh */
    rc = TCP_data_recv(sockfd);
    if (rc <= 0) TCP_exit(_TCP_LSTMSG_, rc, -14);

    if (strcmp(tcp_rbuf, _TCP_NRMEND_) != 0) {
        WriteLog( LogFp, "%s - ERROR : SERVER ABNORMALY ENDED\n", TS );
    } else {
        WriteLog( LogFp, "%s - =====  << LIST JOB ---> ALL DONE >>  =====\n\n",
                  TS );
    }

    close(sockfd);
    close(fd);

    exit(0);
}

/*
 * file 1 line read and data send
 */
int     Read_Scrfile(fd)
        int     fd;
{
    int     len = 0;
    int     rc;

    for (;;) {
        rc = read(fd, &tcp_sbuf[len], 1);
        if (rc == 0) break;
        if (rc == -1) {
            WriteLog( LogFp, "%s - ERROR : READ SCRIPT - %s\n",
                      TS, sys_errlist[errno] );
            exit(1);
        }
        if (tcp_sbuf[len] == 0x0a) {
            tcp_sbuf[len] == 0x00;
            break;
        }
        len++;
    }

    return(len);
}

/*
 * extract script command line
 */
int     Xcmd_Exect(xcmd_parm)
char    xcmd_parm[5][80];
{
        int     i, j, k, sw;

        i = j = k = sw = 0;
        for (i = 0; i < strlen(tcp_sbuf); i++) {
                if (tcp_sbuf[i] == '#') break;
                if (tcp_sbuf[i] == '\"') {
                        if (sw == 0) { sw = 1; k = 0; i++; }
                        else { sw =0; xcmd_parm[j][k] = 0x00; j++; }
                }
                if (sw == 1) {
                        xcmd_parm[j][k] = tcp_sbuf[i];
                        k++;
                }
        }
        if (sw == 1) {
            WriteLog( LogFp, "%s - ERROR : WRONG SCRIPT SYNTEX\n", TS );
            exit (1);

        }
        return(j);
}
