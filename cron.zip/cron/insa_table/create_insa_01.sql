--2017.11.01 �λ�DB ��ָ� ����� ����� �����Ͱ� ������ ROLLBACK �Ǵ� ������� ����

set serveroutput on;

DECLARE
    v_cnt1    NUMBER(10);
    
BEGIN
    v_cnt1 := 0;

	  SELECT COUNT(*)
      INTO   v_cnt1
      FROM PHM_INF_EMP B,
           ORM_INF_ORG C
     WHERE B.DEPT_CD = C.DEPT_CD(+)     
       AND B.CORP_CODE = '000001'
       AND C.CORP_CODE = '000001'
       AND C.DEPT_DT = (SELECT MAX(DEPT_DT) FROM ORM_INF_ORG WHERE DEPT_CD = B.DEPT_CD AND CORP_CODE = '000001' ) 
       AND C.DEPT_FG = 'Y';  -- C20171130_45037  �λ� �� ��ü �۾�
          
	 IF v_cnt1 > 1000 THEN
	 
		delete from insa02;
		
		insert into insa02
		SELECT B.EMP_NO EMP_NO,
		       SUBSTRB(B.EMP_NM, 1, 20) EMP_NM,
		       B.DEPT_CD DEPT_CD,
		       B.TITLE_CD TITLE_CD,
		       B.TITLE_NM TITLE_NM, 
		       B.JK_CD JK_CD,
		       B.JK_NM JK_NM,
		       B.SR_CD SR_CD,
		       B.SR_NM SR_NM,
		       B.FK_DIV_CD DIV_CD,
		       SUBSTRB(C.DEPT_NM, 1, 50) DEPT_NM,
		       C.SITE_CD SITE_CD,
		       DECODE(SUBSTR(B.DEPT_SORT_CD, 1, 2), 'A3', '2', 'A5', '2', 'AS', '2', '1') EMP_DIVS,
		       DECODE(SUBSTR(B.FK_HIRE_TP, 1, 3), 'TMP', F_CHULJANG_TITLE('TMP', '', ''), 
		                                                 F_CHULJANG_TITLE(B.TITLE_CD, B.SR_CD, B.JK_CD)) CHULJANG_TITLE,
		       B.EMP_STATUS EMP_STATUS,
		       '' EMP_SSN,
		       C.FK_ZIP_CD FK_ZIP_CD,
		       '' EMP_ADDR,
		       SUBSTRB(B.EMP_ENGNM, 1, 20) ENGNM,
		       SUBSTRB(B.EMP_MAIL_ID, 1, 15) EMP_MAIL_ID,
		       C.DEPT_SORT_CD DEPT_SORT_CD,
		       DECODE(SUBSTR(B.DEPT_SORT_CD, 1, 2), 'A3', 'E', 'A5', 'E', 'AS', 'E', 'C') EMP_PART,
		       B.JC_NM JC_NM,
		       B.DEPT_ALL_NM DEPT_ALL_NM,
		       '' FK_DSP_DEPT_CD,       
		       F_GET_DIV_CD('01', 'KOR', B.DEPT_CD, SYSDATE, '3') SAUP_CD,
		       F_GET_DIV_CD('01', 'KOR', B.DEPT_CD, SYSDATE, '30') SAUP_NM,
		       C.FK_DIV_CD FK_DIV_CD,
		       '' EMP_CO_TEL,
		       '' DIV_NM,
		       C.DEPT_FG DEPT_FG, 
		       NVL(TO_CHAR(B.EMP_JOINDT, 'YYYYMMDD'),'') EMP_JOINDT,
		       NVL(TO_CHAR(B.EMP_GRPDT, 'YYYYMMDD'),'') EMP_GRPDT,
		       DECODE(SUBSTR(B.DEPT_SORT_CD, 1, 2), 'A3', '2', 'A5', '2', 'AS', '2', '1') GB            
		  FROM PHM_INF_EMP B,
           ORM_INF_ORG C
     WHERE B.DEPT_CD = C.DEPT_CD(+)     
       AND B.CORP_CODE = '000001'
       AND C.CORP_CODE = '000001'
       AND C.DEPT_DT = (SELECT MAX(DEPT_DT) FROM ORM_INF_ORG WHERE DEPT_CD = B.DEPT_CD AND CORP_CODE = '000001' ) 
       AND C.DEPT_FG = 'Y';  -- C20171130_45037  �λ� �� ��ü �۾�
		   
	ELSE
        dbms_output.put_line('create_insa_01 : PHM_INF_EMP ������ ����!!');
    END IF;
    
    SELECT COUNT(*)
      INTO v_cnt1
      FROM insa02;

    dbms_output.put_line('INSA02 COUNT : '||v_cnt1);
      
    COMMIT;
    
EXCEPTION
    WHEN OTHERS THEN
        dbms_output.put_line('create_insa_01 : DB Error'||sqlcode||sqlerrm);
        ROLLBACK;
                
END;
/
SHOW ERROR;

