declare
 v_cnt               VARCHAR(01);
 user_err            EXCEPTION;

BEGIN
  v_cnt := '';
  begin
   select 'X' into v_cnt from newinsa.instj03lgcon05
   where rownum = 1;
   dbms_output.put_line(v_cnt);
EXCEPTION
  WHEN NO_DATA_FOUND THEN
   dbms_output.put_line('ERR_no_data_found');
   null;
  WHEN USER_ERR THEN
   dbms_output.put_line('ERR_user');
  when others then
   dbms_output.put_line('ERR_others1');
   null;
   END;
if v_cnt = 'X' then
BEGIN
  delete from test03;
   dbms_output.put_line(v_cnt);
EXCEPTION
  WHEN USER_ERR THEN
   dbms_output.put_line('ERR_user');
   null;
  when others then
   dbms_output.put_line('ERR_others');
   null;
END;

BEGIN
   dbms_output.put_line(v_cnt);
  insert into test03 
  ( select  *
     from newinsa.instj03@lgcon05) ;
EXCEPTION
  WHEN USER_ERR THEN
   dbms_output.put_line('ERR_user');
   null;
  when others then
   dbms_output.put_line('ERR_others');
   null;
END;

end if;

   dbms_output.put_line('END');

EXCEPTION
  WHEN USER_ERR THEN
   dbms_output.put_line('ERR_user');
   null;
  when others then
   dbms_output.put_line('ERR_others100');
   null;
END;

/

