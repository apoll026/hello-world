CREATE OR REPLACE PROCEDURE proc_insa_table(p_msg OUT VARCHAR)
IS
v_log VARCHAR2(50);
v_check_msg VARCHAR2(1000);
v_cnt1 NUMBER;
v_cnt2 NUMBER;
v_flag VARCHAR2(2);
v_msg VARCHAR2(500);
v_success_flag VARCHAR2(1);

BEGIN
      v_log := batch_start_log('12');

	  v_check_msg := '';
      v_success_flag := 'Y';
	  
	  --backup_insa01.sql
	  BEGIN
	      DELETE FROM insa01_bk;
	  EXCEPTION
	      WHEN OTHERS THEN
	           v_check_msg := 'delete insa01_bk: ' || SQLERRM;
			   v_success_flag := 'N';
	  END;

	  BEGIN
	      INSERT INTO insa01_bk
		  SELECT *
		  FROM insa01;
	  EXCEPTION
	      WHEN OTHERS THEN
	           v_check_msg := 'insert insa01_bk: ' || SQLERRM;
			   v_success_flag := 'N';
	  END;

	  IF v_check_msg = '' THEN
	      COMMIT;
	  END IF;

	  --create_insta01.sql
	  BEGIN
	      DELETE FROM insta01;
	  EXCEPTION
	      WHEN OTHERS THEN
		      v_check_msg := 'delete insta01: ' || SQLERRM;
			  v_success_flag := 'N';
	  END;

	  BEGIN
          insert into insta01 (
                     DEPT_CD, DEPT_DT, FK_APPT_CD, DEPT_NM,
                     DEPT_ENGNM, DEPT_SORT_CD, DEPT_SEQ, DEPT_FG,
                     DEPT_DESC, DEPT_LEVEL, FK_LDR_EMP_NO, FK_DIV_CD,
                     FK_DIV_DT, FK_DEPT_CD, FK_DEPT_DT, FK_DOC_CD,
                     FK_WKP_CD, FK_AREA_CD, FK_WORK_CD, FK_GUPJI_CD,
                     SITE_CD, FK_PM_EMP_NO, FK_BUSINESS_CD, FK_MARKET_CD,
                     DEPT_PN_AREA, DEPT_PN_OFFICE, DEPT_PN_NO, DEPT_FAX_AREA,
                     DEPT_FAX_OFFICE, DEPT_FAX_NO, FK_ZIP_CD, DEPT_ADDR,
                     SAUP_ST_DT, SAUP_ED_DT, SAUP_MANG_NUM, UPJONG_CD,
                     WHO, TIMESTAMP, EMP_PART, TOT,
                     CURR, ENG2, COST, JIKMU,
                     DVSN_DEPT, MANG_DEPT, sub_ldr_emp_no
                    )
          select
                     DEPT_CD, DEPT_DT, FK_APPT_CD, DEPT_NM,
                     DEPT_ENGNM, DEPT_SORT_CD, DEPT_SEQ, DEPT_FG,
                     DEPT_DESC, DEPT_LEVEL, FK_LDR_EMP_NO, FK_DIV_CD,
                     FK_DIV_DT, FK_DEPT_CD, FK_DEPT_DT, FK_DOC_CD,
                     FK_WKP_CD, FK_AREA_CD, FK_WORK_CD, FK_GUPJI_CD,
                     SITE_CD, FK_PM_EMP_NO, FK_BUSINESS_CD, FK_MARKET_CD,
                     DEPT_PN_AREA, DEPT_PN_OFFICE, DEPT_PN_NO, DEPT_FAX_AREA,
                     DEPT_FAX_OFFICE, DEPT_FAX_NO, FK_ZIP_CD, DEPT_ADDR,
                     SAUP_ST_DT, SAUP_ED_DT, SAUP_MANG_NUM, UPJONG_CD,
                     WHO, TIMESTAMP, EMP_PART, TOT,
                     CURR, ENG2, COST, JIKMU,
                     DVSN_DEPT, MANG_DEPT, sub_ldr_emp_no
          from newinsa_insta01
          where dept_fg = 'Y';
	  EXCEPTION
	      WHEN DUP_VAL_ON_INDEX THEN
		      v_check_msg := 'insert insta01 ������ �ߺ�';
			  v_success_flag := 'N';
		  WHEN OTHERS THEN
		      v_check_msg := 'insert insta01: ' || SQLERRM;
			  v_success_flag := 'N';
	  END;

	  --create_instj03
	  BEGIN
	      DELETE FROM instj03;
	  EXCEPTION
	      WHEN OTHERS THEN
		      v_check_msg := 'delete insta01: ' || SQLERRM;
			  v_success_flag := 'N';
	  END;

	  BEGIN
	      INSERT INTO instj03 (
                      FK_EMP_NO, DAT_ATDT, DAT_SEQ, FK_ATT_CD,
                      FK_JC_CD, FK_TITLE_CD, FK_JK_CD, FK_JJ_CD,
                      FK_SR_CD, FK_WORK_CD, FK_DEPT_CD, FK_DEPT_DT,
                      DAT_RSN, ATT_YN, WHO, TIMESTAMP
                      )
          select
                      FK_EMP_NO, DAT_ATDT, DAT_SEQ, FK_ATT_CD,
                      FK_JC_CD, FK_TITLE_CD, FK_JK_CD, FK_JJ_CD,
                      FK_SR_CD, FK_WORK_CD, FK_DEPT_CD, FK_DEPT_DT,
                      DAT_RSN, ATT_YN, WHO, TIMESTAMP
          from newinsa_instj03;
	  EXCEPTION
	      WHEN DUP_VAL_ON_INDEX THEN
		      v_check_msg := 'insert instj03 ������ �ߺ�';
			  v_success_flag := 'N';
		  WHEN OTHERS THEN
		      v_check_msg := 'insert instj03: ' || SQLERRM;
			  v_success_flag := 'N';
	  END;

	  --create_insve01
	  BEGIN
	      DELETE FROM insve01;
	  EXCEPTION
	      WHEN OTHERS THEN
		      v_check_msg := 'delete insve01: ' || SQLERRM;
			  v_success_flag := 'N';
	  END;

	  BEGIN
          insert into insve01(
                    EMP_NO, EMP_NM, EMP_STATUS, EMP_JOINDT,
                    EMP_GRPDT, EMP_SSN, EMP_DSP_TP, TITLE_CD,
                    TITLE_NM, JC_CD, JC_NM, JK_CD,
                    JK_NM, JJ_CD, JJ_NM, WORK_CD,
                    WORK_NM, SR_CD, SR_NM, DEPT_CD,
                    DEPT_FG, DEPT_DT, DEPT_NM, FK_LDR_EMP_NO,
                    DEPT_SORT_CD, DEPT_LEVEL, FK_DEPT_CD, FK_DEPT_DT,
                    AT_ATDT, AT_SEQ, EMP_PG_MANU, EMP_PG_OFFICE,
                    EMP_PG_NO, EMP_CO_PN_AREA, EMP_CO_PN_OFFICE, EMP_CO_PN_NO,
                    EMP_PART
                   )
          select
                    EMP_NO, EMP_NM, EMP_STATUS, EMP_JOINDT,
                    EMP_GRPDT, EMP_SSN, EMP_DSP_TP, TITLE_CD,
                    TITLE_NM, JC_CD, JC_NM, JK_CD,
                    JK_NM, JJ_CD, JJ_NM, WORK_CD,
                    WORK_NM, SR_CD, SR_NM, DEPT_CD,
                    DEPT_FG, DEPT_DT, DEPT_NM, FK_LDR_EMP_NO,
                    DEPT_SORT_CD, DEPT_LEVEL, FK_DEPT_CD, FK_DEPT_DT,
                    AT_ATDT, AT_SEQ, EMP_PG_MANU, EMP_PG_OFFICE,
                    EMP_PG_NO, EMP_CO_PN_AREA, EMP_CO_PN_OFFICE, EMP_CO_PN_NO,
                    EMP_PART
           from newinsa_insve01;
	  EXCEPTION
	      WHEN DUP_VAL_ON_INDEX THEN
		      v_check_msg := 'insert insve01 ������ �ߺ�';
			  v_success_flag := 'N';
		  WHEN OTHERS THEN
		      v_check_msg := 'insert insve01: ' || SQLERRM;
			  v_success_flag := 'N';
	  END;

      --create_insve01_01
	  BEGIN
	      DELETE FROM insve01_01;
	  EXCEPTION
	      WHEN OTHERS THEN
		      v_check_msg := 'delete insve01_01: ' || SQLERRM;
			  v_success_flag := 'N';
	  END;

	  BEGIN
          insert into insve01_01(
                      EMP_NO, EMP_NM, EMP_STATUS, EMP_JOINDT,
                      EMP_GRPDT, EMP_SSN, FK_DSP_DEPT_CD, FK_DSP_DEPT_DT,
                      EMP_DSP_TP, EMP_MAIL_ID, TITLE_CD, TITLE_NM,
                      GTITLE_CD, GTITLE_NM, JC_CD, JC_NM,
                      JK_CD, JK_NM, JJ_CD, JJ_NM,
                      WORK_CD, WORK_NM, SR_CD, SR_NM,
                      DEPT_CD, DEPT_FG, DEPT_DT, DEPT_NM,
                      FK_LDR_EMP_NO, DEPT_SORT_CD, DEPT_EXP_CD, DEPT_ACCT_CD,
                      DEPT_LEVEL, FK_DEPT_CD, FK_DEPT_DT, FK_DIV_CD,
                      AT_ATDT, AT_SEQ, DEPT_ALL_NM, EMP_PART,
                      PROJ_CD, PROJ_WORK_CD, PROJ_GUPJI_CD)
          select
                      EMP_NO, EMP_NM, EMP_STATUS, EMP_JOINDT,
                      EMP_GRPDT, EMP_SSN, FK_DSP_DEPT_CD, FK_DSP_DEPT_DT,
                      EMP_DSP_TP, EMP_MAIL_ID, TITLE_CD, TITLE_NM,
                      GTITLE_CD, GTITLE_NM, JC_CD, JC_NM,
                      JK_CD, JK_NM, JJ_CD, JJ_NM,
                      WORK_CD, WORK_NM, SR_CD, SR_NM,
                      DEPT_CD, DEPT_FG, DEPT_DT, DEPT_NM,
                      FK_LDR_EMP_NO, DEPT_SORT_CD, DEPT_EXP_CD, DEPT_ACCT_CD,
                      DEPT_LEVEL, FK_DEPT_CD, FK_DEPT_DT, FK_DIV_CD,
                      AT_ATDT, AT_SEQ, DEPT_ALL_NM, EMP_PART,
                      PROJ_CD, PROJ_WORK_CD, PROJ_GUPJI_CD
           from newinsa_insve01_01;
	  EXCEPTION
	      WHEN DUP_VAL_ON_INDEX THEN
		      v_check_msg := 'insert insve01_01 ������ �ߺ�';
			  v_success_flag := 'N';
		  WHEN OTHERS THEN
		      v_check_msg := 'insert insve01_01: ' || SQLERRM;
			  v_success_flag := 'N';
	  END;

      --create_insa_01
	  BEGIN
	      DELETE FROM insa02;
	  EXCEPTION
	      WHEN OTHERS THEN
		      v_check_msg := 'delete insa02: ' || SQLERRM;
			  v_success_flag := 'N';
	  END;

	  BEGIN
          insert into insa02
		   select a.emp_no                         emp_no   ,
                 a.emp_nm                         emp_nm   ,
                 a.dept_cd                        dept_cd  ,
                 a.title_cd                       title_cd ,
                 a.title_nm                       title_nm ,
                 a.jk_cd                          jk_cd    ,
                 a.jk_nm                          jk_nm    ,
                 a.sr_cd                          sr_cd    ,
                 a.sr_nm                          sr_nm    ,
                 a.fk_div_cd                      div_cd   ,
                 b.dept_nm                        dept_nm  ,
                 b.site_cd                        site_cd  ,
                 decode(c.emp_part, 'C','1', 'E','2','')  emp_divs,
                 f_chuljang_title( decode(substr(a.title_cd,1,1),'Z', nvl(c.fk_mail_title_cd,a.title_cd)
                                                                    , a.title_cd),a.sr_cd, a.jk_cd) chuljang_title  ,
                 a.emp_status                     emp_status ,
                 a.emp_ssn                        emp_ssn    ,
                 c.fk_zip_cd                      fk_zip_cd  ,
                 c.emp_addr                       emp_addr   ,
                 c.emp_engnm                      engnm,
                 a.emp_mail_id                    EMP_MAIL_ID,
                 a.dept_sort_cd                   DEPT_SORT_CD,
                 a.emp_part                       EMP_PART,
                 a.jc_nm                          JC_NM,
                 a.dept_all_nm                    DEPT_ALL_NM,
                 a.fk_dsp_dept_cd                 FK_DSP_DEPT_CD,
                 f_get_div_cd(a.dept_cd)          SAUP_CD,
                 f_get_div_nm(a.dept_cd)          SAUP_NM,
                 b.fk_div_cd                      FK_DIV_CD,
                 rtrim(ltrim(c.emp_co_pn_area))||'-'||
                 rtrim(ltrim(c.emp_co_pn_office))||'-'||
                 rtrim(ltrim(c.emp_co_pn_no))     EMP_CO_TEL,
                 d.div_nm                         DIV_NM,
                 b.dept_fg                        DEPT_FG,
                 nvl(to_char(c.emp_joindt,'yyyymmdd'),'')   emp_joindt,
                 nvl(to_char(c.emp_grpdt,'yyyymmdd'), '')   emp_grpdt,
                 DECODE(NVL(c.emp_part, 'C'), 'C','1','E','2')    gb
           from insve01_01 a,
                newinsa_insta01    b ,
                inste01    c,
                instc16    d
          where a.dept_cd   =  b.dept_cd(+)
            and a.emp_no    =  c.emp_no
            and b.dept_dt   =  (select max(dept_dt) from newinsa_insta01 where dept_cd = a.dept_cd )
            and b.fk_div_cd = d.div_cd(+);
	  EXCEPTION
	      WHEN DUP_VAL_ON_INDEX THEN
		      v_check_msg := 'insert insa02 ������ �ߺ�';
			  v_success_flag := 'N';
		  WHEN OTHERS THEN
		      v_check_msg := 'insert insa02: ' || SQLERRM;
			  v_success_flag := 'N';
	  END;
	  
	  --create_insa_03
	  BEGIN
          insert into insa02
          select /*+rule*/a.emp_no       			emp_no   ,
                 a.emp_nm      			emp_nm   ,
                 a.dept_cd      			dept_cd  ,
                 'ZF'       			title_cd ,
                 '�����'     			title_nm ,
                 a.jk_cd        			jk_cd    ,
                 a.jk_nm        			jk_nm    ,
                 '30'         			sr_cd    ,
                 '�����'       			sr_nm    ,
                 b.fk_div_cd                      div_cd   ,
                 b.dept_nm      			dept_nm  ,
                 b.site_cd      			site_cd  ,
                 '1'                              emp_divs ,
                 f_chuljang_title('ZF' ,'00', a.jk_cd)     chuljang_title  ,
                 decode( a.emp_status, 'T',
                 decode( sign( to_char( sysdate, 'yyyymmdd' ) - to_char( at_atdt_st, 'yyyymmdd' )), -1, 'C',
                         a.emp_status ), a.emp_status )                     emp_status,
                 a.emp_ssn                        emp_ssn ,
          	null , null ,
                 '','',
                 a.dept_sort_cd, 
                 '','','','','','','','','','','','',''
           from imsve01 a,
                newinsa_insta01 b
          where a.dept_cd   =  b.dept_cd
            and b.dept_dt   =  ( select max(dept_dt) from newinsa_insta01 where dept_cd = a.dept_cd )
            and a.emp_no not in ( select emp_no from insa02 );
	  EXCEPTION
	      WHEN DUP_VAL_ON_INDEX THEN
		      v_check_msg := 'insert insa02_2 ������ �ߺ�';
			  v_success_flag := 'N';
		  WHEN OTHERS THEN
		      v_check_msg := 'insert insa02_2: ' || SQLERRM;
			  v_success_flag := 'N';
	  END;	  
	  
	  --create_insa_03_1
	  BEGIN
          insert into insa02
          select a.emp_no       			emp_no   ,
                 a.emp_nm      			emp_nm   ,
                 a.dept_cd      			dept_cd  ,
                 'ZF'       			title_cd ,
                 '�����'     			title_nm ,
                 a.jk_cd        			jk_cd    ,
                 a.jk_nm        			jk_nm    ,
                 '30'         			sr_cd    ,
                 '�����'       			sr_nm    ,
                 b.fk_div_cd                      div_cd   ,
                 b.dept_nm      			dept_nm  ,
                 b.site_cd      			site_cd  ,
                 '1'                              emp_divs ,          
                 f_chuljang_title('ZF' ,'00', a.jk_cd)     chuljang_title  ,          
                 a.emp_status                     emp_status ,
                 a.emp_ssn                        emp_ssn ,
          	null , null ,
                 '','','','','','','','','','','','','','','',''
           from ms_ve01 a,
                newinsa_insta01 b
          where a.dept_cd   =  b.dept_cd
            and b.dept_dt   =  ( select max(dept_dt) from newinsa_insta01 where dept_cd = a.dept_cd )
            and a.emp_no not in ( select emp_no from insa02 );
	  EXCEPTION
	      WHEN DUP_VAL_ON_INDEX THEN
		      v_check_msg := 'insert insa02_3 ������ �ߺ�';
			  v_success_flag := 'N';
		  WHEN OTHERS THEN
		      v_check_msg := 'insert insa02_3: ' || SQLERRM;
			  v_success_flag := 'N';
	  END;
	  
	  --create_insa_05
	  --�̰Ŵ� ������.
	  
	  --create_insa_06
	  BEGIN
          insert into  insa02
          select a.emp_no                           emp_no   ,
                 a.emp_name                         emp_nm   ,
                 a.dept_code                        dept_cd  ,
                 a.jikw_code                        title_cd ,
                 a.jikw_name                        title_nm ,
                 decode(a.jikc_code,'21','FG',a.jikc_code)  jk_cd , 
                 a.jikc_name                        jk_nm    ,
                 a.jikg_code                        sr_cd    ,
                 a.jikg_name                        sr_nm    ,
                 c.dvsn_code                        div_cd   ,
                 c.dept_name                        dept_nm  ,
                 '3'                                site_cd  ,
                 '4'                                emp_divs ,
                 f_chuljang_title(a.jikw_code, '1', decode(a.jikc_code,'21','FG',a.jikc_code) ) chuljang_title ,
                 a.emp_status                       emp_status,
                 jumin_no                           emp_ssn,
                 ''                                 fk_zip_cd  ,
                 ''                                 emp_addr   ,
                 substrb(nvl(a.emp_engnm, ''),1,20) engnm,
                 ''                                 emp_mail_id,
                 b.dept_sort_cd                     dept_sort_cd,
                 ''                                 emp_part,
                 ''                                 jc_nm,
                 ''                                 dept_all_nm,
                 ''                                 fk_dsp_dept_cd,
                 ''                                 saup_cd,
                 ''                                 saup_nm,
                 ''                                 fk_div_cd,
                 ''                                 emp_co_tel,
                 ''                                 div_nm,
                 ''                                 dept_fg,
                 substrb(nvl(a.ipsa_date,''),1,8)   emp_jointdt,
                 substrb(nvl(a.group_date,''),1,8)  emp_grpdt,
                 '1'                                gb
            from qa010ve            a
               , (select * from newinsa_insta01 where dept_fg = 'Y' ) b
               , fatx010            c
           where a.dept_code  = c.dept_code
             and a.dept_code  = b.dept_cd(+)
             and length(a.emp_no) = 5;
	  EXCEPTION
	      WHEN DUP_VAL_ON_INDEX THEN
		      v_check_msg := 'insert insa02_4 ������ �ߺ�';
			  v_success_flag := 'N';
		  WHEN OTHERS THEN
		      v_check_msg := 'insert insa02_4: ' || SQLERRM;
			  v_success_flag := 'N';
	  END;
	  
	  --create_insvj03_01
	  BEGIN
	      DELETE FROM insvj03_01;
	  EXCEPTION
	      WHEN OTHERS THEN
		      v_check_msg := 'delete insvj03_01: ' || SQLERRM;
			  v_success_flag := 'N';
	  END;

	  BEGIN
          insert into insvj03_01 (
                         EMP_NO, EMP_NM, EMP_STATUS, EMP_JOINDT,
                         EMP_SSN, FK_ATT_CD, FK_DSP_DEPT_CD, FK_DSP_DEPT_DT,
                         EMP_DSP_TP, EMP_MAIL_ID, TITLE_CD, TITLE_NM,
                         JC_CD, JC_NM, JK_CD, JK_NM,
                         JJ_CD, JJ_NM, DEPT_CD, DEPT_FG,
                         DEPT_DT, DEPT_NM, FK_LDR_EMP_NO, DEPT_SORT_CD,
                         DEPT_EXP_CD, DEPT_LEVEL, FK_DEPT_CD, FK_DEPT_DT,
                         DEPT_ALL_NM
                       )
          select   
                         EMP_NO, EMP_NM, EMP_STATUS, EMP_JOINDT,
                         EMP_SSN, FK_ATT_CD, FK_DSP_DEPT_CD, FK_DSP_DEPT_DT,
                         EMP_DSP_TP, EMP_MAIL_ID, TITLE_CD, TITLE_NM,
                         JC_CD, JC_NM, JK_CD, JK_NM,
                         JJ_CD, JJ_NM, DEPT_CD, DEPT_FG,
                         DEPT_DT, DEPT_NM, FK_LDR_EMP_NO, DEPT_SORT_CD,
                         DEPT_EXP_CD, DEPT_LEVEL, FK_DEPT_CD, FK_DEPT_DT,
                         DEPT_ALL_NM
          from newinsa_insvj03_01;
	  EXCEPTION
	      WHEN DUP_VAL_ON_INDEX THEN
		      v_check_msg := 'insert insvj03_01 ������ �ߺ�';
			  v_success_flag := 'N';
		  WHEN OTHERS THEN
		      v_check_msg := 'insert insvj03_01: ' || SQLERRM;
			  v_success_flag := 'N';
	  END;
	  
	  BEGIN
	      update fatx920
          set use_yn = 'N'
          where emp_no in ( select emp_no from insa02
                            where emp_status = 'T' );
	  EXCEPTION
	      WHEN OTHERS THEN
		      v_check_msg := 'update fatx920: ' ||SQLERRM;
			  v_success_flag := 'N';
	  END;
	  
	  IF v_check_msg = '' THEN
	      COMMIT;
	  END IF;
	  
	  SELECT COUNT(1)
	  INTO v_cnt1
	  FROM insa02
	  WHERE emp_divs <> '4';
		  
	  SELECT COUNT(1)
	  INTO v_cnt2
	  FROM insa02
	  WHERE emp_divs = '4';
          
	  IF v_cnt1 > 1000 AND v_cnt2 > 100 THEN
	      BEGIN    
		      DELETE FROM insa01;
		  EXCEPTION
		      WHEN OTHERS THEN
			      v_check_msg := 'delete insa01: ' || SQLERRM;
				  v_success_flag := 'N';
		  END;
		  
		  BEGIN
		      INSERT INTO insa01
			  SELECT * FROM insa02;
          EXCEPTION
	          WHEN DUP_VAL_ON_INDEX THEN
		          v_check_msg := 'insert insvj03_01 ������ �ߺ�';
				  v_success_flag := 'N';
		      WHEN OTHERS THEN
		          v_check_msg := 'insert insvj03_01: ' || SQLERRM;	  
				  v_success_flag := 'N';
		  END;
	  ELSE
	      v_check_msg := 'insa01 ������ ����';
		  v_success_flag := 'N';
	  END IF;
	  
	  IF v_check_msg = '' THEN
	      COMMIT;
	  END IF;
	  	  
	  --ALTER PROCEDURE proc_update_insa01_ch COMPILE;
	  proc_update_insa01_ch(v_flag, v_msg);
	  
	  IF v_flag = 'N' THEN
	      v_check_msg := v_msg;
		  v_success_flag := 'N';
	  END IF;
	  
	  /*analyze table insta01 compute statistics;
      analyze index inx_insta01 compute statistics;
      analyze table instj03 compute statistics;
      analyze table insve01 compute statistics;
      analyze table insvj03_01 compute statistics;	  
	 */
	 
	  IF v_check_msg = '' THEN
	      COMMIT;
      ELSE
	      ROLLBACK;
      END IF;
	  
	  batch_end_log(v_log, v_success_flag := 'N';, NULL, v_check_msg );
END;
/
