    acct  245818  397458   0 12:02:15 pts/19  0:00 grep dbsec_sql
