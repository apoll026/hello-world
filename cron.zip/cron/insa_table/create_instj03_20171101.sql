--drop table instj03;
-- FA User �� truncate ���� ���ſ� ���� ���� 2004.03.12 by ������
-- truncate table instj03;
delete from instj03;
--alter table instj03 drop constraint pk_instj03;
insert into instj03 (
                      FK_EMP_NO, DAT_ATDT, DAT_SEQ, FK_ATT_CD,
                      FK_JC_CD, FK_TITLE_CD, FK_JK_CD, FK_JJ_CD,
                      FK_SR_CD, FK_WORK_CD, FK_DEPT_CD, FK_DEPT_DT,
                      DAT_RSN, ATT_YN, WHO, TIMESTAMP
                    )
SELECT FK_EMP_NO, DAT_ATDT, 
       ROW_NUMBER() OVER (PARTITION BY FK_EMP_NO, DAT_ATDT ORDER BY FK_EMP_NO, DAT_ATDT) - 1 DAT_SEQ, 
       SUBSTR(FK_ATT_CD, 1, 2) FK_ATT_CD,
       FK_JC_CD, FK_TITLE_CD, FK_JK_CD, FK_JJ_CD,
       FK_SR_CD, '' FK_WORK_CD, FK_DEPT_CD, FK_DEPT_DT,
       DAT_RSN, ATT_YN, '' WHO, SYSDATE TIMESTAMP
  FROM NEWINSA_INSTJ03
/

--alter ���� ���� 2009.01.03 ȿ��
--alter table instj03  
--add constraint pk_instj03  primary key  ( fk_emp_no , dat_atdt , dat_seq )
--using index tablespace ts_fa_idx04
--pctfree 5
--storage ( initial     512K
--          next        512K
--          pctincrease 0 )
--/
