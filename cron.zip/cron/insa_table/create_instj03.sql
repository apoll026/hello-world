--2017.11.01 �λ�DB ��ָ� ����� ����� �����Ͱ� ������ ROLLBACK �Ǵ� ������� ����

set serveroutput on;

DECLARE
    v_cnt1    NUMBER(10);
    
BEGIN
    v_cnt1 := 0;

	SELECT COUNT(*)
    	  INTO   v_cnt1
       FROM NEWINSA_INSTJ03;
          
	IF v_cnt1 > 1000 THEN
	 
		delete from instj03;
		
		insert into instj03 (
		                      FK_EMP_NO, DAT_ATDT, DAT_SEQ, FK_ATT_CD,
		                      FK_JC_CD, FK_TITLE_CD, FK_JK_CD, FK_JJ_CD,
		                      FK_SR_CD, FK_WORK_CD, FK_DEPT_CD, FK_DEPT_DT,
		                      DAT_RSN, ATT_YN, WHO, TIMESTAMP
		                    )
		SELECT FK_EMP_NO, DAT_ATDT, 
		       ROW_NUMBER() OVER (PARTITION BY FK_EMP_NO, DAT_ATDT ORDER BY FK_EMP_NO, DAT_ATDT) - 1 DAT_SEQ, 
		       SUBSTR(FK_ATT_CD, 1, 2) FK_ATT_CD,
		       FK_JC_CD, FK_TITLE_CD, FK_JK_CD, FK_JJ_CD,
		       FK_SR_CD, '' FK_WORK_CD, FK_DEPT_CD, FK_DEPT_DT,
		       DAT_RSN, ATT_YN, '' WHO, SYSDATE TIMESTAMP
		  FROM NEWINSA_INSTJ03;
		  
	ELSE
        dbms_output.put_line('create_instj03 : NEWINSA_INSTJ03 ������ ����!!');
    END IF;
    
    SELECT COUNT(*)
      INTO v_cnt1
      FROM instj03;

    dbms_output.put_line('INSTJ03 COUNT : '||v_cnt1);
      
    COMMIT;
    
EXCEPTION
    WHEN OTHERS THEN
        dbms_output.put_line('create_instj03 : DB Error'||sqlcode||sqlerrm);
        ROLLBACK;
                
END;
/
SHOW ERROR;

