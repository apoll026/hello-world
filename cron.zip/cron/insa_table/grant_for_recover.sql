grant all on insa01 to sea with grant option;
grant all on insa01 to biz with grant option;
grant all on insa01 to apt with grant option;
grant all on insa01 to plan with grant option;
grant all on insa01 to ja with grant option;
