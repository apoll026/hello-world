DROP SNAPSHOT pmis_job;
CREATE SNAPSHOT pmis_job
 TABLESPACE TS_ACCT01
 PCTFREE    5
 PCTUSED    60
 STORAGE    (INITIAL	1M
 	     NEXT	1M
             PCTINCREASE  0)
 USING   INDEX TABLESPACE TS_ACCT01_IDX
 STORAGE ( INITIAL     500K
 	   NEXT	       500K
 	   PCTINCREASE    0
 )
 REFRESH FORCE WITH ROWID
 NEXT (trunc(sysdate) + 1 + 3/24)
AS
select pjt_no,
        grp_cd,
        disc_cd,
        pos_cd,
        hf_fg,
        seq,
        emp_no,
        emp_nm,
        lvl,
        pos_des,
        pgrp_cd,
        pdept_cd,
        pdisc_cd,
        ppos,
        phf_fg,
        pseq,
        sch_str_dt,
        sch_end_dt,
        sysdate upd_date
 from t_stf_org_chart
where nvl(emp_no,'99999') <> '99999'
/
exec dbms_snapshot.refresh('pmis_job')
