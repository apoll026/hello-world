
insert into insa02 values ('lgcns', 'LGCNS', 'H2220', 'V0', '�븮','ZZ','','A3','3��','H1','�繫ȸ����','1','1','D5','C','','','',
'','lgcns','','','','','','','','','','','','',to_char(sysdate,'YYYYMMDD'),'');

BEGIN
insert into  insa02
SELECT A.EMP_NO EMP_NO,
       SUBSTRB(A.EMP_NAME, 1, 20) EMP_NM,
       A.DEPT_CODE DEPT_CD,
       A.JIKW_CODE TITLE_CD,
       A.JIKW_NAME TITLE_NM,
       DECODE(A.JIKC_CODE, '21', 'JTETC008' ,A.JIKC_CODE) JK_CD,
       A.JIKC_NAME JK_NM,
       A.JIKG_CODE SR_CD,
       A.JIKG_NAME SR_NM,
       D.DVSN_CODE DIV_CD,
       SUBSTRB(D.DEPT_NAME, 1, 50) DEPT_NM,
       '3' SITE_CD,
       '4' EMP_DIVS,
       F_CHULJANG_TITLE(A.JIKW_CODE, '1', DECODE(A.JIKC_CODE, '21', 'JTETC008', A.JIKC_CODE)) CHULJANG_TITLE,
       A.EMP_STATUS EMP_STATUS,
       '' EMP_SSN,
       '' FK_ZIP_CD,
       '' EMP_ADDR,
       SUBSTRB(NVL(A.EMP_ENGNM, ''), 1, 20) ENGNM,
       '' EMP_MAIL_ID,
       B.DEPT_SORT_CD DEPT_SORT_CD,
       '' EMP_PART,
       '' JC_NM,
       '' DEPT_ALL_NM,
       '' FK_DSP_DEPT_CD,
       '' SAUP_CD,
       '' SAUP_NM,
       '' FK_DIV_CD,
       '' EMP_CO_TEL,
       '' DIV_NM,
       '' DEPT_FG,
       SUBSTRB(NVL(A.IPSA_DATE, ''), 1, 8) EMP_JOINTDT,
       SUBSTRB(NVL(A.GROUP_DATE, ''), 1, 8) EMP_GRPDT,
       '1' GB
  FROM QA010VE A,
       ORM_INF_ORG B,      --C20171130_45037  �λ� �� ��ü �۾�
       FATX010 D
 WHERE A.DEPT_CODE  = D.DEPT_CODE
   AND A.DEPT_CODE  = B.DEPT_CD(+)   
   AND B.CORP_CODE = '000001'
   AND B.DEPT_FG = 'Y'
   AND B.DEPT_DT = (SELECT MAX(DEPT_DT) FROM ORM_INF_ORG WHERE DEPT_CD = A.DEPT_CODE AND CORP_CODE = '000001')
   AND LENGTH(A.EMP_NO) = 5;  
   
  
   
EXCEPTION
  when others then
   dbms_output.put_line('06_ERR');
   null;
END;

/
