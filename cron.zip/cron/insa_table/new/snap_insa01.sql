DROP SNAPSHOT insa01;
CREATE SNAPSHOT insa01
       TABLESPACE TS_ACCT01
       PCTFREE    5
       PCTUSED    60
       STORAGE    (INITIAL      1M
                   NEXT         1M
                   PCTINCREASE  0)
       USING   INDEX TABLESPACE TS_ACCT01_IDX
                     STORAGE ( INITIAL     500K
                               NEXT        500K
                               PCTINCREASE    0
                             )
       REFRESH FORCE
       NEXT (trunc(sysdate) + 1 + 3/24)
AS
select distinct
       a.emp_no       			emp_no   , 
       a.emp_nm      			emp_nm   , 
       a.dept_cd      			dept_cd  ,
       a.title_cd     			title_cd ,
       a.title_nm     			title_nm ,
       a.jk_cd        			jk_cd    ,
       a.jk_nm        			jk_nm    ,
       b.fk_div_cd                      div_cd   ,
       b.dept_nm      			dept_nm  ,
       b.site_cd      			site_cd  ,
       '1'                              emp_divs ,
       f_chuljang_title(a.title_cd)     chuljang_title  
 from newinsa.insve01_01@lgcon05 a,
      newinsa.insta01@lgcon05 b
where a.dept_cd   =  b.dept_cd(+)
  and b.dept_fg   =  'Y'
/
exec dbms_snapshot.refresh('insa01')
/
