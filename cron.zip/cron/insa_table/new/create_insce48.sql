drop table insce48;
create table insce48
as select  *
 from cdmgr.insce48@lgcon05 
/
alter table insce48
add constraint pk_insce48  primary key  ( zip_num )
using index tablespace ts_acct01_idx
pctfree 5
storage ( initial     512K
          next        512K
          pctincrease 0 )
/
grant all on insce48 to public with grant option 
/
