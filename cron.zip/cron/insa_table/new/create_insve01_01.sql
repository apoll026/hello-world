drop table insve01_01;
create table insve01_01
as select  *
 from newinsa.insve01_01@lgcon05 
/
alter table insve01_01  
add constraint pk_insve01_01  primary key  ( emp_no        )
using index tablespace ts_acct01_idx
pctfree 5
storage ( initial     512K
          next        512K
          pctincrease 0 )
/
grant all on insve01_01 to public with grant option 
/
