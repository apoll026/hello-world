grant all on PROC_RETN_SLIP to apt with grant option 
/
