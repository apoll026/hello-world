drop table insve01;
create table insve01
as select  *
 from newinsa.insve01@lgcon05 
/
alter table insve01 
add constraint pk_insve01  primary key  ( emp_no        )
using index tablespace ts_acct01_idx
pctfree 5
storage ( initial     512K
          next        512K
          pctincrease 0 )
/
grant all on insve01 to public with grant option 
/
