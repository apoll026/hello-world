--��赿 �λ� insert
-- insert into  insa01
-- (select  *
--  from insa01_bb )
insert into insa00
( EMP_NO,
  EMP_NM,
  DEPT_CD,
  TITLE_CD,
  TITLE_NM,
  JK_CD,
  JK_NM,
  SR_CD,
  SR_NM,
  DIV_CD,
  DEPT_NM,
  SITE_CD,
  EMP_DIVS,
  CHULJANG_TITLE,
  EMP_STATUS,
  EMP_SSN,
  FK_ZIP_CD,
  EMP_ADDR)
(select * from insa01_bb
 where emp_no not in ( select emp_no from insa00
                       where emp_no in (select emp_no from insa01_bb))
)
/
