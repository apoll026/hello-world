drop table curctbl;
create table curctbl as select code curc_code, rtrim(substr(code_name, 1, 3)) curc_match
                       from fatx800
                      where classify = '34'
/
