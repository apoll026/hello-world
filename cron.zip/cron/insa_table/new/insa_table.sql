@create_insa_01.sql
@create_insa_03.sql
@create_insa_04.sql
@create_insa_05.sql
@create_insa_06.sql
@create_insa_07.sql
