drop table insa01_bk;
create table insa01_bk 
as select  *
 from insa01
/
alter table insa01_bk
add constraint pk_insa01_bk   primary key  ( emp_no        )
using index tablespace ts_acct01_idx
pctfree 5
storage ( initial     100K
          next        100K
          pctincrease 0 )
/

