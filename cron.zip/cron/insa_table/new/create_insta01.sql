drop table insta01;
create table insta01
as select  *
 from newinsa.insta01@lgcon05 
/
alter table insta01 
add constraint pk_insta01  primary key  ( dept_cd , dept_dt )
using index tablespace ts_acct01_idx
pctfree 5
storage ( initial     512K
          next        512K
          pctincrease 0 )
/
grant all on insta01 to public with grant option 
/
