select count(*) from insa00
/
