drop table instj03;
create table instj03
as select  *
 from newinsa.instj03@lgcon05 
/
alter table instj03  
add constraint pk_instj03  primary key  ( fk_emp_no , dat_atdt , dat_seq )
using index tablespace ts_acct01_idx
pctfree 5
storage ( initial     512K
          next        512K
          pctincrease 0 )
/
grant all on instj03 to public with grant option 
/
