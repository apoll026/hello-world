insert into insa00 ( emp_no , emp_nm , emp_divs , emp_status )
values ( '80001','����1','4','C')
/
insert into insa00 ( emp_no , emp_nm , emp_divs , emp_status )
values ( '80002','����2','4','C')
/
insert into insa00 ( emp_no , emp_nm , emp_divs , emp_status )
values ( '80003','����3','4','C')
/
