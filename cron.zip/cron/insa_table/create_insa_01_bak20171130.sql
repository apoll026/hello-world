--2017.11.01 �λ�DB ��ָ� ����� ����� �����Ͱ� ������ ROLLBACK �Ǵ� ������� ����

set serveroutput on;

DECLARE
    v_cnt1    NUMBER(10);
    
BEGIN
    v_cnt1 := 0;

	SELECT COUNT(*)
    	  INTO   v_cnt1
      FROM NEWINSA_INSVE01 A,
		       PHM_INF_EMP B,
		       ORM_INF_ORG C,
		       NEWINSA_INSTA01 D
		 WHERE A.DEPT_CD = C.DEPT_CD(+)
		   AND A.DEPT_CD = D.DEPT_CD(+)
		   AND A.EMP_NO = B.EMP_NO(+)
		   AND C.CORP_CODE = '000001'
		   AND C.DEPT_FG = 'Y'
		   AND D.DEPT_DT = (SELECT MAX(DEPT_DT) FROM NEWINSA_INSTA01 WHERE DEPT_CD = A.DEPT_CD)
		   AND D.DEPT_FG = 'Y';
          
	 IF v_cnt1 > 1000 THEN
	 
		delete from insa02;
		
		insert into insa02
		SELECT A.EMP_NO EMP_NO,
		       SUBSTRB(A.EMP_NM, 1, 20) EMP_NM,
		       A.DEPT_CD DEPT_CD,
		       A.TITLE_CD TITLE_CD,
		       A.TITLE_NM TITLE_NM, 
		       A.JK_CD JK_CD,
		       A.JK_NM JK_NM,
		       A.SR_CD SR_CD,
		       A.SR_NM SR_NM,
		       B.FK_DIV_CD DIV_CD,
		       SUBSTRB(C.DEPT_NM, 1, 50) DEPT_NM,
		       C.SITE_CD SITE_CD,
		       DECODE(SUBSTR(A.DEPT_SORT_CD, 1, 2), 'A3', '2', 'A5', '2', 'AS', '2', '1') EMP_DIVS,
		       DECODE(SUBSTR(A.FK_HIRE_TP, 1, 3), 'TMP', F_CHULJANG_TITLE('TMP', '', ''), 
		                                                 F_CHULJANG_TITLE(A.TITLE_CD, A.SR_CD, A.JK_CD)) CHULJANG_TITLE,
		       A.EMP_STATUS EMP_STATUS,
		       '' EMP_SSN,
		       C.FK_ZIP_CD FK_ZIP_CD,
		       '' EMP_ADDR,
		       SUBSTRB(A.EMP_ENGNM, 1, 20) ENGNM,
		       SUBSTRB(A.EMP_MAIL_ID, 1, 15) EMP_MAIL_ID,
		       D.DEPT_SORT_CD DEPT_SORT_CD,
		       DECODE(SUBSTR(A.DEPT_SORT_CD, 1, 2), 'A3', 'E', 'A5', 'E', 'AS', 'E', 'C') EMP_PART,
		       A.JC_NM JC_NM,
		       A.DEPT_ALL_NM DEPT_ALL_NM,
		       '' FK_DSP_DEPT_CD,       
		       F_GET_DIV_CD('01', 'KOR', A.DEPT_CD, SYSDATE, '3') SAUP_CD,
		       F_GET_DIV_CD('01', 'KOR', A.DEPT_CD, SYSDATE, '30') SAUP_NM,
		       C.FK_DIV_CD FK_DIV_CD,
		       '' EMP_CO_TEL,
		       '' DIV_NM,
		       C.DEPT_FG DEPT_FG, 
		       NVL(TO_CHAR(A.EMP_JOINDT, 'YYYYMMDD'),'') EMP_JOINDT,
		       NVL(TO_CHAR(A.EMP_GRPDT, 'YYYYMMDD'),'') EMP_GRPDT,
		       DECODE(SUBSTR(A.DEPT_SORT_CD, 1, 2), 'A3', '2', 'A5', '2', 'AS', '2', '1') GB            
		  FROM NEWINSA_INSVE01 A,
		       PHM_INF_EMP B,
		       ORM_INF_ORG C,
		       NEWINSA_INSTA01 D
		 WHERE A.DEPT_CD = C.DEPT_CD(+)
		   AND A.DEPT_CD = D.DEPT_CD(+)
		   AND A.EMP_NO = B.EMP_NO(+)
		   AND C.CORP_CODE = '000001'
		   AND C.DEPT_FG = 'Y'
		   AND D.DEPT_DT = (SELECT MAX(DEPT_DT) FROM NEWINSA_INSTA01 WHERE DEPT_CD = A.DEPT_CD)
		   AND D.DEPT_FG = 'Y';
		   
	ELSE
        dbms_output.put_line('create_insa_01 : NEWINSA_INSVE01 ������ ����!!');
    END IF;
    
    SELECT COUNT(*)
      INTO v_cnt1
      FROM insa02;

    dbms_output.put_line('INSA02 COUNT : '||v_cnt1);
      
    COMMIT;
    
EXCEPTION
    WHEN OTHERS THEN
        dbms_output.put_line('create_insa_01 : DB Error'||sqlcode||sqlerrm);
        ROLLBACK;
                
END;
/
SHOW ERROR;

