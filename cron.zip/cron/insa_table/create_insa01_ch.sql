insert into insa01_ch 
select emp_no, dept_cd,null, null, x.site_cd,'2','C'
  from insa01 a, fatx010 x
 where emp_no = 'M0082'
   and dept_cd= dept_code
/
