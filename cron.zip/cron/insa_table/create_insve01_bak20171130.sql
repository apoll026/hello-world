--drop table insve01;
-- FA User �� truncate ���� ���ſ� ���� ���� 2004.03.12 by ������
-- truncate table insve01;
-- 2015.08.29 Ŀ�Էѹ�ǰ� ���� 
--2017.11.01 �λ�DB ��ָ� ����� ����� �����Ͱ� ������ ROLLBACK �Ǵ� ������� ����

set serveroutput on;
DECLARE
	v_cnt1    NUMBER(10);
    --v_msg     VARCHAR2(200);
BEGIN
	v_cnt1 := 0;
	
	SELECT COUNT(*)
    	  INTO   v_cnt1
       FROM NEWINSA_INSVE01 A, NEWINSA_INSTA01 B, ORM_INF_ORG C
	 WHERE A.DEPT_CD = B.DEPT_CD(+)
		  AND A.DEPT_CD = C.DEPT_CD(+)
         AND B.DEPT_FG = 'Y'
         AND C.DEPT_FG = 'Y'
         AND C.CORP_CODE = '000001';
          
	 IF v_cnt1 > 1000 THEN

		delete from insve01;
		--alter table insve01 drop constraint pk_insve01;
		insert into insve01(
		                    EMP_NO, EMP_NM, EMP_STATUS, EMP_JOINDT,
		                    EMP_GRPDT, EMP_SSN, EMP_DSP_TP, TITLE_CD,
		                    TITLE_NM, JC_CD, JC_NM, JK_CD,
		                    JK_NM, JJ_CD, JJ_NM, WORK_CD,
		                    WORK_NM, SR_CD, SR_NM, DEPT_CD,
		                    DEPT_FG, DEPT_DT, DEPT_NM, FK_LDR_EMP_NO,
		                    DEPT_SORT_CD, DEPT_LEVEL, FK_DEPT_CD, FK_DEPT_DT,
		                    AT_ATDT, AT_SEQ, EMP_PG_MANU, EMP_PG_OFFICE,
		                    EMP_PG_NO, EMP_CO_PN_AREA, EMP_CO_PN_OFFICE, EMP_CO_PN_NO,
		                    EMP_PART
		                   )
		SELECT A.EMP_NO, SUBSTRB(A.EMP_NM, 1, 20) EMP_NM, A.EMP_STATUS, A.EMP_JOINDT,
		       A.EMP_GRPDT, '' EMP_SSN, '' EMP_DSP_TP, A.TITLE_CD,
		       A.TITLE_NM, A.JC_CD, A.JC_NM, A.JK_CD,
		       A.JK_NM, SUBSTRB(A.JJ_CD, 1, 2) JJ_CD, A.JJ_NM, A.WORK_CD,
		       A.WORK_NM, A.SR_CD, A.SR_NM, A.DEPT_CD,
		       A.DEPT_FG, A.DEPT_DT, SUBSTRB(A.DEPT_NM, 1, 50), A.FK_LDR_EMP_NO,
		       A.DEPT_SORT_CD, C.DEPT_LEVEL, A.FK_DEPT_CD, '' FK_DEPT_DT,
		       A.AT_ATDT, A.AT_SEQ, '' EMP_PG_MANU, '' EMP_PG_OFFICE,
		       '' EMP_PG_NO, '' EMP_CO_PN_AREA, '' EMP_CO_PN_OFFICE, '' EMP_CO_PN_NO,
		       DECODE(SUBSTR(A.DEPT_SORT_CD, 1, 2), 'A3', 'E', 'A5', 'E', 'C') EMP_PART
		  FROM NEWINSA_INSVE01 A, NEWINSA_INSTA01 B, ORM_INF_ORG C
		 WHERE A.DEPT_CD = B.DEPT_CD(+)
		   AND A.DEPT_CD = C.DEPT_CD(+)
		   AND B.DEPT_FG = 'Y'
		   AND C.DEPT_FG = 'Y'
		   AND C.CORP_CODE = '000001';
		   
	ELSE
        dbms_output.put_line('create_insve01 : NEWINSA_INSVE01 ������ ����!!');
    END IF;
    
    SELECT COUNT(*)
      INTO v_cnt1
      FROM insve01;

    dbms_output.put_line('INSVE01 COUNT : '||v_cnt1);
        
    COMMIT;
    
EXCEPTION
    WHEN OTHERS THEN
        dbms_output.put_line('create_insve01 : DB Error'||sqlcode||sqlerrm);
        ROLLBACK;
END;
/
SHOW ERROR;

/*
alter table insve01 
add constraint pk_insve01  primary key  ( emp_no        )
using index tablespace ts_fa_idx04
pctfree 5
storage ( initial     512K
          next        512K
          pctincrease 0 )
/
*/
