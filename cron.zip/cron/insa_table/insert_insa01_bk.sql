DECLARE
    v_cnt1    NUMBER(10);
    v_cnt2    NUMBER(10);
    v_msg     VARCHAR2(200);
BEGIN
    v_cnt1 := 0;
    v_cnt2 := 0;

    SELECT COUNT(*)
    INTO   v_cnt1
    FROM   INSA02
    WHERE  EMP_DIVS != '4';
   
    SELECT COUNT(*)
    INTO   v_cnt2
    FROM   INSA02
    WHERE  EMP_DIVS = '4';

    IF v_cnt1 > 1000 AND v_cnt2 > 100 THEN

        DELETE FROM INSA01_dbsec#;

        INSERT INTO INSA01_dbsec#
        SELECT * FROM INSA02_dbsec#;
    ELSE
        dbms_output.put_line('insa02 ������ ����!!');
    END IF;
    

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        dbms_output.put_line('DB Error'||sqlcode||sqlerrm);
        ROLLBACK;
END;
/
SHOW ERROR;
/
