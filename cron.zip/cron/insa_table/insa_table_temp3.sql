!cd /app/acct/cron/insa_table
!date >> insa_table.log
@@backup_insa01.sql
commit;
!date >> insa_table.log
exit
