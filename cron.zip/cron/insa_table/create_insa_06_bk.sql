insert into  insa02
select a.inempno     			emp_no   , 
       a.inname      			emp_nm   , 
       a.indeptcd    			dept_cd  ,
       a.injikwcd     			title_cd ,
       kk_func_code_name('31',a.injikwcd) title_nm,
       a.injikccd     			jk_cd    ,
       kk_func_code_name('32',a.injikccd) jk_nm,
       ''                               cr_cd,
       ''                               cr_nm,
       c.dvsn_code                      div_cd   ,
       c.dept_name    			dept_nm  ,
       '3'            			site_cd  ,
       '4'                              emp_divs ,
-- 2005.02.28 C2005022301000000346 ���������ȭ�� ������û
-- '���(D6)' �������� �߰�
--      f_chuljang_title(a.injikccd, '1') chuljang_title  ,
       f_chuljang_title(a.injikccd, '1', a.injikccd) chuljang_title  ,
-- ������
       decode(a.instat, '1', 'C', 'T')  emp_status,
       '' emp_ssn,
       ''                               fk_zip_cd  ,
       ''                               emp_addr   ,
       substrb(nvl(a.inengnm, ''),1,20) engnm,
       ''                               emp_mail_id,
       ''                               dept_sort_cd,
       ''                               emp_part,
       ''                               jc_nm,
       ''                               dept_all_nm,
       ''                               fk_dsp_dept_cd,
       ''                               saup_cd,
       ''                               saup_nm,
       ''                               fk_div_cd,
       ''                               emp_co_tel,
       ''                               div_nm,
       ''                               dept_fg,
       substrb(nvl(a.inipsdate,''),1,8) emp_jointdt,
       substrb(nvl(a.ingrpdate,''),1,8) emp_grpdt,
       '1'                              gb
 from insamast@ora7 a,
      fatx010       c
where a.indeptcd  = c.dept_code
  and length(a.indeptcd) > 4
/
