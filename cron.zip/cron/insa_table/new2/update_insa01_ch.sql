var p_flag varchar2(1000);
var p_msg varchar2(1000);
Exec proc_update_insa01_ch(:p_flag, :p_msg)
/
