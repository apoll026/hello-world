BEGIN
insert into  insa02
select a.emp_no                           emp_no   ,
       a.emp_name                         emp_nm   ,
       a.dept_code                        dept_cd  ,
       a.jikw_code                        title_cd ,
       a.jikw_name                        title_nm ,--kk_func_code_name('31',a.injikwcd) title_nm,
       a.jikc_code                        jk_cd    ,
       a.jikc_name                        jk_nm    ,--kk_func_code_name('32',a.injikccd) jk_nm,
       a.jikg_code                        sr_cd    ,
       a.jikg_name                        sr_nm    ,
       c.dvsn_code                        div_cd   ,
       c.dept_name                        dept_nm  ,
       '3'                                site_cd  ,
       '4'                                emp_divs ,
       f_chuljang_title(a.jikw_code, '1') chuljang_title  ,
       a.emp_status                       emp_status,
       jumin_no                           emp_ssn,
       ''                                 fk_zip_cd  ,
       ''                                 emp_addr   ,
       substrb(nvl(a.emp_engnm, ''),1,20) engnm,
       ''                                 emp_mail_id,
       ''                                 dept_sort_cd,
       ''                                 emp_part,
       ''                                 jc_nm,
       ''                                 dept_all_nm,
       ''                                 fk_dsp_dept_cd,
       ''                                 saup_cd,
       ''                                 saup_nm,
       ''                                 fk_div_cd,
       ''                                 emp_co_tel,
       ''                                 div_nm,
       ''                                 dept_fg,
       substrb(nvl(a.ipsa_date,''),1,8)   emp_jointdt,
       substrb(nvl(a.group_date,''),1,8)  emp_grpdt,
       '1'                                gb
  from kcuser.qa010ve@kcuser a,
       fatx010            c
 where a.dept_code  = c.dept_code
   and length(a.emp_no) = 5;

EXCEPTION
  when others then
   dbms_output.put_line('06_ERR');
   null;
END;

/
