/***********************************************************
 system��       : ȸ��ý���
 sub system��   : ��ǥ ����
 function��     : proc_update_insa01_ch.sql
 description    : ��ǥ�ڷḦ �о �ܾ׸� �����Ѵ�.
 parameters(in) : p_strt, p_fnsh
 parameters(out): p_flag      - Y/N
                  p_msg       - Error�� Message

 ��������      ������  �������
------------------------------------------------------------
 2000.01.24    �赿ȯ  �ʱ��ۼ�
***********************************************************/

CREATE OR REPLACE PROCEDURE proc_update_insa01_ch( p_flag   OUT VARCHAR2,
                                               p_msg    OUT VARCHAR2)
IS
    USER_ERR       EXCEPTION;
    v_insa01       insa01%rowtype;
    v_nadjt_rec    fata500%rowtype;
    p_old_dept_cd  varchar2(6);
    p_to_day       varchar2(8);
    p_chng_date    varchar2(8);
    p_dept_cd      varchar2(6);
    v_msg          varchar2(100);

    -- �ܾ� �̿� ��ǥ(88��)�� ����
    CURSOR insa_cur IS
        SELECT * FROM INSA02
        WHERE EMP_STATUS = 'C'
        ORDER BY EMP_NO; 

BEGIN

     BEGIN
       SELECT TO_CHAR(sysdate, 'yyyymmdd') INTO p_to_day
         FROM DUAL;

     EXCEPTION
        WHEN OTHERS THEN
           p_msg := '��¥SELECT ERROR';
           raise user_err;
     END;
 
    OPEN insa_cur;
    LOOP
        FETCH insa_cur INTO v_insa01;
        EXIT WHEN insa_cur%NOTFOUND;

        p_old_dept_cd := '';
        p_chng_date := '';

        BEGIN
          SELECT NVL(dept_cd,'') INTO p_old_dept_cd
          FROM INSA01_BK
          WHERE EMP_NO = v_insa01.emp_no;

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
             p_old_dept_cd := '';
          WHEN OTHERS THEN
             p_msg := '�λ���SELECT ERROR';
             raise user_err;
        END;

        IF LENGTH(p_old_dept_cd) > 0 THEN
            p_chng_date := p_to_day;
        ELSE
            p_chng_date := '';
        END IF; 

       IF v_insa01.dept_cd <> p_old_dept_cd THEN
           
          BEGIN
             INSERT INTO INSA01_CH
               (EMP_NO, DEPT_CD, OLD_DEPT_CD,
                CHNG_DATE, SITE_CD, EMP_DIVS, EMP_STATUS)
              VALUES ( v_insa01.emp_no, v_insa01.dept_cd, p_old_dept_cd,
                       p_chng_date, v_insa01.site_cd, v_insa01.emp_divs,
                       v_insa01.emp_status);    
                      
           EXCEPTION
     	      WHEN DUP_VAL_ON_INDEX THEN
    	        UPDATE  INSA01_CH        
          	    SET DEPT_CD = v_insa01.dept_cd,
                        OLD_DEPT_CD = p_old_dept_cd,
                        CHNG_DATE = p_chng_date,
                        SITE_CD = v_insa01.site_cd,
                        EMP_DIVS = v_insa01.emp_divs,
                        EMP_STATUS = v_insa01.emp_status
                  WHERE EMP_NO = v_insa01.emp_no;

              WHEN OTHERS THEN
                  p_msg := '�λ������μ�����insert Error';
                  raise user_err;
           END;

       ELSE

          BEGIN
             INSERT INTO INSA01_CH
               (EMP_NO, DEPT_CD,
                SITE_CD, EMP_DIVS, EMP_STATUS)
              VALUES ( v_insa01.emp_no, v_insa01.dept_cd,
                       v_insa01.site_cd, v_insa01.emp_divs,
                       v_insa01.emp_status);    
                      
           EXCEPTION
     	      WHEN DUP_VAL_ON_INDEX THEN
    	        UPDATE  INSA01_CH        
          	    SET DEPT_CD = v_insa01.dept_cd,
                        SITE_CD = v_insa01.site_cd,
                        EMP_DIVS = v_insa01.emp_divs,
                        EMP_STATUS = v_insa01.emp_status
               WHERE EMP_NO = v_insa01.emp_no;

           WHEN OTHERS THEN
             p_msg := '�λ������μ�����insert Error';
             raise user_err;

           END;

       END IF; 

    END LOOP;

    p_flag := 'Y';
    dbms_output.put_line( 'INSA01_CH ���� ����');
    commit;

EXCEPTION        
    WHEN OTHERS THEN
        p_msg := p_msg||';insa�����μ���������'||sqlcode;
        p_flag := 'N';
        dbms_output.put_line(p_msg);
        rollback;

END ;
--proc_update_insa01_ch;
/
SHOW ERROR;
/
