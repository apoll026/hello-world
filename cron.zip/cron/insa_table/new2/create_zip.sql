drop table insce48
/
create table insce48
as select  *
 from insce48_bk
/
alter table insce48
add constraint pk_insce48  primary key  ( seq, zip_num, zip_address )
using index tablespace ts_acct01_idx
pctfree 5
storage ( initial     2M
          next        2M
          pctincrease 0 )

/

