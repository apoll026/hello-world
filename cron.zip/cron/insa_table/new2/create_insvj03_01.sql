Drop Table insvj03_01 ; 
Create Table insvj03_01
as select  *
 from newinsa.insvj03_01@lgcon05
/
grant all on insvj03_01 to public with grant option
/
