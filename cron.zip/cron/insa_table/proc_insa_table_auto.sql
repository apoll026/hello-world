DECLARE
v_log VARCHAR2(50);
v_check VARCHAR2(1000);
v_today   VARCHAR2(8);

  BEGIN
      v_log := batch_start_log('12');
      
      select to_char(sysdate,'YYYYMMDD')
      into   v_today
      from dual;
      
      BEGIN
          select emp_grpdt
          into   v_check
          from insa01
         where emp_no='lgcns';
      EXCEPTION
          WHEN OTHERS THEN
              v_check := '';
      END;
    
      IF v_check <> v_today THEN
          batch_end_log(v_log, 'N' , NULL, 'insa01 ����Ÿ�� ���� ��¥�� �ƴմϴ�.' );
      END IF;
      batch_end_log(v_log, 'Y' , NULL, '' );
  END;
/