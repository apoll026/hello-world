select * from insa01
where emp_no = 'M0027'
/
