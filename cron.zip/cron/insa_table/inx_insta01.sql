drop index inx_insta01;
create index inx_insta01 on insta01 ( dept_sort_cd )
tablespace ts_fa_idx04
pctfree 5
storage ( initial      1M
          next         1M
          pctincrease  0 )
/
