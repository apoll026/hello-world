--drop table insta01;
-- FA User �� truncate ���� ���ſ� ���� ���� 2004.03.12 by ������
-- truncate table insta01;
delete from insta01;
--alter table insta01 drop constraint pk_insta01;
insert into insta01 (
                     DEPT_CD, DEPT_DT, FK_APPT_CD, DEPT_NM,
                     DEPT_ENGNM, DEPT_SORT_CD, DEPT_SEQ, DEPT_FG,
                     DEPT_DESC, DEPT_LEVEL, FK_LDR_EMP_NO, FK_DIV_CD,
                     FK_DIV_DT, FK_DEPT_CD, FK_DEPT_DT, FK_DOC_CD,
                     FK_WKP_CD, FK_AREA_CD, FK_WORK_CD, FK_GUPJI_CD,
                     SITE_CD, FK_PM_EMP_NO, FK_BUSINESS_CD, FK_MARKET_CD,
                     DEPT_PN_AREA, DEPT_PN_OFFICE, DEPT_PN_NO, DEPT_FAX_AREA,
                     DEPT_FAX_OFFICE, DEPT_FAX_NO, FK_ZIP_CD, DEPT_ADDR,
                     SAUP_ST_DT, SAUP_ED_DT, SAUP_MANG_NUM, UPJONG_CD,
                     WHO, TIMESTAMP, EMP_PART, TOT,
                     CURR, ENG2, COST, JIKMU,
                     DVSN_DEPT, MANG_DEPT, sub_ldr_emp_no
                    )
SELECT B.DEPT_CD DEPT_CD, B.DEPT_DT DEPT_DT, '' FK_APPT_CD, SUBSTRB(B.DEPT_NM, 1, 50) DEPT_NM,  
       B.DEPT_ENGNM DEPT_ENGNM, REPLACE(B.DEPT_SORT_CD, '.', '') DEPT_SORT_CD, '' DEPT_SEQ, B.DEPT_FG DEPT_FG,
       B.DEPT_DESC DEPT_DESC, A.DEPT_LEVEL DEPT_LEVEL, B.FK_LDR_EMP_NO FK_LDR_EMP_NO, A.FK_DIV_CD FK_DIV_CD,
       '' FK_DIV_DT, B.FK_DEPT_CD FK_DEPT_CD, '' FK_DEPT_DT, '' FK_DOC_CD,
       '' FK_WKP_CD, '' FK_AREA_CD, B.FK_WORK_CD FK_WORK_CD, SUBSTR(B.FK_GUPJI_CD, 1, 1) FK_GUPJI_CD,
       C.SITE_CD SITE_CD, B.FK_PM_EMP_NO FK_PM_EMP_NO, A.FK_BUSINESS_CD FK_BUSINESS_CD, A.FK_MARKET_CD FK_MARKET_CD,
       '' DEPT_PN_AREA, '' DEPT_PN_OFFICE, '' DEPT_PN_NO, '' DEPT_FAX_AREA,
       A.DEPT_FAX_OFFICE DEPT_FAX_OFFICE, A.DEPT_FAX_NO DEPT_FAX_NO, A.FK_ZIP_CD FK_ZIP_CD, 
       SUBSTRB(B.DEPT_ADDR, 1, 70) DEPT_ADDR,
       '' SAUP_ST_DT, '' SAUP_ED_DT, '' SAUP_MANG_NUM, '' UPJONG_CD,
       'batch' WHO, SYSDATE TIMESTAMP, 
       DECODE(SUBSTR(A.DEPT_SORT_CD, 1, 2), 'A3', 'E', 'A5', 'E', 'AS', 'E', 'C') EMP_PART, '' TOT,
       '' CURR, '' ENG2, '' COST, '' JIKMU,
       '' DVSN_DEPT, '' MANG_DEPT, '' SUB_LDR_EMP_NO
  FROM ORM_INF_ORG A, NEWINSA_INSTA01 B, FATX010 C
 WHERE B.DEPT_CD = A.DEPT_CD(+) 
   AND B.DEPT_CD = C.DEPT_CODE(+)
   AND A.CORP_CODE = '000001'
   AND A.DEPT_FG = 'Y'
   AND B.DEPT_FG = 'Y';