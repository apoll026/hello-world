BEGIN
insert into insa02
select /*+rule*/a.emp_no       			emp_no   ,
       a.emp_nm      			emp_nm   ,
       a.dept_cd      			dept_cd  ,
       'ZF'       			title_cd ,
       '�����'     			title_nm ,
       a.jk_cd        			jk_cd    ,
       a.jk_nm        			jk_nm    ,
       '30'         			sr_cd    ,
       '�����'       			sr_nm    ,
       FUNC_GET_dVSN_CODE(A.DEPT_CD)     div_cd   ,
       b.dept_nm      			dept_nm  ,
       b.site_cd      			site_cd  ,
       '1'                              emp_divs ,
-- 2005.02.28 C2005022301000000346 ���������ȭ�� ������û
-- '���(D6)' �������� �߰�
--       f_chuljang_title('ZF' ,'00' )     chuljang_title  ,
       f_chuljang_title('ZF' ,'00', a.jk_cd)     chuljang_title  ,
-- ������
       decode( a.emp_status, 'T',
       decode( sign( to_char( sysdate, 'yyyymmdd' ) - to_char( at_atdt_st, 'yyyymmdd' )), -1, 'C',
               a.emp_status ), a.emp_status )                     emp_status,
       ''                        emp_ssn ,
	null , null ,
       '','',
       a.dept_sort_cd,  -- �ؿ������ ��������� ���Ͽ� �߰� by ������ 20050413
       '','','','','','','','','','','','',''
       --to_char(sysdate,'yyyyMMddhhmmss') emp_grpdt, ''
 from imsve01 a,
      newinsa_insta01 b
where a.dept_cd   =  b.dept_cd
  and b.dept_dt   =  ( select max(dept_dt) from newinsa_insta01 where dept_cd = a.dept_cd )
  and a.emp_no not in ( select emp_no from insa02 );

EXCEPTION
  when others then
   dbms_output.put_line('03_ERR');
   null;
END;
/
