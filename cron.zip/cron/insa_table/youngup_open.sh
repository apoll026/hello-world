#!/sbin/sh
################################################################################
###  Script      Name     invalid_object    	                              ##
###===========================================================================##
###  Create      By       CHS                                                 ##
###---------------------------------------------------------------------------##
###  Create      Date     2000.02.15                                          ##
###  Modify      Date                                                         ##
###---------------------------------------------------------------------------##
###  Description                                                              ##
###---------------------------------------------------------------------------##
###                                                                           ##
################################################################################
###---------------------------------------------------------------------------##
###  ORACLE USER ȯ�� SETTING                                                 ##
###---------------------------------------------------------------------------##
###---------------------------------------------------------------------------##
###  Crontab�� ���� ���� ȯ�溯��                                             ##
###---------------------------------------------------------------------------##
##export         ORACLE_SID=DBSVR04
##export         ORACLE_BASE=app/oracle
##export         ORACLE_HOME=$ORACLE_BASE/product/8.1.7
##export         PATH=$ORACLE_HOME/bin:$PATH
##export         NLS_LANG=American_America.KO16KSC5601
##export         LD_LIBRARY_PATH=$ORACLE_HOME/lib
##export         TERM=vt100
##export         ORACLE_TERM=vt220
##export         ORACLE_DOC=$ORACLE_BASE/doc
##export         TMPDIR=$ORACLE_BASE/tmp
##export         NLS_LANG=American_America.KO16KSC5601
##export         TNS_ADMIN=$ORACLE_HOME/network/admin
##export         ORA_NLS33=$ORACLE_HOME/ocommon/nls/admin/data
export ORACLE_BASE=/app/oracle
export ORACLE_HOME=$ORACLE_BASE/product/8.1.7
export ORACLE_SID=DBSVR04
export NLS_LANG=American_America.KO16KSC5601
export TMPDIR=$ORACLE_BASE/tmp
export ORACLE_DOC=$ORACLE_BASE/doc
export ORA_NLS33=$ORACLE_HOME/ocommon/nls/admin/data
export PATH=$ORACLE_HOME/bin:$PATH
export LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib
###---------------------------------------------------------------------------##
################################################################################
###
cd /app/acct/fixdata; sqlplus fa/suioe9z @youngup_open.sql;
