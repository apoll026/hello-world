--drop table insve01_01;
-- FA User �� truncate ���� ���ſ� ���� ���� 2004.03.12 by ������
-- truncate table insve01_01
delete from insve01_01;

--alter table insve01_01 drop constraint pk_insve01_01;
insert into insve01_01(
                      EMP_NO, EMP_NM, EMP_STATUS, EMP_JOINDT,
                      EMP_GRPDT, EMP_SSN, FK_DSP_DEPT_CD, FK_DSP_DEPT_DT,
                      EMP_DSP_TP, EMP_MAIL_ID, TITLE_CD, TITLE_NM,
                      GTITLE_CD, GTITLE_NM, JC_CD, JC_NM,
                      JK_CD, JK_NM, JJ_CD, JJ_NM,
                      WORK_CD, WORK_NM, SR_CD, SR_NM,
                      DEPT_CD, DEPT_FG, DEPT_DT, DEPT_NM,
                      FK_LDR_EMP_NO, DEPT_SORT_CD, DEPT_EXP_CD, DEPT_ACCT_CD,
                      DEPT_LEVEL, FK_DEPT_CD, FK_DEPT_DT, FK_DIV_CD,
                      AT_ATDT, AT_SEQ, DEPT_ALL_NM, EMP_PART,
                      PROJ_CD, PROJ_WORK_CD, PROJ_GUPJI_CD)
SELECT A.EMP_NO, SUBSTRB(A.EMP_NM, 1, 20) EMP_NM,  
       A.EMP_STATUS, A.EMP_JOINDT,
       A.EMP_GRPDT, '' EMP_SSN, '' FK_DSP_DEPT_CD, '' FK_DSP_DEPT_DT,
       '' EMP_DSP_TP, SUBSTRB(A.EMP_MAIL_ID, 1, 15) EMP_MAIL_ID, A.TITLE_CD, A.TITLE_NM,
       '' GTITLE_CD, '' GTITLE_NM, A.JC_CD, A.JC_NM,
       A.JK_CD, A.JK_NM, SUBSTRB(A.JJ_CD, 1, 2) JJ_CD, A.JJ_NM,
       A.WORK_CD, A.WORK_NM, A.SR_CD, A.SR_NM,
       A.DEPT_CD, A.DEPT_FG, A.DEPT_DT, SUBSTRB(A.DEPT_NM, 1, 50) DEPT_NM,
       A.FK_LDR_EMP_NO, A.DEPT_SORT_CD, '' DEPT_EXP_CD, '' DEPT_ACCT_CD,
       C.DEPT_LEVEL, A.FK_DEPT_CD, '' FK_DEPT_DT, C.FK_DIV_CD,
       A.AT_ATDT, A.AT_SEQ, A.DEPT_ALL_NM, 
       DECODE(SUBSTR(A.DEPT_SORT_CD, 1, 2), 'A3', 'E', 'A5', 'E', 'C') EMP_PART,
       '' PROJ_CD, A.PROJ_WORK_CD, '' PROJ_GUPJI_CD
  FROM NEWINSA_INSVE01 A, NEWINSA_INSTA01 B, ORM_INF_ORG C
 WHERE A.DEPT_CD = B.DEPT_CD(+)
   AND A.DEPT_CD = C.DEPT_CD(+)
   AND B.DEPT_FG = 'Y'
   AND C.DEPT_FG = 'Y'
   AND C.CORP_CODE = '000001'
/

/*
alter table insve01_01  
add constraint pk_insve01_01  primary key  ( emp_no        )
using index tablespace ts_fa_idx04
pctfree 5
storage ( initial     512K
          next        512K
          pctincrease 0 )
         
/
*/
