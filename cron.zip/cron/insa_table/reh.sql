insert into insa02
select a.emp_no                         emp_no   ,
       a.emp_nm                         emp_nm   ,
       a.dept_cd                        dept_cd  ,
       a.title_cd                       title_cd ,
       a.title_nm                       title_nm ,
       a.jk_cd                          jk_cd    ,
       a.jk_nm                          jk_nm    ,
       a.sr_cd                          sr_cd    ,
       a.sr_nm                          sr_nm    ,
       a.fk_div_cd                      div_cd   ,
       b.dept_nm                        dept_nm  ,
       b.site_cd                        site_cd  ,
       decode(c.emp_part, 'C','1', 'E','2','')  emp_divs,
       f_chuljang_title( decode(substr(a.title_cd,1,1),'Z', nvl(c.fk_mail_title_cd,a.title_cd)
                                                          , a.title_cd),a.sr_cd, a.jk_cd) chuljang_title  ,
       a.emp_status                     emp_status ,
       a.emp_ssn                        emp_ssn    ,
       c.fk_zip_cd                      fk_zip_cd  ,
       c.emp_addr                       emp_addr   ,
       c.emp_engnm                      engnm,
       a.emp_mail_id                    EMP_MAIL_ID,
       a.dept_sort_cd                   DEPT_SORT_CD,
       a.emp_part                       EMP_PART,
       a.jc_nm                          JC_NM,
       a.dept_all_nm                    DEPT_ALL_NM,
       a.fk_dsp_dept_cd                 FK_DSP_DEPT_CD,
       f_get_div_cd(a.dept_cd)          SAUP_CD,
       f_get_div_nm(a.dept_cd)          SAUP_NM,
       b.fk_div_cd                      FK_DIV_CD,
       rtrim(ltrim(c.emp_co_pn_area))||'-'||
       rtrim(ltrim(c.emp_co_pn_office))||'-'||
       rtrim(ltrim(c.emp_co_pn_no))     EMP_CO_TEL,
       d.div_nm                         DIV_NM,
       b.dept_fg                        DEPT_FG,
       nvl(to_char(c.emp_joindt,'yyyymmdd'),'')   emp_joindt,
       nvl(to_char(c.emp_grpdt,'yyyymmdd'), '')   emp_grpdt,
       DECODE(NVL(c.emp_part, 'C'), 'C','1','E','2')    gb
 from newinsa_insve01_01 a,
      insta01    b ,
      inste01    c,
      instc16    d
where a.emp_no = '62519'
  and a.dept_cd   =  b.dept_cd(+)
  and a.emp_no    =  c.emp_no
  and b.dept_dt   =  (select max(dept_dt) from insta01 where dept_cd = a.dept_cd )
  and b.fk_div_cd = d.div_cd(+)
/
