!cd /app/acct/cron/insa_table
spool insa_table_temp.log
set serveroutput on
insert into to_load_yang(txt1,bigo)
values('����',to_char(sysdate));

commit;

@@backup_insa01.sql
commit;

insert into to_load_yang(txt1, bigo)
values('����',to_char(sysdate));
commit;

dbms_output.put_line('aaa');
spool off
exit
