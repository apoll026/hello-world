DECLARE
    v_cnt1    NUMBER(10);
    v_cnt2    NUMBER(10);
    v_msg     VARCHAR2(200);
BEGIN
    v_cnt1 := 0;
    v_cnt2 := 0;

    SELECT COUNT(*)
    INTO   v_cnt1
    FROM   FA.INSA02
    WHERE  EMP_DIVS != '4';
   
    SELECT COUNT(*)
    INTO   v_cnt2
    FROM   FA.INSA02
    WHERE  EMP_DIVS = '4';

    IF v_cnt1 > 1000 AND v_cnt2 > 100 THEN

        DELETE FROM FA.INSA01;

        INSERT INTO FA.INSA01
        SELECT * FROM FA.INSA02;
    ELSE
        dbms_output.put_line('insa02 ������ ����!!');
    END IF;
    
    -- ���ֿ��븮 �ڸ��̵��� ���� ����..
    update insa01 set dept_cd = 'H2220',
                      dept_nm = '�繫ȸ����'
    where emp_no = '51125'
    and   to_char(sysdate, 'yyyymmdd') <= '20040131';

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        dbms_output.put_line('DB Error'||sqlcode||sqlerrm);
        ROLLBACK;
END;
/
SHOW ERROR;
/
