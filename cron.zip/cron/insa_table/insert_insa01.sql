-- spool /app/acct/cron/insa_table/insa_table.log
set serveroutput on;
DECLARE
    v_cnt1    NUMBER(10);
    v_cnt2    NUMBER(10);
    v_msg     VARCHAR2(200);
    -- ���Ͽ������˰��� �ڵ�ȭ
    v_log     varchar2(100);
    
BEGIN
    v_cnt1 := 0;
    v_cnt2 := 0;
    
    v_log := batch_start_log(12);

    SELECT COUNT(*)
    INTO   v_cnt1
    FROM   INSA02
    WHERE  EMP_DIVS != '4';
   
    SELECT COUNT(*)
    INTO   v_cnt2
    FROM   INSA02
    WHERE  EMP_DIVS = '4';

    IF v_cnt1 > 1000 AND v_cnt2 > 100 THEN

        DELETE FROM INSA01;  

        INSERT INTO INSA01
        SELECT * FROM INSA02;
    ELSE
        dbms_output.put_line('insa02 ������ ����!!');
    END IF;
    
    SELECT COUNT(*)
      INTO v_cnt1
      FROM INSA01;

    SELECT COUNT(*)
      INTO v_cnt2
      FROM INSA02;
      
      dbms_output.put_line('INSA01 COUNT : '||v_cnt1);
      dbms_output.put_line('INSA02 COUNT : '||v_cnt2);
      dbms_output.put_line('��ġ����ð� : '||to_char(sysdate,'yyyyMMdd hh24:mi:ss'));
      
    COMMIT;
    -- ���Ͽ������˰��� �ڵ�ȭ
    batch_end_log(v_log, 'Y', null , null );
    
EXCEPTION
    WHEN OTHERS THEN
        dbms_output.put_line('DB Error'||sqlcode||sqlerrm);
        ROLLBACK;
        
        -- ���Ͽ������˰��� �ڵ�ȭ
        batch_end_log(v_log, 'N', null , v_msg );
        
END;
/
SHOW ERROR;

--spool off
