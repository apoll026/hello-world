--drop Table insvj03_01 ; 
-- FA User �� truncate ���� ���ſ� ���� ���� 2004.03.12 by ������
-- truncate table insvj03_01;
delete from insvj03_01;
insert into insvj03_01 (
                         EMP_NO, EMP_NM, EMP_STATUS, EMP_JOINDT,
                         EMP_SSN, FK_ATT_CD, FK_DSP_DEPT_CD, FK_DSP_DEPT_DT,
                         EMP_DSP_TP, EMP_MAIL_ID, TITLE_CD, TITLE_NM,
                         JC_CD, JC_NM, JK_CD, JK_NM,
                         JJ_CD, JJ_NM, DEPT_CD, DEPT_FG,
                         DEPT_DT, DEPT_NM, FK_LDR_EMP_NO, DEPT_SORT_CD,
                         DEPT_EXP_CD, DEPT_LEVEL, FK_DEPT_CD, FK_DEPT_DT,
                         DEPT_ALL_NM
                       )
select   
                         EMP_NO, EMP_NM, EMP_STATUS, EMP_JOINDT,
                         '' EMP_SSN, FK_ATT_CD, FK_DSP_DEPT_CD, FK_DSP_DEPT_DT,
                         EMP_DSP_TP, EMP_MAIL_ID, TITLE_CD, TITLE_NM,
                         JC_CD, JC_NM, JK_CD, JK_NM,
                         JJ_CD, JJ_NM, DEPT_CD, DEPT_FG,
                         DEPT_DT, DEPT_NM, FK_LDR_EMP_NO, DEPT_SORT_CD,
                         DEPT_EXP_CD, DEPT_LEVEL, FK_DEPT_CD, FK_DEPT_DT,
                         DEPT_ALL_NM
from newinsa_insvj03_01
/
