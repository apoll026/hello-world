
!cd /app/acct/cron/insa_table
spool /app/acct/cron/insa_table/insa_table.log
!date >> insa_table.log
@@backup_insa01.sql
commit;
!echo "backup_insa01.sql"
!date >> insa_table.log
@@create_insta01.sql
!echo "create_insta01.sql"
!date >> insa_table.log
@@create_instj03.sql
!echo "create_instj03.sql"
!date >> insa_table.log
@@create_insve01.sql
!echo "create_insve01.sql"
!date >> insa_table.log
@@create_insve01_01.sql
!echo "create_insve01_01.sql"
!date >> insa_table.log
@@create_insa_01.sql
!echo "create_insa_01.sql"
!date >> insa_table.log
@@create_insa_06.sql
!echo "create_insa_06.sql"
!date >> insa_table.log
update fatx920
set use_yn = 'N'
where emp_no in ( select emp_no from insa02
                  where emp_status = 'T' ); 
commit;
!date >> insa_table.log
alter PROCEDURE proc_update_insa01_ch compile;
@@insert_insa01.sql
set pause off
!date >> insa_table.log
@@update_insa01_ch.sql
!date >> insa_table.log
analyze table insta01 compute statistics;
analyze table instj03 compute statistics;
!date >> insa_table.log
exit

