BEGIN
insert into insa02
select substr(a.sabun,3,5)     		emp_no   , 
       a.name        			emp_nm   , 
       a.buseo        			dept_cd  ,
       a.jikwi        			title_cd ,
       a.jikwi_nm     			title_nm ,
       a.jikwi        			jk_cd    ,
       a.jikwi_nm     			jk_nm    ,
       a.jikwi        			sr_cd    ,
       a.jikwi_nm     			sr_nm    ,
       a.saup_cd                        div_cd   ,
       a.buseo_nm     			dept_nm  ,
       '1'            			site_cd  ,
       '2'                              emp_divs ,
       a.chuljang_cd                    chuljang_title,  
       a.emp_status                     emp_status     ,
       ''                        emp_ssn        ,
       a.zip_cd                        fk_zip_cd       ,
       a.emp_addr                       emp_addr  ,
       '','','','','','','','','','','','','','','',''
 from lgen_employ_v@db2insa a       
where substr(a.sabun,3,5) not in ( select emp_no
				     from insa02   ) ;

EXCEPTION
  when others then
   dbms_output.put_line('02_ERR');
   null;
END;
/
