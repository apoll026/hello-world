--��赿 �λ� insert
-- insert into  insa01
-- (select  *
--  from insa01_bb )
insert into insa01
      (select * from insa01_bb
       where emp_no not in ( select emp_no from insa01
                             where emp_no in (select emp_no from insa01_bb)
     ))
/
