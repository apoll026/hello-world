insert into insa01
select a.emp_no       			emp_no   ,
       a.emp_nm      			emp_nm   ,
       a.dept_cd      			dept_cd  ,
       'ZF'       			title_cd ,
       '�����'     			title_nm ,
       a.jk_cd        			jk_cd    ,
       a.jk_nm        			jk_nm    ,
       '00'         			sr_cd    ,
       '�����'       			sr_nm    ,
       b.fk_div_cd                      div_cd   ,
       b.dept_nm      			dept_nm  ,
       b.site_cd      			site_cd  ,
       '1'                              emp_divs ,
       f_chuljang_title('ZF' ,'00' )     chuljang_title  ,
       a.emp_status                     emp_status ,
       a.emp_ssn                        emp_ssn ,
	null , null
 from nomu.imsve01@lgcon05 a,
      insta01 b
where a.dept_cd   =  b.dept_cd
  and b.dept_dt   =  ( select max(dept_dt) from insta01 where dept_cd = a.dept_cd )
  and a.emp_no not in ( select emp_no from insa01 )
/
