truncate table insa01;
insert into insa01
select a.emp_no       			emp_no   , 
       a.emp_nm      			emp_nm   , 
       a.dept_cd      			dept_cd  ,
       a.title_cd     			title_cd ,
       a.title_nm     			title_nm ,
       a.jk_cd        			jk_cd    ,
       a.jk_nm        			jk_nm    ,
       a.sr_cd        			sr_cd    ,
       a.sr_nm        			sr_nm    ,
       a.fk_div_cd                      div_cd   ,
       b.dept_nm      			dept_nm  ,
       b.site_cd      			site_cd  ,
       decode(c.emp_part, 'C','1', 'E','2','')  emp_divs,
       f_chuljang_title(a.title_cd,a.sr_cd)     chuljang_title  ,
       a.emp_status                     emp_status ,
       a.emp_ssn                        emp_ssn    ,
       c.fk_zip_cd                      fk_zip_cd  ,
       c.emp_addr                       emp_addr   
 from insve01_01 a,
      insta01    b ,
      newinsa.inste01@lgcon05   c
where a.dept_cd   =  b.dept_cd(+)
  and a.emp_no    =  c.emp_no
  and b.dept_dt   =  (select max(dept_dt) from insta01 where dept_cd = a.dept_cd )
/
