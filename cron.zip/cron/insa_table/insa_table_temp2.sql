!cd /app/acct/cron/insa_table
spool insa_table_temp.log
set serveroutput on
insert into to_load_yang(txt1,bigo)
values('start',to_char(sysdate));

commit;

@@create_insve01.sql
commit;

insert into to_load_yang(txt1, bigo)
values('fnsh',to_char(sysdate));
commit;

dbms_output.put_line('aaa');
spool off
exit
