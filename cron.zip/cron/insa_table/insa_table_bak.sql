!cd /app/acct/cron/insa_table
!date >> insa_table.log
@@backup_insa01.sql
commit;
@@create_insta01.sql
@@inx_insta01.sql
@@create_instj03.sql
@@create_insve01.sql
@@create_insve01_01.sql
@@create_insa_01.sql
@@create_insa_03.sql
@@create_insa_03_1.sql
@@create_insa_05.sql
@@create_insa_06.sql
@@create_insvj03_01.sql
update fatx920
set use_yn = 'N'
where emp_no in ( select emp_no from insa02
                  where emp_status = 'T' ); 
commit;
alter PROCEDURE proc_update_insa01_ch compile;
@@insert_insa01.sql
set pause off
@@update_insa01_ch.sql
analyze table insta01 compute statistics;
analyze index inx_insta01 compute statistics;
analyze table instj03 compute statistics;
analyze table insve01 compute statistics;
analyze table insvj03_01 compute statistics;
!date >> insa_table.log
exit

