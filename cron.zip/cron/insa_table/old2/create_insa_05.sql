insert into insa01 values ('lgcns', 'LGCNS', 'H2220', 'V0', '�븮','ZZ','','A3','3��','H1','�繫ȸ����','1','1','D5','C','7101171646219','527870','���������������뱸�顡������  710',
'','lgcns','','','','','','','','','','','','','','')
/
insert into insa01 values ('99999', 'LG CNS', 'HH001', 'V0', '�븮','ZZ','','A3','3��','H1','�繫ȸ����','1','1','D5','C','7101171646219','527870','���������������뱸�顡������  710',
'','lgcns','','','','','','','','','','','','','','')
/
insert into insa01 values ('test', 'test', 'H2220', 'V0', '�븮','ZZ','','A3','3��','H1','�繫ȸ����','1','1','D5','C','7101171646219','527870','���������������뱸�顡������  710',
'','test','','','','','','','','','','','','','','')
/
insert into insa01
select '99998'                          emp_no   ,
       '������'                         emp_nm   ,
       a.dept_cd                        dept_cd  ,
       a.title_cd                       title_cd ,
       a.title_nm                       title_nm ,
       a.jk_cd                          jk_cd    ,
       a.jk_nm                          jk_nm    ,
       a.sr_cd                          sr_cd    ,
       a.sr_nm                          sr_nm    ,
       a.fk_div_cd                      div_cd   ,
       b.dept_nm                        dept_nm  ,
       b.site_cd                        site_cd  ,
       decode(c.emp_part, 'C','1', 'E','2','')  emp_divs,
       f_chuljang_title(a.title_cd,a.sr_cd)     chuljang_title  ,
       a.emp_status                     emp_status ,
       '7000000000000'                  emp_ssn    ,
       c.fk_zip_cd                      fk_zip_cd  ,
       c.emp_addr                       emp_addr   ,
       'System Engineer'                engnm,
       'admin'                          EMP_MAIL_ID,
       a.dept_sort_cd                   DEPT_SORT_CD,
       a.emp_part                       EMP_PART,
       a.jc_nm                          JC_NM,
       a.dept_all_nm                    DEPT_ALL_NM,
       a.fk_dsp_dept_cd                 FK_DSP_DEPT_CD,
       biz.f_get_div_cd(a.dept_cd)      SAUP_CD,
       biz.f_get_div_nm(a.dept_cd)      SAUP_NM,
       b.fk_div_cd                      FK_DIV_CD,
       rtrim(ltrim(c.emp_co_pn_area))||'-'||
       rtrim(ltrim(c.emp_co_pn_office))||'-'||
       rtrim(ltrim(c.emp_co_pn_no))     EMP_CO_TEL,
       d.div_nm                         DIV_NM,
       b.dept_fg                        DEPT_FG,
       nvl(to_char(c.emp_joindt,'yyyymmdd'),'')   emp_joindt,
       nvl(to_char(c.emp_grpdt,'yyyymmdd'), '')   emp_grpdt,
       DECODE(NVL(c.emp_part, 'C'), 'C','1','E','2')    gb
 from insve01_01 a,
      insta01    b ,
      newinsa.inste01@lgcon05   c,
      cdmgr.instc16@lgcon05 d
where a.dept_cd   =  b.dept_cd(+)
  and a.emp_no    =  c.emp_no
  and b.dept_dt   =  (select max(dept_dt) from insta01 where dept_cd = a.dept_cd )
  and b.fk_div_cd = d.div_cd(+)
  and a.emp_mail_id = 'sbree'
/
insert into insa01
select 'khsh'                           emp_no ,
       '�Ű�ȭ'                         emp_nm ,
       a.dept_cd                        dept_cd ,
       'X1'                             title_cd ,
       '���'                           title_nm ,
       a.jk_cd                          jk_cd ,
       a.jk_nm                          jk_nm ,
       a.sr_cd                          sr_cd ,
       a.sr_nm                          sr_nm ,
       a.fk_div_cd                      div_cd ,
       b.dept_nm                        dept_nm ,
       b.site_cd                        site_cd ,
       decode(c.emp_part, 'C','1', 'E','2','') emp_divs,
       f_chuljang_title(a.title_cd,a.sr_cd)    chuljang_title,
       a.emp_status                     emp_status ,
       '7000000000000'                  emp_ssn    ,
       c.fk_zip_cd                      fk_zip_cd  ,
       c.emp_addr                       emp_addr   ,
       'SHIN KYUNG HWA'                 engnm,
       'khshin3'                        EMP_MAIL_ID,
       a.dept_sort_cd                   DEPT_SORT_CD,
       a.emp_part                       EMP_PART,
       '��'                           JC_NM,
       a.dept_all_nm                    DEPT_ALL_NM,
       a.fk_dsp_dept_cd                 FK_DSP_DEPT_CD,
       biz.f_get_div_cd(a.dept_cd)      SAUP_CD,
       biz.f_get_div_nm(a.dept_cd)      SAUP_NM,
       b.fk_div_cd                      FK_DIV_CD,
       '02-728-2507'                    EMP_CO_TEL,
       d.div_nm                         DIV_NM,
       b.dept_fg                        DEPT_FG,
       nvl(to_char(c.emp_joindt,'yyyymmdd'),'')   emp_joindt,
       nvl(to_char(c.emp_grpdt,'yyyymmdd'), '')   emp_grpdt,
       DECODE(NVL(c.emp_part, 'C'), 'C','1','E','2')    gb
 from insve01_01 a,
      insta01    b ,
      newinsa.inste01@lgcon05   c,
      cdmgr.instc16@lgcon05 d
where a.dept_cd   =  b.dept_cd(+)
  and a.emp_no    =  c.emp_no
  and b.dept_dt   =  (select max(dept_dt) from insta01 where dept_cd = a.dept_cd )
  and b.fk_div_cd = d.div_cd(+)
  and a.emp_mail_id = 'kjjang'
/
