﻿//
// KTNET Client OpenWeb Java Script
// 최종 수정일 : 2016.01.25
// 작성자 : choijaeduck@gmail.com
//

//////////////////////////////////////////////////////////////////////////
// PKI관련 함수
//////////////////////////////////////////////////////////////////////////
var acceptPolicy = "1 2 410 200012 1 1 3:범용기업|1 2 410 200004 5 1 1 7:범용기업|1 2 410 200005 1 1 5:범용기업|1 2 410 200004 5 2 1 1:범용기업|1 2 410 200004 5 4 1 2:범용기업|1 2 410 200004 5 3 1 1:범용기관|1 2 410 200004 5 3 1 2:범용기업|1 2 410 200012 1 1 5:GS건설|";
//var acceptPolicy = "1 2 410 200012 1 1 3:범용기업|1 2 410 200004 5 1 1 7:범용기업|1 2 410 200005 1 1 5:범용기업|1 2 410 200004 5 2 1 1:범용기업|1 2 410 200004 5 4 1 2:범용기업|1 2 410 200004 5 3 1 1:범용기관|1 2 410 200004 5 3 1 2:범용기업|";
function PrintKTNETObject(corp)
{
    var WebAppRoot = fnGetRoot(corp);
    var flConfig = "nxtspki_config.js";
    if (typeof (corp) != "undefined" && corp != null) {
        if (corp == "000010" || corp.toUpperCase() == "ONM")
            flConfig = "nxtspki_config_Onm.js";
        else if (corp == "000030" || corp.toUpperCase() == "SND")
            flConfig = "nxtspki_config_Snd.js";
        else if (corp == "000040" || corp.toUpperCase() == "GCS")
            flConfig = "nxtspki_config_Gcs.js";
        else if (corp == "000050" || corp.toUpperCase() == "EST")
        	flConfig = "nxtspki_config_Est.js";
        //C20200526_38947_발주사 추가 요청 (베트남 법인 VGSI, VGSE) -->>
        else if (corp == "000110" || corp.toUpperCase() == "VGSI")
        	flConfig = "nxtspki_config_Vgsi.js";
        else if (corp == "000120" || corp.toUpperCase() == "VGSE")
        	flConfig = "nxtspki_config_Vgse.js";
        //C20200526_38947_발주사 추가 요청 (베트남 법인 VGSI, VGSE) <<--
        else
            flConfig = "nxtspki_config.js";
    }
    
    document.write("<script type='text/javascript' src='" + WebAppRoot + "Common/js/ktnet/nxts.min.js'><" + "/script>");
    document.write("<script type='text/javascript' src='" + WebAppRoot + "Common/js/ktnet/" + flConfig + "'><" + "/script>");
    document.write("<script type='text/javascript' src='" + WebAppRoot + "Common/js/ktnet/nxtspki.js'><" + "/script>");
}

function managerCertificate( orgMsg) {
	var sRand ;
    var options = {};
	
	if ( orgMsg == null || orgMsg == "") {
		//sRand = getRandom(3);
		sRand = "1234567890";
	}
	else {
		sRand = orgMsg ;		
	}
	
    nxTSPKI.signData(sRand, options, selectcert_complete_callback);
}

function verifyCertificate( signVal) {
	var certValidation = true ;
	
	if ( signVal == "" ) {
		alert("검증할 서명값이 없습니다.");
		return false;
	}
	nxTSPKI.verifySignedData(signVal, {"certValidation": certValidation}, verifycert_complete_callback);

}

function checkVID(vid) {
	if ( vid == "" ) {
		alert("식별정보가 없습니다.");
		return false;
	}

	nxTSPKI.verifyVID(vid,{},vid_complete_callback);
}

function signData( orgInf) {
    //var options = {};     // 범용인증서만 적용토록 수정_2020.02.25
    var options = { initPolicy: acceptPolicy };
		
	if ( orgInf[0] == "" ) {
		alert("서명할 데이타가 없습니다.");
		return false;
	}

	nxTSPKI.signData(orgInf, options, sign_complete_callback);
}

function verifySignedData( signVal) {
	var nRet ;
	
	if ( signVal == "" ) {
		alert("검증할 서명값이 없습니다.");
		return false;
	}
	
	var certValidation = false ;
	
	nxTSPKI.verifySignedData(signVal, {"certValidation": certValidation}, verify_complete_callback);
	
}

/**
 * 인증서정보에서 인증기관 이름 구하기
 * PKIObject   : PKI 처리하는 Object
 */
function getCertAuthorityName(strDn) {
	return getCertAuthName(getCertAuthority(strDn));	
}

/**
 * 인증서정보에서 인증기관코드 구하기
 * PKIObject   : PKI 처리하는 Object
 */
function getCertAuthorityCode(strDn) {
	return getCertAuthCode(getCertAuthority(strDn));
}

function getCertHash(strDN) {
	var rtnValue;

	if ( strDN == null ) {
		strDN =  getCertDN();
	}

	return getHash(strDN);
}

/**
 * Hash 구하기
 * HashObject   : Hash 처리하는 Object
 */
function getHash( str) {
	nxTSPKI.hashData("SHA1",str, hash_complete_callback);
//	nxTSPKI.hashData("SHA256",data, hash_complete_callback);
}



/*
function getMedia()
{
	TSToolkit.GetSelectedCertInfo(1);

	alert("Media="+TSToolkit.OutDataNum);
	return TSToolkit.OutDataNum;
}


function getMediaName(strMediaCode) {
	var strMediaName ;

	if ( strMediaCode == null ) {
		strMediaCode = getMedia();
	}
	
	if (strMediaCode == "0") {
		strMediaName = "HDD";
	} else if(strMediaCode == "1") {
		strMediaName     = "Removable Disk";
	} else if(strMediaCode == "2") {
		strMediaName = "Smart Card";
	} else if(strMediaCode == "3") {
		strMediaName     = "Security Token";
	}
	
	return strMediaName ;
}

function getMediaNameKor(strMediaCode) {
	var strMediaName ;

	if ( strMediaCode == null ) {
		strMediaCode = getMedia();
	}
	
	if(strMediaCode == "0") {
		strMediaName = "하드디스크";
	} else if(strMediaCode == "1") {
		strMediaName     = "이동식디스크";
	} else if(strMediaCode == "2") {
		strMediaName = "스마트카드";
	} else if(strMediaCode == "3") {
		strMediaName     = "보안토큰";
	}		
	return strMediaName ;
}
*/

function getCommonName(dn){
	var index, strCn ;
	index = dn.indexOf("cn=");
	strCn =  dn.substring(index+3) ;
	index = strCn.indexOf(",") ;
	strCn = strCn.substring(0,index) ;
	
	return strCn ;
}

function getCertAuthority(issuer){
	var index, strCertAuthority ;
	index = issuer.indexOf("o=");
	strCertAuthority =  issuer.substring(index+2) ;
	index = strCertAuthority.indexOf(",") ;
	strCertAuthority = strCertAuthority.substring(0,index) ;
	
	return strCertAuthority.toUpperCase() ;
}

function getCertAuthCode(strCertAuthority){
	var strCertAuthorityCode ;

	if(strCertAuthority == "KICA") {
		strCertAuthorityCode = "0";
	} else if(strCertAuthority == "SIGNKOREA") {
		strCertAuthorityCode = "1";
	} else if(strCertAuthority == "YESSIGN") {
		strCertAuthorityCode = "2";
	} else if(strCertAuthority == "CROSSCERT") {
		strCertAuthorityCode = "3";
	} else if(strCertAuthority == "TRADESIGN") {
		strCertAuthorityCode = "4";
	} else if(strCertAuthority == "NCASIGN") {
		strCertAuthorityCode = "5";
	} else if(strCertAuthority == "KAL") {
		strCertAuthorityCode = "6";
	} else if((strCertAuthority == "GOVERNMENT OF KOREA")||(strCertAuthority == "PUBLIC OF KOREA")) {
		strCertAuthorityCode = "7";
	}
	return strCertAuthorityCode ;
}

function getCertAuthName(strCertAuthority) {
	var strCertAuthorityName ;

	if(strCertAuthority == "KICA") {
		strCertAuthorityName = "한국정보인증";
	} else if(strCertAuthority == "SIGNKOREA") {
		strCertAuthorityName = "한국증권전산";
	} else if(strCertAuthority == "YESSIGN") {
		strCertAuthorityName = "금융결제원";
	} else if(strCertAuthority == "CROSSCERT") {
		strCertAuthorityName     = "한국전자인증";
	} else if(strCertAuthority == "TRADESIGN") {
		strCertAuthorityName = "한국무역정보통신";
	} else if(strCertAuthority == "NCASIGN") {
		strCertAuthorityName = "한국전산원";
	} else if(strCertAuthority == "KAL") {
		strCertAuthorityName = "대한항공사설";
	} else if((strCertAuthority == "GOVERNMENT OF KOREA")||(strCertAuthority == "PUBLIC OF KOREA")) {
		strCertAuthorityName = "행정자치부";
	}

	return strCertAuthorityName ;
}

