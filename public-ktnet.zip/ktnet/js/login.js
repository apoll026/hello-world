﻿var $openPop = (function () {
    return {
        //회사소개
        intro: function () {
            var url;
            if("Ko" == getDomainType()) {
                url = "http://www.gsenc.com/Company/Ceo.aspx";
            } else {
                url = "http://www.gsenc.com/en/Company/Ceo.aspx";
            }

            window.open(url, "_blank");
        },

        //사이버신문고
        cyber: function () {
            if ("Ko" == getDomainType()) {
                window.open("http://www.gsenc.com/Customer/CustomerSinmungo.aspx", "_blank");                
            } else {
                window.open("http://www.gsenc.com/en/Customer/CustomerSinmungo.aspx", "_blank");
            }
        },

        //개인정보취급방침
        privateInfo: function (ver) {
            var filename = "";
            if (typeof (ver) != "undefined" && ver != null && ver != "" && ver != "V1") {
                filename = "PrivateInfo_" + ver;
            } else {
                filename = "PrivateInfo";
            }

            $openPop.commonLayout(doSend(filename, "000001"));
        },

        //이메일주소수집거부
        email: function () {
            $openPop.commonLayout(doSend("Email", "000001"));
        },

        //원격지원
        remote: function (pLang) {
            var userAgent = navigator.userAgent;
            if (userAgent == null || (userAgent.indexOf("MSIE") == -1 && userAgent.indexOf("Trident") == -1)) {
                if ("Ko" == getDomainType()) {
                    alert("Internet Explorer 가 아닌 브라우저로 접속하셨습니다.\n" +
                            "IE 이외 브라우저는 지원하지 않으니 IE 로 접속 바랍니다.");
                } else {
                    alert("It operates on only Microsoft Internet Explorer.");                    
                }
                return;
            }

            window.open("https://939.co.kr/gsenc/", "_blank");
        },

        //아이디&비밀번호 찾기
        search: function(){
            $("#user-control-auth").css("display", "none");
            $("#user-control-search").css("display", "block");
            $("#user-control-search").fadeIn();
        },

        //등록절차
        step: function(){
            $openPop.commonLayout(doSend("StepInfo", "000001"));
        },

        //인증관리
        authManager: function () {
            var userAgentInfo = navigator.userAgent;
            if (userAgentInfo.match("iPhone") != null || userAgentInfo.match("Android") != null) {
                if ("Ko" == getDomainType()) {
                    alert("모바일 사용자는 이용할 수 없습니다.");
                } else {
                    alert("Mobile users are not allowed.");
                }
                
                return false;
            }

            $("#user-control-search").css("display", "none");
            $("#user-control-auth").css("display", "block");
            $("#user-control-auth").fadeIn();
            $.authInterval();
            $("#authMain").spin(opts);
        },

        //증명확인 열기
        proveOpen: function(){
            $(".b4_over").show(700);
        },

        //증명확인 닫기
        proveClose: function(){
            $(".b4_over").hide(700);
        },

        //기성실적 증명확인
        gisung: function () {
            window.open("https://www.gspartner.co.kr/EPSWeb/EPSMAI/EPSMAI4000.aspx",
                "gisung",
                "width=430,height=180,top=" + (screen.height - 150) / 2 +
                                            ",left=" + (screen.width - 380) / 2 +
                                            ",scrollbars=yes,menubar=no,toolbar=no,location=no,status=yes,resizable=no,copyhistory=no");
        },

        //증명발급확인
        issue: function(){
            window.open("https://www.gspartner.co.kr/EPSWeb/EPSMAI/EPSMAI4010.aspx",
                "issue",
                "width=430,height=180,top=" + (screen.height - 150) / 2 +
                                            ",left=" + (screen.width - 380) / 2 +
                                            ",scrollbars=yes,menubar=no,toolbar=no,status=yes,resizable=no,copyhistory=no");
        },

    	//공동발주사 전자서명
        Sign: function () {
        	window.open("https://www.gspartner.co.kr/EPSWeb/EPSCON/EPSCON1200.aspx",
                "Sign",
                "width=1280,height=900,top=5,left=5,scrollbars=yes,menubar=no,toolbar=no,status=yes,resizable=yes,copyhistory=no");
        },

        //공통레이아웃
        commonLayout: function (varg) {
            $("#r_pop").css("display", "block");
            $("#r_pop").html(varg);

            doOpenLayer("r_pop");
        },

        //레이아웃 닫기
        close: function () {
            $("a.c").click(function (e) {
                $("#user-control-search").fadeOut();
                doResetSearchFooter();

                $("#user-control-auth").fadeOut();
                doResetAuthFooter();

                $("#r_pop").empty();

                e.preventDefault();
            });
        },

        //자회사용 공통레이아웃_2020.01.09 추가
        othCommonLayout: function (varg) {
            $("#r_popOth").css("display", "block");
            $("#r_popOth").html(varg);

            doOpenLayer("r_popOth");
        },
        //인증관리_2020.01.09 추가
        XiAuthManager: function () {
            var userAgentInfo = navigator.userAgent;
            if (userAgentInfo.match("iPhone") != null || userAgentInfo.match("Android") != null) {
                if ("Ko" == getDomainType()) {
                    alert("모바일 사용자는 이용할 수 없습니다.");
                } else {
                    alert("Mobile users are not allowed.");
                }
                return false;
            }

            $("#user-control-search").css("display", "none");
            $("#user-control-auth").css("display", "block");
            $("#user-control-auth").fadeIn();
            $.authInterval();   // 자이 S&D 용으로 분기해얄 듯 한데....
            $("#authMain").spin(opts);
        },
        //등록절차_2020.01.09 추가
        othStep: function (corpCd) {
            if (corpCd == "000010")
                $openPop.othCommonLayout(doSend("OnmStepInfo", corpCd));
            else if (corpCd == "000030")
                $openPop.commonLayout(doSend("SndStepInfo", corpCd));
            else if (corpCd == "000040")
                $openPop.othCommonLayout(doSend("GcsStepInfo", corpCd));
            else if (corpCd == "000050")
                $openPop.othCommonLayout(doSend("EstStepInfo", corpCd));
			//C20200526_38947_발주사 추가 요청 (베트남 법인 VGSI, VGSE)-->>
            else if (corpCd == "000110")
            	$openPop.othCommonLayout(doSend("VgsiStepInfo", corpCd));
            else if (corpCd == "000120")
            	$openPop.othCommonLayout(doSend("VgseStepInfo", corpCd));
            //C20200526_38947_발주사 추가 요청 (베트남 법인 VGSI, VGSE)<<--
        },
        //자회사 회사소개_2020.01.09 추가
        othIntro: function (corpCd) {
            var url;
            if ("Ko" == getDomainType()) {
                if (corpCd == "000010")
                    url = "http://www.zeitonm.com/company/ceo";
                else if (corpCd == "000030")
                    url = "http://xisnd.com/index.php/page/greetings/44";
                else if (corpCd == "000040")
                    url = "http://www.elysian.co.kr/about/ceo.asp";
                else if (corpCd == "000050")
                    url = "http://www.xiestec.co.kr/company/greeting.asp";

            	//C20200526_38947_발주사 추가 요청 (베트남 법인 VGSI, VGSE)-->>
                else if (corpCd == "000110")
                    url = "http://gsenc.vn/";
                else if (corpCd == "000120")
                    url = "http://gsenc.vn/";
            	//C20200526_38947_발주사 추가 요청 (베트남 법인 VGSI, VGSE)<<--

            } else {
                if (corpCd == "000010")
                    url = "http://www.zeitonm.com/en/company_en/ceo";
                else if (corpCd == "000030")
                    url = "http://xisnd.com/index.php/page/greetings/44";
                else if (corpCd == "000040")
                    url = "http://www.elysian.co.kr/about/ceo.asp";
                else if (corpCd == "000050")
                    url = "http://www.xiestec.co.kr/company/greeting.asp";

                //C20200526_38947_발주사 추가 요청 (베트남 법인 VGSI, VGSE)-->>
                else if (corpCd == "000110")
                	url = "http://www.zeitonm.com/en/company_en/ceo";
                else if (corpCd == "000120")
                	url = "http://www.zeitonm.com/en/company_en/ceo";
            	//C20200526_38947_발주사 추가 요청 (베트남 법인 VGSI, VGSE)<<--
            }

            window.open(url, "_blank");
        },
        //자회사 개인정보취급방침_2020.01.09 추가
        othPrivateInfo: function (corpCd) {
            var url = "";
            var fnm = "";
            if (corpCd == "000010") {
                fnm = "OnmPrivateInfo";
            }
            else if (corpCd == "000030") {
                fnm = "SndPrivateInfo";
            }
            else if (corpCd == "000040") {
                fnm = "GcsPrivateInfo";
            }
            else if (corpCd == "000050") {
                fnm = "EstPrivateInfo";
            }

        	//C20200526_38947_발주사 추가 요청 (베트남 법인 VGSI, VGSE)-->>
            else if (corpCd == "000110") {
            	fnm = "VgsiPrivateInfo";
            }
            else if (corpCd == "000120") {
            	fnm = "VgsePrivateInfo";
            }
			//C20200526_38947_발주사 추가 요청 (베트남 법인 VGSI, VGSE)<<--

            if (url != "")
                window.open(url, "_blank");
            else
            {
                if (corpCd == "000030")
                    $openPop.commonLayout(doSend(fnm, corpCd));
                else
                    $openPop.othCommonLayout(doSend(fnm, corpCd));
            }
                
        },
        //인증관리_2020.01.09 추가
        othAuthManager: function (corpCd) {
            var WebAppRoot = fnGetRoot(corpCd);
            var url = WebAppRoot + "Common/cab/ktnetOpenWeb/install/pki/index.htm";

            window.open(url, "_blank");
        },
        //이메일주소수집거부_2020.01.09 추가
        othEmail: function (corpCd) {
            $openPop.othCommonLayout(doSend("EmailOther", corpCd));
        },
        //레이아웃 닫기
        othClose: function () {
            $("a.c").click(function (e) {
                $("#user-control-search").fadeOut();
                //doResetSearchFooter();
                
                $("#user-control-auth").fadeOut();
                //doResetAuthFooter();

                $("#r_popOth").empty().fadeOut();

                e.preventDefault();
            });
        },
    };
})();

function doOpenLayer(obj) {
    var temp = $("#" + obj);
    temp.css("min-height", $(document).height());
    $("body,html").animate({ scrollTop: 0 }, 666);
    temp.fadeIn();

    temp.find("a.c").click(function (e) {
        temp.fadeOut();
        temp.empty();
        e.preventDefault();
    });

    temp.find(".btn_w a").click(function (e) {
        temp.fadeOut();
        temp.empty();
        e.preventDefault();
    });
}

function doSend(varg, corp) {
    var WebAppRoot = fnGetRoot(corp);   //2020.01.09 추가
    var $layerContent;
    $.ajax({
        type: "get",
        url: WebAppRoot + "Common/footer/" + getDomainType() + "/" + varg + ".html",
        dataType: "html",
        async: false,
        success: function (data) {
            if (data.indexOf("<div") > -1) {
                $layerContent = data.substring(data.indexOf("<div"));
            }
        },
        error: function (xhr, textStatus) {
            alert(xhr.responseText);
        }
    });

    return $layerContent;
}

function SetComboVer(corpCd, defval) {
    var arrVer;
    if (corpCd == "000001") {
        arrVer = new Array("V 1.0 2016년 09월 30일 ~", "V 2.0 2020년 02월 24일 ~");
    }

    $('#ddlPriv').empty();
    for (i = 0; i < arrVer.length; i++) {
        var optVal = i + 1;
        var selected = optVal == defval ? "selected" : "";
        $('#ddlPriv').append("<option value=" + optVal + " " + selected + ">" + arrVer(i) + "</option>");
    }
}

function SetComboVer(objComRs, obj, bType, AllText, fnType, defVal) {

    // 기존 데이터 제거
    $('select[id$=ddlPriv]').empty();

    if (fnType === 'first') {
        // true 이면, ALL 추가
        if (bType == true)
            $('select[id$=' + obj + ']').append("<option value=''>" + AllText + "</option>");
        else
            $('select[id$=' + obj + ']').val('');
    }

    if (objComRs != '' && objComRs != null) {

        // 추가 option태그
        rStem = objComRs.split(";");
        for (var i = 0; i < rStem.length; i++) {
            trs = rStem[i].split(":");
            $('select[id$=' + obj + ']').append("<option value=" + trs[0] + ">" + trs[1] + "</option>");
        }
    }

    if (fnType === 'last') {
        // true 이면, ALL 추가
        if (bType == true)
            $('select[id$=' + obj + ']').append("<option value=''>" + AllText + "</option>");
        else
            $('select[id$=' + obj + ']').val('');
    }

    //2019.11.28 추가
    if (typeof (defVal) != "undefined" && defVal != null && defVal != "") {
        $('select[id$=' + obj + ']').val(defVal);
    }
}


