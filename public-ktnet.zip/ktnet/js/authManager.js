﻿(function ($) {
    this.check;

    $.authInterval = function () {
        this.check = setInterval(this.authStart, 3000);
    },

    $.authStart = function () {
        console.log("authStart");

        nxTSCommon.installCheck(false,
            {
                ajaxto: 2500,
                success: installComplete,
                versionCheck: [nxTSConfig.TSTOOLKIT]
            });
    },

    $.authStop = function () {
        clearInterval(this.check);
    }

})(jQuery)