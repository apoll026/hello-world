﻿$(document).ready(function () {
    console = window.console || { log: function () { } };

    //휴대폰번호
    $(".input_cellphone").keypress(function (event) {
        if (event.which && (event.which < 48 || event.which > 57)) {
            event.preventDefault();
        }

        fn_maskPhone(this);
    });

    //사업자번호 
    $(".biz_num").keypress(function (event) {
        if (event.which && (event.which < 48 || event.which > 57)) {
            event.preventDefault();
        }
    }).mask("999-99-99999", { placeholder: "__-__-_____" });

});

function fn_maskPhone(obj) {
    obj.value = fn_PhoneNumStr(obj.value);
}

function fn_PhoneNumStr(str) {
    var RegNotNum = /[^0-9]/g;
    var RegPhoneNum = "";
    var DataForm = "";

    // return blank     
    if (str == "" || str == null) return "";

    // delete not number
    str = str.replace(RegNotNum, '');

    if (str.length < 4) return str;

    if (str.length > 3 && str.length < 7) {
        DataForm = "$1-$2";
        RegPhoneNum = /([0-9]{3})([0-9]+)/;
    } else if (str.length == 7) {
        DataForm = "$1-$2";
        RegPhoneNum = /([0-9]{3})([0-9]{4})/;
    } else if (str.length == 8) {
        DataForm = "$1-$2-$3";
        RegPhoneNum = /([0-9]{3})([0-9]{4})([0-9]+)/;
    } else if (str.length == 9) {
        DataForm = "$1-$2-$3";
        RegPhoneNum = /([0-9]{3})([0-9]{4})([0-9]+)/;
    } else if (str.length == 10) {
        if (str.substring(0, 2) == "02") {
            DataForm = "$1-$2-$3";
            RegPhoneNum = /([0-9]{3})([0-9]{4})([0-9]+)/;
        } else {
            DataForm = "$1-$2-$3";
            RegPhoneNum = /([0-9]{3})([0-9]{4})([0-9]+)/;
        }
    } else if (str.length > 10) {
        DataForm = "$1-$2-$3";
        RegPhoneNum = /([0-9]{3})([0-9]{4})([0-9]+)/;
    }

    if (RegPhoneNum != '') {
        while (RegPhoneNum.test(str)) {
            str = str.replace(RegPhoneNum, DataForm);
        }
    }

    return str;
}

//***************************************************************
// 사업자번호 형식
// 생성일자 : 2020년 01월 09일
// 작업자   : 이미화
// comBizNumberChangeStr
//***************************************************************
function comBizNumberChangeStr(str) {
    var RegNotNum = /[^0-9]/gi;
    var RegPhonNum = "";
    var DataForm = "";

    str = str.replace(RegNotNum, '');
    if (str == "" || str == null) { return "" };

    if (str.length > 3 && str.length < 5) {
        DataForm = "$1-$2";
        RegPhonNum = /([0-9]{3})([0-9]+)/;
    }
    else if (str.length == 5) {
        DataForm = "$1-$2";
        RegPhonNum = /([0-9]{3})([0-9]{2})/;
    }
    else if (str.length == 6) {
        DataForm = "$1-$2-$3";
        RegPhonNum = /([0-9]{3})([0-9]{2})([0-9]+)/;
    }
    else if (str.length > 6) {
        DataForm = "$1-$2-$3";
        RegPhonNum = /([0-9]{3})([0-9]{2})([0-9]+)/;
    }

    if (str.length >= 4) {
        while (RegPhonNum.test(str)) {
            str = str.replace(RegPhonNum, DataForm);
        }
    }
    return str;
}

/*=======================================================================
/*Function명 : setKeyDownHandler(imgID)
/*내      용 : 엔터시 클릭이벤트 실행
/======================================================================*/
function setKeyDownHandler(img) {

    if (event.keyCode == 13) {

        event.returnValue = false;
        event.cancel = true;
        document.getElementById(img).click();
        return false;
    }
}

function doSendAjax(url, callback) {
    $.ajax({
        type: "POST",
        async: false,
        cache: false,
        url: url,
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            var jsonStr = JSON.parse(data.d);
            eval(callback)(jsonStr.rtnCd, jsonStr.rtnMsg);
        },
        error: function (xhr, textStatus) {
            var rspTxt = JSON.parse(xhr.responseText);
            alert(rspTxt.Message + "\r\n관리자에게 문의바랍니다.");
        }
    });
}

function block() {
    //#ffcc00
    $.blockUI({ message: '', css: { backgroundColor: '#000000', color: '#ececec' } });
}

function unblock() {
    $.unblockUI(); 
}

String.prototype.replaceAll = function (org, dest) {
    return this.split(org).join(dest);
}

var opts = {
    lines: 10,
    length: 10,
    width: 7,
    radius: 12,
    color: "#000",
    speed: 1.4,
    trail: 54,
    shadow: false,
    top: "40%"
};

$.fn.spin = function (opts) {
    this.each(function () {
        var $this = $(this),
        data = $this.data();

        if (data.spinner) {
            data.spinner.stop();
            delete data.spinner;
        }
        if (opts !== false) {
            data.spinner = new Spinner($.extend({ color: $this.css('color') }, opts)).spin(this);
        }
    });

    return this;
};

function getCookie(name) {
    var nameOfCookie = name + "=";
    var x = 0;
    while (x <= document.cookie.length) {
        var y = (x + nameOfCookie.length);
        if (document.cookie.substring(x, y) == nameOfCookie) {
            if ((endOfCookie = document.cookie.indexOf(";", y)) == -1) {
                endOfCookie = document.cookie.length;
            }

            return unescape(document.cookie.substring(y, endOfCookie));
        }
        x = document.cookie.indexOf(" ", x) + 1;
        if (x == 0)
            break;
    }

    return "";
}


//***************************************************************
// To-do Count 조회
// 생성일자 : 2020년 01월 09일
// 작업자   : 이미화
//***************************************************************
function fuGetTodoCount(corpCD) {
    var objs = $("input[id$=hfAllowSys]").val().split(",");
    var WebAppRoot = fnGetRoot(corpCD);
    $.each(objs, function (idx, val) {
        var objId = "em"+ val;// obj.id;
        var params = {};
        params.sysCd = val;
        params.corpCD = corpCD;
        
        $.ajax({
            type: "POST",
            url: WebAppRoot + 'Common/WebService/AsycMethod.aspx' + '/GetTodoCount',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify(params),
            cache : false,
            success: function (data) {
                //debugger;
                if (typeof (data) != "undefined" && data != null && typeof (data.d) != "undefined" && data.d != null) {
                    var retCnt = Number(data.d);
                    if (retCnt > 0) {
                        $("#" + objId).text(data.d).show();
                        var divId = $("#" + objId)[0].parentNode.parentNode.id;
                        $("#" + divId).show();
                    }
                }
            },
            Error: function (x, e) {
                //console.log(e)
            }
        });
    });
}

function fnGetRoot(corp) {
    if (typeof (corp) == "undefined" || corp == null) return gWebAppRoot;

    if (corp == "000010" || corp.toUpperCase() == "ONM")
        return gWebAppRoot_Onm;
    else if (corp == "000030" || corp.toUpperCase() == "SND")
        return gWebAppRoot_Snd;
    else if (corp == "000040" || corp.toUpperCase() == "GCS")
        return gWebAppRoot_Gcs;
    else if (corp == "000050" || corp.toUpperCase() == "EST")
    	return gWebAppRoot_Est;
    //C20200526_38947_발주사 추가 요청 (베트남 법인 VGSI, VGSE) -->>
    else if (corp == "000110" || corp.toUpperCase() == "VGSI")
    	return gWebAppRoot_Vgsi;
    else if (corp == "000120" || corp.toUpperCase() == "VGSE")
    	return gWebAppRoot_Vgse;
    //C20200526_38947_발주사 추가 요청 (베트남 법인 VGSI, VGSE) <<--
    else
        return gWebAppRoot;
}

