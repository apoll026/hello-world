﻿// 전역 변수
var gWebAppRoot = "/";
var gWebAppRoot_Snd = "/SND/";
var gWebAppRoot_Onm = "/ONM/";
var gWebAppRoot_Gcs = "/GCS/";
var gWebAppRoot_Est = "/EST/";
var gWebAppRoot_Vgse = "/VGSE/"; //C20200526_38947_발주사 추가 요청 (베트남 법인 VGSI, VGSE)
var gWebAppRoot_Vgsi = "/VGSI/"; //C20200526_38947_발주사 추가 요청 (베트남 법인 VGSI, VGSE)