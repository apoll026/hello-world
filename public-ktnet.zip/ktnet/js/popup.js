﻿
/*=======================================================================
/*Function명 : setOpenPopupCenter(sUrl, sName, iWidth, iHeight, sScroll, sResize, sLocation, sMenuID)
/*내      용 : 팝업창 화면 중앙에 띄우기
/======================================================================*/
function setOpenPopupCenter(sUrl, sName, iWidth, iHeight, sScroll, sResize, sLocation) {

    var iLeft = (screen.availWidth - iWidth) / 2;
    var iTop = (screen.availHeight - iHeight) / 2;

    if (sResize == "Y") {
        sResize = "yes";
    }
    else {
        sResize = "no";
    }

    if (sScroll == "Y") {
        sScroll = "yes";
    }
    else
        sScroll = "no";


    var sFeatures = "width=" + iWidth
                  + ",height=" + iHeight
                  + ",left=" + iLeft
                  + ",top=" + iTop
                  + ",resizable=" + sResize
                  + ",scrollbars=" + sScroll
                  + ",toolbar=no,status=no"
                  + ",location=" + sLocation;

   

    var vPopup = window.open(sUrl, sName, sFeatures);
    if (vPopup != null) {
        vPopup.focus();
    }
    return false;
}

/*=======================================================================
/*Function명 : setShowModal(modalWindowName, width, height, menuid)
/*내      용 : 모달 다이얼로그 박스를 띄운다.
/*             다이얼로그에서 넘겨준 값을 리턴
/======================================================================*/
function setShowModal(modalWindowName, width, height, scroll) {
    var arr;
    var sUrl = modalWindowName;
    if (!scroll) {
        scroll = "no";
    }
    arr = showModalDialog(sUrl,
                        window,
                        "center:yes;edge:raised;resizable:no;status:no;help:no;scroll:" + scroll + "; dialogWidth:" + width + "px; dialogHeight:" + height + "px;");
    return arr;
}
/*=================================================================
summary: 단일 컨트롤의 팝업 or 모달창을 뛰움
parameter: popupyn - 팝업여부(true, false)
value 해당 팝업에뛰어줄 value
hdFORM_ID - 해당 페이지 URL
width - 팝업 가로크기
height - 팝업 세로크기

/======================================================================*/
function setUserControlPopup(popupyn, page, formid, width, height, IDClient, NameClient, hdIDClient, hddataClient, TelClient) {

    if (popupyn == "Y") {

        var iLeft = (screen.availWidth - width) / 2;
        var iTop = (screen.availHeight - height) / 2;
        var sFeatures = "width=" + width
                  + ",height=" + height
                  + ",left=" + iLeft
                  + ",top=" + iTop
                  + ",scrollbars=no"
                  + ",toolbar=no,status=no";
        window.open(page, formid, sFeatures);
        return false;

    } else {
        var result = showModalDialog(page,
                        window,
                        "center:yes;edge:raised;resizable:no;status:no;help:no;scroll:no;dialogWidth:" + width + "px; dialogHeight:" + height + "px;Help:No");
        if ((result != null) && (result != undefined)) {


            document.getElementById(hdIDClient).value = result[0];
            document.getElementById(IDClient).value = result[1];
            document.getElementById(NameClient).value = result[2];
            document.getElementById(hddataClient).value = result[3];

            if (formid == "HR_Employees_pop" && document.getElementById(TelClient) != null)
                document.getElementById(TelClient).value = result[4];
        }

    }

    return false;
}


/*=======================================================================
summary: 유저컨트롤 모달
parameter: formid : 해당 팝업 page 
, param : 필요한 파람 값들
, width : width
, height : 높이
/======================================================================*/
function setUserControlModal(formid, param) {
    
    var page = "/Buyer/Common/Popup/" + formid + ".aspx?POPUPYN=N" + param;
    if (param == "") {
        page += "&SELECTYN=Y";
    }
    var width = "400";
    var height = "400";
    
    switch (formid.toUpperCase()) {

        //case "CODE_POP":
        //    width = "350";
        //    break;
        //case "CONSTCLASS_POP":
        //    width = "350";
        //    break;
        case "HR_EMPLOYESS_POP":
            width = "700";
            height = "600";
            break;
        //case "PORJECT_POP":
        //    width = "350";
        //    break;
        case "COMPANY_POP":
            width = "990";
            height = "600";
            break;
        case "PROJECTPOPUP":
            width = "700";
            break;
        case "CONSTCLASS_POP":
            width = "450";
            break;
        case "PASSWORD_CHANGE_POP"://비밀번호 변경
            width = "550";
            height = "350";
            break;
        case "PR_COMPANY_POP":
            width = "990";
            height = "600";
            break;
        case "PAYMENT_DEDUCTION_POP":
            width = "990";
            height = "600";
            break
        case "PR_ITEM_POP":
            width = "800";
            height = "450";
            break;
    }
    
    var result = showModalDialog(page,
                        window,
                        "scroll:no; font-family:Verdana; status:no; center:yes; dialogWidth:" + width + "px; dialogHeight:" + height + "px;Help:No");
    
    return result;
}
/*=======================================================================
summary: 유저컨트롤 모달
parameter: formid : 해당 팝업 page 
, param : 필요한 파람 값들
/======================================================================*/
function setCommonSearchModal(formid, param, id, name) {
    
    param += "&SELECTYN=N";
    var result = setUserControlModal(formid, param);
    if ((result != null) && (result != undefined)) {
        $("#" + id).val(result[1])
        $("#" + name).val(result[2])
    }
    return false;
}
/*=======================================================================
summary: 공통팝업 
parameter: formid : 해당 팝업 page 
, param : 필요한 파람 값들
, width : width
, height : 높이
/======================================================================*/
function setCommonPopup(formid, param) {
    
    var page = "/Buyer/Common/Popup/" + formid + ".aspx?" + param;
    var width = "400";
    var height = "400";
    var sScroll = "no";
    var sResize = "no";
    var sLocation = "no";
    
    switch (formid.toUpperCase()) {

        case "COMPANY_INFO_POP":

            width = window.screen.width < 1150 ? window.screen.width : 1150;

            height = "700";
            sScroll = "Y";
            break;
        case "PROJECTPOPUP":

            width = window.screen.width < 1150 ? window.screen.width : 1150;

            height = "700";
            sScroll = "Y";
            break;
        case "HR_EMPLOYESS_POP":

            width = window.screen.width < 1150 ? window.screen.width : 1150;

            height = "700";
            sScroll = "Y";
            break;

        case "PR_COMPANY_POP":
            width = "990";
            height = "600";
            break;

        case "Payment_Deduction_pop":
            width = "990";
            height = "600";
            break;
    }
    setOpenPopupCenter(page, formid, width, height, sScroll, sResize, sLocation)

}
/*=======================================================================
summary: 공통팝업 모달
parameter: formid : 해당 팝업 page 
, param : 필요한 파람 값들
, width : width
, height : 높이
/======================================================================*/
function setCommonModal(formid, param) {

    var page = "/Buyer/Common/Popup/" + formid + ".aspx?" + param;
    var width = "400";
    var height = "400";
    
    switch (formid.toUpperCase()) {

        case "COMPANY_INFO_POP":
            width = "600";
            height = "800";
            break;
     
    }

    var result = showModalDialog(page,
                        window,
                        "scroll:no; font-family:Verdana; status:no; center:yes; dialogWidth:" + width + "px; dialogHeight:" + height + "px;Help:No");

    return result;
}
/*=======================================================================
summary: 유저 컨트롤 Ajax
parameter: id - textboxid, name - textboxname, formid - 컨트롤id, param : 
form_id : 호출한 해당값
/======================================================================*/
var obj;
function GetCMBlurAjax(id, name, hdid, formid, hddata, param, telid) {
    obj = getXMLHTTPRequest();
    if (obj != null && document.getElementById(id).value != document.getElementById(hdid).value) {
        obj.onreadystatechange = function () {
            setProcessResponse(id, name, hdid, hddata, telid);
        }
        obj.open("GET", "/Buyer/Common/Popup/PopupCMBlurAjax.aspx?SearchText=" + encodeURIComponent(document.getElementById(id).value) + "&FORM_ID=" + formid + param, false);
        obj.send(null);
    }
    return false;
}

/*=======================================================================
summary: getXMLHTTPRequest
 
/======================================================================*/
function getXMLHTTPRequest() {
    var xRequest = null;
    if (window.XMLHttpRequest) {
        xRequest = new XMLHttpRequest();
    } else if (typeof ActiveXObject != "undefined") {
        xRequest = new ActiveXObject("Microsoft.XMLHTTP");
    }
    return xRequest;
}

/*=======================================================================
summary: 유저컨트롤에 데이터를 세팅한다.
parameter: id - textboxid, name - textboxname, formid - 컨트롤id, param : 
form_id : 호출한 해당값
/======================================================================*/
function setProcessResponse(id, name, hdid, hddata, telid) {
    if (obj.readyState == 4) {
        if (obj.status == 200) {
            var Data = new Array();

            var retval = obj.responseText;
            Data = retval.split('^*^');
            document.getElementById(id).value = Data[0];
            document.getElementById(name).value = Data[1];
            document.getElementById(hdid).value = Data[2];
            if (telid != null && document.getElementById(telid) != null) {
                document.getElementById(telid).value = "";
            }

            var fn_data = "";
            if (Data.length > 2 && Data[3] !="") {
                fn_data = Data[3].substring(Data[3].indexOf("[") + 1, Data[3].indexOf("]"));

                if (telid != null) {
                    var aa = JSON.parse(Data[3]);
                    if (aa.Table[0].TEL != null && document.getElementById(telid) != null)
                        document.getElementById(telid).value = aa.Table[0].TEL;
                }
            }

            
            
            document.getElementById(hddata).value = fn_data;


        }
        else {
            alert("Search Error!");
        }
    }
}
/*=======================================================================
summary: 유저컨트롤 데이터를 놓는다. 
parameter: clientid - txtid box, clientname - txtname box
         , clienthdid - txtid 히든 box, clienthddata - 그외의 데이터
         , id - id 값
         , name - 이름값
         , hdid - 진짜 key id값
         , hddata - 그이외에 필요한 데이터
/======================================================================*/
function setUserControlData(clientid, clientname, clienthdid, clienthddata, id, name, hdid, hddata, fn_name) {
    try {
        document.getElementById(clientid).value = id;
        document.getElementById(clientname).value = name;
        document.getElementById(clienthdid).value = hdid;
        document.getElementById(clienthddata).value = hddata;

        if (fn_name != "") {
            eval(fn_name)(hddata);
        }
    } catch (e) {
        alert(e.message)
    }
    
}
//***************************************************************
// 공종내역 팝업
//***************************************************************
function setConstdetailPop(PRNo, ConstCode, ViewYN, MENU_ID) {
    var vUrl = "/Buyer/Pr/Sub/pr_constdetail_save_pop.aspx";
    vUrl += "?PRNo=" + escape(PRNo) + "&ConstCode=" + escape(ConstCode) + "&ViewYN=" + escape(ViewYN) + "&MENU_ID=" + escape(MENU_ID);
    var result = setShowModal(vUrl, "900px", "700px");
    return result;
}
//***************************************************************
// 견적대비표 팝업
//***************************************************************
function setEligibilityResultPop(bidNo, bidRound, MENU_ID) {
    var vUrl = "bid_predecide_compare_pop.aspx";
    vUrl += "?bidNo=" + escape(bidNo) + "&bidRound=" + escape(bidRound) + "&MENU_ID=" + escape(MENU_ID);
    var result = setOpenPopupCenter(vUrl, "bid_predecide_compare_pop", 1000, 750, "Y", "N", "N");
    return result;
}
//***************************************************************
// 적격심사 결과 팝업
//***************************************************************
function setEligibilityResultPop(bidNo, bidRound, CompanyCode, MENU_ID) {
    var vUrl = "bid_open_eligibility_save_pop.aspx";
    vUrl += "?bidNo=" + escape(bidNo) + "&bidRound=" + escape(bidRound) + "&CompanyCode=" + escape(CompanyCode) + "&PointType=V&MENU_ID=" + escape(MENU_ID);
    var result = setOpenPopupCenter(vUrl, "", 1000, 750, "Y", "N", "N");
    return result;
}
//***************************************************************
// 투찰정보 팝업
//***************************************************************
function setBidSubmitInfoPop(bidNo, bidRound, CompanyCode, MENU_ID) {
    var vUrl = "/Buyer/Bid/Sub/bid_predecide_submit_pop.aspx";
    vUrl += "?bidNo=" + escape(bidNo) + "&bidRound=" + escape(bidRound) + "&CompanyCode=" + escape(CompanyCode) + "&MENU_ID=" + MENU_ID;
    var result = setOpenPopupCenter(vUrl, "bid_open_eligibility_save_pop", 1000, 900, "Y", "N", "N");
    return result;
}
//***************************************************************
// 투찰이력 팝업
//***************************************************************
function setBidSubmitHistoryPop(bidNo, MENU_ID) {
    var vUrl = "/Buyer/Bid/Sub/bid_predecide_submit_history_pop.aspx";
    vUrl += "?bidNo=" + escape(bidNo) + "&MENU_ID=" + MENU_ID;
    var result = setOpenPopupCenter(vUrl, "bid_predecide_submit_history_pop", 600, 400, "N", "N", "N");
    return result;
}
//***************************************************************
// 현설 참가 정보 팝업
//***************************************************************
function setBidSitebriefingPop(bidNo, bidRound, CompanyCode, MENU_ID) {
    var vUrl = "/Buyer/Bid/Sub/bid_sitebriefing_charge_view_pop.aspx";
    vUrl += "?bidNo=" + escape(bidNo) + "&bidRound=" + escape(bidRound) + "&CompanyCode=" + escape(CompanyCode) + "&MENU_ID=" + MENU_ID;
    var result = setOpenPopupCenter(vUrl, "bid_sitebriefing_charge_view_pop", 650, 450, "N", "N", "N");
    return result;
}
//***************************************************************
// 참가신청 정보 팝업
//***************************************************************
function setBidJoinPop(bidNo, bidRound, CompanyCode, MENU_ID) {
    var vUrl = "/Buyer/Bid/Sub/bid_goingon_join_view_pop.aspx";
    vUrl += "?bidNo=" + escape(bidNo) + "&bidRound=" + escape(bidRound) + "&CompanyCode=" + escape(CompanyCode) + "&MENU_ID=" + MENU_ID;
    var result = setOpenPopupCenter(vUrl, "bid_goingon_join_view_pop", 500, 270, "N", "N", "N");
    return result;
}
//***************************************************************
// 입찰담당자 정보 팝업
//***************************************************************
function setBidSubmitChargePop(bidNo, bidRound, CompanyCode, MENU_ID) {
    var vUrl = "/Buyer/Bid/Sub/bid_submit_charge_view_pop.aspx";
    vUrl += "?bidNo=" + escape(bidNo) + "&bidRound=" + escape(bidRound) + "&CompanyCode=" + escape(CompanyCode) + "&MENU_ID=" + MENU_ID;
    var result = setOpenPopupCenter(vUrl, "bid_submit_charge_view_pop", 600, 340, "N", "N", "N");
    return result;
}
//***************************************************************
// 자동공지사항 상세 팝업
//***************************************************************
function setAutoNoticePop(keys) {
    var strTempKeyList = keys;
    if (Trim(strTempKeyList).length == 0)
        return;

    // (고유번호)_(로그인 전후 구분 (외부이므로 'E'로 고정))_시작_종료일  
    var arrList = strTempKeyList.split("^*^");
    if (arrList != null) {
        for (var i = 0; i < arrList.length; i++) {
            if (!getCookie(arrList[i])) {
                var vUrl = "/Buyer/Common/Popup/notice_auto_pop.aspx";
                vUrl += "?NoticeNo=" + escape(arrList[i]);
                setOpenPopupCenter(vUrl, "notice_view_pop" + arrList[i], 700, 550, "N", "N", "N");
            }
        }
    }
}
//***************************************************************
// 공지사항 상세 팝업
//***************************************************************
function noticePop(key) {    
    var vUrl = "/Buyer/Common/Popup/notice_auto_pop.aspx";
        vUrl += "?NoticeNo=" + escape(key);
        setOpenPopupCenter(vUrl, "notice_view_pop", 700, 550, "N", "N", "N");
}

/**
  * 쿠키값 추출
  * @param cookieName 쿠키명
  */
function getCookie(cookieName) {
    var search = cookieName + "=";
    var cookie = document.cookie;

    // 현재 쿠키가 존재할 경우
    if (cookie.length > 0) {
        // 해당 쿠키명이 존재하는지 검색한 후 존재하면 위치를 리턴.
        startIndex = cookie.indexOf(cookieName);

        // 만약 존재한다면
        if (startIndex != -1) {
            // 값을 얻어내기 위해 시작 인덱스 조절
            startIndex += cookieName.length;

            // 값을 얻어내기 위해 종료 인덱스 추출
            endIndex = cookie.indexOf(";", startIndex);

            // 만약 종료 인덱스를 못찾게 되면 쿠키 전체길이로 설정
            if (endIndex == -1) endIndex = cookie.length;

            // 쿠키값을 추출하여 리턴
            return unescape(cookie.substring(startIndex + 1, endIndex));
        } else {
            // 쿠키 내에 해당 쿠키가 존재하지 않을 경우
            return false;
        }
    } else {
        // 쿠키 자체가 없을 경우
        return false;
    }
}
/**
 * 쿠키 설정
 * @param cookieName 쿠키명
 * @param cookieValue 쿠키값
 * @param expireDay 쿠키 유효날짜
 */
function setCookie(cookieName, cookieValue, expireDate) {
    //00:00시 기준 쿠키설정하기
    var todayDate = new Date();
    todayDate = new Date(parseInt(todayDate.getTime() / 86400000) * 86400000 + 54000000);
    if (todayDate > new Date()) {
        expireDate = expireDate - 1;
    }
    todayDate.setDate(todayDate.getDate() + parseInt(expireDate));
    document.cookie = cookieName + "=" + escape(cookieValue) + "; path=/; expires=" + todayDate.toGMTString() + ";";
}
//***************************************************************
// 전자계약 업체 정보
// CompMgmtType:업체구분(C:회사,J:공동도급사,P:개인)
//***************************************************************
function setContractCompanyModal(CompMgmtType, MENU_ID) {
    var vUrl = "/Buyer/Contract/Sub/popup/contract_company_pop.aspx";
    vUrl += "?CompMgmtType=" + CompMgmtType + "&MENU_ID=" + escape(MENU_ID);
    var result = setShowModal(vUrl, "600px", "500px");
    return result;
}