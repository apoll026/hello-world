﻿(function ($) {
    this.check;

    $.authInterval = function () {
        this.check = setInterval(this.authStart, 3000);
    },

    $.authStart = function () {
        console.log("authStart");

        nxTSCommon.installCheck(false,
            {
                ajaxto: 2500,
                success: installComplete,
                versionCheck: [nxTSConfig.TSTOOLKIT]
            });
    },

    $.authStop = function () {
        clearInterval(this.check);
    }

})(jQuery)

var opts = {
    lines: 10,
    length: 10,
    width: 7,
    radius: 12,
    color: "#000",
    speed: 1.4,
    trail: 54,
    shadow: false,
    top: "40%"
};

$.fn.spin = function (opts) {
    this.each(function () {
        var $this = $(this),
        data = $this.data();

        if (data.spinner) {
            data.spinner.stop();
            delete data.spinner;
        }
        if (opts !== false) {
            data.spinner = new Spinner($.extend({ color: $this.css('color') }, opts)).spin(this);
        }
    });

    return this;
};