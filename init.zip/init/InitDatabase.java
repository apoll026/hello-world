import java.io.File;
import java.sql.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.IOException;

public class InitDatabase {
    public static void main(String[] args) {

        Create init = new Create();
        init.call();
    }

}

class Create {

    private String dbUrl = "jdbc:postgresql://_JDBC_URL_:5432";
    private String dbUser = "_DB_USER_";
    private String dbPass = "_DB_PASS_";
    private String dbAdminUser = "_DB_ADMIN_USER_";
    private String dbAdminPass = "_DB_ADMIN_PASS_";
    private String systemName = "_SYSTEM_NAME_";


    public void call() {

        Connection dbConn = null;
        Connection tableConn = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        String sql = null;
        String dbName = systemName + "db"; // New Database Name

        int dbCount = 0;
        int tableCount = 0;

        try {
            // Postgres DB Connection
            dbConn = getConnection("postgres", true);

            // Database check
            sql = "SELECT count(1) as num FROM PG_DATABASE WHERE DATNAME = '" + dbName + "'";
            preparedStatement = dbConn.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                dbCount = resultSet.getInt("num");
            }
            System.out.println("SQL (DBCount) : " + sql + " -> " + dbCount);

            if (dbCount == 0) {
                // Create Database
                sql = "CREATE DATABASE " + dbName;
                preparedStatement = dbConn.prepareStatement(sql);
                preparedStatement.executeUpdate();
                System.out.println("SQL : " + sql);
            }

            // System DB Connection
            tableConn = getConnection(dbName, false);

            // Table check
            sql = "SELECT COUNT(1) AS NUM FROM PG_TABLES WHERE SCHEMANAME = 'public'";
            preparedStatement = tableConn.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                tableCount = resultSet.getInt("num");
            }
            System.out.println("SQL (TableCount) : " + sql + " -> " + tableCount);

            if (tableCount == 0) {

                int userCount = 0;

                // User Check (developer)
                sql = "SELECT COUNT(1) AS NUM FROM PG_USER WHERE USENAME = 'developer'";
                preparedStatement = dbConn.prepareStatement(sql);
                resultSet = preparedStatement.executeQuery();

                if (resultSet.next()) {
                    userCount = resultSet.getInt("num");
                }
                System.out.println("SQL (UserCount) : " + sql + " -> " + userCount);

                if (userCount == 0) {
                    // Create User (developer)
                    sql = "CREATE USER developer WITH PASSWORD '" + dbPass + "'";
                    preparedStatement = dbConn.prepareStatement(sql);
                    preparedStatement.executeUpdate();
                    System.out.println("SQL : CREATE USER developer WITH PASSWORD '**********'");
                }

                // User Check (Application User)
                sql = "SELECT COUNT(1) AS NUM FROM PG_USER WHERE USENAME = '" + dbUser + "'";
                preparedStatement = dbConn.prepareStatement(sql);
                resultSet = preparedStatement.executeQuery();

                if (resultSet.next()) {
                    userCount = resultSet.getInt("num");
                }
                System.out.println("SQL (UserCount) : " + sql + " -> " + userCount);

                if (userCount == 0) {
                    // Create User (Application User)
                    sql = "CREATE USER " + dbUser + " WITH PASSWORD '" + dbPass + "'";
                    preparedStatement = dbConn.prepareStatement(sql);
                    preparedStatement.executeUpdate();
                    System.out.println("SQL : CREATE USER " + dbUser + " WITH PASSWORD '**********'");
                }

                // Grant Database (developer)
                sql = "GRANT CONNECT, CREATE, TEMPORARY ON DATABASE " + dbName + " TO developer";
                preparedStatement = dbConn.prepareStatement(sql);
                preparedStatement.executeUpdate();
                System.out.println("SQL : " + sql);

                // Grant Database (Application User)
                sql = "GRANT CONNECT, CREATE, TEMPORARY ON DATABASE " + dbName + " TO " + dbUser;
                preparedStatement = dbConn.prepareStatement(sql);
                preparedStatement.executeUpdate();
                System.out.println("SQL : " + sql);

                // Grant Schema (developer)
                sql = "GRANT USAGE, CREATE ON SCHEMA public TO " + dbUser;
                preparedStatement = tableConn.prepareStatement(sql);
                preparedStatement.executeUpdate();
                System.out.println("SQL : " + sql);

                // Grant Schema (Application User)
                sql = "GRANT USAGE, CREATE ON SCHEMA public TO developer";
                preparedStatement = tableConn.prepareStatement(sql);
                preparedStatement.executeUpdate();
                System.out.println("SQL : " + sql);

                // Run DDL & DML
                querySqlFile("ddl", tableConn, preparedStatement, ";");
                querySqlFile("sequence", tableConn, preparedStatement, ";");
                querySqlFile("dml", tableConn, preparedStatement, ";");
                querySqlFile("func", tableConn, preparedStatement, "$$;");

                // Grant Table (developer)
                sql = "GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO developer";
                preparedStatement = tableConn.prepareStatement(sql);
                preparedStatement.executeUpdate();
                System.out.println("SQL : " + sql);

                // Grant Table (Application User)
                sql = "GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO " + dbUser;
                preparedStatement = tableConn.prepareStatement(sql);
                preparedStatement.executeUpdate();
                System.out.println("SQL : " + sql);

                // Grant Sequence (developer)
                sql = "GRANT SELECT,UPDATE,USAGE ON ALL SEQUENCES IN SCHEMA public TO developer";
                preparedStatement = tableConn.prepareStatement(sql);
                preparedStatement.executeUpdate();
                System.out.println("SQL : " + sql);

                // Grant Sequence (Application User)
                sql = "GRANT SELECT,UPDATE,USAGE ON ALL SEQUENCES IN SCHEMA public TO " + dbUser;
                preparedStatement = tableConn.prepareStatement(sql);
                preparedStatement.executeUpdate();
                System.out.println("SQL : " + sql);


                tableConn.commit();
            }


        } catch (Exception e) {
            e.printStackTrace();
            try {
                if (tableConn != null) {
                    tableConn.rollback();
                }
                if (dbConn != null && dbCount == 0) {
                    if (tableConn != null) {
                        tableConn.close();
                    }
                    sql = "DROP DATABASE " + dbName;
                    preparedStatement = dbConn.prepareStatement(sql);
                    preparedStatement.executeUpdate();
                    System.out.println("SQL : " + sql);
                }
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
        } finally {
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (tableConn != null) {
                try {
                    tableConn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (dbConn != null) {
                try {
                    dbConn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void querySqlFile(String folderName, Connection con, PreparedStatement pstmt, String seperator) throws IOException, SQLException {

        String currentDir = System.getProperty("user.dir") + "/init/";
        File folder = new File(currentDir + folderName);

        if (folder.exists() && folder.isDirectory()) {
            File[] files = folder.listFiles();

            if (files != null) {
                for (File file : files) {


                    String content = new String(Files.readAllBytes(Paths.get(file.getPath())));
                    String[] query = content.split(seperator);

                    System.out.println("SQL File[" + file.getPath() + "] Start");

                    for (int i = 0; i < query.length; i++) {
                        try {
                            if (query[i].trim().isEmpty()) {
                                continue;
                            }
                            pstmt = con.prepareStatement(query[i]);
                            pstmt.executeUpdate();
                        } catch (SQLException e) {
                            System.out.println(query[i]);
                            throw e;
                        }
                    }
                    System.out.println("SQL File[" + file.getPath() + "] End");
                }
            }

        }
    }

    public Connection getConnection(String name, boolean isAutoCommit) {
        Connection con = null;

        try {
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(dbUrl + "/" + name, dbAdminUser, dbAdminPass);
            con.setAutoCommit(isAutoCommit);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return con;
    }
}
