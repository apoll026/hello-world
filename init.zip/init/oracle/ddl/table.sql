create table tb_wsf_msg_m
(
    msg_ctn          varchar2(4000) not null,
    lang_cd          varchar2(3)    not null,
    msg_txt_ctn      varchar2(4000),
    rmk              varchar2(4000),
    opt_val_ctn1     varchar2(4000),
    opt_val_ctn2     varchar2(4000),
    opt_val_ctn3     varchar2(4000),
    use_yn           varchar2(1),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP
);

comment on table tb_wsf_msg_m is '메시지관리';

comment on column tb_wsf_msg_m.msg_ctn is '메시지코드';

comment on column tb_wsf_msg_m.lang_cd is '언어코드';

comment on column tb_wsf_msg_m.msg_txt_ctn is '메시지명';

comment on column tb_wsf_msg_m.rmk is '비고';

comment on column tb_wsf_msg_m.opt_val_ctn1 is '옵션값내용1';

comment on column tb_wsf_msg_m.opt_val_ctn2 is '옵션값내용2';

comment on column tb_wsf_msg_m.opt_val_ctn3 is '옵션값내용3';

comment on column tb_wsf_msg_m.use_yn is '사용여부';

comment on column tb_wsf_msg_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_msg_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_msg_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_msg_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_msg_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_msg_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_msg_m
    add constraint tb_wsf_msg_m_pk
        primary key (msg_ctn, lang_cd);

create table tb_wsf_menu_m
(
    mnu_id           varchar2(50)   not null,
    mnu_nm           varchar2(1000) not null,
    msg_ctn          varchar2(4000),
    mnu_url          varchar2(500),
    mnu_lv_no        numeric(10),
    uppr_mnu_id      varchar2(50),
    sort_ord         numeric(10),
    mnu_eps_yn       varchar2(1),
    use_yn           varchar2(1),
    mnu_desc         varchar2(200),
    mnu_opt_val_ctn1 varchar2(500),
    mnu_opt_val_ctn2 varchar2(500),
    mnu_opt_val_ctn3 varchar2(500),
    mnu_opt_val_ctn4 varchar2(500),
    mnu_opt_val_ctn5 varchar2(500),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    internal_yn      varchar2(1)
);

comment on table tb_wsf_menu_m is '메뉴';

comment on column tb_wsf_menu_m.mnu_id is '메뉴아이디';

comment on column tb_wsf_menu_m.mnu_nm is '메뉴메시지코드';

comment on column tb_wsf_menu_m.msg_ctn is '메시지내용';

comment on column tb_wsf_menu_m.mnu_url is '메뉴경로';

comment on column tb_wsf_menu_m.mnu_lv_no is '메뉴레벨';

comment on column tb_wsf_menu_m.uppr_mnu_id is '상위메뉴아이디';

comment on column tb_wsf_menu_m.sort_ord is '메뉴정렬순서번호';

comment on column tb_wsf_menu_m.mnu_eps_yn is '메뉴노출여부';

comment on column tb_wsf_menu_m.use_yn is '사용여부';

comment on column tb_wsf_menu_m.mnu_desc is '메뉴설명';

comment on column tb_wsf_menu_m.mnu_opt_val_ctn1 is '메뉴옵션값내용1';

comment on column tb_wsf_menu_m.mnu_opt_val_ctn2 is '메뉴옵션값내용2';

comment on column tb_wsf_menu_m.mnu_opt_val_ctn3 is '메뉴옵션값내용3';

comment on column tb_wsf_menu_m.mnu_opt_val_ctn4 is '메뉴옵션값내용4';

comment on column tb_wsf_menu_m.mnu_opt_val_ctn5 is '메뉴옵션값내용5';

comment on column tb_wsf_menu_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_menu_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_menu_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_menu_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_menu_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_menu_m.data_upd_dtm is '데이터수정일시';

comment on column tb_wsf_menu_m.internal_yn is '내부링크여부';

alter table tb_wsf_menu_m
    add constraint tb_wsf_menu_m_pk
        primary key (mnu_id);

create table tb_wsf_cmn_gr_c
(
    cmn_gr_cd        varchar2(50) not null,
    cmn_gr_cd_nm     varchar2(50) not null,
    cmn_gr_cd_desc   varchar2(1000),
    wkt_area_divs_cd varchar2(50),
    msg_ctn          varchar2(4000),
    sort_ord         numeric(10),
    opt_val_nm1      varchar2(100),
    opt_val_nm2      varchar2(100),
    opt_val_nm3      varchar2(100),
    opt_val_nm4      varchar2(100),
    opt_val_nm5      varchar2(100),
    opt_val_nm6      varchar2(100),
    opt_val_nm7      varchar2(100),
    opt_val_nm8      varchar2(100),
    opt_val_nm9      varchar2(100),
    opt_val_nm10     varchar2(100),
    opt_val_nm11     varchar2(100),
    opt_val_nm12     varchar2(100),
    opt_val_nm13     varchar2(100),
    opt_val_nm14     varchar2(100),
    opt_val_nm15     varchar2(100),
    rmk              varchar2(4000),
    use_yn           varchar2(1),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP
);

comment on table tb_wsf_cmn_gr_c is '공통그룹코드';

comment on column tb_wsf_cmn_gr_c.cmn_gr_cd is '공통그룹코드';

comment on column tb_wsf_cmn_gr_c.cmn_gr_cd_nm is '공통그룹코드명';

comment on column tb_wsf_cmn_gr_c.cmn_gr_cd_desc is '공통그룹코드설명';

comment on column tb_wsf_cmn_gr_c.wkt_area_divs_cd is '업무영역구분코드';

comment on column tb_wsf_cmn_gr_c.msg_ctn is '메세지내용';

comment on column tb_wsf_cmn_gr_c.sort_ord is '정렬순서';

comment on column tb_wsf_cmn_gr_c.opt_val_nm1 is '옵션값명1';

comment on column tb_wsf_cmn_gr_c.opt_val_nm2 is '옵션값명2';

comment on column tb_wsf_cmn_gr_c.opt_val_nm3 is '옵션값명3';

comment on column tb_wsf_cmn_gr_c.opt_val_nm4 is '옵션값명4';

comment on column tb_wsf_cmn_gr_c.opt_val_nm5 is '옵션값명5';

comment on column tb_wsf_cmn_gr_c.opt_val_nm6 is '옵션값명6';

comment on column tb_wsf_cmn_gr_c.opt_val_nm7 is '옵션값명7';

comment on column tb_wsf_cmn_gr_c.opt_val_nm8 is '옵션값명8';

comment on column tb_wsf_cmn_gr_c.opt_val_nm9 is '옵션값명9';

comment on column tb_wsf_cmn_gr_c.opt_val_nm10 is '옵션값명10';

comment on column tb_wsf_cmn_gr_c.opt_val_nm11 is '옵션값명11';

comment on column tb_wsf_cmn_gr_c.opt_val_nm12 is '옵션값명12';

comment on column tb_wsf_cmn_gr_c.opt_val_nm13 is '옵션값명13';

comment on column tb_wsf_cmn_gr_c.opt_val_nm14 is '옵션값명14';

comment on column tb_wsf_cmn_gr_c.opt_val_nm15 is '옵션값명15';

comment on column tb_wsf_cmn_gr_c.rmk is '비고';

comment on column tb_wsf_cmn_gr_c.use_yn is '사용여부';

comment on column tb_wsf_cmn_gr_c.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_cmn_gr_c.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_cmn_gr_c.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_cmn_gr_c.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_cmn_gr_c.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_cmn_gr_c.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_cmn_gr_c
    add constraint tb_wsf_cmn_gr_c_pk
        primary key (cmn_gr_cd);

create table tb_wsf_cmn_c
(
    cmn_gr_cd        varchar2(50)  not null,
    cmn_cd           varchar2(150) not null,
    cmn_cd_nm        varchar2(200) not null,
    cmn_cd_desc      varchar2(400),
    uppr_cmn_cd      varchar2(150),
    msg_ctn          varchar2(4000),
    sort_ord         numeric(10),
    use_yn           varchar2(1),
    opt_val_ctn1     varchar2(4000),
    opt_val_ctn2     varchar2(4000),
    opt_val_ctn3     varchar2(4000),
    opt_val_ctn4     varchar2(4000),
    opt_val_ctn5     varchar2(4000),
    opt_val_ctn6     varchar2(4000),
    opt_val_ctn7     varchar2(4000),
    opt_val_ctn8     varchar2(4000),
    opt_val_ctn9     varchar2(4000),
    opt_val_ctn10    varchar2(4000),
    opt_val_ctn11    varchar2(4000),
    opt_val_ctn12    varchar2(4000),
    opt_val_ctn13    varchar2(4000),
    opt_val_ctn14    varchar2(4000),
    opt_val_ctn15    varchar2(4000),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP
);

comment on table tb_wsf_cmn_c is '공통코드';

comment on column tb_wsf_cmn_c.cmn_gr_cd is '공통그룹코드';

comment on column tb_wsf_cmn_c.cmn_cd is '공통코드';

comment on column tb_wsf_cmn_c.cmn_cd_nm is '공통코드명';

comment on column tb_wsf_cmn_c.cmn_cd_desc is '공통코드설명';

comment on column tb_wsf_cmn_c.uppr_cmn_cd is '상위공통코드';

comment on column tb_wsf_cmn_c.msg_ctn is '메세지내용';

comment on column tb_wsf_cmn_c.sort_ord is '정렬순서';

comment on column tb_wsf_cmn_c.use_yn is '사용여부';

comment on column tb_wsf_cmn_c.opt_val_ctn1 is '옵션값내용1';

comment on column tb_wsf_cmn_c.opt_val_ctn2 is '옵션값내용2';

comment on column tb_wsf_cmn_c.opt_val_ctn3 is '옵션값내용3';

comment on column tb_wsf_cmn_c.opt_val_ctn4 is '옵션값내용4';

comment on column tb_wsf_cmn_c.opt_val_ctn5 is '옵션값내용5';

comment on column tb_wsf_cmn_c.opt_val_ctn6 is '옵션값내용6';

comment on column tb_wsf_cmn_c.opt_val_ctn7 is '옵션값내용7';

comment on column tb_wsf_cmn_c.opt_val_ctn8 is '옵션값내용8';

comment on column tb_wsf_cmn_c.opt_val_ctn9 is '옵션값내용9';

comment on column tb_wsf_cmn_c.opt_val_ctn10 is '옵션값내용10';

comment on column tb_wsf_cmn_c.opt_val_ctn11 is '옵션값내용11';

comment on column tb_wsf_cmn_c.opt_val_ctn12 is '옵션값내용12';

comment on column tb_wsf_cmn_c.opt_val_ctn13 is '옵션값내용13';

comment on column tb_wsf_cmn_c.opt_val_ctn14 is '옵션값내용14';

comment on column tb_wsf_cmn_c.opt_val_ctn15 is '옵션값내용15';

comment on column tb_wsf_cmn_c.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_cmn_c.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_cmn_c.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_cmn_c.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_cmn_c.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_cmn_c.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_cmn_c
    add constraint tb_wsf_cmn_c_pk
        primary key (cmn_gr_cd, cmn_cd);

create table tb_wsf_ntdk_m
(
    ntdk_id          numeric(10) not null,
    ntdk_nm          varchar2(200),
    ntdk_desc        varchar2(200),
    use_yn           varchar2(1),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP
);

comment on column tb_wsf_ntdk_m.ntdk_id is '통보처아이디';

comment on column tb_wsf_ntdk_m.ntdk_nm is '통보처제목';

comment on column tb_wsf_ntdk_m.ntdk_desc is '통보처설명';

comment on column tb_wsf_ntdk_m.use_yn is '사용여부';

comment on column tb_wsf_ntdk_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_ntdk_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_ntdk_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_ntdk_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_ntdk_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_ntdk_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_ntdk_m
    add constraint tb_wsf_ntdk_m_pk
        primary key (ntdk_id);

create table tb_wsf_ntdk_d
(
    ntdk_id          numeric(10) not null,
    ntdk_seq         numeric(18) not null,
    ntdk_divs_cd     varchar2(50),
    apr_notf_user_id varchar2(50) not null,
    sort_ord         numeric(10),
    use_yn           varchar2(1),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP
);

comment on table tb_wsf_ntdk_d is '통보처상세';

comment on column tb_wsf_ntdk_d.ntdk_id is '통보처ID';

comment on column tb_wsf_ntdk_d.ntdk_seq is '통보처순번';

comment on column tb_wsf_ntdk_d.ntdk_divs_cd is '통보처구분코드';

comment on column tb_wsf_ntdk_d.apr_notf_user_id is '결재통보사용자ID';

comment on column tb_wsf_ntdk_d.sort_ord is '정렬순서';

comment on column tb_wsf_ntdk_d.use_yn is '사용여부';

comment on column tb_wsf_ntdk_d.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_ntdk_d.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_ntdk_d.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_ntdk_d.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_ntdk_d.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_ntdk_d.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_ntdk_d
    add constraint tb_wsf_ntdk_d_pk
        primary key (ntdk_id, ntdk_seq);

create table tb_wsf_apr_rule_m
(
    apr_rule_id          varchar2(50)  not null,
    apr_rule_nm          varchar2(100) not null,
    apr_ln_add_pmit_yn   varchar2(1)   not null,
    apr_rfer_add_psbl_yn varchar2(1)   not null,
    apr_ln_rstb_pmit_yn  varchar2(1)   not null,
    apr_ln_dupl_pmit_yn  varchar2(1)   not null,
    apr_exc_tgt_id       varchar2(50),
    mst_ntdk_id          numeric(10),
    data_ins_user_id     varchar2(50),
    data_ins_user_ip     varchar2(40),
    data_ins_dtm         TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id     varchar2(50),
    data_upd_user_ip     varchar2(40),
    data_upd_dtm         TIMESTAMP default CURRENT_TIMESTAMP,
    mst_ntdk_dept_id     numeric(10)
);

comment on table tb_wsf_apr_rule_m is '결재규칙기본';

comment on column tb_wsf_apr_rule_m.apr_rule_id is '결재규칙ID';

comment on column tb_wsf_apr_rule_m.apr_rule_nm is '결재규칙명';

comment on column tb_wsf_apr_rule_m.apr_ln_add_pmit_yn is '결재라인추가허용여부';

comment on column tb_wsf_apr_rule_m.apr_rfer_add_psbl_yn is '결재참조자추가가능여부';

comment on column tb_wsf_apr_rule_m.apr_ln_rstb_pmit_yn is '결재라인재설정허용여부';

comment on column tb_wsf_apr_rule_m.apr_ln_dupl_pmit_yn is '결재라인중복허용여부';

comment on column tb_wsf_apr_rule_m.apr_exc_tgt_id is '결재제외ID';

comment on column tb_wsf_apr_rule_m.mst_ntdk_id is '기본통보처ID';

comment on column tb_wsf_apr_rule_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_apr_rule_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_apr_rule_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_apr_rule_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_apr_rule_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_apr_rule_m.data_upd_dtm is '데이터수정일시';

comment on column tb_wsf_apr_rule_m.mst_ntdk_dept_id is '기본통보처부서ID';

alter table tb_wsf_apr_rule_m
    add constraint tb_wsf_apr_rule_m_pk
        primary key (apr_rule_id);

create table tb_wsf_apr_rule_d
(
    apr_rule_id        varchar2(50) not null,
    apr_ln_id          varchar2(30) not null,
    apr_tp_divs_cd     varchar2(20),
    prl_yn             varchar2(1),
    apr_ln_snb         numeric(18, 5),
    apr_ln_seq         numeric(18),
    apr_ln_role_cd     varchar2(10),
    dept_cd            varchar2(20),
    user_id            varchar2(50),
    apr_ln_chg_psbl_yn varchar2(1),
    apr_ln_del_psbl_yn varchar2(1),
    data_ins_user_id   varchar2(50),
    data_ins_user_ip   varchar2(40),
    data_ins_dtm       TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id   varchar2(50),
    data_upd_user_ip   varchar2(40),
    data_upd_dtm       TIMESTAMP default CURRENT_TIMESTAMP
);

comment on table tb_wsf_apr_rule_d is '결재규칙상세';

comment on column tb_wsf_apr_rule_d.apr_rule_id is '결재규칙ID';

comment on column tb_wsf_apr_rule_d.apr_ln_id is '결재라인ID';

comment on column tb_wsf_apr_rule_d.apr_tp_divs_cd is '결재유형구분코드';

comment on column tb_wsf_apr_rule_d.prl_yn is '병렬여부';

comment on column tb_wsf_apr_rule_d.apr_ln_snb is '결재라인차수';

comment on column tb_wsf_apr_rule_d.apr_ln_seq is '결재라인순번';

comment on column tb_wsf_apr_rule_d.apr_ln_role_cd is '결재라인역할코드';

comment on column tb_wsf_apr_rule_d.dept_cd is '부서코드';

comment on column tb_wsf_apr_rule_d.user_id is '사용자ID';

comment on column tb_wsf_apr_rule_d.apr_ln_chg_psbl_yn is '결재라인변경가능여부';

comment on column tb_wsf_apr_rule_d.apr_ln_del_psbl_yn is '결재라인삭제가능여부';

comment on column tb_wsf_apr_rule_d.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_apr_rule_d.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_apr_rule_d.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_apr_rule_d.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_apr_rule_d.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_apr_rule_d.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_apr_rule_d
    add constraint tb_wsf_apr_rule_d_pk
        primary key (apr_rule_id, apr_ln_id);

create table tb_wsf_apr_rule_exc_m
(
    apr_exc_tgt_id   varchar2(50) not null,
    apr_exc_nm       varchar2(20),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP
);

comment on table tb_wsf_apr_rule_exc_m is '결재규칙제외기본';

comment on column tb_wsf_apr_rule_exc_m.apr_exc_tgt_id is '결재제외대상ID';

comment on column tb_wsf_apr_rule_exc_m.apr_exc_nm is '결재제외명';

comment on column tb_wsf_apr_rule_exc_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_apr_rule_exc_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_apr_rule_exc_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_apr_rule_exc_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_apr_rule_exc_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_apr_rule_exc_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_apr_rule_exc_m
    add constraint tb_wsf_apr_rule_exc_m_pk
        primary key (apr_exc_tgt_id);

create table tb_wsf_apr_rule_exc_d
(
    apr_exc_tgt_id   varchar2(50) not null,
    apr_exc_seq      numeric(18) not null,
    apr_exc_divs_cd  varchar2(20) not null,
    apr_exc_user_id  varchar2(50),
    apr_exc_jti_cd   varchar2(10),
    apr_exc_jps_cd   varchar2(10),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP
);

comment on table tb_wsf_apr_rule_exc_d is '결재규칙제외상세';

comment on column tb_wsf_apr_rule_exc_d.apr_exc_tgt_id is '결재제외대상ID';

comment on column tb_wsf_apr_rule_exc_d.apr_exc_seq is '결재제외순번';

comment on column tb_wsf_apr_rule_exc_d.apr_exc_divs_cd is '결재제외구분코드(직급, 직책, 사용자)';

comment on column tb_wsf_apr_rule_exc_d.apr_exc_user_id is '결재제외사용자ID';

comment on column tb_wsf_apr_rule_exc_d.apr_exc_jti_cd is '결재제외직위코드';

comment on column tb_wsf_apr_rule_exc_d.apr_exc_jps_cd is '결재제외직책코드';

comment on column tb_wsf_apr_rule_exc_d.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_apr_rule_exc_d.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_apr_rule_exc_d.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_apr_rule_exc_d.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_apr_rule_exc_d.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_apr_rule_exc_d.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_apr_rule_exc_d
    add constraint tb_wsf_apr_rule_exc_d_pk
        primary key (apr_exc_tgt_id, apr_exc_seq);

create table tb_wsf_atch_file_m
(
    atch_file_gr_id            varchar2(50) not null,
    atch_file_id               varchar2(50) not null,
    atch_file_nm               varchar2(500),
    sort_ord                   numeric(10),
    atch_file_save_loc_divs_cd varchar2(20),
    atch_file_save_nm          varchar2(500),
    atch_file_size             numeric,
    atch_file_efnm_nm          varchar2(100),
    atch_file_save_path_ctn    varchar2(4000),
    atch_file_tp_cd            varchar2(20),
    opt_val_ctn1               varchar2(4000),
    opt_val_ctn2               varchar2(4000),
    opt_val_ctn3               varchar2(4000),
    opt_val_ctn4               varchar2(4000),
    opt_val_ctn5               varchar2(4000),
    use_yn                     varchar2(1),
    data_ins_user_id           varchar2(50),
    data_ins_user_ip           varchar2(40),
    data_ins_dtm               TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id           varchar2(50),
    data_upd_user_ip           varchar2(40),
    data_upd_dtm               TIMESTAMP default CURRENT_TIMESTAMP
);

comment on table tb_wsf_atch_file_m is '첨부파일';

comment on column tb_wsf_atch_file_m.atch_file_gr_id is '첨부파일그룹ID';

comment on column tb_wsf_atch_file_m.atch_file_id is '첨부파일ID';

comment on column tb_wsf_atch_file_m.atch_file_nm is '첨부파일명';

comment on column tb_wsf_atch_file_m.sort_ord is '정렬순서';

comment on column tb_wsf_atch_file_m.atch_file_save_loc_divs_cd is '첨부파일저장위치구분코드';

comment on column tb_wsf_atch_file_m.atch_file_save_nm is '첨부파일저장명';

comment on column tb_wsf_atch_file_m.atch_file_size is '첨부파일크기';

comment on column tb_wsf_atch_file_m.atch_file_efnm_nm is '첨부파일확장자명';

comment on column tb_wsf_atch_file_m.atch_file_save_path_ctn is '첨부파일저장경로내용';

comment on column tb_wsf_atch_file_m.atch_file_tp_cd is '첨부파일유형코드';

comment on column tb_wsf_atch_file_m.opt_val_ctn1 is '옵션값내용1';

comment on column tb_wsf_atch_file_m.opt_val_ctn2 is '옵션값내용2';

comment on column tb_wsf_atch_file_m.opt_val_ctn3 is '옵션값내용3';

comment on column tb_wsf_atch_file_m.opt_val_ctn4 is '옵션값내용4';

comment on column tb_wsf_atch_file_m.opt_val_ctn5 is '옵션값내용5';

comment on column tb_wsf_atch_file_m.use_yn is '사용여부';

comment on column tb_wsf_atch_file_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_atch_file_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_atch_file_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_atch_file_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_atch_file_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_atch_file_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_atch_file_m
    add constraint tb_wsf_atch_file_m_pk
        primary key (atch_file_gr_id, atch_file_id);

create table tb_wsf_role_m
(
    role_cd          varchar2(20) not null,
    role_nm          varchar2(400),
    role_desc        varchar2(4000),
    use_yn           varchar2(1),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    itgr_yn          varchar2(1)
);

comment on table tb_wsf_role_m is '역할(Roles) 기본 정보 테이블';

comment on column tb_wsf_role_m.role_cd is '역할코드';

comment on column tb_wsf_role_m.role_nm is '역할명';

comment on column tb_wsf_role_m.role_desc is '역할설명';

comment on column tb_wsf_role_m.use_yn is '사용여부';

comment on column tb_wsf_role_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_role_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_role_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_role_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_role_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_role_m.data_upd_dtm is '데이터수정일시';

comment on column tb_wsf_role_m.itgr_yn is 'itgr_yn';

alter table tb_wsf_role_m
    add constraint tb_wsf_role_m_pk
        primary key (role_cd);

create table tb_wsf_role_menu_m
(
    role_cd          varchar2(20) not null,
    mnu_id           varchar2(50) not null,
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP
);

comment on table tb_wsf_role_menu_m is '역할별 메뉴 권한 매핑 테이블';

comment on column tb_wsf_role_menu_m.role_cd is '역할코드';

comment on column tb_wsf_role_menu_m.mnu_id is '메뉴ID';

comment on column tb_wsf_role_menu_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_role_menu_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_role_menu_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_role_menu_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_role_menu_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_role_menu_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_role_menu_m
    add constraint tb_wsf_role_menu_m_pk
        primary key (role_cd, mnu_id);

create table tb_wsf_role_emp_m
(
    role_cd          varchar2(20) not null,
    user_id          varchar2(50) not null,
    emp_no           varchar2(30),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP
);

comment on table tb_wsf_role_emp_m is '역할별 사원 매핑 테이블';

comment on column tb_wsf_role_emp_m.role_cd is '역할코드';

comment on column tb_wsf_role_emp_m.user_id is '사용자ID';

comment on column tb_wsf_role_emp_m.emp_no is '사용자사번';

comment on column tb_wsf_role_emp_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_role_emp_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_role_emp_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_role_emp_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_role_emp_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_role_emp_m.data_upd_dtm is '데이터수정일시';

create table tb_wsf_api_m_back
(
    api_id           varchar2(50) not null,
    api_nm           varchar2(100),
    api_url          varchar2(500),
    use_yn           varchar2(1),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    http_mthd_cd     varchar2(50)
);

comment on table tb_wsf_api_m_back is 'API역할관리BACK';

comment on column tb_wsf_api_m_back.api_id is 'API ID';

comment on column tb_wsf_api_m_back.api_nm is 'API명';

comment on column tb_wsf_api_m_back.api_url is 'APIURL주소';

comment on column tb_wsf_api_m_back.use_yn is '사용여부';

comment on column tb_wsf_api_m_back.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_api_m_back.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_api_m_back.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_api_m_back.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_api_m_back.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_api_m_back.data_upd_dtm is '데이터수정일시';

comment on column tb_wsf_api_m_back.http_mthd_cd is 'HTTP방법코드';

alter table tb_wsf_api_m_back
    add constraint tb_wsf_api_m_pk
        primary key (api_id);

create table tb_wsf_role_api_m
(
    role_cd          varchar2(20) not null,
    api_id           varchar2(50) not null,
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP
);

comment on table tb_wsf_role_api_m is '역할별 API 권한 매핑 테이블';

comment on column tb_wsf_role_api_m.role_cd is 'API ID';

comment on column tb_wsf_role_api_m.api_id is 'API ID';

comment on column tb_wsf_role_api_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_role_api_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_role_api_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_role_api_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_role_api_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_role_api_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_role_api_m
    add constraint tb_wsf_role_api_m_pk
        primary key (role_cd, api_id);

create table tb_wsf_role_dept_m
(
    role_cd          varchar2(20) not null,
    dept_cd          varchar2(20) not null,
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP
);

comment on table tb_wsf_role_dept_m is '역할별 부서 매핑 테이블';

comment on column tb_wsf_role_dept_m.role_cd is '역할코드';

comment on column tb_wsf_role_dept_m.dept_cd is '부서코드';

comment on column tb_wsf_role_dept_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_role_dept_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_role_dept_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_role_dept_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_role_dept_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_role_dept_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_role_dept_m
    add constraint tb_wsf_role_dept_m_pk
        primary key (role_cd, dept_cd);

create table tb_wsf_bbs_m
(
    bbs_no            varchar2(10) not null,
    bbs_tp_cd         varchar2(10),
    bbs_sort_ord      numeric,
    bbs_title         varchar2(300),
    bbs_ctn           varchar2(4000),
    smry_ctn          varchar2(4000),
    atch_file_gr_id   varchar2(50),
    htag_ctn          varchar2(300),
    impt_yn           varchar2(1),
    use_yn            varchar2(1),
    bbs_vwct          numeric,
    ptup_end_dt       varchar2(50),
    noti_use_yn       varchar2(1),
    poup_use_yn       varchar2(1),
    poup_st_dtm       TIMESTAMP,
    poup_end_dtm      TIMESTAMP,
    poup_eps_nuse_ddn numeric(7),
    bbm_clsf_cd       varchar2(50),
    ptup_tgt_cop_cd   varchar2(10),
    data_ins_user_id  varchar2(50),
    data_ins_user_ip  varchar2(40),
    data_ins_dtm      TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id  varchar2(50),
    data_upd_user_ip  varchar2(40),
    data_upd_dtm      TIMESTAMP default CURRENT_TIMESTAMP,
    prnt_re_bbs_no    varchar2(10),
    re_bbs_yn         varchar2(10)
);

comment on table tb_wsf_bbs_m is '게시판기본';

comment on column tb_wsf_bbs_m.bbs_no is '게시글번호';

comment on column tb_wsf_bbs_m.bbs_tp_cd is '게시판유형코드';

comment on column tb_wsf_bbs_m.bbs_sort_ord is '게시글정렬순서';

comment on column tb_wsf_bbs_m.bbs_title is '게시글제목명';

comment on column tb_wsf_bbs_m.bbs_ctn is '게시글내용';

comment on column tb_wsf_bbs_m.smry_ctn is '요약내용';

comment on column tb_wsf_bbs_m.atch_file_gr_id is '첨부파일그룹ID';

comment on column tb_wsf_bbs_m.htag_ctn is '해시태그내용';

comment on column tb_wsf_bbs_m.impt_yn is '중요여부';

comment on column tb_wsf_bbs_m.use_yn is '사용여부';

comment on column tb_wsf_bbs_m.bbs_vwct is '게시글조회수';

comment on column tb_wsf_bbs_m.ptup_end_dt is '게시종료일자';

comment on column tb_wsf_bbs_m.noti_use_yn is '공지사용여부';

comment on column tb_wsf_bbs_m.poup_use_yn is '팝업사용여부';

comment on column tb_wsf_bbs_m.poup_st_dtm is '팝업시작일시';

comment on column tb_wsf_bbs_m.poup_end_dtm is '팝업종료일시';

comment on column tb_wsf_bbs_m.poup_eps_nuse_ddn is '팝업노출미사용일수';

comment on column tb_wsf_bbs_m.bbm_clsf_cd is '게시글분류코드';

comment on column tb_wsf_bbs_m.ptup_tgt_cop_cd is '게시대상법인코드';

comment on column tb_wsf_bbs_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_bbs_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_bbs_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_bbs_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_bbs_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_bbs_m.data_upd_dtm is '데이터수정일시';

comment on column tb_wsf_bbs_m.prnt_re_bbs_no is '원게시글no';

comment on column tb_wsf_bbs_m.re_bbs_yn is '답글여부';

create index tb_wsf_bbs_m_ptup_end_dt_index
    on tb_wsf_bbs_m (ptup_end_dt);

create index tb_wsf_bbs_m_prnt_re_bbs_no_index
    on tb_wsf_bbs_m (prnt_re_bbs_no);

alter table tb_wsf_bbs_m
    add constraint tb_wsf_bbs_m_pk
        primary key (bbs_no);

create table tb_wsf_bbs_re_d
(
    bbs_no           varchar2(10) not null,
    bbs_re_no        varchar2(10) not null,
    bbs_re_ctn       varchar2(4000)        not null,
    del_yn           varchar2(1)  not null,
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    prnt_re_no       varchar2(10)
);

comment on table tb_wsf_bbs_re_d is '게시판댓글상세';

comment on column tb_wsf_bbs_re_d.bbs_no is '게시글번호';

comment on column tb_wsf_bbs_re_d.bbs_re_no is '게시글댓글번호';

comment on column tb_wsf_bbs_re_d.bbs_re_ctn is '게시글댓글내용';

comment on column tb_wsf_bbs_re_d.del_yn is '댓글삭제여부';

comment on column tb_wsf_bbs_re_d.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_bbs_re_d.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_bbs_re_d.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_bbs_re_d.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_bbs_re_d.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_bbs_re_d.data_upd_dtm is '데이터수정일시';

comment on column tb_wsf_bbs_re_d.prnt_re_no is '원댓글no';

create index tb_wsf_bbs_re_d_bbs_no_index
    on tb_wsf_bbs_re_d (bbs_no);

alter table tb_wsf_bbs_re_d
    add constraint tb_wsf_bbs_re_d_pk
        primary key (bbs_no, bbs_re_no);

create table tb_wsf_dt_m
(
    cop_cd           varchar2(10) not null,
    scal_dt          varchar2(8)  not null,
    scal_yy          varchar2(4),
    scal_mm          varchar2(2),
    scal_dd          varchar2(2),
    lcal_dt          varchar2(8),
    dywk_no_cd       varchar2(1),
    yywk             varchar2(6),
    mm_wct           numeric(3),
    hldy_yn          varchar2(1),
    hldy_nm          varchar2(30),
    opt_val_nm1      varchar2(100),
    opt_val_nm2      varchar2(100),
    opt_val_nm3      varchar2(100),
    opt_val_nm4      varchar2(100),
    opt_val_nm5      varchar2(100),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP
);

comment on table tb_wsf_dt_m is '날짜기본';

comment on column tb_wsf_dt_m.cop_cd is '법인코드';

comment on column tb_wsf_dt_m.scal_dt is '양력일자';

comment on column tb_wsf_dt_m.scal_yy is '양력년도';

comment on column tb_wsf_dt_m.scal_mm is '양력월';

comment on column tb_wsf_dt_m.scal_dd is '양력일';

comment on column tb_wsf_dt_m.lcal_dt is '음력일자';

comment on column tb_wsf_dt_m.dywk_no_cd is '요일번호코드';

comment on column tb_wsf_dt_m.yywk is '년주차수';

comment on column tb_wsf_dt_m.mm_wct is '월주차수';

comment on column tb_wsf_dt_m.hldy_yn is '휴일여부';

comment on column tb_wsf_dt_m.hldy_nm is '휴일명';

comment on column tb_wsf_dt_m.opt_val_nm1 is '옵션값명1';

comment on column tb_wsf_dt_m.opt_val_nm2 is '옵션값명2';

comment on column tb_wsf_dt_m.opt_val_nm3 is '옵션값명3';

comment on column tb_wsf_dt_m.opt_val_nm4 is '옵션값명4';

comment on column tb_wsf_dt_m.opt_val_nm5 is '옵션값명5';

comment on column tb_wsf_dt_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_dt_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_dt_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_dt_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_dt_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_dt_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_dt_m
    add constraint tb_wsf_dt_m_pk
        primary key (cop_cd, scal_dt);

create table tb_wsf_eml_sndo_log_m
(
    eml_sndo_seq     numeric(18)   not null,
    eml_log_seq      numeric(18)   not null,
    eml_tp_cd        varchar2(20),
    eml_tit_nm       varchar2(100),
    eml_rcvr_lst_ctn varchar2(4000) not null,
    sed_emal         varchar2(100)  not null,
    sed_dtm          TIMESTAMP     not null,
    eml_trnm_stat_cd varchar2(20),
    eml_trnm_rlt_ctn varchar2(200),
    eml_bdy_ctn      varchar2(4000),
    apr_req_id       varchar2(50),
    opt_val_nm1      varchar2(100),
    opt_val_nm2      varchar2(100),
    opt_val_nm3      varchar2(100),
    opt_val_nm4      varchar2(100),
    opt_val_nm5      varchar2(100),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP
);

comment on table tb_wsf_eml_sndo_log_m is '메일발송로그기본';

comment on column tb_wsf_eml_sndo_log_m.eml_sndo_seq is '이메일발송순번';

comment on column tb_wsf_eml_sndo_log_m.eml_log_seq is '이메일로그순번';

comment on column tb_wsf_eml_sndo_log_m.eml_tp_cd is '이메일유형코드';

comment on column tb_wsf_eml_sndo_log_m.eml_tit_nm is '이메일제목이름';

comment on column tb_wsf_eml_sndo_log_m.eml_rcvr_lst_ctn is '이메일수신자목록내용';

comment on column tb_wsf_eml_sndo_log_m.sed_emal is '발신이메일주소';

comment on column tb_wsf_eml_sndo_log_m.sed_dtm is '발신일시';

comment on column tb_wsf_eml_sndo_log_m.eml_trnm_stat_cd is '이메일전송상태코드';

comment on column tb_wsf_eml_sndo_log_m.eml_trnm_rlt_ctn is '이메일전송결과내용';

comment on column tb_wsf_eml_sndo_log_m.eml_bdy_ctn is '이메일본문내용';

comment on column tb_wsf_eml_sndo_log_m.apr_req_id is '결재요청ID';

comment on column tb_wsf_eml_sndo_log_m.opt_val_nm1 is '옵션값명1';

comment on column tb_wsf_eml_sndo_log_m.opt_val_nm2 is '옵션값명2';

comment on column tb_wsf_eml_sndo_log_m.opt_val_nm3 is '옵션값명3';

comment on column tb_wsf_eml_sndo_log_m.opt_val_nm4 is '옵션값명4';

comment on column tb_wsf_eml_sndo_log_m.opt_val_nm5 is '옵션값명5';

comment on column tb_wsf_eml_sndo_log_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_eml_sndo_log_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_eml_sndo_log_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_eml_sndo_log_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_eml_sndo_log_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_eml_sndo_log_m.data_upd_dtm is '데이터수정일시';

create index tb_wsf_eml_sndo_log_m_ix01
    on tb_wsf_eml_sndo_log_m (sed_dtm);

alter table tb_wsf_eml_sndo_log_m
    add constraint tb_wsf_eml_sndo_log_m_pk
        primary key (eml_sndo_seq, eml_log_seq);

create table tb_wsf_logn_log_m
(
    cont_log_id      varchar2(50)                         not null,
    cont_dtm         TIMESTAMP default CURRENT_TIMESTAMP not null,
    cont_user_id     varchar2(50)                         not null,
    cont_ip          varchar2(40),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP
);

comment on table tb_wsf_logn_log_m is '로그인로그';

comment on column tb_wsf_logn_log_m.cont_log_id is '접속로그ID';

comment on column tb_wsf_logn_log_m.cont_dtm is '접속일시';

comment on column tb_wsf_logn_log_m.cont_user_id is '접속사용자ID';

comment on column tb_wsf_logn_log_m.cont_ip is '접속IP주소';

comment on column tb_wsf_logn_log_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_logn_log_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_logn_log_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_logn_log_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_logn_log_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_logn_log_m.data_upd_dtm is '데이터수정일시';

create index tb_wsf_logn_log_m_ix01
    on tb_wsf_logn_log_m (cont_dtm);

alter table tb_wsf_logn_log_m
    add constraint tb_wsf_logn_log_m_pk
        primary key (cont_log_id);

create table tb_wsf_mnu_aces_log_m
(
    aces_log_id      varchar2(50)                         not null,
    mnu_id           varchar2(50)                         not null,
    cont_dtm         TIMESTAMP default CURRENT_TIMESTAMP not null,
    cont_user_id     varchar2(50),
    cont_ip          varchar2(40),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP
);

comment on table tb_wsf_mnu_aces_log_m is '메뉴접근로그';

comment on column tb_wsf_mnu_aces_log_m.aces_log_id is '접근로그ID';

comment on column tb_wsf_mnu_aces_log_m.mnu_id is '메뉴ID';

comment on column tb_wsf_mnu_aces_log_m.cont_dtm is '접속일시';

comment on column tb_wsf_mnu_aces_log_m.cont_user_id is '접속사용자ID';

comment on column tb_wsf_mnu_aces_log_m.cont_ip is '접속IP주소';

comment on column tb_wsf_mnu_aces_log_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_mnu_aces_log_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_mnu_aces_log_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_mnu_aces_log_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_mnu_aces_log_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_mnu_aces_log_m.data_upd_dtm is '데이터수정일시';

create index tb_wsf_mnu_aces_log_m_ix01
    on tb_wsf_mnu_aces_log_m (cont_dtm);

create index tb_wsf_mnu_aces_log_m_ix02
    on tb_wsf_mnu_aces_log_m (cont_user_id);

create index tb_wsf_mnu_aces_log_m_ix03
    on tb_wsf_mnu_aces_log_m (cont_ip);

alter table tb_wsf_mnu_aces_log_m
    add constraint tb_wsf_mnu_aces_log_m_pk
        primary key (aces_log_id);

create table tb_wsf_if_log_m
(
    if_log_seq       numeric(22) not null,
    if_log_dtm       TIMESTAMP   not null,
    if_nm            varchar2(300),
    if_divs_cd       varchar2(20),
    if_trmt_val_ctn  varchar2(4000),
    if_rest_val_ctn  varchar2(4000),
    opt_val_nm1      varchar2(100),
    opt_val_nm2      varchar2(100),
    opt_val_nm3      varchar2(100),
    opt_val_nm4      varchar2(100),
    opt_val_nm5      varchar2(100),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP
);

comment on table tb_wsf_if_log_m is '인터페이스로그기본';

comment on column tb_wsf_if_log_m.if_log_seq is '인터페이스로그순번';

comment on column tb_wsf_if_log_m.if_log_dtm is '인터페이스로그일시';

comment on column tb_wsf_if_log_m.if_nm is '인터페이스명';

comment on column tb_wsf_if_log_m.if_divs_cd is '인터페이스구분코드';

comment on column tb_wsf_if_log_m.if_trmt_val_ctn is '인터페이스송신값내용';

comment on column tb_wsf_if_log_m.if_rest_val_ctn is '인터페이스수신값내용';

comment on column tb_wsf_if_log_m.opt_val_nm1 is '옵션값명1';

comment on column tb_wsf_if_log_m.opt_val_nm2 is '옵션값명2';

comment on column tb_wsf_if_log_m.opt_val_nm3 is '옵션값명3';

comment on column tb_wsf_if_log_m.opt_val_nm4 is '옵션값명4';

comment on column tb_wsf_if_log_m.opt_val_nm5 is '옵션값명5';

comment on column tb_wsf_if_log_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_if_log_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_if_log_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_if_log_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_if_log_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_if_log_m.data_upd_dtm is '데이터수정일시';

create index tb_wsf_if_log_m_ix01
    on tb_wsf_if_log_m (if_log_dtm);

alter table tb_wsf_if_log_m
    add constraint tb_wsf_if_log_m_pk
        primary key (if_log_seq);

create table tb_wsf_eml_sndo_que_m
(
    eml_sndo_seq     numeric(18)   not null,
    eml_tp_cd        varchar2(20),
    eml_tit_nm       varchar2(1000) not null,
    eml_rcvr_lst_ctn varchar2(4000) not null,
    sed_emal         varchar2(100)  not null,
    eml_sed_user_nm  varchar2(100),
    sed_dtm          TIMESTAMP,
    eml_trnm_stat_cd varchar2(20),
    eml_trnm_rlt_ctn varchar2(200),
    eml_dtl_ctn      varchar2(4000),
    apr_req_id       varchar2(50),
    opt_val_nm1      varchar2(100),
    opt_val_nm2      varchar2(100),
    opt_val_nm3      varchar2(100),
    opt_val_nm4      varchar2(100),
    opt_val_nm5      varchar2(100),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP
);

comment on table tb_wsf_eml_sndo_que_m is '메일발송큐기본';

comment on column tb_wsf_eml_sndo_que_m.eml_sndo_seq is '이메일발송순번';

comment on column tb_wsf_eml_sndo_que_m.eml_tp_cd is '이메일유형코드';

comment on column tb_wsf_eml_sndo_que_m.eml_tit_nm is '이메일제목명';

comment on column tb_wsf_eml_sndo_que_m.eml_rcvr_lst_ctn is '이메일수신자목록내용';

comment on column tb_wsf_eml_sndo_que_m.sed_emal is '발신이메일주소';

comment on column tb_wsf_eml_sndo_que_m.eml_sed_user_nm is '이메일발신사용자명';

comment on column tb_wsf_eml_sndo_que_m.sed_dtm is '발신일시';

comment on column tb_wsf_eml_sndo_que_m.eml_trnm_stat_cd is '이메일전송상태코드';

comment on column tb_wsf_eml_sndo_que_m.eml_trnm_rlt_ctn is '이메일전송결과내용';

comment on column tb_wsf_eml_sndo_que_m.eml_dtl_ctn is '이메일상세내용';

comment on column tb_wsf_eml_sndo_que_m.apr_req_id is '결재요청ID';

comment on column tb_wsf_eml_sndo_que_m.opt_val_nm1 is '옵션값명1';

comment on column tb_wsf_eml_sndo_que_m.opt_val_nm2 is '옵션값명2';

comment on column tb_wsf_eml_sndo_que_m.opt_val_nm3 is '옵션값명3';

comment on column tb_wsf_eml_sndo_que_m.opt_val_nm4 is '옵션값명4';

comment on column tb_wsf_eml_sndo_que_m.opt_val_nm5 is '옵션값명5';

comment on column tb_wsf_eml_sndo_que_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_eml_sndo_que_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_eml_sndo_que_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_eml_sndo_que_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_eml_sndo_que_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_eml_sndo_que_m.data_upd_dtm is '데이터수정일시';

create index tb_wsf_eml_sndo_que_m_ix01
    on tb_wsf_eml_sndo_que_m (eml_trnm_rlt_ctn);

alter table tb_wsf_eml_sndo_que_m
    add constraint tb_wsf_eml_sndo_que_m_pk
        primary key (eml_sndo_seq);

create table tb_wsf_apr_dlgt_m
(
    apr_dlgt_no      numeric(20) not null,
    apr_dlgt_user_id varchar2(50) not null,
    apr_dele_user_id varchar2(50) not null,
    apr_dlgt_st_dt   varchar2(8)  not null,
    apr_dlgt_end_dt  varchar2(8)  not null,
    use_yn           varchar2(1)  not null,
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    apr_dlgt_emp_no  varchar2(50),
    apr_dele_emp_no  varchar2(50)
);

comment on table tb_wsf_apr_dlgt_m is '결재위임';

comment on column tb_wsf_apr_dlgt_m.apr_dlgt_no is '결재위임번호';

comment on column tb_wsf_apr_dlgt_m.apr_dlgt_user_id is '결재위임사용자ID';

comment on column tb_wsf_apr_dlgt_m.apr_dele_user_id is '결재수임사용자ID';

comment on column tb_wsf_apr_dlgt_m.apr_dlgt_st_dt is '결재위임시작일자';

comment on column tb_wsf_apr_dlgt_m.apr_dlgt_end_dt is '결재위임종료일자';

comment on column tb_wsf_apr_dlgt_m.use_yn is '사용여부';

comment on column tb_wsf_apr_dlgt_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_apr_dlgt_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_apr_dlgt_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_apr_dlgt_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_apr_dlgt_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_apr_dlgt_m.data_upd_dtm is '데이터수정일시';

comment on column tb_wsf_apr_dlgt_m.apr_dlgt_emp_no is '결재위임직원번호';

comment on column tb_wsf_apr_dlgt_m.apr_dele_emp_no is '결재수임직원no';

alter table tb_wsf_apr_dlgt_m
    add constraint tb_wsf_apr_dlgt_m_pk
        primary key (apr_dlgt_no);

create table v_returnval
(
    user_info varchar2(4000)
);

comment on table v_returnval is 'v_returnval';

create table tb_wsf_hr_dept_i
(
    seq_id              numeric(22),
    subsidiary_code     varchar2(2),
    organization_id     numeric(22),
    organization_name   varchar2(240),
    organization_code   varchar2(150),
    parent_org_id       numeric(15),
    parent_org_name     varchar2(240),
    parent_org_code     varchar2(150),
    supervisor_number   varchar2(30),
    supervisor_name     varchar2(300),
    biz_place_id        numeric(22),
    biz_place_name      varchar2(240),
    division_id         numeric(22),
    division_name       varchar2(240),
    organization_type   varchar2(50),
    date_from           varchar2(14),
    date_to             varchar2(14),
    sortcode            varchar2(50),
    organization_level  varchar2(5),
    organization_ename  varchar2(240),
    location            varchar2(50),
    use_flag            varchar2(1),
    business_group_id   varchar2(100),
    business_group_name varchar2(100),
    eai_data_crud_cd    varchar2(1),
    attribute1          varchar2(240),
    attribute2          varchar2(240),
    attribute3          varchar2(240),
    attribute4          varchar2(240),
    attribute5          varchar2(240),
    attribute6          varchar2(240),
    attribute7          varchar2(240),
    attribute8          varchar2(240),
    attribute9          varchar2(240),
    attribute10         varchar2(240),
    attribute11         varchar2(240),
    attribute12         varchar2(240),
    attribute13         varchar2(240),
    attribute14         varchar2(240),
    attribute15         varchar2(240),
    attribute16         varchar2(240),
    attribute17         varchar2(240),
    attribute18         varchar2(240),
    attribute19         varchar2(240),
    creation_date       varchar2(14),
    update_date         varchar2(14),
    transfer_date11     varchar2(14),
    transfer_flag11     varchar2(5),
    data_ins_dtm        TIMESTAMP not null,
    transfer_flag       varchar2(1),
    transfer_date       TIMESTAMP
);

comment on column tb_wsf_hr_dept_i.seq_id is '데이터 고유 식별자 (시퀀스 번호)';

comment on column tb_wsf_hr_dept_i.subsidiary_code is '자회사 코드 (Subsidiary 식별 코드)';

comment on column tb_wsf_hr_dept_i.organization_id is '조직 고유 ID (시스템 내부 식별용)';

comment on column tb_wsf_hr_dept_i.organization_name is '조직 이름 (예: 영업1팀)';

comment on column tb_wsf_hr_dept_i.organization_code is '조직 코드 (예: ORG001)';

comment on column tb_wsf_hr_dept_i.parent_org_id is '상위 조직 고유 ID';

comment on column tb_wsf_hr_dept_i.parent_org_name is '상위 조직 이름';

comment on column tb_wsf_hr_dept_i.parent_org_code is '상위 조직 코드';

comment on column tb_wsf_hr_dept_i.supervisor_number is '조직 책임자(상급자) 사번';

comment on column tb_wsf_hr_dept_i.supervisor_name is '조직 책임자(상급자) 이름';

comment on column tb_wsf_hr_dept_i.biz_place_id is '사업장 고유 ID';

comment on column tb_wsf_hr_dept_i.biz_place_name is '사업장 이름';

comment on column tb_wsf_hr_dept_i.division_id is '부서 또는 사업부 ID';

comment on column tb_wsf_hr_dept_i.division_name is '부서 또는 사업부 이름';

comment on column tb_wsf_hr_dept_i.organization_type is '조직 유형 (예: 부서, 팀, 본부)';

comment on column tb_wsf_hr_dept_i.date_from is '조직 유효 시작일';

comment on column tb_wsf_hr_dept_i.date_to is '조직 유효 종료일';

comment on column tb_wsf_hr_dept_i.sortcode is '조직 정렬 코드';

comment on column tb_wsf_hr_dept_i.organization_level is '조직 단계 (레벨)';

comment on column tb_wsf_hr_dept_i.organization_ename is '조직 영문 이름';

comment on column tb_wsf_hr_dept_i.location is '조직 위치 정보 (주소 또는 지역명)';

comment on column tb_wsf_hr_dept_i.use_flag is '사용 여부 플래그 (Y=사용, N=미사용)';

comment on column tb_wsf_hr_dept_i.business_group_id is '비즈니스 그룹 ID';

comment on column tb_wsf_hr_dept_i.business_group_name is '비즈니스 그룹 이름';

comment on column tb_wsf_hr_dept_i.eai_data_crud_cd is 'EAI 연동 데이터 CRUD 코드 (C=생성, U=수정, D=삭제)';

comment on column tb_wsf_hr_dept_i.attribute1 is '확장 속성 1';

comment on column tb_wsf_hr_dept_i.attribute2 is '확장 속성 2';

comment on column tb_wsf_hr_dept_i.attribute3 is '확장 속성 3';

comment on column tb_wsf_hr_dept_i.attribute4 is '확장 속성 4';

comment on column tb_wsf_hr_dept_i.attribute5 is '확장 속성 5';

comment on column tb_wsf_hr_dept_i.attribute6 is '확장 속성 6';

comment on column tb_wsf_hr_dept_i.attribute7 is '확장 속성 7';

comment on column tb_wsf_hr_dept_i.attribute8 is '확장 속성 8';

comment on column tb_wsf_hr_dept_i.attribute9 is '확장 속성 9';

comment on column tb_wsf_hr_dept_i.attribute10 is '확장 속성 10';

comment on column tb_wsf_hr_dept_i.attribute11 is '확장 속성 11';

comment on column tb_wsf_hr_dept_i.attribute12 is '확장 속성 12';

comment on column tb_wsf_hr_dept_i.attribute13 is '확장 속성 13';

comment on column tb_wsf_hr_dept_i.attribute14 is '확장 속성 14';

comment on column tb_wsf_hr_dept_i.attribute15 is '확장 속성 15';

comment on column tb_wsf_hr_dept_i.attribute16 is '확장 속성 16';

comment on column tb_wsf_hr_dept_i.attribute17 is '확장 속성 17';

comment on column tb_wsf_hr_dept_i.attribute18 is '확장 속성 18';

comment on column tb_wsf_hr_dept_i.attribute19 is '확장 속성 19';

comment on column tb_wsf_hr_dept_i.creation_date is '데이터 생성 일시';

comment on column tb_wsf_hr_dept_i.update_date is '데이터 최종 수정 일시';

comment on column tb_wsf_hr_dept_i.transfer_date11 is '데이터 이관 일시 (특정 시스템 연동)';

comment on column tb_wsf_hr_dept_i.transfer_flag11 is '데이터 이관 여부 플래그 (Y/N, 특정 시스템 연동)';

comment on column tb_wsf_hr_dept_i.data_ins_dtm is '데이터 입력 일시 (Insert Datetime)';

comment on column tb_wsf_hr_dept_i.transfer_flag is '데이터 전송 완료 여부 플래그 (Y/N)';

comment on column tb_wsf_hr_dept_i.transfer_date is '데이터 전송 완료 일시';

create table tb_wsf_sso_auth_i
(
    eai_row_id         numeric(20),
    syscd              varchar2(50),
    user_id            varchar2(100),
    auth_lev_1         varchar2(100),
    auth_lev_2         varchar2(100),
    auth_lev_3         varchar2(100),
    auth_lev_4         varchar2(100),
    auth_lev_5         varchar2(100),
    attribute2         varchar2(100),
    attribute3         varchar2(100),
    attribute4         varchar2(100),
    attribute5         varchar2(100),
    creation_date      varchar2(14),
    eai_transfer_date5 varchar2(14),
    eai_transfer_flag5 varchar2(1),
    data_ins_dtm       TIMESTAMP not null,
    attribute1         varchar2(100),
    transfer_flag      varchar2(1),
    transfer_date      TIMESTAMP
);

comment on table tb_wsf_sso_auth_i is 'SSO 사용자 권한 인증 테이블';

comment on column tb_wsf_sso_auth_i.eai_row_id is 'EAI 연동용 데이터 고유 식별자';

comment on column tb_wsf_sso_auth_i.syscd is '시스템 코드';

comment on column tb_wsf_sso_auth_i.user_id is '사용자 ID';

comment on column tb_wsf_sso_auth_i.auth_lev_1 is '권한 레벨 1';

comment on column tb_wsf_sso_auth_i.auth_lev_2 is '권한 레벨 2';

comment on column tb_wsf_sso_auth_i.auth_lev_3 is '권한 레벨 3';

comment on column tb_wsf_sso_auth_i.auth_lev_4 is '권한 레벨 4';

comment on column tb_wsf_sso_auth_i.auth_lev_5 is '권한 레벨 5';

comment on column tb_wsf_sso_auth_i.attribute2 is '확장 속성 2';

comment on column tb_wsf_sso_auth_i.attribute3 is '확장 속성 3';

comment on column tb_wsf_sso_auth_i.attribute4 is '확장 속성 4';

comment on column tb_wsf_sso_auth_i.attribute5 is '확장 속성 5';

comment on column tb_wsf_sso_auth_i.creation_date is '데이터 생성 일시';

comment on column tb_wsf_sso_auth_i.eai_transfer_date5 is 'EAI 연동 전송 일시 (5차 전송)';

comment on column tb_wsf_sso_auth_i.eai_transfer_flag5 is 'EAI 연동 전송 여부 플래그 (5차 전송, Y/N)';

comment on column tb_wsf_sso_auth_i.data_ins_dtm is '데이터 입력 일시 (Insert Datetime)';

comment on column tb_wsf_sso_auth_i.attribute1 is '확장 속성 1';

comment on column tb_wsf_sso_auth_i.transfer_flag is '데이터 전송 완료 여부 (Y/N)';

comment on column tb_wsf_sso_auth_i.transfer_date is '데이터 전송 완료 일시';

create table tb_wsf_apr_col_dlg_i
(
    eai_row_id       numeric(22),
    eai_create_date  varchar2(14),
    eai_data_crud_cd varchar2(1),
    syscd            varchar2(50),
    auth_lev_1       varchar2(100),
    auth_lev_2       varchar2(100),
    empno_from       varchar2(20),
    empno_to         varchar2(20),
    date_from        varchar2(14),
    date_to          varchar2(14),
    current_use      varchar2(1),
    last_update_id   varchar2(50),
    last_update_date varchar2(14),
    data_ins_dtm     TIMESTAMP not null,
    transfer_flag    varchar2(1),
    transfer_date    TIMESTAMP
);

comment on column tb_wsf_apr_col_dlg_i.eai_row_id is 'EAI 행 ID';

comment on column tb_wsf_apr_col_dlg_i.eai_create_date is '생성일자';

comment on column tb_wsf_apr_col_dlg_i.eai_data_crud_cd is 'CRUD코드';

comment on column tb_wsf_apr_col_dlg_i.syscd is '시스템 코드';

comment on column tb_wsf_apr_col_dlg_i.auth_lev_1 is '인증 레벨 1';

comment on column tb_wsf_apr_col_dlg_i.auth_lev_2 is '인증 레벨 2';

comment on column tb_wsf_apr_col_dlg_i.empno_from is '직원no FROM';

comment on column tb_wsf_apr_col_dlg_i.empno_to is '직원no TO';

comment on column tb_wsf_apr_col_dlg_i.date_from is '날짜 from';

comment on column tb_wsf_apr_col_dlg_i.date_to is '날짜 to';

comment on column tb_wsf_apr_col_dlg_i.current_use is '현재 사용';

comment on column tb_wsf_apr_col_dlg_i.last_update_id is '마지막 수정ID';

comment on column tb_wsf_apr_col_dlg_i.last_update_date is '마지막 수정 날짜';

comment on column tb_wsf_apr_col_dlg_i.data_ins_dtm is '데이터 입력 날짜';

comment on column tb_wsf_apr_col_dlg_i.transfer_flag is '변환 flag';

comment on column tb_wsf_apr_col_dlg_i.transfer_date is '변환 날짜';

create table tb_wsf_hr_emp_i
(
    seq_id                    numeric(20),
    subsidiary_code           varchar2(2),
    employee_number           varchar(4000) not null,
    effective_start_date      varchar2(14),
    effective_end_date        varchar2(14),
    assignment_status_type_id numeric(9),
    full_name                 varchar(4000),
    email_address             varchar(4000),
    jikgun                    varchar(4000),
    sso_user_id               varchar(4000),
    mail_action_update        varchar2(14),
    original_date_of_hire     varchar2(14),
    date_of_hire              varchar2(14),
    position_code             varchar2(4000),
    position_name             varchar2(4000),
    job_title_code            varchar2(4000),
    job_title_name            varchar2(4000),
    grade_title_code          varchar2(4000),
    grade_title               varchar2(4000),
    person_type               varchar2(4000),
    date_of_suspend           varchar2(14),
    date_of_retire            varchar2(14),
    person_id                 numeric(10),
    organization_id           numeric(15),
    organization_code         varchar2(4000),
    organization_name         varchar2(4000),
    parent_org_id             numeric(15),
    parent_org_code           varchar2(4000),
    parent_org_name           varchar2(4000),
    division_id               numeric(15),
    division_name             varchar2(4000),
    jojik_manager             varchar2(4000),
    org_manager               varchar2(4000),
    business_place_id         numeric(15),
    business_place_name       varchar2(4000),
    chinese_name              varchar2(4000),
    eng_name                  varchar2(4000),
    telephone_number_1        varchar2(4000),
    telephone_number_2        varchar2(4000),
    telephone_number_3        varchar2(4000),
    date_of_marry             varchar2(14),
    date_of_birth             varchar2(14),
    ls_type                   varchar2(4000),
    marital_status            varchar2(4000),
    self_approve_flag         varchar2(1),
    external_email            varchar2(4000),
    user_person_type          varchar2(4000),
    employee_category         varchar2(4000),
    establishment_id          numeric(15),
    establishment_name        varchar2(4000),
    postal_code               varchar2(4000),
    address_line1             varchar2(4000),
    address_line2             varchar2(4000),
    location_name             varchar2(4000),
    cost_biz                  varchar2(4000),
    cost_org                  varchar2(4000),
    cost_gubun                varchar2(4000),
    sso_password              varchar2(4000),
    fse_foreignsabun          varchar2(10),
    other_action              varchar2(4000),
    sso_action                varchar2(1),
    other_start_date          varchar2(14),
    other_end_date            varchar2(14),
    original_company          varchar2(4000),
    ehr_insert_flag           varchar2(1),
    fse_flag                  varchar2(1),
    fax_telephone_number_1    varchar2(4000),
    nickname                  varchar2(4000),
    person_sosrtcode          varchar2(4000),
    organization_nick_code    varchar2(4000),
    organization_nick_name    varchar2(4000),
    imsg_action_date          varchar2(14),
    attribute1                varchar2(4000),
    attribute2                varchar2(4000),
    attribute3                varchar2(4000),
    attribute4                varchar2(4000),
    attribute5                varchar2(4000),
    attribute6                varchar2(4000),
    attribute7                varchar2(4000),
    attribute8                varchar2(4000),
    attribute9                varchar2(4000),
    attribute10               varchar2(4000),
    attribute11               varchar2(4000),
    attribute12               varchar2(4000),
    attribute13               varchar2(4000),
    attribute14               varchar2(4000),
    attribute15               varchar2(4000),
    attribute16               varchar2(4000),
    attribute17               varchar2(4000),
    attribute18               varchar2(4000),
    attribute19               varchar2(4000),
    attribute20               varchar2(4000),
    creation_date             varchar2(14),
    last_update_date          varchar2(14),
    transfer_flag11           varchar2(1),
    transfer_date11           varchar2(14),
    transfer_date             TIMESTAMP,
    transfer_flag             varchar2(1),
    data_ins_dtm              TIMESTAMP,
    attribute24               varchar2(4000)
);

comment on column tb_wsf_hr_emp_i.seq_id is '데이터 고유 식별자 (시퀀스 번호)';

comment on column tb_wsf_hr_emp_i.subsidiary_code is '자회사 코드';

comment on column tb_wsf_hr_emp_i.employee_number is '사원 번호';

comment on column tb_wsf_hr_emp_i.effective_start_date is '데이터 유효 시작일';

comment on column tb_wsf_hr_emp_i.effective_end_date is '데이터 유효 종료일';

comment on column tb_wsf_hr_emp_i.assignment_status_type_id is '근무 상태 구분 ID';

comment on column tb_wsf_hr_emp_i.full_name is '사원 전체 이름';

comment on column tb_wsf_hr_emp_i.email_address is '사내 이메일 주소';

comment on column tb_wsf_hr_emp_i.jikgun is '직군';

comment on column tb_wsf_hr_emp_i.sso_user_id is 'SSO 사용자 ID';

comment on column tb_wsf_hr_emp_i.mail_action_update is '메일 변경 액션';

comment on column tb_wsf_hr_emp_i.original_date_of_hire is '최초 입사일';

comment on column tb_wsf_hr_emp_i.date_of_hire is '현재 입사일';

comment on column tb_wsf_hr_emp_i.position_code is '포지션 코드';

comment on column tb_wsf_hr_emp_i.position_name is '포지션 이름';

comment on column tb_wsf_hr_emp_i.job_title_code is '직책 코드';

comment on column tb_wsf_hr_emp_i.job_title_name is '직책 이름';

comment on column tb_wsf_hr_emp_i.grade_title_code is '직급 코드';

comment on column tb_wsf_hr_emp_i.grade_title is '직급 명칭';

comment on column tb_wsf_hr_emp_i.person_type is '인사 유형 (예: 정규직, 계약직)';

comment on column tb_wsf_hr_emp_i.date_of_suspend is '휴직 시작일';

comment on column tb_wsf_hr_emp_i.date_of_retire is '퇴직일';

comment on column tb_wsf_hr_emp_i.person_id is '사원 고유 ID';

comment on column tb_wsf_hr_emp_i.organization_id is '조직 ID';

comment on column tb_wsf_hr_emp_i.organization_code is '조직 코드';

comment on column tb_wsf_hr_emp_i.organization_name is '조직 이름';

comment on column tb_wsf_hr_emp_i.parent_org_id is '상위 조직 ID';

comment on column tb_wsf_hr_emp_i.parent_org_code is '상위 조직 코드';

comment on column tb_wsf_hr_emp_i.parent_org_name is '상위 조직 이름';

comment on column tb_wsf_hr_emp_i.division_id is '사업부 ID';

comment on column tb_wsf_hr_emp_i.division_name is '사업부 이름';

comment on column tb_wsf_hr_emp_i.jojik_manager is '조직 매니저 여부';

comment on column tb_wsf_hr_emp_i.org_manager is '조직장 여부';

comment on column tb_wsf_hr_emp_i.business_place_id is '사업장 ID';

comment on column tb_wsf_hr_emp_i.business_place_name is '사업장 이름';

comment on column tb_wsf_hr_emp_i.chinese_name is '중국어 이름';

comment on column tb_wsf_hr_emp_i.eng_name is '영문 이름';

comment on column tb_wsf_hr_emp_i.telephone_number_1 is '전화번호 1';

comment on column tb_wsf_hr_emp_i.telephone_number_2 is '전화번호 2';

comment on column tb_wsf_hr_emp_i.telephone_number_3 is '전화번호 3';

comment on column tb_wsf_hr_emp_i.date_of_marry is '결혼일자';

comment on column tb_wsf_hr_emp_i.date_of_birth is '생년월일';

comment on column tb_wsf_hr_emp_i.ls_type is '고용 형태 구분 (LS 유형)';

comment on column tb_wsf_hr_emp_i.marital_status is '결혼 상태';

comment on column tb_wsf_hr_emp_i.self_approve_flag is '자기 승인 가능 여부';

comment on column tb_wsf_hr_emp_i.external_email is '외부 이메일 주소';

comment on column tb_wsf_hr_emp_i.user_person_type is '사용자 인사 유형';

comment on column tb_wsf_hr_emp_i.employee_category is '사원 분류';

comment on column tb_wsf_hr_emp_i.establishment_id is '법인 ID';

comment on column tb_wsf_hr_emp_i.establishment_name is '법인 이름';

comment on column tb_wsf_hr_emp_i.postal_code is '우편번호';

comment on column tb_wsf_hr_emp_i.address_line1 is '주소 1';

comment on column tb_wsf_hr_emp_i.address_line2 is '주소 2';

comment on column tb_wsf_hr_emp_i.location_name is '근무 위치명';

comment on column tb_wsf_hr_emp_i.cost_biz is '비용 사업 구분';

comment on column tb_wsf_hr_emp_i.cost_org is '비용 조직 구분';

comment on column tb_wsf_hr_emp_i.cost_gubun is '비용 구분';

comment on column tb_wsf_hr_emp_i.sso_password is 'SSO 비밀번호';

comment on column tb_wsf_hr_emp_i.fse_foreignsabun is '외국인 사번 (FSE용)';

comment on column tb_wsf_hr_emp_i.other_action is '기타 작업 정보';

comment on column tb_wsf_hr_emp_i.sso_action is 'SSO 작업 구분';

comment on column tb_wsf_hr_emp_i.other_start_date is '기타 작업 시작일';

comment on column tb_wsf_hr_emp_i.other_end_date is '기타 작업 종료일';

comment on column tb_wsf_hr_emp_i.original_company is '최초 소속 회사';

comment on column tb_wsf_hr_emp_i.ehr_insert_flag is 'EHR 데이터 입력 여부';

comment on column tb_wsf_hr_emp_i.fse_flag is 'FSE 구분 플래그';

comment on column tb_wsf_hr_emp_i.fax_telephone_number_1 is '팩스 번호';

comment on column tb_wsf_hr_emp_i.nickname is '별명';

comment on column tb_wsf_hr_emp_i.person_sosrtcode is '사원 정렬 코드';

comment on column tb_wsf_hr_emp_i.organization_nick_code is '조직 별칭 코드';

comment on column tb_wsf_hr_emp_i.organization_nick_name is '조직 별칭 이름';

comment on column tb_wsf_hr_emp_i.imsg_action_date is 'IMSG 액션 일자';

comment on column tb_wsf_hr_emp_i.attribute1 is '확장 속성 1';

comment on column tb_wsf_hr_emp_i.attribute2 is '확장 속성 2';

comment on column tb_wsf_hr_emp_i.attribute3 is '확장 속성 3';

comment on column tb_wsf_hr_emp_i.attribute4 is '확장 속성 4';

comment on column tb_wsf_hr_emp_i.attribute5 is '확장 속성 5';

comment on column tb_wsf_hr_emp_i.attribute6 is '확장 속성 6';

comment on column tb_wsf_hr_emp_i.attribute7 is '확장 속성 7';

comment on column tb_wsf_hr_emp_i.attribute8 is '확장 속성 8';

comment on column tb_wsf_hr_emp_i.attribute9 is '확장 속성 9';

comment on column tb_wsf_hr_emp_i.attribute10 is '확장 속성 10';

comment on column tb_wsf_hr_emp_i.attribute11 is '확장 속성 11';

comment on column tb_wsf_hr_emp_i.attribute12 is '확장 속성 12';

comment on column tb_wsf_hr_emp_i.attribute13 is '확장 속성 13';

comment on column tb_wsf_hr_emp_i.attribute14 is '확장 속성 14';

comment on column tb_wsf_hr_emp_i.attribute15 is '확장 속성 15';

comment on column tb_wsf_hr_emp_i.attribute16 is '확장 속성 16';

comment on column tb_wsf_hr_emp_i.attribute17 is '확장 속성 17';

comment on column tb_wsf_hr_emp_i.attribute18 is '확장 속성 18';

comment on column tb_wsf_hr_emp_i.attribute19 is '확장 속성 19';

comment on column tb_wsf_hr_emp_i.attribute20 is '확장 속성 20';

comment on column tb_wsf_hr_emp_i.creation_date is '데이터 생성 일시';

comment on column tb_wsf_hr_emp_i.last_update_date is '데이터 최종 수정 일시';

comment on column tb_wsf_hr_emp_i.transfer_flag11 is '데이터 이관 여부 플래그 (특정 시스템용)';

comment on column tb_wsf_hr_emp_i.transfer_date11 is '데이터 이관 일시 (특정 시스템용)';

comment on column tb_wsf_hr_emp_i.transfer_date is '데이터 전송 완료 일시';

comment on column tb_wsf_hr_emp_i.transfer_flag is '데이터 전송 완료 여부 (Y/N)';

comment on column tb_wsf_hr_emp_i.data_ins_dtm is '데이터 입력 일시 (Insert Datetime)';

comment on column tb_wsf_hr_emp_i.attribute24 is '확장 속성 24';

create table tb_wsf_dept_m
(
    dept_cd          varchar2(20) not null,
    cop_cd           varchar2(10) not null,
    dept_gr_cd       varchar2(50),
    uppr_dept_gr_cd  varchar2(50),
    dept_nm          varchar2(300),
    dept_eng_nm      varchar2(300),
    dept_cng_nm      varchar2(300),
    tem_ldr_user_id  varchar2(50),
    uppr_dept_cd     varchar2(20),
    use_yn           varchar2(1),
    sortcode         varchar2(30),
    dept_lv          varchar2(5),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    dept_type        varchar2(50),
    org_id           numeric(15),
    uppr_org_id      numeric(15)
);

comment on table tb_wsf_dept_m is '부서관리';

comment on column tb_wsf_dept_m.dept_cd is '부서코드';

comment on column tb_wsf_dept_m.cop_cd is '회사코드';

comment on column tb_wsf_dept_m.dept_gr_cd is '부서그룹코드';

comment on column tb_wsf_dept_m.uppr_dept_gr_cd is '상위부서그룹코드';

comment on column tb_wsf_dept_m.dept_nm is '부서이름';

comment on column tb_wsf_dept_m.dept_eng_nm is '부서영어이름';

comment on column tb_wsf_dept_m.dept_cng_nm is '부서중국이름';

comment on column tb_wsf_dept_m.tem_ldr_user_id is '리더사용자ID';

comment on column tb_wsf_dept_m.uppr_dept_cd is '상위부서코드';

comment on column tb_wsf_dept_m.use_yn is '사용여부';

comment on column tb_wsf_dept_m.sortcode is '정렬코드';

comment on column tb_wsf_dept_m.dept_lv is '부서레벨';

comment on column tb_wsf_dept_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_dept_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_dept_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_dept_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_dept_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_dept_m.data_upd_dtm is '데이터수정일시';

comment on column tb_wsf_dept_m.dept_type is '부서유형';

comment on column tb_wsf_dept_m.org_id is '조직ID';

comment on column tb_wsf_dept_m.uppr_org_id is '상위조직ID';

create table tb_wsf_emp_m
(
    user_id          varchar2(50) not null,
    emp_no           varchar2(30) not null,
    emp_nm           varchar2(50),
    emp_eng_nm       varchar2(100),
    emp_cng_nm       varchar2(100),
    dept_cd          varchar2(30),
    dept_nm          varchar2(300),
    dept_eng_nm      varchar2(300),
    dept_cng_nm      varchar2(300),
    cop_cd           varchar2(30),
    jti_cd           varchar2(30),
    jti_nm           varchar2(200),
    jti_eng_nm       varchar2(50),
    jti_cng_nm       varchar2(50),
    jps_cd           varchar2(30),
    jps_nm           varchar2(200),
    jps_eng_nm       varchar2(50),
    jps_cng_nm       varchar2(50),
    ino_stat_cd      varchar2(30),
    jcom_dt          varchar2(14),
    rsgn_dt          varchar2(14),
    uppr_emp_no      varchar2(30),
    ondu_regn_cd     varchar2(50),
    ondu_regn_nm     varchar2(50),
    sso_dtpl_nm      varchar2(100),
    hme_tano         varchar2(30),
    hme_phn          varchar2(50),
    ofc_tano         varchar2(30),
    ofc_phn          varchar2(50),
    ofc_etn_phn      varchar2(50),
    doc_auth_cd      varchar2(30),
    ino_divs_cd      varchar2(30),
    emp_hphn         varchar2(50),
    old_dept_cd      varchar2(30),
    old_emp_no       varchar2(30),
    dept_eng_desc    varchar2(100),
    emp_lowr_gr_cd   varchar2(50),
    emp_uppr_gr_cd   varchar2(50),
    eml_dmn_ifo_nm   varchar2(200),
    sso_dtpl_cd      varchar2(50),
    sso_emp_cng_nm   varchar2(100),
    ctry_cd          varchar2(30),
    sso_chg_tp_cd    varchar2(50),
    sso_chg_dt       varchar2(8),
    use_yn           varchar2(1),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    dept_gr_cd       varchar2(30),
    org_id           varchar2(50),
    login_wrong_cnt  varchar2(50)
);

comment on table tb_wsf_emp_m is '직원정보';

comment on column tb_wsf_emp_m.user_id is '사용자ID';

comment on column tb_wsf_emp_m.emp_no is '사용자no';

comment on column tb_wsf_emp_m.emp_nm is '사용자이름';

comment on column tb_wsf_emp_m.emp_eng_nm is '사용자영어이름';

comment on column tb_wsf_emp_m.emp_cng_nm is '사용자중국어이름';

comment on column tb_wsf_emp_m.dept_cd is '부서코드';

comment on column tb_wsf_emp_m.dept_nm is '부서이름';

comment on column tb_wsf_emp_m.dept_eng_nm is '부서영어이름';

comment on column tb_wsf_emp_m.dept_cng_nm is '부서중국어이름';

comment on column tb_wsf_emp_m.cop_cd is '회사코드';

comment on column tb_wsf_emp_m.jti_cd is '직위코드';

comment on column tb_wsf_emp_m.jti_nm is '직위이름';

comment on column tb_wsf_emp_m.jti_eng_nm is '직위영어이름';

comment on column tb_wsf_emp_m.jti_cng_nm is '직위중국어이름';

comment on column tb_wsf_emp_m.jps_cd is '직책코드';

comment on column tb_wsf_emp_m.jps_nm is '직책이름';

comment on column tb_wsf_emp_m.jps_eng_nm is '직책영어이름';

comment on column tb_wsf_emp_m.jps_cng_nm is '직책중국어이름';

comment on column tb_wsf_emp_m.ino_stat_cd is 'ino_stat_cd';

comment on column tb_wsf_emp_m.jcom_dt is 'jcom_dt';

comment on column tb_wsf_emp_m.rsgn_dt is 'rsgn_dt';

comment on column tb_wsf_emp_m.uppr_emp_no is '상위직원no';

comment on column tb_wsf_emp_m.ondu_regn_cd is 'ondu_regn_cd';

comment on column tb_wsf_emp_m.ondu_regn_nm is 'ondu_regn_nm';

comment on column tb_wsf_emp_m.sso_dtpl_nm is 'sso_dtpl_nm';

comment on column tb_wsf_emp_m.hme_tano is '집택스no';

comment on column tb_wsf_emp_m.hme_phn is '집전화번호';

comment on column tb_wsf_emp_m.ofc_tano is '사무실택스no';

comment on column tb_wsf_emp_m.ofc_phn is '사무실전화번호';

comment on column tb_wsf_emp_m.ofc_etn_phn is '사무실내선전화번호';

comment on column tb_wsf_emp_m.doc_auth_cd is '문서인증코드';

comment on column tb_wsf_emp_m.ino_divs_cd is 'ino_divs_cd';

comment on column tb_wsf_emp_m.emp_hphn is '직원핸드폰번호';

comment on column tb_wsf_emp_m.old_dept_cd is 'old_dept_cd';

comment on column tb_wsf_emp_m.old_emp_no is 'old_emp_no';

comment on column tb_wsf_emp_m.dept_eng_desc is '부서영어설명';

comment on column tb_wsf_emp_m.emp_lowr_gr_cd is '하위직원그룹코드';

comment on column tb_wsf_emp_m.emp_uppr_gr_cd is '상위직원그룹코드';

comment on column tb_wsf_emp_m.eml_dmn_ifo_nm is 'eml_dmn_ifo_nm';

comment on column tb_wsf_emp_m.sso_dtpl_cd is 'sso_dtpl_cd';

comment on column tb_wsf_emp_m.sso_emp_cng_nm is 'sso직원중국어이름';

comment on column tb_wsf_emp_m.ctry_cd is '나라코드';

comment on column tb_wsf_emp_m.sso_chg_tp_cd is 'sso_chg_tp_cd';

comment on column tb_wsf_emp_m.sso_chg_dt is 'sso_chg_dt';

comment on column tb_wsf_emp_m.use_yn is '사용여부';

comment on column tb_wsf_emp_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_emp_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_emp_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_emp_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_emp_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_emp_m.data_upd_dtm is '데이터수정일시';

comment on column tb_wsf_emp_m.dept_gr_cd is '부서그룹코드';

comment on column tb_wsf_emp_m.org_id is '조직ID';

comment on column tb_wsf_emp_m.login_wrong_cnt is '로그인실패횟수(미사용)';

alter table tb_wsf_emp_m
    add constraint tb_wsf_emp_m_pk
        primary key (emp_no);

alter table tb_wsf_emp_m
    add constraint tb_wsf_emp_m_pk_2
        unique (user_id);

create table tb_wsf_btch_log_m
(
    btch_log_seq     numeric(22) not null,
    btch_log_dtm     TIMESTAMP   not null,
    btch_cls_nm      varchar2(300),
    btch_mthd_nm     varchar2(100),
    btch_crn         varchar2(50),
    btch_rslt        varchar2(4000),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP
);

comment on table tb_wsf_btch_log_m is '배치로그기본';

comment on column tb_wsf_btch_log_m.btch_log_seq is '배치로그순번';

comment on column tb_wsf_btch_log_m.btch_log_dtm is '배치로그일시';

comment on column tb_wsf_btch_log_m.btch_cls_nm is '배치클래스명';

comment on column tb_wsf_btch_log_m.btch_mthd_nm is '배치메소드명';

comment on column tb_wsf_btch_log_m.btch_crn is '배치크론식';

comment on column tb_wsf_btch_log_m.btch_rslt is '배치결과';

comment on column tb_wsf_btch_log_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_btch_log_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_btch_log_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_btch_log_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_btch_log_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_btch_log_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_btch_log_m
    add constraint tb_wsf_btch_log_m_pk
        primary key (btch_log_seq);

create table tb_wsf_apr_ln_m
(
    req_no           varchar2(50) not null,
    appr_ln_seq      numeric(18) not null,
    next_appr_seq    numeric(18),
    next_appr_type   varchar2(1),
    next_appr_emp_no varchar2(27),
    prl_yn           varchar2(1),
    appr_status      varchar2(1),
    appr_message     varchar2(1000),
    appr_date        TIMESTAMP,
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    dlgt_emp_no      varchar2(27)
);

comment on table tb_wsf_apr_ln_m is '결재라인기본';

comment on column tb_wsf_apr_ln_m.req_no is '결재요청번호';

comment on column tb_wsf_apr_ln_m.appr_ln_seq is '결재라인차수';

comment on column tb_wsf_apr_ln_m.next_appr_seq is '결재선 순번(병렬일 때 같은 값을 가짐)';

comment on column tb_wsf_apr_ln_m.next_appr_type is '결재타입';

comment on column tb_wsf_apr_ln_m.next_appr_emp_no is '결재자사번(결재수임자)';

comment on column tb_wsf_apr_ln_m.prl_yn is '병렬여부';

comment on column tb_wsf_apr_ln_m.appr_status is '결재 상태';

comment on column tb_wsf_apr_ln_m.appr_message is '결재의견';

comment on column tb_wsf_apr_ln_m.appr_date is '결재처리일';

comment on column tb_wsf_apr_ln_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_apr_ln_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_apr_ln_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_apr_ln_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_apr_ln_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_apr_ln_m.data_upd_dtm is '데이터수정일시';

comment on column tb_wsf_apr_ln_m.dlgt_emp_no is '결재위임자 사번';

alter table tb_wsf_apr_ln_m
    add constraint tb_wsf_apr_ln_test_m_pk
        primary key (req_no, appr_ln_seq);

create table tb_wsf_apr_req_m
(
    req_no               varchar2(27) not null,
    system_id            varchar2(27),
    form_id              varchar2(27),
    req_emp_no           varchar2(27),
    appr_title           varchar2(200),
    body_html            CLOB,
    form_editor_data     varchar2(4000),
    appr_security_type   varchar2(10),
    appr_line_type       varchar2(10),
    appr_period_cd       varchar2(27),
    file_link_name       varchar2(4000),
    file_link_url        varchar2(4000),
    file_size            varchar2(4000),
    read_user            varchar2(4000),
    read_dept            varchar2(4000),
    reference_id         varchar2(4000),
    form_data            varchar2(4000),
    appkey02             varchar2(50),
    appkey03             varchar2(50),
    relevant_depts       varchar2(4000),
    review_comments      varchar2(300),
    opt_val_ctn1         varchar2(4000),
    opt_val_ctn2         varchar2(4000),
    opt_val_ctn3         varchar2(4000),
    opt_val_ctn4         varchar2(4000),
    opt_val_ctn5         varchar2(4000),
    data_ins_user_id     varchar2(50),
    data_ins_user_ip     varchar2(40),
    data_ins_dtm         TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id     varchar2(50),
    data_upd_user_ip     varchar2(40),
    data_upd_dtm         TIMESTAMP default CURRENT_TIMESTAMP,
    apr_req_prog_stat_cd varchar2(10)
);

comment on table tb_wsf_apr_req_m is '결재 요청 기본';

comment on column tb_wsf_apr_req_m.req_no is '결재요청번호';

comment on column tb_wsf_apr_req_m.system_id is 'Legacy 시스템 ID';

comment on column tb_wsf_apr_req_m.form_id is '양식 ID';

comment on column tb_wsf_apr_req_m.req_emp_no is '요청자 사번';

comment on column tb_wsf_apr_req_m.appr_title is '결재문저 세목';

comment on column tb_wsf_apr_req_m.body_html is '모바일 본문내용';

comment on column tb_wsf_apr_req_m.form_editor_data is '웹 본문내용';

comment on column tb_wsf_apr_req_m.appr_security_type is '문서종류';

comment on column tb_wsf_apr_req_m.appr_line_type is '협의유형';

comment on column tb_wsf_apr_req_m.appr_period_cd is '보존연한코드';

comment on column tb_wsf_apr_req_m.file_link_name is '첨부파일명';

comment on column tb_wsf_apr_req_m.file_link_url is '첨부파일 URL';

comment on column tb_wsf_apr_req_m.file_size is '첨부파일사이즈';

comment on column tb_wsf_apr_req_m.read_user is '통보자사번';

comment on column tb_wsf_apr_req_m.read_dept is '공개 부서코드';

comment on column tb_wsf_apr_req_m.reference_id is '참조자 사번';

comment on column tb_wsf_apr_req_m.form_data is '연동양식 layout용 본문';

comment on column tb_wsf_apr_req_m.appkey02 is '업무 구분키 02';

comment on column tb_wsf_apr_req_m.appkey03 is '업무 구분키 03';

comment on column tb_wsf_apr_req_m.relevant_depts is '유관부서 정보';

comment on column tb_wsf_apr_req_m.review_comments is '검토의견';

comment on column tb_wsf_apr_req_m.opt_val_ctn1 is '옵션값내용1';

comment on column tb_wsf_apr_req_m.opt_val_ctn2 is '옵션값내용2';

comment on column tb_wsf_apr_req_m.opt_val_ctn3 is '옵션값내용3';

comment on column tb_wsf_apr_req_m.opt_val_ctn4 is '옵션값내용4';

comment on column tb_wsf_apr_req_m.opt_val_ctn5 is '옵션값내용5';

comment on column tb_wsf_apr_req_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_apr_req_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_apr_req_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_apr_req_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_apr_req_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_apr_req_m.data_upd_dtm is '데이터수정일시';

comment on column tb_wsf_apr_req_m.apr_req_prog_stat_cd is '결재용청진행상태코드';

alter table tb_wsf_apr_req_m
    add constraint tb_wsf_apr_req_test_m_pk
        primary key (req_no);

create table tb_wsf_notice_m
(
    notice_no         varchar2(10) not null,
    notice_tp_cd      varchar2(10),
    notice_sort_ord   numeric,
    notice_title      varchar2(300),
    notice_ctn        varchar2(4000),
    smry_ctn          varchar2(4000),
    atch_file_gr_id   varchar2(50),
    htag_ctn          varchar2(300),
    impt_yn           varchar2(1),
    use_yn            varchar2(1),
    notice_vwct       numeric,
    ptup_end_dt       varchar2(50),
    noti_use_yn       varchar2(1),
    poup_use_yn       varchar2(1),
    poup_st_dtm       TIMESTAMP,
    poup_end_dtm      TIMESTAMP,
    poup_eps_nuse_ddn numeric,
    notice_clsf_cd    varchar2(50),
    ptup_tgt_cop_cd   varchar2(10),
    data_ins_user_id  varchar2(50),
    data_ins_user_ip  varchar2(40),
    data_ins_dtm      TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id  varchar2(50),
    data_upd_user_ip  varchar2(40),
    data_upd_dtm      TIMESTAMP default CURRENT_TIMESTAMP,
    re_notice_yn      varchar2(1),
    prnt_re_notice_no varchar2(10)
);

comment on table tb_wsf_notice_m is '게시판기본';

comment on column tb_wsf_notice_m.notice_no is '게시글번호';

comment on column tb_wsf_notice_m.notice_tp_cd is '게시판유형코드';

comment on column tb_wsf_notice_m.notice_sort_ord is '게시글정렬순서';

comment on column tb_wsf_notice_m.notice_title is '게시글제목명';

comment on column tb_wsf_notice_m.notice_ctn is '게시글내용';

comment on column tb_wsf_notice_m.smry_ctn is '요약내용';

comment on column tb_wsf_notice_m.atch_file_gr_id is '첨부파일그룹ID';

comment on column tb_wsf_notice_m.htag_ctn is '해시태그내용';

comment on column tb_wsf_notice_m.impt_yn is '중요여부';

comment on column tb_wsf_notice_m.use_yn is '사용여부';

comment on column tb_wsf_notice_m.notice_vwct is '게시글조회수';

comment on column tb_wsf_notice_m.ptup_end_dt is '게시종료일자';

comment on column tb_wsf_notice_m.noti_use_yn is '공지사용여부';

comment on column tb_wsf_notice_m.poup_use_yn is '팝업사용여부';

comment on column tb_wsf_notice_m.poup_st_dtm is '팝업시작일시';

comment on column tb_wsf_notice_m.poup_end_dtm is '팝업종료일시';

comment on column tb_wsf_notice_m.poup_eps_nuse_ddn is '팝업노출미사용일수';

comment on column tb_wsf_notice_m.notice_clsf_cd is '게시글분류코드';

comment on column tb_wsf_notice_m.ptup_tgt_cop_cd is '게시대상법인코드';

comment on column tb_wsf_notice_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_notice_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_notice_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_notice_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_notice_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_notice_m.data_upd_dtm is '데이터수정일시';

comment on column tb_wsf_notice_m.re_notice_yn is '답글여부';

comment on column tb_wsf_notice_m.prnt_re_notice_no is '부모글 번호';

alter table tb_wsf_notice_m
    add constraint tb_wsf_notice_m_pk
        primary key (notice_no);

create table tb_wsf_notice_re_d
(
    notice_no        varchar2(50),
    notice_re_no     varchar2(50) not null,
    notice_re_ctn    varchar2(4000),
    del_yn           varchar2(50) not null,
    prnt_re_no       varchar2(50) not null,
    use_yn           varchar2(50) not null,
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_ins_user_id varchar2(50),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50)
);

comment on column tb_wsf_notice_re_d.notice_no is '공지사항no';

comment on column tb_wsf_notice_re_d.notice_re_no is '댓글no';

comment on column tb_wsf_notice_re_d.notice_re_ctn is '댓글내용';

comment on column tb_wsf_notice_re_d.del_yn is '삭제여부';

comment on column tb_wsf_notice_re_d.prnt_re_no is '상위댓글no';

comment on column tb_wsf_notice_re_d.use_yn is '사요여부';

comment on column tb_wsf_notice_re_d.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_notice_re_d.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_notice_re_d.data_upd_dtm is '데이터수정일시';

comment on column tb_wsf_notice_re_d.data_upd_user_id is '데이터수정사용자ID';

alter table tb_wsf_notice_re_d
    add primary key (notice_re_no);

alter table tb_wsf_notice_re_d
    add constraint fk_tb_wsf_fw_notice_note_m
        foreign key (notice_no) references tb_wsf_notice_m
            on delete cascade;

create table tb_wsf_ntdk_dept_m
(
    ntdk_dept_id     numeric(10) not null,
    ntdk_dept_nm     varchar2(200),
    ntdk_dept_desc   varchar2(200),
    use_yn           varchar2(1),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP
);

comment on column tb_wsf_ntdk_dept_m.ntdk_dept_id is '통보처아이디';

comment on column tb_wsf_ntdk_dept_m.ntdk_dept_nm is '통보처제목';

comment on column tb_wsf_ntdk_dept_m.ntdk_dept_desc is '통보처설명';

comment on column tb_wsf_ntdk_dept_m.use_yn is '사용여부';

comment on column tb_wsf_ntdk_dept_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_ntdk_dept_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_ntdk_dept_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_ntdk_dept_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_ntdk_dept_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_ntdk_dept_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_ntdk_dept_m
    add constraint tb_wsf_ntdk_dept_m_pk
        primary key (ntdk_dept_id);

create table tb_wsf_ntdk_dept_d
(
    ntdk_dept_id      numeric(10) not null,
    ntdk_dept_seq     numeric(18) not null,
    ntdk_dept_divs_cd varchar2(50),
    apr_notf_dept_cd  varchar2(50) not null,
    sort_ord          numeric(10),
    use_yn            varchar2(1),
    data_ins_user_id  varchar2(50),
    data_ins_user_ip  varchar2(40),
    data_ins_dtm      TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id  varchar2(50),
    data_upd_user_ip  varchar2(40),
    data_upd_dtm      TIMESTAMP default CURRENT_TIMESTAMP
);

comment on table tb_wsf_ntdk_dept_d is '통보부서상세';

comment on column tb_wsf_ntdk_dept_d.ntdk_dept_id is '통보부서ID';

comment on column tb_wsf_ntdk_dept_d.ntdk_dept_seq is '통보부서순번';

comment on column tb_wsf_ntdk_dept_d.ntdk_dept_divs_cd is '통보부서구분코드';

comment on column tb_wsf_ntdk_dept_d.apr_notf_dept_cd is '결재통보부서ID';

comment on column tb_wsf_ntdk_dept_d.sort_ord is '정렬순서';

comment on column tb_wsf_ntdk_dept_d.use_yn is '사용여부';

comment on column tb_wsf_ntdk_dept_d.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_ntdk_dept_d.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_ntdk_dept_d.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_ntdk_dept_d.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_ntdk_dept_d.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_ntdk_dept_d.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_ntdk_dept_d
    add constraint tb_wsf_ntdk_dept_d_pk
        primary key (ntdk_dept_id, ntdk_dept_seq);

create table tb_wsf_role_btn_m_old
(
    btn_grp_cd       varchar2(30) not null,
    btn_cd           varchar2(30) not null,
    role_cd          varchar2(30) not null,
    use_yn           varchar2(1),
    btn_desc         varchar2(4000),
    opt_val_ctn1     varchar2(4000),
    opt_val_ctn2     varchar2(4000),
    opt_val_ctn3     varchar2(4000),
    opt_val_ctn4     varchar2(4000),
    opt_val_ctn5     varchar2(4000),
    opt_val_ctn6     varchar2(4000),
    opt_val_ctn7     varchar2(4000),
    opt_val_ctn8     varchar2(4000),
    opt_val_ctn9     varchar2(4000),
    opt_val_ctn10    varchar2(4000),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(50),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(50),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP
);

comment on table tb_wsf_role_btn_m_old is '역할별 버튼 권한 매핑 테이블 (백업본)';

comment on column tb_wsf_role_btn_m_old.btn_grp_cd is '버튼그룹코드';

comment on column tb_wsf_role_btn_m_old.btn_cd is '버튼코드';

comment on column tb_wsf_role_btn_m_old.role_cd is '역할코드';

comment on column tb_wsf_role_btn_m_old.use_yn is '사용여부';

comment on column tb_wsf_role_btn_m_old.btn_desc is '버튼설명';

comment on column tb_wsf_role_btn_m_old.opt_val_ctn1 is '옵션값내용1';

comment on column tb_wsf_role_btn_m_old.opt_val_ctn2 is '옵션값내용2';

comment on column tb_wsf_role_btn_m_old.opt_val_ctn3 is '옵션값내용3';

comment on column tb_wsf_role_btn_m_old.opt_val_ctn4 is '옵션값내용4';

comment on column tb_wsf_role_btn_m_old.opt_val_ctn5 is '옵션값내용5';

comment on column tb_wsf_role_btn_m_old.opt_val_ctn6 is '옵션값내용6';

comment on column tb_wsf_role_btn_m_old.opt_val_ctn7 is '옵션값내용7';

comment on column tb_wsf_role_btn_m_old.opt_val_ctn8 is '옵션값내용8';

comment on column tb_wsf_role_btn_m_old.opt_val_ctn9 is '옵션값내용9';

comment on column tb_wsf_role_btn_m_old.opt_val_ctn10 is '옵션값내용10';

comment on column tb_wsf_role_btn_m_old.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_role_btn_m_old.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_role_btn_m_old.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_role_btn_m_old.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_role_btn_m_old.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_role_btn_m_old.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_role_btn_m_old
    add constraint tb_wsf_role_btn_m_pk
        primary key (btn_grp_cd, btn_cd, role_cd);

create table tb_wsf_role_btn_m
(
    btn_gr_cd        varchar2(30) not null,
    btn_cd           varchar2(30) not null,
    role_cd          varchar2(30) not null,
    use_yn           varchar2(1),
    btn_desc         varchar2(4000),
    opt_val_ctn1     varchar2(4000),
    opt_val_ctn2     varchar2(4000),
    opt_val_ctn3     varchar2(4000),
    opt_val_ctn4     varchar2(4000),
    opt_val_ctn5     varchar2(4000),
    opt_val_ctn6     varchar2(4000),
    opt_val_ctn7     varchar2(4000),
    opt_val_ctn8     varchar2(4000),
    opt_val_ctn9     varchar2(4000),
    opt_val_ctn10    varchar2(4000),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(50),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(50),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP
);

comment on table tb_wsf_role_btn_m is '역할별 버튼 권한 매핑 테이블';

comment on column tb_wsf_role_btn_m.btn_gr_cd is '버튼그룹코드';

comment on column tb_wsf_role_btn_m.btn_cd is '버튼코드';

comment on column tb_wsf_role_btn_m.role_cd is '역할코드';

comment on column tb_wsf_role_btn_m.use_yn is '사용여부';

comment on column tb_wsf_role_btn_m.btn_desc is '버튼설명';

comment on column tb_wsf_role_btn_m.opt_val_ctn1 is '옵션값내용1';

comment on column tb_wsf_role_btn_m.opt_val_ctn2 is '옵션값내용2';

comment on column tb_wsf_role_btn_m.opt_val_ctn3 is '옵션값내용3';

comment on column tb_wsf_role_btn_m.opt_val_ctn4 is '옵션값내용4';

comment on column tb_wsf_role_btn_m.opt_val_ctn5 is '옵션값내용5';

comment on column tb_wsf_role_btn_m.opt_val_ctn6 is '옵션값내용6';

comment on column tb_wsf_role_btn_m.opt_val_ctn7 is '옵션값내용7';

comment on column tb_wsf_role_btn_m.opt_val_ctn8 is '옵션값내용8';

comment on column tb_wsf_role_btn_m.opt_val_ctn9 is '옵션값내용9';

comment on column tb_wsf_role_btn_m.opt_val_ctn10 is '옵션값내용10';

comment on column tb_wsf_role_btn_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_role_btn_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_role_btn_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_role_btn_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_role_btn_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_role_btn_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_role_btn_m
    add constraint tb_wsf_role_btn_m_pk_new
        primary key (btn_gr_cd, btn_cd, role_cd);

create table tb_wsf_api_m
(
    api_id           varchar2(50) not null,
    class_nm         varchar2(250),
    api_url          varchar2(4000),
    api_nm           varchar2(4000),
    http_mthd_cd     varchar2(10),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    use_yn           varchar2(1)
);

comment on table tb_wsf_api_m is 'API역할관리';

comment on column tb_wsf_api_m.api_id is 'API ID';

comment on column tb_wsf_api_m.class_nm is '클래스명';

comment on column tb_wsf_api_m.api_url is 'API URL';

comment on column tb_wsf_api_m.api_nm is 'API명';

comment on column tb_wsf_api_m.http_mthd_cd is '메소드';

comment on column tb_wsf_api_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_api_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_api_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_api_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_api_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_api_m.data_upd_dtm is '데이터수정일시';

comment on column tb_wsf_api_m.use_yn is '사용 여부';

alter table tb_wsf_api_m
    add constraint tb_wsf_menu_api_m_pk
        primary key (api_id);

create table tb_wsf_apr_tpl_m
(
    apr_tpl_id       varchar2(50) not null,
    intg_apr_tp_cd   varchar2(50),
    eapr_tpl_id      varchar2(50),
    apr_tpl_nm       varchar2(200),
    sort_ord         numeric(10),
    apr_tpl_desc     varchar2(200),
    use_yn           varchar2(1),
    prs_desc         varchar2(4000),
    wcst_use_yn      varchar2(1),
    wcst_desc        varchar2(4000),
    notf_use_yn      varchar2(1),
    ntdk_id          numeric(10),
    mgr_use_yn       varchar2(1),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(40),
    data_upd_dtm     TIMESTAMP
);

comment on table tb_wsf_apr_tpl_m is '결재양식기본';

comment on column tb_wsf_apr_tpl_m.apr_tpl_id is '결재양식ID';

comment on column tb_wsf_apr_tpl_m.intg_apr_tp_cd is '통합결재유형코드';

comment on column tb_wsf_apr_tpl_m.eapr_tpl_id is '전자결재양식ID';

comment on column tb_wsf_apr_tpl_m.apr_tpl_nm is '결재양식명';

comment on column tb_wsf_apr_tpl_m.sort_ord is '정렬순서';

comment on column tb_wsf_apr_tpl_m.apr_tpl_desc is '결재양식설명';

comment on column tb_wsf_apr_tpl_m.use_yn is '사용여부';

comment on column tb_wsf_apr_tpl_m.prs_desc is '프로세스설명';

comment on column tb_wsf_apr_tpl_m.wcst_use_yn is '동의서사용여부';

comment on column tb_wsf_apr_tpl_m.wcst_desc is '동의서설명';

comment on column tb_wsf_apr_tpl_m.notf_use_yn is '통보사용여부';

comment on column tb_wsf_apr_tpl_m.ntdk_id is '통보처ID';

comment on column tb_wsf_apr_tpl_m.mgr_use_yn is '담당자사용여부';

comment on column tb_wsf_apr_tpl_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_apr_tpl_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_apr_tpl_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_apr_tpl_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_apr_tpl_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_apr_tpl_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_apr_tpl_m
    add constraint tb_wsf_apr_tpl_m_pk
        primary key (apr_tpl_id);

create table tb_wsf_btn_log_m
(
    btn_key_cd       varchar2(4000),
    btn_gr_cd        varchar2(4000),
    btn_cd           varchar2(4000),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(40),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    cont_dtm         TIMESTAMP default CURRENT_TIMESTAMP,
    user_id          varchar2(4000)
);

comment on table tb_wsf_btn_log_m is '버튼로그마스터테이블';

comment on column tb_wsf_btn_log_m.btn_key_cd is '버튼키코드';

comment on column tb_wsf_btn_log_m.btn_gr_cd is '버튼그룹코드';

comment on column tb_wsf_btn_log_m.btn_cd is '버튼코드';

comment on column tb_wsf_btn_log_m.data_ins_user_id is '데이터입력일시';

comment on column tb_wsf_btn_log_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_btn_log_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_btn_log_m.cont_dtm is '접속일시';

comment on column tb_wsf_btn_log_m.user_id is '사용자ID';

create table tb_wsf_help_m
(
    pgm_id          varchar2(50) not null,
    help_nm          varchar2(50),
    help_type        varchar2(50),
    help_url         varchar2(50),
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(50),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(50),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    use_yn           varchar2(1),
    help_file        varchar2(50),
    help_link        varchar2(50)
);

comment on table tb_wsf_help_m is '도움말';

comment on column tb_wsf_help_m.pgm_id is '도움말ID';

comment on column tb_wsf_help_m.help_nm is '도움말명';

comment on column tb_wsf_help_m.help_type is '도움말 타입';

comment on column tb_wsf_help_m.help_url is '도움말 URL';

comment on column tb_wsf_help_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_help_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_help_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_help_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_help_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_help_m.data_upd_dtm is '데이터수정일시';

comment on column tb_wsf_help_m.use_yn is '사용여부';

comment on column tb_wsf_help_m.help_file is '도움말 파일';

comment on column tb_wsf_help_m.help_link is '도움말 링크';

alter table tb_wsf_help_m
    add constraint tb_wsf_help_m_pk
        primary key (pgm_id);

create table tb_wsf_emp_pass_m
(
    user_id         varchar2(50)  not null,
    user_pass       varchar2(100) not null,
    login_wrong_cnt integer default 0
);

comment on table tb_wsf_emp_pass_m is '직원로그인인증';

comment on column tb_wsf_emp_pass_m.user_id is '사용자ID';

comment on column tb_wsf_emp_pass_m.user_pass is '사용자통과';

comment on column tb_wsf_emp_pass_m.login_wrong_cnt is '로그인실패횟수';

alter table tb_wsf_emp_pass_m
    add constraint tb_wsf_emp_pass_m_pk
        primary key (user_id);

create table tb_wsf_refresh_token
(
    seq          NUMBER GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    user_id      varchar2(255) not null,
    token        varchar2(4000)         not null,
    expiry_dtm   TIMESTAMP    not null,
    data_upd_dtm TIMESTAMP default CURRENT_TIMESTAMP
);

comment on table tb_wsf_refresh_token is '리프레시 토큰 관리 테이블';

comment on column tb_wsf_refresh_token.seq is '시퀀스';

comment on column tb_wsf_refresh_token.user_id is '사용자ID';

comment on column tb_wsf_refresh_token.token is '토큰';

comment on column tb_wsf_refresh_token.expiry_dtm is '만료일시';

comment on column tb_wsf_refresh_token.data_upd_dtm is '데이터수정일시';

create index idx_refresh_token_user_id
    on tb_wsf_refresh_token (user_id);

create index idx_refresh_token_expiry
    on tb_wsf_refresh_token (expiry_dtm);

alter table tb_wsf_refresh_token
    add unique (token);

create table tb_wsf_personal_search_m
(
    search_id        varchar2(50) not null,
    search_url       varchar2(50),
    search_form_id   varchar2(50) not null,
    search_query     varchar2(4000)        not null,
    user_id          varchar2(50) not null,
    data_ins_user_id varchar2(50),
    data_ins_user_ip varchar2(50),
    data_ins_dtm     TIMESTAMP default CURRENT_TIMESTAMP,
    data_upd_user_id varchar2(50),
    data_upd_user_ip varchar2(50),
    data_upd_dtm     TIMESTAMP default CURRENT_TIMESTAMP
);

comment on table tb_wsf_personal_search_m is '사용자 검색 조건';

comment on column tb_wsf_personal_search_m.search_id is '검색 ID';

comment on column tb_wsf_personal_search_m.search_url is '검색 URL';

comment on column tb_wsf_personal_search_m.search_form_id is '검색 양식 ID';

comment on column tb_wsf_personal_search_m.search_query is '검색 쿼리';

comment on column tb_wsf_personal_search_m.user_id is '사용자 ID';

comment on column tb_wsf_personal_search_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_personal_search_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_personal_search_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_personal_search_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_personal_search_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_personal_search_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_personal_search_m
    add constraint tb_wsf_user_searches_m_pk
        primary key (search_id);

alter table tb_wsf_personal_search_m
    add constraint tb_wsf_personal_search_m_pk
        unique (search_url, user_id, search_form_id);

create table tb_wsf_multi_db2
(
    col1 varchar2(4000) not null,
    col2 varchar2(4000)
);

comment on column tb_wsf_multi_db2.col1 is '열1';

comment on column tb_wsf_multi_db2.col2 is '열2';

create table tb_wsf_btch_m
(
    btch_id          varchar2(4000) not null,
    btch_nm          varchar2(4000) not null,
    btch_desc        varchar2(4000),
    btch_cron        varchar2(4000) not null,
    last_executed_dt TIMESTAMP,
    success_yn       varchar2(4000) not null,
    use_yn           varchar2(4000) not null
);

comment on table tb_wsf_btch_m is '배치 작업 마스터 테이블';

comment on column tb_wsf_btch_m.btch_id is '배치ID';

comment on column tb_wsf_btch_m.btch_nm is '배치명';

comment on column tb_wsf_btch_m.btch_desc is '배치설명';

comment on column tb_wsf_btch_m.btch_cron is '배치주기';

comment on column tb_wsf_btch_m.last_executed_dt is '최근수행시기';

comment on column tb_wsf_btch_m.success_yn is '성공여부';

comment on column tb_wsf_btch_m.use_yn is '사용여부';

alter table tb_wsf_btch_m
    add primary key (btch_id);

