CREATE OR REPLACE FUNCTION fn_get_cd_nm(
    p_gr_cd    IN VARCHAR2,
    p_cd       IN VARCHAR2,
    p_lang_cd  IN VARCHAR2
) RETURN VARCHAR2
IS
    d_return   VARCHAR2(2000);
    v_lang_cd  VARCHAR2(10);
BEGIN
    d_return := NULL;
    v_lang_cd := NVL(p_lang_cd, 'ko');

SELECT COALESCE(M.MSG_TXT_CTN, C.CMN_CD_NM)
INTO d_return
FROM TB_WSF_CMN_GR_C G
         INNER JOIN TB_WSF_CMN_C C ON G.CMN_GR_CD = C.CMN_GR_CD
         LEFT JOIN TB_WSF_MSG_M M ON C.MSG_CTN = M.MSG_CTN AND M.LANG_CD = v_lang_cd
WHERE G.CMN_GR_CD = p_gr_cd
  AND C.CMN_CD = p_cd;

RETURN d_return;
END;
/


CREATE OR REPLACE FUNCTION fn_get_cd_opt_val(
    p_gr_cd    IN VARCHAR2,
    p_cd       IN VARCHAR2,
    p_opt_num  IN NUMBER
) RETURN VARCHAR2
IS
    d_return VARCHAR2(4000);
BEGIN
    d_return := NULL;

SELECT CASE p_opt_num
           WHEN 1  THEN C.OPT_VAL_CTN1
           WHEN 2  THEN C.OPT_VAL_CTN2
           WHEN 3  THEN C.OPT_VAL_CTN3
           WHEN 4  THEN C.OPT_VAL_CTN4
           WHEN 5  THEN C.OPT_VAL_CTN5
           WHEN 6  THEN C.OPT_VAL_CTN6
           WHEN 7  THEN C.OPT_VAL_CTN7
           WHEN 8  THEN C.OPT_VAL_CTN8
           WHEN 9  THEN C.OPT_VAL_CTN9
           WHEN 10 THEN C.OPT_VAL_CTN10
           WHEN 11 THEN C.OPT_VAL_CTN11
           WHEN 12 THEN C.OPT_VAL_CTN12
           WHEN 13 THEN C.OPT_VAL_CTN13
           WHEN 14 THEN C.OPT_VAL_CTN14
           WHEN 15 THEN C.OPT_VAL_CTN15
           ELSE NULL
           END
INTO d_return
FROM TB_WSF_CMN_GR_C G
         INNER JOIN TB_WSF_CMN_C C ON G.CMN_GR_CD = C.CMN_GR_CD
WHERE G.CMN_GR_CD = p_gr_cd
  AND C.CMN_CD    = p_cd;

RETURN d_return;
END;
/
CREATE OR REPLACE FUNCTION fn_get_dept_nm(
    p_dept_cd   IN VARCHAR2,
    p_lang_cd   IN VARCHAR2
) RETURN VARCHAR2
IS
    d_return   VARCHAR2(1000);
    v_lang_cd  VARCHAR2(10);
BEGIN
    d_return := NULL;
    v_lang_cd := NVL(p_lang_cd, 'KO');

SELECT CASE
           WHEN v_lang_cd = 'ko' THEN DEPT_NM
           WHEN v_lang_cd IN ('zhC', 'zhT') THEN DEPT_CNG_NM
           WHEN v_lang_cd IN ('en', 'pl') THEN DEPT_ENG_NM
           ELSE DEPT_ENG_NM
           END
INTO d_return
FROM TB_WSF_DEPT_M
WHERE DEPT_CD = p_dept_cd;

RETURN d_return;

EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
END;
/

CREATE OR REPLACE FUNCTION fn_get_user_jikwi_nm(
    p_user_id_no IN VARCHAR2,
    p_lang_cd    IN VARCHAR2,
    p_flag       IN VARCHAR2
) RETURN VARCHAR2
IS
    d_return   VARCHAR2(1000);
    v_lang_cd  VARCHAR2(10) := NVL(p_lang_cd, 'ko');
BEGIN
    d_return := NULL;

BEGIN
        IF p_flag = 'ID' THEN
SELECT CASE
           WHEN v_lang_cd = 'ko' THEN
               CASE WHEN JPS_CD IS NULL THEN JTI_NM ELSE JPS_NM END
           WHEN v_lang_cd IN ('zhC', 'zhT') THEN
               CASE WHEN JPS_CD IS NULL THEN JTI_CNG_NM ELSE JPS_CNG_NM END
           WHEN v_lang_cd IN ('en', 'pl') THEN
               CASE WHEN JPS_CD IS NULL THEN JTI_ENG_NM ELSE JPS_ENG_NM END
           ELSE
               CASE WHEN JPS_CD IS NULL THEN JTI_ENG_NM ELSE JPS_ENG_NM END
           END
INTO d_return
FROM TB_WSF_EMP_M E
WHERE E.USER_ID = p_user_id_no
  AND E.USE_YN = 'Y';

ELSIF p_flag = 'NO' THEN
SELECT CASE
           WHEN v_lang_cd = 'ko' THEN
               CASE WHEN JPS_CD IS NULL THEN JTI_NM ELSE JPS_NM END
           WHEN v_lang_cd IN ('zhC', 'zhT') THEN
               CASE WHEN JPS_CD IS NULL THEN JTI_CNG_NM ELSE JPS_CNG_NM END
           WHEN v_lang_cd IN ('en', 'pl') THEN
               CASE WHEN JPS_CD IS NULL THEN JTI_ENG_NM ELSE JPS_ENG_NM END
           ELSE
               CASE WHEN JPS_CD IS NULL THEN JTI_ENG_NM ELSE JPS_ENG_NM END
           END
INTO d_return
FROM TB_WSF_EMP_M E
WHERE E.USER_ID = p_user_id_no
  AND E.USE_YN = 'Y';
END IF;

EXCEPTION
        WHEN NO_DATA_FOUND THEN
            d_return := NULL;
END;

RETURN d_return;
END;
/
CREATE OR REPLACE FUNCTION fn_get_user_nm(
    p_user_id_no IN VARCHAR2,
    p_lang_cd    IN VARCHAR2,
    p_flag       IN VARCHAR2
) RETURN VARCHAR2
IS
    d_return   VARCHAR2(1000);
    v_lang_cd  VARCHAR2(10) := NVL(p_lang_cd, 'ko');
BEGIN
    d_return := NULL;

BEGIN
        IF p_flag = 'ID' THEN
SELECT CASE
           WHEN v_lang_cd = 'ko' THEN EMP_NM
           WHEN v_lang_cd IN ('zhC', 'zhT') THEN EMP_CNG_NM
           WHEN v_lang_cd IN ('en', 'pl') THEN EMP_ENG_NM
           ELSE EMP_ENG_NM
           END
INTO d_return
FROM TB_WSF_EMP_M E
WHERE E.USER_ID = p_user_id_no
  AND E.USE_YN = 'Y';

ELSIF p_flag = 'NO' THEN
SELECT CASE
           WHEN v_lang_cd = 'ko' THEN EMP_NM
           WHEN v_lang_cd IN ('zhC', 'zhT') THEN EMP_CNG_NM
           WHEN v_lang_cd IN ('en', 'pl') THEN EMP_ENG_NM
           ELSE EMP_ENG_NM
           END
INTO d_return
FROM TB_WSF_EMP_M E
WHERE E.EMP_NO = p_user_id_no
  AND E.USE_YN = 'Y';
END IF;

EXCEPTION
        WHEN NO_DATA_FOUND THEN
            NULL;
END;

RETURN d_return;
END;
/
CREATE OR REPLACE FUNCTION fn_get_message(
    p_msg_ctn  IN VARCHAR2,
    p_lang_cd  IN VARCHAR2
) RETURN VARCHAR2
IS
    d_return   VARCHAR2(2000);
    v_lang_cd  VARCHAR2(10);
BEGIN
    d_return := NULL;
    v_lang_cd := NVL(p_lang_cd, 'ko');

SELECT COALESCE(A.MSG_TXT_CTN, p_msg_ctn)
INTO d_return
FROM TB_WSF_MSG_M A
WHERE A.MSG_CTN = p_msg_ctn
  AND A.LANG_CD = v_lang_cd;

RETURN d_return;
END;
/
CREATE OR REPLACE FUNCTION fn_get_user_info (
    p_user_id    IN VARCHAR2,
    p_lang_cd    IN VARCHAR2,
    p_disp_type  IN NUMBER DEFAULT 1
) RETURN VARCHAR2
IS
    v_returnval  VARCHAR2(2000);
BEGIN
    v_returnval := '';

    IF p_disp_type = 1 THEN
BEGIN
SELECT
    CASE
        WHEN p_lang_cd = 'ko' THEN
            EMP_NM || '(' || USER_ID || '/' ||
            CASE
                WHEN JPS_CD IS NULL THEN JTI_NM
                ELSE JPS_NM
                END || '/' || D.DEPT_NM || ')'
        WHEN p_lang_cd IN ('zhC', 'zhT') THEN
            EMP_CNG_NM || '(' || USER_ID || '/' ||
            CASE
                WHEN JPS_CD IS NULL THEN JTI_CNG_NM
                ELSE JPS_CNG_NM
                END || '/' || D.DEPT_CNG_NM || ')'
        WHEN p_lang_cd IN ('en', 'pl') THEN
            EMP_ENG_NM || '(' || USER_ID || '/' ||
            CASE
                WHEN JPS_CD IS NULL THEN JTI_ENG_NM
                ELSE JPS_ENG_NM
                END || '/' || D.DEPT_ENG_NM || ')'
        ELSE
            EMP_ENG_NM || '(' || USER_ID || '/' ||
            CASE
                WHEN JPS_CD IS NULL THEN JTI_ENG_NM
                ELSE JPS_ENG_NM
                END || '/' || D.DEPT_ENG_NM || ')'
        END
INTO v_returnval
FROM TB_WSF_EMP_M E
         JOIN TB_WSF_DEPT_M D ON E.DEPT_CD = D.DEPT_CD
WHERE E.USER_ID = p_user_id
  AND E.USE_YN = 'Y';

EXCEPTION
            WHEN NO_DATA_FOUND THEN
                v_returnval := '-';
END;

    ELSIF p_disp_type = 2 THEN
BEGIN
SELECT
    CASE
        WHEN p_lang_cd = 'ko' THEN
            EMP_NM || '(' || USER_ID || ')'
        WHEN p_lang_cd IN ('zh-CN', 'zh-TW') THEN
            NVL(EMP_CNG_NM, EMP_ENG_NM) || '(' || USER_ID || ')'
        WHEN p_lang_cd IN ('en', 'pl') THEN
            NVL(EMP_ENG_NM, EMP_NM) || '(' || USER_ID || ')'
        ELSE
            EMP_ENG_NM || '(' || USER_ID || ')'
        END
INTO v_returnval
FROM TB_WSF_EMP_M E
         JOIN TB_WSF_DEPT_M D ON E.DEPT_CD = D.DEPT_CD
WHERE E.USER_ID = p_user_id
  AND E.USE_YN = 'Y';

EXCEPTION
            WHEN NO_DATA_FOUND THEN
                v_returnval := '-';
END;

END IF;

RETURN v_returnval;
END;
/
