create or replace function fn_get_cd_nm(p_gr_cd character varying, p_cd character varying, p_lang_cd character varying) returns character varying
	language plpgsql
as $$
/*******************************************************************************
 * Project      : WSF
 * Module       : CMN
 * Program Name : FN_GET_CD_NM
 * Description  : 공통코드명 조회
 * Program History
 *------------------------------------------------------------------------------
 *  Date    		In Charge          Description
 *------------------------------------------------------------------------------
 *  2023-04-30                         최초작성
 *  2023-05-12  메시지를 MSG_CTN 코드로 Join하도록 수정, 메시지 코드가 없을 경우 cmn_nm 을 조회하도록 수정
 *******************************************************************************/
DECLARE
d_return     VARCHAR(2000);
    v_lang_cd    VARCHAR(10);

BEGIN

    d_return := NULL;
    v_lang_cd := COALESCE(P_LANG_CD,'ko');

SELECT COALESCE(M.MSG_TXT_CTN, C.CMN_CD_NM)
INTO d_return
FROM TB_WSF_CMN_GR_C   G
         INNER JOIN TB_WSF_CMN_C C ON ( G.CMN_GR_CD   = C.CMN_GR_CD)
         LEFT JOIN TB_WSF_MSG_M M ON ( C.MSG_CTN = M.MSG_CTN AND M.LANG_CD = v_lang_cd)
WHERE G.CMN_GR_CD  = P_GR_CD
  AND C.CMN_CD     = P_CD
;

RETURN d_return;

END;
$$;

alter function fn_get_cd_nm(varchar, varchar, varchar) owner to developer;

create or replace function fn_get_cd_opt_val(p_gr_cd character varying, p_cd character varying, p_opt_num numeric) returns character varying
	language plpgsql
as $$
/*******************************************************************************
 * Project      : WSF
 * Module       : CMN
 * Program Name : FN_GET_CD_OPT_VAL
 * Description  : 공통코드 옵션값 조회
 * Program History
 *------------------------------------------------------------------------------
 *  Date        In Charge          Description
 *------------------------------------------------------------------------------
 *  2023-06-05                         최초작성
 *******************************************************************************/
DECLARE
d_return     VARCHAR(4000);

BEGIN

    d_return := NULL;

SELECT CASE P_OPT_NUM WHEN  1
                          THEN C.OPT_VAL_CTN1
                      WHEN  2
                          THEN C.OPT_VAL_CTN2
                      WHEN  3
                          THEN C.OPT_VAL_CTN3
                      WHEN  4
                          THEN C.OPT_VAL_CTN4
                      WHEN  5
                          THEN C.OPT_VAL_CTN5
                      WHEN  6
                          THEN C.OPT_VAL_CTN6
                      WHEN  7
                          THEN C.OPT_VAL_CTN7
                      WHEN  8
                          THEN C.OPT_VAL_CTN8
                      WHEN  9
                          THEN C.OPT_VAL_CTN9
                      WHEN  10
                          THEN C.OPT_VAL_CTN10
                      WHEN  11
                          THEN C.OPT_VAL_CTN11
                      WHEN  12
                          THEN C.OPT_VAL_CTN12
                      WHEN  13
                          THEN C.OPT_VAL_CTN13
                      WHEN  14
                          THEN C.OPT_VAL_CTN14
                      WHEN  15
                          THEN C.OPT_VAL_CTN15
                      ELSE NULL
           END
INTO d_return
FROM TB_WSF_CMN_GR_C G
         INNER JOIN TB_WSF_CMN_C C
                    ON (G.CMN_GR_CD = C.CMN_GR_CD)
WHERE G.CMN_GR_CD = P_GR_CD
  AND C.CMN_CD = P_CD;

RETURN d_return;

END;
$$;

alter function fn_get_cd_opt_val(varchar, varchar, numeric) owner to developer;

create or replace function fn_get_dept_nm(p_dept_cd character varying, p_lang_cd character varying) returns character varying
	language plpgsql
as $$
/*******************************************************************************
 * Project      : WSF
 * Module       : CMN
 * Program Name : FN_GET_DEPT_NM
 * Description  : 부서테이블에서 부서명 조회
 * Program History
 *------------------------------------------------------------------------------
 *  Date    		In Charge   Description
 *------------------------------------------------------------------------------
 *  2023-04-30         	                      최초작성
 *******************************************************************************/
DECLARE
d_return     VARCHAR(1000);
    v_lang_cd    VARCHAR(10);

BEGIN

    d_return := NULL;
    v_lang_cd := COALESCE(P_LANG_CD,'KO');

SELECT
    CASE WHEN P_LANG_CD = 'ko'                THEN DEPT_NM
         WHEN P_LANG_CD IN ('zhC','zhT')  THEN DEPT_CNG_NM
         WHEN P_LANG_CD IN ('en','pl')        THEN DEPT_ENG_NM
         ELSE DEPT_ENG_NM
        END AS LANG_DEPT_NM
INTO d_return
FROM TB_WSF_DEPT_M
WHERE DEPT_CD = P_DEPT_CD
;
RETURN d_return;

EXCEPTION
    WHEN OTHERS THEN
        RETURN null;
END;
$$;

alter function fn_get_dept_nm(varchar, varchar) owner to developer;

create or replace function fn_get_jikwi_nm(p_jps_cd character varying, p_jti_cd character varying, p_lang_cd character varying) returns character varying
	language plpgsql
as $$
/*******************************************************************************
 * Project      : WSF
 * Module       : CMN
 * Program Name : FN_GET_JIKWI_NM
 * Description  : 직위코드 없으면 직책명  직위코드 있으면 직위명  RETURN
                  P_JPS_CD : 직책코드     P_JTI_CD : 직위코드
 * Program History
 *------------------------------------------------------------------------------
 *  Date    		In Charge   Description
 *------------------------------------------------------------------------------
 *  2023-04-30      	                     최초작성
*******************************************************************************/
DECLARE
d_return     VARCHAR(1000);
    V_LANG_CD    VARCHAR(10) := COALESCE(P_LANG_CD,'ko');

BEGIN
    d_return := NULL;
BEGIN
        IF (P_JTI_CD is NULL OR P_JTI_CD = ''  )  THEN  -- 직위코드가 없는경우

SELECT M.MSG_TXT_CTN
INTO d_return
FROM TB_WSF_CMN_GR_C   G
         INNER JOIN TB_WSF_CMN_C C ON ( G.CMN_GR_CD   = C.CMN_GR_CD)
         INNER JOIN TB_WSF_MSG_M M ON ( C.MSG_CTN = M.MSG_CTN)
WHERE G.CMN_GR_CD  = 'JPS_CD'
  AND C.CMN_CD     = P_JPS_CD
  AND M.LANG_CD    = V_LANG_CD ;

ELSE

SELECT M.MSG_TXT_CTN
INTO d_return
FROM TB_WSF_CMN_GR_C   G
         INNER JOIN TB_WSF_CMN_C C ON ( G.CMN_GR_CD   = C.CMN_GR_CD)
         INNER JOIN TB_WSF_MSG_M M ON ( C.MSG_CTN = M.MSG_CTN)
WHERE G.CMN_GR_CD  = 'JTI_CD'
  AND C.CMN_CD     = P_JTI_CD
  AND M.LANG_CD    = V_LANG_CD;

END IF;

EXCEPTION
        WHEN NO_DATA_FOUND THEN
            NULL;
END;
RETURN d_return;
END;
$$;

alter function fn_get_jikwi_nm(varchar, varchar, varchar) owner to developer;

create or replace function fn_get_local_time_d(p_timezne character varying, p_datetime date, p_format character varying) returns character varying
	language plpgsql
as $$
/*******************************************************************************
 * Project      : WSF
 * Module       : CMN
 * Program Name : FN_GET_LOCAL_TIME_D
 * Description  : datetime - timezone 으로 return
 * Paramata     :
 * Program History
 *------------------------------------------------------------------------------
 *  Date    		In Charge          Description
 *------------------------------------------------------------------------------
 *  2023-05-15  최초작성
 *******************************************************************************/
DECLARE
d_return     VARCHAR(100);
    v_timezone   VARCHAR(100);
    v_optval4    VARCHAR(100);
    v_optval5    VARCHAR(100);
    v_optval6    VARCHAR(100);
    v_optval7    VARCHAR(100);
    v_optval8    VARCHAR(100);
    v_optval9    VARCHAR(100);
    v_optval10   VARCHAR(100);
    v_sSTime     VARCHAR(100); -- 시작 서머타임
    v_eSTime     VARCHAR(100); -- 종료 서머타임
    v_Year       VARCHAR(4);
    err_code   VARCHAR (1024);
    err_msg    VARCHAR (1024);
BEGIN

    d_return := NULL;

BEGIN
        IF P_DATETIME IS NULL THEN
            RETURN NULL;
END IF;

        IF P_TIMEZNE IS NULL  THEN
            v_timezone := 'GMT000000009';   -- 없으면 한국값으로
else
            v_timezone := P_TIMEZNE;
END IF;

SELECT TO_CHAR ( P_DATETIME
                     +  TO_NUMBER(OPT_VAL_CTN1)/24 * ( CASE WHEN TO_NUMBER(OPT_VAL_CTN1) < 10  THEN 1 ELSE -1 END) , P_FORMAT )
INTO d_return
FROM TB_WSF_CMN_GR_C   G
         INNER JOIN TB_WSF_CMN_C C ON ( G.CMN_GR_CD   = C.CMN_GR_CD)
WHERE G.CMN_GR_CD='GPT_TMZ_CD'
  AND CMN_CD = v_timezone  ;

SELECT  C.OPT_VAL_CTN4, C.OPT_VAL_CTN5, C.OPT_VAL_CTN6, C.OPT_VAL_CTN7
     ,C.OPT_VAL_CTN8, C.OPT_VAL_CTN9, C.OPT_VAL_CTN10
INTO v_optval4, v_optval5, v_optval6, v_optval7, v_optval8,  v_optval9, v_optval10
FROM TB_WSF_CMN_GR_C G
         INNER JOIN TB_WSF_CMN_C C ON ( G.CMN_GR_CD   = C.CMN_GR_CD)
WHERE G.CMN_GR_CD='GPT_TMZ_CD'
  AND CMN_CD = v_timezone  ;

IF  v_optval4 IS NOT NULL AND v_optval5 IS NOT NULL AND  v_optval6 IS NOT NULL AND  v_optval7 IS NOT NULL AND
            v_optval8 IS NOT NULL AND v_optval9 IS NOT NULL AND  v_optval10  IS NOT NULL THEN

            v_Year := SUBSTR(d_return,1,4) ;

            /*시작일자 지정 월의 지정주차 일요일 */
SELECT TO_CHAR(FN_GET_NEXT_DAY(TRUNC(TO_DATE(v_Year||LPAD(v_optval4,2,'0')||'01' ,'YYYYMMDD')-1),1)+(TO_NUMBER(v_optval6)-1)*7,'YYYYMMDD')||REPLACE (v_optval7,':','') || '00'
INTO v_sSTime;

/*종료일자 지정월의 지정주차 일요일*/
SELECT TO_CHAR(FN_GET_NEXT_DAY(TRUNC(TO_DATE(v_Year||LPAD(v_optval8,2,'0')||'01' ,'YYYYMMDD')-1),1)+(TO_NUMBER(v_optval9)-1)*7,'YYYYMMDD')||REPLACE (v_optval10,':','') || '00'
INTO v_eSTime;

IF d_return >=  v_sSTime AND  d_return <= v_eSTime  THEN  -- 타임존 적용
SELECT TO_CHAR(TO_DATE(d_return,'YYYYMMDDHH24MISS' )  + TO_NUMBER('1')/24  , P_FORMAT )
INTO d_return;
END IF;

END IF ;

        -- d_return := TO_CHAR(d_retun_date,P_FORMAT ) ;
EXCEPTION
        WHEN OTHERS THEN
            /*  err_code := SQLCODE;
               err_msg := SUBSTR (SQLERRM, 1, 200);
               d_return := err_code || SUBSTR (SQLERRM, 1, 200);*/
            d_return := TO_CHAR ( current_date - 100,P_FORMAT )    ;  -- 오류시 에러 일으키지 말고 100년전으로 회귀
END;
RETURN d_return;

END;
$$;

alter function fn_get_local_time_d(varchar, date, varchar) owner to developer;

create or replace function fn_get_user_dept_nm(p_user_id_no character varying, p_lang_cd character varying, p_flag character varying) returns character varying
	language plpgsql
as $$
/*******************************************************************************
 * Project      : WSF
 * Module       : CMN
 * Program Name : FN_GET_USER_DEPT_NM
 * Description  : 임직원의 부서명 조회
 * Program History
 *------------------------------------------------------------------------------
 *  Date    		In Charge   Description
 *------------------------------------------------------------------------------
 *  2023-04-30      	                   최초작성
*******************************************************************************/
DECLARE
d_return     VARCHAR(1000);
    V_LANG_CD    VARCHAR(10) := COALESCE(P_LANG_CD,'ko');

BEGIN
    d_return := NULL;
BEGIN
        IF (P_FLAG = 'ID')  THEN  -- USER_ID

SELECT
    CASE WHEN P_LANG_CD = 'ko'            THEN DEPT_NM
         WHEN P_LANG_CD IN ('zhC','zhT')  THEN DEPT_CNG_NM
         WHEN P_LANG_CD IN ('en','pl')    THEN DEPT_ENG_NM
         ELSE DEPT_ENG_NM
        END AS LANG_DEPT_NM
INTO   d_return
FROM   TB_WSF_EMP_M E
WHERE   E.USER_ID = P_USER_ID_NO
  AND   E.USE_YN = 'Y';

ELSIF (P_FLAG = 'NO') THEN -- EMP_NO

SELECT
    CASE WHEN P_LANG_CD = 'ko'            THEN DEPT_NM
         WHEN P_LANG_CD IN ('zhC','zhT')  THEN DEPT_CNG_NM
         WHEN P_LANG_CD IN ('en','pl')    THEN DEPT_ENG_NM
         ELSE DEPT_ENG_NM
        END AS LANG_DEPT_NM
INTO   d_return
FROM   TB_WSF_EMP_M E
WHERE   E.EMP_NO = P_USER_ID_NO
  AND   E.USE_YN = 'Y';
END IF;

EXCEPTION
        WHEN NO_DATA_FOUND THEN
            NULL;
END;
RETURN d_return;
END;
$$;

alter function fn_get_user_dept_nm(varchar, varchar, varchar) owner to developer;

create or replace function fn_get_user_jikwi_nm(p_user_id_no character varying, p_lang_cd character varying, p_flag character varying) returns character varying
	language plpgsql
as $$
/*******************************************************************************
 * Project      : WSF
 * Module       : CMN
 * Program Name : FN_GET_EMP_NM
 * Description  : 임직원 명 조회
 * Program History
 *------------------------------------------------------------------------------
 *  Date    		In Charge   Description
 *------------------------------------------------------------------------------
 *  2023-04-30      	                   최초작성
*******************************************************************************/
DECLARE
d_return     VARCHAR(1000);
    V_LANG_CD    VARCHAR(10) := COALESCE(P_LANG_CD,'ko');

BEGIN
    d_return := NULL;
BEGIN
        IF (P_FLAG = 'ID') THEN  -- USER_ID
SELECT
    CASE
        WHEN P_LANG_CD = 'ko' THEN
            CASE WHEN JPS_CD IS NULL THEN JTI_NM ELSE JPS_NM END
        WHEN P_LANG_CD IN ('zhC', 'zhT') THEN
            CASE WHEN JPS_CD IS NULL THEN JTI_CNG_NM ELSE JPS_CNG_NM END
        WHEN P_LANG_CD IN ('en', 'pl') THEN
            CASE WHEN JPS_CD IS NULL THEN JTI_ENG_NM ELSE JPS_ENG_NM END
        ELSE
            CASE WHEN JPS_CD IS NULL THEN JTI_ENG_NM ELSE JPS_ENG_NM END
        END AS JTI_NM
INTO d_return
FROM TB_WSF_EMP_M E
WHERE E.USER_ID = P_USER_ID_NO
  AND E.USE_YN = 'Y';

ELSIF (P_FLAG = 'NO') THEN -- EMP_NO
SELECT
    CASE
        WHEN P_LANG_CD = 'ko' THEN
            CASE WHEN JPS_CD IS NULL THEN JTI_NM ELSE JPS_NM END
        WHEN P_LANG_CD IN ('zhC', 'zhT') THEN
            CASE WHEN JPS_CD IS NULL THEN JTI_CNG_NM ELSE JPS_CNG_NM END
        WHEN P_LANG_CD IN ('en', 'pl') THEN
            CASE WHEN JPS_CD IS NULL THEN JTI_ENG_NM ELSE JPS_ENG_NM END
        ELSE
            CASE WHEN JPS_CD IS NULL THEN JTI_ENG_NM ELSE JPS_ENG_NM END
        END AS JTI_NM
INTO d_return
FROM TB_WSF_EMP_M E
WHERE E.USER_ID = P_USER_ID_NO
  AND E.USE_YN = 'Y';
END IF;

EXCEPTION
        WHEN NO_DATA_FOUND THEN
            d_return := NULL;
END;
RETURN d_return;
END;
$$;

alter function fn_get_user_jikwi_nm(varchar, varchar, varchar) owner to developer;

create or replace function fn_get_user_nm(p_user_id_no character varying, p_lang_cd character varying, p_flag character varying) returns character varying
	language plpgsql
as $$
/*******************************************************************************
 * Project      : WSF
 * Module       : CMN
 * Program Name : FN_GET_EMP_NM
 * Description  : 임직원 명 조회
 * Program History
 *------------------------------------------------------------------------------
 *  Date    		In Charge   Description
 *------------------------------------------------------------------------------
 *  2023-04-30      	                   최초작성
*******************************************************************************/
DECLARE
d_return     VARCHAR(1000);
    V_LANG_CD    VARCHAR(10) := COALESCE(P_LANG_CD,'ko');

BEGIN
    d_return := NULL;
BEGIN
        IF (P_FLAG = 'ID')  THEN  -- USER_ID

SELECT
    CASE WHEN P_LANG_CD = 'ko'                THEN EMP_NM
         WHEN P_LANG_CD IN ('zhC','zhT')  THEN EMP_CNG_NM
         WHEN P_LANG_CD IN ('en','pl')        THEN EMP_ENG_NM
         ELSE EMP_ENG_NM
        END AS LANG_EMP_NM
INTO   d_return
FROM   TB_WSF_EMP_M E
WHERE   E.USER_ID = P_USER_ID_NO
  AND   E.USE_YN = 'Y';

ELSIF (P_FLAG = 'NO') THEN -- EMP_NO

SELECT
    CASE WHEN P_LANG_CD = 'ko'                THEN EMP_NM
         WHEN P_LANG_CD IN ('zhC','zhT')  THEN EMP_CNG_NM
         WHEN P_LANG_CD IN ('en','pl')        THEN EMP_ENG_NM
         ELSE EMP_ENG_NM
        END AS LANG_EMP_NM
INTO   d_return
FROM   TB_WSF_EMP_M E
WHERE   E.EMP_NO = P_USER_ID_NO
  AND   E.USE_YN = 'Y';
END IF;

EXCEPTION
        WHEN NO_DATA_FOUND THEN
            NULL;
END;
RETURN d_return;
END;
$$;

alter function fn_get_user_nm(varchar, varchar, varchar) owner to developer;

create or replace function fn_get_local_time_s(p_timezne character varying, p_datetime character varying, p_format character varying) returns character varying
	language plpgsql
as $$
/*******************************************************************************
 * Project      : WSF
 * Module       : CMN
 * Program Name : FN_GET_LOCAL_TIME_S
 * Description  : datetime - timezone 으로 return
 * Paramata     :
 * Program History
 *------------------------------------------------------------------------------
 *  Date    		In Charge          Description
 *------------------------------------------------------------------------------
 *  2023-05-15  최초작성
  *******************************************************************************/
DECLARE
d_return     VARCHAR(100);
    v_timezone   VARCHAR(100);
    v_optval4    VARCHAR(100);
    v_optval5    VARCHAR(100);
    v_optval6    VARCHAR(100);
    v_optval7    VARCHAR(100);
    v_optval8    VARCHAR(100);
    v_optval9    VARCHAR(100);
    v_optval10   VARCHAR(100);
    v_sSTime     VARCHAR(100); -- 시작 서머타임
    v_eSTime     VARCHAR(100); -- 종료 서머타임
    v_Year       VARCHAR(4);
    err_code   VARCHAR (1024);
    err_msg    VARCHAR (1024);

BEGIN

    d_return := NULL;

BEGIN
        IF P_DATETIME IS NULL THEN
            RETURN NULL;
END IF;

        IF P_TIMEZNE IS NULL  THEN
            v_timezone := 'GMT000000009';   -- 없으면 한국값으로
else
            v_timezone := P_TIMEZNE;
END IF;
        /* 타임존 별 서머타임 정보 가져오기 */

SELECT C.OPT_VAL_CTN4
     ,C.OPT_VAL_CTN5
     ,C.OPT_VAL_CTN6
     ,C.OPT_VAL_CTN7
     ,C.OPT_VAL_CTN8
     ,C.OPT_VAL_CTN9
     ,C.OPT_VAL_CTN10
INTO v_optval4
    ,v_optval5
    ,v_optval6
    ,v_optval7
    ,v_optval8
    ,v_optval9
    ,v_optval10
FROM TB_WSF_CMN_GR_C G
         INNER JOIN TB_WSF_CMN_C C ON ( G.CMN_GR_CD   = C.CMN_GR_CD)
WHERE G.CMN_GR_CD='GPT_TMZ_CD'
  AND CMN_CD = v_timezone  ;

SELECT TO_CHAR(TO_DATE(P_DATETIME, 'YYYYMMDDHH24MISS')
                   +  TO_NUMBER(OPT_VAL_CTN1)/24 * ( CASE WHEN TO_NUMBER(OPT_VAL_CTN1) < 10  THEN 1 ELSE -1 END) , P_FORMAT )
INTO d_return
FROM TB_WSF_CMN_GR_C   G
         INNER JOIN TB_WSF_CMN_C C ON ( G.CMN_GR_CD   = C.CMN_GR_CD)
WHERE G.CMN_GR_CD='GPT_TMZ_CD'
  AND CMN_CD = v_timezone  ;

IF v_optval4 IS NOT NULL AND
           v_optval5 IS NOT NULL AND
           v_optval6 IS NOT NULL AND
           v_optval7 IS NOT NULL AND
           v_optval8 IS NOT NULL AND
           v_optval9 IS NOT NULL AND
           v_optval10 IS NOT NULL THEN

            v_Year := SUBSTR(d_return,1,4) ;

            /*시작일자 지정 월의 지정주차 일요일 */
SELECT TO_CHAR(FN_GET_NEXT_DAY(TRUNC(TO_DATE(v_Year||LPAD(v_optval4,2,'0')||'01' ,'YYYYMMDD')-1),1)+(TO_NUMBER(v_optval6)-1)*7,'YYYYMMDD')||REPLACE (v_optval7,':','') || '00'
INTO v_sSTime ;

/*종료일자 지정월의 지정주차 일요일*/
SELECT TO_CHAR(FN_GET_NEXT_DAY(TRUNC(TO_DATE(v_Year||LPAD(v_optval8,2,'0')||'01' ,'YYYYMMDD')-1),1)+(TO_NUMBER(v_optval9)-1)*7,'YYYYMMDD')||REPLACE (v_optval10,':','') || '00'
INTO v_eSTime;

IF d_return >=  v_sSTime AND  d_return <= v_eSTime  THEN  -- 타임존 적용
SELECT TO_CHAR(TO_DATE(d_return,'YYYYMMDDHH24MISS' ) + TO_NUMBER('1')/24  , P_FORMAT )
INTO d_return;
END IF;

END IF ;

EXCEPTION
        WHEN OTHERS THEN
            /***** 로그 확인용..
               에러 메시지 RETURN 시 app에서 오류 날 수 있음.
              ( err_code := SQLCODE;
              err_msg := SUBSTR (SQLERRM, 1, 200);
              d_return := err_code || SUBSTR (SQLERRM, 1, 200);
            ******/
            d_return := TO_CHAR ( current_date - 100,P_FORMAT );  -- 오류시 에러 일으키지 말고 100년전으로 회귀
END;
RETURN d_return;

END;
$$;

alter function fn_get_local_time_s(varchar, varchar, varchar) owner to developer;

create or replace function fn_get_message(p_msg_ctn character varying, p_lang_cd character varying) returns character varying
	language plpgsql
as $$
/*******************************************************************************
 * Project      : WSF
 * Module       : CMN
 * Program Name : FN_GET_MESSAGE
 * Description  : 다국어 메시지 조회
 * Program History
 *------------------------------------------------------------------------------
 *  Date        In Charge          Description
 *------------------------------------------------------------------------------
 *  2023-04-30                         최초작성
 *******************************************************************************/
DECLARE
d_return     VARCHAR(2000);
    v_lang_cd    VARCHAR(10);

BEGIN

    d_return := NULL;
    v_lang_cd := COALESCE(P_LANG_CD,'ko');

SELECT COALESCE(A.MSG_TXT_CTN, P_MSG_CTN)
INTO d_return
FROM TB_WSF_MSG_M A
WHERE A.MSG_CTN  = P_MSG_CTN
  AND A.LANG_CD  = v_lang_cd
;

RETURN d_return;

END;
$$;

alter function fn_get_message(varchar, varchar) owner to developer;

create or replace function fn_get_next_day(date_input date, weekday numeric) returns date
	language sql
as $$
/*******************************************************************************
 * Project      : WSF
 * Module       : CMN
 * Program Name : fn_get_next_day
 * Description  : Oracle NEXT_DAY Function을 구현 (date_input 이후에 첫번째 weekday 날짜를 리턴)
 * Parameter    :
    - date_input
    - weekday(1: SUN, 2: MON, 3: TUE, 4: WED, 5: THUR, 6: FRI, 7: SAT)
 * Program History
 *------------------------------------------------------------------------------
 *  Date    		In Charge          Description
 *------------------------------------------------------------------------------
 *  2024-08-14  최초작성
 *******************************************************************************/

SELECT $1::DATE + COALESCE(NULLIF((7 + ($2 - 1) - EXTRACT(DOW FROM $1::DATE))::INT % 7, 0), 7) AS result
$$;

alter function fn_get_next_day(date, numeric) owner to developer;

create or replace function fn_batch_emp() returns void
	language plpgsql
as $$
DECLARE
row_limit CONSTANT INTEGER := 100;
    row_offset INTEGER := 0;
    rec RECORD;
BEGIN
    LOOP
        FOR rec IN
SELECT
    *
FROM tb_wsf_hr_emp_i
WHERE (SSO_USER_ID != '' OR SSO_USER_ID IS NOT NULL)
  AND (DATE_OF_RETIRE = '' OR DATE_OF_RETIRE IS NULL)
  AND PERSON_TYPE != '퇴직자'
            LIMIT row_limit OFFSET row_offset
    LOOP
INSERT INTO TB_WSF_EMP_M (
                           USER_ID
                         ,EMP_NO
                         ,EMP_NM
                         ,EMP_ENG_NM
                         ,EMP_CNG_NM
                         ,DEPT_CD
                         ,DEPT_NM
                         ,DEPT_GR_CD
                         ,DEPT_ENG_NM
                         ,DEPT_CNG_NM
                         ,COP_CD
                         ,JTI_CD
                         ,JTI_NM
                         ,JTI_ENG_NM
                         ,JTI_CNG_NM
                         ,JPS_CD
                         ,JPS_NM
                         ,JPS_ENG_NM
                         ,JPS_CNG_NM
                         ,JCOM_DT
                         ,RSGN_DT
                         ,UPPR_EMP_NO
                         ,ONDU_REGN_CD
                         ,ONDU_REGN_NM
                         ,SSO_DTPL_NM
                         ,HME_TANO
                         ,HME_PHN
                         ,OFC_TANO
                         ,OFC_PHN
                         ,OFC_ETN_PHN
                         ,DOC_AUTH_CD
                         ,EML_SVR_DMN_IFO_NM
                         ,INO_DIVS_CD
                         ,EMP_HPHN
                         ,OLD_DEPT_CD
                         ,OLD_EMP_NO
                         ,DEPT_ENG_DESC
                         ,EMP_LOWR_GR_CD
                         ,EMP_UPPR_GR_CD
                         ,EML_DMN_IFO_NM
                         ,SSO_DTPL_CD
                         ,SSO_EMP_CNG_NM
                         ,CTRY_CD
                         ,SSO_CHG_TP_CD
                         ,SSO_CHG_DT
                         ,USE_YN
                         ,DATA_INS_USER_ID
                         ,DATA_INS_USER_IP
                         ,DATA_INS_DTM
                         ,DATA_UPD_USER_ID
                         ,DATA_UPD_USER_IP
                         ,DATA_UPD_DTM
                         ,INO_STAT_CD
) VALUES (
    rec.sso_user_id
        ,rec.employee_number
        ,rec.full_name
        ,rec.eng_name
        ,rec.chinese_name
        ,rec.organization_id::VARCHAR
        ,rec.organization_name
        ,rec.organization_code::VARCHAR
        ,COALESCE((SELECT DEPT_ENG_NM FROM TB_WSF_DEPT_M WHERE DEPT_CD = rec.organization_id::VARCHAR ), '')
        ,COALESCE((SELECT DEPT_CNG_NM FROM TB_WSF_DEPT_M WHERE DEPT_CD = rec.organization_id::VARCHAR ), '')
        ,'LGIT'||rec.subsidiary_code
        ,rec.position_code
        ,rec.position_name
        ,''
        ,''
        ,rec.grade_title_code
        ,rec.grade_title
        ,''
        ,''
        ,rec.date_of_hire
        ,rec.date_of_retire
        ,''
        ,rec.business_place_id
        ,rec.business_place_name
        ,rec.location_name
        ,''
        ,rec.telephone_number_1
        ,''
        ,rec.telephone_number_3
        ,''
        ,''
        ,''
        ,''
        ,rec.telephone_number_2
        ,''
        ,''
        ,''
        ,''
        ,''
        ,rec.email_address
        ,''
        ,''
        ,rec.subsidiary_code
        ,''
        ,''
        ,''
        ,'ADMIN'
        ,'0.0.0.0'
        ,CURRENT_TIMESTAMP
        ,'ADMIN'
        ,'0.0.0.0'
        ,CURRENT_TIMESTAMP
        ,''
    );
END LOOP;

        IF NOT FOUND THEN
            EXIT;
END IF;

        row_offset := row_offset + row_limit;
END LOOP;

    RAISE NOTICE 'SUCCESS';

END;

$$;

alter function fn_batch_emp() owner to developer;

create or replace function fn_get_user_info(p_user_id character varying, p_lang_cd character varying, p_disp_type numeric DEFAULT 1) returns character varying
	language plpgsql
as $$
DECLARE
V_RETURNVAL VARCHAR(2000);
BEGIN
    V_RETURNVAL := '';
BEGIN
        IF (P_DISP_TYPE = 1 ) THEN /*름( id/직급or 직책/팀)*/
SELECT
    CASE WHEN P_LANG_CD = 'ko'               THEN
             EMP_NM ||'(' || USER_ID || '/'||
             CASE
                 WHEN JPS_CD IS NULL THEN JTI_NM
                 ELSE JPS_NM
                 END
                 || '/' || D.DEPT_NM  ||')'
         WHEN P_LANG_CD IN ('zhC','zhT')  THEN
             EMP_CNG_NM ||'(' || USER_ID ||  '/'||
             CASE
                 WHEN JPS_CD IS NULL THEN JTI_CNG_NM
                 ELSE JPS_CNG_NM
                 END
                 || '/' || D.DEPT_CNG_NM || ')'
         WHEN P_LANG_CD IN ('en','pl')        THEN
             EMP_ENG_NM ||'(' || USER_ID ||  '/'||
             CASE
                 WHEN JPS_CD IS NULL THEN JTI_ENG_NM
                 ELSE JPS_ENG_NM
                 END
                 || '/' || D.DEPT_ENG_NM || ')'
         ELSE
             EMP_ENG_NM ||'(' || USER_ID ||  '/'||
             CASE
                 WHEN JPS_CD IS NULL THEN JTI_ENG_NM
                 ELSE JPS_ENG_NM
                 END
                 || '/' || D.DEPT_ENG_NM || ')'
        END AS USER_INFO
INTO V_RETURNVAL
FROM TB_WSF_EMP_M E
         INNER JOIN TB_WSF_DEPT_M D ON E.DEPT_CD = D.DEPT_CD
WHERE E.USER_ID = P_USER_ID
  AND E.USE_YN = 'Y';
ELSIF( P_DISP_TYPE = 2) THEN
SELECT
    CASE WHEN P_LANG_CD = 'ko'
             THEN EMP_NM ||'(' || USER_ID ||   ')'
         WHEN P_LANG_CD IN ('zh-CN','zh-TW')
             THEN CASE WHEN EMP_CNG_NM IS NULL
                           THEN EMP_ENG_NM
                       ELSE EMP_CNG_NM
                      END ||'(' || USER_ID ||  ')'
         WHEN P_LANG_CD IN ('en','pl')
             THEN CASE WHEN EMP_ENG_NM IS NULL
                           THEN EMP_NM
                       ELSE EMP_ENG_NM
                      END ||'(' || USER_ID ||  ')'
         ELSE EMP_ENG_NM ||'(' || USER_ID ||  ')'
        END AS USER_INFO
INTO V_RETURNVAL
FROM TB_WSF_EMP_M E
         INNER JOIN TB_WSF_DEPT_M D ON E.DEPT_CD = D.DEPT_CD
WHERE E.USER_ID = P_USER_ID
  AND E.USE_YN = 'Y';
END IF;
EXCEPTION
        WHEN NO_DATA_FOUND THEN
            V_RETURNVAL := '-';
END;
RETURN V_RETURNVAL;
END;
$$;

alter function fn_get_user_info(varchar, varchar, numeric) owner to developer;

create or replace function fn_batch_dept() returns void
	language plpgsql
as $$
DECLARE
row_limit CONSTANT INTEGER := 100;
    row_offset INTEGER := 0;
    rec RECORD;
BEGIN
    LOOP
        FOR rec IN
SELECT
    *
FROM TB_WSF_HR_DEPT_I
WHERE USE_FLAG = 'Y'
  AND (
    organization_code != parent_org_code
                    OR organization_code IS NULL
                    OR parent_org_code IS NULL
                    OR organization_code = ''
                    OR parent_org_code = ''
    )
  AND ((date_to = '' OR date_to is null) OR to_char(current_date, 'YYYYMMDD') || '000000' BETWEEN date_from AND date_to)
    LIMIT row_limit OFFSET row_offset
    LOOP
INSERT INTO TB_WSF_DEPT_M (
    ORG_ID,
    UPPR_ORG_ID,
    DEPT_CD,
    UPPR_DEPT_CD,
    COP_CD,
    DEPT_NM,
    DEPT_ENG_NM,
    DEPT_CNG_NM,
    TEM_LDR_USER_ID,
    USE_YN,
    DATA_INS_USER_ID,
    DATA_INS_USER_IP,
    DATA_INS_DTM,
    DATA_UPD_USER_ID,
    DATA_UPD_USER_IP,
    DATA_UPD_DTM,
    SORTCODE,
    DEPT_LV,
    DEPT_TYPE
) VALUES (
    rec.organization_id,
    rec.parent_org_id,
    rec.organization_code,
    rec.parent_org_code,
    'LGIT'||rec.subsidiary_code,
    rec.organization_name,
    CASE WHEN (rec.organization_ename IS NULL OR rec.organization_ename = '')
    THEN rec.organization_name
    ELSE rec.organization_ename
    END,
    CASE WHEN (rec.organization_ename IS NULL OR rec.organization_ename = '')
    THEN rec.organization_name
    ELSE rec.organization_ename
    END,
    rec.supervisor_number,
    rec.use_flag,
    'ADMIN',
    '0.0.0.0',
    CURRENT_TIMESTAMP,
    'ADMIN',
    '0.0.0.0',
    CURRENT_TIMESTAMP,
    rec.sortcode,
    rec.organization_level,
    rec.organization_type
    );
END LOOP;

        IF NOT FOUND THEN
            EXIT;
END IF;

        row_offset := row_offset + row_limit;
END LOOP;

    RAISE NOTICE 'SUCCESS';

END;

$$;

alter function fn_batch_dept() owner to developer;

