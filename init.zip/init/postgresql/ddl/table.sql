create table tb_wsf_msg_m
(
    msg_ctn          varchar(4000) not null,
    lang_cd          varchar(3)    not null,
    msg_txt_ctn      varchar(4000) not null,
    rmk              varchar(4000),
    opt_val_ctn1     varchar(4000),
    opt_val_ctn2     varchar(4000),
    opt_val_ctn3     varchar(4000),
    use_yn           varchar(1),
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP
);

comment on column tb_wsf_msg_m.msg_ctn is '메시지코드';

comment on column tb_wsf_msg_m.lang_cd is '언어코드';

comment on column tb_wsf_msg_m.msg_txt_ctn is '메시지명';

comment on column tb_wsf_msg_m.rmk is '비고';

comment on column tb_wsf_msg_m.opt_val_ctn1 is '옵션값내용1';

comment on column tb_wsf_msg_m.opt_val_ctn2 is '옵션값내용2';

comment on column tb_wsf_msg_m.opt_val_ctn3 is '옵션값내용3';

comment on column tb_wsf_msg_m.use_yn is '사용여부';

comment on column tb_wsf_msg_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_msg_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_msg_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_msg_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_msg_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_msg_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_msg_m
    owner to developer;

alter table tb_wsf_msg_m
    add constraint tb_wsf_msg_m_pk
        primary key (msg_ctn, lang_cd);

create table tb_wsf_menu_m
(
    mnu_id           varchar(50)   not null,
    mnu_nm           varchar(1000) not null,
    msg_ctn          varchar(4000),
    mnu_url          varchar(500),
    mnu_lv_no        numeric(10),
    uppr_mnu_id      varchar(50),
    sort_ord         numeric(10),
    mnu_eps_yn       varchar(1),
    use_yn           varchar(1),
    mnu_desc         varchar(200),
    mnu_opt_val_ctn1 varchar(500),
    mnu_opt_val_ctn2 varchar(500),
    mnu_opt_val_ctn3 varchar(500),
    mnu_opt_val_ctn4 varchar(500),
    mnu_opt_val_ctn5 varchar(500),
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP,
    internal_yn      varchar(1),
);

comment on column tb_wsf_menu_m.mnu_id is '메뉴아이디';

comment on column tb_wsf_menu_m.mnu_nm is '메뉴메시지코드';

comment on column tb_wsf_menu_m.mnu_url is '메뉴경로';

comment on column tb_wsf_menu_m.mnu_lv_no is '메뉴레벨';

comment on column tb_wsf_menu_m.uppr_mnu_id is '상위메뉴아이디';

comment on column tb_wsf_menu_m.sort_ord is '메뉴정렬순서번호';

comment on column tb_wsf_menu_m.mnu_eps_yn is '메뉴노출여부';

comment on column tb_wsf_menu_m.use_yn is '사용여부';

comment on column tb_wsf_menu_m.mnu_desc is '메뉴설명';

comment on column tb_wsf_menu_m.mnu_opt_val_ctn1 is '메뉴옵션값내용1';

comment on column tb_wsf_menu_m.mnu_opt_val_ctn2 is '메뉴옵션값내용2';

comment on column tb_wsf_menu_m.mnu_opt_val_ctn3 is '메뉴옵션값내용3';

comment on column tb_wsf_menu_m.mnu_opt_val_ctn4 is '메뉴옵션값내용4';

comment on column tb_wsf_menu_m.mnu_opt_val_ctn5 is '메뉴옵션값내용5';

comment on column tb_wsf_menu_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_menu_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_menu_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_menu_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_menu_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_menu_m.data_upd_dtm is '데이터수정일시';

comment on column tb_wsf_menu_m.internal_yn is '내부링크여부';

alter table tb_wsf_menu_m
    owner to developer;

alter table tb_wsf_menu_m
    add constraint tb_wsf_menu_m_pk
        primary key (mnu_id);

create table tb_wsf_cmn_gr_c
(
    cmn_gr_cd        varchar(50) not null,
    cmn_gr_cd_nm     varchar(50) not null,
    cmn_gr_cd_desc   varchar(1000),
    wkt_area_divs_cd varchar(50),
    msg_ctn          varchar(4000),
    sort_ord         numeric(10),
    opt_val_nm1      varchar(100),
    opt_val_nm2      varchar(100),
    opt_val_nm3      varchar(100),
    opt_val_nm4      varchar(100),
    opt_val_nm5      varchar(100),
    opt_val_nm6      varchar(100),
    opt_val_nm7      varchar(100),
    opt_val_nm8      varchar(100),
    opt_val_nm9      varchar(100),
    opt_val_nm10     varchar(100),
    opt_val_nm11     varchar(100),
    opt_val_nm12     varchar(100),
    opt_val_nm13     varchar(100),
    opt_val_nm14     varchar(100),
    opt_val_nm15     varchar(100),
    rmk              varchar(4000),
    use_yn           varchar(1),
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP
);

comment on column tb_wsf_cmn_gr_c.cmn_gr_cd is '공통그룹코드';

comment on column tb_wsf_cmn_gr_c.cmn_gr_cd_nm is '공통그룹코드명';

comment on column tb_wsf_cmn_gr_c.cmn_gr_cd_desc is '공통그룹코드설명';

comment on column tb_wsf_cmn_gr_c.wkt_area_divs_cd is '업무영역구분코드';

comment on column tb_wsf_cmn_gr_c.msg_ctn is '메세지내용';

comment on column tb_wsf_cmn_gr_c.sort_ord is '정렬순서';

comment on column tb_wsf_cmn_gr_c.opt_val_nm1 is '옵션값명1';

comment on column tb_wsf_cmn_gr_c.opt_val_nm2 is '옵션값명2';

comment on column tb_wsf_cmn_gr_c.opt_val_nm3 is '옵션값명3';

comment on column tb_wsf_cmn_gr_c.opt_val_nm4 is '옵션값명4';

comment on column tb_wsf_cmn_gr_c.opt_val_nm5 is '옵션값명5';

comment on column tb_wsf_cmn_gr_c.opt_val_nm6 is '옵션값명6';

comment on column tb_wsf_cmn_gr_c.opt_val_nm7 is '옵션값명7';

comment on column tb_wsf_cmn_gr_c.opt_val_nm8 is '옵션값명8';

comment on column tb_wsf_cmn_gr_c.opt_val_nm9 is '옵션값명9';

comment on column tb_wsf_cmn_gr_c.opt_val_nm10 is '옵션값명10';

comment on column tb_wsf_cmn_gr_c.opt_val_nm11 is '옵션값명11';

comment on column tb_wsf_cmn_gr_c.opt_val_nm12 is '옵션값명12';

comment on column tb_wsf_cmn_gr_c.opt_val_nm13 is '옵션값명13';

comment on column tb_wsf_cmn_gr_c.opt_val_nm14 is '옵션값명14';

comment on column tb_wsf_cmn_gr_c.opt_val_nm15 is '옵션값명15';

comment on column tb_wsf_cmn_gr_c.rmk is '비고';

comment on column tb_wsf_cmn_gr_c.use_yn is '사용여부';

comment on column tb_wsf_cmn_gr_c.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_cmn_gr_c.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_cmn_gr_c.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_cmn_gr_c.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_cmn_gr_c.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_cmn_gr_c.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_cmn_gr_c
    owner to developer;

alter table tb_wsf_cmn_gr_c
    add constraint tb_wsf_cmn_gr_c_pk
        primary key (cmn_gr_cd);

create table tb_wsf_cmn_c
(
    cmn_gr_cd        varchar(50)  not null,
    cmn_cd           varchar(150) not null,
    cmn_cd_nm        varchar(200) not null,
    cmn_cd_desc      varchar(400),
    uppr_cmn_cd      varchar(150),
    msg_ctn          varchar(4000),
    sort_ord         numeric(10),
    use_yn           varchar(1),
    opt_val_ctn1     varchar(4000),
    opt_val_ctn2     varchar(4000),
    opt_val_ctn3     varchar(4000),
    opt_val_ctn4     varchar(4000),
    opt_val_ctn5     varchar(4000),
    opt_val_ctn6     varchar(4000),
    opt_val_ctn7     varchar(4000),
    opt_val_ctn8     varchar(4000),
    opt_val_ctn9     varchar(4000),
    opt_val_ctn10    varchar(4000),
    opt_val_ctn11    varchar(4000),
    opt_val_ctn12    varchar(4000),
    opt_val_ctn13    varchar(4000),
    opt_val_ctn14    varchar(4000),
    opt_val_ctn15    varchar(4000),
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP
);

comment on column tb_wsf_cmn_c.cmn_gr_cd is '공통그룹코드';

comment on column tb_wsf_cmn_c.cmn_cd is '공통코드';

comment on column tb_wsf_cmn_c.cmn_cd_nm is '공통코드명';

comment on column tb_wsf_cmn_c.cmn_cd_desc is '공통코드설명';

comment on column tb_wsf_cmn_c.uppr_cmn_cd is '상위공통코드';

comment on column tb_wsf_cmn_c.msg_ctn is '메세지내용';

comment on column tb_wsf_cmn_c.sort_ord is '정렬순서';

comment on column tb_wsf_cmn_c.use_yn is '사용여부';

comment on column tb_wsf_cmn_c.opt_val_ctn1 is '옵션값내용1';

comment on column tb_wsf_cmn_c.opt_val_ctn2 is '옵션값내용2';

comment on column tb_wsf_cmn_c.opt_val_ctn3 is '옵션값내용3';

comment on column tb_wsf_cmn_c.opt_val_ctn4 is '옵션값내용4';

comment on column tb_wsf_cmn_c.opt_val_ctn5 is '옵션값내용5';

comment on column tb_wsf_cmn_c.opt_val_ctn6 is '옵션값내용6';

comment on column tb_wsf_cmn_c.opt_val_ctn7 is '옵션값내용7';

comment on column tb_wsf_cmn_c.opt_val_ctn8 is '옵션값내용8';

comment on column tb_wsf_cmn_c.opt_val_ctn9 is '옵션값내용9';

comment on column tb_wsf_cmn_c.opt_val_ctn10 is '옵션값내용10';

comment on column tb_wsf_cmn_c.opt_val_ctn11 is '옵션값내용11';

comment on column tb_wsf_cmn_c.opt_val_ctn12 is '옵션값내용12';

comment on column tb_wsf_cmn_c.opt_val_ctn13 is '옵션값내용13';

comment on column tb_wsf_cmn_c.opt_val_ctn14 is '옵션값내용14';

comment on column tb_wsf_cmn_c.opt_val_ctn15 is '옵션값내용15';

comment on column tb_wsf_cmn_c.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_cmn_c.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_cmn_c.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_cmn_c.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_cmn_c.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_cmn_c.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_cmn_c
    owner to developer;

alter table tb_wsf_cmn_c
    add constraint tb_wsf_cmn_c_pk
        primary key (cmn_gr_cd, cmn_cd);

create table tb_wsf_ntdk_m
(
    ntdk_id          numeric(10) not null,
    ntdk_nm          varchar(200),
    ntdk_desc        varchar(200),
    use_yn           varchar(1),
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP
);

comment on column tb_wsf_ntdk_m.ntdk_id is '통보처아이디';

comment on column tb_wsf_ntdk_m.ntdk_nm is '통보처제목';

comment on column tb_wsf_ntdk_m.ntdk_desc is '통보처설명';

comment on column tb_wsf_ntdk_m.use_yn is '사용여부';

comment on column tb_wsf_ntdk_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_ntdk_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_ntdk_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_ntdk_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_ntdk_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_ntdk_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_ntdk_m
    owner to developer;

alter table tb_wsf_ntdk_m
    add constraint tb_wsf_ntdk_m_pk
        primary key (ntdk_id);

create table tb_wsf_ntdk_d
(
    ntdk_id          numeric(10) not null,
    ntdk_seq         numeric(18) not null,
    ntdk_divs_cd     varchar(50),
    apr_notf_user_id varchar(50) not null,
    sort_ord         numeric(10),
    use_yn           varchar(1),
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP
);

comment on table tb_wsf_ntdk_d is '통보처상세';

comment on column tb_wsf_ntdk_d.ntdk_id is '통보처ID';

comment on column tb_wsf_ntdk_d.ntdk_seq is '통보처순번';

comment on column tb_wsf_ntdk_d.ntdk_divs_cd is '통보처구분코드';

comment on column tb_wsf_ntdk_d.apr_notf_user_id is '결재통보사용자ID';

comment on column tb_wsf_ntdk_d.sort_ord is '정렬순서';

comment on column tb_wsf_ntdk_d.use_yn is '사용여부';

comment on column tb_wsf_ntdk_d.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_ntdk_d.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_ntdk_d.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_ntdk_d.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_ntdk_d.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_ntdk_d.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_ntdk_d
    owner to developer;

alter table tb_wsf_ntdk_d
    add constraint tb_wsf_ntdk_d_pk
        primary key (ntdk_id, ntdk_seq);

create table tb_wsf_apr_rule_m
(
    apr_rule_id          varchar(50)  not null,
    apr_rule_nm          varchar(100) not null,
    apr_ln_add_pmit_yn   varchar(1)   not null,
    apr_rfer_add_psbl_yn varchar(1)   not null,
    apr_ln_rstb_pmit_yn  varchar(1)   not null,
    apr_ln_dupl_pmit_yn  varchar(1)   not null,
    apr_exc_tgt_id       varchar(50),
    mst_ntdk_id          numeric(10),
    data_ins_user_id     varchar(50),
    data_ins_user_ip     varchar(40),
    data_ins_dtm         timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id     varchar(50),
    data_upd_user_ip     varchar(40),
    data_upd_dtm         timestamp default CURRENT_TIMESTAMP,
    mst_ntdk_dept_id     numeric(10)
);

comment on table tb_wsf_apr_rule_m is '결재규칙기본';

comment on column tb_wsf_apr_rule_m.apr_rule_id is '결재규칙ID';

comment on column tb_wsf_apr_rule_m.apr_rule_nm is '결재규칙명';

comment on column tb_wsf_apr_rule_m.apr_ln_add_pmit_yn is '결재라인추가허용여부';

comment on column tb_wsf_apr_rule_m.apr_rfer_add_psbl_yn is '결재참조자추가가능여부';

comment on column tb_wsf_apr_rule_m.apr_ln_rstb_pmit_yn is '결재라인재설정허용여부';

comment on column tb_wsf_apr_rule_m.apr_ln_dupl_pmit_yn is '결재라인중복허용여부';

comment on column tb_wsf_apr_rule_m.apr_exc_tgt_id is '결재제외ID';

comment on column tb_wsf_apr_rule_m.mst_ntdk_id is '기본통보처ID';

comment on column tb_wsf_apr_rule_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_apr_rule_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_apr_rule_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_apr_rule_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_apr_rule_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_apr_rule_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_apr_rule_m
    owner to developer;

alter table tb_wsf_apr_rule_m
    add constraint tb_wsf_apr_rule_m_pk
        primary key (apr_rule_id);

create table tb_wsf_apr_rule_d
(
    apr_rule_id        varchar(50) not null,
    apr_ln_id          varchar(30) not null,
    apr_tp_divs_cd     varchar(20),
    prl_yn             varchar(1),
    apr_ln_snb         numeric(18, 5),
    apr_ln_seq         numeric(18),
    apr_ln_role_cd     varchar(10),
    dept_cd            varchar(20),
    user_id            varchar(50),
    apr_ln_chg_psbl_yn varchar(1),
    apr_ln_del_psbl_yn varchar(1),
    data_ins_user_id   varchar(50),
    data_ins_user_ip   varchar(40),
    data_ins_dtm       timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id   varchar(50),
    data_upd_user_ip   varchar(40),
    data_upd_dtm       timestamp default CURRENT_TIMESTAMP
);

comment on table tb_wsf_apr_rule_d is '결재규칙상세';

comment on column tb_wsf_apr_rule_d.apr_rule_id is '결재규칙ID';

comment on column tb_wsf_apr_rule_d.apr_ln_id is '결재라인ID';

comment on column tb_wsf_apr_rule_d.apr_tp_divs_cd is '결재유형구분코드';

comment on column tb_wsf_apr_rule_d.prl_yn is '병렬여부';

comment on column tb_wsf_apr_rule_d.apr_ln_snb is '결재라인차수';

comment on column tb_wsf_apr_rule_d.apr_ln_seq is '결재라인순번';

comment on column tb_wsf_apr_rule_d.apr_ln_role_cd is '결재라인역할코드';

comment on column tb_wsf_apr_rule_d.dept_cd is '부서코드';

comment on column tb_wsf_apr_rule_d.user_id is '사용자ID';

comment on column tb_wsf_apr_rule_d.apr_ln_chg_psbl_yn is '결재라인변경가능여부';

comment on column tb_wsf_apr_rule_d.apr_ln_del_psbl_yn is '결재라인삭제가능여부';

comment on column tb_wsf_apr_rule_d.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_apr_rule_d.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_apr_rule_d.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_apr_rule_d.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_apr_rule_d.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_apr_rule_d.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_apr_rule_d
    owner to developer;

alter table tb_wsf_apr_rule_d
    add constraint tb_wsf_apr_rule_d_pk
        primary key (apr_rule_id, apr_ln_id);

create table tb_wsf_apr_rule_exc_m
(
    apr_exc_tgt_id   varchar(50) not null,
    apr_exc_nm       varchar(20),
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP
);

comment on table tb_wsf_apr_rule_exc_m is '결재규칙제외기본';

comment on column tb_wsf_apr_rule_exc_m.apr_exc_tgt_id is '결재제외대상ID';

comment on column tb_wsf_apr_rule_exc_m.apr_exc_nm is '결재제외명';

comment on column tb_wsf_apr_rule_exc_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_apr_rule_exc_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_apr_rule_exc_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_apr_rule_exc_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_apr_rule_exc_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_apr_rule_exc_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_apr_rule_exc_m
    owner to developer;

alter table tb_wsf_apr_rule_exc_m
    add constraint tb_wsf_apr_rule_exc_m_pk
        primary key (apr_exc_tgt_id);

create table tb_wsf_apr_rule_exc_d
(
    apr_exc_tgt_id   varchar(50) not null,
    apr_exc_seq      numeric(18) not null,
    apr_exc_divs_cd  varchar(20) not null,
    apr_exc_user_id  varchar(50),
    apr_exc_jti_cd   varchar(10),
    apr_exc_jps_cd   varchar(10),
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP
);

comment on table tb_wsf_apr_rule_exc_d is '결재규칙제외상세';

comment on column tb_wsf_apr_rule_exc_d.apr_exc_tgt_id is '결재제외대상ID';

comment on column tb_wsf_apr_rule_exc_d.apr_exc_seq is '결재제외순번';

comment on column tb_wsf_apr_rule_exc_d.apr_exc_divs_cd is '결재제외구분코드(직급, 직책, 사용자)';

comment on column tb_wsf_apr_rule_exc_d.apr_exc_user_id is '결재제외사용자ID';

comment on column tb_wsf_apr_rule_exc_d.apr_exc_jti_cd is '결재제외직위코드';

comment on column tb_wsf_apr_rule_exc_d.apr_exc_jps_cd is '결재제외직책코드';

comment on column tb_wsf_apr_rule_exc_d.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_apr_rule_exc_d.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_apr_rule_exc_d.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_apr_rule_exc_d.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_apr_rule_exc_d.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_apr_rule_exc_d.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_apr_rule_exc_d
    owner to developer;

alter table tb_wsf_apr_rule_exc_d
    add constraint tb_wsf_apr_rule_exc_d_pk
        primary key (apr_exc_tgt_id, apr_exc_seq);

create table tb_wsf_atch_file_m
(
    atch_file_gr_id            varchar(50) not null,
    atch_file_id               varchar(50) not null,
    atch_file_nm               varchar(500),
    sort_ord                   numeric(10),
    atch_file_save_loc_divs_cd varchar(20),
    atch_file_save_nm          varchar(500),
    atch_file_size             numeric,
    atch_file_efnm_nm          varchar(100),
    atch_file_save_path_ctn    varchar(4000),
    atch_file_tp_cd            varchar(20),
    opt_val_ctn1               varchar(4000),
    opt_val_ctn2               varchar(4000),
    opt_val_ctn3               varchar(4000),
    opt_val_ctn4               varchar(4000),
    opt_val_ctn5               varchar(4000),
    use_yn                     varchar(1),
    data_ins_user_id           varchar(50),
    data_ins_user_ip           varchar(40),
    data_ins_dtm               timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id           varchar(50),
    data_upd_user_ip           varchar(40),
    data_upd_dtm               timestamp default CURRENT_TIMESTAMP
);

comment on column tb_wsf_atch_file_m.atch_file_gr_id is '첨부파일그룹ID';

comment on column tb_wsf_atch_file_m.atch_file_id is '첨부파일ID';

comment on column tb_wsf_atch_file_m.atch_file_nm is '첨부파일명';

comment on column tb_wsf_atch_file_m.sort_ord is '정렬순서';

comment on column tb_wsf_atch_file_m.atch_file_save_loc_divs_cd is '첨부파일저장위치구분코드';

comment on column tb_wsf_atch_file_m.atch_file_save_nm is '첨부파일저장명';

comment on column tb_wsf_atch_file_m.atch_file_size is '첨부파일크기';

comment on column tb_wsf_atch_file_m.atch_file_efnm_nm is '첨부파일확장자명';

comment on column tb_wsf_atch_file_m.atch_file_save_path_ctn is '첨부파일저장경로내용';

comment on column tb_wsf_atch_file_m.atch_file_tp_cd is '첨부파일유형코드';

comment on column tb_wsf_atch_file_m.opt_val_ctn1 is '옵션값내용1';

comment on column tb_wsf_atch_file_m.opt_val_ctn2 is '옵션값내용2';

comment on column tb_wsf_atch_file_m.opt_val_ctn3 is '옵션값내용3';

comment on column tb_wsf_atch_file_m.opt_val_ctn4 is '옵션값내용4';

comment on column tb_wsf_atch_file_m.opt_val_ctn5 is '옵션값내용5';

comment on column tb_wsf_atch_file_m.use_yn is '사용여부';

comment on column tb_wsf_atch_file_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_atch_file_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_atch_file_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_atch_file_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_atch_file_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_atch_file_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_atch_file_m
    owner to developer;

alter table tb_wsf_atch_file_m
    add constraint tb_wsf_atch_file_m_pk
        primary key (atch_file_gr_id, atch_file_id);

create table tb_wsf_role_m
(
    role_cd          varchar(20) not null,
    role_nm          varchar(400),
    role_desc        varchar(4000),
    use_yn           varchar(1),
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP,
    itgr_yn          varchar(1)
);

comment on column tb_wsf_role_m.role_cd is '역할코드';

comment on column tb_wsf_role_m.role_nm is '역할명';

comment on column tb_wsf_role_m.role_desc is '역할설명';

comment on column tb_wsf_role_m.use_yn is '사용여부';

comment on column tb_wsf_role_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_role_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_role_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_role_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_role_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_role_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_role_m
    owner to developer;

alter table tb_wsf_role_m
    add constraint tb_wsf_role_m_pk
        primary key (role_cd);

create table tb_wsf_role_menu_m
(
    role_cd          varchar(20) not null,
    mnu_id           varchar(50) not null,
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP
);

comment on column tb_wsf_role_menu_m.role_cd is '역할코드';

comment on column tb_wsf_role_menu_m.mnu_id is '메뉴ID';

comment on column tb_wsf_role_menu_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_role_menu_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_role_menu_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_role_menu_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_role_menu_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_role_menu_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_role_menu_m
    owner to developer;

alter table tb_wsf_role_menu_m
    add constraint tb_wsf_role_menu_m_pk
        primary key (role_cd, mnu_id);

create table tb_wsf_role_emp_m
(
    role_cd          varchar(20) not null,
    user_id          varchar(50) not null,
    emp_no           varchar(30) not null,
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP
);

comment on column tb_wsf_role_emp_m.role_cd is '역할코드';

comment on column tb_wsf_role_emp_m.user_id is '사용자ID';

comment on column tb_wsf_role_emp_m.emp_no is '사용자사번';

comment on column tb_wsf_role_emp_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_role_emp_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_role_emp_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_role_emp_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_role_emp_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_role_emp_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_role_emp_m
    owner to developer;

alter table tb_wsf_role_emp_m
    add constraint tb_wsf_role_emp_m_pk
        primary key (role_cd, user_id, emp_no);

create table tb_wsf_api_m_back
(
    api_id           varchar(50) not null,
    api_nm           varchar(100),
    api_url          varchar(500),
    use_yn           varchar(1),
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP,
    http_mthd_cd     varchar(50)
);

comment on column tb_wsf_api_m_back.api_id is 'API ID';

comment on column tb_wsf_api_m_back.api_nm is 'API명';

comment on column tb_wsf_api_m_back.api_url is 'APIURL주소';

comment on column tb_wsf_api_m_back.use_yn is '사용여부';

comment on column tb_wsf_api_m_back.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_api_m_back.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_api_m_back.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_api_m_back.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_api_m_back.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_api_m_back.data_upd_dtm is '데이터수정일시';

comment on column tb_wsf_api_m_back.http_mthd_cd is 'HTTP방법코드';

alter table tb_wsf_api_m_back
    owner to developer;

alter table tb_wsf_api_m_back
    add constraint tb_wsf_api_m_pk
        primary key (api_id);

create table tb_wsf_role_api_m
(
    role_cd          varchar(20) not null,
    api_id           varchar(50) not null,
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP
);

comment on column tb_wsf_role_api_m.role_cd is 'API ID';

comment on column tb_wsf_role_api_m.api_id is 'API ID';

comment on column tb_wsf_role_api_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_role_api_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_role_api_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_role_api_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_role_api_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_role_api_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_role_api_m
    owner to developer;

alter table tb_wsf_role_api_m
    add constraint tb_wsf_role_api_m_pk
        primary key (role_cd, api_id);

create table tb_wsf_role_dept_m
(
    role_cd          varchar(20) not null,
    dept_cd          varchar(20) not null,
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP
);

comment on column tb_wsf_role_dept_m.role_cd is '역할코드';

comment on column tb_wsf_role_dept_m.dept_cd is '부서코드';

comment on column tb_wsf_role_dept_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_role_dept_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_role_dept_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_role_dept_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_role_dept_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_role_dept_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_role_dept_m
    owner to developer;

alter table tb_wsf_role_dept_m
    add constraint tb_wsf_role_dept_m_pk
        primary key (role_cd, dept_cd);

create table tb_wsf_bbs_m
(
    bbs_no            varchar(10) not null,
    bbs_tp_cd         varchar(10),
    bbs_sort_ord      numeric,
    bbs_title         varchar(300),
    bbs_ctn           clob,
    smry_ctn          varchar(4000),
    atch_file_gr_id   varchar(50),
    htag_ctn          varchar(300),
    impt_yn           varchar(1),
    use_yn            varchar(1),
    bbs_vwct          numeric,
    ptup_end_dt       varchar(50),
    noti_use_yn       varchar(1),
    poup_use_yn       varchar(1),
    poup_st_dtm       timestamp,
    poup_end_dtm      timestamp,
    poup_eps_nuse_ddn numeric(7),
    bbm_clsf_cd       varchar(50),
    ptup_tgt_cop_cd   varchar(10),
    data_ins_user_id  varchar(50),
    data_ins_user_ip  varchar(40),
    data_ins_dtm      timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id  varchar(50),
    data_upd_user_ip  varchar(40),
    data_upd_dtm      timestamp default CURRENT_TIMESTAMP,
    prnt_re_bbs_no    varchar(10),
    re_bbs_yn         varchar(10)
);

comment on table tb_wsf_bbs_m is '게시판기본';

comment on column tb_wsf_bbs_m.bbs_no is '게시글번호';

comment on column tb_wsf_bbs_m.bbs_tp_cd is '게시판유형코드';

comment on column tb_wsf_bbs_m.bbs_sort_ord is '게시글정렬순서';

comment on column tb_wsf_bbs_m.bbs_title is '게시글제목명';

comment on column tb_wsf_bbs_m.bbs_ctn is '게시글내용';

comment on column tb_wsf_bbs_m.smry_ctn is '요약내용';

comment on column tb_wsf_bbs_m.atch_file_gr_id is '첨부파일그룹ID';

comment on column tb_wsf_bbs_m.htag_ctn is '해시태그내용';

comment on column tb_wsf_bbs_m.impt_yn is '중요여부';

comment on column tb_wsf_bbs_m.use_yn is '사용여부';

comment on column tb_wsf_bbs_m.bbs_vwct is '게시글조회수';

comment on column tb_wsf_bbs_m.ptup_end_dt is '게시종료일자';

comment on column tb_wsf_bbs_m.noti_use_yn is '공지사용여부';

comment on column tb_wsf_bbs_m.poup_use_yn is '팝업사용여부';

comment on column tb_wsf_bbs_m.poup_st_dtm is '팝업시작일시';

comment on column tb_wsf_bbs_m.poup_end_dtm is '팝업종료일시';

comment on column tb_wsf_bbs_m.poup_eps_nuse_ddn is '팝업노출미사용일수';

comment on column tb_wsf_bbs_m.bbm_clsf_cd is '게시글분류코드';

comment on column tb_wsf_bbs_m.ptup_tgt_cop_cd is '게시대상법인코드';

comment on column tb_wsf_bbs_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_bbs_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_bbs_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_bbs_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_bbs_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_bbs_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_bbs_m
    owner to developer;

alter table tb_wsf_bbs_m
    add constraint tb_wsf_bbs_m_pk
        primary key (bbs_no);

create table tb_wsf_bbs_re_d
(
    bbs_no           varchar(10)   not null,
    bbs_re_no        varchar(10)   not null,
    bbs_re_ctn       varchar(1000) not null,
    del_yn           varchar(1)    not null,
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP,
    prnt_re_no       varchar(10)
);

comment on table tb_wsf_bbs_re_d is '게시판댓글상세';

comment on column tb_wsf_bbs_re_d.bbs_no is '게시글번호';

comment on column tb_wsf_bbs_re_d.bbs_re_no is '게시글댓글번호';

comment on column tb_wsf_bbs_re_d.bbs_re_ctn is '게시글댓글내용';

comment on column tb_wsf_bbs_re_d.del_yn is '댓글삭제여부';

comment on column tb_wsf_bbs_re_d.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_bbs_re_d.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_bbs_re_d.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_bbs_re_d.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_bbs_re_d.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_bbs_re_d.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_bbs_re_d
    owner to developer;

alter table tb_wsf_bbs_re_d
    add constraint tb_wsf_bbs_re_d_pk
        primary key (bbs_no, bbs_re_no);

create table tb_wsf_dt_m
(
    cop_cd           varchar(10) not null,
    scal_dt          varchar(8)  not null,
    scal_yy          varchar(4),
    scal_mm          varchar(2),
    scal_dd          varchar(2),
    lcal_dt          varchar(8),
    dywk_no_cd       varchar(1),
    yywk             varchar(6),
    mm_wct           numeric(3),
    hldy_yn          varchar(1),
    hldy_nm          varchar(30),
    opt_val_nm1      varchar(100),
    opt_val_nm2      varchar(100),
    opt_val_nm3      varchar(100),
    opt_val_nm4      varchar(100),
    opt_val_nm5      varchar(100),
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP
);

comment on table tb_wsf_dt_m is '날짜기본';

comment on column tb_wsf_dt_m.cop_cd is '법인코드';

comment on column tb_wsf_dt_m.scal_dt is '양력일자';

comment on column tb_wsf_dt_m.scal_yy is '양력년도';

comment on column tb_wsf_dt_m.scal_mm is '양력월';

comment on column tb_wsf_dt_m.scal_dd is '양력일';

comment on column tb_wsf_dt_m.lcal_dt is '음력일자';

comment on column tb_wsf_dt_m.dywk_no_cd is '요일번호코드';

comment on column tb_wsf_dt_m.yywk is '년주차수';

comment on column tb_wsf_dt_m.mm_wct is '월주차수';

comment on column tb_wsf_dt_m.hldy_yn is '휴일여부';

comment on column tb_wsf_dt_m.hldy_nm is '휴일명';

comment on column tb_wsf_dt_m.opt_val_nm1 is '옵션값명1';

comment on column tb_wsf_dt_m.opt_val_nm2 is '옵션값명2';

comment on column tb_wsf_dt_m.opt_val_nm3 is '옵션값명3';

comment on column tb_wsf_dt_m.opt_val_nm4 is '옵션값명4';

comment on column tb_wsf_dt_m.opt_val_nm5 is '옵션값명5';

comment on column tb_wsf_dt_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_dt_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_dt_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_dt_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_dt_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_dt_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_dt_m
    owner to developer;

alter table tb_wsf_dt_m
    add constraint tb_wsf_dt_m_pk
        primary key (cop_cd, scal_dt);

create table tb_wsf_eml_sndo_log_m
(
    eml_sndo_seq     numeric(18)   not null,
    eml_log_seq      numeric(18)   not null,
    eml_tp_cd        varchar(20),
    eml_tit_nm       varchar(100),
    eml_rcvr_lst_ctn varchar(4000) not null,
    sed_emal         varchar(100)  not null,
    sed_dtm          timestamp     not null,
    eml_trnm_stat_cd varchar(20),
    eml_trnm_rlt_ctn varchar(200),
    eml_bdy_ctn      varchar(4000),
    apr_req_id       varchar(50),
    opt_val_nm1      varchar(100),
    opt_val_nm2      varchar(100),
    opt_val_nm3      varchar(100),
    opt_val_nm4      varchar(100),
    opt_val_nm5      varchar(100),
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP
);

comment on table tb_wsf_eml_sndo_log_m is '메일발송로그기본';

comment on column tb_wsf_eml_sndo_log_m.eml_sndo_seq is '이메일발송순번';

comment on column tb_wsf_eml_sndo_log_m.eml_log_seq is '이메일로그순번';

comment on column tb_wsf_eml_sndo_log_m.eml_tp_cd is '이메일유형코드';

comment on column tb_wsf_eml_sndo_log_m.eml_rcvr_lst_ctn is '이메일수신자목록내용';

comment on column tb_wsf_eml_sndo_log_m.sed_emal is '발신이메일주소';

comment on column tb_wsf_eml_sndo_log_m.sed_dtm is '발신일시';

comment on column tb_wsf_eml_sndo_log_m.eml_trnm_stat_cd is '이메일전송상태코드';

comment on column tb_wsf_eml_sndo_log_m.eml_trnm_rlt_ctn is '이메일전송결과내용';

comment on column tb_wsf_eml_sndo_log_m.eml_bdy_ctn is '이메일본문내용';

comment on column tb_wsf_eml_sndo_log_m.apr_req_id is '결재요청ID';

comment on column tb_wsf_eml_sndo_log_m.opt_val_nm1 is '옵션값명1';

comment on column tb_wsf_eml_sndo_log_m.opt_val_nm2 is '옵션값명2';

comment on column tb_wsf_eml_sndo_log_m.opt_val_nm3 is '옵션값명3';

comment on column tb_wsf_eml_sndo_log_m.opt_val_nm4 is '옵션값명4';

comment on column tb_wsf_eml_sndo_log_m.opt_val_nm5 is '옵션값명5';

comment on column tb_wsf_eml_sndo_log_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_eml_sndo_log_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_eml_sndo_log_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_eml_sndo_log_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_eml_sndo_log_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_eml_sndo_log_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_eml_sndo_log_m
    owner to developer;

create index tb_wsf_eml_sndo_log_m_ix01
    on tb_wsf_eml_sndo_log_m (sed_dtm);

alter table tb_wsf_eml_sndo_log_m
    add constraint tb_wsf_eml_sndo_log_m_pk
        primary key (eml_sndo_seq, eml_log_seq);

create table tb_wsf_logn_log_m
(
    cont_log_id      varchar(50)                         not null,
    cont_dtm         timestamp default CURRENT_TIMESTAMP not null,
    cont_user_id     varchar(50)                         not null,
    cont_ip          varchar(40),
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP
);

comment on column tb_wsf_logn_log_m.cont_log_id is '접속로그ID';

comment on column tb_wsf_logn_log_m.cont_dtm is '접속일시';

comment on column tb_wsf_logn_log_m.cont_user_id is '접속사용자ID';

comment on column tb_wsf_logn_log_m.cont_ip is '접속IP주소';

comment on column tb_wsf_logn_log_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_logn_log_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_logn_log_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_logn_log_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_logn_log_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_logn_log_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_logn_log_m
    owner to developer;

create index tb_wsf_logn_log_m_ix01
    on tb_wsf_logn_log_m (cont_dtm);

alter table tb_wsf_logn_log_m
    add constraint tb_wsf_logn_log_m_pk
        primary key (cont_log_id);

create table tb_wsf_mnu_aces_log_m
(
    aces_log_id      varchar(50)                         not null,
    mnu_id           varchar(50)                         not null,
    cont_dtm         timestamp default CURRENT_TIMESTAMP not null,
    cont_user_id     varchar(50),
    cont_ip          varchar(40),
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP
);

comment on column tb_wsf_mnu_aces_log_m.aces_log_id is '접근로그ID';

comment on column tb_wsf_mnu_aces_log_m.mnu_id is '메뉴ID';

comment on column tb_wsf_mnu_aces_log_m.cont_dtm is '접속일시';

comment on column tb_wsf_mnu_aces_log_m.cont_user_id is '접속사용자ID';

comment on column tb_wsf_mnu_aces_log_m.cont_ip is '접속IP주소';

comment on column tb_wsf_mnu_aces_log_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_mnu_aces_log_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_mnu_aces_log_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_mnu_aces_log_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_mnu_aces_log_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_mnu_aces_log_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_mnu_aces_log_m
    owner to developer;

create index tb_wsf_mnu_aces_log_m_ix01
    on tb_wsf_mnu_aces_log_m (cont_dtm);

create index tb_wsf_mnu_aces_log_m_ix02
    on tb_wsf_mnu_aces_log_m (cont_user_id);

create index tb_wsf_mnu_aces_log_m_ix03
    on tb_wsf_mnu_aces_log_m (cont_ip);

alter table tb_wsf_mnu_aces_log_m
    add constraint tb_wsf_mnu_aces_log_m_pk
        primary key (aces_log_id);

create table tb_wsf_if_log_m
(
    if_log_seq       numeric(22) not null,
    if_log_dtm       timestamp   not null,
    if_nm            varchar(300),
    if_divs_cd       varchar(20),
    if_trmt_val_ctn  clob,
    if_rest_val_ctn  clob,
    opt_val_nm1      varchar(100),
    opt_val_nm2      varchar(100),
    opt_val_nm3      varchar(100),
    opt_val_nm4      varchar(100),
    opt_val_nm5      varchar(100),
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP
);

comment on table tb_wsf_if_log_m is '인터페이스로그기본';

comment on column tb_wsf_if_log_m.if_log_seq is '인터페이스로그순번';

comment on column tb_wsf_if_log_m.if_log_dtm is '인터페이스로그일시';

comment on column tb_wsf_if_log_m.if_nm is '인터페이스명';

comment on column tb_wsf_if_log_m.if_divs_cd is '인터페이스구분코드';

comment on column tb_wsf_if_log_m.if_trmt_val_ctn is '인터페이스송신값내용';

comment on column tb_wsf_if_log_m.if_rest_val_ctn is '인터페이스수신값내용';

comment on column tb_wsf_if_log_m.opt_val_nm1 is '옵션값명1';

comment on column tb_wsf_if_log_m.opt_val_nm2 is '옵션값명2';

comment on column tb_wsf_if_log_m.opt_val_nm3 is '옵션값명3';

comment on column tb_wsf_if_log_m.opt_val_nm4 is '옵션값명4';

comment on column tb_wsf_if_log_m.opt_val_nm5 is '옵션값명5';

comment on column tb_wsf_if_log_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_if_log_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_if_log_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_if_log_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_if_log_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_if_log_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_if_log_m
    owner to developer;

create index tb_wsf_if_log_m_ix01
    on tb_wsf_if_log_m (if_log_dtm);

alter table tb_wsf_if_log_m
    add constraint tb_wsf_if_log_m_pk
        primary key (if_log_seq);

create table tb_wsf_eml_sndo_que_m
(
    eml_sndo_seq     numeric(18)   not null,
    eml_tp_cd        varchar(20),
    eml_tit_nm       varchar(1000) not null,
    eml_rcvr_lst_ctn varchar(4000) not null,
    sed_emal         varchar(100)  not null,
    eml_sed_user_nm  varchar(100),
    sed_dtm          timestamp,
    eml_trnm_stat_cd varchar(20),
    eml_trnm_rlt_ctn varchar(200),
    eml_dtl_ctn      clob,
    apr_req_id       varchar(50),
    opt_val_nm1      varchar(100),
    opt_val_nm2      varchar(100),
    opt_val_nm3      varchar(100),
    opt_val_nm4      varchar(100),
    opt_val_nm5      varchar(100),
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP
);

comment on table tb_wsf_eml_sndo_que_m is '메일발송큐기본';

comment on column tb_wsf_eml_sndo_que_m.eml_sndo_seq is '이메일발송순번';

comment on column tb_wsf_eml_sndo_que_m.eml_tp_cd is '이메일유형코드';

comment on column tb_wsf_eml_sndo_que_m.eml_tit_nm is '이메일제목명';

comment on column tb_wsf_eml_sndo_que_m.eml_rcvr_lst_ctn is '이메일수신자목록내용';

comment on column tb_wsf_eml_sndo_que_m.sed_emal is '발신이메일주소';

comment on column tb_wsf_eml_sndo_que_m.eml_sed_user_nm is '이메일발신사용자명';

comment on column tb_wsf_eml_sndo_que_m.sed_dtm is '발신일시';

comment on column tb_wsf_eml_sndo_que_m.eml_trnm_stat_cd is '이메일전송상태코드';

comment on column tb_wsf_eml_sndo_que_m.eml_trnm_rlt_ctn is '이메일전송결과내용';

comment on column tb_wsf_eml_sndo_que_m.eml_dtl_ctn is '이메일상세내용';

comment on column tb_wsf_eml_sndo_que_m.apr_req_id is '결재요청ID';

comment on column tb_wsf_eml_sndo_que_m.opt_val_nm1 is '옵션값명1';

comment on column tb_wsf_eml_sndo_que_m.opt_val_nm2 is '옵션값명2';

comment on column tb_wsf_eml_sndo_que_m.opt_val_nm3 is '옵션값명3';

comment on column tb_wsf_eml_sndo_que_m.opt_val_nm4 is '옵션값명4';

comment on column tb_wsf_eml_sndo_que_m.opt_val_nm5 is '옵션값명5';

comment on column tb_wsf_eml_sndo_que_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_eml_sndo_que_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_eml_sndo_que_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_eml_sndo_que_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_eml_sndo_que_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_eml_sndo_que_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_eml_sndo_que_m
    owner to developer;

create index tb_wsf_eml_sndo_que_m_ix01
    on tb_wsf_eml_sndo_que_m (eml_trnm_rlt_ctn);

alter table tb_wsf_eml_sndo_que_m
    add constraint tb_wsf_eml_sndo_que_m_pk
        primary key (eml_sndo_seq);

create table tb_wsf_apr_dlgt_m
(
    apr_dlgt_no      numeric(20) not null,
    apr_dlgt_user_id varchar(50) not null,
    apr_dele_user_id varchar(50) not null,
    apr_dlgt_st_dt   varchar(8)  not null,
    apr_dlgt_end_dt  varchar(8)  not null,
    use_yn           varchar(1)  not null,
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP,
    apr_dlgt_emp_no  varchar(50),
    apr_dele_emp_no  varchar(50)
);

comment on table tb_wsf_apr_dlgt_m is '결재위임';

comment on column tb_wsf_apr_dlgt_m.apr_dlgt_no is '결재위임번호';

comment on column tb_wsf_apr_dlgt_m.apr_dlgt_user_id is '결재위임사용자ID';

comment on column tb_wsf_apr_dlgt_m.apr_dele_user_id is '결재수임사용자ID';

comment on column tb_wsf_apr_dlgt_m.apr_dlgt_st_dt is '결재위임시작일자';

comment on column tb_wsf_apr_dlgt_m.apr_dlgt_end_dt is '결재위임종료일자';

comment on column tb_wsf_apr_dlgt_m.use_yn is '사용여부';

comment on column tb_wsf_apr_dlgt_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_apr_dlgt_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_apr_dlgt_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_apr_dlgt_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_apr_dlgt_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_apr_dlgt_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_apr_dlgt_m
    owner to developer;

alter table tb_wsf_apr_dlgt_m
    add constraint tb_wsf_apr_dlgt_m_pk
        primary key (apr_dlgt_no);

create table tb_wsf_hr_dept_i
(
    seq_id              bigint,
    subsidiary_code     varchar(2),
    organization_id     bigint,
    organization_name   varchar(240),
    organization_code   varchar(150),
    parent_org_id       numeric(15),
    parent_org_name     varchar(240),
    parent_org_code     varchar(150),
    supervisor_number   varchar(30),
    supervisor_name     varchar(300),
    biz_place_id        bigint,
    biz_place_name      varchar(240),
    division_id         bigint,
    division_name       varchar(240),
    organization_type   varchar(50),
    date_from           varchar(14),
    date_to             varchar(14),
    sortcode            varchar(50),
    organization_level  varchar(5),
    organization_ename  varchar(240),
    location            varchar(50),
    use_flag            varchar(1),
    business_group_id   varchar(100),
    business_group_name varchar(100),
    eai_data_crud_cd    varchar(1),
    attribute1          varchar(240),
    attribute2          varchar(240),
    attribute3          varchar(240),
    attribute4          varchar(240),
    attribute5          varchar(240),
    attribute6          varchar(240),
    attribute7          varchar(240),
    attribute8          varchar(240),
    attribute9          varchar(240),
    attribute10         varchar(240),
    attribute11         varchar(240),
    attribute12         varchar(240),
    attribute13         varchar(240),
    attribute14         varchar(240),
    attribute15         varchar(240),
    attribute16         varchar(240),
    attribute17         varchar(240),
    attribute18         varchar(240),
    attribute19         varchar(240),
    creation_date       varchar(14),
    update_date         varchar(14),
    transfer_date11     varchar(14),
    transfer_flag11     varchar(5),
    data_ins_dtm        timestamp not null,
    transfer_flag       varchar(1),
    transfer_date       timestamp
);

alter table tb_wsf_hr_dept_i
    owner to developer;

create table tb_wsf_sso_auth_i
(
    eai_row_id         numeric(20),
    syscd              varchar(50),
    user_id            varchar(100),
    auth_lev_1         varchar(100),
    auth_lev_2         varchar(100),
    auth_lev_3         varchar(100),
    auth_lev_4         varchar(100),
    auth_lev_5         varchar(100),
    attribute2         varchar(100),
    attribute3         varchar(100),
    attribute4         varchar(100),
    attribute5         varchar(100),
    creation_date      varchar(14),
    eai_transfer_date5 varchar(14),
    eai_transfer_flag5 varchar(1),
    data_ins_dtm       timestamp not null,
    attribute1         varchar(100),
    transfer_flag      varchar(1),
    transfer_date      timestamp
);

alter table tb_wsf_sso_auth_i
    owner to developer;

create table tb_wsf_apr_col_dlg_i
(
    eai_row_id       numeric(22),
    eai_create_date  varchar(14),
    eai_data_crud_cd varchar(1),
    syscd            varchar(50),
    auth_lev_1       varchar(100),
    auth_lev_2       varchar(100),
    empno_from       varchar(20),
    empno_to         varchar(20),
    date_from        varchar(14),
    date_to          varchar(14),
    current_use      varchar(1),
    last_update_id   varchar(50),
    last_update_date varchar(14),
    data_ins_dtm     timestamp not null,
    transfer_flag    varchar(1),
    transfer_date    timestamp
);

alter table tb_wsf_apr_col_dlg_i
    owner to developer;

create table tb_wsf_hr_emp_i
(
    seq_id                    numeric(20),
    subsidiary_code           varchar(2),
    employee_number           text not null,
    effective_start_date      varchar(14),
    effective_end_date        varchar(14),
    assignment_status_type_id numeric(9),
    full_name                 text,
    email_address             text,
    jikgun                    text,
    sso_user_id               text,
    mail_action_update        varchar(14),
    original_date_of_hire     varchar(14),
    date_of_hire              varchar(14),
    position_code             text,
    position_name             text,
    job_title_code            text,
    job_title_name            text,
    grade_title_code          text,
    grade_title               text,
    person_type               text,
    date_of_suspend           varchar(14),
    date_of_retire            varchar(14),
    person_id                 numeric(10),
    organization_id           numeric(15),
    organization_code         text,
    organization_name         text,
    parent_org_id             numeric(15),
    parent_org_code           text,
    parent_org_name           text,
    division_id               numeric(15),
    division_name             text,
    jojik_manager             text,
    org_manager               text,
    business_place_id         numeric(15),
    business_place_name       text,
    chinese_name              text,
    eng_name                  text,
    telephone_number_1        text,
    telephone_number_2        text,
    telephone_number_3        text,
    date_of_marry             varchar(14),
    date_of_birth             varchar(14),
    ls_type                   text,
    marital_status            text,
    self_approve_flag         varchar(1),
    external_email            text,
    user_person_type          text,
    employee_category         text,
    establishment_id          numeric(15),
    establishment_name        text,
    postal_code               text,
    address_line1             text,
    address_line2             text,
    location_name             text,
    cost_biz                  text,
    cost_org                  text,
    cost_gubun                text,
    sso_password              text,
    fse_foreignsabun          varchar(10),
    other_action              text,
    sso_action                varchar(1),
    other_start_date          varchar(14),
    other_end_date            varchar(14),
    original_company          text,
    ehr_insert_flag           varchar(1),
    fse_flag                  varchar(1),
    fax_telephone_number_1    text,
    nickname                  text,
    person_sosrtcode          text,
    organization_nick_code    text,
    organization_nick_name    text,
    imsg_action_date          varchar(14),
    attribute1                text,
    attribute2                text,
    attribute3                text,
    attribute4                text,
    attribute5                text,
    attribute6                text,
    attribute7                text,
    attribute8                text,
    attribute9                text,
    attribute10               text,
    attribute11               text,
    attribute12               text,
    attribute13               text,
    attribute14               text,
    attribute15               text,
    attribute16               text,
    attribute17               text,
    attribute18               text,
    attribute19               text,
    attribute20               text,
    creation_date             varchar(14),
    last_update_date          varchar(14),
    transfer_flag11           varchar(1),
    transfer_date11           varchar(14),
    transfer_date             timestamp,
    transfer_flag             varchar(1),
    data_ins_dtm              timestamp,
    attribute24               text
);

alter table tb_wsf_hr_emp_i
    owner to developer;

create table tb_wsf_dept_m
(
    dept_cd          varchar(20) not null,
    cop_cd           varchar(10) not null,
    dept_gr_cd       varchar(50),
    uppr_dept_gr_cd  varchar(50),
    dept_nm          varchar(300),
    dept_eng_nm      varchar(300),
    dept_cng_nm      varchar(300),
    tem_ldr_user_id  varchar(50),
    uppr_dept_cd     varchar(20),
    use_yn           varchar(1),
    sortcode         varchar(30),
    dept_lv          varchar(5),
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP,
    dept_type        varchar(50),
    org_id           numeric(15),
    uppr_org_id      numeric(15)
);

alter table tb_wsf_dept_m
    owner to developer;

create table tb_wsf_emp_m
(
    user_id          varchar(50) not null,
    emp_no           varchar(30) not null,
    emp_nm           varchar(50),
    emp_eng_nm       varchar(100),
    emp_cng_nm       varchar(100),
    dept_cd          varchar(30),
    dept_nm          varchar(300),
    dept_eng_nm      varchar(300),
    dept_cng_nm      varchar(300),
    cop_cd           varchar(30),
    jti_cd           varchar(30),
    jti_nm           varchar(200),
    jti_eng_nm       varchar(50),
    jti_cng_nm       varchar(50),
    jps_cd           varchar(30),
    jps_nm           varchar(200),
    jps_eng_nm       varchar(50),
    jps_cng_nm       varchar(50),
    ino_stat_cd      varchar(30),
    jcom_dt          varchar(14),
    rsgn_dt          varchar(14),
    uppr_emp_no      varchar(30),
    ondu_regn_cd     varchar(50),
    ondu_regn_nm     varchar(50),
    sso_dtpl_nm      varchar(100),
    hme_tano         varchar(30),
    hme_phn          varchar(50),
    ofc_tano         varchar(30),
    ofc_phn          varchar(50),
    ofc_etn_phn      varchar(50),
    doc_auth_cd      varchar(30),
    ino_divs_cd      varchar(30),
    emp_hphn         varchar(50),
    old_dept_cd      varchar(30),
    old_emp_no       varchar(30),
    dept_eng_desc    varchar(100),
    emp_lowr_gr_cd   varchar(50),
    emp_uppr_gr_cd   varchar(50),
    eml_dmn_ifo_nm   varchar(200),
    sso_dtpl_cd      varchar(50),
    sso_emp_cng_nm   varchar(100),
    ctry_cd          varchar(30),
    sso_chg_tp_cd    varchar(50),
    sso_chg_dt       varchar(8),
    use_yn           varchar(1),
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP,
    dept_gr_cd       varchar(30),
    org_id           varchar(50)
);

alter table tb_wsf_emp_m
    owner to developer;

alter table tb_wsf_emp_m
    add constraint tb_wsf_emp_m_pk
        primary key (emp_no);

alter table tb_wsf_emp_m
    add constraint tb_wsf_emp_m_uk
        unique (user_id);

create table tb_wsf_emp_pass_m
(
    user_id         varchar(50)  not null,
    user_pass       varchar(100) not null,
    login_wrong_cnt integer default 0
);

alter table tb_wsf_emp_pass_m
    owner to developer;

alter table tb_wsf_emp_pass_m
    add constraint tb_wsf_emp_pass_m_pk
        primary key (user_id);



create table tb_wsf_btch_log_m
(
    btch_log_seq     numeric(22) not null,
    btch_log_dtm     timestamp   not null,
    btch_cls_nm      varchar(300),
    btch_mthd_nm     varchar(100),
    btch_crn         varchar(50),
    btch_rslt        varchar(4000),
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP
);

comment on table tb_wsf_btch_log_m is '배치로그기본';

comment on column tb_wsf_btch_log_m.btch_log_seq is '배치로그순번';

comment on column tb_wsf_btch_log_m.btch_log_dtm is '배치로그일시';

comment on column tb_wsf_btch_log_m.btch_cls_nm is '배치클래스명';

comment on column tb_wsf_btch_log_m.btch_mthd_nm is '배치메소드명';

comment on column tb_wsf_btch_log_m.btch_crn is '배치크론식';

comment on column tb_wsf_btch_log_m.btch_rslt is '배치결과';

comment on column tb_wsf_btch_log_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_btch_log_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_btch_log_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_btch_log_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_btch_log_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_btch_log_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_btch_log_m
    owner to developer;

alter table tb_wsf_btch_log_m
    add constraint tb_wsf_btch_log_m_pk
        primary key (btch_log_seq);

create table tb_wsf_apr_ln_m
(
    req_no           varchar(50) not null,
    appr_ln_seq      numeric(18) not null,
    next_appr_seq    numeric(18),
    next_appr_type   varchar(1),
    next_appr_emp_no varchar(27),
    prl_yn           varchar(1),
    appr_status      varchar(1),
    appr_message     varchar(1000),
    appr_date        timestamp,
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP,
    dlgt_emp_no      varchar(27)
);

comment on table tb_wsf_apr_ln_m is '결재라인기본';

comment on column tb_wsf_apr_ln_m.req_no is '결재요청번호';

comment on column tb_wsf_apr_ln_m.appr_ln_seq is '결재라인차수';

comment on column tb_wsf_apr_ln_m.next_appr_seq is '결재선 순번(병렬일 때 같은 값을 가짐)';

comment on column tb_wsf_apr_ln_m.next_appr_type is '결재타입';

comment on column tb_wsf_apr_ln_m.next_appr_emp_no is '결재자사번(결재수임자)';

comment on column tb_wsf_apr_ln_m.prl_yn is '병렬여부';

comment on column tb_wsf_apr_ln_m.appr_status is '결재 상태';

comment on column tb_wsf_apr_ln_m.appr_message is '결재의견';

comment on column tb_wsf_apr_ln_m.appr_date is '결재처리일';

comment on column tb_wsf_apr_ln_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_apr_ln_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_apr_ln_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_apr_ln_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_apr_ln_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_apr_ln_m.data_upd_dtm is '데이터수정일시';

comment on column tb_wsf_apr_ln_m.dlgt_emp_no is '결재위임자 사번';

alter table tb_wsf_apr_ln_m
    owner to developer;

alter table tb_wsf_apr_ln_m
    add constraint tb_wsf_apr_ln_test_m_pk
        primary key (req_no, appr_ln_seq);

create table tb_wsf_apr_req_m
(
    req_no               varchar(27) not null,
    system_id            varchar(27),
    form_id              varchar(27),
    req_emp_no           varchar(27),
    appr_title           varchar(200),
    body_html            varchar(10000),
    form_editor_data     clob,
    appr_security_type   varchar(10),
    appr_line_type       varchar(10),
    appr_period_cd       varchar(27),
    file_link_name       varchar(4000),
    file_link_url        varchar(4000),
    file_size            varchar(4000),
    read_user            varchar(4000),
    read_dept            varchar(4000),
    reference_id         varchar(4000),
    form_data            varchar(4000),
    appkey02             varchar(50),
    appkey03             varchar(50),
    relevant_depts       varchar(4000),
    review_comments      varchar(300),
    opt_val_ctn1         varchar(4000),
    opt_val_ctn2         varchar(4000),
    opt_val_ctn3         varchar(4000),
    opt_val_ctn4         varchar(4000),
    opt_val_ctn5         varchar(4000),
    data_ins_user_id     varchar(50),
    data_ins_user_ip     varchar(40),
    data_ins_dtm         timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id     varchar(50),
    data_upd_user_ip     varchar(40),
    data_upd_dtm         timestamp default CURRENT_TIMESTAMP,
    apr_req_prog_stat_cd varchar(10)
);

comment on table tb_wsf_apr_req_m is '결재 요청 기본';

comment on column tb_wsf_apr_req_m.req_no is '결재요청번호';

comment on column tb_wsf_apr_req_m.system_id is 'Legacy 시스템 ID';

comment on column tb_wsf_apr_req_m.form_id is '양식 ID';

comment on column tb_wsf_apr_req_m.req_emp_no is '요청자 사번';

comment on column tb_wsf_apr_req_m.appr_title is '결재문저 세목';

comment on column tb_wsf_apr_req_m.body_html is '모바일 본문내용';

comment on column tb_wsf_apr_req_m.form_editor_data is '웹 본문내용';

comment on column tb_wsf_apr_req_m.appr_security_type is '문서종류';

comment on column tb_wsf_apr_req_m.appr_line_type is '협의유형';

comment on column tb_wsf_apr_req_m.appr_period_cd is '보존연한코드';

comment on column tb_wsf_apr_req_m.file_link_name is '첨부파일명';

comment on column tb_wsf_apr_req_m.file_link_url is '첨부파일 URL';

comment on column tb_wsf_apr_req_m.file_size is '첨부파일사이즈';

comment on column tb_wsf_apr_req_m.read_user is '통보자사번';

comment on column tb_wsf_apr_req_m.read_dept is '공개 부서코드';

comment on column tb_wsf_apr_req_m.reference_id is '참조자 사번';

comment on column tb_wsf_apr_req_m.form_data is '연동양식 layout용 본문';

comment on column tb_wsf_apr_req_m.appkey02 is '업무 구분키 02';

comment on column tb_wsf_apr_req_m.appkey03 is '업무 구분키 03';

comment on column tb_wsf_apr_req_m.relevant_depts is '유관부서 정보';

comment on column tb_wsf_apr_req_m.review_comments is '검토의견';

comment on column tb_wsf_apr_req_m.opt_val_ctn1 is '옵션값내용1';

comment on column tb_wsf_apr_req_m.opt_val_ctn2 is '옵션값내용2';

comment on column tb_wsf_apr_req_m.opt_val_ctn3 is '옵션값내용3';

comment on column tb_wsf_apr_req_m.opt_val_ctn4 is '옵션값내용4';

comment on column tb_wsf_apr_req_m.opt_val_ctn5 is '옵션값내용5';

comment on column tb_wsf_apr_req_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_apr_req_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_apr_req_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_apr_req_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_apr_req_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_apr_req_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_apr_req_m
    owner to developer;

alter table tb_wsf_apr_req_m
    add constraint tb_wsf_apr_req_test_m_pk
        primary key (req_no);

create table tb_wsf_notice_m
(
    notice_no         varchar(10) not null,
    notice_tp_cd      varchar(10),
    notice_sort_ord   numeric,
    notice_title      varchar(300),
    notice_ctn        clob,
    smry_ctn          varchar(4000),
    atch_file_gr_id   varchar(50),
    htag_ctn          varchar(300),
    impt_yn           varchar(1),
    use_yn            varchar(1),
    notice_vwct       numeric,
    ptup_end_dt       varchar(50),
    noti_use_yn       varchar(1),
    poup_use_yn       varchar(1),
    poup_st_dtm       timestamp,
    poup_end_dtm      timestamp,
    poup_eps_nuse_ddn numeric,
    notice_clsf_cd    varchar(50),
    ptup_tgt_cop_cd   varchar(10),
    data_ins_user_id  varchar(50),
    data_ins_user_ip  varchar(40),
    data_ins_dtm      timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id  varchar(50),
    data_upd_user_ip  varchar(40),
    data_upd_dtm      timestamp default CURRENT_TIMESTAMP,
    re_notice_yn      varchar(1),
    prnt_re_notice_no varchar(10)
);

comment on table tb_wsf_notice_m is '게시판기본';

comment on column tb_wsf_notice_m.notice_no is '게시글번호';

comment on column tb_wsf_notice_m.notice_tp_cd is '게시판유형코드';

comment on column tb_wsf_notice_m.notice_sort_ord is '게시글정렬순서';

comment on column tb_wsf_notice_m.notice_title is '게시글제목명';

comment on column tb_wsf_notice_m.notice_ctn is '게시글내용';

comment on column tb_wsf_notice_m.smry_ctn is '요약내용';

comment on column tb_wsf_notice_m.atch_file_gr_id is '첨부파일그룹ID';

comment on column tb_wsf_notice_m.htag_ctn is '해시태그내용';

comment on column tb_wsf_notice_m.impt_yn is '중요여부';

comment on column tb_wsf_notice_m.use_yn is '사용여부';

comment on column tb_wsf_notice_m.notice_vwct is '게시글조회수';

comment on column tb_wsf_notice_m.ptup_end_dt is '게시종료일자';

comment on column tb_wsf_notice_m.noti_use_yn is '공지사용여부';

comment on column tb_wsf_notice_m.poup_use_yn is '팝업사용여부';

comment on column tb_wsf_notice_m.poup_st_dtm is '팝업시작일시';

comment on column tb_wsf_notice_m.poup_end_dtm is '팝업종료일시';

comment on column tb_wsf_notice_m.poup_eps_nuse_ddn is '팝업노출미사용일수';

comment on column tb_wsf_notice_m.notice_clsf_cd is '게시글분류코드';

comment on column tb_wsf_notice_m.ptup_tgt_cop_cd is '게시대상법인코드';

comment on column tb_wsf_notice_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_notice_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_notice_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_notice_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_notice_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_notice_m.data_upd_dtm is '데이터수정일시';

comment on column tb_wsf_notice_m.re_notice_yn is '답글여부';

comment on column tb_wsf_notice_m.prnt_re_notice_no is '부모글 번호';

alter table tb_wsf_notice_m
    owner to developer;

alter table tb_wsf_notice_m
    add constraint tb_wsf_notice_m_pk
        primary key (notice_no);

create table tb_wsf_notice_re_d
(
    notice_no        varchar(50),
    notice_re_no     varchar(50) not null,
    notice_re_ctn    text,
    del_yn           varchar(50) not null,
    prnt_re_no       varchar(50) not null,
    use_yn           varchar(50) not null,
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_ins_user_id varchar(50),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50)
);

alter table tb_wsf_notice_re_d
    owner to developer;

alter table tb_wsf_notice_re_d
    add primary key (notice_re_no);

alter table tb_wsf_notice_re_d
    add constraint fk_tb_wsf_fw_notice_note_m
        foreign key (notice_no) references tb_wsf_notice_m
            on delete cascade;

create table tb_wsf_ntdk_dept_m
(
    ntdk_dept_id     numeric(10) not null,
    ntdk_dept_nm     varchar(200),
    ntdk_dept_desc   varchar(200),
    use_yn           varchar(1),
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP
);

comment on column tb_wsf_ntdk_dept_m.ntdk_dept_id is '통보처아이디';

comment on column tb_wsf_ntdk_dept_m.ntdk_dept_nm is '통보처제목';

comment on column tb_wsf_ntdk_dept_m.ntdk_dept_desc is '통보처설명';

comment on column tb_wsf_ntdk_dept_m.use_yn is '사용여부';

comment on column tb_wsf_ntdk_dept_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_ntdk_dept_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_ntdk_dept_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_ntdk_dept_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_ntdk_dept_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_ntdk_dept_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_ntdk_dept_m
    owner to developer;

alter table tb_wsf_ntdk_dept_m
    add constraint tb_wsf_ntdk_dept_m_pk
        primary key (ntdk_dept_id);

create table tb_wsf_ntdk_dept_d
(
    ntdk_dept_id      numeric(10) not null,
    ntdk_dept_seq     numeric(18) not null,
    ntdk_dept_divs_cd varchar(50),
    apr_notf_dept_cd  varchar(50) not null,
    sort_ord          numeric(10),
    use_yn            varchar(1),
    data_ins_user_id  varchar(50),
    data_ins_user_ip  varchar(40),
    data_ins_dtm      timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id  varchar(50),
    data_upd_user_ip  varchar(40),
    data_upd_dtm      timestamp default CURRENT_TIMESTAMP
);

comment on table tb_wsf_ntdk_dept_d is '통보부서상세';

comment on column tb_wsf_ntdk_dept_d.ntdk_dept_id is '통보부서ID';

comment on column tb_wsf_ntdk_dept_d.ntdk_dept_seq is '통보부서순번';

comment on column tb_wsf_ntdk_dept_d.ntdk_dept_divs_cd is '통보부서구분코드';

comment on column tb_wsf_ntdk_dept_d.apr_notf_dept_cd is '결재통보부서ID';

comment on column tb_wsf_ntdk_dept_d.sort_ord is '정렬순서';

comment on column tb_wsf_ntdk_dept_d.use_yn is '사용여부';

comment on column tb_wsf_ntdk_dept_d.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_ntdk_dept_d.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_ntdk_dept_d.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_ntdk_dept_d.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_ntdk_dept_d.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_ntdk_dept_d.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_ntdk_dept_d
    owner to developer;

alter table tb_wsf_ntdk_dept_d
    add constraint tb_wsf_ntdk_dept_d_pk
        primary key (ntdk_dept_id, ntdk_dept_seq);

create table tb_wsf_role_btn_m_old
(
    btn_grp_cd       varchar(30) not null,
    btn_cd           varchar(30) not null,
    role_cd          varchar(30) not null,
    use_yn           varchar(1),
    btn_desc         varchar(4000),
    opt_val_ctn1     varchar(4000),
    opt_val_ctn2     varchar(4000),
    opt_val_ctn3     varchar(4000),
    opt_val_ctn4     varchar(4000),
    opt_val_ctn5     varchar(4000),
    opt_val_ctn6     varchar(4000),
    opt_val_ctn7     varchar(4000),
    opt_val_ctn8     varchar(4000),
    opt_val_ctn9     varchar(4000),
    opt_val_ctn10    varchar(4000),
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(50),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(50),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP
);

comment on column tb_wsf_role_btn_m_old.btn_cd is '버튼코드';

comment on column tb_wsf_role_btn_m_old.role_cd is '역할코드';

comment on column tb_wsf_role_btn_m_old.use_yn is '사용여부';

comment on column tb_wsf_role_btn_m_old.btn_desc is '버튼설명';

comment on column tb_wsf_role_btn_m_old.opt_val_ctn1 is '옵션값내용1';

comment on column tb_wsf_role_btn_m_old.opt_val_ctn2 is '옵션값내용2';

comment on column tb_wsf_role_btn_m_old.opt_val_ctn3 is '옵션값내용3';

comment on column tb_wsf_role_btn_m_old.opt_val_ctn4 is '옵션값내용4';

comment on column tb_wsf_role_btn_m_old.opt_val_ctn5 is '옵션값내용5';

comment on column tb_wsf_role_btn_m_old.opt_val_ctn6 is '옵션값내용6';

comment on column tb_wsf_role_btn_m_old.opt_val_ctn7 is '옵션값내용7';

comment on column tb_wsf_role_btn_m_old.opt_val_ctn8 is '옵션값내용8';

comment on column tb_wsf_role_btn_m_old.opt_val_ctn9 is '옵션값내용9';

comment on column tb_wsf_role_btn_m_old.opt_val_ctn10 is '옵션값내용10';

comment on column tb_wsf_role_btn_m_old.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_role_btn_m_old.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_role_btn_m_old.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_role_btn_m_old.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_role_btn_m_old.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_role_btn_m_old.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_role_btn_m_old
    owner to developer;

alter table tb_wsf_role_btn_m_old
    add constraint tb_wsf_role_btn_m_pk
        primary key (btn_grp_cd, btn_cd, role_cd);

create table tb_wsf_role_btn_m
(
    btn_gr_cd        varchar(30) not null,
    btn_cd           varchar(30) not null,
    role_cd          varchar(30) not null,
    use_yn           varchar(1),
    btn_desc         varchar(4000),
    opt_val_ctn1     varchar(4000),
    opt_val_ctn2     varchar(4000),
    opt_val_ctn3     varchar(4000),
    opt_val_ctn4     varchar(4000),
    opt_val_ctn5     varchar(4000),
    opt_val_ctn6     varchar(4000),
    opt_val_ctn7     varchar(4000),
    opt_val_ctn8     varchar(4000),
    opt_val_ctn9     varchar(4000),
    opt_val_ctn10    varchar(4000),
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(50),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(50),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP
);

comment on column tb_wsf_role_btn_m.btn_gr_cd is '버튼그룹코드';

comment on column tb_wsf_role_btn_m.btn_cd is '버튼코드';

comment on column tb_wsf_role_btn_m.role_cd is '역할코드';

comment on column tb_wsf_role_btn_m.use_yn is '사용여부';

comment on column tb_wsf_role_btn_m.btn_desc is '버튼설명';

comment on column tb_wsf_role_btn_m.opt_val_ctn1 is '옵션값내용1';

comment on column tb_wsf_role_btn_m.opt_val_ctn2 is '옵션값내용2';

comment on column tb_wsf_role_btn_m.opt_val_ctn3 is '옵션값내용3';

comment on column tb_wsf_role_btn_m.opt_val_ctn4 is '옵션값내용4';

comment on column tb_wsf_role_btn_m.opt_val_ctn5 is '옵션값내용5';

comment on column tb_wsf_role_btn_m.opt_val_ctn6 is '옵션값내용6';

comment on column tb_wsf_role_btn_m.opt_val_ctn7 is '옵션값내용7';

comment on column tb_wsf_role_btn_m.opt_val_ctn8 is '옵션값내용8';

comment on column tb_wsf_role_btn_m.opt_val_ctn9 is '옵션값내용9';

comment on column tb_wsf_role_btn_m.opt_val_ctn10 is '옵션값내용10';

comment on column tb_wsf_role_btn_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_role_btn_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_role_btn_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_role_btn_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_role_btn_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_role_btn_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_role_btn_m
    owner to developer;

alter table tb_wsf_role_btn_m
    add constraint tb_wsf_role_btn_m_pk_new
        primary key (btn_gr_cd, btn_cd, role_cd);

create table tb_wsf_api_m
(
    api_id           varchar(50) not null,
    class_nm         varchar(250),
    api_url          clob,
    api_nm           clob,
    http_mthd_cd     varchar(10),
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP,
    use_yn           varchar(1)
);

comment on column tb_wsf_api_m.class_nm is '클래스명';

comment on column tb_wsf_api_m.api_url is 'API URL';

comment on column tb_wsf_api_m.api_nm is 'API명';

comment on column tb_wsf_api_m.http_mthd_cd is '메소드';

comment on column tb_wsf_api_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_api_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_api_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_api_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_api_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_api_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_api_m
    owner to developer;

alter table tb_wsf_api_m
    add constraint tb_wsf_menu_api_m_pk
        primary key (api_id);

create table tb_wsf_apr_tpl_m
(
    apr_tpl_id       varchar(50) not null,
    intg_apr_tp_cd   varchar(50),
    eapr_tpl_id      varchar(50),
    apr_tpl_nm       varchar(200),
    sort_ord         numeric(10),
    apr_tpl_desc     varchar(200),
    use_yn           varchar(1),
    prs_desc         varchar(4000),
    wcst_use_yn      varchar(1),
    wcst_desc        clob,
    notf_use_yn      varchar(1),
    ntdk_id          numeric(10),
    mgr_use_yn       varchar(1),
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(40),
    data_ins_dtm     timestamp,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(40),
    data_upd_dtm     timestamp
);

comment on table tb_wsf_apr_tpl_m is '결재양식기본';

comment on column tb_wsf_apr_tpl_m.apr_tpl_id is '결재양식ID';

comment on column tb_wsf_apr_tpl_m.intg_apr_tp_cd is '통합결재유형코드';

comment on column tb_wsf_apr_tpl_m.eapr_tpl_id is '전자결재양식ID';

comment on column tb_wsf_apr_tpl_m.apr_tpl_nm is '결재양식명';

comment on column tb_wsf_apr_tpl_m.sort_ord is '정렬순서';

comment on column tb_wsf_apr_tpl_m.apr_tpl_desc is '결재양식설명';

comment on column tb_wsf_apr_tpl_m.use_yn is '사용여부';

comment on column tb_wsf_apr_tpl_m.prs_desc is '프로세스설명';

comment on column tb_wsf_apr_tpl_m.wcst_use_yn is '동의서사용여부';

comment on column tb_wsf_apr_tpl_m.wcst_desc is '동의서설명';

comment on column tb_wsf_apr_tpl_m.notf_use_yn is '통보사용여부';

comment on column tb_wsf_apr_tpl_m.ntdk_id is '통보처ID';

comment on column tb_wsf_apr_tpl_m.mgr_use_yn is '담당자사용여부';

comment on column tb_wsf_apr_tpl_m.data_ins_user_id is '데이터입력사용자ID';

comment on column tb_wsf_apr_tpl_m.data_ins_user_ip is '데이터입력사용자IP주소';

comment on column tb_wsf_apr_tpl_m.data_ins_dtm is '데이터입력일시';

comment on column tb_wsf_apr_tpl_m.data_upd_user_id is '데이터수정사용자ID';

comment on column tb_wsf_apr_tpl_m.data_upd_user_ip is '데이터수정사용자IP주소';

comment on column tb_wsf_apr_tpl_m.data_upd_dtm is '데이터수정일시';

alter table tb_wsf_apr_tpl_m
    owner to developer;

alter table tb_wsf_apr_tpl_m
    add constraint tb_wsf_apr_tpl_m_pk
        primary key (apr_tpl_id);

create table tb_wsf_personal_search_m
(
    search_id          varchar(50) not null
        constraint tb_wsf_user_searches_m_pk
            primary key,
    search_url         varchar(50),
    search_form_id varchar(50) not null,
    search_query TEXT NOT NULL,
    user_id varchar(50) NOT NULL,
    data_ins_user_id varchar(50),
    data_ins_user_ip varchar(50),
    data_ins_dtm     timestamp default CURRENT_TIMESTAMP,
    data_upd_user_id varchar(50),
    data_upd_user_ip varchar(50),
    data_upd_dtm     timestamp default CURRENT_TIMESTAMP
);

alter table tb_wsf_personal_search_m
    owner to developer;

comment on table tb_wsf_personal_search_m is '사용자 검색 조건';

comment on column tb_wsf_personal_search_m.search_id is '검색 ID';
comment on column tb_wsf_personal_search_m.search_url is '검색 URL';
comment on column tb_wsf_personal_search_m.search_form_id is '검색 양식 ID';
comment on column tb_wsf_personal_search_m.search_query is '검색 쿼리';
comment on column tb_wsf_personal_search_m.user_id is '사용자 ID';
comment on column tb_wsf_personal_search_m.data_ins_user_id is '데이터입력사용자ID';
comment on column tb_wsf_personal_search_m.data_ins_user_ip is '데이터입력사용자IP주소';
comment on column tb_wsf_personal_search_m.data_ins_dtm is '데이터입력일시';
comment on column tb_wsf_personal_search_m.data_upd_user_id is '데이터수정사용자ID';
comment on column tb_wsf_personal_search_m.data_upd_user_ip is '데이터수정사용자IP주소';
comment on column tb_wsf_personal_search_m.data_upd_dtm is '데이터수정일시';

alter table public.tb_wsf_personal_search_m
    add constraint tb_wsf_personal_search_m_pk
        unique (search_url, user_id, search_form_id);

