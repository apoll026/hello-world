insert into public.tb_wsf_role_m (role_cd, role_nm, role_desc, use_yn, data_ins_user_id, data_ins_user_ip, data_ins_dtm, data_upd_user_id, data_upd_user_ip, data_upd_dtm, itgr_yn)
values  ('ADM', '시스템 관리자', '시스템 관리자', 'Y', 'FW_DEFAULT', null, null, null, null, '2024-11-07 00:00:00.000000', 'Y'),
        ('PTN', '협력업체', '협력업체', 'Y', 'FW_DEFAULT', null, null, null, null, '2024-11-07 00:00:00.000000', 'Y'),
        ('PTN2', '테스트', '테스트', 'Y', 'developer', '0:0:0:0:0:0:0:1', '2024-11-07 00:00:00.000000', 'developer', '0:0:0:0:0:0:0:1', '2024-11-07 00:00:00.000000', 'Y'),
        ('PTN3', 'TEMP-ROLE', 'TEMP-ROLE', 'Y', 'FW-DEFAULT', '0.0.0.0', '2024-11-07 00:00:00.000000', 'FW-DEFAULT', '0.0.0.0', '2024-11-07 00:00:00.000000', 'Y'),
        ('CMN', '일반 사용자', '일반 사용자', 'Y', 'FW_DEFAULT', null, null, null, null, '2024-11-07 00:00:00.000000', null);