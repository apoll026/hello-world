create sequence seq_mnu_aces_log_id;

alter sequence seq_mnu_aces_log_id owner to developer;

create sequence seq_cont_log_id;

alter sequence seq_cont_log_id owner to developer;

create sequence seq_if_log_id;

alter sequence seq_if_log_id owner to developer;

create sequence seq_eml_sndo;

alter sequence seq_eml_sndo owner to developer;

create sequence seq_apr_req_id;

alter sequence seq_apr_req_id owner to developer;

create sequence seq_eml_log;

alter sequence seq_eml_log owner to developer;

create sequence seq_todo_id;

alter sequence seq_todo_id owner to developer;

create sequence seq_btch_log_id;

alter sequence seq_btch_log_id owner to developer;

