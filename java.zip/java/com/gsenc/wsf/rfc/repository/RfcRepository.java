package com.gsenc.wsf.rfc.repository;

import org.apache.ibatis.annotations.Mapper;

import com.gsenc.wsf.rfc.model.RfcVO;

@Mapper
public interface RfcRepository {
	RfcVO selectRfc(RfcVO rfcVO);
}
