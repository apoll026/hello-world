package com.gsenc.wsf.rfc.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;
import com.gsenc.wsf.rfc.model.RfcVO;
import com.gsenc.wsf.rfc.service.RfcService;

import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api")

public class RfcController {
	private final RfcService rfcService;

	@Operation(summary = "RFC 로그 분리 샘플")
	@GetMapping(value = "/v1/rfc/sample-log", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<RfcVO>> findDepartments(
		RfcVO rfcVO) {
		return new ResponseEntity<>(
			CommonResponseVO.<RfcVO>builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(rfcService.sampleLog(rfcVO))
				.build(),
			HttpStatus.OK);
	}
}
