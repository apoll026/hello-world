package com.gsenc.wsf.rfc.service;

import com.gsenc.wsf.rfc.model.RfcVO;

public interface RfcService {

    RfcVO sampleLog(RfcVO rfcVO);
}
