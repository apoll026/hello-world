package com.gsenc.wsf.rfc.service;

import org.slf4j.Marker;
import org.slf4j.MarkerFactory;
import org.springframework.stereotype.Service;

import com.gsenc.wsf.common.constant.LogConstants;
import com.gsenc.wsf.rfc.model.RfcVO;
import com.gsenc.wsf.rfc.repository.RfcRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class RfcServiceImpl implements RfcService {

	private final RfcRepository rfcRepository;
	Marker marker = MarkerFactory.getMarker(LogConstants.RFC);

	@Override
	public RfcVO sampleLog(RfcVO rfcVO) {

		try {
			rfcRepository.selectRfc(rfcVO);
		} catch (Exception e) {
			log.error(marker, "[Request ]\n{}", rfcVO.toString());
			log.error(marker, "[Response]\n{}", rfcVO.toString());
			log.error(marker, "[Error   ]", e);
		}
		return rfcVO;
	}
}
