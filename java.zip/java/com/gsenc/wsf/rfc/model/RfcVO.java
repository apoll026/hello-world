package com.gsenc.wsf.rfc.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class RfcVO {

	@Schema(description = "col1", example = "col1")
	private String col1;

	@Schema(description = "col2", example = "col2")
	private String col2;
}
