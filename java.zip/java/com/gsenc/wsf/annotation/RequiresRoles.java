package com.gsenc.wsf.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.METHOD, ElementType.TYPE, ElementType.ANNOTATION_TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface RequiresRoles {
    String[] value() default {};

    /**
     * 타입
     * @return type ROLE or BTN_KEY
     */
    String type() default "ROLE";   //ROLE, BTN_KEY
}
