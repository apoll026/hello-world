package com.gsenc.wsf.aop;

import java.util.Date;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.gsenc.wsf.annotation.WsfScheduled;
import com.gsenc.wsf.log.model.BatchLogVO;
import com.gsenc.wsf.log.service.BatchLogService;

@Aspect
@Component
public class WsfScheduledAspect {

	@Value("${spring.profiles.active}")
	private String activeProfile;
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private BatchLogService batchLogService;
	@Autowired
	private Environment environment;

	/**
	 * activeProfile을 활용해서 개발/운영 서버에서만 동작하도록 설정
	 *
	 * @return
	 */
	private boolean isEnable() {
		return !activeProfile.equals("default");
	}

	@Around("@annotation(wsfScheduled)")
	public Object handleWsfScheduled(ProceedingJoinPoint joinPoint, WsfScheduled wsfScheduled) throws Throwable {

		MethodSignature signature = (MethodSignature)joinPoint.getSignature();
		Class<?> returnType = signature.getReturnType();

		if (isEnable()) {
			// Annotation 호출 클래스명#메소드명
			logger.info("[" + joinPoint.getSignature().getDeclaringTypeName() + "#" + joinPoint.getSignature().getName()
				+ "] :: " + new Date().toString());
			// 실행
			Object result = joinPoint.proceed();

			BatchLogVO vo = new BatchLogVO();
			vo.setBtchClsNm(joinPoint.getSignature().getDeclaringTypeName());
			vo.setBtchMthdNm(joinPoint.getSignature().getName());

			String cron = environment.getProperty(wsfScheduled.cron().replace("${", "").replace("}", ""),
				wsfScheduled.cron());

			vo.setBtchCrn(cron);
			vo.setBtchRslt(result.toString());

			// 배치 로그 저장
			batchLogService.createBatchLog(vo);

			return result;
		}

		if (returnType == int.class || returnType == Integer.class) {
			return 0;
		} else {
			return null;
		}
	}
}
