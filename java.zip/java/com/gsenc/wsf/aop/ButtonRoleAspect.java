package com.gsenc.wsf.aop;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import com.gsenc.wsf.annotation.RequiresRoles;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.exception.BusinessException;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.role.model.RoleButtonResponseVO;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.extern.slf4j.Slf4j;

@Aspect
@Component
@Slf4j
public class ButtonRoleAspect {
	@Around("within(@com.gsenc.wsf.annotation.RequiresRoles *)")
	public Object checkClassPermission(ProceedingJoinPoint joinPoint) throws Throwable {

		UserSessionVO userSessionContext = SessionScopeUtil.getContextSession();
		Class<?> targetClass = joinPoint.getTarget().getClass();
		Object proceed = joinPoint.proceed();

		if (userSessionContext != null) {

			RequiresRoles annotation = targetClass.getAnnotation(RequiresRoles.class);

			String[] value = annotation.value();

			List<String> sessionRoleCodes = SessionScopeUtil.getContextSession().getRoleCodes();
			boolean result = sessionRoleCodes.stream().anyMatch(o -> Arrays.asList(value).contains(o));

			if (!result) {
				throw new BusinessException("User does not have permission",
					StatusCodeConstants.NOT_AUTHORIZED_EXCEPTION);
			}
		} else {
			throw new BusinessException("Session Expire - session, Access method is " + targetClass.getName(),
				StatusCodeConstants.SESSION_EXPIRE);
		}

		return proceed;
	}

	@Before("@annotation(com.gsenc.wsf.annotation.RequiresRoles)")
	public void checkPermission(JoinPoint joinPoint) {
		UserSessionVO userSessionContext = SessionScopeUtil.getContextSession();

		MethodSignature signature = (MethodSignature)joinPoint.getSignature();
		Method method = signature.getMethod();

		RequiresRoles annotation = method.getAnnotation(RequiresRoles.class);
		String[] value = annotation.value();
		String type = annotation.type();

		if (userSessionContext != null) {
			boolean result = true;
			if ("ROLE".equals(type)) {
				List<String> sessionRoleCodes = SessionScopeUtil.getContextSession().getRoleCodes();
				result = sessionRoleCodes.stream().anyMatch(o -> Arrays.asList(value).contains(o));
			} else {
				List<RoleButtonResponseVO> roleBtns = SessionScopeUtil.getContextSession().getRoleButtonCodes();
				result = roleBtns.stream().map(o -> o.getBtnKeyCd()).anyMatch(o -> Arrays.asList(value).contains(o));
			}
			if (!result) {
				throw new BusinessException("User does not have permission",
					StatusCodeConstants.NOT_AUTHORIZED_EXCEPTION);
			}

		} else {
			throw new BusinessException("Session Expire - session, Access method is " + method.getName(),
				StatusCodeConstants.SESSION_EXPIRE);
		}

	}

}
