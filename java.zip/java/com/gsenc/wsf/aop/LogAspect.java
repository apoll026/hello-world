package com.gsenc.wsf.aop;

import java.util.Arrays;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Aspect
@Slf4j
public class LogAspect {

	private static final String CLASS_LOG_FORMAT = "Class Name : [";
	private static final String METHOD_LOG_FORMAT = "Method Name : [";

	@Before(
		"(execution(* com.gsenc.wsf.common.exception..*(..))"
			+ " or execution(* com.gsenc.wsf.common.interceptor..*(..))"
			+ " or execution(* com.gsenc.wsf.*.repository..*(..))"
			+ " or execution(* com.gsenc.wsf.*.controller..*(..))"
			+ " or execution(* com.gsenc.wsf.*.service..*(..))"
			+ " or execution(* com.gsenc.eas.sample..*(..)))"
			+ " && !@annotation(com.gsenc.wsf.annotation.NoLogging)")
	public void beforeMethod(JoinPoint joinPoint) {
		var beforeMethodInfo = new StringBuilder();
		var logInfo =
			beforeMethodInfo
				.append("Before method :")
				.append(CLASS_LOG_FORMAT)
				.append(joinPoint.getSignature().getDeclaringTypeName())
				.append("], ")
				.append(METHOD_LOG_FORMAT)
				.append(joinPoint.getSignature().getName())
				.append("], ")
				.append("Data : [")
				.append(Arrays.toString(joinPoint.getArgs()))
				.append("]")
				.toString();

		log.debug(logInfo);
	}

	@AfterReturning(
		pointcut =
			"(execution(* com.gsenc.wsf.common.exception..*(..))"
				+ " or execution(* com.gsenc.wsf.common.interceptor..*(..))"
				+ " or execution(* com.gsenc.wsf.*.repository..*(..))"
				+ " or execution(* com.gsenc.wsf.*.controller..*(..))"
				+ " or execution(* com.gsenc.wsf.*.service..*(..))"
				+ " or execution(* com.gsenc.eas.sample..*(..)))"
				+ " && !@annotation(com.gsenc.wsf.annotation.NoLogging)",
		returning = "result")
	public void afterMethod(JoinPoint joinPoint, Object result) {
		var afterMethodInfo = new StringBuilder();
		var logInfo =
			afterMethodInfo
				.append("After  method :")
				.append(CLASS_LOG_FORMAT)
				.append(joinPoint.getSignature().getDeclaringTypeName())
				.append("], ")
				.append(METHOD_LOG_FORMAT)
				.append(joinPoint.getSignature().getName())
				.append("], ")
				.append("Data : [")
				.append(result)
				.append("]")
				.toString();

		log.debug(logInfo);
	}

	@AfterThrowing(
		pointcut =
			"(execution(* com.gsenc.wsf.common.interceptor..*(..))"
				+ " || execution(* com.gsenc.wsf.common.filter..*(..))"
				+ " || execution(* com.gsenc.wsf.*.repository..*(..))"
				+ " || execution(* com.gsenc.wsf.*.controller..*(..))"
				+ " || execution(* com.gsenc.eas.*.repository..*(..))"
				+ " || execution(* com.gsenc.eas.*.controller..*(..))"
				+ " || execution(* com.gsenc.eas.*.service..*(..))"
				+ " || execution(* com.gsenc.wsf.*.service..*(..)))",
		throwing = "ex")
	public void afterThrowing(JoinPoint joinPoint, Exception ex) {
		var afterThrowingInfo = new StringBuilder();
		var logInfo =
			afterThrowingInfo
				.append("This method Throwing :")
				.append(CLASS_LOG_FORMAT)
				.append(joinPoint.getSignature().getDeclaringTypeName())
				.append("], ")
				.append(METHOD_LOG_FORMAT)
				.append(joinPoint.getSignature().getName())
				.append("], ")
				.append("Exception : [")
				.append(exceptionToString(ex))
				.append("]")
				.toString();

		log.error(logInfo);
	}

	private String exceptionToString(Exception exception) {
		return ExceptionUtils.getStackTrace(exception);
	}

}
