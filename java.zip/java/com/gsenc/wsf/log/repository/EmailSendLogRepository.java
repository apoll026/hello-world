package com.gsenc.wsf.log.repository;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.log.model.EmailSendLogVO;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface EmailSendLogRepository {

	int insertEmailSendLog(@Param("email") EmailSendLogVO emailSendLogVO, @Param("session") UserSessionVO session);

	long selectEmlLogSeq();

}
