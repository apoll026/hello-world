package com.gsenc.wsf.log.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.log.model.EmailLogRequestVO;
import com.gsenc.wsf.log.model.EmailLogResponseVO;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface EmailLogRepository {
	int selectEmailLogListCount(@Param("condition") EmailLogRequestVO condition);

	List<EmailLogResponseVO> selectEmailLogList(@Param("condition") EmailLogRequestVO condition,
		@Param("session") UserSessionVO UserSessionVO);
}
