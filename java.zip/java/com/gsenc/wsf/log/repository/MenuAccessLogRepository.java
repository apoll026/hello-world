package com.gsenc.wsf.log.repository;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.log.model.GsLogVO;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface MenuAccessLogRepository {

	int insertMenuAccessLog(@Param("pgmId") String pgmId, @Param("session") UserSessionVO session);

	void callGsApAccessLog(@Param("gsLogVO") GsLogVO gsLogVO, @Param("session") UserSessionVO session);

}
