package com.gsenc.wsf.log.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.log.model.MenuLogRequestVO;
import com.gsenc.wsf.log.model.MenuLogResponseVO;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface MenuLogRepository {
	int selectMenuLogListCount(@Param("condition") MenuLogRequestVO condition);

	List<MenuLogResponseVO> selectMenuLogList(@Param("condition") MenuLogRequestVO condition,
		@Param("session") UserSessionVO userSession);
}
