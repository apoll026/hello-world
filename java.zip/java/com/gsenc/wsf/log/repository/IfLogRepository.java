package com.gsenc.wsf.log.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.log.model.IfLogRequestVO;
import com.gsenc.wsf.log.model.IfLogResponseVO;
import com.gsenc.wsf.log.model.IfLogVO;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface IfLogRepository {

	int insertIfLog(@Param("iflog") IfLogVO ifLogVO, @Param("session") UserSessionVO session);

	long selectIfLogSeq();

	int insertIfLogSend(@Param("iflog") IfLogVO ifLogVO, @Param("session") UserSessionVO session);

	int updateIfLogReceive(@Param("iflog") IfLogVO ifLogVO, @Param("session") UserSessionVO session);

	int selectIfLogListCount(@Param("condition") IfLogRequestVO condiiton);

	List<IfLogResponseVO> selectIfLogList(@Param("condition") IfLogRequestVO condition);
}
