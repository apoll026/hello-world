package com.gsenc.wsf.log.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.log.model.ButtonLogRequestVO;
import com.gsenc.wsf.log.model.ButtonLogResponseVO;
import com.gsenc.wsf.log.model.ButtonLogVO;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface ButtonLogRepository {
	int insertButtonLog(@Param("buttonLog") ButtonLogVO buttonLogVO, @Param("session") UserSessionVO session);

	List<ButtonLogResponseVO> selectButtonLogList(@Param("buttonLog") ButtonLogRequestVO buttonLogRequestVO, @Param("session") UserSessionVO session);

	int selectButtonLogListCount(@Param("buttonLog") ButtonLogRequestVO buttonLogRequestVO);
}
