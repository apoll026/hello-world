package com.gsenc.wsf.log.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.log.model.LoginLogRequestVO;
import com.gsenc.wsf.log.model.LoginLogResponseVO;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface LoginLogRepository {

	int insertLoginLog(@Param("session") UserSessionVO UserSessionVO);

	List<LoginLogResponseVO> selectLoginLogList(@Param("condition") LoginLogRequestVO condition,
		@Param("session") UserSessionVO UserSessionVO);

	int selectLoginLogListCount(@Param("condition") LoginLogRequestVO condition);

}
