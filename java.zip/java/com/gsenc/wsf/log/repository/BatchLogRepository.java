package com.gsenc.wsf.log.repository;


import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.log.model.BatchLogVO;

@Mapper
public interface BatchLogRepository {
    int insertBatchLog(@Param("batchlog") BatchLogVO batchLogVO);

    int selectBatchLogListCount(@Param("condition") BatchLogVO condiiton);

    List<BatchLogVO> selectBatchLogList(@Param("condition") BatchLogVO condition);

}
