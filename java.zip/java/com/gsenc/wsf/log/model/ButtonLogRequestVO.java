package com.gsenc.wsf.log.model;

import com.gsenc.wsf.common.model.PaginationRequestVO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = true)
@SuperBuilder
public class ButtonLogRequestVO extends PaginationRequestVO {

    @Schema(description = "시작일시", example = "20230501")
    String contDtmFr;

    @Schema(description = "종료일시", example = "20230501")
    String contDtmTo;

    @Schema(description = "검색어", example = "gigi")
    String searchItem;
}
