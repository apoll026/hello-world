package com.gsenc.wsf.log.model;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@SuperBuilder
public class ButtonLogVO {
    @Schema(description = "버튼그룹코드", example = "샘플화면")
    private String btnKeyCd;

    @Schema(description = "버튼그룹코드", example = "샘플화면")
    private String btnGrCd;

    @Schema(description = "버튼코드", example = "reg001")
    private String btnCd;

    public static ButtonLogVO from(String btnKeyCd) {
        return ButtonLogVO.builder().btnKeyCd(btnKeyCd).btnGrCd(btnKeyCd.split("\\.")[0]).btnCd(btnKeyCd.split("\\.")[1]).build();
    }
}
