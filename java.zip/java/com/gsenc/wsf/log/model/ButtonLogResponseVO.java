package com.gsenc.wsf.log.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class ButtonLogResponseVO {
    @Schema(description = "화면별버튼코드", example = "샘플화면.reg001")
    private String btnKeyCd;
    @Schema(description = "버튼그룹코드", example = "샘플화면")
    private String btnGrCd;
    @Schema(description = "버튼코드", example = "reg001")
    private String btnCd;
    @Schema(description = "내용일시", example = "")
    private String contDtm;
    @Schema(description = "버튼설명", example = "샘플화면 첫번째 등록버튼")
    private String btnDesc;
    @Schema(description = "사용자명", example = "")
    private String empName;
    @Schema(description = "접속IP", example = "")
    private String contIp;
}
