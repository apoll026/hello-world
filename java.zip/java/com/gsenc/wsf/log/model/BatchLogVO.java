package com.gsenc.wsf.log.model;

import com.gsenc.wsf.common.model.PaginationRequestVO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = true)
@SuperBuilder

public class BatchLogVO extends PaginationRequestVO {

    private String btchLogSeq;
    private String btchLogDtm;
    private String btchClsNm;
    private String btchMthdNm;
    private String btchCrn;
    private String btchRslt;
    private String dataInsUserId;
    private String dataInsUserIp;
    private String dataInsDtm;
    private String dataUpdUserId;
    private String dataUpdUserIp;
    private String dataUpdDtm;

    @Schema(description = "배치로그시작일자", example = "20230501")
    String batchLogDtmFr;
    @Schema(description = "배치로그종료일자", example = "20230801")
    String batchLogDtmTo;
    @Schema(description = "검색어", example = "Type2")
    String searchItem;
}
