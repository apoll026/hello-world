package com.gsenc.wsf.log.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GsLogVO {

	@Schema(description = "API URL", example = "API 경로")
	private String apiUrl;

	@Schema(description = "현재 화면 URL", example = "현재 화면 URL")
	private String currentUrl;

	@Schema(description = "이전 화면 URL", example = "이전 화면 URL")
	private String prevUrl;

	@Schema(description = "요청 본문", example = "요청 데이터")
	private String requestBody;

	@Schema(description = "액션 타입", example = "RE:조회 LI:화면별 로그인 LO:화면별 로그아웃 EX:엑셀다운 PT:출력 AP:승인 ET:기타 WR:저장")
	private String actType;

	@Schema(description = "클라이언트 타입", example = "N(Normal PC), M(Mobile), P(PDA), C(citrix/metaframe), X(제외), E(기타)")
	private String clntType;

	@Schema(description = "System ID", example = "EAS")
	private String systemId;

	@Schema(description = "Program ID", example = "")
	private String programId;

	@Schema(description = "System Name", example = "전자전표")
	private String systemName;

	// OUT 파라미터
	private String oMsg;

}
