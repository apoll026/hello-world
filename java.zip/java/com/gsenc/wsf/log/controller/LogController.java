package com.gsenc.wsf.log.controller;

import java.util.Map;

import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.wsf.common.constant.GsActTypeConstants;
import com.gsenc.wsf.log.model.GsLogVO;
import com.gsenc.wsf.log.service.LogService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "Log")
@Validated
@RequestMapping("/api")

public class LogController {

	private final LogService logService;

	@Operation(summary = "메뉴접근 로그")
	@PostMapping(value = "/v1/log/menu-access", produces = MediaType.APPLICATION_JSON_VALUE)
	public void createMenuAccessLog(
		@RequestBody Map<String, String> pgmId) {
		logService.createMenuAccessLog(pgmId.get("pgmId"));
	}

	@Operation(summary = "화면 접근 로그 (GS 공통 로그)")
	@PostMapping(value = "/v1/log/gs-menu-access", produces = MediaType.APPLICATION_JSON_VALUE)
	public void callGsApAccessLog(
		@RequestBody GsLogVO gsLogVO, HttpServletRequest request) {

		logService.callGsApAccessLog(request, GsActTypeConstants.LO, gsLogVO.getPrevUrl());
		logService.callGsApAccessLog(request, GsActTypeConstants.LI, gsLogVO.getCurrentUrl());
	}

}
