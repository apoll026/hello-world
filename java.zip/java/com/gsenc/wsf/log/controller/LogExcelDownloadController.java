package com.gsenc.wsf.log.controller;

import java.io.IOException;

import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.cfs.sample.model.ExcelRequestVO;
import com.gsenc.cfs.sample.service.LogExcelDownloadService;
import com.gsenc.wsf.common.constant.GsActTypeConstants;
import com.gsenc.wsf.log.model.BatchLogVO;
import com.gsenc.wsf.log.model.EmailLogRequestVO;
import com.gsenc.wsf.log.model.IfLogRequestVO;
import com.gsenc.wsf.log.model.LoginLogRequestVO;
import com.gsenc.wsf.log.model.MenuLogRequestVO;
import com.gsenc.wsf.log.service.LogService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "Log")
@Validated
@RequestMapping("/api")

public class LogExcelDownloadController {

	private final LogExcelDownloadService logExcelDownloadService;
	private final LogService logService;

	@Operation(summary = "로그인 로그 엑셀 다운로드")
	@PostMapping(value = "/v1/login/list/excel-download")
	public void downLoadLogInLogListExcel(@RequestBody ExcelRequestVO<LoginLogRequestVO> condition,
		HttpServletResponse response, HttpServletRequest request) throws IOException {

		logService.callGsApAccessLog(request, GsActTypeConstants.EX); // 공통 로그 생성

		logExcelDownloadService.downloadLogInLogListExcel(condition, response);
	}

	@Operation(summary = "이메일 로그 엑셀 다운로드")
	@PostMapping(value = "/v1/email/list/excel-download")
	public void downLoadEmailLogListExcel(@RequestBody ExcelRequestVO<EmailLogRequestVO> condition,
		HttpServletResponse response, HttpServletRequest request) throws IOException {

		logService.callGsApAccessLog(request, GsActTypeConstants.EX); // 공통 로그 생성

		logExcelDownloadService.downloadEmailLogListExcel(condition, response);
	}

	@Operation(summary = "메뉴접근 로그 엑셀 다운로드")
	@PostMapping(value = "/v1/menu/list/excel-download")
	public void downLoadMenuAccessLogListExcel(@RequestBody ExcelRequestVO<MenuLogRequestVO> condition,
		HttpServletResponse response, HttpServletRequest request) throws IOException {

		logService.callGsApAccessLog(request, GsActTypeConstants.EX); // 공통 로그 생성

		logExcelDownloadService.downloadMenuAccessLogListExcel(condition, response);
	}

	@Operation(summary = "I/F 로그 엑셀 다운로드")
	@PostMapping(value = "/v1/if/list/excel-download")
	public void downLoadIFLogListExcel(@RequestBody ExcelRequestVO<IfLogRequestVO> condition,
		HttpServletResponse response, HttpServletRequest request) throws IOException {

		logService.callGsApAccessLog(request, GsActTypeConstants.EX); // 공통 로그 생성

		logExcelDownloadService.downloadIFLogListExcel(condition, response);
	}

	@Operation(summary = "배치 로그 엑셀 다운로드")
	@PostMapping(value = "/v1/batch/list/excel-download")
	public void downLoadBatchLogListExcel(@RequestBody ExcelRequestVO<BatchLogVO> condition,
		HttpServletResponse response, HttpServletRequest request) throws IOException {

		logService.callGsApAccessLog(request, GsActTypeConstants.EX); // 공통 로그 생성

		logExcelDownloadService.downloadBatchLogListExcel(condition, response);
	}
}
