package com.gsenc.wsf.log.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;
import com.gsenc.wsf.common.model.PaginationResponseVO;
import com.gsenc.wsf.log.model.BatchLogVO;
import com.gsenc.wsf.log.service.BatchLogService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "Batch Log")
@Validated
@RequestMapping("/api")

public class BatchLogController {
	private final BatchLogService batchLogService;

	@Operation(summary = "배치로그 목록 조회")
	@GetMapping(value = "/v1/admin/batch-log", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<PaginationResponseVO<BatchLogVO>>> findBbsPosts(
		@Valid BatchLogVO condition) {
		return new ResponseEntity<>(CommonResponseVO.<PaginationResponseVO<BatchLogVO>>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(batchLogService.findBatchLogList(condition))
			.build(), HttpStatus.OK);
	}
}
