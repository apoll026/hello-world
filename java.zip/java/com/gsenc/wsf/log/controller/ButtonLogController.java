package com.gsenc.wsf.log.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;
import com.gsenc.wsf.common.model.PaginationResponseVO;
import com.gsenc.wsf.log.model.ButtonLogRequestVO;
import com.gsenc.wsf.log.model.ButtonLogResponseVO;
import com.gsenc.wsf.log.model.ButtonLogVO;
import com.gsenc.wsf.log.service.ButtonLogService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "Button Log")
@Validated
@RequestMapping("/api")
public class ButtonLogController {

	private final ButtonLogService buttonLogService;

	@Operation(summary = "버튼로그 목록 조회")
	@GetMapping(value = "/v1/admin/button-log", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<PaginationResponseVO<ButtonLogResponseVO>>> findButtonLogList(
		@Valid ButtonLogRequestVO buttonLogRequestVO) {
		return new ResponseEntity<>(CommonResponseVO.<PaginationResponseVO<ButtonLogResponseVO>>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(buttonLogService.findButtonLogList(buttonLogRequestVO))
			.build(), HttpStatus.OK);
	}

	@Operation(summary = "버튼로그 목록 추가")
	@PostMapping(value = "/v1/admin/button-log", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<String>> saveButtonClickLog(@RequestBody ButtonLogVO buttonLogVO) {
		return new ResponseEntity<>(CommonResponseVO.<String>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(buttonLogService.saveButtonClickLog(buttonLogVO.getBtnKeyCd()))
			.build(), HttpStatus.OK);
	}
}
