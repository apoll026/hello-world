package com.gsenc.wsf.log.service;

import com.gsenc.wsf.common.model.PaginationResponseVO;
import com.gsenc.wsf.log.model.IfLogRequestVO;
import com.gsenc.wsf.log.model.IfLogResponseVO;

public interface IfLogService {
    PaginationResponseVO<IfLogResponseVO> findIfLogList(IfLogRequestVO condition);
}
