package com.gsenc.wsf.log.service;

import org.springframework.stereotype.Service;

import com.gsenc.wsf.common.model.PaginationResponseVO;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.log.model.EmailLogRequestVO;
import com.gsenc.wsf.log.model.EmailLogResponseVO;
import com.gsenc.wsf.log.repository.EmailLogRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class EmailLogServiceImpl implements EmailLogService{
    private final EmailLogRepository emailLogRepository;


    @Override
    public PaginationResponseVO<EmailLogResponseVO> findEmailLogList(EmailLogRequestVO condition) {
        return PaginationResponseVO.<EmailLogResponseVO>builder()
                .totalCount(emailLogRepository.selectEmailLogListCount(condition))
                .list(emailLogRepository.selectEmailLogList(condition, SessionScopeUtil.getContextSession()))
                .build();
    }
}
