package com.gsenc.wsf.log.service;

import com.gsenc.wsf.common.model.PaginationResponseVO;
import com.gsenc.wsf.log.model.EmailLogRequestVO;
import com.gsenc.wsf.log.model.EmailLogResponseVO;

public interface EmailLogService {
    PaginationResponseVO<EmailLogResponseVO> findEmailLogList(EmailLogRequestVO condition);
}
