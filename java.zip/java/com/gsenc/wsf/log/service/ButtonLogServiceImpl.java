package com.gsenc.wsf.log.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.exception.BusinessException;
import com.gsenc.wsf.common.model.PaginationResponseVO;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.log.model.ButtonLogRequestVO;
import com.gsenc.wsf.log.model.ButtonLogResponseVO;
import com.gsenc.wsf.log.model.ButtonLogVO;
import com.gsenc.wsf.log.repository.ButtonLogRepository;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class ButtonLogServiceImpl implements ButtonLogService {
	private final ButtonLogRepository buttonLogRepository;

	@Transactional
	@Override
	public String saveButtonClickLog(String btnKryCd) {
		try {
			ButtonLogVO buttonLogVO = ButtonLogVO.from(btnKryCd);
			UserSessionVO UserSessionVO = SessionScopeUtil.getContextSession();
			if (buttonLogRepository.insertButtonLog(buttonLogVO, UserSessionVO) == 1) {
				return "success";
			} else {
				throw new BusinessException("저장 실패.", StatusCodeConstants.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.info("ButtonLogServiceImpl.createButtonLog() :: FAILED");
			log.debug(e.getMessage(), e);
			throw new BusinessException(e.getMessage(), e);
		}
	}

	public PaginationResponseVO<ButtonLogResponseVO> findButtonLogList(ButtonLogRequestVO buttonLogRequestVO) {
		try {
			return PaginationResponseVO.<ButtonLogResponseVO>builder()
				.totalCount(buttonLogRepository.selectButtonLogListCount(buttonLogRequestVO))
				.list(buttonLogRepository.selectButtonLogList(buttonLogRequestVO, SessionScopeUtil.getContextSession()))
				.build();
		} catch (Exception e) {
			log.info("ButtonLogServiceImpl.findButtonLogList() :: FAILED");
			log.debug(e.getMessage(), e);
			throw new BusinessException(e.getMessage(), e);
		}
	}
}
