package com.gsenc.wsf.log.service;

import com.gsenc.wsf.common.model.PaginationResponseVO;
import com.gsenc.wsf.log.model.LoginLogRequestVO;
import com.gsenc.wsf.log.model.LoginLogResponseVO;

public interface LoginLogService {
    PaginationResponseVO<LoginLogResponseVO> findLoginLogs(LoginLogRequestVO condition);
}
