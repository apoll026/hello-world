package com.gsenc.wsf.log.service;

import org.springframework.stereotype.Service;

import com.gsenc.wsf.common.model.PaginationResponseVO;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.log.model.LoginLogRequestVO;
import com.gsenc.wsf.log.model.LoginLogResponseVO;
import com.gsenc.wsf.log.repository.LoginLogRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class LoginLogServiceImpl implements LoginLogService {
    private final LoginLogRepository loginLogRepository;

    @Override
    public PaginationResponseVO<LoginLogResponseVO> findLoginLogs(LoginLogRequestVO condition) {
        return PaginationResponseVO.<LoginLogResponseVO>builder()
                .totalCount(loginLogRepository.selectLoginLogListCount(condition))
                .list(loginLogRepository.selectLoginLogList(condition, SessionScopeUtil.getContextSession()))
                .build();
    }
}
