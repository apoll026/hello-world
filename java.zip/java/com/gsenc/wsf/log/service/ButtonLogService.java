package com.gsenc.wsf.log.service;


import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.common.model.PaginationResponseVO;
import com.gsenc.wsf.log.model.ButtonLogRequestVO;
import com.gsenc.wsf.log.model.ButtonLogResponseVO;


public interface ButtonLogService {
    String saveButtonClickLog(String btnKryCd);

    PaginationResponseVO<ButtonLogResponseVO> findButtonLogList(@Param("condition") ButtonLogRequestVO buttonLogRequestVO );
}
