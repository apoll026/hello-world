package com.gsenc.wsf.log.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.gsenc.wsf.common.constant.GsActTypeConstants;
import com.gsenc.wsf.common.filter.BufferedRequestWrapper;
import com.gsenc.wsf.common.util.RequestUtil;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.common.util.StringUtil;
import com.gsenc.wsf.log.model.EmailSendLogVO;
import com.gsenc.wsf.log.model.GsLogVO;
import com.gsenc.wsf.log.model.IfLogVO;
import com.gsenc.wsf.log.repository.EmailSendLogRepository;
import com.gsenc.wsf.log.repository.IfLogRepository;
import com.gsenc.wsf.log.repository.MenuAccessLogRepository;
import com.gsenc.wsf.session.model.UserSessionVO;

import antlr.actions.cpp.ActionLexerTokenTypes;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class LogServiceImpl implements LogService {

	private final MenuAccessLogRepository menuAccessLogRepository;
	private final EmailSendLogRepository emailSendLogRepository;
	private final IfLogRepository ifLogRepository;

	@Value("${system.id}")
	private String systemId;

	@Value("${system.name}")
	private String systemName;

	@Value("${spring.profiles.active}")
	private String profile;

	@Override
	@Async
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void createMenuAccessLog(String pgmId) {
		try {
			if ("default".equals(profile)) {
				return;
			}

			UserSessionVO session = SessionScopeUtil.getContextSession();
			if (session == null)
				return;
			menuAccessLogRepository.insertMenuAccessLog(pgmId, session);    // 메뉴 접근 로그
		} catch (Exception e) {
			log.info("LogServiceImpl.createMenuAccessLog() :: FAILED");
			log.debug(e.getMessage(), e);
		}
	}

	/**
	 * Interceptor에서 호출하는 GS 공통 로그
	 * actType은 Request Method로 구분
	 * @param request
	 */
	@Override
	@Async
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void callGsApAccessLog(HttpServletRequest request) {
		callGsApAccessLog(request, null, null);
	}

	/**
	 * Excel 다운로드 등 Controller/Service에서 호출
	 * @param request
	 * @param actType
	 */
	@Override
	@Async
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void callGsApAccessLog(HttpServletRequest request, String actType) {
		callGsApAccessLog(request, actType, null);
	}

	/**
	 * 화면 접근/이탈 로그 발생시 직접 호출
	 * @param req
	 * @param actType
	 * @param apiUrl
	 */
	@Override
	@Async
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void callGsApAccessLog(HttpServletRequest req, String actType, String apiUrl) {

		try {

			// AP_ACCESS_LOG 로컬에서도 남게 주석
			if ("default".equals(profile)) {
				return;
			}

			BufferedRequestWrapper request = new BufferedRequestWrapper(req);
			UserSessionVO session = SessionScopeUtil.getContextSession();
			if (session == null)
				return;

			String clntType = "N";

			if (actType == null) {
				String httpMthdCd = request.getMethod();
				actType = GsActTypeConstants.WR;

				if ("GET".equals(httpMthdCd)) {
					actType = GsActTypeConstants.RE;
				}
			}

			String requestBody = null;

			if (apiUrl == null) {
				apiUrl = request.getRequestURI();
				requestBody = RequestUtil.getRequestParametersAsJson(request);
			}

			GsLogVO gsLogVO = GsLogVO.builder()
				.apiUrl(apiUrl)
				.requestBody(StringUtil.truncateToOracleVarchar(requestBody))
				.actType(actType)
				.clntType(clntType)
				.systemId(systemId)
				.programId(apiUrl)
				.systemName(systemName)
				.build();
			menuAccessLogRepository.callGsApAccessLog(gsLogVO, session);    // 메뉴 접근 로그
		} catch (Exception e) {
			log.error("LogServiceImpl.callGsApAccessLog() :: FAILED");
			log.error(e.getMessage(), e);
		}
	}

	@Override
	@Async
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public long createEmailSendLog(EmailSendLogVO emailSendLogVO) {
		try {
			UserSessionVO session = SessionScopeUtil.getContextSession();
			// Batch 등 Session 이 없을때 호출 될 수 도 있음.
			if (session == null) {
				session = UserSessionVO.builder()
					.mailId(emailSendLogVO.getDataInsUserId())
					.userIp(emailSendLogVO.getDataInsUserIp())
					.build();
			}
			long emlLogSeq = emailSendLogRepository.selectEmlLogSeq();
			emailSendLogVO.setEmlLogSeq(emlLogSeq);

			emailSendLogRepository.insertEmailSendLog(emailSendLogVO, session);

			return emlLogSeq;
		} catch (Exception e) {
			log.info("LogServiceImpl.createEmailSendLog() :: FAILED");
			log.debug(e.getMessage(), e);
		}

		return 0;
	}

	@Override
	@Async
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void createIfLog(IfLogVO ifLogVO) {
		try {
			UserSessionVO session = SessionScopeUtil.getContextSession();
			// Batch 등 Session 이 없을때 호출 될 수 도 있음.
			if (session == null) {
				session = UserSessionVO.builder()
					.mailId(ifLogVO.getDataInsUserId())
					.userIp(ifLogVO.getDataInsUserIp())
					.build();
			}

			ifLogRepository.insertIfLog(ifLogVO, session);
		} catch (Exception e) {
			log.info("LogServiceImpl.createIfLog() :: FAILED");
			log.debug(e.getMessage(), e);
		}

	}

}
