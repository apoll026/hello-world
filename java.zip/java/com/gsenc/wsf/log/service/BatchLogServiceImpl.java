package com.gsenc.wsf.log.service;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.gsenc.wsf.common.model.PaginationResponseVO;
import com.gsenc.wsf.log.model.BatchLogVO;
import com.gsenc.wsf.log.repository.BatchLogRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class BatchLogServiceImpl implements BatchLogService{


    private final BatchLogRepository batchLogRepository;


    @Override
    @Async
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void createBatchLog(BatchLogVO batchVO) {
        try {
            batchVO.setDataInsUserId("BATCH");
            batchVO.setDataUpdUserId("BATCH");
            batchLogRepository.insertBatchLog(batchVO);
        } catch (Exception e) {
            log.info("BatchLogServiceImpl.createBatchLog() :: FAILED");
            log.debug(e.getMessage(),e);
        }

    }
    @Override
    public PaginationResponseVO<BatchLogVO> findBatchLogList(BatchLogVO condition) {
        return PaginationResponseVO.<BatchLogVO>builder()
                .totalCount(batchLogRepository.selectBatchLogListCount(condition))
                .list(batchLogRepository.selectBatchLogList(condition))
                .build();
    }
}
