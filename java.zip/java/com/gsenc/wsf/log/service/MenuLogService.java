package com.gsenc.wsf.log.service;

import com.gsenc.wsf.common.model.PaginationResponseVO;
import com.gsenc.wsf.log.model.MenuLogRequestVO;
import com.gsenc.wsf.log.model.MenuLogResponseVO;

public interface MenuLogService {
    PaginationResponseVO<MenuLogResponseVO> findMenuLogList(MenuLogRequestVO condition);
}
