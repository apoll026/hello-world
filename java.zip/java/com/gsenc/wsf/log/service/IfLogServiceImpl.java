package com.gsenc.wsf.log.service;

import org.springframework.stereotype.Service;

import com.gsenc.wsf.common.model.PaginationResponseVO;
import com.gsenc.wsf.log.model.IfLogRequestVO;
import com.gsenc.wsf.log.model.IfLogResponseVO;
import com.gsenc.wsf.log.repository.IfLogRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class IfLogServiceImpl implements IfLogService{
    private final IfLogRepository ifLogRepository;

    @Override
    public PaginationResponseVO<IfLogResponseVO> findIfLogList(IfLogRequestVO condition) {
        return PaginationResponseVO.<IfLogResponseVO>builder()
                .totalCount(ifLogRepository.selectIfLogListCount(condition))
                .list(ifLogRepository.selectIfLogList(condition))
                .build();
    }
}
