package com.gsenc.wsf.log.service;

import com.gsenc.wsf.log.model.EmailSendLogVO;
import com.gsenc.wsf.log.model.IfLogVO;

import jakarta.servlet.http.HttpServletRequest;

public interface LogService {

	void createMenuAccessLog(String pgmId);

	long createEmailSendLog(EmailSendLogVO emailSendLogVO);

	void createIfLog(IfLogVO ifLogVO);

	void callGsApAccessLog(HttpServletRequest request);

	void callGsApAccessLog(HttpServletRequest request, String actType);

	void callGsApAccessLog(HttpServletRequest request, String actType, String menuUrl);
}
