package com.gsenc.wsf.log.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gsenc.wsf.common.model.PaginationResponseVO;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.log.model.MenuLogRequestVO;
import com.gsenc.wsf.log.model.MenuLogResponseVO;
import com.gsenc.wsf.log.repository.MenuLogRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class MenuLogServiceImpl implements MenuLogService {
    private final MenuLogRepository menuLogRepository;
    @Override
    @Transactional(readOnly = true)
    public PaginationResponseVO<MenuLogResponseVO> findMenuLogList(MenuLogRequestVO condition) {
        return PaginationResponseVO.<MenuLogResponseVO>builder()
                .totalCount(menuLogRepository.selectMenuLogListCount(condition))
                .list(menuLogRepository.selectMenuLogList(condition, SessionScopeUtil.getContextSession()))
                .build();
    }
}
