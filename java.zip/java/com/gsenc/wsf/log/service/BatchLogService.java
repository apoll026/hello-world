package com.gsenc.wsf.log.service;

import com.gsenc.wsf.common.model.PaginationResponseVO;
import com.gsenc.wsf.log.model.BatchLogVO;

public interface BatchLogService {
    PaginationResponseVO<BatchLogVO> findBatchLogList(BatchLogVO condition);
    void createBatchLog(BatchLogVO batchVO);
}
