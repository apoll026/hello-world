package com.gsenc.wsf.session.controller;

import static org.springframework.http.HttpStatus.*;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.exception.BusinessException;
import com.gsenc.wsf.common.model.CommonResponseVO;
import com.gsenc.wsf.common.service.PersonalSearchService;
import com.gsenc.wsf.common.util.NetworkUtil;
import com.gsenc.wsf.company.service.CompanyService;
import com.gsenc.wsf.employee.service.EmployeeService;
import com.gsenc.wsf.session.model.*;
import com.gsenc.wsf.session.service.SessionService;
import com.gsenc.wsf.verification.model.UserVO;
import com.gsenc.wsf.verification.service.VerificationService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequiredArgsConstructor
@Tag(name = "0. Session")
@Validated
@Slf4j
@RequestMapping("/api")
public class SessionController {

	private final SessionService sessionService;
	private final EmployeeService employeeService;
	private final PersonalSearchService personalSearchService;
	private final VerificationService verificationService;
	private final CompanyService companyService;

	@Value("${activeProfile}")
	private String activeProfile;

	@Value("${system.devLoginPassword}")
	private String devLoginPassword;

	@Operation(summary = "FW제공 개발용 로그인 및 세션 생성")
	@PostMapping(value = "/v1/dev/login", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<UserSessionVO>> login(
		@RequestBody DevLoginRequestVO devLoginRequest,
		HttpServletRequest request,
		HttpServletResponse response)
		throws BusinessException {

		//devLoginRequest.setMailId("yang.bongug");
		//devLoginRequest.setUserPass("f3bfe5b0f2ed58d20873c045ec1570069bc9520fbf368394670911a8eb8ee97a4f872f18b0df1040cf9933b4dd466709aa664b791fb86f619dda2138d0555d48");

		EmployeeVO employeeInfo = employeeService.selectEmployeeByUserId(devLoginRequest.getMailId());

		// 사용자가 없는 경우
		if (employeeInfo == null) {
			return new ResponseEntity(CommonResponseVO.<UserSessionVO>builder()
				.successOrNot(CommonConstants.NO_FLAG)
				.statusCode(StatusCodeConstants.USER_NOT_FOUND)
				.build(), OK);
		}
		// TODO : 전자전표 백도어 로그인 로직 필요
		if (!"default".equals(activeProfile)) {
		}

		HttpSession session = request.getSession();
		String userIp = NetworkUtil.getClientIP(request);

		UserSessionVO userSession = sessionService.createUserSession(
			devLoginRequest.getMailId(),
			devLoginRequest.getLangCd(),
			userIp
		);

		if (userSession != null) {
			userSession.setFormLogin(true);
			session.setAttribute(CommonConstants.HTTP_SESSION_KEY, userSession);

			return new ResponseEntity(CommonResponseVO.<UserSessionVO>builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(userSession)
				.build(), OK);
		} else {
			return new ResponseEntity(CommonResponseVO.<UserSessionVO>builder()
				.successOrNot(CommonConstants.NO_FLAG)
				.statusCode(StatusCodeConstants.USER_NOT_FOUND)
				.build(), OK);
		}
	}

	@Operation(summary = "FW제공 개발용 로그인 및 세션 생성")
	@PostMapping(value = "/v1/dev/outlogin", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<UserSessionVO>> outlogin(
			@RequestBody DevLoginRequestVO devLoginRequest,
			HttpServletRequest request,
			HttpServletResponse response)
			throws BusinessException {
		log.info("outlogin init");
		log.info(devLoginRequest.getCmpnNum());
		log.info(devLoginRequest.getSerialNumberHex());
		//devLoginRequest.setMailId("yang.bongug");
		//devLoginRequest.setUserPass("f3bfe5b0f2ed58d20873c045ec1570069bc9520fbf368394670911a8eb8ee97a4f872f18b0df1040cf9933b4dd466709aa664b791fb86f619dda2138d0555d48");

		CmpnCodeVO cmpnCode = companyService.selectSpCheckLogin(devLoginRequest.getCmpnNum(), devLoginRequest.getSerialNumberHex());

		// 사용자가 없는 경우
		if (cmpnCode == null) {
			return new ResponseEntity(CommonResponseVO.<UserSessionVO>builder()
					.successOrNot(CommonConstants.NO_FLAG)
					.statusCode(StatusCodeConstants.USER_NOT_FOUND)
					.build(), OK);
		}
		// TODO : 전자전표 백도어 로그인 로직 필요
		if (!"default".equals(activeProfile)) {
		}

		HttpSession session = request.getSession();
		String userIp = NetworkUtil.getClientIP(request);

		UserCompanySessionVO userSession = sessionService.createUserCompanySession(
				devLoginRequest.getCmpnNum(),
				devLoginRequest.getLangCd(),
				userIp
		);

		if (userSession != null) {
			userSession.setFormLogin(true);
			session.setAttribute(CommonConstants.HTTP_SESSION_KEY, userSession);

			return new ResponseEntity(CommonResponseVO.<UserCompanySessionVO>builder()
					.successOrNot(CommonConstants.YES_FLAG)
					.statusCode(StatusCodeConstants.SUCCESS)
					.data(userSession)
					.build(), OK);
		} else {
			return new ResponseEntity(CommonResponseVO.<UserCompanySessionVO>builder()
					.successOrNot(CommonConstants.NO_FLAG)
					.statusCode(StatusCodeConstants.USER_NOT_FOUND)
					.build(), OK);
		}
	}

	@Operation(summary = "ID/PW 확인 및 인증번호 발송")
	@PostMapping(value = "/v1/verify/sendCertNumber", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<?>> sendCertNumber(
		@RequestBody DevLoginRequestVO devLoginRequest,
		HttpServletRequest request) {

		devLoginRequest.setMailId("yang.bongug");
		devLoginRequest.setUserPass("f3bfe5b0f2ed58d20873c045ec1570069bc9520fbf368394670911a8eb8ee97a4f872f18b0df1040cf9933b4dd466709aa664b791fb86f619dda2138d0555d48");

		EmployeeVO employeeInfo = employeeService.selectEmployeeByUserId(devLoginRequest.getMailId());

		// 사용자가 없는 경우
		if (employeeInfo == null || !devLoginPassword.trim().equals(devLoginRequest.getUserPass())) {
			return new ResponseEntity(CommonResponseVO.<UserSessionVO>builder()
				.successOrNot(CommonConstants.NO_FLAG)
				.statusCode(StatusCodeConstants.USER_NOT_FOUND)
				.build(), HttpStatus.OK);
		}

		return new ResponseEntity<>(
			CommonResponseVO.builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(verificationService.sendCertNumber(request))
				.build(),
			HttpStatus.OK);
	}

	@Operation(summary = "Admin IP 등록 여부 체크")
	@PostMapping(value = "/v1/verify/checkAdminIp", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<?>> checkAdminIp(
		HttpServletRequest request) {

		UserVO userVO = verificationService.checkAdminIp(request);

		// 사용자가 없는 경우
		if (userVO == null) {
			return new ResponseEntity(CommonResponseVO.<UserSessionVO>builder()
				.successOrNot(CommonConstants.NO_FLAG)
				.statusCode(StatusCodeConstants.USER_NOT_FOUND)
				.build(), HttpStatus.OK);
		}

		return new ResponseEntity<>(
			CommonResponseVO.builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(userVO)
				.build(),
			HttpStatus.OK);
	}

	@Operation(summary = "인증번호 검증 및 로그인")
	@PostMapping(value = "/v1/verify/checkCertNumber", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<?>> checkCertNumber(
		@RequestBody DevLoginRequestVO devLoginRequest,
		HttpServletRequest request) {

		if (!verificationService.checkCertNumber(devLoginRequest, request)) {
			return new ResponseEntity(CommonResponseVO.<UserSessionVO>builder()
				.successOrNot(CommonConstants.NO_FLAG)
				.statusCode(StatusCodeConstants.AUTHENTICATION_FAILED)
				.build(), HttpStatus.OK);
		}

		String userIp = NetworkUtil.getClientIP(request);

		HttpSession session = request.getSession();
		UserSessionVO userSession = sessionService.createUserSession(
			devLoginRequest.getMailId(),
			devLoginRequest.getLangCd(),
			userIp
		);

		userSession.setFormLogin(true);
		session.setAttribute(CommonConstants.HTTP_SESSION_KEY, userSession);
		return new ResponseEntity(CommonResponseVO.<UserSessionVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(userSession)
			.build(), OK);
	}

	@Operation(summary = "세션 조회")
	@GetMapping(value = "/v1/session", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<UserCompanySessionVO>> getSession(
		HttpServletRequest request)
		throws Exception {

		HttpSession session = request.getSession();
		UserCompanySessionVO userSession = (UserCompanySessionVO)session.getAttribute(CommonConstants.HTTP_SESSION_KEY);

		// 2025-04-09 서용태 (검색조건 개인화 데이터)
		userSession.setPersonalSearches(personalSearchService.selectPersonalSearch(request, userSession));

		return new ResponseEntity(CommonResponseVO.<UserCompanySessionVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(userSession)
			.build(), OK);
	}

	@Operation(summary = "세션 언어 변경")
	@PutMapping(value = "/v1/session/langCd", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO> updateUserSessionLangCd(
		@RequestBody @Parameter(description = "언어", example = "ko", required = true) String langCd)
		throws BusinessException {

		sessionService.updateUserSessionLangCd(langCd);

		return new ResponseEntity(CommonResponseVO.builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.build(), OK);
	}

	@Operation(summary = "세션 메뉴 변경")
	@PutMapping(value = "/v1/session/menus", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO> updateUserSessionMenus() throws BusinessException {
		sessionService.updateUserSessionMenus();

		return new ResponseEntity(CommonResponseVO.builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.build(), OK);
	}
}
