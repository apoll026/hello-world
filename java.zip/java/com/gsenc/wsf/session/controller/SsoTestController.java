package com.gsenc.wsf.session.controller;

import static org.springframework.http.HttpStatus.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.wsf.common.component.SsoManager;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.exception.BusinessException;
import com.gsenc.wsf.common.model.CommonResponseVO;
import com.gsenc.wsf.common.model.SsoVO;

import SafeIdentity.SSO;
import jakarta.servlet.http.HttpServletRequest;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@Slf4j
public class SsoTestController {

	private final SsoManager ssoManager;

	/**
	 * SSO 토큰 테스트 API
	 * 프론트엔드에서 전달받은 토큰을 검증하고 결과를 반환
	 */
	@PostMapping("/v1/sso/test")
	public ResponseEntity<CommonResponseVO<SsoTestResult>> testSsoToken(
		@RequestBody SsoTestRequest request,
		HttpServletRequest httpRequest) {

		SsoTestResult result = new SsoTestResult();

		try {
			// 1. 요청 정보 설정
			String testToken = request.getToken();
			String remoteAddr = httpRequest.getRemoteAddr();

			result.setInputToken(testToken);
			result.setRemoteAddress(remoteAddr);
			result.setTestTime(LocalDateTime.now());

			// 2. 토큰 유효성 기본 체크
			if (testToken == null || testToken.isEmpty()) {
				result.setSuccess(false);
				result.setErrorCode(-441);
				result.setErrorMessage("Token 값이 존재하지 않습니다. 로그인 상태를 확인해 주세요.");
				return new ResponseEntity(CommonResponseVO.<SsoTestResult>builder()
					.successOrNot(CommonConstants.NO_FLAG)
					.statusCode(StatusCodeConstants.NOT_VALID_SSO_TOKEN)
					.build(), BAD_REQUEST);
			}

			// 3. SSO 토큰 검증 수행
			SSO sso = ssoManager.verifySsoToken(testToken, remoteAddr);

			// 4. 검증 성공 시 사용자 정보 추출
			SsoVO ssoInfo = SsoManager.buildSsoVO(sso);

			// 5. 결과 설정
			result.setSuccess(true);
			result.setSsoInfo(ssoInfo);
			result.setRawSsoData(extractRawSsoData(sso));

			log.info("SSO 토큰 테스트 성공: userId={}, remoteAddr={}", ssoInfo.getUserId(), remoteAddr);

		} catch (BusinessException e) {
			// SSO 검증 실패
			result.setSuccess(false);
			result.setErrorMessage(e.getMessage());

			// 에러 코드 추출 (메시지에서 파싱하거나 별도 필드로 관리)
			result.setErrorCode(extractErrorCodeFromMessage(e.getMessage()));

			log.warn("SSO 토큰 테스트 실패: {}", e.getMessage());

		} catch (Exception e) {
			// 예상치 못한 오류
			result.setSuccess(false);
			result.setErrorMessage("SSO 테스트 중 예상치 못한 오류가 발생했습니다: " + e.getMessage());
			result.setErrorCode(-9999);

			log.error("SSO 토큰 테스트 중 예외 발생", e);
		}

		return new ResponseEntity(CommonResponseVO.<SsoTestResult>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(result)
			.build(), OK);
	}

	/**
	 * SSO 객체에서 Raw 데이터 추출 (디버깅용)
	 */
	private Map<String, Object> extractRawSsoData(SSO sso) {
		Map<String, Object> rawData = new HashMap<>();

		try {
			rawData.put("userID", sso.getValueUserID());
			rawData.put("USERID", sso.getValue("USERID"));
			rawData.put("EMPNO", sso.getValue("EMPNO"));
			rawData.put("USERTYPE", sso.getValue("USERTYPE"));
			rawData.put("LOCALE", sso.getValue("LOCALE"));

			// 추가 필드들도 확인 (SSO 시스템에 따라 다를 수 있음)
			rawData.put("USERNAME", sso.getValue("USERNAME"));
			rawData.put("DEPT", sso.getValue("DEPT"));
			rawData.put("EMAIL", sso.getValue("EMAIL"));

		} catch (Exception e) {
			log.warn("SSO Raw 데이터 추출 중 오류: {}", e.getMessage());
		}

		return rawData;
	}

	/**
	 * 에러 메시지에서 에러 코드 추출
	 */
	private Integer extractErrorCodeFromMessage(String errorMessage) {
		// SsoManager의 ERROR_MESSAGES에서 역추적
		Map<Integer, String> errorMessages = getErrorMessages();

		for (Map.Entry<Integer, String> entry : errorMessages.entrySet()) {
			if (errorMessage.contains(entry.getValue())) {
				return entry.getKey();
			}
		}

		return null; // 코드를 찾을 수 없는 경우
	}

	/**
	 * SsoManager의 에러 메시지 맵 반환 (실제로는 SsoManager에서 가져와야 함)
	 */
	private Map<Integer, String> getErrorMessages() {
		Map<Integer, String> errorMessages = new HashMap<>();
		errorMessages.put(-441, "Token 값이 존재 하지 않습니다. 로그인 상태를 확인해 주세요.");
		errorMessages.put(-442, "Token 값이 존재 하지 않습니다. 로그인 상태를 확인해 주세요.");
		errorMessages.put(-448, "SSO Agent, PolicyServer가 응답하지 않습니다.");
		errorMessages.put(-710, "SSO Agent, PolicyServer가 응답하지 않습니다.");
		errorMessages.put(-748, "SSO Agent, PolicyServer가 응답하지 않습니다.");
		errorMessages.put(-771, "SSO Agent, PolicyServer가 응답하지 않습니다.");
		errorMessages.put(-1032, "SSO Agent, PolicyServer가 응답하지 않습니다.");
		errorMessages.put(-1033, "SSO Agent, PolicyServer가 응답하지 않습니다.");
		errorMessages.put(-1205, "다시 로그인해주세요.");
		errorMessages.put(-1207, "다시 로그인해주세요.");
		errorMessages.put(-2902, "사용자의 세션이 만료되었습니다. 다시 로그인해주세요.");
		errorMessages.put(-2919, "허용된 동시접속 개수를 초과하였습니다.");
		errorMessages.put(-2979, "사용자의 요청이 너무 많아 정책서버가 요청을 처리하지 못했습니다. 잠시 후에 다시 시도해주세요.");
		return errorMessages;
	}

	/**
	 * SSO 테스트 요청 DTO
	 */
	@Data
	public static class SsoTestRequest {
		private String token;
	}

	/**
	 * SSO 테스트 결과 DTO
	 */
	@Data
	public static class SsoTestResult {
		private boolean success;
		private String inputToken;
		private String remoteAddress;
		private LocalDateTime testTime;

		// 성공 시 정보
		private SsoVO ssoInfo;
		private Map<String, Object> rawSsoData;

		// 실패 시 정보
		private Integer errorCode;
		private String errorMessage;

		// 추가 디버깅 정보
		private String debugInfo;
	}
}
