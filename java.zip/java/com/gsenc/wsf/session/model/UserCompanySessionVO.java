package com.gsenc.wsf.session.model;

import java.io.Serializable;
import java.util.List;

import com.gsenc.wsf.common.model.PersonalSearchVO;
import com.gsenc.wsf.menu.model.MenuResponseVO;
import com.gsenc.wsf.role.model.RoleButtonResponseVO;

import lombok.*;

@Data
@Builder
@NoArgsConstructor
@ToString
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class UserCompanySessionVO implements Serializable {

	private static final long serialVersionUID = 1L;

	/** 기존 AMXIS 필드 */
	/** 사용자 IP */
	private String userIp;
	/** 다국어 정보 */
	private String langCd;
	/** 권한 코드목록 */
	private List<String> roleCodes;
	/** 버튼권한 코드목록 */
	private List<RoleButtonResponseVO> roleButtonCodes;
	/** 개인화 검색 목록 */
	private List<PersonalSearchVO> personalSearches;
	/** 접근 가능 메뉴목록 */
	private List<MenuResponseVO> menus;
	/** 타임존 코드 */
	private String timeZoneCd;

	private String empNo;

	private String mailId;

	private String auth;

	private String userGrp;

	private String deptCode;

	/** 세션 필드 */
	/** 업체사업자번호 */
	private String cmpnNum;
	/** 사업장전화번호 */
	private String cmpnOffice;
	/** HP 번호 */
	private String cmpnMobile;
	/** Email 담당자 */
	private String cmpnEmail;
	/** 담당자 */
	private String cmpnManagerName;

	/** 업체코드 */
	private String cmpnCode;
	/** 인증서 Seq No */
	private String certSeq;
	/** 제출일자 */
	private String smtYmd;
	/** 유효기간 시작일 */
	private String validFromYmd;
	/** 유효기간 만기일 */
	private String validEndYmd;
	/** 발행인증기관 */
	private String certAuth;
	/** 인증기관코드 */
	private String certAuthCd;
	/** 인증서 DN */
	private String certDn;
	/** 인증서 내용 */
	private String certInfo;
	/** 해쉬값 */
	private String certHash;
	/** 인증서 OID */
	private String certOID;
	/** 저장매체 */
	private String certMedia;
	/** 승인일자 */
	private String apprYmd;
	/** 승인상태(0:미승인 1:승인 2:승인취소) */
	private String apprStauts;
	/** 사용상태(Y:사용,N:사용안함) */
	private String useStatus;
	/** 인증서 SERIAL */
	private String certSerial;
	/** 등록ID */
	private String regId;
	/** 등록일시 */
	private String regDate;
	/** 수정ID */
	private String updId;
	/** 수정일시 */
	private String updDate;
	/** 사업자번호 */
	private String BSCD;

	/** 사업자명 */
	private String cmpnName;
	/** 대표자명 */
	private String repsName;
	/** 사업장주소 */
	private String orgAddr;
	/**  */
	private String mngrName;
	/**  */
	private String mngrDept;
	/**  */
	private String cmpnOffic2;
	/**  */
	private String cmpnMobile2;
	/**  */
	private String cmpnEmail2;
	/**  */
	private String roleFlag;
	/**  */
	private String roleName;
	/**  */
	private String roleOffice;
	/**  */
	private String roleMobile;
	/** 승인상태 */
	private String applySttu;
	/** 암호화상태 */
	private String certSttu;
	/** 공급일자 */
	private String applyDate;
	/** 등록 사번 */
	private String updEmp;
	/** 부여권한 이메일 */
	private String roleEmail;
	/** 부여권한 주소 */
	private String roleAddr;
	/** 사용여부 */
	private String useYn;

	/** 폼 로그인 여부 */
	private boolean isFormLogin;

	public UserCompanySessionVO(
		CmpnCodeVO cmpnCodeVO,
		List<String> roleCodes,
		List<MenuResponseVO> menus,
		String langCd,
		String userIp
	) {
		this.mailId = cmpnCodeVO.getMailId();
		this.empNo = cmpnCodeVO.getEmpNo();
		this.cmpnCode = cmpnCodeVO.getCmpnCode();
		this.cmpnNum = cmpnCodeVO.getCmpnNum();
		this.cmpnOffice = cmpnCodeVO.getCmpnOffice();
		this.cmpnMobile = cmpnCodeVO.getCmpnMobile();
		this.cmpnEmail = cmpnCodeVO.getCmpnEmail();
		this.cmpnManagerName = cmpnCodeVO.getCmpnManagerName();
		this.certSeq = cmpnCodeVO.getCertSeq();
		this.smtYmd = cmpnCodeVO.getSmtYmd();
		this.validFromYmd = cmpnCodeVO.getValidFromYmd();
		this.validEndYmd = cmpnCodeVO.getValidEndYmd();
		this.certAuth = cmpnCodeVO.getCertAuth();
		this.certAuthCd = cmpnCodeVO.getCertAuthCd();
		this.certDn = cmpnCodeVO.getCertDn();
		this.certInfo = cmpnCodeVO.getCertInfo();
		this.certHash = cmpnCodeVO.getCertHash();
		this.certOID = cmpnCodeVO.getCertOID();
		this.certMedia = cmpnCodeVO.getCertMedia();
		this.apprYmd = cmpnCodeVO.getApprYmd();
		this.apprStauts = cmpnCodeVO.getApprStauts();
		this.useStatus = cmpnCodeVO.getUseStatus();
		this.certSerial = cmpnCodeVO.getCertSerial();
		this.regId = cmpnCodeVO.getRegId();
		this.regDate = cmpnCodeVO.getRegDate();
		this.updId = cmpnCodeVO.getUpdId();
		this.updDate = cmpnCodeVO.getUpdDate();
		this.BSCD = cmpnCodeVO.getBSCD();
		this.cmpnName = cmpnCodeVO.getCmpnName();
		this.repsName = cmpnCodeVO.getRepsName();
		this.orgAddr = cmpnCodeVO.getOrgAddr();
		this.mngrName = cmpnCodeVO.getMngrName();
		this.mngrDept = cmpnCodeVO.getMngrDept();
		this.cmpnOffic2 = cmpnCodeVO.getCmpnOffic2();
		this.cmpnMobile2 = cmpnCodeVO.getCmpnMobile2();
		this.cmpnEmail2 = cmpnCodeVO.getCmpnEmail2();
		this.roleFlag = cmpnCodeVO.getRoleFlag();
		this.roleName = cmpnCodeVO.getRoleName();
		this.roleOffice = cmpnCodeVO.getRoleOffice();
		this.roleMobile = cmpnCodeVO.getRoleMobile();
		this.applySttu = cmpnCodeVO.getApplySttu();
		this.certSttu = cmpnCodeVO.getCertSttu();
		this.applyDate = cmpnCodeVO.getApplyDate();
		this.updEmp = cmpnCodeVO.getUpdEmp();
		this.roleEmail = cmpnCodeVO.getRoleEmail();
		this.roleAddr = cmpnCodeVO.getRoleAddr();
		this.useYn = cmpnCodeVO.getUseYn();

		this.roleCodes = roleCodes;
		this.roleButtonCodes = roleButtonCodes;
		this.menus = menus;
		this.langCd = langCd;
		this.userIp = userIp;
	}
}
