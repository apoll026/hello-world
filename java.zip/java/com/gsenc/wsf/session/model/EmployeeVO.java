package com.gsenc.wsf.session.model;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Slf4j
public class EmployeeVO {

	/** 메일ID */
	private String mailId;
	/** 사번 */
	private String empNo;
	/** 사용자명 */
	private String empName;
	/** 패스워드 */
	private String passwd;
	/** 사용자상태 */
	private String empSttu;
	/** 부서코드 */
	private String deptCode;
	/** 부서명 */
	private String deptName;
	/** 리더사번 */
	private String lderEmpno;
	/** 직위 */
	private String titlCode;
	/** 직위명 */
	private String titlName;
	/** 직급 */
	private String grdeCode;
	/** 직급명 */
	private String grdeName;
	/** 권한 */
	private String auth;
	/** 현장(SA),본사(MA),리조트(RA) */
	private String ordrFlag;
	/** 전화번호 */
	private String empTel;
	/** 모바일번호 */
	private String empMobl;
	/** 최종수정자 */
	private String updEmpno;
	/** 최종수정일 */
	private String updDate;
	/** 최종수정ID */
	private String updId;
	/** 출장직급 */
	private String biztTitl;
	/** 주민번호 */
	private String empSsn;
	/** 영문명 */
	private String engName;
	/** 결재암호 */
	private String apprPasswd;
	/** 기술개발지원전송/사용여부권한 */
	private String actAuth;
	/** 카드사용권한 */
	private String cardAuth;
	/** 사용부서 */
	private String useDept;
	/** 주관부서담당파트 */
	private String partFlag;
	/** 미확인 */
	private String newWin;
	/** 품보비 사용권한 */
	private String quaAuth;
	/** 기타 권한 */
	private String frsAuth;
	/** A:인사시스템관리, B: 기타 */
	private String insaDivs;
	/** Y:재무업무 담당자 N:일반 */
	private String partCharge;
	/** 퇴직일 */
	private String retireDate;

	/** 패스워드 */
	private String userPass;
	/** 로그인 실패 카운트 */
	private int loginWrongCnt;

	/** 사이트코드 */
	private String siteCd;
	/** 기능영역 */
	private String funcArea;
	/** 기능영역명 */
	private String funcAreaName;
	/** 리더명 */
	private String lderEmpName;
	/** 리더부서코드 */
	private String lderDeptCode;
	/** 리더부서명 */
	private String lderDeptName;
	/** 리더직위코드 */
	private String lderTitlCode;
	/** 리더직위명 */
	private String lderTitlName;
	/** 부문코드 */
	private String dvsnCode;
	/** 주부서 */
	private String mainDept;
	/** 주부서명 */
	private String mainName;
	/** 사용자그룹 */
	private String userGrp;
	/** EIP패스워드 */
	private String eipPasswd;
	/** EIP패스워드512 */
	private String eipPasswd512;

	private String cmpnCode;

	private String cmpnNum;

}
