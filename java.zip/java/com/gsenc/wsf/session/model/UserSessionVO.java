package com.gsenc.wsf.session.model;

import java.io.Serializable;
import java.util.List;

import com.gsenc.wsf.common.model.PersonalSearchVO;
import com.gsenc.wsf.menu.model.MenuResponseVO;
import com.gsenc.wsf.role.model.RoleButtonResponseVO;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Builder
@NoArgsConstructor
@ToString
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class UserSessionVO implements Serializable {

	private static final long serialVersionUID = 1L;

	/** 기존 AMXIS 필드 */
	/** 사용자 IP */
	private String userIp;
	/** 다국어 정보 */
	private String langCd;
	/** 권한 코드목록 */
	private List<String> roleCodes;
	/** 버튼권한 코드목록 */
	private List<RoleButtonResponseVO> roleButtonCodes;
	/** 개인화 검색 목록 */
	private List<PersonalSearchVO> personalSearches;
	/** 접근 가능 메뉴목록 */
	private List<MenuResponseVO> menus;
	/** 타임존 코드 */
	private String timeZoneCd;

	/** UAT 세션 필드 */
	/** 출장 직급(D1~D6) */
	private String biztTitl;
	/** 부서/현장구분 1:본사, 2:현장 */
	private String siteCd;
	/** 메일 ID */
	private String mailId;
	/** 패스워드 */
	private String passwd;
	/** 사번 */
	private String empNo;
	/** 사용자명 */
	private String empName;
	/** 사용자 영문명 */
	private String engName;
	/** 직위코드 */
	private String titlCode;
	/** 직위명 */
	private String titlName;
	/** 직급명 */
	private String grdeName;
	/** 부서코드 */
	private String deptCode;
	/** 부서명 */
	private String deptName;
	/** 계정과목(FATY500_SAP.CLSS:A0 */
	private String funcArea;
	/** 계정과목명 */
	private String funcAreaName;
	/** 기술개발지원 전송/사용여부 권한 */
	private String actAuth;
	/** 현장(SA), 본사(MA), 리조트(RA) */
	private String ordrFlag;
	/** 권한 */
	private String auth;
	/** 리더이름 */
	private String lderEmpName;
	/** 리더사번 */
	private String lderEmpno;
	/** 리더 부서코드 */
	private String lderDeptCode;
	/** 리더 부서명 */
	private String lderDeptName;
	/** 리더 직위코드 */
	private String lderTitlCode;
	/** 리더 직위명 */
	private String lderTitlName;
	/** 사업부 코드 */
	private String dvsnCode;
	/** 전화번호 */
	private String empTel;
	/** 카드 권한 */
	private String cardAuth;
	/** 주 사용부서 코드 */
	private String mainDept;
	/** 주 사용부서명 */
	private String mainName;
	/** 담당파트 */
	private String partFlag;
	/** 사용자 그룹 */
	private String userGrp;
	/** 품보비 사용권한이 NULL 일 때 N */
	private String newWin;
	/** 품보비 사용권한 */
	private String quaAuth;
	/** 암호화 패스워드 */
	private String eipPasswd;
	/** 암호화 패스워드2 */
	private String eipPasswd512;
	/** 사업자 코드 */
	private String cmpnCode;
	/** 사업자등록번호 */
	private String cmpnNum;

	/** 폼 로그인 여부 */
	private boolean isFormLogin;

	public UserSessionVO(
		EmployeeVO employeeInfo,
		List<String> roleCodes,
		List<MenuResponseVO> menus,
		String langCd,
		String userIp
	) {
		this.mailId = employeeInfo.getMailId();
		this.empNo = employeeInfo.getEmpNo();
		this.empName = employeeInfo.getEmpName();
		this.passwd = employeeInfo.getPasswd();
		this.titlCode = employeeInfo.getTitlCode();
		this.titlName = employeeInfo.getTitlName();
		this.grdeName = employeeInfo.getGrdeName();
		this.deptCode = employeeInfo.getDeptCode();
		this.deptName = employeeInfo.getDeptName();
		this.lderEmpno = employeeInfo.getLderEmpno();
		this.ordrFlag = employeeInfo.getOrdrFlag();
		this.auth = employeeInfo.getAuth();
		this.empTel = employeeInfo.getEmpTel();
		this.biztTitl = employeeInfo.getBiztTitl();
		this.engName = employeeInfo.getEngName();
		this.actAuth = employeeInfo.getActAuth();
		this.cardAuth = employeeInfo.getCardAuth();
		this.partFlag = employeeInfo.getPartFlag();
		this.newWin = employeeInfo.getNewWin();
		this.quaAuth = employeeInfo.getQuaAuth();
		this.siteCd = employeeInfo.getSiteCd();
		this.funcArea = employeeInfo.getFuncArea();
		this.funcAreaName = employeeInfo.getFuncAreaName();
		this.lderEmpName = employeeInfo.getLderEmpName();
		this.lderDeptCode = employeeInfo.getLderDeptCode();
		this.lderDeptName = employeeInfo.getLderDeptName();
		this.lderTitlCode = employeeInfo.getLderTitlCode();
		this.lderTitlName = employeeInfo.getLderTitlName();
		this.dvsnCode = employeeInfo.getDvsnCode();
		this.mainDept = employeeInfo.getMainDept();
		this.mainName = employeeInfo.getMainName();
		this.userGrp = employeeInfo.getUserGrp();
		this.eipPasswd = employeeInfo.getEipPasswd();
		this.eipPasswd512 = employeeInfo.getEipPasswd512();
		this.cmpnCode = employeeInfo.getCmpnCode();
		this.cmpnNum = employeeInfo.getCmpnNum();

		this.roleCodes = roleCodes;
		this.roleButtonCodes = roleButtonCodes;
		this.menus = menus;
		this.langCd = langCd;
		this.userIp = userIp;
	}
}
