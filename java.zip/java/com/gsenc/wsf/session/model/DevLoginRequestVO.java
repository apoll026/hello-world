package com.gsenc.wsf.session.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class DevLoginRequestVO {

	@NotBlank
	@Schema(description = "메일ID", example = "developer")
	private String mailId;

	@NotBlank
	@Schema(description = "사업자번호", example = "developer")
	private String cmpnNum;

	@NotBlank
	@Schema(description = "인증번호", example = "developer")
	private String serialNumberHex;

	@Schema(description = "사용자PASSWORD")
	private String userPass;

	@NotBlank
	@Schema(description = "언어", example = "ko")
	private String langCd;

	@Schema(description = "인증번호")
	private String authCode;
}
