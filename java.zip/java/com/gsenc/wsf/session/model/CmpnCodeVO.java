package com.gsenc.wsf.session.model;

import lombok.*;
import lombok.extern.slf4j.Slf4j;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Slf4j
public class CmpnCodeVO {

	/** CFTX010 */
	/** 업체코드 */
	private String cmpnCode;
	/** 업체사업자번호 */
	private String cmpnNum;
	/** 사업장전화번호 */
	private String cmpnOffice;
	/** HP 번호 */
	private String cmpnMobile;
	/** Email 담당자 */
	private String cmpnEmail;
	/** 담당자 */
	private String cmpnManagerName;
	/** 등록일자 */
	private String regDate;
	/** 수정일자 */
	private String updDate;

	/** CFTX100 */
	/** 인증서 Seq No */
	private String certSeq;
	/** 제출일자 */
	private String smtYmd;
	/** 유효기간 시작일 */
	private String validFromYmd;
	/** 유효기간 만기일 */
	private String validEndYmd;
	/** 발행인증기관 */
	private String certAuth;
	/** 인증기관코드 */
	private String certAuthCd;
	/** 인증서 DN */
	private String certDn;
	/** 인증서 내용 */
	private String certInfo;
	/** 해쉬값 */
	private String certHash;
	/** 인증서 OID */
	private String certOID;
	/** 저장매체 */
	private String certMedia;
	/** 승인일자 */
	private String apprYmd;
	/** 승인상태(0:미승인 1:승인 2:승인취소) */
	private String apprStauts;
	/** 사용상태(Y:사용,N:사용안함) */
	private String useStatus;
	/** 인증서 SERIAL */
	private String certSerial;
	/** 등록ID */
	private String regId;
	/** 수정ID */
	private String updId;
	/** 사업자번호 */
	private String BSCD;

	private String mailId;

	private String empNo;

	/** CFTX300 */
	/** 사업자명 */
	private String cmpnName;
	/** 대표자명 */
	private String repsName;
	/** 사업장주소 */
	private String orgAddr;
	/**  */
	private String mngrName;
	/**  */
	private String mngrDept;
	/**  */
	private String cmpnOffic2;
	/**  */
	private String cmpnMobile2;
	/**  */
	private String cmpnEmail2;
	/**  */
	private String roleFlag;
	/**  */
	private String roleName;
	/**  */
	private String roleOffice;
	/**  */
	private String roleMobile;
	/** 승인상태 */
	private String applySttu;
	/** 암호화상태 */
	private String certSttu;
	/** 공급일자 */
	private String applyDate;
	/** 등록 사번 */
	private String updEmp;
	/** 부여권한 이메일 */
	private String roleEmail;
	/** 부여권한 주소 */
	private String roleAddr;
	/** 사용여부 */
	private String useYn;
}
