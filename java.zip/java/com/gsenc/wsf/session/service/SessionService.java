package com.gsenc.wsf.session.service;

import com.gsenc.wsf.session.model.UserCompanySessionVO;
import com.gsenc.wsf.session.model.UserSessionVO;

import jakarta.servlet.http.HttpServletRequest;

public interface SessionService {

	UserSessionVO createUserSession(String userId, String langCd, String userIp);

	UserCompanySessionVO createUserCompanySession(String cmpnNum, String langCd, String userIp);

	String authenticateWithResult(HttpServletRequest request);

	void updateUserSessionLangCd(String langCd);

	void updateUserSessionMenus();
}
