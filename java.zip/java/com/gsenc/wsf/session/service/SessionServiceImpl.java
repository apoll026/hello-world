package com.gsenc.wsf.session.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gsenc.wsf.common.component.SsoManager;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.SsoConstants;
import com.gsenc.wsf.common.exception.BusinessException;
import com.gsenc.wsf.common.model.SsoVO;
import com.gsenc.wsf.common.util.LocaleUtil;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.common.util.ValidateUtil;
import com.gsenc.wsf.company.service.CompanyService;
import com.gsenc.wsf.employee.service.EmployeeService;
import com.gsenc.wsf.log.repository.LoginLogRepository;
import com.gsenc.wsf.menu.model.MenuResponseVO;
import com.gsenc.wsf.role.service.RoleButtonService;
import com.gsenc.wsf.role.service.RoleDepartmentService;
import com.gsenc.wsf.role.service.RoleEmployeeService;
import com.gsenc.wsf.role.service.RoleMenuService;
import com.gsenc.wsf.session.model.*;
import com.gsenc.wsf.session.model.UserSessionVO;

import SafeIdentity.SSO;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
@Transactional
public class SessionServiceImpl implements SessionService {

	private final EmployeeService employeeService;
	private final CompanyService companyService;
	private final RoleEmployeeService roleEmployeeService;
	private final RoleDepartmentService roleDepartmentService;
	private final RoleMenuService roleMenuService;
	private final RoleButtonService roleButtonService;
	private final SsoManager ssoManager;
	private final LoginLogRepository loginLogRepository;

	@Override
	public UserSessionVO createUserSession(String userId, String langCd, String userIp) {

		EmployeeVO employeeInfo = employeeService.selectEmployeeByUserId(userId);
		if (ValidateUtil.isEmpty(employeeInfo)) {
			return null;
		}

		List<String> roleCodes = roleEmployeeService.findRoleCodesByUserId(userId);// 유저auth

		List<String> deptRoleCodes = roleDepartmentService.findRolesByDepartment(employeeInfo.getDeptCode());//,부서auth

		roleCodes.addAll(deptRoleCodes);

		String auth = roleMenuService.findAuthByMailId(userId);
		String empNo = employeeInfo.getEmpNo();
		List<MenuResponseVO> menus = roleMenuService.findMenusByEmpNo(empNo);

		UserSessionVO userSession = new UserSessionVO(employeeInfo, roleCodes, menus, langCd, userIp);

		SessionScopeUtil.setContextSession(userSession);

		return userSession;
	}

	@Override
	public UserCompanySessionVO createUserCompanySession(String cmpnNum, String langCd, String userIp) {

		// cmpnNum 또는 userIp 를 확인
		CmpnCodeVO companyInfo = companyService.selectCompanyByCmpnCode(cmpnNum);
		if (ValidateUtil.isEmpty(companyInfo)) {
			return null;
		}

		// roleCodes를 확인하여 값이 있으면 관리자 페이지 권한이 있고 아니면 현장 현금등록자임.
		List<String> roleCodes = roleEmployeeService.findRoleCodesByUserId(userIp);// 유저auth
		//if (roleCodes != null) {

		//List<String> deptRoleCodes = roleDepartmentService.findRolesByDepartment(companyInfo.getCmpnCode());//,부서auth
		//roleCodes.addAll(deptRoleCodes);
		//String auth = roleMenuService.findAuthByMailId(cmpnNum);

		String cmpnCode = companyInfo.getCmpnCode();
		List<MenuResponseVO> menus = roleMenuService.findMenusByEmpNo(cmpnCode);

		UserCompanySessionVO userSession = new UserCompanySessionVO(companyInfo, roleCodes, menus, langCd, userIp);

		SessionScopeUtil.setCompanyContextSession(userSession);

		return userSession;
	}

	@Override
	public String authenticateWithResult(HttpServletRequest request) {
		// 1. 기존 세션 확인 (폼 로그인 포함)
		if (hasValidSession(request)) {
			return SsoConstants.AUTH_SUCCESS;
		}

		// 2. SSO 인증 시도
		return authenticateWithSSOResult(request);
	}

	/**
	 * HTTP 세션에서 유효한 사용자 세션이 있는지 확인
	 * 폼 로그인의 경우 SSO 검증을 생략
	 */
	private boolean hasValidSession(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		if (session == null) {
			return false;
		}

		//UserSessionVO userSession = (UserSessionVO)session.getAttribute(CommonConstants.HTTP_SESSION_KEY);
		UserCompanySessionVO userSession = (UserCompanySessionVO)session.getAttribute(CommonConstants.HTTP_SESSION_KEY);
		if (userSession == null) {
			return false;
		}

		// 폼 로그인의 경우 SSO 검증 없이 세션만으로 인증 처리
		if (userSession.isFormLogin()) {
			SessionScopeUtil.setContextSession(userSession);
			return true;
		}

		// SSO 로그인 세션이 있는 경우 - SSO 토큰 재검증 필요
		return false;
	}

	/**
	 * SSO 토큰을 통한 인증 처리 (상세 결과 반환)
	 */
	private String authenticateWithSSOResult(HttpServletRequest request) {
		try {
			// SSO 토큰 추출 및 검증
			SsoVO ssoInfo = validateSsoToken(request);
			if (ssoInfo == null) {
				return SsoConstants.AUTH_SSO_FAILED;
			}

			// 기존 세션이 있는 경우 SSO 검증만 성공하면 인증 성공으로 처리
			HttpSession session = request.getSession(false);
			if (session != null) {
				UserSessionVO userSession = (UserSessionVO)session.getAttribute(CommonConstants.HTTP_SESSION_KEY);
				if (userSession != null) {
					SessionScopeUtil.setContextSession(userSession);
					return SsoConstants.AUTH_SUCCESS;
				}
			}

			// 사용자 권한 확인 및 세션 생성
			if (createAndSetUserSession(request, ssoInfo)) {
				return SsoConstants.AUTH_SUCCESS;
			} else {
				// SSO 인증은 성공했으나 사이트 권한이 없음
				return SsoConstants.AUTH_AUTHORIZATION_FAILED;
			}

		} catch (BusinessException e) {
			log.debug("SSO authentication failed: {}", e.getMessage());
			return SsoConstants.AUTH_SSO_FAILED;
		}
	}

	/**
	 * SSO 토큰 검증
	 */
	private SsoVO validateSsoToken(HttpServletRequest request) {
		String sToken = ssoManager.extractToken(request);
		if (sToken == null || sToken.isEmpty()) {
			log.error("SSO Token is empty");
			return null;
		}

		String sRemoteAddr = request.getRemoteAddr();
		SSO sso = ssoManager.verifySsoToken(sToken, sRemoteAddr);

		return SsoManager.buildSsoVO(sso);
	}

	/**
	 * 사용자 권한 확인 후 세션 생성 및 설정
	 */
	private boolean createAndSetUserSession(HttpServletRequest request, SsoVO ssoInfo) {
		String userId = ssoInfo.getUserId();
		String langCd = request.getLocale().getLanguage();
		String remoteAddr = request.getRemoteAddr();

		// 사용자 권한 확인 및 세션 생성
		UserSessionVO newUserSession = createUserSession(userId, langCd, remoteAddr);

		if (newUserSession == null) {
			log.info("User does not have permission: {}", userId);
			return false;
		}

		// HTTP 세션에 저장
		HttpSession session = request.getSession(true);
		session.setAttribute(CommonConstants.HTTP_SESSION_KEY, newUserSession);
		SessionScopeUtil.setContextSession(newUserSession);

		// 로그인 로그 기록
		loginLogRepository.insertLoginLog(newUserSession);

		return true;
	}

	@Override
	public void updateUserSessionLangCd(String langCd) {

		UserSessionVO userSessionContext = SessionScopeUtil.getContextSession();

		if (userSessionContext != null && LocaleUtil.hasLanguageCode(langCd)) {
			SessionScopeUtil.getContextSession().setLangCd(langCd);
		}
	}

	@Override
	public void updateUserSessionMenus() {

		UserSessionVO userSessionContext = SessionScopeUtil.getContextSession();

		String userId = userSessionContext.getMailId();
		String empNo = userSessionContext.getEmpNo();
		EmployeeVO employeeInfo = employeeService.selectEmployeeByUserId(userId);
		if (ValidateUtil.isEmpty(employeeInfo)) {
			return;
		}

		List<MenuResponseVO> menus = getMenuResponseVO(empNo);

		SessionScopeUtil.getContextSession().setMenus(menus);
	}

	/**
	 * empNo로 해당 유저 메뉴 반환
	 *
	 * @param empNo 로 유저Id
	 * @return {List<MenuResponseVO>} 메뉴 리스트 반환
	 */
	private List<MenuResponseVO> getMenuResponseVO(String empNo) {

		return roleMenuService.findMenusByEmpNo(empNo);
	}
}
