package com.gsenc.wsf.api.service;

import java.util.List;

import com.gsenc.wsf.api.model.ApiUrlConditionVO;
import com.gsenc.wsf.api.model.ApiUrlRequestVO;
import com.gsenc.wsf.api.model.ApiUrlResponseVO;
import com.gsenc.wsf.common.model.DmlResponseVO;

public interface ApiUrlService {

    //Management
    List<ApiUrlResponseVO> findApiUrls(ApiUrlConditionVO apiCondition);

    DmlResponseVO saveApiUrls(List<ApiUrlRequestVO> apis);

    boolean createApiRoles(String apiId, List<String> roleCodes);

    boolean modifyApiRoles(String apiId, List<String> roleCodes);

    //Service
    boolean checkAccessibleApiUrlsByRoleCodes(String apiUrl, String httpMthdCd, List<String> roleCodes);

}
