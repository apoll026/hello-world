package com.gsenc.wsf.verification.repository;

import org.apache.ibatis.annotations.Mapper;

import com.gsenc.wsf.verification.model.TalkVO;
import com.gsenc.wsf.verification.model.UserVO;

@Mapper
public interface VerificationRepository {
	void sendCertNumberTalk(TalkVO verificationVO);

	UserVO selectReceiverInfo(UserVO userVO);
}
