package com.gsenc.wsf.verification.service;

import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.util.CertUtil;
import com.gsenc.wsf.common.util.NetworkUtil;
import com.gsenc.wsf.mail.model.MailRequestVO;
import com.gsenc.wsf.mail.model.MailVO;
import com.gsenc.wsf.mail.service.MailService;
import com.gsenc.wsf.session.model.DevLoginRequestVO;
import com.gsenc.wsf.verification.model.TalkVO;
import com.gsenc.wsf.verification.model.UserVO;
import com.gsenc.wsf.verification.repository.VerificationRepository;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class VerificationServiceImpl implements VerificationService {

	private final VerificationRepository verificationRepository;
	private final MailService mailService;

	@Value("${spring.profiles.active}")
	private String activeProfile;

	@Value("${talk.sender}")
	private String sender;

	@Value("${talk.systemCode}")
	private String systemCode;

	@Override
	public boolean sendCertNumber(HttpServletRequest request) {
		SecureRandom random = new SecureRandom();
		String secureNumber = String.valueOf(random.nextInt(900000) + 100000);

		HttpSession session = request.getSession();
		session.setAttribute(CommonConstants.CERT_NUMBER, CertUtil.createCertInfo(secureNumber));

		UserVO userVO = verificationRepository.selectReceiverInfo(
			UserVO.builder().ipAddress(NetworkUtil.getClientIpNew(request)).build());

		if (userVO == null) {
			return false;
		}

		// 운영 환경은 알림톡
		if ("prd".equals(activeProfile)) {
			if (sendCertNumberTalk(userVO.getMobileNum(), secureNumber)) {
				return true;
			}
			// 운영 환경에서도 알림톡 실패시 메일 발송
		}

		return sendCertNumberMail(userVO.getEmail(), secureNumber);

	}

	@Override
	public boolean checkCertNumber(DevLoginRequestVO devLoginRequest, HttpServletRequest request) {

		HttpSession session = request.getSession();
		boolean isValid = CertUtil.isValidCert((Map<String, Object>)session.getAttribute(CommonConstants.CERT_NUMBER),
			devLoginRequest.getAuthCode());

		if (isValid) {
			session.removeAttribute(CommonConstants.CERT_NUMBER);
		}

		return isValid;
	}

	@Override
	public UserVO checkAdminIp(HttpServletRequest request) {

		try {
			return verificationRepository.selectReceiverInfo(
				UserVO.builder().ipAddress(NetworkUtil.getClientIpNew(request)).build());
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return null;

	}

	@Override
	public boolean sendCertNumberTalk(String receiver, String secureNumber) {
		try {

			TalkVO talkVO = TalkVO.builder()
				.receiver(receiver)
				.sender(sender)
				.systemCode(systemCode)
				.certNumber(secureNumber)
				.build();

			verificationRepository.sendCertNumberTalk(talkVO);

			return true;

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return false;
	}

	@Override
	public boolean sendCertNumberMail(String receiver, String secureNumber) {

		Map<String, Object> templateData = new HashMap<>();
		templateData.put("secureNumber", secureNumber);

		MailRequestVO mailRequestVO = MailRequestVO.builder()
			.toAddress(receiver)
			.subject("[GS건설] GS E&C 인증코드 안내메일")
			.content(mailService.makeTemplate("verification-template", templateData))
			.build();

		MailVO mailVO = mailService.parseMailRequest(mailRequestVO);

		int result = mailService.sendMailImmediately(mailVO);

		if (result == -1) {
			return false;
		}

		return true;
	}

}
