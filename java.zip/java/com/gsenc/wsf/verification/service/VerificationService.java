package com.gsenc.wsf.verification.service;

import com.gsenc.wsf.session.model.DevLoginRequestVO;
import com.gsenc.wsf.verification.model.UserVO;

import jakarta.servlet.http.HttpServletRequest;

public interface VerificationService {

	boolean sendCertNumber(HttpServletRequest reques);

	boolean sendCertNumberTalk(String receiver, String secureNumber);

	boolean sendCertNumberMail(String receiver, String secureNumber);

	boolean checkCertNumber(DevLoginRequestVO devLoginRequest, HttpServletRequest request);

	UserVO checkAdminIp(HttpServletRequest request);
}
