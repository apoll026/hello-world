package com.gsenc.wsf.verification.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TalkVO {

	@Schema(description = "수신자 번호", example = "수신자 번호")
	private String receiver;

	@Schema(description = "발신자 번호", example = "발신자 번호")
	private String sender;

	@Schema(description = "시스템 코드", example = "시스템 코드")
	private String systemCode;

	@Schema(description = "인증 번호", example = "인증 번호")
	private String certNumber;

}
