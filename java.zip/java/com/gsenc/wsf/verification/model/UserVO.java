package com.gsenc.wsf.verification.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserVO {

	@Schema(description = "이메일 주소", example = "user@example.com")
	private String email;

	@Schema(description = "휴대폰 번호", example = "010-1234-5678")
	private String mobileNum;

	@Schema(description = "IP", example = "0.0.0.0")
	private String ipAddress;
}
