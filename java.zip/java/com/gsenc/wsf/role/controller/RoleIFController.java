package com.gsenc.wsf.role.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.wsf.common.model.DataWrapperVO;
import com.gsenc.wsf.common.util.RestResponseFactoryUtil;
import com.gsenc.wsf.role.model.SsoAuthRestRequestVO;
import com.gsenc.wsf.role.service.RoleIFService;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequiredArgsConstructor
@Tag(name = "RoleIf")
@Validated
@Slf4j
@RequestMapping("/api")
public class RoleIFController {

	private final RoleIFService roleIFService;

	@PostMapping(value = "/v1/sso-auth", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DataWrapperVO> ssoAuth(@RequestBody DataWrapperVO<SsoAuthRestRequestVO> sso,
		HttpServletRequest request) {

		return new ResponseEntity<>(
			RestResponseFactoryUtil.createReturnDataVO(roleIFService.migrateAuth(sso.getData().getRecord(), request)),
			HttpStatus.OK);
	}
}
