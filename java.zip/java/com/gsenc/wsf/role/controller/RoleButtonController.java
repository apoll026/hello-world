package com.gsenc.wsf.role.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;
import com.gsenc.wsf.common.model.ValidList;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.role.model.RoleButtonRequestVO;
import com.gsenc.wsf.role.service.RoleButtonService;
import com.gsenc.wsf.session.model.UserSessionVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequiredArgsConstructor
@Tag(name = "RoleButton")
@Validated
@Slf4j
@RequestMapping("/api")
public class RoleButtonController {

	private final RoleButtonService roleButtonService;

	@Operation(summary = "버튼 역할코드 조회", description = "버튼 역할코드 조회")
	@GetMapping(value = "/v1/role/button", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO> findRoleButtonCodes(
		@Parameter(description = "searchBtnGrCd", example = "샘플화면") @RequestParam(required = false) String searchBtnGrCd,
		@Parameter(description = "useYn", example = "Y") @RequestParam(required = false) String searchUseYn,
		@Parameter(description = "searchBtnCd", example = "reg001") @RequestParam(required = false) String searchBtnCd) {
		return new ResponseEntity<>(
			CommonResponseVO.builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(roleButtonService.findRoleButtonCodes(searchBtnGrCd, searchUseYn, searchBtnCd))
				.build(),
			HttpStatus.OK);
	}

	@Operation(summary = "버튼 역할코드 저장", description = "header값에 따라 insert/update. C: Insert, U: Update")
	@PostMapping(value = "/v1/role/button", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<UserSessionVO>> saveRoleButtonCodes(
		@RequestBody @Valid ValidList<RoleButtonRequestVO> roleButtonCodes) {
		roleButtonService.saveRoleButtonCodes(roleButtonCodes);
		UserSessionVO userSession = SessionScopeUtil.getContextSession();
		return new ResponseEntity<>(
			CommonResponseVO.<UserSessionVO>builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(userSession)
				.build(),
			HttpStatus.OK);
	}

	@Operation(summary = "버튼 역할코드 중복조회")
	@PostMapping(value = "/v1/role/button/duplicate", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO> isDuplicatedButtonRoles(
		@RequestBody @Valid ValidList<RoleButtonRequestVO> roleButtonRequestVOList) {
		return new ResponseEntity<>(
			CommonResponseVO.<Boolean>builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(roleButtonService.isDuplicatedRoleButtons(roleButtonRequestVOList))
				.build(),
			HttpStatus.OK);
	}

}
