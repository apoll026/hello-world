package com.gsenc.wsf.role.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;
import com.gsenc.wsf.common.model.DmlResponseVO;
import com.gsenc.wsf.common.model.ValidList;
import com.gsenc.wsf.role.model.RoleRequestVO;
import com.gsenc.wsf.role.model.RoleResponseVO;
import com.gsenc.wsf.role.service.RoleService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequiredArgsConstructor
@Tag(name = "Role")
@Validated
@Slf4j
@RequestMapping("/api")
public class RoleController {
	private final RoleService roleService;

	@Operation(summary = "역할 조회")
	@GetMapping(value = "/v1/roles", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<List<RoleResponseVO>>> findRoles(
		@Parameter(description = "역할명") @RequestParam(required = false) String roleNm) {
		return new ResponseEntity<>(CommonResponseVO.<List<RoleResponseVO>>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(roleService.findRoles(roleNm))
			.build(), HttpStatus.OK);
	}

	@Operation(summary = "역할 추가/수정")
	@PostMapping(value = "/v1/roles", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<DmlResponseVO>> saveRoles(
		@RequestBody @Valid ValidList<RoleRequestVO> roles) {
		return new ResponseEntity<>(CommonResponseVO.<DmlResponseVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(roleService.saveRoles(roles))
			.build(), HttpStatus.OK);
	}

	@Operation(summary = "역할 삭제")
	@DeleteMapping(value = "/v1/roles", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<DmlResponseVO>> removeRoles(
		@Parameter(description = "역할코드 목록") @RequestBody List<@NotBlank String> roleCds) {
		return new ResponseEntity<>(CommonResponseVO.<DmlResponseVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(DmlResponseVO.builder()
				.deletedRows(roleService.removeRoles(roleCds))
				.build())
			.build(), HttpStatus.OK);
	}

}
