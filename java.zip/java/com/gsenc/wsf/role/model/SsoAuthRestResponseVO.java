package com.gsenc.wsf.role.model;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
public class SsoAuthRestResponseVO implements Serializable {

    @Schema(description = "ERP, WEB, MES 구분", example = "WEB")
    private String syscd;

    @Schema(description = "사번", example = "12345")
    private String user_id;

    @Schema(description = "시스템코드", example = "WSF")
    private String auth_lev_1;

    @Schema(description = "", example = "")
    private String auth_lev_2;

    @Schema(description = "업무/제품군", example = "ADM")
    private String auth_lev_3;

    @Schema(description = "", example = "")
    private String auth_lev_4;

    @Schema(description = "", example = "")
    private String auth_lev_5;

    @Schema(description = "C:추가, D:삭제", example = "C")
    private String attribute1;

    @Schema(description = "승인자사번", example = "12345")
    private String attribute2;

    @Schema(description = "권한구분자(메뉴권한)", example = "")
    private String attribute3;

    @Schema(description = "여유컬럼", example = "")
    private String attribute4;

    @Schema(description = "여유컬럼", example = "")
    private String attribute5;

    @Schema(description = "만든날짜", example = "20241129112007")
    private String creation_date;

    @Schema(description = "결과코드", example = "S")
    private String o_ret_code;

    @Schema(description = "결과메시지", example = "")
    private String o_ret_msg;

    @Schema(description = "", example = "")
    private String eai_transfer_flag5;

    @Schema(description = "", example = "")
    private String eai_transfer_date5;

}
