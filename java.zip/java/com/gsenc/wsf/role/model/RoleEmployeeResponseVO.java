package com.gsenc.wsf.role.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class RoleEmployeeResponseVO {

	@Schema(description = "메일ID")
	private String mailId;

	@Schema(description = "사원번호")
	private String empNo;

	@Schema(description = "사원명")
	private String empName;

	@Schema(description = "부서코드")
	private String deptCode;

	@Schema(description = "부서명")
	private String deptName;

	@Schema(description = "직위코드")
	private String titlCode;

	@Schema(description = "직위명")
	private String titlName;

	@Schema(description = "회사전화번호")
	private String officeNumber;

}
