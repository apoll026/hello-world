package com.gsenc.wsf.role.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class SsoAuthRestRequestVO implements Serializable {

    @Schema(description = "ERP, WEB, MES 구분", example = "WEB")
    private String syscd;

    @Schema(description = "사번", example = "12345")
    private String userId;

    @Schema(description = "시스템코드", example = "")
    @JsonProperty("auth_lev_1")
    private String authLev1;

    @Schema(description = "", example = "")
    @JsonProperty("auth_lev_2")
    private String authLev2;

    @Schema(description = "업무/제품군", example = "")
    @JsonProperty("auth_lev_3")
    private String authLev3;

    @Schema(description = "", example = "")
    @JsonProperty("auth_lev_4")
    private String authLev4;

    @Schema(description = "", example = "")
    @JsonProperty("auth_lev_5")
    private String authLev5;

    @Schema(description = "C:추가, D:삭제", example = "")
    private String attribute1;

    @Schema(description = "승인자사번", example = "")
    private String attribute2;

    @Schema(description = "권한구분자(메뉴권한)", example = "")
    private String attribute3;

    @Schema(description = "여유컬럼", example = "")
    private String attribute4;

    @Schema(description = "여유컬럼", example = "")
    private String attribute5;

    @Schema(description = "만든날짜", example = "")
    private String creationDate;

    @Schema(description = "", example = "")
    private String eaiTransferDate5;

    @Schema(description = "", example = "")
    private String eaiTransferFlag5;

}
