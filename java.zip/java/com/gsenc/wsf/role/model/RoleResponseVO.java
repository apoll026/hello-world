package com.gsenc.wsf.role.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class RoleResponseVO {

    @Schema(description = "역할코드", name = "역할코드")
    private String roleCd;

    @Schema(description = "역할명", name = "역할명")
    private String roleNm;

    @Schema(description = "역할설명", name = "역할설명")
    private String roleDesc;

    @Schema(description = "사용여부", name = "사용여부")
    private String useYn;

    @Schema(description = "연계여부", name = "연계여부")
    private String itgrYn;
}
