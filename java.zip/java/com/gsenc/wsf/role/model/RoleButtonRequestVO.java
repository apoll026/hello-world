package com.gsenc.wsf.role.model;

import com.gsenc.wsf.common.model.CrudVO;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Getter
@Setter
@SuperBuilder
public class RoleButtonRequestVO extends CrudVO {

	@Schema(description = "버튼그룹코드", example = "샘플화면")
	private String btnGrCd;

	@Schema(description = "버튼코드", example = "reg001")
	private String btnCd;

	@Schema(description = "역할코드", example = "ADM")
	private String roleCd;

	@NotBlank
	@Pattern(regexp = "^[YN]$")
	@Schema(description = "사용여부", example = "Y")
	private String useYn;

	@Schema(description = "버튼설명", example = "샘플화면 첫번째 등록버튼")
	private String btnDesc;

	@Schema(description = "옵션값내용1", example = "")
	private String optValCtn1;

	@Schema(description = "옵션값내용2", example = "")
	private String optValCtn2;

	@Schema(description = "옵션값내용3", example = "")
	private String optValCtn3;

	@Schema(description = "옵션값내용4", example = "")
	private String optValCtn4;

	@Schema(description = "옵션값내용5", example = "")
	private String optValCtn5;

	@Schema(description = "옵션값내용6", example = "")
	private String optValCtn6;

	@Schema(description = "옵션값내용7", example = "")
	private String optValCtn7;

	@Schema(description = "옵션값내용8", example = "")
	private String optValCtn8;

	@Schema(description = "옵션값내용9", example = "")
	private String optValCtn9;

	@Schema(description = "옵션값내용10", example = "")
	private String optValCtn10;

}
