package com.gsenc.wsf.role.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.department.model.DepartmentVO;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface RoleDepartmentRepository {
	List<String> selectRolesByDeptCd(String deptCd);

	List<DepartmentVO> selectDepartmentsByRoleCd(@Param("roleCd") String roleCd,
		@Param("session") UserSessionVO session);

	int insertRoleDepartment(@Param("roleCd") String roleCd, @Param("deptCd") String deptCd,
		@Param("session") UserSessionVO session);

	int deleteRoleDepartment(@Param("roleCd") String roleCd, @Param("deptCdList") List<String> deptCdList);
}
