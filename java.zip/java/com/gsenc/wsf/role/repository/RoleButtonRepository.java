package com.gsenc.wsf.role.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.common.model.ValidList;
import com.gsenc.wsf.role.model.RoleButtonRequestVO;
import com.gsenc.wsf.role.model.RoleButtonResponseVO;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface RoleButtonRepository {

	List<RoleButtonResponseVO> selectRoleButtonList(@Param("searchBtnGrCd") String btnGrCd,
		@Param("useYn") String useYn,
		@Param("searchBtnCd") String btnCd);

	List<RoleButtonResponseVO> selectRoleButtonListByRoleCds(@Param("roleCds") List<String> roleCds);

	int selectDuplicatedCount(@Param("arrBtnGrCd") String[] arrBtnGrCd, @Param("arrBtnCd") String[] arrBtnCd,
		@Param("arrRoleCd") String[] arrRoleCd);

	int mergeRoleButtonCodes(@Param("roleBtnReqList") ValidList<RoleButtonRequestVO> roleButtonCodes,
		@Param("session") UserSessionVO userSession);

	int deleteRoleButtonCodes(@Param("roleBtnReqList") List<RoleButtonRequestVO> deleteCodes);
}
