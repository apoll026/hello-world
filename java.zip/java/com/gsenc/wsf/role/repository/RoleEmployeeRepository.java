package com.gsenc.wsf.role.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.role.model.RoleResponseVO;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface RoleEmployeeRepository {

	List<RoleResponseVO> selectRoleEmployees(@Param("roleCd") String roleCd,
		@Param("session") UserSessionVO userSession);

	boolean existRoleEmployees(String roleCd);

	int insertRoleEmployee(@Param("roleCd") String roleCd, @Param("userId") String userId,
		@Param("session") UserSessionVO userSession);

	int deleteRoleEmployees(@Param("roleCd") String roleCd, @Param("userIdList") List<String> userIdList);

	List<String> selectRoleCdsByUserId(@Param("userId") String userId);

	List<String> selectRoleCdsByUserIdOther(@Param("userId") String userId, @Param("userPass") String userPass);

}
