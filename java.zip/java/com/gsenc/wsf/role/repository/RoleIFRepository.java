package com.gsenc.wsf.role.repository;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.role.model.SsoAuthRestRequestVO;

@Mapper
public interface RoleIFRepository {
    int mergeRoleEmp(@Param("ssoAuth") SsoAuthRestRequestVO ssoAuthRestRequestVO);

    void updateSsoAuthI(@Param("ssoAuth") SsoAuthRestRequestVO ssoAuthRestRequestVO);

    void insertSsoAuthI(@Param("ssoAuth") SsoAuthRestRequestVO ssoAuthRestRequestVO);

    void deleteRoleEmp(@Param("roleCd") String roleCd, @Param("userId") String userId);
}
