package com.gsenc.wsf.role.repository;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.menu.model.MenuResponseVO;
import com.gsenc.wsf.session.model.UserCompanySessionVO;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface RoleMenuRepository {

	List<MenuResponseVO> selectMenusByRoleCd(@Param("roleCd") String roleCd);

	int deleteRoleMenuByRoleCd(@Param("roleCd") String roleCd);

	int insertRoleMenusByRoleCd(@Param("roleCd") String roleCd, @Param("mnuIdList") List<String> mnuIdList,
		@Param("session") UserSessionVO session);
	int insertMenuByAuth(@Param("auth") String auth, @Param("pgmId") String pgmId,
						 @Param("session") UserCompanySessionVO session);
	void selectMenusByEmpNo(@Param("params") Map<String, Object> params);
	String selectAuthByMailId(@Param("mailId") String mailId);

	int upsertMenuAuth(@Param("auth") String auth,@Param("pgmAuth") String pgmAuth,@Param("pgmId") String pgmId, @Param("session") UserSessionVO userSession);

	int deleteMenuAuth(@Param("auth") String auth, @Param("pgmId") String pgmId, @Param("session") UserSessionVO userSession);
}
