package com.gsenc.wsf.role.service;

import com.gsenc.wsf.role.model.SsoAuthRestRequestVO;
import com.gsenc.wsf.role.model.SsoAuthRestResponseVO;

import jakarta.servlet.http.HttpServletRequest;

public interface RoleIFService {

	SsoAuthRestResponseVO migrateAuth(SsoAuthRestRequestVO ssoAuthRestRequestVO, HttpServletRequest request);
}
