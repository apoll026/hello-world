package com.gsenc.wsf.role.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.menu.model.MenuResponseVO;
import com.gsenc.wsf.role.repository.RoleMenuRepository;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class RoleMenuServiceImpl implements RoleMenuService {

	private final RoleMenuRepository roleMenuRepository;

	@Override
	@Transactional(readOnly = true)
	public List<MenuResponseVO> findMenusByRole(String roleCd) {
		return roleMenuRepository.selectMenusByRoleCd(roleCd);
	}

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public int saveMenusByRole(String roleCd, List<String> mnuIdList) {
		UserSessionVO session = SessionScopeUtil.getContextSession();
		roleMenuRepository.deleteRoleMenuByRoleCd(roleCd);
		return roleMenuRepository.insertRoleMenusByRoleCd(roleCd, mnuIdList, session);
	}

	@Override
	@Transactional(readOnly = true)
	public List<MenuResponseVO> findMenusByEmpNo(String empNo) {
		try {
			Map<String, Object> params = new HashMap<>();
			params.put("i_emp_no", empNo);
			params.put("o_rc", null);  // OUT 파라미터 반드시 포함

			roleMenuRepository.selectMenusByEmpNo(params);
			List<MenuResponseVO> result = (List<MenuResponseVO>) params.get("o_rc");

			return result != null ? result : new ArrayList<>();

		} catch (Exception e) {
			System.err.println("Error calling PROC_GET_MUNU_AUTH: " + e.getMessage());
			e.printStackTrace();
			return new ArrayList<>();
		}
	}

	@Override
	@Transactional(readOnly = true)
	public String findAuthByMailId(String mailId) {
		return roleMenuRepository.selectAuthByMailId(mailId);
	}
}
