package com.gsenc.wsf.role.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gsenc.wsf.common.model.ValidList;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.role.model.RoleButtonRequestVO;
import com.gsenc.wsf.role.model.RoleButtonResponseVO;
import com.gsenc.wsf.role.repository.RoleButtonRepository;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class RoleButtonServiceImpl implements RoleButtonService {

	private final RoleButtonRepository roleButtonRepository;

	@Override
	public boolean isDuplicatedRoleButtons(List<RoleButtonRequestVO> roleButtonRequestVOList) {

		roleButtonRequestVOList = roleButtonRequestVOList.stream()
			.filter(o -> "C".equals(o.getCrudKey()))
			.collect(Collectors.toList());

		boolean result = false;

		if (roleButtonRequestVOList.size() > 0) {

			String[] btnGrpList = roleButtonRequestVOList.stream()
				.map(RoleButtonRequestVO::getBtnGrCd)
				.toArray(String[]::new);
			String[] btnCdList = roleButtonRequestVOList.stream()
				.map(RoleButtonRequestVO::getBtnCd)
				.toArray(String[]::new);
			String[] roleCdList = roleButtonRequestVOList.stream()
				.map(RoleButtonRequestVO::getRoleCd)
				.toArray(String[]::new);

			result = 0 < roleButtonRepository.selectDuplicatedCount(btnGrpList, btnCdList, roleCdList);
		}

		return result;
	}

	@Override
	public List<RoleButtonResponseVO> findRoleButtonCodes(String btnGrCd, String useYn, String btnCd) {
		return roleButtonRepository.selectRoleButtonList(btnGrCd, useYn, btnCd);
	}

	@Override
	public List<RoleButtonResponseVO> findRoleButtonCodesByRoleCds(List<String> roleCodes) {
		return roleButtonRepository.selectRoleButtonListByRoleCds(roleCodes);
	}

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public void saveRoleButtonCodes(ValidList<RoleButtonRequestVO> roleButtonCodes) {
		UserSessionVO userSession = SessionScopeUtil.getContextSession();
		for (int i = 0; i < roleButtonCodes.size(); i++) {
			roleButtonRepository.mergeRoleButtonCodes((ValidList<RoleButtonRequestVO>)roleButtonCodes.subList(i, i + 1),
				userSession);
		}
		List<RoleButtonResponseVO> responseVOS = findRoleButtonCodesByRoleCds(userSession.getRoleCodes());
		SessionScopeUtil.getContextSession().setRoleButtonCodes(responseVOS);
	}
}
