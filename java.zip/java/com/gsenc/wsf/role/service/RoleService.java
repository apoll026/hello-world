package com.gsenc.wsf.role.service;

import java.util.List;

import com.gsenc.wsf.common.model.DmlResponseVO;
import com.gsenc.wsf.role.model.RoleRequestVO;
import com.gsenc.wsf.role.model.RoleResponseVO;

public interface RoleService {

    List<RoleResponseVO> findRoles(String roleNm);

    DmlResponseVO saveRoles(List<RoleRequestVO> roles);

    int removeRoles(List<String> roleCodes);

}
