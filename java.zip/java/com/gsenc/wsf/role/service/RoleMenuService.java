package com.gsenc.wsf.role.service;

import java.util.List;

import com.gsenc.wsf.menu.model.MenuResponseVO;

public interface RoleMenuService {

    List<MenuResponseVO> findMenusByRole(String roleCd);

    int saveMenusByRole(String roleCd, List<String> mnuIdList);


    //List<MenuResponseVO> findMenusByRoleCodes(List<String> roleCodes);
    List<MenuResponseVO> findMenusByEmpNo(String mailId);

    //List<MenuResponseVO> findMenusByAuth(String auth);

    String findAuthByMailId(String mailId);
}
