package com.gsenc.wsf.role.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.common.util.ValidateUtil;
import com.gsenc.wsf.role.model.RoleResponseVO;
import com.gsenc.wsf.role.repository.RoleEmployeeRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class RoleEmployeeServiceImpl implements RoleEmployeeService {

    private final RoleEmployeeRepository roleEmployeeRepository;

    @Override
    @Transactional(readOnly = true)
    public List<RoleResponseVO> findRoleEmployees(String roleCd) {
        return roleEmployeeRepository.selectRoleEmployees(roleCd, SessionScopeUtil.getContextSession());
    }

    @Override
    @Transactional(rollbackFor = { Exception.class })
    public int createRoleEmployees(String roleCd, List<String> userIdList) {

        int result = 0;
        if(!ValidateUtil.isEmpty(userIdList)){
            for(String userId : userIdList){
                result += roleEmployeeRepository.insertRoleEmployee(roleCd, userId, SessionScopeUtil.getContextSession());
            }
        }
        return result;
    }

    @Override
    @Transactional(rollbackFor = { Exception.class })
    public int removeRoleEmployees(String roleCd, List<String> userIdList) {
        return roleEmployeeRepository.deleteRoleEmployees(roleCd, userIdList);
    }

    @Override
    @Transactional(readOnly = true)
    public List<String> findRoleCodesByUserId(String userId){
        return roleEmployeeRepository.selectRoleCdsByUserId(userId);
    }

}
