package com.gsenc.wsf.role.service;

import java.util.List;

import com.gsenc.wsf.common.model.ValidList;
import com.gsenc.wsf.role.model.RoleButtonRequestVO;
import com.gsenc.wsf.role.model.RoleButtonResponseVO;

import jakarta.validation.Valid;

public interface RoleButtonService {

	boolean isDuplicatedRoleButtons(List<RoleButtonRequestVO> roleButtonRequestVOList);

	List<RoleButtonResponseVO> findRoleButtonCodes(String btnGrCd, String useYn, String btnCd);

	List<RoleButtonResponseVO> findRoleButtonCodesByRoleCds(List<String> roleCodes);

	void saveRoleButtonCodes(@Valid ValidList<RoleButtonRequestVO> roleButtonCodes);

}
