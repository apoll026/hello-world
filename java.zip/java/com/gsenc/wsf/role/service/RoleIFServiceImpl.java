package com.gsenc.wsf.role.service;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.gsenc.wsf.common.util.NetworkUtil;
import com.gsenc.wsf.common.util.StringUtil;
import com.gsenc.wsf.log.model.IfLogVO;
import com.gsenc.wsf.log.service.LogService;
import com.gsenc.wsf.role.model.RoleRequestVO;
import com.gsenc.wsf.role.model.RoleResponseVO;
import com.gsenc.wsf.role.model.SsoAuthRestRequestVO;
import com.gsenc.wsf.role.model.SsoAuthRestResponseVO;
import com.gsenc.wsf.role.repository.RoleIFRepository;
import com.gsenc.wsf.role.repository.RoleRepository;
import com.gsenc.wsf.session.model.UserSessionVO;

import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class RoleIFServiceImpl implements RoleIFService {

	private final ApplicationContext applicationContext;

	private final LogService logService;
	private final RoleIFRepository roleIFRepository;
	private final RoleRepository roleRepository;

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public SsoAuthRestResponseVO migrateAuth(SsoAuthRestRequestVO ssoAuthRestRequestVO, HttpServletRequest request) {

		SsoAuthRestResponseVO resultVO = SsoAuthRestResponseVO.builder()
			.eai_transfer_flag5(ssoAuthRestRequestVO.getEaiTransferFlag5())
			.eai_transfer_date5(ssoAuthRestRequestVO.getEaiTransferDate5())
			.syscd(ssoAuthRestRequestVO.getSyscd())
			.user_id(ssoAuthRestRequestVO.getUserId())
			.creation_date(ssoAuthRestRequestVO.getCreationDate())
			.auth_lev_1(ssoAuthRestRequestVO.getAuthLev1())
			.auth_lev_2(ssoAuthRestRequestVO.getAuthLev2())
			.auth_lev_3(ssoAuthRestRequestVO.getAuthLev3())
			.auth_lev_4(ssoAuthRestRequestVO.getAuthLev4())
			.auth_lev_5(ssoAuthRestRequestVO.getAuthLev5())
			.o_ret_code("S")
			.o_ret_msg("SUCCESS")
			.build();

		IfLogVO ifLog = IfLogVO.builder()
			.ifNm("ROLE-IF")
			.ifDivsCd("BATCH")
			.ifTrmtValCtn("")
			.ifRestValCtn(ssoAuthRestRequestVO.toString())
			.dataInsUserId("Batch")
			.dataInsUserIp(NetworkUtil.getClientIP(request))
			.build();

		RoleIFServiceImpl proxy = applicationContext.getBean(RoleIFServiceImpl.class);

		try {
			proxy.createSsoAuthI(ssoAuthRestRequestVO);

			// attribute1 : "C" == "신규", "D" == "삭제"
			boolean isCreate = StringUtil.isEmpty(ssoAuthRestRequestVO.getAttribute1()) || "C".equals(
				ssoAuthRestRequestVO.getAttribute1());

			// role_m 테이블에 등록되어 있는 역할코드 조회
			List<RoleResponseVO> currRoles = roleRepository.selectRoles(null);

			if (!currRoles.isEmpty()) {
				List<String> roleCdList = currRoles.stream()
					.map(RoleResponseVO::getRoleCd)
					.collect(Collectors.toList());
				String roleCd = ssoAuthRestRequestVO.getAuthLev3();
				boolean isExist = roleCdList.contains(roleCd);

				if (isCreate) {
					// 역할코드가 기존 테이블에 존재하지 않으면 역할테이블에 임시로 값을 저장해줌
					if (!isExist) {
						RoleRequestVO insVO = RoleRequestVO.builder()
							.roleCd(roleCd)
							.roleNm("TEMP-ROLE")
							.roleDesc("TEMP-ROLE")
							.useYn("Y")
							.itgrYn("Y")
							.build();
						UserSessionVO sessionVO = UserSessionVO.builder()
							.userIp("0.0.0.0")
							.mailId("FW-DEFAULT")
							.build();
						roleRepository.insertRoles(Collections.singletonList(insVO), sessionVO);
					}
					// 역할코드가 존재하는 경우에만 머지, 역할코드가 존재하지 않는 삭제 데이터는 처리하지 않음.
					int res = roleIFRepository.mergeRoleEmp(ssoAuthRestRequestVO);

					if (res < 1) {
						throw new Exception();
					}

				} else { // 삭제
					roleIFRepository.deleteRoleEmp(roleCd, ssoAuthRestRequestVO.getUserId());
				}

				this.updateRoleIntegration(roleCd);
			}

			roleIFRepository.updateSsoAuthI(ssoAuthRestRequestVO);

		} catch (Exception e) {
			resultVO.setO_ret_code("E");
			resultVO.setO_ret_msg("EXCEPTION");
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			log.error(e.getMessage(), e);
		} finally {
			ifLog.setOptValNm1(resultVO.getO_ret_code());
			ifLog.setOptValNm2(resultVO.getO_ret_msg());
			logService.createIfLog(ifLog);
			return resultVO;
		}

	}

	private void updateRoleIntegration(String roleCd) {
		roleRepository.updateItgrRole(roleCd);
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void createSsoAuthI(SsoAuthRestRequestVO ssoAuthRestRequestVO) {
		roleIFRepository.insertSsoAuthI(ssoAuthRestRequestVO);
	}
}
