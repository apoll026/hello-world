package com.gsenc.wsf.common.snmip;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;
import com.gsenc.wsf.common.util.HttpConnectionUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequiredArgsConstructor
@Tag(name = "SNMIP")
@Validated
@Slf4j
@RequestMapping("/api")
public class SNMIPSample {

	private static final String AIP_URL = "https://aip2.gsenc.com/api/AIPP";
	private static final String SYSTEM_ID = "44D8410B-9B1F-4E2E-B269-269AE2D50FD7";
	private static final String NFS_PATH = "\\\\165.243.39.242\\v110\\AIP\\EAS";    // API 서버가 Windows에서 동작하기 때문에 Windows용 주소 필요

	@Value("${aip.upload-path}")
	private String nfsDir;    // WAS(Linux) 파일 업로드 경로

	private static String staticNfsDir;

	@Value("${aip.upload-path}")
	public void setStaticNfsDir(String nfsDir) {
		SNMIPSample.staticNfsDir = nfsDir;
	}

	@Operation(summary = "snmipTest")
	@GetMapping(value = "/v1/snmipTest", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO> snmipTest() {
		try {
			String path = "/temp";
			String fileName = "test.pptx";
			String contentValidUntil = "2025-06-16";
			List<GetFileStatusVO.CustomUserRight> customUserRights = List.of(
				GetFileStatusVO.CustomUserRight.builder()
					.Rights(List.of("VIEW", "EDIT"))
					.Users(List.of("donghyun.bang@gsenc.com")).build()
			);

			// 사용 가능한 민감도 Label 조회
			List<GetSensitivityLabelListVO> labels = Sample_GetSensitivityLabelList();
			log.info("Sensitivity Labels: {}", labels);

			String labelId = "bf6d8c37-5bcf-4bc2-b06b-a6032f19e2a3";

			// 파일 AIP 암호화 여부 조회
			// IsFileEncryptedVO encryptedStatus = Sample_IsFileEncrypted(path, fileName);
			// log.info("Is File Encrypted: {}", encryptedStatus);

			// 암호화 상태 조회
			// GetFileStatusVO fileStatus = Sample_GetFileStatus(path, fileName);
			// log.info("File Status: {}", fileStatus);

			// 파일에 AIP 민감도 레이블 적용
			// GenericSnmipResponse setLabelResponse = Sample_SetSensitivityLabel(path, fileName, labelId);
			// log.info("Set Label Response: {}", setLabelResponse);

			// 파일에 AIP 민감도 레이블 제거
			// GenericSnmipResponse removeLabelResponse = Sample_RemoveSensitivityLabel(path, fileName);
			// log.info("Remove Label Response: {}", removeLabelResponse);

			// 파일에 AIP 사용자 지정 보호를 적용
			// GenericSnmipResponse customProtectionResponse = Sample_SetCustomProtection(path, fileName,
			// 	contentValidUntil, customUserRights);
			// log.info("Set Custom Protection Response: {}", customProtectionResponse);

			/**
			 * POI 엑셀 생성 후 민감도 레이블 적용 샘플
			 */
			fileName = "test.xlsx";
			// POI 엑셀 생성 후 AIP 민감도 레이블 적용
			GenericSnmipResponse setLabelResponseWithPoi = Sample_SetSensitivityLabelWithPoi(path, fileName, labelId);
			log.info("Set Label Response: {}", setLabelResponseWithPoi);

			// POI 엑셀 에 민감도 레이블이 적용되었는지 확인
			IsFileEncryptedVO encryptedStatus = Sample_IsFileEncrypted(path, fileName);
			log.info("Is File Encrypted: {}", encryptedStatus);

			return ResponseEntity.ok(CommonResponseVO.builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(null)
				.build());

		} catch (Exception e) {
			log.error("Error during snmipTest: ", e);
			return ResponseEntity.internalServerError().body(CommonResponseVO.builder()
				.successOrNot(CommonConstants.NO_FLAG)
				.statusCode(StatusCodeConstants.FAIL)
				.data(e.getMessage())
				.build());
		}
	}

	/**
	 * GetSensitivityLabelList - 사용 가능한 민감도 레이블 목록을 조회합니다.
	 */
	public static List<GetSensitivityLabelListVO> Sample_GetSensitivityLabelList() {
		log.info("# Sample_GetSensitivityLabelList");
		GetSensitivityLabelListRequest payload = GetSensitivityLabelListRequest.builder()
			.SystemId(SYSTEM_ID)
			.build();
		GetSensitivityLabelListVO[] result = HttpConnectionUtil.restRequestToVO(
			"POST",
			AIP_URL + "/GetSensitivityLabelList",
			payload,
			GetSensitivityLabelListVO[].class,
			null
		);
		return Arrays.asList(result);
	}

	/**
	 * IsFileEncrypted - 파일의 AIP 암호화 여부를 검사합니다.
	 */
	public static IsFileEncryptedVO Sample_IsFileEncrypted(String path, String fileName) {
		log.info("# Sample_IsFileEncrypted");
		String nfsPath = NFS_PATH + path.replaceAll("/", "\\\\");
		log.info(" -> Path: {}", nfsPath);
		FileRequest payload = FileRequest.builder()
			.SystemId(SYSTEM_ID)
			.Path(nfsPath)
			.FileName(fileName)
			.build();
		return HttpConnectionUtil.restRequestToVO(
			"POST",
			AIP_URL + "/IsFileEncrypted",
			payload,
			IsFileEncryptedVO.class,
			null
		);
	}

	/**
	 * GetFileStatus - 파일의 AIP 암호화 상태를 조회합니다.
	 */
	public static GetFileStatusVO Sample_GetFileStatus(String path, String fileName) {
		log.info("# Sample_GetFileStatus");
		String nfsPath = NFS_PATH + path.replaceAll("/", "\\\\");
		log.info(" -> Path: {}", nfsPath);
		FileRequest payload = FileRequest.builder()
			.SystemId(SYSTEM_ID)
			.Path(nfsPath)
			.FileName(fileName)
			.build();
		return HttpConnectionUtil.restRequestToVO(
			"POST",
			AIP_URL + "/GetFileStatus",
			payload,
			GetFileStatusVO.class,
			null
		);
	}

	/**
	 * SetSensitivityLabel - 파일에 AIP 민감도 레이블을 적용합니다.
	 */
	public static GenericSnmipResponse Sample_SetSensitivityLabel(String path, String fileName, String labelId) {
		log.info("# Sample_SetSensitivityLabel");
		String nfsPath = NFS_PATH + path.replaceAll("/", "\\\\");
		log.info(" -> Path: {}", nfsPath);
		SetSensitivityLabelRequest payload = SetSensitivityLabelRequest.builder()
			.SystemId(SYSTEM_ID)
			.Path(nfsPath)
			.FileName(fileName)
			.LabelId(labelId)
			.build();
		return HttpConnectionUtil.restRequestToVO(
			"POST",
			AIP_URL + "/SetSensitivityLabel",
			payload,
			GenericSnmipResponse.class,
			null
		);
	}

	/**
	 * RemoveSensitivityLabel - 파일의 AIP 민감도 레이블을 제거합니다.
	 */
	public static GenericSnmipResponse Sample_RemoveSensitivityLabel(String path, String fileName) {
		log.info("# Sample_RemoveSensitivityLabel");
		String nfsPath = NFS_PATH + path.replaceAll("/", "\\\\");
		log.info(" -> Path: {}", nfsPath);
		FileRequest payload = FileRequest.builder()
			.SystemId(SYSTEM_ID)
			.Path(nfsPath)
			.FileName(fileName)
			.build();
		return HttpConnectionUtil.restRequestToVO(
			"POST",
			AIP_URL + "/RemoveSensitivityLabel",
			payload,
			GenericSnmipResponse.class,
			null
		);
	}

	/**
	 * Sample_SetCustomProtection - 파일에 AIP 사용자 지정 보호를 적용합니다.
	 */
	public static GenericSnmipResponse Sample_SetCustomProtection(
		String path,
		String fileName,
		String contentValidUntil,
		List<GetFileStatusVO.CustomUserRight> customUserRights
	) {
		log.info("# Sample_SetCustomProtection");
		String nfsPath = NFS_PATH + path.replaceAll("/", "\\\\");
		log.info(" -> Path: {}", nfsPath);
		SetCustomProtectionRequest payload = SetCustomProtectionRequest.builder()
			.SystemId(SYSTEM_ID)
			.Path(nfsPath)
			.FileName(fileName)
			.ContentValidUntil(contentValidUntil)
			.CustomUserRights(customUserRights)
			.build();
		return HttpConnectionUtil.restRequestToVO(
			"POST",
			AIP_URL + "/SetCustomProtection",
			payload,
			GenericSnmipResponse.class,
			null
		);
	}

	/**
	 * Sample_SetSensitivityLabelWithPoi - POI로 엑셀 파일을 생성하고 파일에 AIP 민감도 레이블을 적용합니다.
	 */
	public static GenericSnmipResponse Sample_SetSensitivityLabelWithPoi(String path, String fileName, String labelId) {
		log.info("# Sample_SetSensitivityLabelWithPoi");
		String nfsPath = NFS_PATH + path.replaceAll("/", "\\\\");
		log.info(" -> Path: {}", nfsPath);

		createSampleExcel(staticNfsDir + path + "/" + fileName);

		SetSensitivityLabelRequest payload = SetSensitivityLabelRequest.builder()
			.SystemId(SYSTEM_ID)
			.Path(nfsPath)
			.FileName(fileName)
			.LabelId(labelId)
			.build();
		return HttpConnectionUtil.restRequestToVO(
			"POST",
			AIP_URL + "/SetSensitivityLabel",
			payload,
			GenericSnmipResponse.class,
			null
		);
	}

	/**
	 * createSampleExcel - POI로 엑셀 파일 생성.
	 */
	public static void createSampleExcel(String tempPath) {
		Workbook workbook = new XSSFWorkbook();
		Sheet sheet = workbook.createSheet("샘플시트");

		Row header = sheet.createRow(0);
		header.createCell(0).setCellValue("이름");
		header.createCell(1).setCellValue("점수");

		Row row1 = sheet.createRow(1);
		row1.createCell(0).setCellValue("홍길동");
		row1.createCell(1).setCellValue(90);

		Row row2 = sheet.createRow(2);
		row2.createCell(0).setCellValue("김철수");
		row2.createCell(1).setCellValue(85);

		try (FileOutputStream fileOut = new FileOutputStream(tempPath)) {
			workbook.write(fileOut);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				workbook.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@Getter
	@Builder
	@ToString
	private static class GetSensitivityLabelListRequest {
		/** 시스템 ID */
		private String SystemId;
	}

	@Getter
	@Builder
	@ToString
	private static class FileRequest {
		/** 시스템 ID */
		private String SystemId;
		/** 파일 경로 */
		private String Path;
		/** 파일 이름 */
		private String FileName;
	}

	@Getter
	@Builder
	@ToString
	private static class SetSensitivityLabelRequest {
		/** 시스템 ID */
		private String SystemId;
		/** 파일 경로 */
		private String Path;
		/** 파일 이름 */
		private String FileName;
		/** 레이블 ID */
		private String LabelId;
	}

	@Getter
	@Builder
	@ToString
	private static class SetCustomProtectionRequest {
		/** 시스템 ID */
		private String SystemId;
		/** 파일 경로 */
		private String Path;
		/** 파일 이름 */
		private String FileName;
		/** 콘텐츠 유효 기간 (YYYY-MM-DD) */
		private String ContentValidUntil;
		/** 사용자 지정 권한 목록 */
		private List<GetFileStatusVO.CustomUserRight> CustomUserRights;
	}

	@Getter
	@Builder
	@ToString
	public static class GetSensitivityLabelListVO {
		/** 레이블 ID */
		private String Id;
		/** 레이블 이름 */
		private String Name;
		/** 민감도 수준 */
		private int Sensitivity;
		/** 레이블 설명 */
		private String Description;
	}

	@Getter
	@SuperBuilder
	@ToString
	public static class IsFileEncryptedVO extends GenericSnmipResponse {
		/** 입력 파일 경로 */
		private String InputFilePath;
		/** AIP 암호화 여부 */
		private boolean IsAIPEncrypted;
	}

	@Getter
	@SuperBuilder
	@ToString
	public static class GetFileStatusVO extends GenericSnmipResponse {
		/** 파일 이름 */
		private String FileName;
		/** 레이블 지정 여부 */
		private boolean IsLabeled;
		/** 레이블 ID */
		private String LabelId;
		/** 레이블 이름 */
		private String LabelName;
		/** 레이블 지정 방법 */
		private String LabelingMethod;
		/** 레이블 지정 날짜 */
		private String LabelDate;
		/** RMS 보호 여부 */
		private boolean IsRMSProtected;
		/** RMS 템플릿 ID */
		private String RMSTemplateId;
		/** RMS 템플릿 이름 */
		private String RMSTemplateName;
		/** RMS 소유자 */
		private String RMSOwner;
		/** 콘텐츠 ID */
		private String ContentId;
		/** 콘텐츠 유효 기간 (YYYY-MM-DD) */
		private String ContentValidUntil;
		/** 사용자 지정 권한 목록 */
		private List<CustomUserRight> CustomUserRights;

		@Getter
		@Builder
		@ToString
		public static class CustomUserRight {
			/** 권한 목록 (예: VIEW, EDIT) */
			private List<String> Rights;
			/** 사용자 목록 (이메일 주소) */
			private List<String> Users;
		}
	}

	@Getter
	@SuperBuilder
	@ToString
	public static class GenericSnmipResponse {
		/** API 호출 결과 (true: 성공, false: 실패) */
		private boolean Result;
		/** API 호출 결과 메시지 */
		private String Message;
	}
}
