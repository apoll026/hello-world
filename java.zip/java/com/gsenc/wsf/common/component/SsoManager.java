package com.gsenc.wsf.common.component;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.gsenc.wsf.common.constant.SsoConstants;
import com.gsenc.wsf.common.exception.BusinessException;
import com.gsenc.wsf.common.model.SsoVO;

import SafeIdentity.SSO;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class SsoManager {

	private static final Map<Integer, String> ERROR_MESSAGES = new HashMap<>();

	static {
		ERROR_MESSAGES.put(-441, "Token 값이 존재 하지 않습니다. 로그인 상태를 확인해 주세요.");
		ERROR_MESSAGES.put(-442, "Token 값이 존재 하지 않습니다. 로그인 상태를 확인해 주세요.");
		ERROR_MESSAGES.put(-448, "SSO Agent, PolicyServer가 응답하지 않습니다.");
		ERROR_MESSAGES.put(-710, "SSO Agent, PolicyServer가 응답하지 않습니다.");
		ERROR_MESSAGES.put(-748, "SSO Agent, PolicyServer가 응답하지 않습니다.");
		ERROR_MESSAGES.put(-771, "SSO Agent, PolicyServer가 응답하지 않습니다.");
		ERROR_MESSAGES.put(-1032, "SSO Agent, PolicyServer가 응답하지 않습니다.");
		ERROR_MESSAGES.put(-1033, "SSO Agent, PolicyServer가 응답하지 않습니다.");
		ERROR_MESSAGES.put(-1205, "다시 로그인해주세요.");
		ERROR_MESSAGES.put(-1207, "다시 로그인해주세요.");
		ERROR_MESSAGES.put(-2902, "사용자의 세션이 만료되었습니다. 다시 로그인해주세요.");
		ERROR_MESSAGES.put(-2919, "허용된 동시접속 개수를 초과하였습니다.");
		ERROR_MESSAGES.put(-2979, "사용자의 요청이 너무 많아 정책서버가 요청을 처리하지 못했습니다. 잠시 후에 다시 시도해주세요.");
	}

	public String extractToken(HttpServletRequest request) {
		String sToken = getCookie(request);
		if (sToken == null || sToken.isEmpty()) {
			sToken = request.getParameter(SsoConstants.S_NAME);
		}
		return sToken;
	}

	public SSO verifySsoToken(String sToken, String sRemoteAddr) {
		SSO sso = new SSO();
		int nResult = sso.verifyToken(sToken, sRemoteAddr);
		if (nResult != 0) {
			String errorMessage = getErrorMessage(nResult);
			log.error("SSO Token validation failed: {}, Error Code: {}", errorMessage, nResult);
			throw new BusinessException(errorMessage);
		}
		return sso;
	}

	public static SsoVO buildSsoVO(SSO sso) {
		return SsoVO.builder()
			.uid(sso.getValueUserID())
			.userId(sso.getValue("USERID"))
			.empNo(sso.getValue("EMPNO"))
			.userType(sso.getValue("USERTYPE"))
			.locale(sso.getValue("LOCALE"))
			.build();
	}

	private String getCookie(HttpServletRequest request) {
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (Cookie cookie : cookies) {
				if (SsoConstants.S_NAME.equals(cookie.getName())) {
					return cookie.getValue();
				}
			}
		}
		return null;
	}

	private String getErrorMessage(int nResult) {
		return ERROR_MESSAGES.getOrDefault(nResult, "알수 없는 오류가 발생하였습니다. 다시 시도해주시고 오류가 반복될 경우 연락주세요.");
	}

}
