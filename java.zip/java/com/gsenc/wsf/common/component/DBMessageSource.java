package com.gsenc.wsf.common.component;

import java.text.MessageFormat;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.context.support.AbstractMessageSource;
import org.springframework.stereotype.Component;

import com.gsenc.wsf.message.model.MessageSimpleVO;
import com.gsenc.wsf.message.service.MessageService;

@Component("messageSource")
public class DBMessageSource extends AbstractMessageSource {
    @Autowired
    private MessageService messageService;
    private static final String DEFAULT_LOCALE_CODE = "ko";

    @Override
    protected MessageFormat resolveCode(String code, Locale locale) {

        Locale currentLocale = LocaleContextHolder.getLocale();

        // 주석으로 다국어 변환 모듈 주석처리 원복 할때는 아래 리턴문은 주석처리 하고 아래에 있는 주석 풀면됨
        // 반영되면 안됨
        //return new MessageFormat(code,currentLocale);


        //swagger 주석으로 다국어 변환 모듈 주석처리

        String newLocale;
        if(currentLocale.toString().equals("zht")){
            newLocale = "zhT";
        }else if (currentLocale.toString().equals("zhc")){
            newLocale = "zhC";
        }else{
            newLocale = currentLocale.getLanguage();
        }

        MessageSimpleVO message = messageService.findMessageCache(code, newLocale);

        if (message == null) {
            return new MessageFormat(code,currentLocale);
        }
        return new MessageFormat(message.getMsgTxtCtn(),currentLocale);


    }
}
