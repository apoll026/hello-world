package com.gsenc.wsf.common.component;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import com.gsenc.wsf.message.service.MessageService;

@Component
public class MessageApplicationRunner implements ApplicationRunner {

    private final MessageService messageService;

    public MessageApplicationRunner(MessageService messageService) {
        this.messageService = messageService;
    }

    @Override
    public void run(ApplicationArguments args) throws Exception {
        messageService.deployTranslatedMessagesAll();
    }
}
