package com.gsenc.wsf.common.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;
import lombok.experimental.UtilityClass;

@UtilityClass
public class RequestUtil {

	/**
	 * HTTP 요청의 파라미터를 JSON 문자열로 변환합니다.
	 *
	 * @param request HTTP 요청 객체
	 * @return 요청 파라미터를 JSON 형식으로 변환한 문자열
	 * @throws Exception JSON 변환 중 발생할 수 있는 예외
	 */
	public static String getRequestParametersAsJson(HttpServletRequest request) throws Exception {
		String method = request.getMethod();
		if ("GET".equalsIgnoreCase(method)) {
			// GET: 쿼리 파라미터
			Map<String, String[]> paramMap = request.getParameterMap();
			ObjectMapper objectMapper = new ObjectMapper();
			return objectMapper.writeValueAsString(paramMap);
		} else if ("POST".equalsIgnoreCase(method)) {
			String contentType = request.getContentType();
			if (contentType != null && contentType.contains("application/json")) {
				// POST: JSON body
				return getBody(request);
			} else if (contentType != null && contentType.contains("application/x-www-form-urlencoded")) {
				// POST: 폼 파라미터
				Map<String, String[]> paramMap = request.getParameterMap();
				ObjectMapper objectMapper = new ObjectMapper();
				return objectMapper.writeValueAsString(paramMap);
			} else {
				// 기타: body 전체 반환
				return getBody(request);
			}
		}
		// 기타 메서드 처리
		return null;
	}

	/**
	 * HTTP 요청의 본문(body)을 문자열로 읽어옵니다.
	 *
	 * @param request HTTP 요청 객체
	 * @return 요청 본문 문자열
	 * @throws IOException 요청 본문 읽기 중 발생할 수 있는 예외
	 */
	public static String getBody(HttpServletRequest request) throws IOException {
		StringBuilder sb = new StringBuilder();
		BufferedReader reader = request.getReader();
		String line;
		while ((line = reader.readLine()) != null) {
			sb.append(line);
		}
		return sb.toString();
	}
}
