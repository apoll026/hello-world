package com.gsenc.wsf.common.util;

import java.io.InputStream;
import java.net.URLEncoder;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.core.MediaType;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.BodyPart;
import com.sun.jersey.multipart.BodyPartEntity;
import com.sun.jersey.multipart.FormDataBodyPart;
import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.file.StreamDataBodyPart;

import lombok.extern.slf4j.Slf4j;
import net.sf.json.JSONObject;

/**
 * Restful Client ( Call Lib )
 *
 * @author
 * @version 1.0.0
 * @since 2013. 2. 18. 오전 10:17:23
 */
@Slf4j
public class RestfulClient {


    /**
     * read time 오래 걸리는 회사를 위해 10초로
     *
     * @param pathUri
     * @param headEntity
     * @param requestEntity
     * @param <T>
     * @return
     * @throws Exception
     */
    public static <T> T clientResponseLong(String pathUri, Class<T> headEntity, Object requestEntity) throws Exception {
        return clientResponse(pathUri, headEntity, requestEntity, 10000);
    }

    public static <T> T clientResponse(String pathUri, Class<T> headEntity, Object requestEntity) throws Exception {
        return clientResponse(pathUri, headEntity, requestEntity, 3000);
    }

    /**
     * 클라이언트 요청 및 결과 : 기본 JSON 전달
     *
     * @param pathUri
     * @param headEntity
     * @param requestEntity
     * @return headEntity
     * @throws Exception
     */
    public static <T> T clientResponse(String pathUri, Class<T> headEntity, Object requestEntity, int time) throws Exception {

        // 변수
        T result = null;
        // Head head = null;
        // AuthInfoBody body = null;
        Client client = null;
        try {

            // 데이터 가져오기
            client = Client.create();

            WebResource webResource = client.resource(pathUri);

            client.setConnectTimeout(1000); // timeout
            client.setReadTimeout(time);

            // Post로 요청 : JSON
            ClientResponse response = webResource.type(MediaType.APPLICATION_JSON_TYPE)
                    .accept(MediaType.APPLICATION_JSON)
                    .post(ClientResponse.class, requestEntity.toString());

            // 결과 상태 체크
            if (response.getStatus() != 200) {
                throw new RuntimeException("Failed : HTTP error  :"
                        + response.getClientResponseStatus().getReasonPhrase() + " (" + response.getStatus() + ")");
            }

            // 결과 Entiry
            T returnData = response.getEntity(headEntity);

            // 결과
            result = returnData;

        } catch (Exception e) {
            throw e;
        } finally {
            log.info("clientResponse :: finally");
        }

        return result;

    }

    /**
     * 클라이언트 요청 및 결과 : xml 전달
     *
     * @param pathUri
     * @param headEntity
     * @param requestEntity
     * @return headEntity
     * @throws Exception
     */
    public static <T> T clientResponseXml(String pathUri, Class<T> headEntity, Object requestEntity) throws Exception {

        // 변수
        T result = null;
        // Head head = null;
        // AuthInfoBody body = null;

        try {

            // 데이터 가져오기
            Client client = Client.create();

            WebResource webResource = client.resource(pathUri);

            client.setConnectTimeout(100); // timeout
            client.setReadTimeout(3000);

            // Post로 요청 : JSON
            ClientResponse response = webResource.type(MediaType.APPLICATION_XML_TYPE)
                    // .accept(MediaType.APPLICATION_XML)
                    .post(ClientResponse.class, requestEntity.toString());

            // 결과 상태 체크
            if (response.getStatus() != 200) {
                throw new RuntimeException("Failed : HTTP error  :"
                        + response.getClientResponseStatus().getReasonPhrase() + " (" + response.getStatus() + ")");
            }

            // 결과 Entiry
            T returnData = response.getEntity(headEntity);

            // 결과
            result = returnData;

        } catch (Exception e) {
            throw e;
        } finally {
            log.info("clientResponseXml :: finally");
        }

        return result;

    }


    /**
     * post 방식으로 전달
     *
     * @param pathUri
     * @param headEntity
     * @param requestEntity
     * @return
     * @throws Exception
     */
    public static <T> T clientResponsePost(String pathUri, Class<T> headEntity, Object requestEntity) throws Exception {

        // 변수
        T result = null;
        // Head head = null;
        // AuthInfoBody body = null;

        try {

            // 데이터 가져오기
            Client client = Client.create();

            WebResource webResource = client.resource(pathUri);

            client.setConnectTimeout(5000); // timeout
            client.setReadTimeout(5000);

            // Post로 요청 : JSON
            ClientResponse response = webResource.type(MediaType.APPLICATION_FORM_URLENCODED_TYPE + "; charset=UTF-8")
                    .post(ClientResponse.class, requestEntity.toString());

            // 결과 상태 체크
            if (response.getStatus() != 200) {
                throw new RuntimeException("Failed : HTTP error  :"
                        + response.getClientResponseStatus().getReasonPhrase() + " (" + response.getStatus() + ")");
            }

            // 결과 Entiry
            T returnData = response.getEntity(headEntity);

            // 결과
            result = returnData;

        } catch (Exception e) {
            throw e;
        } finally {
            log.info("com.gsenc.wsf.common.util.RestfulClient#clientResponsePost");
        }

        return result;
    }

    /**
     * post 방식으로 전달 - 파라미터 map으로 받음.
     *
     * @param pathUri
     * @param headEntity
     * @param map
     * @return
     * @throws Exception
     */
    public static <T> T clientResponsePostAsMap(String pathUri, Class<T> headEntity, Map<String, String> map) throws Exception {

        StringBuilder sb = new StringBuilder();
        for (Entry<String, String> e : map.entrySet()) {
            if (sb.length() > 0) {
                sb.append('&');
            }
            sb.append(e.getKey()).append('=').append(URLEncoder.encode(e.getValue(), "UTF-8"));
        }

        return clientResponsePost(pathUri, headEntity, sb);
    }

    /*
     * private static String convertStreamToString(InputStream is) {
     *
     * BufferedReader reader = new BufferedReader(new InputStreamReader(is));
     * StringBuilder sb = new StringBuilder();
     *
     * String line = null; try { while ((line = reader.readLine()) != null) {
     * sb.append(line + "\n"); } } catch (IOException e) { e.printStackTrace();
     * } finally { try { is.close(); } catch (IOException e) {
     * e.printStackTrace(); } } return sb.toString(); }
     */

    /**
     * 클라이언트 파일업로드 요청 및 결과
     *
     * @param pathUri
     * @param headEntity
     * @param mimeMultipartData
     * @return headEntity
     * @throws Exception
     */
    public static <T> T clientResponseFileUpload(String pathUri, Class<T> headEntity,
                                                 FormDataMultiPart mimeMultipartData) throws Exception {

        // 변수
        T result = null;
        FormDataMultiPart form = null;
        try {

            // 데이터 가져오기
            Client client = Client.create();

            // 리소스정보 설정 : ex) http://domain:port/ikep4-webapp/rest
            WebResource webResource = client.resource(pathUri);

            // Set FormData
            form = new FormDataMultiPart();

            // String fileEncoding=System.getProperty("file.encoding"); //
            // JAVA_OPTS -Dfile.encoding=UTF-8
            // log.debug("file.encoding = "+fileEncoding);

            for (BodyPart p : mimeMultipartData.getBodyParts()) {
                FormDataBodyPart bp = (FormDataBodyPart) p;

                if (p.getContentDisposition().getFileName() != null) {
                    BodyPartEntity bpe = (BodyPartEntity) p.getEntity(); // is this cast safe?
                    InputStream fileStream = bpe.getInputStream();

                    FormDataContentDisposition disposition = (FormDataContentDisposition) p.getContentDisposition();

                    // set param File
                    StreamDataBodyPart sbp = new StreamDataBodyPart("file", fileStream,
                            URLEncoder.encode(disposition.getFileName(), "UTF-8"), MediaType.MULTIPART_FORM_DATA_TYPE);

                    form.bodyPart(sbp);

                } else if (bp.isSimple()) {
                    String name = bp.getName();
                    String value = bp.getValue();

                    // value = XssFilterCore.getInstance().doFilter(value);

                    // set param field
                    form.field(name, value);

                }
            }

            // Post로 요청 : JSON
            ClientResponse response = webResource.type(MediaType.MULTIPART_FORM_DATA).accept(MediaType.APPLICATION_JSON)
                    .post(ClientResponse.class, form);

            // 결과 상태 체크
            if (response.getStatus() != 200) {
                throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
            }

            // 결과 Entiry
            T returnData = response.getEntity(headEntity);

            // 결과
            result = returnData;

        } catch (Exception e) {
            throw e;
        } finally {
            if(form != null){
                form.close();
            }
        }

        return result;
    }

    /**
     * 클라이언트 요청 및 결과 : 기본 JSON 전달 / Header Cookie값 전달
     *
     * @param pathUri
     * @param requestEntity
     * @return
     * @throws Exception
     */
    public static String clientResponseGetCookie(String pathUri, Object requestEntity) throws Exception {

        // 변수
        JSONObject resultJSON = new JSONObject();
        // Head head = null;
        // AuthInfoBody body = null;

        try {

            // 데이터 가져오기
            Client client = Client.create();

            WebResource webResource = client.resource(pathUri);

            client.setConnectTimeout(100); // timeout
            client.setReadTimeout(3000);

            // Post로 요청 : JSON
            ClientResponse response = webResource.type(MediaType.APPLICATION_JSON_TYPE)
                    // .accept(MediaType.APPLICATION_JSON)
                    .post(ClientResponse.class, requestEntity.toString());

            // 결과 상태 체크
            if (response.getStatus() != 200) {
                throw new RuntimeException("Failed : HTTP error  :"
                        + response.getClientResponseStatus().getReasonPhrase() + " (" + response.getStatus() + ")");
            }

            if (response.getHeaders().containsKey("Set-Cookie")) {
                resultJSON.put("Set-Cookie", response.getHeaders().get("Set-Cookie").get(0).split(";")[0]);
            }

            // 결과 Entiry
            JSONObject returnData = JSONObject.fromObject(response.getEntity(String.class));
            resultJSON.put("Result", returnData.optString("Result"));

        } catch (Exception e) {
            throw e;
        }

        return resultJSON.toString();

    }


    public static <T> T clientResponseGET(String pathUri, Class<T> headEntity, String cookie) throws Exception {

        // 변수
        T result = null;
        // Head head = null;
        // AuthInfoBody body = null;

        try {

            // 데이터 가져오기
            Client client = Client.create();

            WebResource webResource = client.resource(pathUri);

            client.setConnectTimeout(100); // timeout
            client.setReadTimeout(3000);

            // Post로 요청 : JSON
            ClientResponse response = webResource.type(MediaType.APPLICATION_JSON_TYPE)
                    // .accept(MediaType.APPLICATION_JSON)
                    .header("Cookie", cookie)
                    .get(ClientResponse.class);

            // 결과 상태 체크
            if (response.getStatus() != 200) {
                throw new RuntimeException("Failed : HTTP error  :"
                        + response.getClientResponseStatus().getReasonPhrase() + " (" + response.getStatus() + ")");
            }

            // 결과 Entiry
            T returnData = response.getEntity(headEntity);

            // 결과
            result = returnData;

        } catch (Exception e) {
            throw e;
        }

        return result;
    }

    public static <T> T clientResponseSetCookie(String pathUri, Class<T> headEntity, Object requestEntity, String cookie) throws Exception {

        // 변수
        T result = null;
        // Head head = null;
        // AuthInfoBody body = null;

        try {

            // 데이터 가져오기
            Client client = Client.create();

            WebResource webResource = client.resource(pathUri);

            client.setConnectTimeout(1000); // timeout
            client.setReadTimeout(5000);

            // Post로 요청 : JSON
            ClientResponse response = webResource.type(MediaType.APPLICATION_JSON_TYPE)
                    // .accept(MediaType.APPLICATION_JSON)
                    .header("Cookie", cookie)
                    .post(ClientResponse.class, requestEntity.toString());

            // 결과 상태 체크
            if (response.getStatus() != 200) {
                throw new RuntimeException("Failed : HTTP error  :"
                        + response.getClientResponseStatus().getReasonPhrase() + " (" + response.getStatus() + ")");
            }

            // 결과 Entiry
            T returnData = response.getEntity(headEntity);

            // 결과
            result = returnData;

        } catch (Exception e) {
            throw e;
        }

        return result;
    }


}
