package com.gsenc.wsf.common.util;

import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.session.model.UserCompanySessionVO;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.experimental.UtilityClass;

@UtilityClass
public class SessionScopeUtil {
	public static void setRequestContext(String name, Object value) {

		RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();

		if (requestAttributes != null) {
			requestAttributes.setAttribute(name, value, RequestAttributes.SCOPE_REQUEST);
		}
	}

	public static Object getRequestContext(String name) {
		RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
		if (requestAttributes != null) {
			return requestAttributes.getAttribute(name, RequestAttributes.SCOPE_REQUEST);
		} else {
			return null;
		}
	}

	public static UserSessionVO getContextSession() {
		return (UserSessionVO)getRequestContext(CommonConstants.HTTP_SESSION_KEY);
	}

	public static void setContextSession(Object value) {
		setRequestContext(CommonConstants.HTTP_SESSION_KEY, value);
	}

	public static UserCompanySessionVO getCompanyContextSession() {
		return (UserCompanySessionVO)getRequestContext(CommonConstants.HTTP_SESSION_KEY);
	}

	public static void setCompanyContextSession(Object value) {
		setRequestContext(CommonConstants.HTTP_SESSION_KEY, value);
	}

}
