package com.gsenc.wsf.common.util;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Entities;

import com.gsenc.wsf.file.model.FileVO;
import com.gsenc.wsf.file.service.FileService;

import lombok.experimental.UtilityClass;

@UtilityClass
public class NamoEditorHtmlUtil {

    public String updateCtnWithPreSignedUrls(String ctn, FileService fileService) {
        String decodedHtml = Entities.unescape(ctn);
        Document document = Jsoup.parse(decodedHtml);
        document.select("[class*=namoUploaded]").forEach(element -> {
            String[] ids = element.id().split(",");
            FileVO downloadUrlResponse = fileService.createPreSignedDownloadUrl(ids[0], ids[1]);//download호출하고
            if(element.tagName().equals("video"))
            {
                element.select("source").attr("src",downloadUrlResponse.getPreSignedUrl());
            }else{
                if (element.hasAttr("src")) { //img태그
                    element.attr("src", downloadUrlResponse.getPreSignedUrl()); //src속성 갈아끼우기
                }
                if(element.hasAttr("data")){
                    element.attr("data", downloadUrlResponse.getPreSignedUrl()); //src속성 갈아끼우기
                }
                if (element.hasAttr("href")) {//a태그
                    element.attr("href", downloadUrlResponse.getPreSignedUrl()); //href속성 갈아끼우기
                }
            }


        });
        return document.html();//txt형태
    }
}
