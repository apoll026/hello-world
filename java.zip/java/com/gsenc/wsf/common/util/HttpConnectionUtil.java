package com.gsenc.wsf.common.util;

import java.util.Collections;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.gsenc.wsf.common.constant.HttpMethodConstants;

import lombok.experimental.UtilityClass;

@UtilityClass
public class HttpConnectionUtil {

	private static Gson gson = new Gson();

	/**
	 * @param method     : POST, GET
	 * @param pURL       : 요청 URL
	 * @param attributes : 파라미터 VO 객체
	 * @param classType  : Response VO class
	 * @author YT
	 */
	public static JsonObject restRequest(String method, String pURL, Object attributes, Class<?> classType,
		HttpHeaders optionHeaders) {

		// RestTemplate
		RestTemplate restTemplate = new RestTemplate();

		// ContentType, Accept외 OptionHeader (e.g. x-api-key)
		HttpHeaders headers = optionHeaders;
		if (headers == null) {
			headers = new HttpHeaders();
		}

		// application/json
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

		// VO 객체와 Headers를 조합해서 Entity 생성
		HttpEntity<?> entity = new HttpEntity<>(attributes, headers);

		ResponseEntity<String> response = restTemplate.exchange(pURL, HttpMethod.POST, entity, String.class);
		if (method.equals(HttpMethodConstants.GET)) {
			response = restTemplate.exchange(pURL, HttpMethod.GET, entity, String.class);
		}

		// response body 예시 : {"header":{"returnCode":0,"returnDesc":"OK"}})

		JsonObject obj = gson.fromJson(response.getBody(), JsonObject.class);

		return obj;

	}

	/**
	 * 지정된 VO 타입으로 API 요청 결과를 반환합니다.
	 *
	 * @param method          : HTTP 메서드 (POST, GET 등)
	 * @param pURL            : 요청 URL
	 * @param attributes      : 요청 파라미터 객체
	 * @param responseType    : 응답을 변환할 VO 클래스 타입
	 * @param optionHeaders   : 추가 HTTP 헤더
	 * @param <T>             : 응답 VO의 타입
	 * @return                : 변환된 응답 VO 객체
	 */
	public static <T> T restRequestToVO(String method, String pURL, Object attributes, Class<T> responseType,
		HttpHeaders optionHeaders) {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = (optionHeaders != null) ? optionHeaders : new HttpHeaders();

		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

		HttpMethod httpMethod = HttpMethod.valueOf(method.toUpperCase());
		String requestUrl = pURL;
		HttpEntity<?> entity;

		if (HttpMethodConstants.GET.equalsIgnoreCase(method) && attributes != null) {
			String queryString = convertObjectToQueryString(attributes);
			if (!queryString.isEmpty()) {
				requestUrl = pURL + (pURL.contains("?") ? "&" : "?") + queryString;
			}
			entity = new HttpEntity<>(headers);
		} else {
			entity = new HttpEntity<>(attributes, headers);
		}

		ResponseEntity<String> responseEntity = restTemplate.exchange(requestUrl, httpMethod, entity, String.class);

		String responseBody = responseEntity.getBody();
		if (responseBody != null && responseBody.startsWith("(") && responseBody.endsWith(")")) {
			responseBody = responseBody.substring(1, responseBody.length() - 1);
		}

		return gson.fromJson(responseBody, responseType);
	}

	/**
	 * 객체를 URL 쿼리 스트링으로 변환합니다.
	 *
	 * @param obj : 변환할 객체
	 * @return    : 쿼리 스트링 (예: "param1=value1&param2=value2")
	 */
	private static String convertObjectToQueryString(Object obj) {
		if (obj == null) {
			return "";
		}

		JsonObject jsonObject = gson.toJsonTree(obj).getAsJsonObject();
		StringBuilder queryString = new StringBuilder();

		jsonObject.entrySet().forEach(entry -> {
			if (!queryString.isEmpty()) {
				queryString.append("&");
			}
			try {
				String key = entry.getKey();
				String value = entry.getValue().isJsonNull() ? "" : entry.getValue().getAsString();
				queryString.append(key)
					.append("=")
					.append(value);
			} catch (Exception e) {
			}
		});

		return queryString.toString();
	}
}
