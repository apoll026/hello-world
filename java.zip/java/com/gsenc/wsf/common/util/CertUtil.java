package com.gsenc.wsf.common.util;

import java.util.HashMap;
import java.util.Map;

public class CertUtil {

	// 인증번호와 만료시간을 담은 Map 생성
	public static Map<String, Object> createCertInfo(String secureNumber) {
		long expireTime = System.currentTimeMillis() + (5 * 60 * 1000); // 5분 후
		Map<String, Object> certInfo = new HashMap<>();
		certInfo.put("number", secureNumber);
		certInfo.put("expireTime", expireTime);
		return certInfo;
	}

	// 인증번호 유효성 검증
	public static boolean isValidCert(Map<String, Object> certInfo, String inputNumber) {
		if (certInfo == null || inputNumber == null) {
			return false;
		}
		String storedNumber = (String)certInfo.get("number");
		Long expireTime = (Long)certInfo.get("expireTime");
		if (storedNumber == null || expireTime == null) {
			return false;
		}
		long currentTime = System.currentTimeMillis();
		if (currentTime > expireTime) {
			return false; // 만료됨
		}
		return storedNumber.equals(inputNumber);
	}

}
