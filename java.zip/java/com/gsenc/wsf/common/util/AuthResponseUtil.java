package com.gsenc.wsf.common.util;

import java.io.IOException;
import java.io.PrintWriter;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.SsoConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class AuthResponseUtil {

	private static final ObjectMapper objectMapper = new ObjectMapper();

	public static boolean handleAuthFailure(HttpServletResponse response, String statusCode, HttpServletRequest request)
		throws IOException {

		response.setContentType(MediaType.APPLICATION_JSON_VALUE);
		response.setCharacterEncoding("UTF-8");

		CommonResponseVO<?> errorResponse = createErrorResponse(statusCode);
		HttpStatus httpStatus = determineHttpStatus(statusCode);

		response.setStatus(httpStatus.value());

		PrintWriter writer = response.getWriter();
		writer.write(objectMapper.writeValueAsString(errorResponse));
		writer.flush();

		return false;
	}

	private static CommonResponseVO<?> createErrorResponse(String statusCode) {
		String data = null;
		String finalStatusCode = statusCode;

		// SsoConstants 결과를 StatusCodeConstants로 매핑
		if (SsoConstants.AUTH_SSO_FAILED.equals(statusCode)) {
			finalStatusCode = StatusCodeConstants.SSO_AUTHENTICATION_REQUIRED;
		} else if (SsoConstants.AUTH_AUTHORIZATION_FAILED.equals(statusCode)) {
			finalStatusCode = StatusCodeConstants.ACCESS_DENIED;
		}

		// AuthenticationInterceptor에서 사용하는 "EXCEPTION" 데이터 처리
		if (StatusCodeConstants.SESSION_EXPIRE.equals(finalStatusCode) ||
			StatusCodeConstants.NOT_AUTHORIZED_EXCEPTION.equals(finalStatusCode)) {
			data = "EXCEPTION";
		}

		return CommonResponseVO.builder()
			.successOrNot(CommonConstants.NO_FLAG)
			.statusCode(finalStatusCode)
			.data(data)
			.build();
	}

	private static HttpStatus determineHttpStatus(String statusCode) {
		if (SsoConstants.AUTH_SSO_FAILED.equals(statusCode) ||
			StatusCodeConstants.SSO_AUTHENTICATION_REQUIRED.equals(statusCode) ||
			StatusCodeConstants.AUTHENTICATION_FAILED.equals(statusCode) ||
			StatusCodeConstants.SESSION_EXPIRE.equals(statusCode)) {
			return HttpStatus.UNAUTHORIZED;
		}

		if (StatusCodeConstants.ACCESS_DENIED.equals(statusCode) ||
			StatusCodeConstants.NOT_AUTHORIZED_EXCEPTION.equals(statusCode) ||
			SsoConstants.AUTH_AUTHORIZATION_FAILED.equals(statusCode)) {
			return HttpStatus.FORBIDDEN;
		}

		return HttpStatus.UNAUTHORIZED; // 기본값
	}
}
