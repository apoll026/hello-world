package com.gsenc.wsf.common.util;

public class NullUtil {

	public static Object nvl(Object value, Object defaultValue) {
		return value != null ? value : defaultValue;
	}

	public static String nvl(String value, String defaultValue) {
		return value != null ? value : defaultValue;
	}

	public static boolean isNone(Object value) {
		if (value == null) {
			return true;
		}
		if (value instanceof String) {
			return ((String)value).trim().isEmpty();
		}
		return false;
	}

	/**
	 * 값이 null이 아니고, 빈 문자열(공백 포함)이 아니면 true 반환
	 */
	public static boolean notNone(Object value) {
		return !isNone(value);
	}
}
