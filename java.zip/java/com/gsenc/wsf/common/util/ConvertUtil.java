package com.gsenc.wsf.common.util;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ConvertUtil {

    private static String toCamelCase(String s) {
        StringBuilder camelCaseString = new StringBuilder();
        boolean nextCharUpperCase = false;
        for (char c : s.toCharArray()) {
            if (c == '_') {
                nextCharUpperCase = true;
            } else {
                if (nextCharUpperCase) {
                    camelCaseString.append(Character.toUpperCase(c));
                    nextCharUpperCase = false;
                } else {
                    camelCaseString.append(c);
                }
            }
        }
        return camelCaseString.toString();
    }


    public static List<String> convertCommaStringToList(String param) {
        if (param == null || param.trim().isEmpty()) {
            return Collections.emptyList();
        }

        return Arrays.stream(param.split(","))
                .map(s -> s.replace("'", "").trim())
                .collect(Collectors.toList());
    }

}
