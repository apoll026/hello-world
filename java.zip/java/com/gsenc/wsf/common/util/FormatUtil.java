package com.gsenc.wsf.common.util;

import com.gsenc.wsf.common.exception.BusinessException;

import lombok.experimental.UtilityClass;

@UtilityClass
public final class FormatUtil {

	public static String getEmployeeEmail(String userId, String empNo) throws BusinessException {
		return userId + "@gsenc.com";
	}
}
