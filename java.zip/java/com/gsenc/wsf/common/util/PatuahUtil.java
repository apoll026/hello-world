package com.gsenc.wsf.common.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ebestech.btss.BVat;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class PatuahUtil {

	@Value("${compumtax.ip}")
	private String taxIp;

	@Value("${compumtax.port}")
	private int taxPort;

	@Value("${compumtax.default-corpnum}")
	private String defaultCorpNum;

	public BVat getCompumTax(String corpNum) throws Exception {
		BVat vat = new BVat();

		/* 초기화시 기본 사업자는 "1048118121"으로 셋팅해야함 */
		vat.init3(taxIp, taxPort, defaultCorpNum);
		/* 조회할 사업자번호 전송 (한개 이상 전송 가능)*/
		vat.sendDat("000001" + corpNum);  // 앞6자리는 일련번호, 뒤 10자리는 사업자번호 (조회할 거래처 사업자번호)
		/* 전송종료신호 전송 */
		vat.sendDat("");

		do {
			/* 사업자 유형 수신 */
			//결과값을 받아 오는데 시간이 2초정도 지연 되므로
			//vat.getRecvDat(1000) 결과가 1일 될때 까지 재호출한다.
			int ret = vat.getRecvDat(1000);
			if (ret == 1) {
				// "1" = 일반
				// "2" = 간이
				// "A" = 간이(세금계산서 발급 사업자)
				// "3" = 면세
				// "4" = 휴업
				// "5" = 폐업
				// "6" = 비영리
				// "9" = 알수없음
				break;
			}
		} while (true);
		vat.close();

		return vat;
	}
}
