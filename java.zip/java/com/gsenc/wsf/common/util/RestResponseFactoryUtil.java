package com.gsenc.wsf.common.util;

import com.gsenc.wsf.common.model.DataWrapperVO;
import com.gsenc.wsf.common.model.RecordWrapperVO;

import lombok.experimental.UtilityClass;

@UtilityClass
public class RestResponseFactoryUtil {
    public static <T>DataWrapperVO createReturnDataVO (T resultVO) {
        return DataWrapperVO.builder().data(RecordWrapperVO.builder().record(resultVO).build()).build();
    };
}
