package com.gsenc.wsf.common.service;

import java.util.List;

import com.gsenc.wsf.common.model.PersonalSearchVO;
import com.gsenc.wsf.session.model.UserCompanySessionVO;
import com.gsenc.wsf.session.model.UserSessionVO;

import jakarta.servlet.http.HttpServletRequest;

public interface PersonalSearchService {

	void insertPersonalSearch(HttpServletRequest request);

	List<PersonalSearchVO> selectPersonalSearch(HttpServletRequest request, UserCompanySessionVO userSession);
}
