package com.gsenc.wsf.common.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gsenc.wsf.common.model.PersonalSearchVO;
import com.gsenc.wsf.common.repository.PersonalSearchRepository;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.session.model.UserCompanySessionVO;
import com.gsenc.wsf.session.model.UserSessionVO;

import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class PersonalSearchServiceImpl implements PersonalSearchService {

	private final PersonalSearchRepository personalSearchRepository;

	@Override
	public void insertPersonalSearch(HttpServletRequest request) {

		try {
			String parameterJson = getRequestParamsAsJson(request);
			String originPath = request.getHeader("x-original-path");
			String searchFormId = request.getParameter("searchFormId");

			UserSessionVO session = SessionScopeUtil.getContextSession();

			PersonalSearchVO personalSearchVO = PersonalSearchVO.builder()
				.searchFormId(searchFormId == null ? "default" : searchFormId)
				.searchQuery(parameterJson)
				.searchUrl(originPath)
				.build();

			if (session != null) {
				personalSearchRepository.insertPersonalSearch(personalSearchVO, session);
			}

		} catch (IOException e) {
			log.error(e.getMessage(), e);
			// 오류가 나더라도 통과
		}
	}

	@Override
	public List<PersonalSearchVO> selectPersonalSearch(HttpServletRequest request, UserCompanySessionVO userSession) {
		String originPath = request.getHeader("x-original-path");
		String userId = userSession.getMailId();

		PersonalSearchVO personalSearchVO = PersonalSearchVO.builder()
			.searchUrl(originPath)
			.userId(userId)
			.build();

		return personalSearchRepository.selectPersonalSearch(personalSearchVO);
	}

	public String getRequestParamsAsJson(HttpServletRequest request) throws IOException {
		Map<String, Object> paramMap = new HashMap<>();

		Map<String, String[]> parameters = request.getParameterMap();
		for (Map.Entry<String, String[]> entry : parameters.entrySet()) {
			String key = entry.getKey();
			String[] values = entry.getValue();

			// 값이 여러 개인 경우 배열로, 하나면 단일 값으로
			if (values.length == 1) {
				paramMap.put(key, values[0]);
			} else {
				paramMap.put(key, values);
			}
		}

		ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.writeValueAsString(paramMap);
	}

}
