package com.gsenc.wsf.common.model;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class PersonalSearchVO implements Serializable {

	private static final long serialVersionUID = 1L;

	@Schema(description = "검색 ID", example = "")
	private String searchId;

	@Schema(description = "검색 URL", example = "/system/code")
	private String searchUrl;

	@Schema(description = "검색 양식 ID", example = "formID")
	private String searchFormId;

	@Schema(description = "검색 쿼리")
	private String searchQuery;

	@Schema(description = "사용자 ID")
	private String userId;

}
