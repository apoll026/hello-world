package com.gsenc.wsf.common.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AddressSearchResponseVO {

	private Results results;

	@Getter
	@Setter
	@NoArgsConstructor
	@AllArgsConstructor
	@Builder
	public static class Results {
		private Common common;
		private List<Juso> juso;
	}

	@Getter
	@Setter
	@NoArgsConstructor
	@AllArgsConstructor
	@Builder
	public static class Common {
		/** 총 검색 데이터수 */
		private String totalCount;

		/** 페이지 번호 */
		private String currentPage;

		/** 페이지당 출력할 결과 Row 수 */
		private String countPerPage;

		/** 에러 코드 */
		private String errorCode;

		/** 에러 메시지 */
		private String errorMessage;
	}

	@Getter
	@Setter
	@NoArgsConstructor
	@AllArgsConstructor
	@Builder
	public static class Juso {
		/** 상세 건물명 목록 */
		private String detBdNmList;

		/** 도로명주소(영문) */
		private String engAddr;

		/** 도로명 */
		private String rn;

		/** 읍면동명 */
		private String emdNm;

		/** 우편번호 */
		private String zipNo;

		/** 도로명주소 참고항목 */
		private String roadAddrPart2;

		/** 읍면동일련번호 */
		private String emdNo;

		/** 시군구명 */
		private String sggNm;

		/** 지번주소 */
		private String jibunAddr;

		/** 시도명 */
		private String siNm;

		/** 도로명주소(참고항목 제외) */
		private String roadAddrPart1;

		/** 건물명 */
		private String bdNm;

		/** 행정구역코드 */
		private String admCd;

		/** 지하여부 (0:지상, 1:지하) */
		private String udrtYn;

		/** 지번본번(번지) */
		private String lnbrMnnm;

		/** 전체 도로명 주소 */
		private String roadAddr;

		/** 지번부번(호) */
		private String lnbrSlno;

		/** 건물본번 */
		private String buldMnnm;

		/** 공동주택여부(1:공동주택, 0:비공동주택) */
		private String bdKdcd;

		/** 리명 */
		private String liNm;

		/** 도로명코드 */
		private String rnMgtSn;

		/** 산여부 (0:대지, 1:산) */
		private String mtYn;

		/** 건물관리번호 */
		private String bdMgtSn;

		/** 건물부번 */
		private String buldSlno;
	}
}
