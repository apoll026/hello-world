package com.gsenc.wsf.common.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class AddressSearchRequestVO {
	/**
	 * 신청시 발급받은 승인키
	 * required
	 */
	private String confmKey;

	/**
	 * 현재 페이지 번호
	 * required
	 * default : 1
	 */
	private int currentPage = 1;

	/**
	 * 페이지당 출력할 결과 Row 수
	 * required
	 * default : 10
	 */
	private int countPerPage = 10;

	/**
	 * 주소 검색어
	 * required
	 */
	private String keyword;

	/**
	 * 검색결과형식 설정(xml, json)
	 * default : json
	 */
	private String resultType = "json";

	/**
	 * 변동된 주소정보 포함 여부
	 * default : N
	 */
	private String hstryYn;

	/**
	 * 정확도순 정렬(none), 우선정렬(road: 도로명 포함, location: 지번포함)
	 * keyword(검색어)가 우선정렬 항목에 포함된 결과 우선 표출
	 * default : none
	 */
	private String firstSort;

	/**
	 * 출력결과에 추가된 항목(hstryYn, relJibun, hemdNm) 제공여부
	 * 해동 옵션으로 추가 제공되는 항목의 경우, 추후 특정 항목이 제거되거나 추가될 수 있으니 적용시 고려
	 * default : N
	 */
	private String addInfoYn;

}
