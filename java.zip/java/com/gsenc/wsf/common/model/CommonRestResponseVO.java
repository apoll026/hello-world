package com.gsenc.wsf.common.model;

import lombok.*;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class CommonRestResponseVO {
    private String o_ret_code;
    private String o_ret_msg;
}
