package com.gsenc.wsf.common.model;

import java.lang.reflect.Method;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class SchedulerDefinition {
    private final Object bean;
    private final Method method;
    private final String name;
    private final String fallbackCron;
}
