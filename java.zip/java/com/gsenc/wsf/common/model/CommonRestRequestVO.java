package com.gsenc.wsf.common.model;

import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class CommonRestRequestVO<T> {
    private Class<T> clazz;
    private Object data;
    private T record;

}
