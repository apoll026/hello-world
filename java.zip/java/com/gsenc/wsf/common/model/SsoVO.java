package com.gsenc.wsf.common.model;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@Getter
@Builder
@ToString
public class SsoVO {
	private String uid;
	private String userId;
	private String empNo;
	private String userType;
	private String locale;
}
