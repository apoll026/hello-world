package com.gsenc.wsf.common.filter;

import java.io.*;

import jakarta.servlet.ReadListener;
import jakarta.servlet.ServletInputStream;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;

public class BufferedRequestWrapper extends HttpServletRequestWrapper {
	private final byte[] cachedBody;

	public BufferedRequestWrapper(HttpServletRequest request) throws IOException {
		super(request);
		try (InputStream inputStream = request.getInputStream();
			 ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
			byte[] buffer = new byte[1024];
			int bytesRead;
			while ((bytesRead = inputStream.read(buffer)) != -1) {
				outputStream.write(buffer, 0, bytesRead);
			}
			this.cachedBody = outputStream.toByteArray();
		}
	}

	@Override
	public ServletInputStream getInputStream() {
		return new CachedServletInputStream(new ByteArrayInputStream(cachedBody));
	}

	@Override
	public BufferedReader getReader() {
		return new BufferedReader(new InputStreamReader(getInputStream()));
	}

	private static class CachedServletInputStream extends ServletInputStream {
		private final ByteArrayInputStream inputStream;

		public CachedServletInputStream(ByteArrayInputStream inputStream) {
			this.inputStream = inputStream;
		}

		@Override
		public int read() {
			return inputStream.read();
		}

		@Override
		public boolean isFinished() {
			return inputStream.available() == 0;
		}

		@Override
		public boolean isReady() {
			return true;
		}

		@Override
		public void setReadListener(ReadListener listener) {
			throw new UnsupportedOperationException();
		}
	}
}
