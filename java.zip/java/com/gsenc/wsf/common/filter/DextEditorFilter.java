package com.gsenc.wsf.common.filter;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.dext5.DEXT5Handler;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.file.model.FileVO;
import com.gsenc.wsf.file.repository.FileRepository;
import com.gsenc.wsf.session.model.UserSessionVO;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Slf4j
@Configuration
public class DextEditorFilter implements Filter {
	@Value("${spring.profiles.active}")
	private String profile;
	@Value("${domain.be}")
	private String domain;
	private final FileRepository fileRepository;
	private final String FILE_SEPARATOR = FileSystems.getDefault().getSeparator();

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
		throws IOException, ServletException {
		UserSessionVO session = SessionScopeUtil.getContextSession();
		HttpServletRequest httpRequest = (HttpServletRequest)request;
		HttpServletResponse httpResponse = (HttpServletResponse)response;

		httpResponse.setHeader("Access-Control-Allow-Origin", "*");
		httpResponse.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
		httpResponse.setHeader("Access-Control-Allow-Headers", "*");

		httpRequest.setCharacterEncoding("UTF-8");

		if (!((HttpServletRequest)request).getRequestURI().equals("/api/aaa")) {
			log.error("DextEditorFilter: " + ((HttpServletRequest)request).getRequestURI());
			chain.doFilter(request, response);
			return;
		}

		String _allowFileExt = "gif, jpg, jpeg, png, bmp, wmv, asf, swf, avi, mpg, mpeg, mp4, txt, doc, docx, xls, xlsx, ppt, pptx, hwp, zip, pdf,flv";
		int upload_max_size = 2147483647;

		ServletContext application = httpRequest.getSession().getServletContext();

		DEXT5Handler DEXT5 = new DEXT5Handler();
		String realPath = "";
		String uuid = UUID.randomUUID().toString();
		String fileExtension = "";
		int lastDotIndex = DEXT5.GetOriginalFileName().lastIndexOf(".");
		if (lastDotIndex > 0) {
			fileExtension = DEXT5.GetOriginalFileName().substring(lastDotIndex);
		}
		// 파일명[fileId] 형식으로 저장
		String saveFileName =
			DEXT5.GetOriginalFileName().substring(0, lastDotIndex) + "[" + uuid + "]." + fileExtension;
		DEXT5.SetRealPath("/app");
		String[] allowUploadDirectoryPath = {};
		String tempPath = "/app/eas/fileupload/temp";
		if ("dev".equals(profile) || "prd".equals(profile)) {
			allowUploadDirectoryPath = new String[] {"/app"};
			realPath = "/app/eas/fileupload/editorfiles";

		} else if ("default".equals(profile)) {
			// 프로젝트 루트 디렉토리 경로 가져오기
			String projectRoot = System.getProperty("user.dir");
			String editorDataPath = projectRoot + FILE_SEPARATOR + "dext5editordata";
			tempPath = projectRoot + FILE_SEPARATOR + "temp";

			// 디렉토리가 존재하지 않으면 생성
			try {
				Path editorDir = Paths.get(editorDataPath);
				Path tempDir = Paths.get(tempPath);

				if (!Files.exists(editorDir)) {
					Files.createDirectories(editorDir);
					log.info("Created editor data directory: {}", editorDataPath);
				}

				if (!Files.exists(tempDir)) {
					Files.createDirectories(tempDir);
					log.info("Created temp directory: {}", tempPath);
				}
			} catch (IOException e) {
				log.error("Failed to create directories", e);
				throw new ServletException("Failed to create required directories", e);
			}

			allowUploadDirectoryPath = new String[] {editorDataPath};
			realPath = editorDataPath;

		} else {
			log.error("Unknown profile: {}", profile);
		}
		DEXT5.SetRealPath(realPath);
		DEXT5.SetSaveFileName(saveFileName);
		DEXT5.SetTempRealPath(tempPath);
		// 환경설정파일 물리적 폴더 (서버 환경변수를 사용할 경우)
		//DEXT5.SetConfigPhysicalPath("C:/dext5/config");

		//DEXT5.SetJpegQuality(100); // JPG 품질 (1 ~ 100)
		// (저품질, 용량 축소) 1 ~ 100 (고품질, 용량 증가) - jdk 1.5 이상에서만 사용가능합니다.
		//DEXT5.SetAntialiasing(true); // 이미지 안티앨리어싱 활성화

		// ***************보안 설정 : 업로드 가능한 경로 설정 - 이외의 경로로 업로드 불가능***************

		DEXT5.SetAllowUploadDirectoryPath(allowUploadDirectoryPath);
		// 업로드를 태운다 원래 업로드
		// grpId, fileId
		//

		String result = "";
		try {
			result = DEXT5.DEXTProcess(httpRequest, httpResponse, application, _allowFileExt, upload_max_size);
			//            result = realPath+FILE_SEPARATOR+saveFileName+DEXT5.GetFileExtension();
			//GrId만들고 FileId를 DB에 넣는다
			FileVO file = new FileVO();
			file.setAtchFileGrId("dext5editor");
			file.setAtchFileId(uuid);
			file.setAtchFileNm(DEXT5.GetOriginalFileName());
			file.setUseYn("Y");
			file.setAtchFileSaveNm(saveFileName);
			file.setAtchFileSavePathCtn(DEXT5.LastSaveFile());
			fileRepository.upsertFile("dext5editor", file, session);
			result = domain + "api/v1/file/dext5editorDownload?atchFileId=" + uuid;
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (DEXT5.IsImageUpload()) {
			/*
			// 동일 폴더에 이미지 썸네일 생성하기
			String strSourceFile = DEXT5.LastSaveFile();
			int rtn_value = DEXT5.ImageThumbnail(strSourceFile, "_thumb", 600, 0);
			if (rtn_value != 0) {
				String strLastError = DEXT5.LastErrorMessage();
			}
			*/

			/*
			// 동일 폴더에 이미지 썸네일 생성하기 (변경된 파일경로 리턴)
			String strSourceFile = DEXT5.LastSaveFile();
			String strChangedFile = DEXT5.ImageThumbnailEx(strSourceFile, "_thumb", 600, 0);
			if (strChangedFile.equals("")) {
				String strLastError = DEXT5.LastErrorMessage();
			}
			*/

			/*
			// 썸네일 파일 생성
			String strSourceFile = DEXT5.LastSaveFile();
			String strNewFileName = strSourceFile.replaceAll("\\\\image\\\\", "\\thumbnail\\");
			int rtn_value = DEXT5.GetImageThumbOrNewEx(strSourceFile, strNewFileName, 200, 0, 0);
			if (rtn_value != 0) {
				String strLastError = DEXT5.LastErrorMessage();
			}
			*/

			/*
			// 이미지 포멧 변경
			String strSourceFile = DEXT5.LastSaveFile();
			int rtn_value = DEXT5.ImageConvertFormat(strSourceFile, "png", 0);
			if (rtn_value != 0) {
				String strLastError = DEXT5.LastErrorMessage();
			}
			*/

			/*
			// 이미지 포멧 변경 (변경된 파일경로 리턴)
			String strSourceFile = DEXT5.LastSaveFile();
			String strChangedFile = DEXT5.ImageConvertFormatEx(strSourceFile, "jpg", 0);
			if (strChangedFile.equals("")) {
				String strLastError = DEXT5.LastErrorMessage();
			}
			*/

			/*
			// 이미지 크기 변환
			String strSourceFile = DEXT5.LastSaveFile();
			int rtn_value = DEXT5.ImageConvertSize(strSourceFile, 500, 30);
			if (rtn_value != 0) {
				String strLastError = DEXT5.LastErrorMessage();
			}
			*/

			/*
			// 비율로 이미지 크기 변환
			String strSourceFile = DEXT5.LastSaveFile();
			int rtn_value = DEXT5.ImageConvertSizeByPercent(strSourceFile, 50);
			if (rtn_value != 0) {
				String strLastError = DEXT5.LastErrorMessage();
			}
			*/

			/*
			// 비율로 이미지 크기 변환
			String strSourceFile = DEXT5.LastSaveFile();
			int rtn_value = DEXT5.ImageConvertSizeByPercent(strSourceFile, 50);
			if (rtn_value != 0) {
				String strLastError = DEXT5.LastErrorMessage();
			}
			*/

			/*
			// 이미지 회전
			String strSourceFile = DEXT5.LastSaveFile();
			int rtn_value = DEXT5.ImageRotate(strSourceFile, 90);
			if (rtn_value != 0) {
				String strLastError = DEXT5.LastErrorMessage();
			}
			*/

			/*
			// 이미지 워터마크
			String strSourceFile = DEXT5.LastSaveFile();
			String strWaterMarkFile = "C:\\Temp\\watermark.jpg";
			int rtn_value = DEXT5.ImageWaterMark(strSourceFile, strWaterMarkFile, "TOP", 10, "RIGHT", 10, 0);
			if (rtn_value != 0) {
				String strLastError = DEXT5.LastErrorMessage();
			}
			*/

			/*
			// 텍스트 워터마크
			String strSourceFile = DEXT5.LastSaveFile();
			DEXT5.SetFontInfo("굴림", 50, "FF00FF");
			int rtn_value = DEXT5.TextWaterMark(strSourceFile, "DEXT5", "TOP", 10, "CENTER", 10, 0, 45);
			if (rtn_value != 0) {
				String strLastError = DEXT5.LastErrorMessage();
			}
			*/

	        /*
			// 다른 파일명.확장자
			String strSourceFile = DEXT5.LastSaveFile();
	        String rtn_value = DEXT5.GetNewFileNameEx("jpg", "TIME");
			if (rtn_value.equals("")) {
				String strLastError = DEXT5.LastErrorMessage();
			}
	        */

	        /*
	        // 이미지 가로(Width) 크기
	        String strSourceFile = DEXT5.LastSaveFile();
	        int rtn_value = DEXT5.GetImageWidth(strSourceFile);
	        if (rtn_value <= 0) {
	            String strLastError = DEXT5.LastErrorMessage();
	        }
	        */

			/*
			// 이미지 세로(Height) 크기
			String strSourceFile = DEXT5.LastSaveFile();
			int rtn_value = DEXT5.GetImageHeight(strSourceFile);
			if (rtn_value <= 0) {
				String strLastError = DEXT5.LastErrorMessage();
			}
			*/

			/*
			// 이미지 Format 정보
			String strSourceFile = DEXT5.LastSaveFile();
			String rtn_value = DEXT5.GetImageFormat(strSourceFile);
			if (rtn_value == "") {
				String strLastError = DEXT5.LastErrorMessage();
			}
			*/

			/*
			// 이미지 파일 크기
			String strSourceFile = DEXT5.LastSaveFile();
			long rtn_value = DEXT5.GetImageFileSize(strSourceFile);
			if (rtn_value <= 0) {
				String strLastError = DEXT5.LastErrorMessage();
			}
			*/

			/*
			// 파일 삭제
			String strSourceFile = DEXT5.LastSaveFile();
			int rtn_value = DEXT5.DeleteFile(strSourceFile);
			if (rtn_value != 0) {
				String strLastError = DEXT5.LastErrorMessage();
			}
			*/

			/*
			// 원본 파일명 가져오기
			String strOriginalFileName = DEXT5.OriginalFileName();
			*/
		}

		// 파일 저장 경로 (물리적 경로)
		//if(DEXT5.LastSaveFile().length() > 0) {
		//	System.out.println("save file : [" + DEXT5.LastSaveFile() + "]");
		//}

		// 파일 저장 경로 (WEB URL)
		//if(DEXT5.LastSaveUrl().length() > 0) {
		//System.out.println("save url : [" + DEXT5.LastSaveUrl() + "]");
		//}

		// 에러 Message
		//if(DEXT5.LastErrorMessage().length() > 0) {
		//	System.out.println("DEXT5 Handler Error : [" + DEXT5.LastErrorMessage() + "]");
		//}

		if (!result.equals("")) {
			response.setContentType("text/html");
			ServletOutputStream out = response.getOutputStream();
			out.print(result);
			out.close();
		}

		// 서버모듈 동작 후 이후 종료
		return;
	}
}
