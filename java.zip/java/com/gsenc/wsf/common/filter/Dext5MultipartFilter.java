package com.gsenc.wsf.common.filter;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.gsenc.wsf.common.config.ConditionalMultipartResolver;
import com.gsenc.wsf.common.wrapper.CachedBodyHttpServletRequest;

import dextuploadjk.support.spring.JKMultipartResolver;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@Order(-100)
public class Dext5MultipartFilter implements Filter {

    @Autowired
    private ConditionalMultipartResolver conditionalMultipartResolver;

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
                        FilterChain chain) throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;

        // 모든 multipart 요청을 CachedBodyHttpServletRequest로 감싸기
        if (isMultipartRequest(httpRequest)) {
            try {
                // Request body를 캐싱할 수 있는 wrapper로 감싸기
//                CachedBodyHttpServletRequest wrappedRequest = new CachedBodyHttpServletRequest(httpRequest);
              //  BufferedRequestWrapper wrappedRequest = new BufferedRequestWrapper(httpRequest);

                // dext5 업로드 URL인 경우 JK resolver 사용
                if (httpRequest.getRequestURI().contains("/v1/dextfile/upload")) {
                    JKMultipartResolver dext5Resolver = conditionalMultipartResolver.getDext5Resolver();

                    if (dext5Resolver.isMultipart(httpRequest)) {
                        log.info("Dext5 multipart request detected, using JK resolver");
                        MultipartHttpServletRequest multipartRequest =
                            dext5Resolver.resolveMultipart(httpRequest);

                        // JK resolver로 처리된 multipart request를 전달
                        chain.doFilter(multipartRequest, response);
                        return;
                    }
                }

                // 다른 multipart 요청들은 wrapped request로 전달 (Spring이 자동 처리)
                log.debug("Standard multipart request for: {}", httpRequest.getRequestURI());
                chain.doFilter(httpRequest, response);
                return;

            } catch (Exception e) {
                log.error("Multipart request wrapping error for {}: {}", httpRequest.getRequestURI(), e.getMessage(), e);
                // 에러 발생 시 원본 request로 처리
            }
        }

        // multipart가 아닌 요청들은 원본 request 그대로 전달
        chain.doFilter(request, response);
    }

    private boolean isMultipartRequest(HttpServletRequest request) {
        String contentType = request.getContentType();
        return contentType != null && contentType.toLowerCase().startsWith("multipart/");
    }
}
