package com.gsenc.wsf.common.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.common.model.PersonalSearchVO;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface PersonalSearchRepository {
	void insertPersonalSearch(@Param("personalSearch") PersonalSearchVO personalSearchVO,
							  @Param("session") UserSessionVO session);

	List<PersonalSearchVO> selectPersonalSearch(PersonalSearchVO personalSearchVO);
}
