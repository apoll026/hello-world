package com.gsenc.wsf.common.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.AddressSearchRequestVO;
import com.gsenc.wsf.common.model.AddressSearchResponseVO;
import com.gsenc.wsf.common.model.CommonResponseVO;
import com.gsenc.wsf.common.util.HttpConnectionUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@Tag(name = "ADDRESS")
@RequiredArgsConstructor
@RequestMapping("/api")
@Slf4j
public class AddressSearchController {

	private static final String CONFIRM_KEY = "devU01TX0FVVEgyMDI1MDYxNzA5MTEzMzExNTg1MDg=";
	private static final String JUSO_URL = "https://business.juso.go.kr/addrlink";

	@Operation(summary = "searchTest")
	@GetMapping("/v1/address-search")
	public ResponseEntity<CommonResponseVO<AddressSearchResponseVO>> addressSearch(
		@ModelAttribute AddressSearchRequestVO addressSearchRequestVO
	) {
		AddressSearchRequestVO data = addressSearchRequestVO.toBuilder()
			.confmKey(CONFIRM_KEY)
			.build();

		AddressSearchResponseVO result = HttpConnectionUtil.restRequestToVO(
			"GET",
			JUSO_URL + "/addrLinkApiJsonp.do",
			data,
			AddressSearchResponseVO.class,
			null
		);
		return new ResponseEntity<>(CommonResponseVO.<AddressSearchResponseVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(result)
			.build(), HttpStatus.OK);
	}
}
