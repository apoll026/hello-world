package com.gsenc.wsf.common.constant;

public class LogConstants {
    public static final String RFC = "RFC";

}
