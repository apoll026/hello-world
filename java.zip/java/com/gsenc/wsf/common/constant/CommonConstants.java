package com.gsenc.wsf.common.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class CommonConstants {
	public static final String HTTP_SESSION_KEY = "USER_SESSION";
	public static final String CERT_NUMBER = "CERT_NUMBER";
	public static final String YES_FLAG = "Y";
	public static final String NO_FLAG = "N";
}
