package com.gsenc.wsf.common.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class SsoConstants {
	public static final String S_NAME = "GSENC_SSOTOKEN";
	public static final String DOMAIN = "deveas.gsenc.com";

	// 인증 결과 상수
	/**
	 * 인증 성공 (세션 또는 SSO 인증 성공)
	 */
	public static final String AUTH_SUCCESS = "SUCCESS";

	/**
	 * SSO 토큰이 없거나 유효하지 않음 - SSO 인증 페이지로 리다이렉트 필요
	 */
	public static final String AUTH_SSO_FAILED = "SSO_AUTHENTICATION_FAILED";

	/**
	 * SSO 인증은 성공했으나 사이트 내 권한이 없음 - 권한 없음 페이지로 리다이렉트 필요
	 */
	public static final String AUTH_AUTHORIZATION_FAILED = "AUTHORIZATION_FAILED";
}
