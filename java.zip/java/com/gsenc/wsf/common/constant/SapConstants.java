package com.gsenc.wsf.common.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class SapConstants {

	// SAP TEST SERVER SETTING
	/*public static final String SAPTEST_JCO_TESTASHOST = "10.156.0.57";
	public static final String SAPTEST_JCO_TESTSYSNR = "10";
	public static final String SAPTEST_JCO_TESTCLIENT = "300";
	public static final String SAPTEST_JCO_TESTUSER = "UASIF01";
	public static final String SAPTEST_JCO_TESTPASSWD = "LGCNS001";
	public static final String SAPTEST_JCO_TESTLANG = "ko";*/

	public static final String SAPTEST_JCO_TESTASHOST = "10.142.2.38";
	public static final String SAPTEST_JCO_TESTSYSNR = "00";
	public static final String SAPTEST_JCO_TESTCLIENT = "100";
	public static final String SAPTEST_JCO_TESTUSER = "UASIF01";
	public static final String SAPTEST_JCO_TESTPASSWD = "Gsencsappce001*";
	public static final String SAPTEST_JCO_TESTLANG = "ko";

	// SAP REAL SERVER SETTING
	public static final String SAP_JCO_ASHOST = "10.142.2.38";
	public static final String SAP_JCO_SYSNR = "00";
	public static final String SAP_JCO_CLIENT = "100";
	public static final String SAP_JCO_USER = "UASIF01";
	public static final String SAP_JCO_PASSWD = "LGCNS0011";
	public static final String SAP_JCO_LANG = "ko";

}
