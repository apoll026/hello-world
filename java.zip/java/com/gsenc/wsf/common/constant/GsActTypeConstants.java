package com.gsenc.wsf.common.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class GsActTypeConstants {
	public static final String RE = "RE";   // 조회(Read)
	public static final String LI = "LI";   // 화면별 로그인(Login)
	public static final String LO = "LO";   // 화면별 로그아웃(Logout)
	public static final String EX = "EX";   // 엑셀다운(Excel Download)
	public static final String PT = "PT";   // 출력(Print)
	public static final String AP = "AP";   // 승인(Approve)
	public static final String ET = "ET";   // 기타(Etc)
	public static final String WR = "WR";   // 저장(Write)
}
