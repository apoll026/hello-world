package com.gsenc.wsf.common.exception;

import java.util.Map;

// 전표 작업 때문에 추가한 Exception 으로 throw 시에 메시지 및 Map 데이터 JSON 으로 출력
public class GsEncException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    private final String statusCode;
    private final Map<String, Object> addData;

    public GsEncException(String message, String statusCode, Map<String, Object> addData) {
        super(message);
        this.statusCode = statusCode;
        this.addData = addData;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public Map<String, Object> getAddData() {
        return addData;
    }
}
