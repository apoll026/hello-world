package com.gsenc.wsf.common.config;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import jakarta.servlet.DispatcherType;
import ssc.fundamental.SscStartUp;
import ssc.service.session.SscHttpFilter;
import ssc.service.session.SscListener;
import ssc.service.session.SscServlet;

@Configuration
@Profile("prd")
public class SscConfig {

	@Bean
	public FilterRegistrationBean sscFilterRegistration() {
		FilterRegistrationBean filterReg = new FilterRegistrationBean(new SscHttpFilter());
		filterReg.addUrlPatterns("*");
		filterReg.setDispatcherTypes(DispatcherType.REQUEST);
		filterReg.setName("SscFilter");
		return filterReg;
	}

	@Bean
	public ServletRegistrationBean sscServlet() {
		ServletRegistrationBean registrationBean = new ServletRegistrationBean(new SscServlet());
		registrationBean.addUrlMappings("/SscServlet");
		Map<String, String> initParameters = new HashMap<>();
		initParameters.put("enabledForExtensions", "true");
		registrationBean.setInitParameters(initParameters);
		registrationBean.setLoadOnStartup(1);
		return registrationBean;
	}

	@Bean
	public SscListener sscListener() {
		return new SscListener();
	}

	@Bean
	public SscStartUp sscStartUp() {
		return new SscStartUp();
	}

}
