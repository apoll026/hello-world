package com.gsenc.wsf.common.config;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gsenc.wsf.common.filter.DextEditorFilter;
import com.gsenc.wsf.common.filter.XssReplaceFilter;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
@RequiredArgsConstructor
public class FilterConfig implements WebMvcConfigurer {

	private final ObjectMapper objectMapper;

	@Value("${filter.xss-block.exclude-paths}")
	private final String[] xssBlockExcludePaths;

	@Value("${filter.xss-replace.exclude-paths}")
	private final String[] xssReplaceExcludePaths;

	/**
	 * XssReplaceFilter 설명
	 * XSS 에 해당하는 문자 ( <, >, \, & 등등)가 포함되어있으면 해당 문자를 Replace(escape) 합니다.
	 * 문자 Replace(escape)는 HtmlCharacterEscapes 클래스를 사용합니다.
	 * - replace(escape)된 데이터를 다시 조회 할때 아래 조치를 취할 수 있습니다.
	 * 예시 ) 제목, 성명 등 XSS 문자열을 허용하지 않은 경우는 replace(escape)된 데이터를 그대로 보여줍니다.
	 * FE에서 보여주는 방법에 따라 &lt; , < 로 보임.
	 * 예시 ) 웹에디터를 통한 입력일 경우
	 * html 요소를 화면에 끼워넣기 위한 목적으로 입력한 것이므로 replace(escape) 된 데이터를 unescape 해서 FE에 보내야 합니다.
	 * BE Code Sample :
	 * bbs.setBbmCtn(ValidateUtil.charUnescape(bbs.getBbmCtn()));
	 * <p>
	 * 따라서 FE에서는 XSS 공격 코드가 포함된 결과를 받아보게 되는데
	 * 이를 차단하기 위해 dompurify.sanitize 를 이용해 XSS공격을 위한 패턴을 제거 해야 합니다.
	 * FE Code Sample :
	 * import DOMPurify from 'dompurify';
	 * dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(post?.bbmCtn + '') }}
	 */
	@Bean
	public FilterRegistrationBean<XssReplaceFilter> xssReplaceFilter() {

		// 필터적용을 제외할 Path Pattern
		String[] excludePaths = {
			"/api/auth/**",
			"/api/swagger-ui/**",
			"/api/v1/health/**", "/error", "/api/v1/sso/**",
			"/api/v3/api-docs/**",
			"/soap/**",
			"/api/v1/session/langCd",
			"/api/v1/translated-messages",
			"/file/**", "/v1/file/mbdownload",
			"/api/v1/dept-batch", "/api/v1/emp-batch",
			"/api/v1/sso-auth", "/api/v1/collect-delegation",
			"/v1/mailBatch",
			"/v1/translated-messages/deploy-all",
			"/api/v1/session/langCd",
			"/api/v1/translated-messages",
			"/api/v1/menu/**",
			"/api/v1/admin/menu-log"
			, "/api/v1/verify/**"
			, "/api/v1/Down2Excel/**", "/api/cfs/view/**"
		};

		String[] totalExcludePaths = this.concatenateStringArrays(excludePaths, xssReplaceExcludePaths);
		XssReplaceFilter xssReplaceFilter = new XssReplaceFilter(totalExcludePaths, objectMapper);

		FilterRegistrationBean<XssReplaceFilter> registrationBean = new FilterRegistrationBean<>();
		registrationBean.setFilter(xssReplaceFilter);
		registrationBean.addUrlPatterns("/NOT-YET/**");
		registrationBean.setOrder(1);
		registrationBean.setName("xssReplaceFilter");
		return registrationBean;
	}

	@Bean
	public FilterRegistrationBean<DextEditorFilter> dext5EditorFilter(DextEditorFilter dextEditorFilter) {
		FilterRegistrationBean<DextEditorFilter> registration = new FilterRegistrationBean<>();
		registration.setFilter(dextEditorFilter);
		// URL 패턴 설정
		registration.addUrlPatterns("/api/aaa");
		// 필터 실행 순서 (높은 우선순위 필수)
		registration.setOrder(0);
		return registration;
	}

	private String[] concatenateStringArrays(String[] ary1, String[] ary2) {
		if (ary1 == null || ary1.length == 0)
			return ary2;
		if (ary2 == null || ary2.length == 0)
			return ary1;

		String[] rtnAry = new String[ary1.length + ary2.length];
		System.arraycopy(ary1, 0, rtnAry, 0, ary1.length);
		System.arraycopy(ary2, 0, rtnAry, ary1.length, ary2.length);

		return rtnAry;
	}
}
