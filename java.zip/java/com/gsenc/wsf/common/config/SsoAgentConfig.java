// 20250219 서용태
// 클래스 전체 주석처리 (OSS 오픈소스 라이선스 점검, sso.saml-springboot3-1.0.0.jar 제거)


/*
package com.lginnotek.wsf.common.config;


@Configuration
public class SsoAgentConfig {
    @Value("${spring.config.activate.on-profile}")
    private String profile;

    @Value("${domain.fe}")
    private String DOMAIN_FE;

    @Bean
    public ServletRegistrationBean<AssertionConsumerService> acsServlet() throws IOException {
        ServletRegistrationBean<AssertionConsumerService> bean =
                new ServletRegistrationBean<>(new AssertionConsumerService(), "/acs");

        bean.setLoadOnStartup(3);

        String configFilePath = "";

        if ("default".equals(profile)) {
            configFilePath = "src/main/resources/sso/configuration_default.properties";
        } else {
            configFilePath = "/app/resources/sso/configuration_"+profile+".properties";
        }

        bean.addInitParameter("configFilePath", configFilePath);
        bean.addInitParameter("localEntityId", DOMAIN_FE);
        bean.addInitParameter("NexessErrorPage", "nls4/error.jsp");
        bean.addInitParameter("SesssionCreatePage", "api/v1/sso/login");
        bean.addInitParameter("isSign", "true");
        bean.addInitParameter("defaultRelayState ", DOMAIN_FE);

        return bean;
    }


}
*/
