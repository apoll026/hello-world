package com.gsenc.wsf.common.config;

import java.io.IOException;
import java.net.URISyntaxException;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.support.StandardServletMultipartResolver;

import dextuploadjk.engine.Environment;
import dextuploadjk.support.spring.JKMultipartResolver;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class DextUploadConfig {
	@Value("${spring.config.activate.on-profile}")
	private String profile;

	@Value("${dextupload.tempRepository}")
	private String tempRepository;

	@Value("${dextupload.defaultRepository}")
	private String defaultRepository;

	@Value("${dextupload.autoMakingDirectory:true}")
	private boolean autoMakingDirectory;

	@Value("${dextupload.maxFileSize:0}")
	private long maxFileSize;

	@Value("${dextupload.maxTotalSize:0}")
	private long maxTotalSize;

	@Value("${dextupload.whiteExtensions:}")
	private String whiteExtensions;

	@Value("${dextupload.enableCleaner:true}")
	private boolean enableCleaner;

	@Value("${dextupload.timeAgo:24}")
	private int timeAgo;

	@Value("${dextupload.checksumEnable:false}")
	private boolean checksumEnable;

	@Value("${dextupload.licenseFilePath}")
	private String licenseFilePath;

	@Bean
	public Environment dextEnvironment() throws URISyntaxException, IOException {
		Environment environment = new Environment();

		// Set configuration from config.yml
		environment.setTempRepository(tempRepository);
		environment.setDefaultRepository(defaultRepository);
		environment.setAutoMakingDirectory(autoMakingDirectory);

		if (maxFileSize > 0) {
			environment.setMaxFileSize(maxFileSize);
		}

		if (maxTotalSize > 0) {
			environment.setMaxTotalSize(maxTotalSize);
		}

		if (!whiteExtensions.isEmpty()) {
			environment.setWhiteExtensions(whiteExtensions);
		}

		environment.setEnableCleaner(enableCleaner);
		environment.setTimeAgo(timeAgo);
		environment.setChecksumEnable(checksumEnable);
		if ("default".equals(profile)) {
			environment.setLicenseFilePath(licenseFilePath);
		} else {
			environment.setLicenseAuthKey(
				"V5w/VtPS9P9xbCwKuUnpBqsZTefX3KEBbIEoYuitQNLqL4VZxNTxIwBjFFXHe4Ua6U6KAR66FfrQuQRCLpCs0QL8zUZW6TjWKpNtsYsU2isp8EnySNtIAJ/EbeYxLAsw"
			);
			//environment.setLicenseFilePath(licenseFilePath);
		}
		return environment;
	}

	@Bean
	public StandardServletMultipartResolver standardMultipartResolver() {
		return new StandardServletMultipartResolver();
	}

	@Bean
	@Qualifier("dext5uploader")
	public JKMultipartResolver dext5MultipartResolver(Environment dextEnvironment) {
		JKMultipartResolver resolver = new JKMultipartResolver();
		resolver.setEnvironment(dextEnvironment);
		return resolver;
	}
}
