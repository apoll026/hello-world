package com.gsenc.wsf.common.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.support.StandardServletMultipartResolver;

import dextuploadjk.support.spring.JKMultipartResolver;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component("multipartResolver")
public class ConditionalMultipartResolver implements MultipartResolver {

    @Autowired
    private StandardServletMultipartResolver standardMultipartResolver;

    @Autowired
    @Qualifier("dext5uploader")
    private JKMultipartResolver dext5MultipartResolver;

    @Override
    public boolean isMultipart(HttpServletRequest request) {
        // dext5 업로드 URL인 경우 false 반환하여 자동 처리 방지
        if (request.getRequestURI().contains("/v1/dextfile/upload")) {
            log.debug("Dext5 URL detected, skipping automatic multipart processing");
            return false; // 자동 처리 비활성화
        }
        return standardMultipartResolver.isMultipart(request);
    }

    @Override
    public MultipartHttpServletRequest resolveMultipart(HttpServletRequest request) {
        // 여기는 dext5 URL이 아닌 경우만 호출됨
        log.debug("Using standard multipart resolver for: {}", request.getRequestURI());
        return standardMultipartResolver.resolveMultipart(request);
    }

    @Override
    public void cleanupMultipart(MultipartHttpServletRequest request) {
        if (request.getRequestURI().contains("/v1/dextfile/upload")) {
            dext5MultipartResolver.cleanupMultipart(request);
        } else {
            standardMultipartResolver.cleanupMultipart(request);
        }
    }

    // Dext5 resolver에 접근할 수 있는 메서드 추가
    public JKMultipartResolver getDext5Resolver() {
        return dext5MultipartResolver;
    }
}
