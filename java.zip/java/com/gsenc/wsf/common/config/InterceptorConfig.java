package com.gsenc.wsf.common.config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.gsenc.wsf.common.interceptor.AuthenticationInterceptor;
import com.gsenc.wsf.common.interceptor.LocaleInterceptor;
import com.gsenc.wsf.common.interceptor.PersonalSearchInterceptor;
import com.gsenc.wsf.common.interceptor.SsoInterceptor;

import lombok.RequiredArgsConstructor;

@Configuration
@EnableWebMvc
@RequiredArgsConstructor
public class InterceptorConfig implements WebMvcConfigurer {

	private final AuthenticationInterceptor authInterceptor;
	private final SsoInterceptor ssoInterceptor;
	private final PersonalSearchInterceptor personalSearchInterceptor;

	@Value("${interceptor.auth.exclude-paths}")
	private final String[] authExcludePaths;

	@Value("${spring.config.activate.on-profile}")
	private String profile;

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		List<String> urlPatterns = Arrays.asList("/**");
		List<String> excludePatterns = this.getAuthExcludePaths();

		registry.addInterceptor(ssoInterceptor)
			.addPathPatterns(urlPatterns)
			.excludePathPatterns(excludePatterns)
			.order(1);

		registry.addInterceptor(authInterceptor)
			.addPathPatterns(urlPatterns)
			.excludePathPatterns(excludePatterns)
			.order(2);

		registry.addInterceptor(personalSearchInterceptor)
			.addPathPatterns(urlPatterns)
			.excludePathPatterns(excludePatterns)
			.order(3);

		LocaleInterceptor localeInterceptor = new LocaleInterceptor();
		localeInterceptor.setParamName("langCd");
		registry.addInterceptor(localeInterceptor);
	}

	private List<String> getAuthExcludePaths() {
		List<String> excludePatterns = new ArrayList<>(Arrays.asList(
			"/api/v1/session/redirect-url",
			"/api/auth/**",
			"/api/swagger-ui/**",
			"/api/v1/health/**",
			"/error",
			"/api/v1/sso/**",
			"/api/v3/api-docs/**",
			"/soap/**",
			"/api/v1/session/langCd",
			"/api/v1/translated-messages",
			"/file/**",
			"/v1/file/mbdownload",
			"/api/v1/dept-batch",
			"/api/v1/emp-batch",
			"/api/v1/sso-auth",
			"/api/v1/collect-delegation",
			"/v1/mailBatch",
			"/v1/translated-messages/deploy-all",
			"/api/ep/em/comm/file/upload",
			"/api/v1/dextfile/upload",
			"/api/v1/files/dext5editor-upload",
			// TODO : 샘플 이후 실제 구현시 exclude 해제 필요
			"/api/v1/address-search",
			"/api/v1/verify/**",
			"/api/v1/Down2Excel/**",
			"/api/v1/company-verify",
			"/api/v1/dev/outlogin"
			//"/api/cfs/view/**"
			//, "/resources/**"
		));

		if ("default".equals(profile)) {
			excludePatterns.add("/api/swagger-ui/*");
		}

		excludePatterns.addAll(Arrays.asList(authExcludePaths));
		return excludePatterns;
	}

}
