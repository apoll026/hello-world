package com.gsenc.wsf.common.sap;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.gsenc.wsf.common.constant.SapConstants;
import com.sap.conn.jco.JCoContext;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoField;
import com.sap.conn.jco.JCoFieldIterator;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoRecordField;
import com.sap.conn.jco.JCoRecordFieldIterator;
import com.sap.conn.jco.JCoRepository;
import com.sap.conn.jco.JCoTable;
import com.sap.conn.jco.ext.DestinationDataProvider;

public class SAPConnection {
	static String SAP_SERVER = "SAP_SERVER";
	private JCoRepository repos;
	private JCoDestination dest;
	private Properties properties;
	private JCoFunction function;

	public void setSAPConnection() {
		String active = System.getProperty("spring.profiles.active");
		if (active == null) {
			active = "dev";
		} else
		    active = "dev";

		properties = new Properties();
		if ("prd".equals(active)) {
			properties.setProperty(DestinationDataProvider.JCO_ASHOST, SapConstants.SAP_JCO_ASHOST);
			properties.setProperty(DestinationDataProvider.JCO_SYSNR, SapConstants.SAP_JCO_SYSNR);
			properties.setProperty(DestinationDataProvider.JCO_CLIENT, SapConstants.SAP_JCO_CLIENT);
			properties.setProperty(DestinationDataProvider.JCO_USER, SapConstants.SAP_JCO_USER);
			properties.setProperty(DestinationDataProvider.JCO_PASSWD, SapConstants.SAP_JCO_PASSWD);
			properties.setProperty(DestinationDataProvider.JCO_LANG, SapConstants.SAP_JCO_LANG);

		} else {
			properties.setProperty(DestinationDataProvider.JCO_ASHOST, SapConstants.SAPTEST_JCO_TESTASHOST);
			properties.setProperty(DestinationDataProvider.JCO_SYSNR, SapConstants.SAPTEST_JCO_TESTSYSNR);
			properties.setProperty(DestinationDataProvider.JCO_CLIENT, SapConstants.SAPTEST_JCO_TESTCLIENT);
			properties.setProperty(DestinationDataProvider.JCO_USER, SapConstants.SAPTEST_JCO_TESTUSER);
			properties.setProperty(DestinationDataProvider.JCO_PASSWD, SapConstants.SAPTEST_JCO_TESTPASSWD);
			properties.setProperty(DestinationDataProvider.JCO_LANG, SapConstants.SAPTEST_JCO_TESTLANG);
		}

		DestinationDataProviderImp dastImp = new DestinationDataProviderImp();
		if (!com.sap.conn.jco.ext.Environment.isDestinationDataProviderRegistered()) {
			com.sap.conn.jco.ext.Environment.registerDestinationDataProvider(dastImp);
		}

		dastImp.changePropertiesForABAP_AS(properties);
		try {
			dest = JCoDestinationManager.getDestination(SAP_SERVER);
			repos = dest.getRepository();

		} catch (Exception e) {
			throw new RuntimeException(e);
		}

	}

	public JCoFunction getFunction(String functionStr) {

		try {
			function = repos.getFunction(functionStr);
		} catch (Exception e) {
			throw new RuntimeException("Problem retrieving JCO.Function object.");
		}
		if (function == null) {
			throw new RuntimeException("Not possible to receive function. ");
		}
		return function;
	}

	public void execute(JCoFunction function) {
		try {
			JCoContext.begin(dest);
			function.execute(dest);
			JCoContext.end(dest);
		} catch (Exception e) {

			try {
				JCoContext.end(dest);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
			}
		}
	}

	public List<String> getExportParameterList() {
		List<String> paramList = new ArrayList<String>();
		JCoParameterList exportLit = function.getExportParameterList();
		JCoFieldIterator it = exportLit.getFieldIterator();
		while (it.hasNextField()) {
			JCoField field = it.nextField();
			paramList.add(field.getName());
			//System.out.println("getExportParameterList:::"+field.getName());
		}
		return paramList;
	}

	public List<String> getImportParameterList() {
		List<String> paramList = new ArrayList<String>();
		JCoParameterList parmList = function.getImportParameterList();
		JCoFieldIterator it = parmList.getFieldIterator();
		while (it.hasNextField()) {
			JCoField field = it.nextField();
			paramList.add(field.getName());
			//System.out.println("getImportParameterList:::"+field.getName());
		}
		return paramList;
	}

	public List<String> getTableParameterList() {
		List<String> paramList = new ArrayList<String>();
		JCoParameterList parmList = function.getTableParameterList();
		JCoFieldIterator it = parmList.getFieldIterator();
		while (it.hasNextField()) {
			JCoField field = it.nextField();
			paramList.add(field.getName());
			//System.out.println("getTableParameterList:::"+field.getName());
		}
		return paramList;
	}

	public List<String> getTableParameterList(String tableName) {
		List<String> paramList = new ArrayList<String>();
		JCoTable resulttable = function.getTableParameterList().getTable(tableName);
		JCoRecordFieldIterator it = resulttable.getRecordFieldIterator();
		while (it.hasNextField()) {
			JCoRecordField field = it.nextRecordField();
			paramList.add(field.getName());
			//System.out.println("getTableParameterList:::"+field.getName());
		}
		return paramList;
	}
}
