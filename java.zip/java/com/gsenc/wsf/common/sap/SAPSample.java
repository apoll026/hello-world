package com.gsenc.wsf.common.sap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequiredArgsConstructor
@Tag(name = "SAP")
@Validated
@Slf4j
@RequestMapping("/api")
public class SAPSample {

	/**
	 * As-Is와 동일한 Sample 구현
	 */

	@Operation(summary = "sapTest")
	@GetMapping(value = "/v1/sapTest", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO> sapTest() {
		try {
			testSAPSerarch();    // SAP 연결해서 검색하는 샘플 소스
			testSAPRecevie();    // SAP 연결해서 전송하는 샘플소스
			testSapDelete();    // SAP 연결해서 삭제하는 샘플소스

			return ResponseEntity.ok(CommonResponseVO.builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(null)
				.build());

		} catch (Exception e) {
			log.error("Error during snmipTest: ", e);
			return ResponseEntity.internalServerError().body(CommonResponseVO.builder()
				.successOrNot(CommonConstants.NO_FLAG)
				.statusCode(StatusCodeConstants.FAIL)
				.data(e.getMessage())
				.build());
		}
	}

	// SAP 연결해서 검색하는 샘플소스
	public static void testSAPSerarch() {
		ArrayList<String> asstNumArray = new ArrayList<String>();

		asstNumArray.add("PEA010100159");
		asstNumArray.add("ABD010201566");
		asstNumArray.add("AADAAXH00188");

		SAPInterFaceClass sapInf = new SAPInterFaceClass();
		ArrayList<HashMap<String, Object>> result = sapInf.searchAsset("20220705", asstNumArray);
		for (HashMap<String, Object> rowInfo : result) {
			for (String key : rowInfo.keySet()) {
				System.out.printf("key: %s , value: %s \n", key, rowInfo.get(key));
			}
		}

	}

	// SAP 연결해서 전송하는 샘플소스
	public static void testSAPRecevie() {
		SAPInterFaceClass sapInf = new SAPInterFaceClass();
		ArrayList<HashMap<String, Object>> inputValue = new ArrayList<HashMap<String, Object>>();
		for (int i = 1; i < 4; i++) {
			HashMap<String, Object> rowInfo = new HashMap<String, Object>();
			rowInfo.put("ASST_NUM", "PEA01010016" + String.valueOf(i));
			rowInfo.put("ITEM_CODE", String.valueOf(i));
			rowInfo.put("ASST_FULL_NAME", String.valueOf(i));
			rowInfo.put("MNGR_EMPNO", String.valueOf(i));
			rowInfo.put("ACQU_DATE", String.valueOf(i));
			rowInfo.put("DURA_YEAR", String.valueOf(i));
			rowInfo.put("DEPR_RULE", String.valueOf(i));
			rowInfo.put("CAR_NUM", String.valueOf(i));
			rowInfo.put("LOT_NUM", String.valueOf(i));
			rowInfo.put("AREA", String.valueOf(i));
			rowInfo.put("DEPT_CODE1", String.valueOf(i));
			rowInfo.put("DEPT_CODE2", String.valueOf(i));
			rowInfo.put("UNIT", String.valueOf(i));
			inputValue.add(rowInfo);
		}
		Map<String, Object> mapResult = sapInf.recevieAsset(inputValue);
		String[] keys = mapResult.keySet().toArray(String[]::new);
		for (String key : keys) {
			System.out.printf("result : %s", mapResult.get(key));
		}
	}

	// SAP 연결해서 삭제하는 샘플소스
	public static void testSapDelete() {
		SAPInterFaceClass sapInf = new SAPInterFaceClass();
		Map<String, Object> mapResult = sapInf.deleteAsset("ABF012200040");
		String[] keys = mapResult.keySet().toArray(String[]::new);
		for (String key : keys) {
			System.out.printf("result : %s", mapResult.get(key));
		}
	}

}
