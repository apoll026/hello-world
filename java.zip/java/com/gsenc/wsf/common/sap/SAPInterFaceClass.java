package com.gsenc.wsf.common.sap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.google.common.base.Objects;
import com.gsenc.wsf.common.util.NullUtil;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoTable;

public class SAPInterFaceClass {
	/**
	 * 유형자산관리 SAP 연동하여 값을 조회하는 함수 조회 기준 날짜, 자산 번호를 입력
	 *
	 * @author yunyoung.ju
	 * @param String searchDay
	 * @param ArrayList asstNum
	 * @return ArrayList<HashMap < String, Object>>
	 */
	public ArrayList<HashMap<String, Object>> searchAsset(String searchDay, ArrayList<String> asstNumArray) {
		SAPConnection sapcon = new SAPConnection();
		sapcon.setSAPConnection();
		ArrayList<HashMap<String, Object>> resultArray = new ArrayList<HashMap<String, Object>>();
		JCoFunction function = sapcon.getFunction("ZFI_IF_ASSET_AMT_INFO");
		JCoParameterList parmList = function.getImportParameterList();
		parmList.setValue("I_BUDAT", searchDay);
		JCoParameterList parmTableList = function.getTableParameterList();
		JCoTable zfis013 = parmTableList.getTable("T_ZFIS013");
		for (String asstNum : asstNumArray) {
			zfis013.appendRow();
			zfis013.setValue("ASST_NUM", asstNum);
			zfis013.setValue("YEAR", "");
			zfis013.setValue("ZAMT01", "0");
			zfis013.setValue("ZAMT02", "0");
			zfis013.setValue("ZAMT03", "0");
			zfis013.setValue("ZAMT04", "0");
			zfis013.setValue("ZAMT05", "0");
			zfis013.setValue("DEPT_CODE", "");
		}

		sapcon.execute(function);
		JCoTable resulttable = function.getTableParameterList().getTable("T_ZFIS013");
		for (int i = 0; i < resulttable.getNumRows(); i++) {
			resulttable.setRow(i);
			HashMap<String, Object> rowInfo = new HashMap<String, Object>();
			String zamt04 = resulttable.getValue("ZAMT04").toString();
			String zcheck = resulttable.getValue("ZCHECK").toString();
			if (NullUtil.isNone(zcheck) && Objects.equal("0", zamt04)) {
				rowInfo.put("ASST_NUM", resulttable.getValue("ASST_NUM").toString());
				rowInfo.put("REMD_AMT", "-1");
				rowInfo.put("잔존가액", "-1");
				rowInfo.put("PROV_AMT", "-1");
				rowInfo.put("DEPR_BAL", "-1");
				rowInfo.put("ASST_AMT", "-1");
				rowInfo.put("ACQU_AMT", "-1");
				rowInfo.put("SUM_ASST", "-1");
				rowInfo.put("SUM_DEPR", "-1");
				rowInfo.put("ASST_DECR", "-1");
				rowInfo.put("SAP_DEPT", "X");
				rowInfo.put("ZCHECK", "");

			} else if (NullUtil.notNone(zcheck) && Objects.equal("0", zamt04)) {
				rowInfo.put("ASST_NUM", resulttable.getValue("ASST_NUM").toString());
				rowInfo.put("REMD_AMT", resulttable.getValue("ZAMT04").toString());
				rowInfo.put("잔존가액", resulttable.getValue("ZAMT04").toString());
				rowInfo.put("PROV_AMT", resulttable.getValue("ZAMT02").toString());
				rowInfo.put("DEPR_BAL", resulttable.getValue("ZAMT04").toString());
				rowInfo.put("ASST_AMT", resulttable.getValue("ZAMT01").toString());
				rowInfo.put("ACQU_AMT", resulttable.getValue("ZAMT01").toString());
				rowInfo.put("SUM_ASST", resulttable.getValue("ZAMT01").toString());
				rowInfo.put("SUM_DEPR", "0");
				rowInfo.put("ASST_DECR", "0");
				rowInfo.put("SAP_DEPT", resulttable.getValue("DEPT_CODE").toString());
				rowInfo.put("ZCHECK", zcheck);
			} else {
            	/*
                int intSumdepr = Integer.parseInt(resulttable.getValue("ZAMT01").toString())
                        - Integer.parseInt(resulttable.getValue("ZAMT04").toString());
                */
				// int 로 처리 불가한 값이 간혹 들어와서 에러 발생함에 따라 long 으로 변경
				long intSumdepr = Long.parseLong(resulttable.getValue("ZAMT01").toString())
					- Long.parseLong(resulttable.getValue("ZAMT04").toString());

				rowInfo.put("ASST_NUM", resulttable.getValue("ASST_NUM").toString());
				rowInfo.put("REMD_AMT", resulttable.getValue("ZAMT04").toString());
				rowInfo.put("잔존가액", resulttable.getValue("ZAMT04").toString());
				rowInfo.put("PROV_AMT", resulttable.getValue("ZAMT02").toString());
				rowInfo.put("DEPR_BAL", resulttable.getValue("ZAMT04").toString());
				rowInfo.put("ASST_AMT", resulttable.getValue("ZAMT01").toString());
				rowInfo.put("ACQU_AMT", resulttable.getValue("ZAMT01").toString());
				rowInfo.put("SUM_ASST", resulttable.getValue("ZAMT01").toString());
				rowInfo.put("SUM_DEPR", String.valueOf(intSumdepr));
				rowInfo.put("ASST_DECR", String.valueOf(intSumdepr));
				rowInfo.put("SAP_DEPT", resulttable.getValue("DEPT_CODE").toString());
				rowInfo.put("ZCHECK", zcheck);
			}
			resultArray.add(rowInfo);
		}

		return resultArray;
	}

	/**
	 * 유형자산관리 SAP 연동하여 값을 전송하는 함수 전송하고자 하는 data를 입력
	 *
	 * @author yunyoung.ju
	 * @param ArrayList<HashMap<String, Object>>
	 * @return String result
	 */
	public Map<String, Object> recevieAsset(ArrayList<HashMap<String, Object>> inputValue) {
		SAPConnection sapcon = new SAPConnection();
		sapcon.setSAPConnection();
		Map<String, Object> result = new HashMap<String, Object>();

		JCoFunction function = sapcon.getFunction("ZFI_IF_ASSET_RECV_001");
		JCoParameterList parmTableList = function.getTableParameterList();
		JCoTable zfis007 = parmTableList.getTable("T_ZFIS007");

		for (HashMap<String, Object> rowInfo : inputValue) {
			zfis007.clear();
			String deprRule = NullUtil.nvl(rowInfo.get("DEPR_RULE"), "").toString();
			String duraYear = NullUtil.nvl(rowInfo.get("DURA_YEAR"), "").toString();
			String duraMonth = NullUtil.nvl(rowInfo.get("DURA_MONTH"), "").toString();
			String gasCheck = NullUtil.nvl(rowInfo.get("GAS_CHECK"), "").toString();
			String deprStat = NullUtil.nvl(rowInfo.get("DEPR_STAT"), "").toString();

			zfis007.appendRow();
			zfis007.setValue("ASST_NUM", rowInfo.get("ASST_NUM").toString());
			zfis007.setValue("ITEM_CODE", rowInfo.get("ITEM_CODE").toString());
			zfis007.setValue("ASST_FULL_NAME", rowInfo.get("ASST_FULL_NAME").toString());
			zfis007.setValue("MNGR_EMPNO", rowInfo.get("MNGR_EMPNO").toString());
			zfis007.setValue("ACQU_DATE", rowInfo.get("ACQU_DATE").toString());
			zfis007.setValue("DURA_YEAR", duraYear);
			zfis007.setValue("DURA_MONTH", duraMonth);
			zfis007.setValue("GAS_CHECK", gasCheck); // 해당값은 SLIP411(해외자산국내전입)에서만 X 로 넘어옴

			if ("X".equals(gasCheck)) {
				if ("2".equals(deprStat)) { //상각종료
					zfis007.setValue("DURA_YEAR", "0");
					zfis007.setValue("DURA_MONTH", "0");

					zfis007.setValue("DEPR_RULE", "Z000");
				} else {
					zfis007.setValue("DURA_YEAR", duraYear.replace("-1", "0"));
					zfis007.setValue("DURA_MONTH", duraMonth.replace("-1", "0"));

					if ("1".equals(deprRule)) {
						zfis007.setValue("DEPR_RULE", "ZA00");
					} else if ("2".equals(deprRule)) {
						zfis007.setValue("DEPR_RULE", "ZB00");
					}
				}
			} else {
				if ("3".equals(deprRule)) {
					zfis007.setValue("DEPR_RULE", "Z000");
					zfis007.setValue("DURA_YEAR", "0");
				} else if ("2".equals(deprRule)) {
					switch (duraYear) {
						case "2":
							zfis007.setValue("DEPR_RULE", "ZB02");
							break;
						case "4":
							zfis007.setValue("DEPR_RULE", "ZB04");
							break;
						case "6":
							zfis007.setValue("DEPR_RULE", "ZB06");
							break;
						case "12":
							zfis007.setValue("DEPR_RULE", "ZB12");
							break;
					}
				} else if ("1".equals(deprRule)) {
					switch (duraYear) {
						case "1":
						case "6":
							zfis007.setValue("DEPR_RULE", "ZA06");
							break;
						case "5":
							zfis007.setValue("DEPR_RULE", "ZA05");
							break;
						case "10":
							zfis007.setValue("DEPR_RULE", "ZA10");
							break;
						case "12":
							zfis007.setValue("DEPR_RULE", "ZA12");
							break;
						case "20":
							zfis007.setValue("DEPR_RULE", "ZA20");
							break;
						case "40":
							zfis007.setValue("DEPR_RULE", "ZA40");
							break;
					}
				}
			}

			zfis007.setValue("CAR_NUM", rowInfo.get("CAR_NUM").toString());
			zfis007.setValue("LOT_NUM", rowInfo.get("LOT_NUM").toString());
			zfis007.setValue("AREA", rowInfo.get("AREA").toString());
			zfis007.setValue("DEPT_CODE1", rowInfo.get("DEPT_CODE1").toString());
			zfis007.setValue("DEPT_CODE2", rowInfo.get("DEPT_CODE2").toString());
			zfis007.setValue("UNIT", rowInfo.get("UNIT").toString());
			zfis007.setValue("IFRESULT", rowInfo.get("ASST_NUM").toString());
			zfis007.setValue("IFMSG", rowInfo.get("ASST_NUM").toString());
			sapcon.execute(function);

			result.put("IFMSG", function.getExportParameterList().getValue("IFMSG").toString());
			result.put("IFRESULT", function.getExportParameterList().getValue("IFRESULT").toString());

		}

		return result;

	}

	/**
	 * 유형자산관리 SAP 연동하여 값을 삭제하는 함수 삭제하고자 하는 data를 입력
	 *
	 * @author yunyoung.ju
	 * @param ArrayList<HashMap<String, Object>>
	 * @return String result
	 */
	public Map<String, Object> deleteAsset(String asstNum) {
		SAPConnection sapcon = new SAPConnection();
		sapcon.setSAPConnection();
		Map<String, Object> result = new HashMap<String, Object>();
		JCoFunction function = sapcon.getFunction("ZFI_IF_ASSET_DELETE");
		JCoParameterList parmList = function.getImportParameterList();
		parmList.setValue("ASST_NUM", asstNum);
		sapcon.execute(function);
		result.put("IFMSG", function.getExportParameterList().getValue("IFMSG").toString());
		result.put("IFRESULT", function.getExportParameterList().getValue("IFRESULT").toString());
		return result;
	}

}
