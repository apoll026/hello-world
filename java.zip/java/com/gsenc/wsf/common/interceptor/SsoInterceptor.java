package com.gsenc.wsf.common.interceptor;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import com.gsenc.wsf.common.constant.SsoConstants;
import com.gsenc.wsf.common.util.AuthResponseUtil;
import com.gsenc.wsf.session.service.SessionService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component
@RequiredArgsConstructor
@Slf4j
public class SsoInterceptor implements HandlerInterceptor {

	private final SessionService sessionService;

	@Value("${spring.config.activate.on-profile}")
	private String profile;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
		throws Exception {

		if (request.getMethod().equalsIgnoreCase("OPTIONS")) {
			return true;
		}

		// 로컬환경에서는 동작하지 않도록 합니다.
		// if ("default".equals(profile)) {
		// 	return true;
		// }

		try {
			String authResult = sessionService.authenticateWithResult(request);

			if (SsoConstants.AUTH_SUCCESS.equals(authResult)) {
				log.debug("Authentication successful");
				return true;
			}

			// 인증 실패 시 응답 처리
			return AuthResponseUtil.handleAuthFailure(response, authResult, request);

		} catch (Exception e) {
			log.error("Authentication process failed: {}", e.getMessage(), e);
			return AuthResponseUtil.handleAuthFailure(response, SsoConstants.AUTH_SSO_FAILED, request);
		}
	}

}
