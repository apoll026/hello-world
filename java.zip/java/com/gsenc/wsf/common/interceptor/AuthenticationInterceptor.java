package com.gsenc.wsf.common.interceptor;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import com.gsenc.wsf.api.service.ApiUrlService;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.util.AuthResponseUtil;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.common.util.ValidateUtil;
import com.gsenc.wsf.log.service.LogService;
import com.gsenc.wsf.session.model.UserCompanySessionVO;
import com.gsenc.wsf.session.model.UserSessionVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
@RequiredArgsConstructor
public class AuthenticationInterceptor implements HandlerInterceptor {
	private final ApiUrlService apiUrlService;
	private final LogService logService;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
		throws Exception {

		if (request.getMethod().equalsIgnoreCase("OPTIONS")) {
			return true;
		}

		String uurl = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
			+ request.getRequestURI();

		// SsoInterceptor에서 이미 세션이 생성되었다고 가정
		HttpSession session = request.getSession(false);

		// 세션이 없다면 SsoInterceptor에서 처리했어야 하는 문제
		if (session == null) {
			log.error("Session should have been created by SsoInterceptor, Access url is " + uurl);
			return AuthResponseUtil.handleAuthFailure(response, StatusCodeConstants.SESSION_EXPIRE, request);
		}

		//UserSessionVO userSession = (UserSessionVO)session.getAttribute(CommonConstants.HTTP_SESSION_KEY);
		UserCompanySessionVO userSession = (UserCompanySessionVO)session.getAttribute(CommonConstants.HTTP_SESSION_KEY);

		String apiUrl = request.getRequestURI();
		String httpMthdCd = request.getMethod();

		if (userSession == null) {
			if (httpMthdCd.equals("POST") && apiUrl.contains("/v1/log")) {
				return true;
			}
			log.error("UserSession should have been created by SsoInterceptor, Access url is " + uurl);
			return AuthResponseUtil.handleAuthFailure(response, StatusCodeConstants.SESSION_EXPIRE, request);
		}

		logService.callGsApAccessLog(request);

		updateLanguageIfNeeded(request, session, userSession);
		SessionScopeUtil.setCompanyContextSession(userSession);
		return true;
		// return checkApiAuthorization(request, response, userSession, uurl);
	}

	private void updateLanguageIfNeeded(HttpServletRequest request, HttpSession session, UserCompanySessionVO userSession) {
		String language = request.getHeader("x-language");
		if (!ValidateUtil.isEmpty(language) && !userSession.getLangCd().equals(language)) {
			userSession.setLangCd(language);
			session.setAttribute(CommonConstants.HTTP_SESSION_KEY, userSession);
		}
	}

	// TODO : API 권한 사용 필요시 role 정의하여 사용필요
	// private boolean checkApiAuthorization(HttpServletRequest request, HttpServletResponse response,
	// 	UserSessionVO userSession, String uurl) throws Exception {
	//
	// 	String apiUrl = request.getRequestURI();
	// 	String httpMthdCd = request.getMethod();
	//
	// 	String queryString = ValidateUtil.charUnescape(StringUtil.nullConvert(request.getQueryString()));
	// 	log.debug("The user who attempted to access the account is {} - {} ( {} , {} ), API URL : {} - {}{}{} ",
	// 		userSession.getMailId(), userSession.getEmpNo(), userSession.getLangCd(), userSession.getTimeZoneCd(),
	// 		httpMthdCd, apiUrl, request.getQueryString() == null ? "" : "?", queryString);
	//
	// 	List<String> roleCodes = userSession.getRoleCodes();
	//
	// 	if (ValidateUtil.isEmpty(roleCodes) || !apiUrlService.checkAccessibleApiUrlsByRoleCodes(apiUrl, httpMthdCd,
	// 		roleCodes)) {
	//
	// 		log.error("Inaccessible Api, Access url is " + uurl);
	// 		return AuthResponseUtil.handleAuthFailure(response, StatusCodeConstants.NOT_AUTHORIZED_EXCEPTION, request);
	// 	}
	//
	// 	return true;
	// }

}
