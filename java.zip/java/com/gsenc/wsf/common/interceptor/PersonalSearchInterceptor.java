package com.gsenc.wsf.common.interceptor;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import com.gsenc.wsf.common.service.PersonalSearchService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component
@RequiredArgsConstructor
@Slf4j
public class PersonalSearchInterceptor implements HandlerInterceptor {

	private final PersonalSearchService personalSearchService;

	@Value("${spring.config.activate.on-profile}")
	private String profile;

	/**
	 * 사용자가 입력한 검색 조건을 저장하는 Interceptor
	 * "Y".equals(request.getParameter("COMMON_PERSONAL_SEARCH_YN"))
	 */
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws
		Exception {

		final String COMMON_PERSONAL_SEARCH_YN = request.getParameter("COMMON_PERSONAL_SEARCH_YN");

		if ("Y".equals(COMMON_PERSONAL_SEARCH_YN)) {
			personalSearchService.insertPersonalSearch(request);
		}

		return true;
	}
}
