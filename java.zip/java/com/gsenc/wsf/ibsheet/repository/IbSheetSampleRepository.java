package com.gsenc.wsf.ibsheet.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.ibsheet.model.IbSheetSampleConditionVo;
import com.gsenc.wsf.ibsheet.model.IbSheetSampleRequestVo;
import com.gsenc.wsf.ibsheet.model.IbSheetSampleResponseVo;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface IbSheetSampleRepository {
	List<IbSheetSampleResponseVo> selectList(@Param("condition") IbSheetSampleConditionVo ibSheetSampleConditionVo);

	int selectListTotalCount(@Param("condition") IbSheetSampleConditionVo ibSheetSampleConditionVo);

	int deleteData(@Param("savaData") List<IbSheetSampleRequestVo> ibSheetSampleRequestVos,
		@Param("session") UserSessionVO UserSessionVO);

	int updateData(@Param("savaData") List<IbSheetSampleRequestVo> ibSheetSampleRequestVos,
		@Param("session") UserSessionVO UserSessionVO);

	int insertData(@Param("savaData") List<IbSheetSampleRequestVo> ibSheetSampleRequestVos,
		@Param("session") UserSessionVO UserSessionVO);

}
