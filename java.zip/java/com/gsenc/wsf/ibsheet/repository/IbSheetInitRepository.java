package com.gsenc.wsf.ibsheet.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.ibsheet.model.IbSheetGridInfoRequestVo;
import com.gsenc.wsf.ibsheet.model.IbSheetGridInfoVo;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface IbSheetInitRepository {
	List<IbSheetGridInfoVo> findByPgmId(@Param("pgmId") String pgmId);

	List<IbSheetGridInfoVo> findByPgmIdAndGridId(
		@Param("pgmId") String pgmId,
		@Param("gridId") String gridId
	);

	int deleteData(
		@Param("savaData") List<IbSheetGridInfoRequestVo> ibSheetGridInfoRequestVo,
		@Param("session") UserSessionVO UserSessionVO
	);

	int updateData(
		@Param("savaData") List<IbSheetGridInfoRequestVo> ibSheetGridInfoRequestVo,
		@Param("session") UserSessionVO UserSessionVO
	);

	int insertData(
		@Param("savaData") List<IbSheetGridInfoRequestVo> ibSheetGridInfoRequestVo,
		@Param("session") UserSessionVO UserSessionVO
	);

	void insertDefaultData(@Param("pgmId") String pgmId);
}
