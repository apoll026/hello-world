package com.gsenc.wsf.ibsheet.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class IbSheetInitColsVo {
	@JsonProperty("Header")
	private List<String> header; // 칼럼이름

	@JsonProperty("Type")
	private String type; // 칼럼 타입 (Text, Lines, Int, Float, Date, Button, Link, Html, Img, Enum, Radio, Bool, Pass, File, Drag)

	@JsonProperty("Visible")
	private Integer visible; // 표시 여부

	@JsonProperty("Name")
	private String name; // 칼럼명

	@JsonProperty("Width")
	private Integer width; // 너비

	@JsonProperty("MinWidth")
	private Integer minWidth; // 최소 너비

	@JsonProperty("CanEdit")
	private Integer canEdit; // 0: readonly, 1: 편집가능

	@JsonProperty("Format")
	private String format; // 데이터 포맷

	@JsonProperty("Align")
	private String align; // 정렬 (left, center, right)

	@JsonProperty("Enum")
	private String enumValues; // code value

	@JsonProperty("EnumKeys")
	private String enumKeys; // code

	@JsonProperty("FormulaRow")
	private String formulaRow; // 합계행

	@JsonProperty("Required")
	private Integer required; // 0: 선택항목, 1: 필수

	@JsonProperty("ColMerge")
	private Integer colMerge; // 0: 머지 안 함, 1: 머지

	@JsonProperty("Size")
	private Integer size; // 최대길이

}
