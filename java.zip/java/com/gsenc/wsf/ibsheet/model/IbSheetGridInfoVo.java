package com.gsenc.wsf.ibsheet.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class IbSheetGridInfoVo {
	private String pgmId;
	private String gridId;
	private String columnId;
	private String columnMsgCd;
	private String description;
	private String display;
	private Integer orderNo;
	private String readonly;
	private String align; // left, center, right
	private String dataType; // Text, Lines, Int, Float, Date, Button, Link, Html, Img, Enum, Radio, Bool, Pass, File, Drag
	private String format;
	private String isRequired;
	private String comboCd;
	private String width;
	private String minWidth;
	private String relWidth;
	private String etcValue;
	private String isMergeYn;
	private String treeKeyYn;
	private String maxLength;
	private String etc;
}
