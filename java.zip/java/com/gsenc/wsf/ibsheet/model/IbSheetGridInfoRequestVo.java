package com.gsenc.wsf.ibsheet.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class IbSheetGridInfoRequestVo extends IbSheetGridInfoVo {
	@JsonProperty("sState")
	private String sState;
}
