package com.gsenc.wsf.ibsheet.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Data
public class IbSheetSampleRequestVo extends IbSheetSampleResponseVo {
	@JsonProperty("sState")
	private String sState;
}
