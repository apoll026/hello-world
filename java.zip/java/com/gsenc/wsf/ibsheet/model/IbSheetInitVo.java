package com.gsenc.wsf.ibsheet.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.*;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class IbSheetInitVo {

    private List<IbSheetInitColsVo> cols;

    @JsonProperty("MainCol")
    private String mainCol;
}
