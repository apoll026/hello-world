package com.gsenc.wsf.ibsheet.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Data
public class IbSheetGridInfoResponseVO extends IbSheetGridInfoVo {
	private String columnMsgCont;

}
