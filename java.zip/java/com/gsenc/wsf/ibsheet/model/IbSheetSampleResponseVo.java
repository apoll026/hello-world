package com.gsenc.wsf.ibsheet.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class IbSheetSampleResponseVo {
	@JsonProperty("sId")
	private String sId;

	@JsonProperty("sCompany")
	private String sCompany;

	@JsonProperty("sCountry")
	private String sCountry;

	@JsonProperty("sSaleQuantity")
	private int sSaleQuantity;

	@JsonProperty("sSaleIncrease")
	private int sSaleIncrease;

	@JsonProperty("sPrice")
	private int sPrice;

	@JsonProperty("sSatisfaction")
	private int sSatisfaction;

	@JsonProperty("sComment")
	private String sComment;

	@JsonProperty("sColMsgCode")
	private String sColMsgCode;

	@JsonProperty("sColMsgCtnKR")
	private String sColMsgCtnKR;

	@JsonProperty("sColMsgCtnEN")
	private String sColMsgCtnEN;
}
