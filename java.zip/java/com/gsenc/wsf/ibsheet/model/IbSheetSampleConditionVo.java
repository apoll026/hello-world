package com.gsenc.wsf.ibsheet.model;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class IbSheetSampleConditionVo {
	String searchItem;
	Integer sPriceFrom;
	Integer sPriceTo;
}
