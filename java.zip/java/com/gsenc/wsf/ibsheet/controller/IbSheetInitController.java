package com.gsenc.wsf.ibsheet.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;
import com.gsenc.wsf.common.model.DmlResponseVO;
import com.gsenc.wsf.ibsheet.model.IbSheetGridInfoRequestVo;
import com.gsenc.wsf.ibsheet.model.IbSheetGridInfoResponseVO;
import com.gsenc.wsf.ibsheet.model.IbSheetInitVo;
import com.gsenc.wsf.ibsheet.service.IbSheetInitService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@Slf4j
public class IbSheetInitController {

	private final IbSheetInitService ibSheetInitService;

	@GetMapping("/v1/ibsheet/grid-configs/{pgmId}/{gridId}")
	public ResponseEntity<CommonResponseVO<IbSheetInitVo>> getGridInitConfigs(
		@PathVariable String pgmId,
		@PathVariable String gridId
	) {
		return new ResponseEntity<>(CommonResponseVO.<IbSheetInitVo>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(ibSheetInitService.getGridInitConfigs(pgmId, gridId))
			.build(), HttpStatus.OK);
	}

	@GetMapping("/v1/ibsheet/grid-configs/{pgmId}")
	public ResponseEntity<CommonResponseVO<List<IbSheetGridInfoResponseVO>>> getGridConfigs(
		@PathVariable String pgmId
	) {
		return new ResponseEntity<>(CommonResponseVO.<List<IbSheetGridInfoResponseVO>>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(ibSheetInitService.getGridConfigs(pgmId))
			.build(), HttpStatus.OK);
	}

	@PostMapping("/v1/ibsheet/grid-configs")
	public ResponseEntity<CommonResponseVO<DmlResponseVO>> saveGridConfigs(
		@RequestBody List<IbSheetGridInfoRequestVo> request
	) {
		return new ResponseEntity<>(CommonResponseVO.<DmlResponseVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(ibSheetInitService.saveGridConfigs(request))
			.build(), HttpStatus.OK);
	}
}
