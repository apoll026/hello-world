package com.gsenc.wsf.ibsheet.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;
import com.gsenc.wsf.common.model.DmlResponseVO;
import com.gsenc.wsf.common.model.PaginationResponseVO;
import com.gsenc.wsf.common.model.ValidList;
import com.gsenc.wsf.ibsheet.model.IbSheetSampleConditionVo;
import com.gsenc.wsf.ibsheet.model.IbSheetSampleRequestVo;
import com.gsenc.wsf.ibsheet.model.IbSheetSampleResponseVo;
import com.gsenc.wsf.ibsheet.service.IbSheetSampleService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Validated
@RequestMapping("/api")
public class IbSheetSampleController {

	private final IbSheetSampleService ibSheetSampleService;

	@GetMapping(value = "/v1/sample/ibsheet", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<PaginationResponseVO<IbSheetSampleResponseVo>>> selectList(
		@Valid IbSheetSampleConditionVo condition) {
		return new ResponseEntity<>(CommonResponseVO.<PaginationResponseVO<IbSheetSampleResponseVo>>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(ibSheetSampleService.selectList(condition))
			.build(), HttpStatus.OK);
	}

	@PostMapping(value = "/v1/sample/ibsheet", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<DmlResponseVO>> saveIBSheetSampleData(
		@RequestBody @Valid ValidList<IbSheetSampleRequestVo> saveData) {
		return new ResponseEntity<>(CommonResponseVO.<DmlResponseVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(ibSheetSampleService.saveIBSheetSampleData(saveData))
			.build(), HttpStatus.OK);
	}

}
