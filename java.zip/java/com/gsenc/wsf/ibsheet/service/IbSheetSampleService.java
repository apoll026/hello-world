package com.gsenc.wsf.ibsheet.service;

import java.util.List;

import com.gsenc.wsf.common.model.DmlResponseVO;
import com.gsenc.wsf.common.model.PaginationResponseVO;
import com.gsenc.wsf.ibsheet.model.IbSheetSampleConditionVo;
import com.gsenc.wsf.ibsheet.model.IbSheetSampleRequestVo;
import com.gsenc.wsf.ibsheet.model.IbSheetSampleResponseVo;

public interface IbSheetSampleService {

	PaginationResponseVO<IbSheetSampleResponseVo> selectList(IbSheetSampleConditionVo ibSheetSampleConditionVo);

	DmlResponseVO saveIBSheetSampleData(List<IbSheetSampleRequestVo> saveData);

}
