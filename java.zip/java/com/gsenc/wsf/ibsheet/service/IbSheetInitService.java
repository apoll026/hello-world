package com.gsenc.wsf.ibsheet.service;

import java.util.List;

import com.gsenc.wsf.common.model.DmlResponseVO;
import com.gsenc.wsf.ibsheet.model.IbSheetGridInfoRequestVo;
import com.gsenc.wsf.ibsheet.model.IbSheetGridInfoResponseVO;
import com.gsenc.wsf.ibsheet.model.IbSheetInitVo;

public interface IbSheetInitService {
	List<IbSheetGridInfoResponseVO> getGridConfigs(String pgmId);

	DmlResponseVO saveGridConfigs(List<IbSheetGridInfoRequestVo> gridConfigs);

	IbSheetInitVo getGridInitConfigs(String pgmId, String gridId);
}
