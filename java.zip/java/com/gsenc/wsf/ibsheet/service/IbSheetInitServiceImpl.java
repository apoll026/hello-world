package com.gsenc.wsf.ibsheet.service;

import static java.util.Arrays.*;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.gsenc.wsf.code.model.UasCodeNameVO;
import com.gsenc.wsf.code.service.CommonCodeService;
import com.gsenc.wsf.common.constant.CrudConstants;
import com.gsenc.wsf.common.exception.BusinessException;
import com.gsenc.wsf.common.model.DmlResponseVO;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.ibsheet.model.IbSheetGridInfoRequestVo;
import com.gsenc.wsf.ibsheet.model.IbSheetGridInfoResponseVO;
import com.gsenc.wsf.ibsheet.model.IbSheetGridInfoVo;
import com.gsenc.wsf.ibsheet.model.IbSheetInitColsVo;
import com.gsenc.wsf.ibsheet.model.IbSheetInitVo;
import com.gsenc.wsf.ibsheet.repository.IbSheetInitRepository;
import com.gsenc.wsf.message.service.MessageService;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class IbSheetInitServiceImpl implements IbSheetInitService {

	private final IbSheetInitRepository ibSheetInitRepository;
	private final MessageService messageService;
	private final CommonCodeService commonCodeService;

	@Override
	public List<IbSheetGridInfoResponseVO> getGridConfigs(String pgmId) {
		List<IbSheetGridInfoVo> gridInfoList = ibSheetInitRepository.findByPgmId(pgmId);
		List<IbSheetGridInfoResponseVO> responseList = new ArrayList<>();
		UserSessionVO userSession = SessionScopeUtil.getContextSession();
		String langCd = userSession.getLangCd();

		for (IbSheetGridInfoVo gridInfo : gridInfoList) {
			IbSheetGridInfoResponseVO responseVO = new IbSheetGridInfoResponseVO();
			BeanUtils.copyProperties(gridInfo, responseVO);

			if (gridInfo.getColumnMsgCd() != null && !gridInfo.getColumnMsgCd().isEmpty()) {
				String msgContent = stream(gridInfo.getColumnMsgCd().split("\\|"))
					.map(msgCd -> messageService.findMessageCache(msgCd.trim(), langCd).getMsgTxtCtn())
					.reduce((s1, s2) -> s1 + "|" + s2)
					.orElse("");
				responseVO.setColumnMsgCont(msgContent);
			}

			responseVO.setDisplay("Y".equals(gridInfo.getDisplay()) ? "1" : "0");
			responseVO.setReadonly("Y".equals(gridInfo.getReadonly()) ? "1" : "0");
			responseVO.setIsRequired("Y".equals(gridInfo.getIsRequired()) ? "1" : "0");
			responseVO.setIsMergeYn("Y".equals(gridInfo.getIsMergeYn()) ? "1" : "0");
			responseVO.setTreeKeyYn("Y".equals(gridInfo.getTreeKeyYn()) ? "1" : "0");

			responseList.add(responseVO);
		}

		return responseList;
	}

	@Override
	public IbSheetInitVo getGridInitConfigs(String pgmId, String gridId) {
		List<IbSheetGridInfoVo> result = ibSheetInitRepository.findByPgmIdAndGridId(pgmId, gridId);
		return mapToInitData(result);
	}

	@Override
	public DmlResponseVO saveGridConfigs(List<IbSheetGridInfoRequestVo> gridConfigs) {
		UserSessionVO session = SessionScopeUtil.getContextSession();
		DmlResponseVO dmlResponseVO = new DmlResponseVO();

		List<IbSheetGridInfoRequestVo> insertDataList = new ArrayList<>();
		List<IbSheetGridInfoRequestVo> updateDataList = new ArrayList<>();
		List<IbSheetGridInfoRequestVo> deleteDataList = new ArrayList<>();

		String pgmId = null;

		for (IbSheetGridInfoRequestVo data : gridConfigs) {
			pgmId = data.getPgmId();

			switch (data.getSState()) {
				case CrudConstants.CREATE:
					insertDataList.add(data);
					break;
				case CrudConstants.UPDATE:
					updateDataList.add(data);
					break;
				case CrudConstants.DELETE:
					deleteDataList.add(data);
					break;
			}
		}
		dmlResponseVO.setDeletedRows(
			deleteDataList.isEmpty() ? 0 : ibSheetInitRepository.deleteData(deleteDataList, session)
		);
		dmlResponseVO.setUpdatedRows(
			updateDataList.isEmpty() ? 0 : ibSheetInitRepository.updateData(updateDataList, session)
		);
		dmlResponseVO.setInsertedRows(
			insertDataList.isEmpty() ? 0 : ibSheetInitRepository.insertData(insertDataList, session)
		);

		if (pgmId != null) {
			ibSheetInitRepository.insertDefaultData(pgmId);
		}

		// if (dmlResponseVO.getDeletedRows() + dmlResponseVO.getInsertedRows() + dmlResponseVO.getUpdatedRows() == 0) {
		// 	throw new BusinessException("Fail");
		// }

		return dmlResponseVO;
	}

	private IbSheetInitVo mapToInitData(List<IbSheetGridInfoVo> vo) {
		IbSheetInitVo ibSheetInitVo = new IbSheetInitVo();
		List<IbSheetInitColsVo> cols = new ArrayList<>();
		UserSessionVO userSession = SessionScopeUtil.getContextSession();
		String langCd = userSession.getLangCd();

		for (IbSheetGridInfoVo gridInfo : vo) {
			IbSheetInitColsVo.IbSheetInitColsVoBuilder colBuilder = IbSheetInitColsVo.builder()
				.name(gridInfo.getColumnId())
				.name(gridInfo.getColumnId())
				.header(
					gridInfo.getColumnMsgCd() != null ?
						stream(gridInfo.getColumnMsgCd().split("\\|"))
							.map(msgCd -> messageService.findMessageCache(msgCd.trim(), langCd).getMsgTxtCtn())
							.toList() :
						new ArrayList<>()
				)
				.visible("Y".equals(gridInfo.getDisplay()) ? 1 : 0)
				.canEdit("Y".equals(gridInfo.getReadonly()) ? 0 : 1)
				.required("Y".equals(gridInfo.getIsRequired()) ? 1 : 0)
				.colMerge("Y".equals(gridInfo.getIsMergeYn()) ? 1 : 0)
				.align(gridInfo.getAlign())
				.type(gridInfo.getDataType())
				.format(gridInfo.getFormat())
				.size(gridInfo.getMaxLength() != null && !gridInfo.getMaxLength().isEmpty() ?
					Integer.parseInt(gridInfo.getMaxLength()) : 0)
				.width(gridInfo.getWidth() != null && !gridInfo.getWidth().isEmpty() ?
					Integer.parseInt(gridInfo.getWidth()) : 0);

			if ("Enum".equals(gridInfo.getDataType())) {
				List<UasCodeNameVO> commonCodes = commonCodeService.findUasCodeNames(
					gridInfo.getComboCd()
				);
				String enumKeys = commonCodes.stream()
					.map(UasCodeNameVO::getCode)
					.reduce((s1, s2) -> s1 + "|" + s2)
					.map(s -> "|" + s)
					.orElse("");
				String enumValues = commonCodes.stream()
					.map(UasCodeNameVO::getCodeName)
					.reduce((s1, s2) -> s1 + "|" + s2)
					.map(s -> "|" + s)
					.orElse("");
				colBuilder.enumKeys(enumKeys).enumValues(enumValues);
			}

			cols.add(colBuilder.build());

			if ("Y".equals(gridInfo.getTreeKeyYn())) {
				ibSheetInitVo.setMainCol(gridInfo.getColumnId());
			}
		}

		ibSheetInitVo.setCols(cols);
		return ibSheetInitVo;
	}
}
