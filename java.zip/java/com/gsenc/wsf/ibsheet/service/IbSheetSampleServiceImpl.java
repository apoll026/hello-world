package com.gsenc.wsf.ibsheet.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gsenc.wsf.common.constant.CrudConstants;
import com.gsenc.wsf.common.exception.BusinessException;
import com.gsenc.wsf.common.model.DmlResponseVO;
import com.gsenc.wsf.common.model.PaginationResponseVO;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.ibsheet.model.IbSheetSampleConditionVo;
import com.gsenc.wsf.ibsheet.model.IbSheetSampleRequestVo;
import com.gsenc.wsf.ibsheet.model.IbSheetSampleResponseVo;
import com.gsenc.wsf.ibsheet.repository.IbSheetSampleRepository;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class IbSheetSampleServiceImpl implements IbSheetSampleService {

	private final IbSheetSampleRepository iBSheetSampleRepository;

	@Override
	public PaginationResponseVO<IbSheetSampleResponseVo> selectList(IbSheetSampleConditionVo ibSheetSampleConditionVo) {
		return PaginationResponseVO.<IbSheetSampleResponseVo>builder()
			.totalCount(iBSheetSampleRepository.selectListTotalCount(ibSheetSampleConditionVo))
			.list(iBSheetSampleRepository.selectList(ibSheetSampleConditionVo))
			.build();
	}

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public DmlResponseVO saveIBSheetSampleData(List<IbSheetSampleRequestVo> saveData) {
		UserSessionVO session = SessionScopeUtil.getContextSession();
		DmlResponseVO dmlResponseVO = new DmlResponseVO();

		List<IbSheetSampleRequestVo> insertDataList = new ArrayList<>();
		List<IbSheetSampleRequestVo> updateDataList = new ArrayList<>();
		List<IbSheetSampleRequestVo> deleteDataList = new ArrayList<>();

		for (IbSheetSampleRequestVo data : saveData) {
			switch (data.getSState()) {
				case CrudConstants.CREATE:
					insertDataList.add(data);
					break;
				case CrudConstants.UPDATE:
					updateDataList.add(data);
					break;
				case CrudConstants.DELETE:
					deleteDataList.add(data);
					break;
			}
		}
		dmlResponseVO.setDeletedRows(
			deleteDataList.isEmpty() ? 0 : iBSheetSampleRepository.deleteData(deleteDataList, session));
		dmlResponseVO.setUpdatedRows(
			updateDataList.isEmpty() ? 0 : iBSheetSampleRepository.updateData(updateDataList, session));
		dmlResponseVO.setInsertedRows(
			insertDataList.isEmpty() ? 0 : iBSheetSampleRepository.insertData(insertDataList, session));

		if (dmlResponseVO.getDeletedRows() + dmlResponseVO.getInsertedRows() + dmlResponseVO.getUpdatedRows() == 0) {
			throw new BusinessException("Fail");
		}

		return dmlResponseVO;
	}

}
