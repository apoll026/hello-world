package com.gsenc.wsf.notice.service;

import java.util.List;

import com.gsenc.wsf.common.model.PaginationResponseVO;
import com.gsenc.wsf.notice.model.NoticeConditionVO;
import com.gsenc.wsf.notice.model.NoticePostDetailResponseVO;
import com.gsenc.wsf.notice.model.NoticePostRequestVO;
import com.gsenc.wsf.notice.model.NoticePostResponseVO;

public interface NoticeService {

    PaginationResponseVO<NoticePostResponseVO> findNotice(NoticeConditionVO noticeCondition);

    NoticePostDetailResponseVO findNoticePost(int bbmNo);

    List<NoticePostDetailResponseVO> findNoticePopupPost();

    int createNoticePost(NoticePostRequestVO noticeVO);

    int modifyNoticePost(NoticePostRequestVO noticeVO);

    int removeNoticePost(int bbmNo);

}
