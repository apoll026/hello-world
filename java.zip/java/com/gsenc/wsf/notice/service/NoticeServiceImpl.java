package com.gsenc.wsf.notice.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.text.StringEscapeUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.exception.BusinessException;
import com.gsenc.wsf.common.model.PaginationResponseVO;
import com.gsenc.wsf.common.util.NamoEditorHtmlUtil;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.common.util.StringUtil;
import com.gsenc.wsf.common.util.ValidateUtil;
import com.gsenc.wsf.employee.model.BbsEmployeeResponseVO;
import com.gsenc.wsf.employee.service.EmployeeService;
import com.gsenc.wsf.file.model.FileVO;
import com.gsenc.wsf.file.service.FileService;
import com.gsenc.wsf.notice.model.NoticeConditionVO;
import com.gsenc.wsf.notice.model.NoticePostDetailResponseVO;
import com.gsenc.wsf.notice.model.NoticePostDetailVO;
import com.gsenc.wsf.notice.model.NoticePostRequestVO;
import com.gsenc.wsf.notice.model.NoticePostResponseVO;
import com.gsenc.wsf.notice.repository.NoticeRepository;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class NoticeServiceImpl implements NoticeService {

	private final NoticeRepository noticeRepository;
	private final EmployeeService employeeService;
	private final FileService fileService;

	@Override
	@Transactional(readOnly = true)
	public PaginationResponseVO<NoticePostResponseVO> findNotice(NoticeConditionVO noticeCondition) {
		UserSessionVO userSession = SessionScopeUtil.getContextSession();
		List<NoticePostResponseVO> noticeList = noticeRepository.selectNoticePosts(noticeCondition, userSession);

		Pattern pattern = Pattern.compile("(&lt;img.*?src=&quot;(.*?)&quot;.*?&gt;)|(<img.*?src=\"(.*?)\".*?>)");

		for (NoticePostResponseVO notice : noticeList) {
			String firstImgSrc = null;
			String bbmCtn = StringUtil.removeHtmlTagsForBbs(notice.getNoticeCtn())
				.replaceAll("&nbsp;", "")
				.replaceAll("&amp;nbsp;", "");
			String whiteSpaceRemoved = StringEscapeUtils.unescapeHtml4(bbmCtn).replaceAll("\\s", "");
			notice.setSmryCtn(whiteSpaceRemoved);

			notice.setNoticeCtn(
				NamoEditorHtmlUtil.updateCtnWithPreSignedUrls(notice.getNoticeCtn(), fileService)); // ctn에 붙여넣기
			String noticeCtn = StringEscapeUtils.unescapeHtml4(notice.getNoticeCtn());
			Matcher matcher = pattern.matcher(noticeCtn);
			if (matcher.find()) {
				firstImgSrc = matcher.group(2) != null ? matcher.group(2) : matcher.group(4);
			}
			notice.setFirstImgTag(firstImgSrc);

			notice.setNoticeCtn(noticeCtn);
		}
		PaginationResponseVO<NoticePostResponseVO> noticePaginationList = new PaginationResponseVO<>(noticeList);
		noticePaginationList.setTotalCount(noticeRepository.selectNoticePostsCount(noticeCondition,userSession));
		return noticePaginationList;
	}

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public NoticePostDetailResponseVO findNoticePost(int bbmNo) {

		UserSessionVO userSession = SessionScopeUtil.getContextSession();
		NoticePostDetailVO notice = Optional.ofNullable(
				noticeRepository.selectNoticePost(bbmNo, userSession.getLangCd()))
			.orElseThrow(
				() -> new BusinessException("The post doesn't exist", StatusCodeConstants.NOT_EXIST_EXCEPTION));

		BbsEmployeeResponseVO insertUser = employeeService.findBbsEmployeeByUserId(notice.getDataInsUserId(),
			userSession.getLangCd());
		BbsEmployeeResponseVO updateUser = employeeService.findBbsEmployeeByUserId(notice.getDataUpdUserId(),
			userSession.getLangCd());
		notice.setNoticeCtn(
			NamoEditorHtmlUtil.updateCtnWithPreSignedUrls(notice.getNoticeCtn(), fileService));//ctn에 붙여넣기
		List<FileVO> atchFiles = fileService.findFiles(notice.getAtchFileGrId());

		noticeRepository.updateNoticePostVwct(bbmNo);

		notice.setNoticeCtn(ValidateUtil.charUnescape(notice.getNoticeCtn()));

		return new NoticePostDetailResponseVO(notice, insertUser, updateUser, atchFiles);
	}

	@Override
	@Transactional(readOnly = true)
	public List<NoticePostDetailResponseVO> findNoticePopupPost() {

		List<NoticePostDetailResponseVO> noticePopupResponseList = new ArrayList<>();
		List<NoticePostDetailVO> noticePopupList = noticeRepository.selectNoticePopupPost();
		for (NoticePostDetailVO notice : noticePopupList) {
			notice.setNoticeCtn(
				NamoEditorHtmlUtil.updateCtnWithPreSignedUrls(notice.getNoticeCtn(), fileService));//ctn에 붙여넣기
		}

		for (NoticePostDetailVO noticePost : noticePopupList) {
			noticePost.setNoticeCtn(ValidateUtil.charUnescape(noticePost.getNoticeCtn()));
			noticePopupResponseList.add(new NoticePostDetailResponseVO(noticePost, null, null, null));
		}
		return noticePopupResponseList;
	}

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public int createNoticePost(NoticePostRequestVO noticeVO) {
		UserSessionVO UserSessionVO = SessionScopeUtil.getContextSession();
		return noticeRepository.insertNoticePost(noticeVO, UserSessionVO);
	}

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public int modifyNoticePost(NoticePostRequestVO noticeVO) {
		UserSessionVO UserSessionVO = SessionScopeUtil.getContextSession();

		NoticePostDetailVO postDetail = noticeRepository.selectNoticePost(Integer.parseInt(noticeVO.getNoticeNo()),
			UserSessionVO.getLangCd());
		if (postDetail == null) {
			throw new BusinessException("The post doesn't exist", StatusCodeConstants.NOT_EXIST_EXCEPTION);
		}
		if (!postDetail.getDataInsUserId().equals(UserSessionVO.getMailId())) {
			throw new BusinessException("User does not have permission to update",
				StatusCodeConstants.NOT_AUTHORIZED_EXCEPTION);
		}

		return noticeRepository.updateNoticePost(noticeVO, UserSessionVO);
	}

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public int removeNoticePost(int bbmNo) {
		UserSessionVO UserSessionVO = SessionScopeUtil.getContextSession();
		NoticePostDetailVO postDetail = noticeRepository.selectNoticePost(bbmNo, UserSessionVO.getLangCd());
		if (postDetail == null) {
			throw new BusinessException("The post doesn't exist", StatusCodeConstants.NOT_EXIST_EXCEPTION);
		}
		if (postDetail.getDataInsUserId() == null || !postDetail.getDataInsUserId().equals(UserSessionVO.getMailId())) {
			throw new BusinessException("User does not have permission to delete",
				StatusCodeConstants.NOT_AUTHORIZED_EXCEPTION);
		}
		return noticeRepository.deleteNoticePost(bbmNo, UserSessionVO);
	}

}
