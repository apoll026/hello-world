package com.gsenc.wsf.notice.service;

import java.util.List;

import com.gsenc.wsf.notice.model.NoticeReplyRequestVO;
import com.gsenc.wsf.notice.model.NoticeReplyResponseVO;

public interface NoticeReplyService {

    int createNoticeReply(NoticeReplyRequestVO noticeReplyRequest);

    int removeNoticeReply(String noticeNo, String noticeReNo);

    int modifyNoticeReply(NoticeReplyRequestVO noticeReplyRequestVO);

    List<NoticeReplyResponseVO> findNoticeReplies(int noticeNo);
}
