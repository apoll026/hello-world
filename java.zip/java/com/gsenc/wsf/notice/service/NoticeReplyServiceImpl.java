package com.gsenc.wsf.notice.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.exception.BusinessException;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.notice.model.NoticeReplyRequestVO;
import com.gsenc.wsf.notice.model.NoticeReplyResponseVO;
import com.gsenc.wsf.notice.model.NoticeReplyVO;
import com.gsenc.wsf.notice.repository.NoticeReplyRepository;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;

@Service("noticeReplyServiceImpl")
@RequiredArgsConstructor
public class NoticeReplyServiceImpl implements NoticeReplyService {

	private final NoticeReplyRepository noticeReplyRepository;

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public int createNoticeReply(NoticeReplyRequestVO noticeReplyRequest) {
		UserSessionVO userSession = SessionScopeUtil.getContextSession();
		return noticeReplyRepository.insertNoticeReply(noticeReplyRequest, userSession);
	}

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public int removeNoticeReply(String noticeNo, String relseReNo) {

		int result = 0;
		UserSessionVO userSession = SessionScopeUtil.getContextSession();
		if (userSession.getRoleCodes().contains("ADM")) {
			result = noticeReplyRepository.deleteNoticeReply(noticeNo, relseReNo);
		} else {
			NoticeReplyVO replyToDelete = noticeReplyRepository.selectNoticeReply(noticeNo, relseReNo);
			if (replyToDelete.getDataInsUserId() == null || !replyToDelete.getDataInsUserId()
				.equals(userSession.getMailId())) {
				throw new BusinessException("User does not have permission to delete",
					StatusCodeConstants.NOT_AUTHORIZED_EXCEPTION);
			}
			result = noticeReplyRepository.deleteNoticeReply(noticeNo, relseReNo);
		}

		return result;
	}

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public int modifyNoticeReply(NoticeReplyRequestVO noticeReplyRequestVO) {
		UserSessionVO userSession = SessionScopeUtil.getContextSession();

		NoticeReplyVO reply = noticeReplyRepository.selectNoticeReply(noticeReplyRequestVO.getNoticeNo(),
			noticeReplyRequestVO.getNoticeReNo());
		if (reply == null) {
			throw new BusinessException("The reply doesn't exist", StatusCodeConstants.NOT_EXIST_EXCEPTION);
		}
		if (!reply.getDataInsUserId().equals(userSession.getMailId())) {
			throw new BusinessException("User does not have permission to update",
				StatusCodeConstants.NOT_AUTHORIZED_EXCEPTION);
		}

		return noticeReplyRepository.updateNoticeReply(noticeReplyRequestVO, userSession);
	}

	@Override
	public List<NoticeReplyResponseVO> findNoticeReplies(int noticeNo) {
		String prntReNo = "-1"; //부모 댓글번호(대댓글 세팅용)
		//세션
		UserSessionVO userSession = SessionScopeUtil.getContextSession();
		//댓글 조회
		List<NoticeReplyResponseVO> replies = noticeReplyRepository.selectNoticeReplies(prntReNo, noticeNo,
			userSession.getLangCd());
		//대댓글 세팅
		for (int i = 0; i < replies.size(); i++) {
			prntReNo = replies.get(i).getNoticeReNo();
			//대댓글 조회
			List<NoticeReplyResponseVO> reReplies = noticeReplyRepository.selectNoticeReplies(prntReNo, noticeNo,
				userSession.getLangCd());
			replies.get(i).setReReplies(reReplies);
		}
		return replies;
	}
}
