package com.gsenc.wsf.notice.model;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class NoticeReplyResponseVO {

	@Schema(description = "게시물 번호")
	private String noticeNo;

	@Schema(description = "게시글 댓글 번호")
	private String noticeReNo;

	@Schema(description = "게시글 댓글 내용")
	private String noticeReCtn;

	@Schema(description = "데이터입력일시")
	private String dataInsDtm;

	@Schema(description = "데이터입력사용자ID")
	private String dataInsUserId;

	@Schema(description = "댓글 사용자 번호")
	private String empNo;

	@Schema(description = "데이터변경일시")
	private String dataUpdDtm;

	@Schema(description = "데이터변경사용자ID")
	private String dataUpdUserId;

	@Schema(description = "사원명")
	private String empNm;

	@Schema(description = "부서명")
	private String deptNm;

	@Schema(description = "직위명")
	private String jtiNm;

	@Schema(description = "부모 댓글 번호")
	private String prntReNo;

	@Schema(description = "삭제 여부")
	private String delYn;

	@Schema(description = "대댓글 목록?")
	private List<NoticeReplyResponseVO> reReplies;

}
