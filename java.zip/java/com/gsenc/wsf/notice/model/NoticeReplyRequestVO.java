package com.gsenc.wsf.notice.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class NoticeReplyRequestVO {

	@NotBlank
	@Schema(description = "게시글번호", example = "1")
	private String noticeNo;

	@NotBlank
	@Schema(description = "게시글댓글번호", example = "1")
	private String noticeReNo;

	@NotBlank
	@Schema(description = "부모댓글번호", example = "1")
	private String prntReNo;

	@NotBlank
	@Schema(description = "게시글댓글내용", example = "안녕하세요")
	private String noticeReCtn;

}
