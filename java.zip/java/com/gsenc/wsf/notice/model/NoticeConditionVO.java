package com.gsenc.wsf.notice.model;

import com.gsenc.wsf.common.model.PaginationRequestVO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = true)
@SuperBuilder
public class NoticeConditionVO extends PaginationRequestVO {

    @Schema(description = "게시판유형코드", example = "NOTI")
    private String noticeTpCd;

    @Schema(description = "제목", example = "제목")
    private String noticeTitle;

    @Schema(description = "내용", example = "내용")
    private String noticeCtn;

    @Schema(description = "검색타입", example = "WRITER")
    private String searchType;

    @Schema(description = "검색내용", example = "내용")
    private String searchCtn;

    @Schema(description = "정렬타입", example = "LAST")
    private String sortValue;
}
