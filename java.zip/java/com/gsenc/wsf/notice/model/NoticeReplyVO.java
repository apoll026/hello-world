package com.gsenc.wsf.notice.model;

import lombok.*;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class NoticeReplyVO {
    private String noticeNo;
    private String noticeReNo;
    private String noticeReCtn;
    private String dataInsDtm;
    private String dataInsUserId;
}
