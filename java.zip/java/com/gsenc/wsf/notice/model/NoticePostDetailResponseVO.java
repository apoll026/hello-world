package com.gsenc.wsf.notice.model;

import java.util.List;

import com.gsenc.wsf.employee.model.BbsEmployeeResponseVO;
import com.gsenc.wsf.file.model.FileVO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class NoticePostDetailResponseVO {

    @Schema(description = "게시물 번호")
    private String noticeNo;

    @Schema(description = "조회수")
    private String noticeVwct;

    @Schema(description = "작성자")
    private BbsEmployeeResponseVO dataInsUser;

    @Schema(description = "작성일")
    private String dataInsDtm;

    @Schema(description = "수정자")
    private BbsEmployeeResponseVO dataUpdUser;

    @Schema(description = "수정일")
    private String dataUpdDtm;

    @Schema(description = "게시판 분류 코드")
    private String noticeTpCd;

    @Schema(description = "게시판 분류 명")
    private String noticeTpNm;

    @Schema(description = "게시대상법인코드")
    private String ptupTgtCopCd;

    @Schema(description = "게시대상법인명")
    private String ptupTgtCopNm;

    @Schema(description = "제목")
    private String noticeTitle;

    @Schema(description = "내용")
    private String noticeCtn;

    @Schema(description = "첨부파일 목록")
    private List<FileVO> atchFiles;

    @Schema(description = "첨부파일그룹ID")
    private String atchFileGrId;

    @Schema(description = "게시종료일자")
    private String ptupEndDt;

    @Schema(description = "댓글 목록")
    private List<NoticeReplyResponseVO> replies;

    @Schema(description = "답글 여부", example ="N")
    private String reNoticeYN;

    @Schema(description = "원 게시물 번호", example ="1")
    private String prntReNoticeNo;

    @Schema(description = "팝업게시시작일시")
    private String poupStDtm;

    @Schema(description = "팝업게시종료일시")
    private String poupEndDtm;

    @Schema(description = "팝업노출미사용일수")
    private String poupEpsNuseDdn;

    @Schema(description = "상단 고정 여부")
    private String imptYn;

    @Schema(description = "팝업 게시 여부", example ="Y")
    private String poupUseYn;


    public NoticePostDetailResponseVO(NoticePostDetailVO noticeDetail,
                                      BbsEmployeeResponseVO insertUser,
                                      BbsEmployeeResponseVO updateUser,
                                      List<FileVO> atchFiles ) {

        this.noticeNo = noticeDetail.getNoticeNo();
        this.noticeVwct = noticeDetail.getNoticeVwct();
        this.dataInsUser = insertUser;
        this.dataInsDtm = noticeDetail.getDataInsDtm();
        this.dataUpdUser = updateUser;
        this.dataUpdDtm = noticeDetail.getDataUpdDtm();
        this.noticeTpCd = noticeDetail.getNoticeTpCd();
        this.noticeTpNm = noticeDetail.getNoticeTpNm();
        this.ptupTgtCopCd = noticeDetail.getPtupTgtCopCd();
        this.ptupTgtCopNm = noticeDetail.getPtupTgtCopNm();
        this.noticeTitle = noticeDetail.getNoticeTitle();
        this.noticeCtn = noticeDetail.getNoticeCtn();
        this.atchFiles = atchFiles;
        this.atchFileGrId = noticeDetail.getAtchFileGrId();
        this.ptupEndDt = noticeDetail.getPtupEndDt();
        this.poupStDtm = noticeDetail.getPoupStDtm();
        this.poupEndDtm = noticeDetail.getPoupEndDtm();
        this.poupEpsNuseDdn = noticeDetail.getPoupEpsNuseDdn();
        this.imptYn = noticeDetail.getImptYn();
        this.poupUseYn = noticeDetail.getPoupUseYn();
    }
}
