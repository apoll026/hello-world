package com.gsenc.wsf.notice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;
import com.gsenc.wsf.common.model.DmlResponseVO;
import com.gsenc.wsf.notice.model.NoticeReplyRequestVO;
import com.gsenc.wsf.notice.model.NoticeReplyResponseVO;
import com.gsenc.wsf.notice.service.NoticeReplyService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;

@RestController
@Tag(name = "Reply")
@Validated
@RequestMapping("/api")
public class NoticeReplyController {

	private final NoticeReplyService noticeReplyService;

	public NoticeReplyController(@Qualifier("noticeReplyServiceImpl") NoticeReplyService noticeReplyService) {
		this.noticeReplyService = noticeReplyService;
	}

	@Operation(summary = "게시글 댓글 생성")
	@PostMapping(value = "/v1/notice/reply", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<DmlResponseVO>> createReply(
		@RequestBody @Valid NoticeReplyRequestVO noticeReplyRequest) {
		return new ResponseEntity<>(CommonResponseVO.<DmlResponseVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(DmlResponseVO.builder()
				.insertedRows(noticeReplyService.createNoticeReply(noticeReplyRequest))
				.build())
			.build(), HttpStatus.OK);
	}

	@Operation(summary = "게시글 댓글 삭제")
	@DeleteMapping(value = "/v1/notice/reply/{bbmNo}/{bbmReNo}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<DmlResponseVO>> removeReply(@PathVariable @NotBlank String bbmNo,
		@PathVariable @NotBlank String bbmReNo) {
		return new ResponseEntity<>(CommonResponseVO.<DmlResponseVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(DmlResponseVO.builder()
				.deletedRows(noticeReplyService.removeNoticeReply(bbmNo, bbmReNo))
				.build())
			.build(), HttpStatus.OK);
	}

	@Operation(summary = "게시글 댓글 수정")
	@PutMapping(value = "/v1/notice/reply", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<DmlResponseVO>> modifyReply(
		@RequestBody @Valid NoticeReplyRequestVO noticeReplyRequest) {
		return new ResponseEntity<>(CommonResponseVO.<DmlResponseVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(DmlResponseVO.builder()
				.updatedRows(noticeReplyService.modifyNoticeReply(noticeReplyRequest))
				.build())
			.build(), HttpStatus.OK);
	}

	@Operation(summary = "게시글 댓글 목록 조회")
	@GetMapping(value = "/v1/notice/reply/{bbmNo}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<List<NoticeReplyResponseVO>>> findNoticeReplies(
		@PathVariable @NotBlank String bbmNo) {
		return new ResponseEntity<>(CommonResponseVO.<List<NoticeReplyResponseVO>>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(noticeReplyService.findNoticeReplies(Integer.parseInt(bbmNo)))
			.build(), HttpStatus.OK);
	}
}
