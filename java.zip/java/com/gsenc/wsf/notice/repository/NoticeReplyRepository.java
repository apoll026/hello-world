package com.gsenc.wsf.notice.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.notice.model.NoticeReplyRequestVO;
import com.gsenc.wsf.notice.model.NoticeReplyResponseVO;
import com.gsenc.wsf.notice.model.NoticeReplyVO;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface NoticeReplyRepository {

	List<NoticeReplyResponseVO> selectNoticeReplies(@Param("prntReNo") String prntReNo, @Param("noticeNo") int noticeNo,
		@Param("langCd") String langCd);

	NoticeReplyVO selectNoticeReply(@Param("noticeNo") String noticeNo, @Param("noticeReNo") String noticeReNo);

	int insertNoticeReply(@Param("noticeReply") NoticeReplyRequestVO noticeReply,
		@Param("session") UserSessionVO userSession);

	int deleteNoticeReply(@Param("noticeNo") String noticeNo, @Param("noticeReNo") String noticeReNo);

	int updateNoticeReply(@Param("noticeReply") NoticeReplyRequestVO noticeReply,
		@Param("session") UserSessionVO UserSessionVO);

}
