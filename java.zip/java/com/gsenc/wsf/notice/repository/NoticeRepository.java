package com.gsenc.wsf.notice.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.notice.model.NoticeConditionVO;
import com.gsenc.wsf.notice.model.NoticePostDetailVO;
import com.gsenc.wsf.notice.model.NoticePostRequestVO;
import com.gsenc.wsf.notice.model.NoticePostResponseVO;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface NoticeRepository {

	int selectNoticePostsCount(@Param("noticeCondition") NoticeConditionVO noticeCondition,@Param("session") UserSessionVO session);

	List<NoticePostResponseVO> selectNoticePosts(@Param("noticeCondition") NoticeConditionVO noticeCondition,
		@Param("session") UserSessionVO session);

	NoticePostDetailVO selectNoticePost(@Param("noticeNo") int noticeNo, @Param("langCd") String langCd);

	List<NoticePostDetailVO> selectNoticePopupPost();

	int updateNoticePostVwct(int bbmNo);

	int insertNoticePost(@Param("post") NoticePostRequestVO noticeVo, @Param("session") UserSessionVO UserSessionVO);

	int updateNoticePost(@Param("post") NoticePostRequestVO noticeVo, @Param("session") UserSessionVO UserSessionVO);

	int deleteNoticePost(@Param("noticeNo") int bbmNo, @Param("session") UserSessionVO UserSessionVO);
}
