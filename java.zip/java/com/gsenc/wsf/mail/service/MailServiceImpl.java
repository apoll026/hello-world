package com.gsenc.wsf.mail.service;

import java.io.File;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring6.SpringTemplateEngine;

import com.gsenc.wsf.common.util.MailUtil;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.common.util.StringUtil;
import com.gsenc.wsf.common.util.ValidateUtil;
import com.gsenc.wsf.department.model.DepartmentRequestVO;
import com.gsenc.wsf.department.model.DepartmentVO;
import com.gsenc.wsf.department.service.DepartmentService;
import com.gsenc.wsf.log.model.EmailLogResponseVO;
import com.gsenc.wsf.log.model.EmailSendLogVO;
import com.gsenc.wsf.log.service.LogService;
import com.gsenc.wsf.mail.model.AttachFileVO;
import com.gsenc.wsf.mail.model.MailRequestVO;
import com.gsenc.wsf.mail.model.MailVO;
import com.gsenc.wsf.mail.repository.EmailSendQueRepository;
import com.gsenc.wsf.session.model.UserSessionVO;

import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.internet.MimeUtility;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class MailServiceImpl implements MailService {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private JavaMailSenderImpl javaMailSender;

	@Autowired
	private SpringTemplateEngine templateEngine;

	private final DepartmentService departmentService;
	private final LogService logService;

	private final EmailSendQueRepository emailSendQueRepository;

	@Value("${spring.mail.from-address}")
	private String fromAddress;

	@Value("${spring.mail.from-address-name}")
	private String fromAddressName;

	@Override
	public MailVO parseMailRequest(MailRequestVO mailRequest) {
		MailVO mailVO = new MailVO();

		List<String> toAddressList;
		List<String> ccAddressList;
		List<String> bccAddressList;

		if (ValidateUtil.isEmpty(mailRequest.getToAddress())) {
			toAddressList = Collections.emptyList();
		} else {
			toAddressList = Arrays.asList(mailRequest.getToAddress().split(","));
		}

		if (ValidateUtil.isEmpty(mailRequest.getCcAddress())) {
			ccAddressList = Collections.emptyList();
		} else {
			ccAddressList = Arrays.asList(mailRequest.getCcAddress().split(","));
		}

		if (ValidateUtil.isEmpty(mailRequest.getBccAddress())) {
			bccAddressList = Collections.emptyList();
		} else {
			bccAddressList = Arrays.asList(mailRequest.getBccAddress().split(","));
		}

		mailVO.setFromAddress(fromAddress);
		mailVO.setFromAddressName(fromAddressName);
		mailVO.setToAddressList(toAddressList);
		mailVO.setCcAddressList(ccAddressList);
		mailVO.setBccAddressList(bccAddressList);
		mailVO.setSubject(mailRequest.getSubject());
		mailVO.setContent(mailRequest.getContent());
		mailVO.setUseHtmlYn(true);

		return mailVO;
	}

	@Override
	public int sendMail(MailVO mailVO) {
		UserSessionVO session = SessionScopeUtil.getContextSession();
		long emlSeq = emailSendQueRepository.selectEmlSndoQueSeq();

		String ccAddress = "";
		if (null != mailVO.getCcAddressList()) {
			ccAddress = String.join(",", mailVO.getCcAddressList());
		}
		String bccAddress = "";
		if (null != mailVO.getBccAddressList()) {
			bccAddress = String.join(",", mailVO.getBccAddressList());
		}
		EmailSendLogVO emailSendQue = EmailSendLogVO.builder()
			.emlSndoSeq(emlSeq)
			.emlTpCd(mailVO.getEmlTpCd())
			.emlTitNm(mailVO.getSubject())
			.emlRcvrLstCtn(String.join(",", mailVO.getToAddressList()))
			.sedEmal(fromAddress)
			.sedEmalNm(fromAddressName)
			.emlDtlCtn(mailVO.getContent())
			.aprReqId(mailVO.getAprReqId())
			.optValNm1(ccAddress)
			.optValNm2(bccAddress)
			.build();
		if (session == null) {
			session = UserSessionVO.builder()
				.mailId(emailSendQue.getDataInsUserId())
				.userIp(emailSendQue.getDataInsUserIp())
				.build();
		}
		emailSendQueRepository.insertEmailSendQue(emailSendQue, session);

		return (int)emlSeq;
	}

	/**
	 * @Desc 다량의 메일을 보내는 배치 메서드입니다.
	 * @return
	 */
	@Override
	public int sendMailBatch() {

		int nResult = 0;
		List<EmailLogResponseVO> emailQue = emailSendQueRepository.selectEmailQueList();
		if (emailQue != null) {
			for (EmailLogResponseVO email : emailQue) {

				MimeMessage mimeMessage = javaMailSender.createMimeMessage();

				List<String> toAddressList = Arrays.asList(email.getEmlRcvrLstCtn().split(","));
				List<String> ccAddressList = null;
				List<String> bccAddressList = null;

				if (null != email.getOptValNm1() && !StringUtil.isEmpty(email.getOptValNm1()))
					ccAddressList = Arrays.asList(email.getOptValNm1().split(","));

				if (null != email.getOptValNm2() && !StringUtil.isEmpty(email.getOptValNm2()))
					bccAddressList = Arrays.asList(email.getOptValNm2().split(","));

				try {
					InternetAddress[] toAddress = MailUtil.listToArray(toAddressList, "UTF-8");
					InternetAddress[] ccAddress = MailUtil.listToArray(ccAddressList, "UTF-8");
					InternetAddress[] bccAddress = MailUtil.listToArray(bccAddressList, "UTF-8");

					MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true,
						"UTF-8"); // use multipart (true)
					mimeMessageHelper.setSubject(
						MimeUtility.encodeText(email.getEmlTitNm(), "UTF-8", "B")); // Base64 encoding
					mimeMessageHelper.setFrom(email.getSedEmal());
					mimeMessageHelper.setFrom(new InternetAddress(email.getSedEmal(), email.getSedEmalNm(), "UTF-8"));
					mimeMessageHelper.setTo(toAddress);
					mimeMessageHelper.setCc(ccAddress);
					mimeMessageHelper.setBcc(bccAddress);

					//mimeMessageHelper.setText(makeTemplate("test-template", null), true);

					// 2025 07 28 메일 템플릿 내용으로만 발송되어서 아래처럼 수정
					Context ctx = new Context();
					ctx.setVariable("title", email.getEmlTitNm());
					ctx.setVariable("content", email.getEmlDtlCtn());

					mimeMessageHelper.setText(makeTemplate("test-template", ctx), email.getEmlDtlCtn());

					javaMailSender.send(mimeMessage);
					nResult = 1;
				} catch (Exception e) {
					logger.info(e.getMessage(), e);
					nResult = -1;
				} finally {
					EmailSendLogVO emailSendque = EmailSendLogVO.builder()
						.emlSndoSeq(email.getEmlSndoSeq())
						.emlTrnmStatCd((nResult == 1 ? "SUCCESS" : "FAIL"))
						.emlTrnmRltCtn("SENT")
						.build();
					emailSendQueRepository.updateEmailQue(emailSendque);

					for (String toAddress : toAddressList) {
						EmailSendLogVO emailSendLog = EmailSendLogVO.builder()
							.emlSndoSeq(email.getEmlSndoSeq())
							.emlTpCd(email.getEmlTpCd())
							.emlRcvrLstCtn(toAddress)
							.sedEmal(email.getSedEmal())
							.emlTitNm(email.getEmlTitNm())
							.emlTrnmStatCd((nResult == 1 ? "SUCCESS" : "FAIL"))
							.emlTrnmRltCtn("SENT")
							.optValNm1(email.getOptValNm1())
							.optValNm2(email.getOptValNm2())
							.emlBdyCtn(email.getEmlDtlCtn())
							.aprReqId(email.getAprReqId())
							.build();

						logService.createEmailSendLog(emailSendLog);
					}

				}
			}
		}
		return nResult;
	}

	/**
	 *
	 * @param mailVO
	 * @Desc 단건 메일을 즉시 보내는 메서드입니다.
	 *       같은 내용의 메일을 여러 수신자한테 보내는 경우 반드시 리스트로 수신자를 넣어 한번의 호출로 발송되게 구현합니다.(과도한 지연시간 방지)
	 *       업무 로직으로 인해 부득이하게 단건씩 보내야 하는 경우 반복문으로 여러번 호출하지 않고 배치기능을 활용해야 합니다.
	 * @return
	 */
	@Override
	public int sendMailImmediately(MailVO mailVO) {
		MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		int nResult = 0;
		try {
			MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true, "UTF-8");

			InternetAddress[] toAddress = MailUtil.listToArray(mailVO.getToAddressList(), "UTF-8");
			InternetAddress[] ccAddress = MailUtil.listToArray(mailVO.getCcAddressList(), "UTF-8");
			InternetAddress[] bccAddress = MailUtil.listToArray(mailVO.getBccAddressList(), "UTF-8");

			mimeMessageHelper.setSubject(MimeUtility.encodeText(mailVO.getSubject(), "UTF-8", "B"));
			mimeMessageHelper.setFrom(
				new InternetAddress(fromAddress, fromAddressName, "UTF-8"));
			mimeMessageHelper.setTo(toAddress);
			mimeMessageHelper.setCc(ccAddress);
			mimeMessageHelper.setBcc(bccAddress);
			mimeMessageHelper.setText(mailVO.getContent(), mailVO.isUseHtmlYn());

			if (!CollectionUtils.isEmpty(mailVO.getAttachFileList())) {
				for (AttachFileVO attachFileDto : mailVO.getAttachFileList()) {
					FileSystemResource fileSystemResource = new FileSystemResource(
						new File(attachFileDto.getRealFileNm()));
					mimeMessageHelper.addAttachment(
						MimeUtility.encodeText(attachFileDto.getAttachFileNm(), "UTF-8", "B"), fileSystemResource);
				}
			}
			javaMailSender.send(mimeMessage);
			nResult = 1;
		} catch (Exception e) {
			logger.debug(e.getMessage(), e);
			nResult = -1;
		}
		return nResult;

	}

	@Override
	public String makeTemplate(String templateType, Object contentObject) {
		String mailContent = "";

		// 샘플 Email Template
		if ("test-template".equals(templateType)) {
			DepartmentRequestVO testVo = new DepartmentRequestVO();
			testVo.setSearchItem("00000");
			List<DepartmentVO> departments = departmentService.findDepartments(testVo);

			Context ctx = new Context();
			ctx.setVariable("title", "테스트 제목");
			ctx.setVariable("departments", departments);

			mailContent = templateEngine.process("test-template", ctx);
		} else if ("verification-template".equals(templateType)) {
			Context ctx = new Context();
			ctx.setVariable("content", contentObject);
			mailContent = templateEngine.process(templateType, ctx);
		}

		return mailContent;
	}

}
