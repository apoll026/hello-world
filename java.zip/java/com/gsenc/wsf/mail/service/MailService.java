package com.gsenc.wsf.mail.service;

import com.gsenc.wsf.mail.model.MailRequestVO;
import com.gsenc.wsf.mail.model.MailVO;

public interface MailService {
    MailVO parseMailRequest(MailRequestVO mailRequest);

    int sendMail(MailVO mailVO);

    int sendMailBatch();

    int sendMailImmediately(MailVO mailVO);

    String makeTemplate(String templateType, Object contentObject);

}
