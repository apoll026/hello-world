package com.gsenc.wsf.mail.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class AttachFileVO {
    private String realFileNm;
    private String attachFileNm;
}
