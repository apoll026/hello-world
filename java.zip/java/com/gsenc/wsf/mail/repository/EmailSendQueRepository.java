package com.gsenc.wsf.mail.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.log.model.EmailLogResponseVO;
import com.gsenc.wsf.log.model.EmailSendLogVO;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface EmailSendQueRepository {

	int insertEmailSendQue(@Param("email") EmailSendLogVO email, @Param("session") UserSessionVO session);

	long selectEmlSndoQueSeq();

	List<EmailLogResponseVO> selectEmailQueList();

	int updateEmailQue(@Param("email") EmailSendLogVO email);
}
