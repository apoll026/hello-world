package com.gsenc.wsf.company.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.company.model.CompanyConditionVO;
import com.gsenc.wsf.employee.model.EmployeeConditionOtherVO;
import com.gsenc.wsf.session.model.CmpnCodeVO;
import com.gsenc.wsf.session.model.EmployeeVO;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface CompanyRepository {

	CmpnCodeVO selectCompanyByCmpnCode(String cmpnNum);

	void selectSpCheckLogin (CompanyConditionVO paramVO);

}
