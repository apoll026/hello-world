package com.gsenc.wsf.company.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.wsf.common.model.DataWrapperVO;
import com.gsenc.wsf.common.util.RestResponseFactoryUtil;
import com.gsenc.wsf.company.service.CompanyService;
import com.gsenc.wsf.session.model.CmpnCodeVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequiredArgsConstructor
@Tag(name = "Company")
@Validated
@Slf4j
@RequestMapping("/api")
public class CompanyController {

	private final CompanyService companyService;

	@Operation(summary = "CompanySignVerify", description = "CompanySignVerify")
	@PostMapping(value = "/v1/company-verify", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DataWrapperVO> callSignVerifyData(@RequestBody DataWrapperVO<List<CmpnCodeVO>> company,
														  HttpServletRequest request) {

		return new ResponseEntity<>(
				RestResponseFactoryUtil.createReturnDataVO(
						companyService.migrateCompany(request)),
				HttpStatus.OK);
	}

}
