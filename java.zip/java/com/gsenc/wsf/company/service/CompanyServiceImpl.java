package com.gsenc.wsf.company.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.exception.BusinessException;
import com.gsenc.wsf.common.model.CommonRestResponseVO;
import com.gsenc.wsf.common.util.FormatUtil;
import com.gsenc.wsf.common.util.NetworkUtil;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.company.model.CompanyConditionVO;
import com.gsenc.wsf.company.repository.CompanyRepository;
import com.gsenc.wsf.employee.model.EmployeeConditionOtherVO;
import com.gsenc.wsf.employee.model.HrEmployeeIFCUDList;
import com.gsenc.wsf.employee.model.HrEmployeeIFVO;
import com.gsenc.wsf.employee.service.EmployeeIFServiceImpl;
import com.gsenc.wsf.log.model.IfLogVO;
import com.gsenc.wsf.session.model.CmpnCodeVO;
import com.gsenc.wsf.session.model.EmployeeVO;
import com.gsenc.wsf.session.model.UserSessionVO;

import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class CompanyServiceImpl implements CompanyService {

	private final CompanyRepository companyRepository;

	@Override
	@Transactional(readOnly = true)
	public CmpnCodeVO selectCompanyByCmpnCode(String cmpnNum) throws BusinessException {
		return companyRepository.selectCompanyByCmpnCode(cmpnNum);
	}

	@Override
	@Transactional(readOnly = true)
	public CmpnCodeVO selectSpCheckLogin(String cmpnNum, String certSerial) throws BusinessException {

		CmpnCodeVO cmpnVo = new CmpnCodeVO();
		CompanyConditionVO paramVO = new CompanyConditionVO();
		paramVO.setI_CMPN_NUM(cmpnNum);
		paramVO.setI_CERT_SERIAL(certSerial);
		paramVO.setOut_List1(null);

		companyRepository.selectSpCheckLogin(paramVO);
		if (paramVO.getOut_List1() != null) {
			for (Map<String, String> list : paramVO.getOut_List1()) {
				log.info(" list key getAcct_name :: {} ", list.get("cmpnNum"));
				cmpnVo.setCmpnCode(list.get("cmpnCode"));
				cmpnVo.setCmpnNum(list.get("cmpnNum"));
			}
		}
		return cmpnVo;

	}

	@Transactional(rollbackFor = {Exception.class})
	public CommonRestResponseVO migrateCompany(HttpServletRequest request) {

		CommonRestResponseVO resultVO = CommonRestResponseVO.builder()
				.o_ret_code("S")
				.o_ret_msg(StatusCodeConstants.SUCCESS)
				.build();
		/*
		IfLogVO ifLog = IfLogVO.builder()
				.ifNm("HR-EMP")
				.ifDivsCd("BATCH")
				.ifTrmtValCtn("")
				.ifRestValCtn(rCompanyList.toString())
				.dataInsUserId("Batch")
				.dataInsUserIp(NetworkUtil.getClientIP(request))
				.build();
		*/
		return resultVO;

	}

}
