package com.gsenc.wsf.company.service;

import java.util.List;

import com.gsenc.wsf.common.exception.BusinessException;
import com.gsenc.wsf.common.model.CommonRestResponseVO;
import com.gsenc.wsf.employee.model.HrEmployeeIFVO;
import com.gsenc.wsf.session.model.CmpnCodeVO;
import com.gsenc.wsf.session.model.EmployeeVO;

import jakarta.servlet.http.HttpServletRequest;

public interface CompanyService {

	CmpnCodeVO selectCompanyByCmpnCode(String cmpnNum) throws BusinessException;

	CmpnCodeVO selectSpCheckLogin(String cmpnNum, String certSerial) throws BusinessException;

	CommonRestResponseVO migrateCompany(HttpServletRequest request);

}
