package com.gsenc.wsf.company.model;

import java.util.List;
import java.util.Map;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class CompanyConditionVO {

    @Schema(description = "사업자번호", example = "cmpnNum")
    private String i_CMPN_NUM;

    @Schema(description = "인증번호", example = "certSerial")
    private String i_CERT_SERIAL;

    @Schema(description = "사업자sap NO", example = "cmpnSap")
    List<Map<String, String>> out_List1;

}
