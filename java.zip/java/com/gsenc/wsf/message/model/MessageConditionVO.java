package com.gsenc.wsf.message.model;

import com.gsenc.wsf.common.model.PaginationRequestVO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = true)
@SuperBuilder
public class MessageConditionVO extends PaginationRequestVO {

    @Schema(description = "메시지코드", example = "multilanguage.page.hello")
    private String optValCtn1;

    @Schema(description = "메시지코드", example = "multilanguage.page.hello")
    private String msgCtn;

    @Schema(description = "메시지명", example = "안녕하세요!")
    private String msgTxtCtn;

    @Schema(description = "언어코드", example = "ko")
    private String langCd;

    @Schema(description = "사용여부", example = "Y")
    private String useYn;

}
