package com.gsenc.wsf.message.service;

import java.util.List;
import java.util.Map;

import com.gsenc.wsf.common.model.DmlResponseVO;
import com.gsenc.wsf.common.model.PaginationResponseVO;
import com.gsenc.wsf.message.model.MessageConditionVO;
import com.gsenc.wsf.message.model.MessageSimpleVO;
import com.gsenc.wsf.message.model.MessageVO;

public interface MessageService {

    Map<String, String> readTranslatedMessageFile(String langCd);

    boolean deployTranslatedMessages(String langCd);

    boolean deployTranslatedMessagesAll();

    PaginationResponseVO<MessageVO> findMessages(MessageConditionVO messageCondition);

    List<MessageVO> findMessagesMsgCtn(MessageConditionVO messageCondition);

    MessageSimpleVO findMessageCache(String msgCtn, String langCd);

    public int refreshMessageAll();

    int createMessage(MessageVO messageVO);

    int modifyMessage(MessageVO messageVO);

    int removeMessage(String msgCtn, String langCd);

    DmlResponseVO saveMessages(List<MessageVO> messages);

}
