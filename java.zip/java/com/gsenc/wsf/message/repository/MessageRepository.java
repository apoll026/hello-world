package com.gsenc.wsf.message.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.message.model.MessageConditionVO;
import com.gsenc.wsf.message.model.MessageSimpleVO;
import com.gsenc.wsf.message.model.MessageVO;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface MessageRepository {
	int selectMessagesCount(@Param("messageCondition") MessageConditionVO messageCondition);

	List<MessageVO> selectMessages(@Param("messageCondition") MessageConditionVO messageCondition,
		@Param("session") UserSessionVO session);

	List<MessageVO> selectMessagesMsgCtn(MessageConditionVO messageCondition);

	List<MessageVO> selectTransaltedMessages(String langCd);

	MessageVO selectMessage(MessageConditionVO messageCondition);

	MessageSimpleVO selectMessageCache(@Param("msgCtn") String msgCtn, @Param("langCd") String langCd);

	List<MessageSimpleVO> selectMessagesAllCache();

	int insertMessage(@Param("message") MessageVO messageVO, @Param("session") UserSessionVO UserSessionVO);

	int updateMessage(@Param("message") MessageVO messageVO, @Param("session") UserSessionVO UserSessionVO);

	int deleteMessage(MessageVO messageVO);

}
