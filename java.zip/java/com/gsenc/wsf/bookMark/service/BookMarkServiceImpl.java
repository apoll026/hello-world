package com.gsenc.wsf.bookMark.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.gsenc.wsf.bookMark.model.BookMarkVO;
import com.gsenc.wsf.bookMark.repository.BookMarkRepository;
import com.gsenc.wsf.common.model.DmlResponseVO;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;

@Service("bookMarkServiceImpl")
@RequiredArgsConstructor
public class BookMarkServiceImpl implements BookMarkService {

    private final BookMarkRepository bookMarkRepository;

    @Override
    public List<BookMarkVO> findBookMarkMenus() {
        UserSessionVO session = SessionScopeUtil.getContextSession();
        return bookMarkRepository.selectBookMark(session.getEmpNo());
    }

    @Override
    public int insertBookMarkMenus(BookMarkVO bookMarkVO) {
        UserSessionVO session = SessionScopeUtil.getContextSession();
        int cnt = bookMarkRepository.insertBookMark(bookMarkVO, session);
        return cnt;
    }

    @Override
    public int deleteBookMarkMenus(BookMarkVO bookMarkVO) {
        UserSessionVO session = SessionScopeUtil.getContextSession();
        int cnt = bookMarkRepository.deleteBookMark(bookMarkVO, session);
        return cnt;
    }
}
