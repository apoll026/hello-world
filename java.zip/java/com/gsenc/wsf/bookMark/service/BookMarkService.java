package com.gsenc.wsf.bookMark.service;

import java.util.List;

import com.gsenc.wsf.bookMark.model.BookMarkVO;
import com.gsenc.wsf.common.model.DmlResponseVO;

public interface BookMarkService {

    List<BookMarkVO> findBookMarkMenus();
    int insertBookMarkMenus(BookMarkVO bookMarkVO);
    int deleteBookMarkMenus(BookMarkVO bookMarkVO);
}
