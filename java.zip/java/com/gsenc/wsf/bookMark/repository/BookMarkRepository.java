package com.gsenc.wsf.bookMark.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.bookMark.model.BookMarkVO;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface BookMarkRepository {

    int insertBookMark(@Param("bookMarkVO") BookMarkVO bookMarkVO,@Param("session") UserSessionVO session);
    int deleteBookMark(@Param("bookMarkVO") BookMarkVO bookMarkVO,@Param("session") UserSessionVO session);
    List<BookMarkVO> selectBookMark(String empNo);



}
