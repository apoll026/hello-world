package com.gsenc.wsf.bookMark.model;

import java.util.List;

import com.gsenc.wsf.menu.model.MenuResponseVO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class BookMarkVO {
    private String pgmUrl;
    private String pgmName;
    private String pgmId;
}
