package com.gsenc.wsf.bookMark.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.gsenc.wsf.bbs.model.BbsConditionVO;
import com.gsenc.wsf.bbs.model.BbsPostResponseVO;
import com.gsenc.wsf.bookMark.model.BookMarkVO;
import com.gsenc.wsf.bookMark.service.BookMarkService;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;
import com.gsenc.wsf.common.model.DmlResponseVO;
import com.gsenc.wsf.common.model.PaginationResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "Bookmark")
@Validated
@RequestMapping("/api")
public class BookMarkController {

    private final BookMarkService bookMarkService;

    @Operation(summary = "북마크 조회")
    @GetMapping(value = "/bookmark", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO<List<BookMarkVO>>> getBookMarkMenus() {
        return new ResponseEntity<>(CommonResponseVO.<List<BookMarkVO>>builder()
                .successOrNot(CommonConstants.YES_FLAG)
                .statusCode(StatusCodeConstants.SUCCESS)
                .data(bookMarkService.findBookMarkMenus())
                .build(), HttpStatus.OK);
    }

    @Operation(summary = "북마크 추가" )
    @PostMapping(value = "/bookmark", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO<DmlResponseVO>> insertBookMarkMenus(@RequestBody BookMarkVO bookMarkVO) {
        return new ResponseEntity<>(CommonResponseVO.<DmlResponseVO>builder()
                .successOrNot(CommonConstants.YES_FLAG)
                .statusCode(StatusCodeConstants.SUCCESS)
                .data(DmlResponseVO.builder().insertedRows(bookMarkService.insertBookMarkMenus(bookMarkVO)).build())
                .build(), HttpStatus.OK);
    }

    @Operation(summary = "북마크 삭제")
    @PutMapping(value = "/bookmark", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO<DmlResponseVO>> deleteBookMarkMenus(@RequestBody BookMarkVO bookMarkVO) {
        return new ResponseEntity<>(CommonResponseVO.<DmlResponseVO>builder()
                .successOrNot(CommonConstants.YES_FLAG)
                .statusCode(StatusCodeConstants.SUCCESS)
                .data(DmlResponseVO.builder().insertedRows(bookMarkService.deleteBookMarkMenus(bookMarkVO)).build())
                .build(), HttpStatus.OK);
    }

}
