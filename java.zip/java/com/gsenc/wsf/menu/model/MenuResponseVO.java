package com.gsenc.wsf.menu.model;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
@EqualsAndHashCode(of = {"pgmId"})
public class MenuResponseVO implements Comparable<MenuResponseVO>, Serializable {

	private static final long serialVersionUID = 1L;

    @Schema(description = "프로그램 ID", example = "MENU001")
    private String pgmId;

    @Schema(description = "프로그램명", example = "사용자 관리")
    private String pgmName;

    @Schema(description = "상위 프로그램 ID", example = "ROOT001")
    private String upgmId;

    @Schema(description = "정렬순서", example = "1")
    private Integer menuLevel;

    @Schema(description = "메시지코드", example = "com.menu.000001")
    private String msgCtn;

    @Schema(description = "프로그램 URL", example = "/user/manage")
    private String pgmUrl;

    @Schema(description = "PM 메뉴 여부", example = "Y")
    private String pmFlag;

    @Schema(description = "프로그램 코드", example = "01")
    private String pgmCode;

    @Schema(description = "프로그램 권한 레벨", example = "1")
    private String pgmAuth;

    @Schema(description = "사용 여부", example = "Y")
    private String useYn;

    @Override
    public int compareTo(MenuResponseVO menuResponseVO) {
        return this.pgmId != null && menuResponseVO.pgmId != null
                ? this.pgmId.compareTo(menuResponseVO.pgmId)
                : 0;
    }
}
