package com.gsenc.wsf.menu.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.OptionalInt;
import java.util.stream.IntStream;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gsenc.wsf.common.constant.CrudConstants;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.common.util.StringUtil;
import com.gsenc.wsf.department.model.DepartmentVO;
import com.gsenc.wsf.menu.model.MenuRequestVO;
import com.gsenc.wsf.menu.model.MenuResponseVO;
import com.gsenc.wsf.menu.repository.MenuRepository;
import com.gsenc.wsf.role.model.RoleEmployeeResponseVO;
import com.gsenc.wsf.role.model.RoleResponseVO;
import com.gsenc.wsf.role.repository.RoleMenuRepository;
import com.gsenc.wsf.session.model.UserCompanySessionVO;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional
public class MenuServiceImpl implements MenuService {

	private final MenuRepository menuRepository;
	private final RoleMenuRepository roleMenuRepository;

	private final String MOVE_UP = "1";
	private final String MOVE_DOWN = "2";
	private final String MOVE_INNER = "3";
	private final String DEFAULT = "4";

	@Override
	@Transactional(readOnly = true)
	public List<MenuResponseVO> findAllMenus(MenuRequestVO menuRequestVO) {
		UserCompanySessionVO session = SessionScopeUtil.getCompanyContextSession();
		return menuRepository.selectAllMenus(menuRequestVO, session);
	}

	@Override
	@Transactional(readOnly = true)
	public MenuResponseVO findMenu(String mnuId) {
		UserCompanySessionVO session = SessionScopeUtil.getCompanyContextSession();
		return menuRepository.selectMenu(mnuId, session);
	}

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public int saveMenu(MenuRequestVO menuRequestVO) {

		if (MOVE_INNER.equals(menuRequestVO.getMenuLocation()) || DEFAULT.equals(menuRequestVO.getMenuLocation())) {
			return saveMenuInnerOrDefault(menuRequestVO);
		} else {
			return saveMenuUpOrDown(menuRequestVO);
		}
	}

	private int saveMenuInnerOrDefault(MenuRequestVO menuRequestVO) {
		if (MOVE_INNER.equals(menuRequestVO.getMenuLocation())) {
			UserCompanySessionVO session = SessionScopeUtil.getCompanyContextSession();
			List<MenuResponseVO> childMenus = menuRepository.selectChildMenus(menuRequestVO.getTargetMenuId(), session);
			menuRequestVO.setUpprMnuId(menuRequestVO.getTargetMenuId());
			menuRequestVO.setSortOrd(childMenus.size());
		}

		this.upsertMenu(menuRequestVO);
		return 1;
	}

	private void upsertMenu(MenuRequestVO menuRequestVO) {
		UserCompanySessionVO session = SessionScopeUtil.getCompanyContextSession();
		if (CrudConstants.CREATE.equals(menuRequestVO.getCrudKey()) || "".equals(menuRequestVO.getPgmId())) {
			menuRepository.insertMenu(menuRequestVO, session);
			//TODO: 임시 기능 11권한 그룹에 자동으로 메뉴 추가 FATY721
			roleMenuRepository.insertMenuByAuth("11", menuRequestVO.getPgmId(), session);
		} else {
			menuRepository.updateMenu(menuRequestVO, session);
		}
	}

	private int saveMenuUpOrDown(MenuRequestVO menuRequestVO) {

		List<MenuResponseVO> targetLevelMenus = this.findSameLevelMenus(menuRequestVO.getTargetMenuId());
		targetLevelMenus.removeIf(x -> x.getPgmId().equals(menuRequestVO.getPgmId()));

		OptionalInt optTargetIndex = IntStream.range(0, targetLevelMenus.size())
			.filter(i -> menuRequestVO.getTargetMenuId().equals(targetLevelMenus.get(i).getPgmId()))
			.findFirst();

		if (optTargetIndex.isPresent()) {
			menuRequestVO.setUpprMnuId(targetLevelMenus.get(optTargetIndex.getAsInt()).getUpgmId());
		}

		int insertIndex = 0;
		if (MOVE_UP.equals(menuRequestVO.getMenuLocation())) {
			insertIndex = optTargetIndex.orElse(0);
		} else if (MOVE_DOWN.equals(menuRequestVO.getMenuLocation())) {
			insertIndex = optTargetIndex.orElse(targetLevelMenus.size() - 1) + 1;
		}

		MenuResponseVO tempIndexMenu = MenuResponseVO.builder().pgmId(menuRequestVO.getPgmId()).build();
		targetLevelMenus.add(insertIndex, tempIndexMenu);

		for (int i = 0; i < targetLevelMenus.size(); i++) {
			if (StringUtil.isEmpty(targetLevelMenus.get(i).getPgmId()) || targetLevelMenus.get(i)
				.getPgmId()
				.equals(menuRequestVO.getPgmId())) {
				menuRequestVO.setSortOrd(i);
				this.upsertMenu(menuRequestVO);
			} else {
				menuRepository.updateMenuSortOrd(targetLevelMenus.get(i).getPgmId(), i,
					SessionScopeUtil.getCompanyContextSession());
			}
		}
		return 1;
	}

	private List<MenuResponseVO> findSameLevelMenus(String menuId) {
		UserCompanySessionVO session = SessionScopeUtil.getCompanyContextSession();
		String upprMnuId = menuRepository.selectMenu(menuId, session).getUpgmId();
		return this.findChildMenus(upprMnuId);
	}

	private List<MenuResponseVO> findChildMenus(String menuId) {
		UserCompanySessionVO session = SessionScopeUtil.getCompanyContextSession();
		return menuRepository.selectChildMenus(menuId, session);
	}

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public int removeMenus(String mnuId) {
		List<MenuResponseVO> siblingMenus = this.findSiblingMenus(mnuId);
		this.updateMenusSortOrder(siblingMenus);

		return menuRepository.deleteMenus(mnuId);
	}

	private List<MenuResponseVO> findSiblingMenus(String mnuId) {
		List<MenuResponseVO> siblingMenus = this.findSameLevelMenus(mnuId);
		siblingMenus.removeIf(x -> x.getPgmId().equals(mnuId));

		return siblingMenus;
	}

	private void updateMenusSortOrder(List<MenuResponseVO> menus) {
		UserCompanySessionVO session = SessionScopeUtil.getCompanyContextSession();
		for (int i = 0; i < menus.size(); i++) {
			menuRepository.updateMenu(MenuRequestVO.builder().pgmId(menus.get(i).getPgmId()).sortOrd(i).build(),
				session);
		}
	}

	@Override
	@Transactional(readOnly = true)
	public List<RoleResponseVO> findRolesByMenuId(String mnuId) {
		return menuRepository.selectRolesByMenuId(mnuId);
	}

	@Override
	@Transactional(readOnly = true)
	public List<RoleEmployeeResponseVO> findEmployeesByMenu(String mnuId) {
		UserCompanySessionVO session = SessionScopeUtil.getCompanyContextSession();
		return menuRepository.selectEmployeesByMenuId(mnuId, session);
	}

	@Override
	@Transactional(readOnly = true)
	public List<DepartmentVO> findDepartmentsByMenu(String mnuId) {
		UserCompanySessionVO session = SessionScopeUtil.getCompanyContextSession();
		return menuRepository.selectDepartmentsByMenuId(mnuId, session);
	}

	@Override
	public List<MenuResponseVO> findAllMenusSearch() {
		UserCompanySessionVO session = SessionScopeUtil.getCompanyContextSession();

		Map<String, Object> params = new HashMap<>();
		params.put("i_emp_no", session.getEmpNo());

		menuRepository.selectAllMenusSearch(params);

		List<MenuResponseVO> result = (List<MenuResponseVO>)params.get("o_rc");
		return result;
	}
}
