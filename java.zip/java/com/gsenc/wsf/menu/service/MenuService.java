package com.gsenc.wsf.menu.service;

import java.util.List;

import com.gsenc.wsf.department.model.DepartmentVO;
import com.gsenc.wsf.menu.model.MenuRequestVO;
import com.gsenc.wsf.menu.model.MenuResponseVO;
import com.gsenc.wsf.role.model.RoleEmployeeResponseVO;
import com.gsenc.wsf.role.model.RoleResponseVO;

public interface MenuService {

	List<MenuResponseVO> findAllMenus(MenuRequestVO menuRequestVO);

	MenuResponseVO findMenu(String mnuId);

	int saveMenu(MenuRequestVO menuRequestVO);

	int removeMenus(String mnuId);

	List<RoleResponseVO> findRolesByMenuId(String mnuId);

	List<RoleEmployeeResponseVO> findEmployeesByMenu(String mnuId);

	List<DepartmentVO> findDepartmentsByMenu(String mnuId);

	List<MenuResponseVO> findAllMenusSearch();
}
