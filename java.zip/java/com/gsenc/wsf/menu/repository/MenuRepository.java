package com.gsenc.wsf.menu.repository;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.department.model.DepartmentVO;
import com.gsenc.wsf.menu.model.MenuRequestVO;
import com.gsenc.wsf.menu.model.MenuResponseVO;
import com.gsenc.wsf.role.model.RoleEmployeeResponseVO;
import com.gsenc.wsf.role.model.RoleResponseVO;
import com.gsenc.wsf.session.model.UserCompanySessionVO;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface MenuRepository {

	List<MenuResponseVO> selectAllMenus(
		@Param("menu") MenuRequestVO menuRequestVO,
		@Param("session") UserCompanySessionVO session
	);

	MenuResponseVO selectMenu(@Param("mnuId") String mnuId, @Param("session") UserCompanySessionVO session);

	List<MenuResponseVO> selectChildMenus(@Param("mnuId") String mnuId, @Param("session") UserCompanySessionVO session);

	int updateMenuSortOrd(@Param("mnuId") String mnuId, @Param("sortOrd") int sortOrd,
		@Param("session") UserCompanySessionVO session);

	int insertMenu(@Param("menu") MenuRequestVO menuRequestVO, @Param("session") UserCompanySessionVO session);

	int updateMenu(@Param("menu") MenuRequestVO menuRequestVO, @Param("session") UserCompanySessionVO session);

	int deleteMenus(@Param("mnuId") String mnuId);

	List<RoleResponseVO> selectRolesByMenuId(@Param("mnuId") String mnuId);

	List<RoleEmployeeResponseVO> selectEmployeesByMenuId(@Param("mnuId") String mnuId,
		@Param("session") UserCompanySessionVO session);

	List<DepartmentVO> selectDepartmentsByMenuId(@Param("mnuId") String mnuId, @Param("session") UserCompanySessionVO session);

	void selectAllMenusSearch(@Param("params") Map<String, Object> params);
}
