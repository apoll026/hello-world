package com.gsenc.wsf.help.model;

import com.gsenc.wsf.common.model.CrudVO;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Getter
@Setter
@SuperBuilder
public class HelpRequestVO extends CrudVO {

	@Schema(description = "PGM ID")
	private String pgmId;

	@NotBlank
	@Schema(description = "도움말 명")
	private String helpNm;

	@NotBlank
	@Schema(description = "도움말 타입")
	private String helpType;

	@NotBlank
	@Schema(description = "도움말 파일")
	private String helpFile;

	@NotBlank
	@Schema(description = "도움말 링크")
	private String helpLink;

	@NotBlank
	@Schema(description = "사용여부")
	private String useYn;

}
