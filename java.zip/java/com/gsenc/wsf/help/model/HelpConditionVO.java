package com.gsenc.wsf.help.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class HelpConditionVO {

	@Schema(description = "도움말 명")
	private String helpNm;

	@Schema(description = "사용여부")
	private String useYn;

}
