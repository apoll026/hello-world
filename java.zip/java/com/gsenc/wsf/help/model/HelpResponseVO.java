package com.gsenc.wsf.help.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class HelpResponseVO {

	@Schema(description = "PGM ID")
	private String pgmId;

	@Schema(description = "도움말 명")
	private String helpNm;

	@Schema(description = "도움말 타입")
	private String helpType;

	@Schema(description = "도움말 파일")
	private String helpFile;

	@Schema(description = "도움말 링크")
	private String helpLink;

	@Schema(description = "사용여부")
	private String useYn;

	@Schema(description = "작성자")
	private String dataInsUserName;

	@Schema(description = "작성일시")
	private String dataInsDtm;

	@Schema(description = "수정자")
	private String dataUpdUserName;

	@Schema(description = "수정일시")
	private String dataUpdDtm;
}
