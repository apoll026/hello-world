package com.gsenc.wsf.help.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.gsenc.wsf.common.model.DmlResponseVO;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.help.model.HelpConditionVO;
import com.gsenc.wsf.help.model.HelpRequestVO;
import com.gsenc.wsf.help.model.HelpResponseVO;
import com.gsenc.wsf.help.repository.HelpRepository;
import com.gsenc.wsf.session.model.UserCompanySessionVO;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class HelpServiceImpl implements HelpService {

	private final HelpRepository helpRepository;

	@Override
	public List<HelpResponseVO> findHelps(HelpConditionVO helpConditionVO) {
		UserSessionVO session = SessionScopeUtil.getContextSession();
		return helpRepository.selectHelps(helpConditionVO, session);
	}

	@Override
	public HelpResponseVO findHelp(String id) {
		UserCompanySessionVO session = SessionScopeUtil.getCompanyContextSession();
		return helpRepository.selectHelp(id, session);
	}

	@Override
	public HelpResponseVO findHelpByPathName(String pathname) {
		return helpRepository.selectHelpByUrl(pathname);
	}

	@Override
	public DmlResponseVO createHelp(HelpRequestVO help) {
		UserSessionVO session = SessionScopeUtil.getContextSession();
		int insertRow = helpRepository.insertHelp(help, session);

		return DmlResponseVO.builder().insertedRows(insertRow).build();
	}

	@Override
	public DmlResponseVO updateHelp(String id, HelpRequestVO help) {
		UserSessionVO session = SessionScopeUtil.getContextSession();
		int updateRow = helpRepository.updateHelp(id, help, session);
		int deleteHelpFiles = helpRepository.deleteHelpFiles(help, session);

		return DmlResponseVO.builder().updatedRows(updateRow).build();
	}

	@Override
	public DmlResponseVO deleteHelp(String id) {
		int deleteRow = helpRepository.deleteHelp(id);

		return DmlResponseVO.builder().deletedRows(deleteRow).build();
	}

}
