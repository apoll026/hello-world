package com.gsenc.wsf.help.service;

import java.util.List;

import com.gsenc.wsf.common.model.DmlResponseVO;
import com.gsenc.wsf.help.model.HelpConditionVO;
import com.gsenc.wsf.help.model.HelpRequestVO;
import com.gsenc.wsf.help.model.HelpResponseVO;

public interface HelpService {
	List<HelpResponseVO> findHelps(HelpConditionVO helpConditionVO);

	HelpResponseVO findHelp(String id);

	HelpResponseVO findHelpByPathName(String pathname);

	DmlResponseVO createHelp(HelpRequestVO help);

	DmlResponseVO updateHelp(String id, HelpRequestVO help);

	DmlResponseVO deleteHelp(String id);
}
