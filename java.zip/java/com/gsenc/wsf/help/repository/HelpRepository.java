package com.gsenc.wsf.help.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.help.model.HelpConditionVO;
import com.gsenc.wsf.help.model.HelpRequestVO;
import com.gsenc.wsf.help.model.HelpResponseVO;
import com.gsenc.wsf.session.model.UserCompanySessionVO;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface HelpRepository {
	List<HelpResponseVO> selectHelps(
		@Param("helpCondition") HelpConditionVO helpConditionVO,
		@Param("session") UserSessionVO userSession
	);

	HelpResponseVO selectHelp(
		@Param("pgmId") String id,
		@Param("session") UserCompanySessionVO userSession
	);

	HelpResponseVO selectHelpByUrl(
		@Param("url") String pathname
	);

	int insertHelp(
		@Param("help") HelpRequestVO helpRequestVO,
		@Param("session") UserSessionVO userSession
	);

	int updateHelp(
		@Param("pgmId") String id,
		@Param("help") HelpRequestVO helpRequestVO,
		@Param("session") UserSessionVO userSession
	);

	int deleteHelp(
		@Param("pgmId") String id
	);

	int deleteHelpFiles(@Param("help") HelpRequestVO help, @Param("session") UserSessionVO session);
}
