package com.gsenc.wsf.help.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;
import com.gsenc.wsf.common.model.DmlResponseVO;
import com.gsenc.wsf.help.model.HelpConditionVO;
import com.gsenc.wsf.help.model.HelpRequestVO;
import com.gsenc.wsf.help.model.HelpResponseVO;
import com.gsenc.wsf.help.service.HelpService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "Help")
@Validated
@RequestMapping("/api")
public class HelpController {
	private final HelpService helpService;

	@Operation(summary = "도움말 목록 조회")
	@GetMapping(value = "/v1/helps", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<List<HelpResponseVO>>> findHelps(
		HelpConditionVO helpConditionVO
	) {
		return new ResponseEntity<>(CommonResponseVO.<List<HelpResponseVO>>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(helpService.findHelps(helpConditionVO))
			.build(), HttpStatus.OK);
	}

	@Operation(summary = "도움말 단건 조회")
	@GetMapping(value = "/v1/helps/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<HelpResponseVO>> findHelp(
		@PathVariable String id
	) {
		return new ResponseEntity<>(CommonResponseVO.<HelpResponseVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(helpService.findHelp(id))
			.build(), HttpStatus.OK);
	}

	@Operation(summary = "도움말 단건 조회 - 상세화면 URL")
	@GetMapping(value = "/v1/helps/by-url", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<HelpResponseVO>> findHelpByPathname(
		@RequestParam(value = "pathname") String pathname
	) {
		return new ResponseEntity<>(CommonResponseVO.<HelpResponseVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(helpService.findHelpByPathName(pathname))
			.build(), HttpStatus.OK);
	}

	@Operation(summary = "도움말 생성")
	@PostMapping(value = "/v1/helps", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<DmlResponseVO>> createHelp(
		@RequestBody HelpRequestVO help
	) {
		return new ResponseEntity<>(CommonResponseVO.<DmlResponseVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(helpService.createHelp(help))
			.build(), HttpStatus.OK);
	}

	@Operation(summary = "도움말 수정")
	@PutMapping(value = "/v1/helps/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<DmlResponseVO>> updateHelp(
		@PathVariable String id,
		@RequestBody HelpRequestVO help
	) {
		return new ResponseEntity<>(CommonResponseVO.<DmlResponseVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(helpService.updateHelp(id, help))
			.build(), HttpStatus.OK);
	}

	@Operation(summary = "도움말 삭제")
	@DeleteMapping(value = "/v1/helps/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<DmlResponseVO>> deleteHelp(
		@PathVariable String id
	) {
		return new ResponseEntity<>(CommonResponseVO.<DmlResponseVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(helpService.deleteHelp(id))
			.build(), HttpStatus.OK);
	}

}
