package com.gsenc.wsf.employee.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.wsf.common.model.DataWrapperVO;
import com.gsenc.wsf.common.util.RestResponseFactoryUtil;
import com.gsenc.wsf.employee.model.HrEmployeeIFVO;
import com.gsenc.wsf.employee.service.EmployeeIFService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequiredArgsConstructor
@Tag(name = "EmployeeIf")
@Validated
@Slf4j
@RequestMapping("/api")
public class EmployeeIFController {

	private final EmployeeIFService employeeIFService;

	@Operation(summary = "EmpBatch", description = "EmpBatch")
	@PostMapping(value = "/v1/emp-batch", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DataWrapperVO> migrateEmployees(@RequestBody DataWrapperVO<List<HrEmployeeIFVO>> emp,
		HttpServletRequest request) {

		return new ResponseEntity<>(
			RestResponseFactoryUtil.createReturnDataVO(
				employeeIFService.migrateEmployees(request, emp.getData().getRecord())),
			HttpStatus.OK);
	}

}
