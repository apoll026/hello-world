package com.gsenc.wsf.employee.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class HrEmployeeIFCUDList {
    List<HrEmployeeIFVO> insertList;
    List<HrEmployeeIFVO> updateList;
}
