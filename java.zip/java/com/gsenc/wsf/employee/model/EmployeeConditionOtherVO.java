package com.gsenc.wsf.employee.model;

import java.util.List;
import java.util.Map;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class EmployeeConditionOtherVO {

    @Schema(description = "검색어", example = "userId")
    private String i_USER_ID;

    @Schema(description = "부서코드", example = "userPass")
    private String i_USER_PASS;

    @Schema(description = "부서명", example = "고문실")
    List<Map<String, String>> out_List1;

}
