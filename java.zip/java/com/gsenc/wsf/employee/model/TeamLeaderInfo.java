package com.gsenc.wsf.employee.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class TeamLeaderInfo {
	@Schema(description = "사용자ID")
	String userId;
	@Schema(description = "사용자ID")
	String userNm;
}
