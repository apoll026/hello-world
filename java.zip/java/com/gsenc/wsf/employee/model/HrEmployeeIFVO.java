package com.gsenc.wsf.employee.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class HrEmployeeIFVO {
    @Schema(description = "EAI_SEQ_ID", example = "1")
    private long seqId;

    @Schema(description = "법인약어", example = "법인약어")
    private String subsidiaryCode;

    @Schema(description = "사번", example = "사번")
    private String employeeNumber;

    @Schema(description = "발령시작일", example = "발령시작일")
    private String effectiveStartDate;

    @Schema(description = "발령종료일", example = "발령종료일")
    private String effectiveEndDate;

    @Schema(description = "발령유형아이디", example = "발령유형아이디")
    private long assignmentStatusTypeId;

    @Schema(description = "성명", example = "성명")
    private String fullName;

    @Schema(description = "email 주소", example = "email 주소")
    private String emailAddress;

    @Schema(description = "직군", example = "직군")
    private String jikgun;

    @Schema(description = "SSO_USER_ID(MAIL_ID):SSO시스템전용", example = "SSO_USER_ID(MAIL_ID):SSO시스템전용")
    private String ssoUserId;

    @Schema(description = "노츠승인일자:SSO시스템전용", example = "노츠승인일자:SSO시스템전용")
    private String mailActionUpdate;

    @Schema(description = "그룹입사일", example = "그룹입사일")
    private String originalDateOfHire;

    @Schema(description = "현회사입사일", example = "현회사입사일")
    private String dateOfHire;

    @Schema(description = "직책코드", example = "직책코드")
    private String positionCode;

    @Schema(description = "직책명", example = "직책명")
    private String positionName;

    @Schema(description = "[관리안함] 직위코드", example = "[관리안함] 직위코드")
    private String jobTitleCode;

    @Schema(description = "[관리안함] 직위명", example = "[관리안함] 직위명")
    private String jobTitleName;

    @Schema(description = "직급코드", example = "직급코드")
    private String gradeTitleCode;

    @Schema(description = "직급명", example = "직급명")
    private String gradeTitle;

    @Schema(description = "휴퇴구분", example = "퇴사자")
    private String personType;

    @Schema(description = "휴직일자", example = "휴직일자")
    private String dateOfSuspend;

    @Schema(description = "퇴직일", example = "퇴직일")
    private String dateOfRetire;

    @Schema(description = "개인아이디", example = "개인아이디")
    private long personId;

    @Schema(description = "조직아이디", example = "조직아이디")
    private long organizationId;

    @Schema(description = "조직코드", example = "조직코드")
    private String organizationCode;

    @Schema(description = "조직명", example = "조직명")
    private String organizationName;

    @Schema(description = "상위조직아이디", example = "상위조직아이디")
    private long parentOrgId;

    @Schema(description = "상위부서코드", example = "상위부서코드")
    private String parentOrgCode;

    @Schema(description = "상위부서명", example = "상위부서명")
    private String parentOrgName;

    @Schema(description = "사업부아이디", example = "사업부아이디")
    private long divisionId;

    @Schema(description = "사업부명", example = "사업부명")
    private String divisionName;

    @Schema(description = "Supervisor", example = "Supervisor")
    private String jojikManager;

    @Schema(description = "[I-Project] 조직책임자", example = "[I-Project] 조직책임자")
    private String orgManager;

    @Schema(description = "[관리안함] 관리사업장 아이디", example = "[관리안함] 관리사업장 아이디")
    private long businessPlaceId;

    @Schema(description = "관리사업장", example = "관리사업장")
    private String businessPlaceName;

    @Schema(description = "한자명", example = "한자명")
    private String chineseName;

    @Schema(description = "영문명", example = "영문명")
    private String engName;

    @Schema(description = "집전화번호", example = "집전화번호")
    @JsonProperty("telephone_number_1")
    private String telephoneNumber1;

    @Schema(description = "핸드폰번호", example = "핸드폰번호")
    @JsonProperty("telephone_number_2")
    private String telephoneNumber2;

    @Schema(description = "사무실전화번호", example = "사무실전화번호")
    @JsonProperty("telephone_number_3")
    private String telephoneNumber3;

    @Schema(description = "결혼기념일", example = "결혼기념일")
    private String dateOfMarry;

    @Schema(description = "생일", example = "생일")
    private String dateOfBirth;

    @Schema(description = "생일구분", example = "생일구분")
    private String lsType;

    @Schema(description = "[I-Project] 기혼/미혼", example = "[I-Project] 기혼/미혼")
    private String maritalStatus;

    @Schema(description = "[관리안함] [I-Project] 본인전결(그룹장이상)FLAG", example = "[관리안함] [I-Project] 본인전결(그룹장이상)FLAG")
    private String selfApproveFlag;

    @Schema(description = "외부 email 주소", example = "외부 email 주소")
    private String externalEmail;

    @Schema(description = "정규직/계약구분", example = "정규직/계약구분")
    private String userPersonType;

    @Schema(description = "Employment 유형", example = "Employment 유형")
    private String employeeCategory;

    @Schema(description = "사업장아이디", example = "사업장아이디")
    private long establishmentId;

    @Schema(description = "사업장명", example = "사업장명")
    private String establishmentName;

    @Schema(description = "우편번호", example = "우편번호")
    private String postalCode;

    @Schema(description = "주소1", example = "주소1")
    private String addressLine1;

    @Schema(description = "주소2", example = "주소2")
    private String addressLine2;

    @Schema(description = "근무지명", example = "근무지명")
    private String locationName;

    @Schema(description = "회계 관리사업장", example = "회계 관리사업장")
    private String costBiz;

    @Schema(description = "회계 비용부서", example = "회계 비용부서")
    private String costOrg;

    @Schema(description = "회계 부서비용구분", example = "회계 부서비용구분")
    private String costGubun;

    @Schema(description = "SSO동기화 PWD:SSO시스템전용", example = "SSO동기화 PWD:SSO시스템전용")
    private String ssoPassword;

    @Schema(description = "FSE 해외 사번:해외시스템전용", example = "FSE 해외 사번:해외시스템전용")
    private String fseForeignsabun;

    @Schema(description = "사용자구분 - R(regular:GERP) / O(others:기타)", example = "사용자구분 - R(regular:GERP) / O(others:기타)")
    private String otherAction;

    @Schema(description = "동기화여부(Y or Null)", example = "동기화여부(Y or Null)")
    private String ssoAction;

    @Schema(description = "사용시작일 계약직/CNS/기타/파견직 사용시작일", example = "사용시작일 계약직/CNS/기타/파견직 사용시작일")
    private String otherStartDate;

    @Schema(description = "사용종료일 계약직/CNS/기타/파견직 사용종료일", example = "사용종료일 계약직/CNS/기타/파견직 사용종료일")
    private String otherEndDate;

    @Schema(description = "기타직 회사명", example = "기타직 회사명")
    private String originalCompany;

    @Schema(description = "인시스템 DML Flag,I(Insert),U(UPDATE), D(DELETE)", example = "인시스템 DML Flag,I(Insert),U(UPDATE), D(DELETE)")
    private String ehrInsertFlag;

    @Schema(description = "해외주재원 구분(Y/N)", example = "해외주재원 구분(Y/N)")
    private String fseFlag;

    @Schema(description = "FAX번호", example = "FAX번호")
    @JsonProperty("fax_telephone_number_1")
    private String faxTelephoneNumber1;

    @Schema(description = "닉네임", example = "닉네임")
    private String nickname;

    @Schema(description = "임직원 표직 순차코드", example = "임직원 표직 순차코드")
    private String personSosrtcode;

    @Schema(description = "조직CODE 닉네임(A,E사번용)", example = "조직CODE 닉네임(A,E사번용)")
    private String organizationNickCode;

    @Schema(description = "조직명 닉네임(A,E사번용)", example = "조직명 닉네임(A,E사번용)")
    private String organizationNickName;

    @Schema(description = "IMSG 승인일자", example = "IMSG 승인일자")
    private String imsgActionDate;

    @Schema(description = "경력유형코드", example = "경력유형코드")
    private String attribute1;

    @Schema(description = "경력인증일", example = "경력인증일")
    private String attribute2;

    @Schema(description = "노조조직코드", example = "노조조직코드")
    private String attribute3;

    @Schema(description = "노조조직명", example = "노조조직명")
    private String attribute4;

    @Schema(description = "노조직책명", example = "노조직책명")
    private String attribute5;

    @Schema(description = "노조직위코드", example = "노조직위코드")
    private String attribute6;

    @Schema(description = "노조직위명", example = "노조직위명")
    private String attribute7;

    @Schema(description = "FSE 국내사번", example = "FSE 국내사번")
    private String attribute8;

    @Schema(description = "해외구사번(노츠용)", example = "해외구사번(노츠용)")
    private String attribute9;

    @Schema(description = "휴퇴코드", example = "휴퇴코드")
    private String attribute10;

    @Schema(description = "해외구사번", example = "해외구사번")
    private String attribute11;

    @Schema(description = "조직명2", example = "조직명2")
    private String attribute12;

    @Schema(description = "GERP 사용여부(A,E사번)", example = "GERP 사용여부(A,E사번)")
    private String attribute13;

    @Schema(description = "추가정보예비14", example = "추가정보예비14")
    private String attribute14;

    @Schema(description = "추가정보예비15", example = "추가정보예비15")
    private String attribute15;

    @Schema(description = "추가정보예비16", example = "추가정보예비16")
    private String attribute16;

    @Schema(description = "추가정보예비17", example = "추가정보예비17")
    private String attribute17;

    @Schema(description = "추가정보예비18", example = "추가정보예비18")
    private String attribute18;

    @Schema(description = "추가정보예비19", example = "추가정보예비19")
    private String attribute19;

    @Schema(description = "추가정보예비20", example = "추가정보예비20")
    private String attribute20;

    @Schema(description = "추가정보예비24", example = "추가정보예비24")
    private String attribute24;

    @Schema(description = "생성일", example = "생성일")
    private String creationDate;

    @Schema(description = "수정일자", example = "수정일자")
    private String lastUpdateDate;

    @Schema(description = "EAI전송여부", example = "EAI전송여부")
    private String transferFlag11;

    @Schema(description = "EAI전송일시", example = "EAI전송일시")
    private String transferDate11;
}
