package com.gsenc.wsf.employee.service;

import java.util.List;

import com.gsenc.wsf.common.model.CommonRestResponseVO;
import com.gsenc.wsf.employee.model.HrEmployeeIFVO;

import jakarta.servlet.http.HttpServletRequest;

public interface EmployeeIFService {
	CommonRestResponseVO migrateEmployees(HttpServletRequest request, List<HrEmployeeIFVO> hrInnoEmployeeVOList);
}
