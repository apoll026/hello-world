package com.gsenc.wsf.employee.service;

import java.util.List;

import com.gsenc.wsf.common.exception.BusinessException;
import com.gsenc.wsf.employee.model.BbsEmployeeResponseVO;
import com.gsenc.wsf.employee.model.EmployeeConditionVO;
import com.gsenc.wsf.employee.model.TeamLeaderInfo;
import com.gsenc.wsf.session.model.EmployeeVO;

public interface EmployeeService {

	EmployeeVO selectEmployeeByUserId(String userId) throws BusinessException;

	EmployeeVO selectEmployeeByUserIdOther(String userId, String userPass) throws BusinessException;

	EmployeeVO selectEmployeeByEmpNo(String empNo) throws BusinessException;

	List<EmployeeVO> searchEmployees(EmployeeConditionVO employeeCondition) throws BusinessException;

	BbsEmployeeResponseVO findBbsEmployeeByUserId(String userId, String langCd);

	String getUserInfo();

	TeamLeaderInfo findTeamLeaderIdByDeptCd(String deptCd);

	String getUserInfo2();

}
