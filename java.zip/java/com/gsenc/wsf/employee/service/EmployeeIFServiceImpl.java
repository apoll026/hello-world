package com.gsenc.wsf.employee.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonRestResponseVO;
import com.gsenc.wsf.common.util.BatchUtil;
import com.gsenc.wsf.common.util.NetworkUtil;
import com.gsenc.wsf.employee.model.HrEmployeeIFCUDList;
import com.gsenc.wsf.employee.model.HrEmployeeIFVO;
import com.gsenc.wsf.employee.repository.EmployeeIFRepository;
import com.gsenc.wsf.log.model.IfLogVO;
import com.gsenc.wsf.log.service.LogService;

import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class EmployeeIFServiceImpl implements EmployeeIFService {

	private final ApplicationContext applicationContext;

	private final LogService logService;
	private final EmployeeIFRepository employeeIFRepository;

	@Transactional(rollbackFor = {Exception.class})
	public CommonRestResponseVO migrateEmployees(HttpServletRequest request, List<HrEmployeeIFVO> hrEmployeeIFVOList) {

		CommonRestResponseVO resultVO = CommonRestResponseVO.builder()
			.o_ret_code("S")
			.o_ret_msg(StatusCodeConstants.SUCCESS)
			.build();

		IfLogVO ifLog = IfLogVO.builder()
			.ifNm("HR-EMP")
			.ifDivsCd("BATCH")
			.ifTrmtValCtn("")
			.ifRestValCtn(hrEmployeeIFVOList.toString())
			.dataInsUserId("Batch")
			.dataInsUserIp(NetworkUtil.getClientIP(request))
			.build();

		EmployeeIFServiceImpl proxy = applicationContext.getBean(EmployeeIFServiceImpl.class);

		try {
			proxy.createHrEmployeeI(hrEmployeeIFVOList);

			HrEmployeeIFCUDList hrEmployeeCUDList = this.getHrEmployeeCUDList();
			this.updateEmployeeMaster(hrEmployeeCUDList.getUpdateList());
			this.createEmployeeMaster(hrEmployeeCUDList.getInsertList());

			employeeIFRepository.updateEmpITranfered();

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			resultVO.setO_ret_code("E");
			resultVO.setO_ret_msg("EXCEPTION");
			ifLog.setIfTrmtValCtn(e.getMessage());
		} finally {

			ifLog.setOptValNm1(resultVO.getO_ret_code());
			ifLog.setOptValNm2(resultVO.getO_ret_msg());

			logService.createIfLog(ifLog);

		}

		return resultVO;

	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void createHrEmployeeI(List<HrEmployeeIFVO> hrEmployeeIFVOList) {
		int loopCount = BatchUtil.getBatchLoopCount(hrEmployeeIFVOList.size());
		for (int i = 0; i < loopCount; i++) {
			List<HrEmployeeIFVO> batchList = BatchUtil.getSubList(hrEmployeeIFVOList, i);
			employeeIFRepository.insertHrEmployeeI(batchList);
		}
	}

	private HrEmployeeIFCUDList getHrEmployeeCUDList() {
		List<HrEmployeeIFVO> hrEmployeeTargetList = employeeIFRepository.selectEmployeeI();
		List<HrEmployeeIFVO> hrEmployeeInsertlist = new ArrayList<>();
		List<HrEmployeeIFVO> hrEmployeeUpdatelist = new ArrayList<>();
		for (HrEmployeeIFVO hrEmployeeVO : hrEmployeeTargetList) {
			if (employeeIFRepository.selectEmployeeMCount(hrEmployeeVO.getEmployeeNumber()) > 0) {
				hrEmployeeUpdatelist.add(hrEmployeeVO);
			} else {
				hrEmployeeInsertlist.add(hrEmployeeVO);
			}
		}

		return new HrEmployeeIFCUDList(hrEmployeeInsertlist, hrEmployeeUpdatelist);
	}

	private void updateEmployeeMaster(List<HrEmployeeIFVO> hrEmployeeUpdatelist) {
		if (!hrEmployeeUpdatelist.isEmpty()) {
			int batchCountEmpUpdate = BatchUtil.getBatchLoopCount(hrEmployeeUpdatelist.size());
			for (int i = 0; i < batchCountEmpUpdate; i++) {
				List<HrEmployeeIFVO> batchList = BatchUtil.getSubList(hrEmployeeUpdatelist, i);

				for (int j = 0; j < batchList.size(); j++) {
					employeeIFRepository.updateEmpMaster(batchList.subList(j, j + 1));
				}
			}
		}
	}

	private void createEmployeeMaster(List<HrEmployeeIFVO> hrEmployeeInsertlist) {
		if (!hrEmployeeInsertlist.isEmpty()) {
			int batchCountEmpInsert = BatchUtil.getBatchLoopCount(hrEmployeeInsertlist.size());
			for (int i = 0; i < batchCountEmpInsert; i++) {
				List<HrEmployeeIFVO> batchList = BatchUtil.getSubList(hrEmployeeInsertlist, i);
				employeeIFRepository.insertEmpMaster(batchList);
			}
		}
	}

}
