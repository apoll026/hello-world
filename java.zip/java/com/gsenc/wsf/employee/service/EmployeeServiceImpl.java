package com.gsenc.wsf.employee.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.wsf.common.exception.BusinessException;
import com.gsenc.wsf.common.util.FormatUtil;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.employee.model.BbsEmployeeResponseVO;
import com.gsenc.wsf.employee.model.EmployeeConditionOtherVO;
import com.gsenc.wsf.employee.model.EmployeeConditionVO;
import com.gsenc.wsf.employee.model.TeamLeaderInfo;
import com.gsenc.wsf.employee.repository.EmployeeRepository;
import com.gsenc.wsf.session.model.EmployeeVO;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class EmployeeServiceImpl implements EmployeeService {

	private final EmployeeRepository employeeRepository;

	@Override
	@Transactional(readOnly = true)
	public EmployeeVO selectEmployeeByUserId(String userId) throws BusinessException {
		return employeeRepository.selectEmployeeByUserId(userId);
	}

	@Override
	@Transactional(readOnly = true)
	public EmployeeVO selectEmployeeByUserIdOther(String userId, String userPass) throws BusinessException {

		EmployeeVO empVo = new EmployeeVO();
		EmployeeConditionOtherVO paramVO = new EmployeeConditionOtherVO();
		paramVO.setI_USER_ID(userId);
		paramVO.setI_USER_PASS(userPass);
		paramVO.setOut_List1(null);

		employeeRepository.selectEmployeeByUserIdOther(paramVO);
		if (paramVO.getOut_List1() != null) {
			for (Map<String, String> list : paramVO.getOut_List1()) {
				log.info(" list key getAcct_name :: {} ", list.get("cmpnNum"));
				empVo.setCmpnCode(list.get("cmpnCode"));
				empVo.setCmpnNum(list.get("cmpnNum"));
			}
		}
		return empVo;
	}

	@Override
	@Transactional(readOnly = true)
	public EmployeeVO selectEmployeeByEmpNo(String empNo) throws BusinessException {
		return employeeRepository.selectEmployeeByEmpNo(empNo);
	}

	@Override
	@Transactional(readOnly = true)
	public List<EmployeeVO> searchEmployees(EmployeeConditionVO employeeCondition) throws BusinessException {
		UserSessionVO userSession = SessionScopeUtil.getContextSession();

		List<EmployeeVO> employeeList = employeeRepository.searchEmployees(employeeCondition, userSession);
		return employeeList;
	}

	@Override
	@Transactional(readOnly = true)
	public BbsEmployeeResponseVO findBbsEmployeeByUserId(String userId, String langCd) throws BusinessException {
		BbsEmployeeResponseVO bbsEmployee = employeeRepository.selectBbsEmployeeByUserId(userId, langCd);
		String email = FormatUtil.getEmployeeEmail(bbsEmployee.getMailId(), bbsEmployee.getEmpNo());
		bbsEmployee.setEmail(email);
		return bbsEmployee;
	}

	@Override
	@Transactional(readOnly = true)
	public String getUserInfo() {
		UserSessionVO userSession = SessionScopeUtil.getContextSession();
		return employeeRepository.selectUserInfo(userSession.getLangCd(), userSession);
	}

	@Override
	@Transactional(readOnly = true)

	public TeamLeaderInfo findTeamLeaderIdByDeptCd(String deptCd) {
		UserSessionVO session = SessionScopeUtil.getContextSession();
		return employeeRepository.selectTeamLeaderIdByDeptCd(deptCd, session.getLangCd());
	}

	@Override
	public String getUserInfo2() {
		UserSessionVO userSession = SessionScopeUtil.getContextSession();
		return employeeRepository.selectUserInfo2(userSession.getLangCd(), userSession);
	}
}
