package com.gsenc.wsf.employee.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gsenc.wsf.employee.model.HrEmployeeIFVO;

@Mapper
public interface EmployeeIFRepository {

    int updateEmpITranfered();

    int insertHrEmployeeI(List<HrEmployeeIFVO> hrEmployee);

    List<HrEmployeeIFVO>selectEmployeeI();

    int selectEmployeeMCount(String empNo);

    int updateEmpMaster(List<HrEmployeeIFVO> hrEmployeeList);

    int insertEmpMaster(List<HrEmployeeIFVO> hrEmployeeList);
}
