package com.gsenc.wsf.employee.repository;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.employee.model.BbsEmployeeResponseVO;
import com.gsenc.wsf.employee.model.EmployeeConditionOtherVO;
import com.gsenc.wsf.employee.model.EmployeeConditionVO;
import com.gsenc.wsf.employee.model.TeamLeaderInfo;
import com.gsenc.wsf.session.model.EmployeeVO;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface EmployeeRepository {

	EmployeeVO selectEmployeeByUserId(String userId);

	void selectEmployeeByUserIdOther (EmployeeConditionOtherVO paramVO);

	EmployeeVO selectEmployeeByEmpNo(String empNo);

	List<EmployeeVO> searchEmployees(@Param("condition") EmployeeConditionVO condition,
		@Param("session") UserSessionVO userSession);

	BbsEmployeeResponseVO selectBbsEmployeeByUserId(@Param("mailId") String userId, @Param("langCd") String langCd);

	String selectUserInfo(@Param("langCd") String langCd, @Param("session") UserSessionVO userSession);

	TeamLeaderInfo selectTeamLeaderIdByDeptCd(@Param("deptCd") String deptCd, @Param("langCd") String langCd);

	String selectUserInfo2(@Param("langCd") String langCd, @Param("session") UserSessionVO userSession);

	String selectEmpNoToUserId(String empNo);

	String selectUserIdToEmpNo(String userId);

}
