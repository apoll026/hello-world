package com.gsenc.wsf.listener;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import jakarta.servlet.http.HttpSessionEvent;
import jakarta.servlet.http.HttpSessionListener;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class SessionListener implements HttpSessionListener {

	@Value("${server.servlet.session.timeout}")
	private int sessionTimeout;

	@Override
	public void sessionCreated(HttpSessionEvent se) {
		se.getSession().setMaxInactiveInterval(sessionTimeout);
		log.info("Session Created : {}, Session Timeout : {}s", se.getSession().getId(),
			se.getSession().getMaxInactiveInterval());
	}
}
