package com.gsenc.wsf.bbs.model;

import lombok.*;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class BbsReplyVO {
    private String bbsNo;
    private String bbsReNo;
    private String bbsReCtn;
    private String dataInsDtm;
    private String dataInsUserId;
}
