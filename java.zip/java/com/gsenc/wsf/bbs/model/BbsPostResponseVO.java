package com.gsenc.wsf.bbs.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class BbsPostResponseVO {

    @Schema(description = "게시물 번호")
    private String bbsNo;

    @Schema(description = "게시물 번호")
    private String rank;

    @Schema(description = "게시판 분류 코드")
    private String bbsTpCd;

    @Schema(description = "게시판 분류 명")
    private String bbsTpNm;

    @Schema(description = "제목")
    private String bbsTitle;

    @Schema(description = "내용")
    private String bbsCtn;

    @Schema(description = "첨부파일 유무")
    private String atchFileExist;

    @Schema(description = "첨부파일그룹ID")
    private String atchFileGrId;

    @Schema(description = "데이터입력사용자ID")
    private String dataInsUserId;

    @Schema(description = "작성자")
    private String dataInsUserInfo;

    @Schema(description = "작성일")
    private String dataInsDtm;

    @Schema(description = "조회수")
    private String bbsVwct;

    @Schema(description = "게시종료일자", example ="20230516")
    private String ptupEndDt;

    @Schema(description = "팝업게시시작일시", example ="2023-05-16 12:00:00")
    private String poupStDtm;

    @Schema(description = "팝업게시종료일시", example ="2023-05-16 12:00:00")
    private String poupEndDtm;

    @Schema(description = "팝업노출미사용일수")
    private String poupEpsNuseDdn;

    @Schema(description = "대상법인이름")
    private String ptupTgtCopNm;

    @Schema(description = "댓글수")
    private String bbsReplyct;

    @Schema(description = "읽음/읽지않음")
    private String readYn;

    @Schema(description = "미리보기 텍스트")
    private String smryCtn;

    @Schema(description = "본문 첫 img 태그")
    private String firstImgTag;

    @Schema(description = "상단 고정 여부", example ="N")
    private String imptYn;

    @Schema(description = "답글 여부", example ="N")
    private String reBbsYN;

    @Schema(description = "원 게시물 번호", example ="1")
    private String prntReBbsNo;

}
