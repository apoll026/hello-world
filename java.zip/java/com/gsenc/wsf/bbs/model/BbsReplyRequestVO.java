package com.gsenc.wsf.bbs.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class BbsReplyRequestVO {

	@NotBlank
	@Schema(description = "게시글번호", example = "1")
	private String bbsNo;

	@NotBlank
	@Schema(description = "게시글댓글번호", example = "1")
	private String bbsReNo;

	@NotBlank
	@Schema(description = "부모댓글번호", example = "1")
	private String prntReNo;

	@NotBlank
	@Schema(description = "게시글댓글내용", example = "안녕하세요")
	private String bbsReCtn;

}
