package com.gsenc.wsf.bbs.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class BbsPostRequestVO {

    @Schema(description = "게시물 번호", example = "1")
    private String bbsNo;

    @Schema(description = "게시판유형코드", example = "NOTI")
    private String bbsTpCd;

    @Schema(description = "게시대상법인코드", example = "C100")
    private String ptupTgtCopCd;

    @Schema(description = "게시대상법인명", example = "㈜LG화학")
    private String ptupTgtCopNm;

    @Schema(description = "제목", example = "공지사항1")
    private String bbsTitle;

    @Schema(description = "내용", example ="내용1")
    private String bbsCtn;

    @Schema(description = "첨부파일그룹ID", example ="1")
    private String atchFileGrId;

    @Schema(description = "게시종료일자", example ="20230516")
    private String ptupEndDt;

    @Schema(description = "팝업게시시작일시", example ="2023-05-16 12:00:00")
    private String poupStDtm;

    @Schema(description = "팝업게시종료일시", example ="2023-05-16 12:00:00")
    private String poupEndDtm;

    @Schema(description = "팝업노출미사용일수", example = "7")
    private String poupEpsNuseDdn;

    @Schema(description = "상단 고정 여부", example ="N")
    private String imptYn;

    @Schema(description = "답글 여부", example ="N")
    private String reBbsYN;

    @Schema(description = "원 게시물 번호", example ="1")
    private String prntReBbsNo;

}
