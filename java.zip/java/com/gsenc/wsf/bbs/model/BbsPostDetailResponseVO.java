package com.gsenc.wsf.bbs.model;

import java.util.List;

import com.gsenc.wsf.employee.model.BbsEmployeeResponseVO;
import com.gsenc.wsf.file.model.FileVO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class BbsPostDetailResponseVO {

    @Schema(description = "게시물 번호")
    private String bbsNo;

    @Schema(description = "조회수")
    private String bbsVwct;

    @Schema(description = "작성자")
    private BbsEmployeeResponseVO dataInsUser;

    @Schema(description = "작성일")
    private String dataInsDtm;

    @Schema(description = "수정자")
    private BbsEmployeeResponseVO dataUpdUser;

    @Schema(description = "수정일")
    private String dataUpdDtm;

    @Schema(description = "게시판 분류 코드")
    private String bbsTpCd;

    @Schema(description = "게시판 분류 명")
    private String bbsTpNm;

    @Schema(description = "게시대상법인코드")
    private String ptupTgtCopCd;

    @Schema(description = "게시대상법인명")
    private String ptupTgtCopNm;

    @Schema(description = "제목")
    private String bbsTitle;

    @Schema(description = "내용")
    private String bbsCtn;

    @Schema(description = "첨부파일 목록")
    private List<FileVO> atchFiles;

    @Schema(description = "첨부파일그룹ID")
    private String atchFileGrId;

    @Schema(description = "게시종료일자")
    private String ptupEndDt;

    @Schema(description = "댓글 목록")
    private List<BbsReplyResponseVO> replies;

    @Schema(description = "답글 여부", example ="N")
    private String reBbsYN;

    @Schema(description = "원 게시물 번호", example ="1")
    private String prntReBbsNo;

    @Schema(description = "팝업게시시작일시")
    private String poupStDtm;

    @Schema(description = "팝업게시종료일시")
    private String poupEndDtm;

    @Schema(description = "팝업노출미사용일수")
    private String poupEpsNuseDdn;

    @Schema(description = "상단 고정 여부")
    private String imptYn;




    public BbsPostDetailResponseVO(BbsPostDetailVO bbsDetail,
                                      BbsEmployeeResponseVO insertUser,
                                      BbsEmployeeResponseVO updateUser,
                                      List<FileVO> atchFiles ) {

        this.bbsNo = bbsDetail.getBbsNo();
        this.bbsVwct = bbsDetail.getBbsVwct();
        this.dataInsUser = insertUser;
        this.dataInsDtm = bbsDetail.getDataInsDtm();
        this.dataUpdUser = updateUser;
        this.dataUpdDtm = bbsDetail.getDataUpdDtm();
        this.bbsTpCd = bbsDetail.getBbsTpCd();
        this.bbsTpNm = bbsDetail.getBbsTpNm();
        this.ptupTgtCopCd = bbsDetail.getPtupTgtCopCd();
        this.ptupTgtCopNm = bbsDetail.getPtupTgtCopNm();
        this.bbsTitle = bbsDetail.getBbsTitle();
        this.bbsCtn = bbsDetail.getBbsCtn();
        this.atchFiles = atchFiles;
        this.atchFileGrId = bbsDetail.getAtchFileGrId();
        this.ptupEndDt = bbsDetail.getPtupEndDt();
        this.poupStDtm = bbsDetail.getPoupStDtm();
        this.poupEndDtm = bbsDetail.getPoupEndDtm();
        this.poupEpsNuseDdn = bbsDetail.getPoupEpsNuseDdn();
        this.prntReBbsNo = bbsDetail.getPrntReBbsNo();
        this.imptYn = bbsDetail.getImptYn();
    }
}
