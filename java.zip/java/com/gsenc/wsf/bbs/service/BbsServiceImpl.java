package com.gsenc.wsf.bbs.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.text.StringEscapeUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gsenc.wsf.bbs.model.BbsConditionVO;
import com.gsenc.wsf.bbs.model.BbsPostDetailResponseVO;
import com.gsenc.wsf.bbs.model.BbsPostDetailVO;
import com.gsenc.wsf.bbs.model.BbsPostRequestVO;
import com.gsenc.wsf.bbs.model.BbsPostResponseVO;
import com.gsenc.wsf.bbs.repository.BbsRepository;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.exception.BusinessException;
import com.gsenc.wsf.common.model.PaginationResponseVO;
import com.gsenc.wsf.common.util.NamoEditorHtmlUtil;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.common.util.StringUtil;
import com.gsenc.wsf.common.util.ValidateUtil;
import com.gsenc.wsf.employee.model.BbsEmployeeResponseVO;
import com.gsenc.wsf.employee.service.EmployeeService;
import com.gsenc.wsf.file.model.FileVO;
import com.gsenc.wsf.file.service.FileService;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class BbsServiceImpl implements BbsService {

	private final BbsRepository bbsRepository;
	private final EmployeeService employeeService;
	private final FileService fileService;

	@Override
	@Transactional(readOnly = true)
	public PaginationResponseVO<BbsPostResponseVO> findBbs(BbsConditionVO bbsCondition) {
		UserSessionVO userSession = SessionScopeUtil.getContextSession();
		List<BbsPostResponseVO> bbsList = bbsRepository.selectBbsPosts(bbsCondition, userSession);

		Pattern pattern = Pattern.compile("(&lt;img.*?src=&quot;(.*?)&quot;.*?&gt;)|(<img.*?src=\"(.*?)\".*?>)");

		for (BbsPostResponseVO bbs : bbsList) {

			String firstImgSrc = null;

			String smryBbsCtn = StringUtil.removeHtmlTagsForBbs(bbs.getBbsCtn())
				.replaceAll("&nbsp;", "")
				.replaceAll("&amp;nbsp;", "");
			String whiteSpaceRemoved = StringEscapeUtils.unescapeHtml4(smryBbsCtn).replaceAll("\\s", "");
			bbs.setSmryCtn(whiteSpaceRemoved);

			bbs.setBbsCtn(NamoEditorHtmlUtil.updateCtnWithPreSignedUrls(bbs.getBbsCtn(), fileService)); // ctn에 붙여넣기
			String bbsCtn = StringEscapeUtils.unescapeHtml4(bbs.getBbsCtn());
			Matcher matcher = pattern.matcher(bbsCtn);
			if (matcher.find()) {
				firstImgSrc = matcher.group(2) != null ? matcher.group(2) : matcher.group(4);
			}
			bbs.setFirstImgTag(firstImgSrc);

			bbs.setBbsCtn(bbsCtn);
		}
		PaginationResponseVO<BbsPostResponseVO> bbsPaginationList = new PaginationResponseVO<>(bbsList);
		bbsPaginationList.setTotalCount(bbsRepository.selectBbsPostsCount(bbsCondition, userSession));
		return bbsPaginationList;
	}

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public BbsPostDetailResponseVO findBbsPost(int bbsNo) {

		UserSessionVO userSession = SessionScopeUtil.getContextSession();
		BbsPostDetailVO bbs = Optional.ofNullable(bbsRepository.selectBbsPost(bbsNo, userSession.getLangCd()))
			.orElseThrow(
				() -> new BusinessException("The post doesn't exist", StatusCodeConstants.NOT_EXIST_EXCEPTION));

		BbsEmployeeResponseVO insertUser = employeeService.findBbsEmployeeByUserId(bbs.getDataInsUserId(),
			userSession.getLangCd());
		BbsEmployeeResponseVO updateUser = employeeService.findBbsEmployeeByUserId(bbs.getDataUpdUserId(),
			userSession.getLangCd());
		bbs.setBbsCtn(NamoEditorHtmlUtil.updateCtnWithPreSignedUrls(bbs.getBbsCtn(), fileService));//ctn에 붙여넣기
		List<FileVO> atchFiles = fileService.findFiles(bbs.getAtchFileGrId());

		bbsRepository.updateBbsPostVwct(bbsNo);

		bbs.setBbsCtn(ValidateUtil.charUnescape(bbs.getBbsCtn()));
		return new BbsPostDetailResponseVO(bbs, insertUser, updateUser, atchFiles);
	}

	@Override
	@Transactional(readOnly = true)
	public List<BbsPostDetailResponseVO> findBbsPopupPost() {

		List<BbsPostDetailResponseVO> bbsPopupResponseList = new ArrayList<>();
		List<BbsPostDetailVO> bbsPopupList = bbsRepository.selectBbsPopupPost();
		for (BbsPostDetailVO bbs : bbsPopupList) {
			bbs.setBbsCtn(NamoEditorHtmlUtil.updateCtnWithPreSignedUrls(bbs.getBbsCtn(), fileService));//ctn에 붙여넣기
		}

		for (BbsPostDetailVO bbsPost : bbsPopupList) {
			bbsPost.setBbsCtn(ValidateUtil.charUnescape(bbsPost.getBbsCtn()));
			bbsPopupResponseList.add(new BbsPostDetailResponseVO(bbsPost, null, null, null));
		}
		return bbsPopupResponseList;
	}

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public int createBbsPost(BbsPostRequestVO bbsVO) {
		UserSessionVO UserSessionVO = SessionScopeUtil.getContextSession();
		return bbsRepository.insertBbsPost(bbsVO, UserSessionVO);
	}

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public int modifyBbsPost(BbsPostRequestVO bbsVO) {
		UserSessionVO UserSessionVO = SessionScopeUtil.getContextSession();

		BbsPostDetailVO postDetail = bbsRepository.selectBbsPost(Integer.parseInt(bbsVO.getBbsNo()),
			UserSessionVO.getLangCd());
		if (postDetail == null) {
			throw new BusinessException("The post doesn't exist", StatusCodeConstants.NOT_EXIST_EXCEPTION);
		}
		if (!postDetail.getDataInsUserId().equals(UserSessionVO.getMailId())) {
			throw new BusinessException("User does not have permission to update",
				StatusCodeConstants.NOT_AUTHORIZED_EXCEPTION);
		}

		return bbsRepository.updateBbsPost(bbsVO, UserSessionVO);
	}

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public int removeBbsPost(int bbsNo) {
		UserSessionVO UserSessionVO = SessionScopeUtil.getContextSession();
		BbsPostDetailVO postDetail = bbsRepository.selectBbsPost(bbsNo, UserSessionVO.getLangCd());
		if (postDetail == null) {
			throw new BusinessException("The post doesn't exist", StatusCodeConstants.NOT_EXIST_EXCEPTION);
		}
		if (postDetail.getDataInsUserId() == null || !postDetail.getDataInsUserId().equals(UserSessionVO.getMailId())) {
			throw new BusinessException("User does not have permission to delete",
				StatusCodeConstants.NOT_AUTHORIZED_EXCEPTION);
		}
		return bbsRepository.deleteBbsPost(bbsNo, UserSessionVO);
	}

}
