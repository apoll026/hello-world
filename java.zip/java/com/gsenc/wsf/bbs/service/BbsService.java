package com.gsenc.wsf.bbs.service;

import java.util.List;

import com.gsenc.wsf.bbs.model.BbsConditionVO;
import com.gsenc.wsf.bbs.model.BbsPostDetailResponseVO;
import com.gsenc.wsf.bbs.model.BbsPostRequestVO;
import com.gsenc.wsf.bbs.model.BbsPostResponseVO;
import com.gsenc.wsf.common.model.PaginationResponseVO;

public interface BbsService {

    PaginationResponseVO<BbsPostResponseVO> findBbs(BbsConditionVO bbsCondition);

    BbsPostDetailResponseVO findBbsPost(int bbmNo);

    List<BbsPostDetailResponseVO> findBbsPopupPost();

    int createBbsPost(BbsPostRequestVO bbsVO);

    int modifyBbsPost(BbsPostRequestVO bbsVO);

    int removeBbsPost(int bbmNo);

}
