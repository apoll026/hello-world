package com.gsenc.wsf.bbs.service;

import java.util.List;

import com.gsenc.wsf.bbs.model.BbsReplyRequestVO;
import com.gsenc.wsf.bbs.model.BbsReplyResponseVO;

public interface BbsReplyService {

    int createBbsReply(BbsReplyRequestVO bbsReplyRequest);

    int removeBbsReply(String bbsNo, String bbsReNo);

    int modifyBbsReply(BbsReplyRequestVO bbsReplyRequestVO);

    List<BbsReplyResponseVO> findBbsReplies(int bbsNo);
}
