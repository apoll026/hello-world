package com.gsenc.wsf.bbs.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gsenc.wsf.bbs.model.BbsReplyRequestVO;
import com.gsenc.wsf.bbs.model.BbsReplyResponseVO;
import com.gsenc.wsf.bbs.model.BbsReplyVO;
import com.gsenc.wsf.bbs.repository.BbsReplyRepository;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.exception.BusinessException;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.employee.model.BbsEmployeeResponseVO;
import com.gsenc.wsf.employee.repository.EmployeeRepository;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;

@Service("bbsReplyServiceImpl")
@RequiredArgsConstructor
public class BbsReplyServiceImpl implements BbsReplyService {

	private final BbsReplyRepository bbsReplyRepository;
	@Override
	@Transactional(rollbackFor = {Exception.class})
	public int createBbsReply(BbsReplyRequestVO bbsReplyRequest) {
		UserSessionVO userSession = SessionScopeUtil.getContextSession();
		return bbsReplyRepository.insertBbsReply(bbsReplyRequest, userSession);
	}

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public int removeBbsReply(String bbsNo, String relseReNo) {

		int result = 0;
		UserSessionVO userSession = SessionScopeUtil.getContextSession();
		if (userSession.getRoleCodes().contains("ADM")) {
			result = bbsReplyRepository.deleteBbsReply(bbsNo, relseReNo);
		} else {
			BbsReplyVO replyToDelete = bbsReplyRepository.selectBbsReply(bbsNo, relseReNo);
			if (replyToDelete.getDataInsUserId() == null || !replyToDelete.getDataInsUserId()
				.equals(userSession.getMailId())) {
				throw new BusinessException("User does not have permission to delete",
					StatusCodeConstants.NOT_AUTHORIZED_EXCEPTION);
			}
			result = bbsReplyRepository.deleteBbsReply(bbsNo, relseReNo);
		}

		return result;
	}

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public int modifyBbsReply(BbsReplyRequestVO bbsReplyRequestVO) {
		UserSessionVO userSession = SessionScopeUtil.getContextSession();

		BbsReplyVO reply = bbsReplyRepository.selectBbsReply(bbsReplyRequestVO.getBbsNo(),
			bbsReplyRequestVO.getBbsReNo());
		if (reply == null) {
			throw new BusinessException("The reply doesn't exist", StatusCodeConstants.NOT_EXIST_EXCEPTION);
		}
		if (!reply.getDataInsUserId().equals(userSession.getMailId())) {
			throw new BusinessException("User does not have permission to update",
				StatusCodeConstants.NOT_AUTHORIZED_EXCEPTION);
		}

		return bbsReplyRepository.updateBbsReply(bbsReplyRequestVO, userSession);
	}

	@Override
	public List<BbsReplyResponseVO> findBbsReplies(int bbsNo) {
		String prntReNo = "-1"; //부모 댓글번호(대댓글 세팅용)
		//세션
		UserSessionVO userSession = SessionScopeUtil.getContextSession();
		//댓글 조회
		List<BbsReplyResponseVO> replies = bbsReplyRepository.selectBbsReplies(prntReNo, bbsNo,
			userSession.getLangCd());
		//대댓글 세팅
		for (int i = 0; i < replies.size(); i++) {
			prntReNo = replies.get(i).getBbsReNo();
			//대댓글 조회
			List<BbsReplyResponseVO> reReplies = bbsReplyRepository.selectBbsReplies(prntReNo, bbsNo,
				userSession.getLangCd());
			replies.get(i).setReReplies(reReplies);
		}
		return replies;
	}
}
