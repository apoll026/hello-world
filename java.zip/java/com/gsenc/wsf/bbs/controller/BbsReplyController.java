package com.gsenc.wsf.bbs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.gsenc.wsf.bbs.model.BbsReplyRequestVO;
import com.gsenc.wsf.bbs.model.BbsReplyResponseVO;
import com.gsenc.wsf.bbs.service.BbsReplyService;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;
import com.gsenc.wsf.common.model.DmlResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;

@RestController
@Tag(name = "Reply")
@Validated
@RequestMapping("/api")

public class BbsReplyController {

	private final BbsReplyService bbsReplyService;

	public BbsReplyController(@Qualifier("bbsReplyServiceImpl") BbsReplyService bbsReplyService) {
		this.bbsReplyService = bbsReplyService;
	}

	@Operation(summary = "게시글 댓글 생성")
	@PostMapping(value = "/v1/bbs/reply", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<DmlResponseVO>> createReply(
		@RequestBody @Valid BbsReplyRequestVO bbsReplyRequest) {
		return new ResponseEntity<>(CommonResponseVO.<DmlResponseVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(DmlResponseVO.builder()
				.insertedRows(bbsReplyService.createBbsReply(bbsReplyRequest))
				.build())
			.build(), HttpStatus.OK);
	}

	@Operation(summary = "게시글 댓글 삭제")
	@DeleteMapping(value = "/v1/bbs/reply/{bbmNo}/{bbmReNo}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<DmlResponseVO>> removeReply(@PathVariable @NotBlank String bbmNo,
		@PathVariable @NotBlank String bbmReNo) {
		return new ResponseEntity<>(CommonResponseVO.<DmlResponseVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(DmlResponseVO.builder()
				.deletedRows(bbsReplyService.removeBbsReply(bbmNo, bbmReNo))
				.build())
			.build(), HttpStatus.OK);
	}

	@Operation(summary = "게시글 댓글 수정")
	@PutMapping(value = "/v1/bbs/reply", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<DmlResponseVO>> modifyReply(
		@RequestBody @Valid BbsReplyRequestVO bbsReplyRequest) {
		return new ResponseEntity<>(CommonResponseVO.<DmlResponseVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(DmlResponseVO.builder()
				.updatedRows(bbsReplyService.modifyBbsReply(bbsReplyRequest))
				.build())
			.build(), HttpStatus.OK);
	}

	@Operation(summary = "게시글 댓글 목록 조회")
	@GetMapping(value = "/v1/bbs/reply/{bbmNo}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<List<BbsReplyResponseVO>>> findBbsReplies(
		@PathVariable @NotBlank String bbmNo) {
		return new ResponseEntity<>(CommonResponseVO.<List<BbsReplyResponseVO>>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(bbsReplyService.findBbsReplies(Integer.parseInt(bbmNo)))
			.build(), HttpStatus.OK);
	}
}
