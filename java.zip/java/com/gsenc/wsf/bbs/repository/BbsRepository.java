package com.gsenc.wsf.bbs.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.bbs.model.BbsConditionVO;
import com.gsenc.wsf.bbs.model.BbsPostDetailVO;
import com.gsenc.wsf.bbs.model.BbsPostRequestVO;
import com.gsenc.wsf.bbs.model.BbsPostResponseVO;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface BbsRepository {

	int selectBbsPostsCount(@Param("bbsCondition") BbsConditionVO bbsCondition,@Param("session") UserSessionVO session);

	List<BbsPostResponseVO> selectBbsPosts(@Param("bbsCondition") BbsConditionVO bbsCondition,
		@Param("session") UserSessionVO session);

	BbsPostDetailVO selectBbsPost(@Param("bbsNo") int bbsNo, @Param("langCd") String langCd);

	List<BbsPostDetailVO> selectBbsPopupPost();

	int updateBbsPostVwct(int bbmNo);

	int insertBbsPost(@Param("post") BbsPostRequestVO bbsVo, @Param("session") UserSessionVO UserSessionVO);

	int updateBbsPost(@Param("post") BbsPostRequestVO bbsVo, @Param("session") UserSessionVO UserSessionVO);

	int deleteBbsPost(@Param("bbsNo") int bbmNo, @Param("session") UserSessionVO UserSessionVO);
}
