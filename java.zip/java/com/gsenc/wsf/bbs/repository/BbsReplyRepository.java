package com.gsenc.wsf.bbs.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.bbs.model.BbsReplyRequestVO;
import com.gsenc.wsf.bbs.model.BbsReplyResponseVO;
import com.gsenc.wsf.bbs.model.BbsReplyVO;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface BbsReplyRepository {

	List<BbsReplyResponseVO> selectBbsReplies(@Param("prntReNo") String prntReNo, @Param("bbsNo") int bbsNo,
		@Param("langCd") String langCd);

	BbsReplyVO selectBbsReply(@Param("bbsNo") String bbsNo, @Param("bbsReNo") String bbsReNo);

	int insertBbsReply(@Param("bbsReply") BbsReplyRequestVO bbsReply, @Param("session") UserSessionVO userSession);

	int deleteBbsReply(@Param("bbsNo") String bbsNo, @Param("bbsReNo") String bbsReNo);

	int updateBbsReply(@Param("bbsReply") BbsReplyRequestVO bbsReply, @Param("session") UserSessionVO UserSessionVO);

}
