package com.gsenc.wsf.department.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.wsf.common.model.DataWrapperVO;
import com.gsenc.wsf.common.util.RestResponseFactoryUtil;
import com.gsenc.wsf.department.model.HrDepartmentIFVO;
import com.gsenc.wsf.department.service.DepartmentIFService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequiredArgsConstructor
@Tag(name = "DepartmentIf")
@Validated
@Slf4j
@RequestMapping("/api")
public class DepartmentIFController {

	private final DepartmentIFService departmentIFService;

	@Operation(summary = "DeptBatch", description = "DeptBatch")
	@PostMapping(value = "/v1/dept-batch", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DataWrapperVO> migrateDepartments(@RequestBody DataWrapperVO<List<HrDepartmentIFVO>> dept,
		HttpServletRequest request) {

		return new ResponseEntity<>(
			RestResponseFactoryUtil.createReturnDataVO(
				departmentIFService.migrateDepartments(request, dept.getData().getRecord())),
			HttpStatus.OK);
	}
}
