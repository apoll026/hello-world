package com.gsenc.wsf.department.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonRestResponseVO;
import com.gsenc.wsf.common.util.BatchUtil;
import com.gsenc.wsf.common.util.NetworkUtil;
import com.gsenc.wsf.department.model.HrDepartmentCUDList;
import com.gsenc.wsf.department.model.HrDepartmentIFVO;
import com.gsenc.wsf.department.repository.DepartmentIFRepository;
import com.gsenc.wsf.log.model.IfLogVO;
import com.gsenc.wsf.log.service.LogService;

import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class DepartmentIFServiceImpl implements DepartmentIFService {

	private final ApplicationContext applicationContext;

	private final LogService logService;
	private final DepartmentIFRepository departmentIFRepository;

	@Transactional(rollbackFor = {Exception.class})
	public CommonRestResponseVO migrateDepartments(HttpServletRequest request,
		List<HrDepartmentIFVO> hrDepartmentIFVOList) {

		CommonRestResponseVO resultVO = CommonRestResponseVO.builder()
			.o_ret_code("S")
			.o_ret_msg(StatusCodeConstants.SUCCESS)
			.build();

		IfLogVO ifLog = IfLogVO.builder()
			.ifNm("HR-DEPT")
			.ifDivsCd("BATCH")
			.ifTrmtValCtn("")
			.ifRestValCtn(hrDepartmentIFVOList.toString())
			.dataInsUserId("Batch")
			.dataInsUserIp(NetworkUtil.getClientIP(request))
			.build();

		DepartmentIFServiceImpl proxy = applicationContext.getBean(DepartmentIFServiceImpl.class);

		try {
			proxy.createHrDepartmentI(hrDepartmentIFVOList);

			List<HrDepartmentIFVO> hrDepartmentTargetlist = departmentIFRepository.selectDepartmentI();

			HrDepartmentCUDList hrDepartmentCUDList = this.getHrDepartmentCUDList(hrDepartmentTargetlist);
			this.updateDepartmentMaster(hrDepartmentCUDList.getUpdateList());
			this.createDepartmentMaster(hrDepartmentCUDList.getInsertList());

			List<HrDepartmentIFVO> hrDepartmentTempTargetlist = departmentIFRepository.selectTempDepartmentI();

			//TEMP FLAG Y에 대한 처리
			HrDepartmentCUDList hrDepartmentTempCUDList = this.getHrDepartmentCUDList(hrDepartmentTempTargetlist);
			this.updateDepartmentMaster(hrDepartmentTempCUDList.getUpdateList());
			this.createDepartmentMaster(hrDepartmentTempCUDList.getInsertList());

			//TEMP FLAG N에 대한 처리
			this.updateDepartmentMaster(
				hrDepartmentTargetlist.stream().filter(o -> "N".equals(o.getUseFlag())).collect(Collectors.toList()));

			departmentIFRepository.updateDeptITranfered();

		} catch (Exception e) {
			resultVO.setO_ret_code("E");
			resultVO.setO_ret_msg("EXCEPTION");
			ifLog.setIfTrmtValCtn(e.getMessage());
			log.error(e.getMessage(), e);
		} finally {
			ifLog.setOptValNm1(resultVO.getO_ret_code());
			ifLog.setOptValNm2(resultVO.getO_ret_msg());
			logService.createIfLog(ifLog);
		}

		return resultVO;
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void createHrDepartmentI(List<HrDepartmentIFVO> hrDepartmentIFVOList) {
		int loopCount = BatchUtil.getBatchLoopCount(hrDepartmentIFVOList.size());
		for (int i = 0; i < loopCount; i++) {
			List<HrDepartmentIFVO> batchList = BatchUtil.getSubList(hrDepartmentIFVOList, i);
			departmentIFRepository.insertHrDepartmentI(batchList);
		}
	}

	private HrDepartmentCUDList getHrDepartmentCUDList(List<HrDepartmentIFVO> hrDepartmentTargetlist) {

		List<HrDepartmentIFVO> hrDepartmentInsertlist = new ArrayList<>();
		List<HrDepartmentIFVO> hrDepartmentUpdatelist = new ArrayList<>();

		for (HrDepartmentIFVO hrDepartmentIFVO : hrDepartmentTargetlist) {

			if (departmentIFRepository.selectDepartmentMCount(hrDepartmentIFVO.getOrganizationId()) > 0) {
				hrDepartmentUpdatelist.add(hrDepartmentIFVO);
			} else {
				hrDepartmentInsertlist.add(hrDepartmentIFVO);
			}
		}

		return new HrDepartmentCUDList(hrDepartmentInsertlist, hrDepartmentUpdatelist);
	}

	private void updateDepartmentMaster(List<HrDepartmentIFVO> hrDepartmentUpdatelist) {
		if (!hrDepartmentUpdatelist.isEmpty()) {
			int batchInsertCount = BatchUtil.getBatchLoopCount(hrDepartmentUpdatelist.size());
			for (int i = 0; i < batchInsertCount; i++) {
				List<HrDepartmentIFVO> batchList = BatchUtil.getSubList(hrDepartmentUpdatelist, i);

				for (int j = 0; j < batchList.size(); j++) {
					departmentIFRepository.updateDeptMaster(batchList.subList(j, j + 1));
				}
			}
		}
	}

	private void createDepartmentMaster(List<HrDepartmentIFVO> hrDepartmentInsertlist) {
		if (!hrDepartmentInsertlist.isEmpty()) {
			int batchUpdateCount = BatchUtil.getBatchLoopCount(hrDepartmentInsertlist.size());
			for (int i = 0; i < batchUpdateCount; i++) {
				List<HrDepartmentIFVO> batchList = BatchUtil.getSubList(hrDepartmentInsertlist, i);
				departmentIFRepository.insertDeptMaster(batchList);
			}
		}
	}
}
