package com.gsenc.wsf.department.service;

import java.util.List;

import com.gsenc.wsf.common.model.CommonRestResponseVO;
import com.gsenc.wsf.department.model.HrDepartmentIFVO;

import jakarta.servlet.http.HttpServletRequest;

public interface DepartmentIFService {
	CommonRestResponseVO migrateDepartments(HttpServletRequest request, List<HrDepartmentIFVO> hrDepartmentIFVOList);
}
