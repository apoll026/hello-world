package com.gsenc.wsf.department.service;

import java.util.List;

import com.gsenc.wsf.department.model.DepartmentRequestVO;
import com.gsenc.wsf.department.model.DepartmentResponseVO;
import com.gsenc.wsf.department.model.DepartmentVO;

public interface DepartmentService {

    List<DepartmentVO> findDepartments(DepartmentRequestVO departmentRequestVo);

    DepartmentResponseVO findDepartmentsAddingUserDeptCode(DepartmentRequestVO departmentRequestVO);

    String findParentDepartment();

}
