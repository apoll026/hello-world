package com.gsenc.wsf.department.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.department.model.DepartmentRequestVO;
import com.gsenc.wsf.department.model.DepartmentResponseVO;
import com.gsenc.wsf.department.model.DepartmentVO;
import com.gsenc.wsf.department.repository.DepartmentRepository;
import com.gsenc.wsf.employee.service.EmployeeService;
import com.gsenc.wsf.session.model.EmployeeVO;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional
public class DepartmentServiceImpl implements DepartmentService {

	private final EmployeeService employeeService;
	private final DepartmentRepository departmentRepository;

	@Override
	@Transactional(readOnly = true)
	public List<DepartmentVO> findDepartments(DepartmentRequestVO departmentRequestVo) {

		UserSessionVO userSession = SessionScopeUtil.getContextSession();
		departmentRequestVo.setLangCd(userSession.getLangCd());

		return departmentRepository.selectAllDepartments(departmentRequestVo);
	}

	@Override
	@Transactional(readOnly = true)
	public DepartmentResponseVO findDepartmentsAddingUserDeptCode(DepartmentRequestVO departmentRequestVo) {
		UserSessionVO userSession = SessionScopeUtil.getContextSession();
		EmployeeVO user = employeeService.selectEmployeeByUserId(userSession.getMailId());
		//EmployeeVO user = employeeService.selectEmployeeByUserIdOther(userSession.getMailId(), userSession.getPasswd());

		return DepartmentResponseVO.builder()
			.departmentList(this.findDepartments(departmentRequestVo))
			.userDeptCode(user.getDeptCode())
			.build();
	}

	@Override
	@Transactional(readOnly = true)
	public String findParentDepartment() {
		UserSessionVO userSession = SessionScopeUtil.getContextSession();
		return departmentRepository.selectParentDepartment(userSession.getDeptCode());
	}

}
