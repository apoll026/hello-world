package com.gsenc.wsf.department.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class HrDepartmentCUDList {
    List<HrDepartmentIFVO> insertList;
    List<HrDepartmentIFVO> updateList;
}
