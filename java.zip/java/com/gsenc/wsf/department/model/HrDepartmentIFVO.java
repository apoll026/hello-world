package com.gsenc.wsf.department.model;


import java.io.Serializable;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class HrDepartmentIFVO implements Serializable {
    @Schema(description = "EAI_SEQ_ID", example = "1")
    private Integer seqId;

    @Schema(description = "조직아이디", example = "조직아이디")
    private Integer organizationId;

    @Schema(description = "소속코드", example = "소속코드")
    private String organizationCode;

    @Schema(description = "조직레벨", example = "조직레벨")
    private String organizationLevel;

    @Schema(description = "조직명", example = "조직명")
    private String organizationName;

    @Schema(description = "조직명(영문)", example = "조직명(영문)")
    private String organizationEname;

    @Schema(description = "사업부명", example = "사업부명")
    private String divisionName;

    @Schema(description = "상위부서명", example = "상위부서명")
    private String parentOrgName;

    @Schema(description = "조직책임자", example = "조직책임자")
    private String supervisorNumber;

    @Schema(description = "조직계층", example = "조직계층")
    private String organizationType;

    @Schema(description = "조직의 Location", example = "조직의 Location")
    private String location;

    @Schema(description = "사용여부", example = "사용여부")
    private String useFlag;

    @Schema(description = "상위조직아이디", example = "상위조직아이디")
    private Integer parentOrgId;

    @Schema(description = "사업장ID", example = "사업장ID")
    private Integer bizPlaceId;

    @Schema(description = "조직책임자명", example = "조직책임자명")
    private String supervisorName;

    @Schema(description = "비지니스그룹아이디", example = "비지니스그룹아이디")
    private String businessGroupId;

    @Schema(description = "법인약어", example = "법인약어")
    private String subsidiaryCode;

    @Schema(description = "데이터처리유형", example = "데이터처리유형")
    private String eaiDataCrudCd;

    @Schema(description = "SORTCODE", example = "SORTCODE")
    private String sortcode;

    @Schema(description = "상위부서코드", example = "상위부서코드")
    private String parentOrgCode;

    @Schema(description = "사업장명", example = "사업장명")
    private String bizPlaceName;

    @Schema(description = "사업부ID", example = "사업부ID")
    private Integer divisionId;

    @Schema(description = "비지니스그룹명", example = "비지니스그룹명")
    private String businessGroupName;

    @Schema(description = "조직종료일", example = "조직종료일")
    private String dateTo;

    @Schema(description = "조직시작일", example = "조직시작일")
    private String dateFrom;

    @Schema(description = "생성일", example = "생성일")
    private String creationDate;

    @Schema(description = "수정일", example = "수정일")
    private String updateDate;

    @Schema(description = "법인조직여부", example = "법인조직여부")
    private String attribute1;

    @Schema(description = "판매법인여부", example = "판매법인여부")
    private String attribute2;

    @Schema(description = "예비속성3", example = "예비속성3")
    private String attribute3;

    @Schema(description = "예비속성4", example = "예비속성4")
    private String attribute4;

    @Schema(description = "예비속성5", example = "예비속성5")
    private String attribute5;

    @Schema(description = "예비속성6", example = "예비속성6")
    private String attribute6;

    @Schema(description = "예비속성7", example = "예비속성7")
    private String attribute7;

    @Schema(description = "예비속성8", example = "예비속성8")
    private String attribute8;

    @Schema(description = "예비속성9", example = "예비속성9")
    private String attribute9;

    @Schema(description = "예비속성10", example = "예비속성10")
    private String attribute10;

    @Schema(description = "예비속성11", example = "예비속성11")
    private String attribute11;

    @Schema(description = "예비속성12", example = "예비속성12")
    private String attribute12;

    @Schema(description = "예비속성13", example = "예비속성13")
    private String attribute13;

    @Schema(description = "예비속성14", example = "예비속성14")
    private String attribute14;

    @Schema(description = "퇴직예정", example = "퇴직예정")
    private String attribute15;

    @Schema(description = "예비속성16", example = "예비속성16")
    private String attribute16;

    @Schema(description = "사업본부", example = "사업본부")
    private String attribute17;

    @Schema(description = "BU", example = "BU")
    private String attribute18;

    @Schema(description = "조직유형코드", example = "조직유형코드")
    private String attribute19;

    @Schema(description = "EAI전송여부", example = "EAI전송여부")
    private String transferFlag11;

    @Schema(description = "EAI전송일시", example = "EAI전송일시")
    private String transferDate11;
}
