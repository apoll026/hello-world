package com.gsenc.wsf.department.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class DepartmentVO {

	@NotBlank
	@Schema(description = "부서코드", name = "부서코드")
	private String deptCode;

	@Schema(description = "부서생성일", name = "부서생성일")
	private String deptDate;

	@Schema(description = "부서명", name = "부서명")
	private String deptName;

	@Schema(description = "정렬코드", name = "정렬코드")
	private String sortCode;

	@Schema(description = "리더사번", name = "리더사번")
	private String lderEmpno;

	@Schema(description = "차상위부서코드", name = "차상위부서코드")
	private String upprDeptCode;

	@Schema(description = "차상위부서생성일", name = "차상위부서생성일")
	private String upprDeptDate;

	@Schema(description = "WORK_CODE", name = "WORK_CODE")
	private String workCode;

	@Schema(description = "본사/현장구분", name = "본사/현장구분")
	private String siteFlag;

	@Schema(description = "부문구분", name = "부문구분")
	private String partFlag;

	@Schema(description = "사용여부", name = "사용여부")
	private String useYn;

	@Schema(description = "최종수정자", name = "최종수정자")
	private String updEmpno;

	@Schema(description = "최종수정일자", name = "최종수정일자")
	private String updDate;

	@Schema(description = "최종수정ID", name = "최종수정ID")
	private String updId;

	@Schema(description = "담당", name = "담당")
	private String chifEmp1;

	@Schema(description = "담당2", name = "담당2")
	private String chifEmp2;

	@Schema(description = "사업부장", name = "사업부장")
	private String chifEmp3;

	@Schema(description = "사업본부장", name = "사업본부장")
	private String chifEmp4;

	@Schema(description = "CEO", name = "CEO")
	private String chifEmp5;

	@Schema(description = "ORGN_LDER", name = "ORGN_LDER")
	private String orgnLder;

	@Schema(description = "DEPT_DIVS", name = "DEPT_DIVS")
	private String deptDivs;

}
