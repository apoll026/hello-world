package com.gsenc.wsf.department.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.department.model.DepartmentRequestVO;
import com.gsenc.wsf.department.model.DepartmentVO;

@Mapper
public interface DepartmentRepository {

    List<DepartmentVO> selectAllDepartments(DepartmentRequestVO departmentRequestVo);
    String selectParentDepartment(@Param("deptCd") String deptCd);

}
