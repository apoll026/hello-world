package com.gsenc.wsf.department.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gsenc.wsf.department.model.HrDepartmentIFVO;

@Mapper
public interface DepartmentIFRepository {

    int updateDeptITranfered();

    int insertHrDepartmentI(List<HrDepartmentIFVO> hrIfDepartments);

    List<HrDepartmentIFVO> selectDepartmentI();

    int selectDepartmentMCount(long organizationId);

    int updateDeptMaster(List<HrDepartmentIFVO> hrDepartmentlist);

    int insertDeptMaster(List<HrDepartmentIFVO> hrDepartmentlist);

    List<HrDepartmentIFVO> selectTempDepartmentI();
}
