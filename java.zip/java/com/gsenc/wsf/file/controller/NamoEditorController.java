package com.gsenc.wsf.file.controller;

import static com.gsenc.wsf.common.util.ValidateUtil.isEmpty;

import java.io.*;
import java.net.URLEncoder;
import java.util.List;
import java.util.UUID;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.EntityBuilder;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.client.WebClient;

import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.exception.BusinessException;
import com.gsenc.wsf.file.model.FileVO;
import com.gsenc.wsf.file.service.FileService;

import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/api")
public class NamoEditorController {
	@Bean
	public WebClient.Builder webClientBuilder() {
		return WebClient.builder();
	}

	private final FileService fileService;
	@Value("${namo.upload-path}")
	private String uploadPath;

	@Value("${namo.backend-url}")
	private String backendUrl;

	@Value("${spring.config.activate.on-profile}")
	private String profile;

	@PostMapping(value = "/v1/namoFileUpload", produces = MediaType.APPLICATION_JSON_VALUE)
	public String uploadFile(@RequestParam("imageFile") MultipartFile file,
		@RequestParam(value = "imageKind", required = false) String imageKind,
		@RequestParam(value = "fileKind", required = false) String fileKind,
		@RequestParam("editorFrame") String editorFrame
	) {
		try {
			if (file.isEmpty()) {
				return new BusinessException("file is Empty.", StatusCodeConstants.FAIL).toString();
			}
			String atchFileGrId = UUID.randomUUID().toString();
			String atchFileTpCd = "";
			String[] fileSizeArr = new String[1];
			String[] fileNameArr = new String[1];
			String[] fileTypeArr = new String[1];
			fileSizeArr[0] = String.valueOf(file.getSize());
			fileNameArr[0] = String.valueOf(file.getOriginalFilename()).replaceAll(",", "_");
			fileTypeArr[0] = file.getContentType();
			// preSignedUrl 발급 (upload 전용)
			List<FileVO> preSignedUrlResponse = fileService.createPreSignedUploadUrl(
				atchFileGrId,
				fileNameArr,
				fileSizeArr,
				fileTypeArr,
				atchFileTpCd
			);
			if (!preSignedUrlResponse.isEmpty()) {
				HttpClient httpClient = HttpClients.custom()
					.setDefaultRequestConfig(
						RequestConfig.custom().setCookieSpec(CookieSpecs.STANDARD).build()
					).build();
				HttpPut put = new HttpPut(preSignedUrlResponse.get(0).getPreSignedUrl());
				File tempFile = File.createTempFile("upload", null);
				file.transferTo(tempFile);
				HttpEntity entity = EntityBuilder.create()
					.setFile(tempFile)
					.build();
				put.setEntity(entity);
				put.setHeader("Content-Type", file.getContentType());

				HttpResponse response = httpClient.execute(put);

				if (response.getStatusLine().getStatusCode() == 200) {
					FileVO downloadUrlResponse = fileService.createPreSignedDownloadUrl(atchFileGrId,
						preSignedUrlResponse.get(0).getAtchFileId());
					String resultPath = downloadUrlResponse.getPreSignedUrl();
					String imageAlign = "backgroundimage".equals(imageKind) ? "repeat" : "baseline";
					String imgKind = isEmpty(imageKind) ? fileKind : imageKind;
					String result = "";
					//TODO: Upload를 성공하면 DownloadUrl을 받아서 FE로 전달해야함
					if ("file".equals(imgKind)) {
						result = "{\n" +
							"  \"result\": \"success\",\n" +
							"  \"addmsg\": [\n" +
							"    {\n" +
							"      \"fileURL\": \"" + resultPath + "\",\n" +
							"      \"fileTitle\": \"" + file.getOriginalFilename() + "\",\n" +
							"      \"fileId\": \"" + atchFileGrId + "," + preSignedUrlResponse.get(0).getAtchFileId()
							+ "\",\n" +
							"      \"fileClass\": \"namoUploaded\",\n" +
							"      \"fileKind\": \"" + imgKind + "\",\n" +
							"      \"fileType\": \"" + file.getContentType() + "\",\n" +
							"      \"fileSize\": \"" + file.getSize() + "\",\n" +
							"      \"editorFrame\": \"" + editorFrame + "\"\n" +
							"    }\n" +
							"  ]\n" +
							"}";
					} else {
						result = "{\n" +
							"  \"result\": \"success\",\n" +
							"  \"addmsg\": [\n" +
							"    {\n" +
							"      \"imageURL\": \"" + resultPath + "\",\n" +
							"      \"imageTitle\": \"\",\n" +
							"      \"imageAlt\": \"\",\n" +
							"      \"imageWidth\": \"\",\n" +
							"      \"imageWidthUnit\": \"px\",\n" +
							"      \"imageHeight\": \"\",\n" +
							"      \"imageHeightUnit\": \"px\",\n" +
							"      \"imageSize\": \"" + file.getSize() + "\",\n" +
							"      \"imageMarginLeft\": \"\",\n" +
							"      \"imageMarginLeftUnit\": \"px\",\n" +
							"      \"imageMarginRight\": \"\",\n" +
							"      \"imageMarginRightUnit\": \"px\",\n" +
							"      \"imageMarginTop\": \"\",\n" +
							"      \"imageMarginTopUnit\": \"px\",\n" +
							"      \"imageMarginBottom\": \"\",\n" +
							"      \"imageMarginBottomUnit\": \"px\",\n" +
							"      \"imageAlign\": \"" + imageAlign + "\",\n" +
							"      \"imageId\": \"" + atchFileGrId + "," + preSignedUrlResponse.get(0).getAtchFileId()
							+ "\",\n" +
							"      \"imageClass\": \"namoUploaded\",\n" +
							"      \"imageBorder\": \"0\",\n" +
							"      \"imageKind\": \"" + imgKind + "\",\n" +
							"      \"imageOrgPath\": \"" + file.getOriginalFilename() + "|" + resultPath + "\",\n" +
							"      \"imageOrgWidth\": \"960\",\n" +
							"      \"imageOrgHeight\": \"540\",\n" +
							"      \"editorFrame\": \"" + editorFrame + "\"\n" +
							"    }\n" +
							"  ]\n" +
							"}";
					}
					return result;
				}
			}

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new BusinessException("Download File Failed..", StatusCodeConstants.FAIL, e);
		}
		return new BusinessException("Download File Failed.", StatusCodeConstants.FAIL).toString();
	}

	@GetMapping(value = "/v1/file/download/{currentDate}/{fileName}", produces = MediaType.APPLICATION_JSON_VALUE)
	public void downloadFile(@PathVariable String fileName, @PathVariable String currentDate,
		HttpServletResponse response) throws IOException {
		if (fileName.contains("../") || fileName.contains("/..") || fileName.contains("/../")) {
			throw new BusinessException("UnAuthorized Path", StatusCodeConstants.FAIL);
		}
		;
		String timestamp = currentDate.substring(8);
		String newFileName = URLEncoder.encode(removeTimestampSuffix(fileName), "UTF-8");

		ClassLoader classLoader = getClass().getClassLoader();
		String classpath = classLoader.getResource("").getPath();

		String filePath;
		if ("default".equals(profile) || "local".equals(profile)) {
			filePath = classpath + uploadPath;
		} else {
			filePath = uploadPath;
		}

		File file = new File(
			filePath + "/" + currentDate.substring(0, 8) + "/" + addTimestampSuffix(fileName, timestamp));

		try (
			FileInputStream fis = new FileInputStream(file);
			BufferedInputStream bis = new BufferedInputStream(fis);
			OutputStream out = response.getOutputStream()
		) {
			response.addHeader("Content-Disposition", "attachment;filename=\"" + newFileName + "\"");
			response.setContentLength((int)file.length());

			int read = 0;

			while ((read = bis.read()) != -1) {
				out.write(read);
			}
		} catch (IOException e) {
			throw new BusinessException("Download File Failed.", StatusCodeConstants.FAIL, e);
		}
	}

	private static String addTimestampSuffix(String fileName, String timestamp) {
		int dotIndex = fileName.lastIndexOf(".");

		if (dotIndex != -1) {
			String extension = fileName.substring(dotIndex);
			String nameWithOutExtension = fileName.substring(0, dotIndex);
			return nameWithOutExtension + "_" + timestamp + extension;
		} else {
			return fileName + "_" + timestamp;
		}
	}

	private static String removeTimestampSuffix(String fileName) {
		int underscoreIndex = fileName.lastIndexOf("_");

		if (underscoreIndex != -1) {
			return fileName.substring(0, underscoreIndex) + fileName.substring(fileName.lastIndexOf("."));
		} else {
			return fileName;
		}
	}
}
