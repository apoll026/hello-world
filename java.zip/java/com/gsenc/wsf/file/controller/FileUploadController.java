package com.gsenc.wsf.file.controller;

import java.io.*;
import java.net.URLEncoder;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.MultipartResolver;

import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.filter.BufferedRequestWrapper;
import com.gsenc.wsf.common.model.CommonResponseVO;
import com.gsenc.wsf.common.model.DmlResponseVO;
import com.gsenc.wsf.common.util.ValidateUtil;
import com.gsenc.wsf.file.model.FileGrIdFileIdVO;
import com.gsenc.wsf.file.model.FileModifyRequestVO;
import com.gsenc.wsf.file.model.FileVO;
import com.gsenc.wsf.file.service.FileService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j

@RestController
@RequiredArgsConstructor
@RequestMapping("/api")
public class FileUploadController {
	private final FileService fileService;

	@Value("${aip.upload-path}")
	private String aipUploadPath;

	// ConditionalMultipartResolver 방식에서는 컨트롤러에서 resolver 주입 불필요
	// Filter에서 이미 처리됨

	@Operation(summary = "dext5업로더 업로드")
	@PostMapping(value = "/v1/dextfile/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<CommonResponseVO<DmlResponseVO>> singleUpload(
			HttpServletRequest request,
			@RequestParam(value = "DEXTUploadX5_MetaData") String meta,
			@RequestParam(value = "DEXTUploadX5_FileData") MultipartFile[] files) throws IOException {

		String atchFileGrId = null;
		if (meta != null && !meta.isEmpty()) {
			String[] parts = meta.split(",");
			if (parts.length > 0) {
				String[] keyValue = parts[0].split("\\|"); // escape pipe '|'
				if (keyValue.length == 2) {
					atchFileGrId = keyValue[1];
				}
			}
		}

		return new ResponseEntity<>(CommonResponseVO.<DmlResponseVO>builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(DmlResponseVO.builder()
						.insertedRows(fileService.createFileForUpload(atchFileGrId, files, new String[] {"1"}, "null", "dext5"))
						.build())
				.build(), HttpStatus.OK
		);
	}

	@Operation(summary = "dext5Editor 파일 업로드 (MultipartFile)")
	@PostMapping(value = "/v1/files/dext5editor-upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<CommonResponseVO<String>> uploadDextEditorFiles(
			HttpServletRequest request,
			@RequestParam(value = "file") MultipartFile file) throws Exception {

		// 디버깅을 위한 로그 추가
		log.info("=== Dext5 Editor Upload Debug ===");
		log.info("Request URI: {}", request.getRequestURI());
		log.info("Content Type: {}", request.getContentType());

		// 모든 파라미터 확인
		log.info("All parameter names:");
		request.getParameterNames().asIterator().forEachRemaining(name -> {
			log.info("  - Parameter {}: {}", name, request.getParameter(name));
		});

		//MultipartFile file = null;
		String fileName = null;
		String editorId = null;
		String timestamp = null;

		log.info(file.getOriginalFilename());


		// MultipartHttpServletRequest로 캐스팅해서 파일 확인
		if (request instanceof MultipartHttpServletRequest) {
			MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
			log.info("Multipart file names: {}", multipartRequest.getFileNames());

			// 모든 파일 확인
			multipartRequest.getFileMap().forEach((key, value) -> {
				log.info("  - File {}: {} (size: {}, empty: {})", key, value.getOriginalFilename(), value.getSize(), value.isEmpty());
			});

			// 파일 찾기 - 여러 가능한 이름으로 시도
			file = multipartRequest.getFile("file");
			if (file == null) {
				file = multipartRequest.getFile("files");
			}
			if (file == null && multipartRequest.getFileNames().hasNext()) {
				String firstFileName = multipartRequest.getFileNames().next();
				file = multipartRequest.getFile(firstFileName);
				log.info("Found file with name: {}", firstFileName);
			}

			// 파라미터 추출
			fileName = multipartRequest.getParameter("fileName");
			editorId = multipartRequest.getParameter("editorId");
			timestamp = multipartRequest.getParameter("timestamp");
		}

		log.info("Final extracted file: {}", file);
		log.info("Final extracted fileName: {}", fileName);
		log.info("Final extracted editorId: {}", editorId);
		log.info("Final extracted timestamp: {}", timestamp);

		if (file == null || file.isEmpty()) {
			return new ResponseEntity<>(CommonResponseVO.<String>builder()
					.successOrNot(CommonConstants.NO_FLAG)
					.statusCode(StatusCodeConstants.SUCCESS)
					.build(), HttpStatus.BAD_REQUEST
			);
		}

		// 단일 파일을 배열로 변환
		MultipartFile[] files = new MultipartFile[]{file};

		String savedPath = fileService.saveDextEditorFiles(files);

		return new ResponseEntity<>(CommonResponseVO.<String>builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(savedPath)
				.build(), HttpStatus.OK
		);
	}

	@Operation(summary = "GrId와 FileId로 파일 미사용 변경")
	@PutMapping(value = "/v1/files/unuse", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<DmlResponseVO>> modifyFilesToUnuseByGrIdAndFileId(
		@RequestBody List<FileGrIdFileIdVO> idList) {

		return new ResponseEntity<>(CommonResponseVO.<DmlResponseVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(DmlResponseVO.builder()
				.updatedRows(fileService.modifyFilesToUnuseByGrIdAndFileId(idList))
				.build())
			.build(), HttpStatus.OK
		);
	}

	@Operation(summary = "AWS Pre-Signed Upload URL 조회")
	@GetMapping(value = "/v1/file/preSignedUploadUrl", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<List<FileVO>>> uploadFiles(
		@Parameter(name = "atchFileGrId") @RequestParam @NotBlank String atchFileGrId
		, @Parameter(name = "originalFileName") @RequestParam String originalFileName
		, @Parameter(name = "fileSize") @RequestParam String fileSize
		, @Parameter(name = "fileType") @RequestParam String fileType
		, @Parameter(name = "atchFileTpCd") @RequestParam String atchFileTpCd) {

		String[] originalFileNameArr = originalFileName.split(",");
		String[] fileSizeArr = fileSize.split(",");
		String[] fileTypeArr = fileType.split(",");

		return new ResponseEntity<>(CommonResponseVO.<List<FileVO>>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(fileService.createPreSignedUploadUrl(atchFileGrId, originalFileNameArr, fileSizeArr, fileTypeArr,
				atchFileTpCd))
			.build(), HttpStatus.OK
		);
	}

	@Operation(summary = "AWS Pre-Signed Download URL 조회")
	@GetMapping(value = "/v1/file/preSignedDownloadUrl", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<FileVO>> downloadS3File(
		HttpServletResponse response
		, @Parameter(name = "atchFileGrId") @RequestParam String atchFileGrId
		, @Parameter(name = "atchFileId") @RequestParam String atchFileId
	) {

		return new ResponseEntity<>(CommonResponseVO.<FileVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(fileService.createPreSignedDownloadUrl(atchFileGrId, atchFileId))
			.build(), HttpStatus.OK
		);
	}

	@Operation(summary = "AWS Pre-Signed Download URL 전체 조회")
	@GetMapping(value = "/v1/file/preSignedDownloadUrlAll", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<List<FileVO>>> downloadS3Files(
		HttpServletResponse response
		, @Parameter(name = "atchFileGrId") @RequestParam String atchFileGrId
	) {

		return new ResponseEntity<>(CommonResponseVO.<List<FileVO>>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(fileService.createPreSignedDownloadUrls(atchFileGrId))
			.build(), HttpStatus.OK
		);
	}

	@Operation(summary = "파일 불러오기")
	@GetMapping(value = "/v1/files", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<List<FileVO>>> findFiles(
		@Parameter(name = "atchFileGrId") @RequestParam @NotBlank String atchFileGrId) {
		return new ResponseEntity<>(CommonResponseVO.<List<FileVO>>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(fileService.findFiles(atchFileGrId))
			.build(), HttpStatus.OK
		);
	}

	@Operation(summary = "파일 업로드")
	@PostMapping(value = "/v1/file/upload", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<DmlResponseVO>> uploadFiles(
		@Parameter(name = "atchFileGrId") @RequestParam @NotBlank String atchFileGrId,
		@Parameter(name = "files") @RequestParam @NotBlank MultipartFile[] files,
		@Parameter(name = "fileSortOrds") @RequestParam String fileSortOrds, @RequestParam String atchFileTpCd) {
		String[] fileSortOrdArray = null;
		if (!ValidateUtil.isEmpty(fileSortOrds)) {
			fileSortOrdArray = fileSortOrds.split(",");
		}

		return new ResponseEntity<>(CommonResponseVO.<DmlResponseVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(DmlResponseVO.builder()
				.insertedRows(
					fileService.createFileForUpload(atchFileGrId, files, fileSortOrdArray, atchFileTpCd, "default"))
				.build())
			.build(), HttpStatus.OK
		);
	}

	@Operation(summary = "파일 새로운 아이디로 업로드")
	@PostMapping(value = "/v1/file/upload/new", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<DmlResponseVO>> uploadFilesWithNewGroupId(
		@Parameter(name = "oldAtchFileGrId") @RequestParam @NotBlank String oldAtchFileGrId,
		@Parameter(name = "newAtchFileGrId") @RequestParam @NotBlank String newAtchFileGrId,
		@Parameter(name = "files") @RequestParam @NotBlank MultipartFile[] files,
		@Parameter(name = "fileSortOrds") @RequestParam String fileSortOrds,
		@Parameter(name = "atchFileTpCd") @RequestParam String atchFileTpCd) {
		String[] fileSortOrdArray = null;
		if (!ValidateUtil.isEmpty(fileSortOrds)) {
			fileSortOrdArray = fileSortOrds.split(",");
		}

		return new ResponseEntity<>(CommonResponseVO.<DmlResponseVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(DmlResponseVO.builder()
				.insertedRows(
					fileService.createFileWithNewFileGroupId(oldAtchFileGrId, newAtchFileGrId, files, fileSortOrdArray,
						atchFileTpCd))
				.build())
			.build(), HttpStatus.OK
		);
	}

	@Operation(summary = "파일 다운로드")
	@GetMapping(value = "/v1/file/download", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<Resource> downloadFile(
		@Parameter(name = "atchFileGrId") @RequestParam @NotBlank String atchFileGrId,
		@Parameter(name = "atchFileId") @RequestParam @NotBlank String atchFileId) throws UnsupportedEncodingException {
		FileVO fileVO = fileService.findFile(atchFileGrId, atchFileId);
		Resource resource = fileService.createFileForDownload(fileVO);

		return ResponseEntity.ok().headers(this.headers(URLEncoder.encode(fileVO.getAtchFileNm(), "UTF-8")))
			.contentType(MediaType
				.parseMediaType(MediaType.APPLICATION_OCTET_STREAM_VALUE))
			.body(resource);
	}

	@Operation(summary = "파일 다운로드")
	@GetMapping(value = "/v1/file/dext5editorDownload", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<Resource> downloadFile(
			@Parameter(name = "atchFileId") @RequestParam @NotBlank String atchFileId) throws UnsupportedEncodingException {
		FileVO fileVO = fileService.findFile("dext5editor", atchFileId);
		Resource resource = fileService.createFileForDownload(fileVO);

		return ResponseEntity.ok().headers(this.headers(URLEncoder.encode(fileVO.getAtchFileNm(), "UTF-8")))
				.contentType(MediaType
						.parseMediaType(MediaType.APPLICATION_OCTET_STREAM_VALUE))
				.body(resource);
	}

	@Operation(summary = "파일 다운로드(모바일용)")
	@GetMapping(value = "/v1/file/mbdownload", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<Resource> downloadFileMob(
		@Parameter(name = "atchFileGrId") @RequestParam @NotBlank String atchFileGrId,
		@Parameter(name = "atchFileId") @RequestParam @NotBlank String atchFileId) throws UnsupportedEncodingException {
		return downloadFile(atchFileGrId, atchFileId);
	}

	@Operation(summary = "파일 비교다운로드")
	@GetMapping(value = "/v1/file/compare", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<Resource> downloadCompareFile(
		@Parameter(name = "atchFileGrId") @RequestParam @NotBlank String atchFileGrId,
		@Parameter(name = "atchFileId") @RequestParam @NotBlank String atchFileId) throws UnsupportedEncodingException {
		return downloadFile(atchFileGrId, atchFileId);
	}

	@Operation(summary = "파일 전체 다운로드")
	@GetMapping(value = "/v1/file/download/all", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public void downloadAllFiles(@Parameter(name = "atchFileGrId") @RequestParam @NotBlank String atchFileGrId,
		HttpServletResponse response) throws IOException {
		List<FileVO> fileVOs = fileService.findFiles(atchFileGrId);

		response.setHeader("Content-Disposition", "attachment; filename=\"" + "compressed.zip" + "\";");
		response.setHeader("Content-Type", "APPLICATION_ZIP");

		fileService.responseZipFromAttachments(response.getOutputStream(), fileVOs);
	}

	@Operation(summary = "파일 정보 수정")
	@PutMapping(value = "/v1/files", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<DmlResponseVO>> modifyFiles(@RequestBody List<FileVO> files) {

		return new ResponseEntity<>(CommonResponseVO.<DmlResponseVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(DmlResponseVO.builder()
				.updatedRows(fileService.modifyFiles(files))
				.build())
			.build(), HttpStatus.OK
		);
	}

	@Operation(summary = "파일 정보 수정 후 새로운 id로 저장")
	@PutMapping(value = "/v1/files/new", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<DmlResponseVO>> modifyFilesWithNewGroupId(
		@RequestBody @Valid FileModifyRequestVO request) {

		return new ResponseEntity<>(CommonResponseVO.<DmlResponseVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(DmlResponseVO.builder()
				.updatedRows(fileService.modifyFilesWithNewGroupId(request.getAtchFileGrId(), request.getFiles()))
				.build())
			.build(), HttpStatus.OK
		);
	}

	@GetMapping("/v1/ibsheet8/download")
	public void downloadFile(HttpServletResponse response,
	@RequestParam(value = "fileName") String fileName) throws IOException {

		File file = new File(aipUploadPath + "/download/" + fileName);
		if (!file.exists()) {
			response.setStatus(HttpServletResponse.SC_NOT_FOUND);
			return;
		}

		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=\"" + URLEncoder.encode(file.getName(), "UTF-8") + "\";");
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setContentLengthLong(file.length());

		try (InputStream is = new FileInputStream(file)) {
			is.transferTo(response.getOutputStream());
			response.getOutputStream().flush();
		}
		if(file.exists()){
			// 파일이 존재하면 삭제
			file.delete();
		}

	}

	private HttpHeaders headers(String name) {
		HttpHeaders header = new HttpHeaders();
		header.add(HttpHeaders.CONTENT_DISPOSITION,
			"attachment; filename=" + name);
		header.add("Cache-Control",
			"no-cache, no-store, must-revalidate");
		header.add("Pragma", "no-cache");
		header.add("Expires", "0");
		return header;
	}

}
