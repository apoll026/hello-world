package com.gsenc.wsf.file.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FileGrIdFileIdVO {
    private String atchFileGrId;
    private String atchFileId;
}
