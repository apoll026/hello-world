package com.gsenc.wsf.file.service;

import static com.gsenc.wsf.common.constant.StatusCodeConstants.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.compress.utils.IOUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.HttpMethod;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import com.gsenc.wsf.common.exception.BusinessException;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.file.model.FileGrIdFileIdVO;
import com.gsenc.wsf.file.model.FileVO;
import com.gsenc.wsf.file.repository.FileRepository;
import com.gsenc.wsf.session.model.UserSessionVO;

import dextuploadjk.engine.FileItem;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class FileServiceImpl implements FileService {

	private final FileRepository fileRepository;

	@Value("${dropzone.upload-path}")
	private String uploadPath;

	@Value("${spring.config.activate.on-profile}")
	private String profile;

	@Value("${cloud.aws.s3.bucket}")
	private String bucket;

	@Value("${cloud.aws.region.static}")
	private String region;

    @Value("${nas.upload-path:#{null}}")
    private String nasUploadPath;

    AmazonS3 s3Client;

	@Override
	@Transactional(readOnly = true)
	public FileVO findFile(String atchFileGrId, String atchFileId) {
		return fileRepository.selectFile(atchFileGrId, atchFileId);
	}

	@Override
	@Transactional(readOnly = true)
	public List<FileVO> findFiles(String atchFileGrId) {
		return fileRepository.selectFiles(atchFileGrId);
	}

	@Override
	public String saveDextEditorFiles(MultipartFile[] files) throws Exception {
		ClassLoader classLoader = getClass().getClassLoader();
		String currentDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
		String folderPath;

		if ("dev".equals(profile)) {
			folderPath = "/app/eas/fileupload/editorfiles";
		} else if ("default".equals(profile)) {
			folderPath = classLoader.getResource("").getPath() + uploadPath + "/dext5editor/" + currentDate;
		} else {
			// 기본 경로 처리
			folderPath = uploadPath + "/dext5editor/" + currentDate;
		}

		// 폴더 생성
		File folder = new File(folderPath);
		if (!folder.exists()) {
			folder.mkdirs();
		}

		String savedPath = null;

		for (MultipartFile file : files) {
			if (file == null || file.isEmpty()) {
				continue;
			}

			String originalFileName = file.getOriginalFilename();
			if (originalFileName == null) {
				continue;
			}

			// UUID를 이용한 고유한 fileId 생성
			String uuid = UUID.randomUUID().toString();
			String fileExtension = "";
			int lastDotIndex = originalFileName.lastIndexOf(".");
			if (lastDotIndex > 0) {
				fileExtension = originalFileName.substring(lastDotIndex);
			}

			// 파일명[fileId] 형식으로 저장
			String saveFileName = originalFileName.substring(0, lastDotIndex) + "[" + uuid + "]" + fileExtension;
			String filePath = folderPath + "/" + saveFileName;

			// 파일 저장
			file.transferTo(new File(filePath));

			// 첫 번째 파일의 경로를 반환값으로 설정
			if (savedPath == null) {
				savedPath = filePath;
				log.info("파일 저장 완료: {}", filePath);
			}
		}

		// JSON 응답을 위해 파일 경로만 반환 (CommonResponseVO로 래핑됨)
		return savedPath;
	}




	/**
	 * Client에서 S3에 Upload하기 위한 Pre-Signed URL 생성
	 *
	 * @author YTSEO
	 */
	@Override
	@Transactional(rollbackFor = {Exception.class})
	public List<FileVO> createPreSignedUploadUrl(String atchFileGrId, String[] originalFileNameArr,
		String[] fileSizeArr, String[] fileTypeArr, String atchFileTpCd) {

		UserSessionVO UserSessionVO = SessionScopeUtil.getContextSession();
		List<FileVO> insertFiles = new ArrayList<FileVO>();

		int insertedRows = 0;

		for (int i = 0; i < originalFileNameArr.length; i++) {

			String originalFileName = originalFileNameArr[i];
			int fileSize = Integer.parseInt(fileSizeArr[i]);

			// 파일명 중복 방지를 위한 UUID
			String uuid = UUID.randomUUID().toString();
			// 저장될 파일명
			String saveFileName = originalFileName.substring(0, originalFileName.lastIndexOf(".")) + "[" + uuid + "]."
				+ originalFileName.substring(originalFileName.lastIndexOf(".") + 1);
			// 저장 폴더 생성을 위한 LocalDate : file/[yyyyMMdd]/[fileName]
			String currentDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
			// S3에 저장될 최종 경로 및 파일명
			String fileSavePath = "file/" + currentDate + "/" + saveFileName;

			// AWS SDK
			s3Client = AmazonS3ClientBuilder
				.standard()
				.withRegion(Regions.AP_NORTHEAST_2).build();

			// Pre-Signed URL 만료 시간 (60분 후)
			Date expiration = new Date();
			long expTimeMillis = expiration.getTime();
			expTimeMillis += TimeUnit.MINUTES.toMillis(60);
			expiration.setTime(expTimeMillis);

			// PUT Pre-Signed URL (PUT)
			GeneratePresignedUrlRequest generatePresignedUrlRequest =
				new GeneratePresignedUrlRequest(bucket, fileSavePath)
					.withMethod(HttpMethod.PUT)
					.withExpiration(expiration);

			URL url = s3Client.generatePresignedUrl(generatePresignedUrlRequest);
			String putPreSignedUrl = url.toString();

			// FileVO
			FileVO fileVO = FileVO.builder()
				.atchFileId(UUID.randomUUID().toString())
				.atchFileNm(originalFileName)
				.sortOrd(i + 1)
				.atchFileSaveLocDivsCd("ONSITE")
				.atchFileSaveNm(saveFileName)
				.atchFileSize(fileSize)
				.atchFileEfnmNm(originalFileName.substring(originalFileName.lastIndexOf(".") + 1))
				.atchFileSavePathCtn(fileSavePath)
				.atchFileTpCd(atchFileTpCd)
				.preSignedUrl(putPreSignedUrl)
				.useYn("Y")
				.build();

			insertedRows += fileRepository.upsertFile(atchFileGrId, fileVO, UserSessionVO);
			insertFiles.add(fileVO);

		}

		return insertFiles;
	}

	/**
	 * Client에서 S3 단일 파일을 Download하기 위한 Pre-Signed URL 생성
	 *
	 * @author YTSEO
	 */
	@Override
	@Transactional(rollbackFor = {Exception.class})
	public FileVO createPreSignedDownloadUrl(String atchFileGrId, String atchFileId) {

		FileVO fileVO = findFile(atchFileGrId, atchFileId);
		String fileSavePath = fileVO.getAtchFileSavePathCtn();

		// AWS SDK
		s3Client = AmazonS3ClientBuilder
			.standard()
			.withRegion(Regions.AP_NORTHEAST_2).build();

		// Pre-Signed URL 만료 시간 (60분 후)
		Date expiration = new Date();
		long expTimeMillis = expiration.getTime();
		expTimeMillis += TimeUnit.MINUTES.toMillis(60);
		expiration.setTime(expTimeMillis);

		// PUT Pre-Signed URL (GET)
		GeneratePresignedUrlRequest generatePresignedUrlRequest =
			new GeneratePresignedUrlRequest(bucket, fileSavePath)
				.withMethod(HttpMethod.GET)
				.withExpiration(expiration);

		URL url = s3Client.generatePresignedUrl(generatePresignedUrlRequest);
		String getPreSignedUrl = url.toString();

		fileVO.setPreSignedUrl(getPreSignedUrl);

		return fileVO;

	}

	/**
	 * Client에서 S3 전체 Download하기 위한 Pre-Signed URL 생성
	 *
	 * @author YTSEO
	 */
	@Override
	@Transactional(rollbackFor = {Exception.class})
	public List<FileVO> createPreSignedDownloadUrls(String atchFileGrId) {

		List<FileVO> fileVOs = findFiles(atchFileGrId);

		for (int i = 0; i < fileVOs.size(); i++) {
			String fileSavePath = fileVOs.get(i).getAtchFileSavePathCtn();

			// AWS SDK
			s3Client = AmazonS3ClientBuilder
				.standard()
				.withRegion(Regions.AP_NORTHEAST_2).build();

			// Pre-Signed URL 만료 시간 (60분 후)
			Date expiration = new Date();
			long expTimeMillis = expiration.getTime();
			expTimeMillis += TimeUnit.MINUTES.toMillis(60);
			expiration.setTime(expTimeMillis);

			// PUT Pre-Signed URL (GET)
			GeneratePresignedUrlRequest generatePresignedUrlRequest =
				new GeneratePresignedUrlRequest(bucket, fileSavePath)
					.withMethod(HttpMethod.GET)
					.withExpiration(expiration);

			URL url = s3Client.generatePresignedUrl(generatePresignedUrlRequest);
			String getPreSignedUrl = url.toString();

			fileVOs.get(i).setPreSignedUrl(getPreSignedUrl);
		}
		return fileVOs;

	}


    @Override
    @Transactional(rollbackFor = {Exception.class})
    public int createFileForUpload(String atchFileGrId, MultipartFile[] files, String[] fileSortOrds, String atchFileTpCd,String editorName) {
        UserSessionVO UserSessionVO = SessionScopeUtil.getContextSession();
        int insertedRows = 0;
        List<FileVO> insertFiles = new ArrayList<FileVO>();
        ClassLoader classLoader = getClass().getClassLoader();
        String classpath = classLoader.getResource("").getPath();
        try {
            for (int i = 0; i < files.length; i++) {
                MultipartFile file = files[i];
                String uuid = UUID.randomUUID().toString();
                String originalFileName = file.getOriginalFilename();

				if (file == null || originalFileName == null) {
					continue;
				}


                String atchFileSaveNm = originalFileName.substring(0, originalFileName.lastIndexOf(".")) + "[" + uuid + "]." + originalFileName.substring(originalFileName.lastIndexOf(".") + 1);
                String currentDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
                String folderPath;
                if ("dev".equals(profile) && "dext5".equals(editorName)) {
                    folderPath = nasUploadPath + "/" + editorName + "/" + currentDate;
                } else if ("default".equals(profile) || "local".equals(profile)) {
                    folderPath = classpath + uploadPath + "/" + editorName + "/" + currentDate;
                } else {
                    folderPath = uploadPath + "/" + editorName + "/" + currentDate;
                }
                String filePath = folderPath + "/" + atchFileSaveNm;
                Integer sortOrd = null;
                if (fileSortOrds != null && fileSortOrds.length > i && !fileSortOrds[i].equals("")) {
                    sortOrd = Integer.parseInt(fileSortOrds[i]);
                }
                if(editorName.equals("dext5")){

                        try {
                            FileItem nextFileItem = (FileItem) file;
                            if (nextFileItem.isEligibleFile()) {
                                nextFileItem.saveAs(folderPath,atchFileSaveNm);
                            }
                        } catch (ClassCastException e) {
                            System.out.println(e.getMessage());
                        }

                }else{
                    File folder = new File(folderPath);
                    if (!folder.exists()) folder.mkdirs();
                    file.transferTo(new File(filePath));
                }


				FileVO fileVO = FileVO.builder()
					.atchFileId(UUID.randomUUID().toString())
					.atchFileNm(file.getOriginalFilename())
					.sortOrd(sortOrd)
					.atchFileSaveLocDivsCd("ONSITE")
					.atchFileSaveNm(atchFileSaveNm)
					.atchFileSize((int)file.getSize())
					.atchFileEfnmNm(originalFileName.substring(originalFileName.lastIndexOf(".") + 1))
					.atchFileSavePathCtn(filePath)
					.atchFileTpCd(atchFileTpCd)
					.useYn("Y").build();

				insertFiles.add(fileVO);
			}

			Collections.sort(insertFiles);
			for (FileVO insertFile : insertFiles) {
				insertedRows += fileRepository.upsertFile(atchFileGrId, insertFile, UserSessionVO);
			}

		} catch (IOException e) {
			throw new BusinessException("file uplaod failed", FILE_UPLOAD_FAILED, e);
		}
		return insertedRows;
	}

    @Override
    @Transactional(rollbackFor = {Exception.class})
    public int createFileWithNewFileGroupId(String oldAtchFileGrId, String newAtchFileGrId, MultipartFile[] files, String[] fileSortOrds, String atchFileTpCd) {
        UserSessionVO session = SessionScopeUtil.getContextSession();
        int insertedRows = 0;
        List<FileVO> oldFileList = fileRepository.selectFiles(oldAtchFileGrId);
        for (FileVO oldFile : oldFileList) {
            insertedRows += fileRepository.upsertFile(newAtchFileGrId, oldFile, session);
        }
        insertedRows += createFileForUpload(newAtchFileGrId, files, fileSortOrds, atchFileTpCd,"N");

		return insertedRows;
	}

	@Override
	public Resource createFileForDownload(FileVO fileVO) {
		File file = new File(fileVO.getAtchFileSavePathCtn());
		Path path = Paths.get(file.getAbsolutePath());
		ByteArrayResource resource = null;
		try {
			resource = new ByteArrayResource(Files.readAllBytes(path));
		} catch (IOException ie) {
			throw new BusinessException("file download failed", FILE_DOWNLOAD_FAILED, ie);
		}
		return resource;
	}

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public int modifyFiles(List<FileVO> files) {
		UserSessionVO session = SessionScopeUtil.getContextSession();
		int result = 0;
		for (int i = 0; i < files.size(); i++) {
			result += fileRepository.updateFiles(files.subList(i, i + 1), session);
		}
		return result;
	}

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public int modifyFilesToUnuseByGrIdAndFileId(List<FileGrIdFileIdVO> idList) {
		UserSessionVO session = SessionScopeUtil.getContextSession();
		int result = 0;

		for (int i = 0; i < idList.size(); i++) {
			FileGrIdFileIdVO fileGrIdFileIdVO = idList.get(i);
			result += fileRepository.updateFilesToUnuseByGrIdAndFileId(fileGrIdFileIdVO.getAtchFileGrId(),fileGrIdFileIdVO.getAtchFileId(),session);
			try {
				FileVO fileVO = findFile(fileGrIdFileIdVO.getAtchFileGrId(), fileGrIdFileIdVO.getAtchFileId());
				String filePath = fileVO.getAtchFileSavePathCtn();
				File file = new File(filePath);
				Path path = Paths.get(file.getAbsolutePath());
				Files.deleteIfExists(path);
			} catch (Exception ex) {
				// 물리적 삭제 실패는 넘어감. DB 삭제 우선
				log.error(ex.getMessage(), ex);
			}
		}
		return result;
	}

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public int modifyFilesWithNewGroupId(String atchFileGrId, List<FileVO> files) {
		UserSessionVO session = SessionScopeUtil.getContextSession();

		List<FileVO> oldFileList = new ArrayList<>();
		if (files.size() > 0) {
			oldFileList = fileRepository.selectFiles(files.get(0).getAtchFileGrId());
		}

		for (FileVO oldFile : oldFileList) {
			fileRepository.upsertFile(atchFileGrId, oldFile, session);
		}
		for (FileVO newFile : files) {
			newFile.setAtchFileGrId(atchFileGrId);
		}
		modifyFiles(files);

		return 0;
	}

	private byte[] readFileContent(String filename) throws IOException {
		FileInputStream fileInputStream = new FileInputStream(filename);
		byte[] fileContent = IOUtils.toByteArray(fileInputStream);
		fileInputStream.close();
		return fileContent;
	}

	public void responseZipFromAttachments(OutputStream os, List<FileVO> fileVOs) {
		try (ZipOutputStream zos = new ZipOutputStream(os)) {
			for (FileVO file : fileVOs) {
				byte[] fileContent = readFileContent(file.getAtchFileSavePathCtn());
				ZipEntry zipEntry = new ZipEntry(file.getAtchFileNm());
				zos.putNextEntry(zipEntry);
				zos.write(fileContent);
				zos.closeEntry();
			}
		} catch (IOException e) {
			log.error(e.getMessage(), e);
		}
	}
}
