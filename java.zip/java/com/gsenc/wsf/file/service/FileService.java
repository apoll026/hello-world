package com.gsenc.wsf.file.service;

import java.io.OutputStream;
import java.util.List;

import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

import com.gsenc.wsf.file.model.FileGrIdFileIdVO;
import com.gsenc.wsf.file.model.FileVO;

public interface FileService {

    FileVO findFile(String atchFileGrId, String atchFileId);

    List<FileVO> findFiles(String atchFileGrId);

    int createFileForUpload(String atchFileGrId, MultipartFile[] files, String[] fileSortOrds, String atchFileTpCd,String editorName);
    List<FileVO> createPreSignedUploadUrl(String atchFileGrId, String [] originalFileNameArr, String [] fileSizeArr, String [] fileTypeArr, String atchFileTpCd);
    FileVO createPreSignedDownloadUrl(String atchFileGrId, String atchFileId);
    List<FileVO> createPreSignedDownloadUrls(String atchFileGrId);

    String saveDextEditorFiles(MultipartFile[] files) throws Exception;

    int createFileWithNewFileGroupId(String oldAtchFileGrId, String newAtchFileGrId, MultipartFile[] files, String[] fileSortOrds, String atchFileTpCd);

    Resource createFileForDownload(FileVO fileVO);


    int modifyFiles(List<FileVO> files);

    int modifyFilesToUnuseByGrIdAndFileId(List<FileGrIdFileIdVO> IdList);

    int modifyFilesWithNewGroupId(String atchFileGrId, List<FileVO> files);


    void responseZipFromAttachments(OutputStream os, List<FileVO> fileVOs);
}
