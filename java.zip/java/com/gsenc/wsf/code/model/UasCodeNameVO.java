package com.gsenc.wsf.code.model;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class UasCodeNameVO {
	private String clss;
	private String code;
	private String codeName;
	private String subCode;
	private String useYn;
}
