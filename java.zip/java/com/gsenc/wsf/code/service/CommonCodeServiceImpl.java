package com.gsenc.wsf.code.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gsenc.wsf.code.model.CommonCodeConditionVO;
import com.gsenc.wsf.code.model.CommonCodeGroupRequestVO;
import com.gsenc.wsf.code.model.CommonCodeGroupResponseVO;
import com.gsenc.wsf.code.model.CommonCodeHeaderResponseVO;
import com.gsenc.wsf.code.model.CommonCodeNameResponseVO;
import com.gsenc.wsf.code.model.CommonCodeRequestVO;
import com.gsenc.wsf.code.model.CommonCodeResponseVO;
import com.gsenc.wsf.code.model.UasCodeNameVO;
import com.gsenc.wsf.code.repository.CommonCodeRepository;
import com.gsenc.wsf.common.model.DmlResponseVO;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CommonCodeServiceImpl implements CommonCodeService {

	private final CommonCodeRepository commonCodeRepository;

	@Override
	@Transactional(readOnly = true)
	public List<CommonCodeGroupResponseVO> findCommonCodeGroups(
		String searchGroupCode,
		String useYn,
		String searchCode) {

		UserSessionVO userSession = SessionScopeUtil.getContextSession();
		return commonCodeRepository.selectCommonCodeGroups(searchGroupCode, useYn, searchCode, userSession.getLangCd());
	}

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public DmlResponseVO saveCommonCodeGroups(List<CommonCodeGroupRequestVO> codeGroups) {
		DmlResponseVO dmlResponseVO = new DmlResponseVO();

		UserSessionVO userSession = SessionScopeUtil.getContextSession();

		for (int i = 0; i < codeGroups.size(); i++) {
			commonCodeRepository.upsertCommonCodeGroups(codeGroups.subList(i, i + 1), userSession);
		}

		List<CommonCodeGroupRequestVO> deleteCodeGroups = codeGroups.stream()
			.filter((groups) -> "D".equals(groups.getCrudKey()))
			.collect(Collectors.toList());

		if (!deleteCodeGroups.isEmpty()) {
			commonCodeRepository.deleteCommonCodeGroups(deleteCodeGroups);
			commonCodeRepository.deleteCommonCodesByCodeGroup(deleteCodeGroups);
		}

		return dmlResponseVO;
	}

	@Override
	@Transactional(readOnly = true)
	public List<CommonCodeResponseVO> findCommonCodes(String cmnGrCd) {
		UserSessionVO userSession = SessionScopeUtil.getContextSession();

		return commonCodeRepository.selectCommonCodes(cmnGrCd, userSession.getLangCd());
	}

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public DmlResponseVO saveCommonCodes(List<CommonCodeRequestVO> codes) {
		DmlResponseVO dmlResponseVO = new DmlResponseVO();

		UserSessionVO userSession = SessionScopeUtil.getContextSession();

		for (int i = 0; i < codes.size(); i++) {
			commonCodeRepository.upsertCommonCodes(codes.subList(i, i + 1), userSession);
		}

		List<CommonCodeRequestVO> deleteCodes = codes.stream()
			.filter((code) -> "D".equals(code.getCrudKey()))
			.collect(Collectors.toList());
		if (!deleteCodes.isEmpty()) {
			commonCodeRepository.deleteCommonCodes(deleteCodes);
		}

		return dmlResponseVO;
	}

	@Override
	@Transactional(readOnly = true)
	public CommonCodeHeaderResponseVO findCommonCodeHeader(String cmnGrCd) {
		return commonCodeRepository.selectCommonCodeHeader(cmnGrCd);
	}

	@Override
	public List<CommonCodeNameResponseVO> findCommonCodeNames(String cmnGrCd) {
		UserSessionVO userSession = SessionScopeUtil.getContextSession();
		return commonCodeRepository.selectCommonCodeNames(cmnGrCd, userSession.getLangCd());
	}

	@Override
	public List<CommonCodeNameResponseVO> findCommonCodeNamesWithCode(String cmnGrCd) {
		UserSessionVO userSession = SessionScopeUtil.getContextSession();
		return commonCodeRepository.selectCommonCodeNamesWithCode(cmnGrCd, userSession.getLangCd());
	}

	@Override
	public List<CommonCodeNameResponseVO> findCommonCodeNamesCondition(CommonCodeConditionVO condition) {
		UserSessionVO userSession = SessionScopeUtil.getContextSession();
		return commonCodeRepository.selectCommonCodeNamesCondition(condition, userSession.getLangCd());
	}

	@Override
	public List<UasCodeNameVO> findUasCodeNames(String clss) {
		return commonCodeRepository.selectUasCodeNames(clss);
	}
}
