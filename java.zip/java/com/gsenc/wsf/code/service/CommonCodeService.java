package com.gsenc.wsf.code.service;

import java.util.List;

import com.gsenc.wsf.code.model.CommonCodeConditionVO;
import com.gsenc.wsf.code.model.CommonCodeGroupRequestVO;
import com.gsenc.wsf.code.model.CommonCodeGroupResponseVO;
import com.gsenc.wsf.code.model.CommonCodeHeaderResponseVO;
import com.gsenc.wsf.code.model.CommonCodeNameResponseVO;
import com.gsenc.wsf.code.model.CommonCodeRequestVO;
import com.gsenc.wsf.code.model.CommonCodeResponseVO;
import com.gsenc.wsf.code.model.UasCodeNameVO;
import com.gsenc.wsf.common.model.DmlResponseVO;

public interface CommonCodeService {

	List<CommonCodeGroupResponseVO> findCommonCodeGroups(
		String searchGroupCode,
		String useYn,
		String searchCode);

	DmlResponseVO saveCommonCodeGroups(List<CommonCodeGroupRequestVO> codeGroups);

	List<CommonCodeResponseVO> findCommonCodes(String cmnGrCd);

	DmlResponseVO saveCommonCodes(List<CommonCodeRequestVO> codes);

	CommonCodeHeaderResponseVO findCommonCodeHeader(String cmnGrCd);

	List<CommonCodeNameResponseVO> findCommonCodeNames(String cmnGrCd);

	List<CommonCodeNameResponseVO> findCommonCodeNamesWithCode(String cmnGrCd);

	List<CommonCodeNameResponseVO> findCommonCodeNamesCondition(CommonCodeConditionVO condition);

	List<UasCodeNameVO> findUasCodeNames(String clss);

}
