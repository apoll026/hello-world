package com.gsenc.wsf.multidb;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface PrimaryMultiDBTestRepository {
    void insertPrimary(@Param("col1")String col1, @Param("col2")String col2);
}
