package com.gsenc.wsf.multidb;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class MultiDBTestServiceImpl implements MultiDBTestService {

    private final PrimaryMultiDBTestRepository primaryMultiDBTestRepository;
//    private final SecondaryMultiDBTestRepository secondaryMultiDBTestRepository;

    @Override
    @Transactional(rollbackFor = {Exception.class})
    public String multiDBTest(String col1, String col2) {
        primaryMultiDBTestRepository.insertPrimary(col1, col2);
//        secondaryMultiDBTestRepository.insertSecondary(null, col2);
        return "success";
    }

}
