package com.gsenc.wsf.multidb;

public interface MultiDBTestService {

    String multiDBTest(String col1,String col2);

}
