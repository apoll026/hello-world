package com.gsenc.wsf.multidb;

import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "Multi DB")
@Validated
@RequestMapping("/api")
public class MultiDBTestController {

    private final MultiDBTestService multiDBTestService;

    @GetMapping("/multiDBTest/{col1}/{col2}")
    @Operation(summary = "멀티DB 샘플")
    public String multiDBTest(@PathVariable String col1, @PathVariable String col2) {
        return multiDBTestService.multiDBTest(col1,col2);
    }

}
