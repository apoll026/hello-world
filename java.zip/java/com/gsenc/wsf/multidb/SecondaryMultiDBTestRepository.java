package com.gsenc.wsf.multidb;

import org.apache.ibatis.annotations.Param;

import com.gsenc.wsf.common.annotation.SecondaryMapper;

@SecondaryMapper
public interface SecondaryMultiDBTestRepository {
    void insertSecondary(@Param("col1")String col1, @Param("col2")String col2);
}
