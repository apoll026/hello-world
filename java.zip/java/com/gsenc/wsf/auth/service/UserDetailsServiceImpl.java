package com.gsenc.wsf.auth.service;

import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.gsenc.wsf.employee.repository.EmployeeRepository;
import com.gsenc.wsf.session.model.EmployeeVO;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {
		EmployeeVO employeeInfo = employeeRepository.selectEmployeeByUserId(userId);

		if (employeeInfo == null) {
			throw new UsernameNotFoundException("User not found: " + userId);
		}

		return new org.springframework.security.core.userdetails.User(
			employeeInfo.getMailId(),
			employeeInfo.getPasswd(),
			Collections.singletonList(new SimpleGrantedAuthority("ROLE_USER"))
		);
	}
}
