package com.gsenc.cfs.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ErrorMessage {

    public static String extractOracleErrorMessage(String message) {
        // ORA-20001: 다음 줄부터 ORA-06512 이전까지 텍스트 추출
        Pattern pattern = Pattern.compile(
                "^\\s*[^:]+:\\s*(.*?)(?=ORA-\\d{5}:|$)",
                Pattern.DOTALL
        );
        Matcher matcher = pattern.matcher(message);

        if (matcher.find()) {
            String result = matcher.group(1).trim();
            return result;
        } else {
            return message;
        }
    }

}
