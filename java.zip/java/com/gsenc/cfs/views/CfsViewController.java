package com.gsenc.cfs.views;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api")
@Controller
public class CfsViewController {

    @GetMapping("/cfs/view/cfsnw0300")
    public String viewUseList() {
        log.info("Controller viewUseList init ok");
        return "views/cfsnw0300/cfs_n_w0300";
    }

    @GetMapping("/cfs/view/cfsnw0100")
    public String viewGoToRegist() {
        log.info("Controller viewGoToRegist init ok");
        return "views/cfsnw0100/cfs_n_w0100";
    }
}
