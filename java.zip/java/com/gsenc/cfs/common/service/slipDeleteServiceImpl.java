package com.gsenc.cfs.common.service;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
//@SuppressWarnings("unchecked")
public class slipDeleteServiceImpl {


}
