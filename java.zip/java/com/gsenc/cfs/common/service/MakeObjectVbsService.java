package com.gsenc.cfs.common.service;

import java.util.Map;

public interface MakeObjectVbsService {

    String funcGetDvsnAuth(Map<String, Object> paramMap);

}
