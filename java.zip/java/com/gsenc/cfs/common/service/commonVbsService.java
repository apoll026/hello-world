package com.gsenc.cfs.common.service;

import java.util.Map;

import com.gsenc.cfs.common.model.GsrsMap;

public interface commonVbsService {

    GsrsMap procGetProfNumCommit(Map<String, Object> paramMap);

    String objRsReplace(String str);

    String fncProcGetApprNumCommit(Map<String, Object> paramMap);

    String fncProcGetDocuNum(Map<String, Object> paramMap);

    String fncProcGetRqstNum(Map<String, Object> paramMap);

    String fncBranchAcctCode(Map<String, Object> paramMap);

}
