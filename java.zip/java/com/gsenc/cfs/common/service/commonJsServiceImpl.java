package com.gsenc.cfs.common.service;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.gsenc.cfs.common.dao.CommonDAO;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
//@SuppressWarnings("unchecked")
public class commonJsServiceImpl implements commonJsService {

	private final static String _COMMON_NAMESPACE = "common.commonJs.";
	private final CommonDAO commonDAO;

	/*

	AS-IS : Common.js.FUNC_EDU_CHK

	기능 : 교훈련비 작성 여부 확인

	swagger
	{
	  "costDept": "92996J",
	  "acctCode": "45050700"
	}



	*/
	public String funcEduChk(Map<String, Object> paramMap) {//UserSessionVO userSession = SessionScopeUtil.getContextSession();

        return (String) commonDAO.selectOne(_COMMON_NAMESPACE + "funcEduChk", paramMap);
	}

	// AS-IS : Common.js.FUNC_EDU_CHK - 외화송금의뢰서 여부 확인
	public String funcFamtChk(Map<String, Object> paramMap) {//UserSessionVO userSession = SessionScopeUtil.getContextSession();
        return (String) commonDAO.selectOne(_COMMON_NAMESPACE + "funcFamtChk", paramMap);

	}

	// AS-IS : Common.js.FUNC_SAVE_BEFR_CHK - 저장전 체크오류
	public String funcSaveBefrChk(Map<String, Object> paramMap) {//UserSessionVO userSession = SessionScopeUtil.getContextSession();
		return (String) commonDAO.selectOne(_COMMON_NAMESPACE + "funcSaveBefrChk", paramMap);

	}
}
