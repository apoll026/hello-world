package com.gsenc.cfs.common.service;

import java.util.Map;

import com.gsenc.cfs.common.model.GsrsMap;

public interface EasCommonApprService {

    Map<String, Object> selectCommonProcGetDocuNum(Map<String, Object> paramMap);

    GsrsMap getAppFaty800(Map<String, Object> paramMap);

}
