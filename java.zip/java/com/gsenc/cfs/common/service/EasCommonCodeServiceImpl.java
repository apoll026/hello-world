package com.gsenc.cfs.common.service;

import java.util.*;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gsenc.cfs.common.dao.CommonDAO;
import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.common.util.StringUtil;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class EasCommonCodeServiceImpl implements EasCommonCodeService {

	private final static String _COMMON_NAMESPACE = "common.EasCode.";

	@Autowired
	private CommonDAO commonDao;

	@SuppressWarnings("unchecked")
	public List<GsrsMap> selectCommonProcGetFaty500(Map<String, Object> paramMap) {//UserSessionVO userSession = SessionScopeUtil.getContextSession();

		commonDao.selectList(_COMMON_NAMESPACE + "selectCommonProcGetFaty500", paramMap);

		return (List<GsrsMap>) paramMap.get("list");
	}

	/* 파라미터 정의
    class, clss => CLSS 필드와 equals 비교
    code => CODE 필드와 equals 비교
    ordField =>
            Camel Case 문자열로 넘겨줘야함
            ORDER BY 로 필드를 지정할때 사용
            code, codeName, subCode 셋중 하나만 가능
            ※ DEFAULT는 프로시저에서 사용중인 code
    ordType =>
            ASC, DESC 택일
            ※ DEFAULT는 프로시저에서 사용중인 asc
     */
	@SuppressWarnings("unchecked")
	public List<GsrsMap> selectCommonCodeList(Map<String, Object> paramMap) {
		paramMap.put("clss", StringUtil.isNullToStringDefault(paramMap.get("clss"), StringUtil.isNullToString(paramMap.get("class")))); // 화면마다 class, clss 케이스가 있어서 둘다 처리
		paramMap.put("ordField", StringUtil.isNullToStringDefault(paramMap.get("ordField"), "code"));

		// 프로시저에서 조회
		commonDao.selectList(_COMMON_NAMESPACE + "selectCommonProcGetFaty500", paramMap);

		List<GsrsMap> list = (List<GsrsMap>) paramMap.get("list");

		String code = StringUtil.isNullToString(paramMap.get("code"));

		if (!code.isEmpty()){
			list = list.stream()
					.filter(p -> code.equals(StringUtil.isNullToString(p.get("code"))))
					.collect(Collectors.toList());
		}

		list.sort(new Comparator<GsrsMap>() {
            @Override
            public int compare(GsrsMap o1, GsrsMap o2) {
				String ordField = StringUtil.isNullToString(paramMap.get("ordField"));
				String ordType = StringUtil.isNullToString(paramMap.get("ordType")).toLowerCase();

                String ordField1 = (String) o1.get(ordField);
				String ordField2 = (String) o2.get(ordField);

				if ("desc".equals(ordType)){
					return ordField2.compareTo(ordField1); // 내림차순
				} else {
					return ordField1.compareTo(ordField2); // 오름차순
				}
            }
        });

		return list;
	}

	@SuppressWarnings("unchecked")
	public List<GsrsMap> selectCommonCodeSapList(Map<String, Object> paramMap) {
		paramMap.put("clss", StringUtil.isNullToStringDefault(paramMap.get("clss"), StringUtil.isNullToString(paramMap.get("class")))); // 화면마다 class, clss 케이스가 있어서 둘다 처리
		paramMap.put("ordField", StringUtil.isNullToStringDefault(paramMap.get("ordField"), "code"));

		// 프로시저에서 조회
		commonDao.selectList(_COMMON_NAMESPACE + "selectCommonProcGetFaty500Sap", paramMap);

		List<GsrsMap> list = (List<GsrsMap>) paramMap.get("list");

		String code = StringUtil.isNullToString(paramMap.get("code"));

		if (!code.isEmpty()){
			list = list.stream()
					.filter(p -> code.equals(StringUtil.isNullToString(p.get("code"))))
					.collect(Collectors.toList());
		}

		list.sort(new Comparator<GsrsMap>() {
			@Override
			public int compare(GsrsMap o1, GsrsMap o2) {
				String ordField = StringUtil.isNullToString(paramMap.get("ordField"));
				String ordType = StringUtil.isNullToString(paramMap.get("ordType")).toLowerCase();

				String ordField1 = (String) o1.get(ordField);
				String ordField2 = (String) o2.get(ordField);

				if ("desc".equals(ordType)){
					return ordField2.compareTo(ordField1); // 내림차순
				} else {
					return ordField1.compareTo(ordField2); // 오름차순
				}
			}
		});

		return list;
	}

	/* 파라미터 정의
    class, clss => CLSS 필드와 equals 비교
    code => CODE 필드와 equals 비교
    subCode => SUB_CODE 필드와 equals 비교
    ordField =>
            Camel Case 문자열로 넘겨줘야함
            ORDER BY 로 필드를 지정할때 사용
            code, codeName, subCode 셋중 하나만 가능
            ※ DEFAULT는 프로시저에서 사용중인 code
    ordType =>
            ASC, DESC 택일
            ※ DEFAULT는 프로시저에서 사용중인 asc
     */
	@SuppressWarnings("unchecked")
	public List<GsrsMap> selectCommonCodeQueryList(Map<String, Object> paramMap) {
		paramMap.put("clss", StringUtil.isNullToStringDefault(paramMap.get("clss"), StringUtil.isNullToString(paramMap.get("class")))); // 화면마다 class, clss 케이스가 있어서 둘다 처리
		paramMap.put("ordType", StringUtil.isNullToString(paramMap.get("ordType")).toLowerCase());
		// 쿼리에서 조회
		return (List<GsrsMap>) commonDao.selectList(_COMMON_NAMESPACE + "selectCommonProcGetFaty500Query", paramMap);
	}

	@SuppressWarnings("unchecked")
	public List<GsrsMap> selectDeptCardList(Map<String, Object> paramMap) {
		return (List<GsrsMap>)commonDao.selectList(_COMMON_NAMESPACE + "selectDeptCardList", paramMap);
	}

	public Boolean selectCommIcheLevel(Map<String, Object> paramMap) {

		String empNo = StringUtil.isNullToString(paramMap.get("empNo"));

		// 혹시 화면에서 넘어온 세션 정보가 없으면 한번더 확인
		if (empNo.isEmpty()){
			UserSessionVO userSession = SessionScopeUtil.getContextSession();

			if (userSession != null){
				paramMap.put("empNo", StringUtil.isNullToStringDefault(userSession.getEmpNo(), ""));
			}
		}

		int rtnCnt = (int) commonDao.selectOne(_COMMON_NAMESPACE + "selectCommIcheLevel", paramMap);

        return rtnCnt > 0;
	}

}
