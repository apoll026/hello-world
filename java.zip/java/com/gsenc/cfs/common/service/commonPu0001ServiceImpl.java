package com.gsenc.cfs.common.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.gsenc.cfs.common.dao.CommonDAO;
import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.common.util.StringUtil;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
//@SuppressWarnings("unchecked")
public class commonPu0001ServiceImpl implements commonPu0001Service {

	private final static String _COMMON_NAMESPACE = "common.commonPu0001.";
	private final static String _BUSINESS_TRIP = "bsl.businessTrip.UA_W_BT001_NTx.";
	private final static String _CORPORATION_CARD = "bsl.corporationCard.CCNTx.";
	private final CommonDAO commonDAO;


	public List<GsrsMap> selectGetData(Map<String, Object> paramMap) {//UserSessionVO userSession = SessionScopeUtil.getContextSession();

		Map<String, Object> inputMap = new HashMap<>();

		List<GsrsMap> rtnMap = new ArrayList<GsrsMap>();
		List<GsrsMap> rtnData = new ArrayList<GsrsMap>();

		UserSessionVO userSession = SessionScopeUtil.getContextSession();

		String empNo = userSession.getEmpNo();
		String auth = userSession.getAuth();
		String userGroup = userSession.getUserGrp();

		if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("1")) {

			// 사원검색
			/*

			case 1: GetData1(CONDITION, OPTION); break;   //사원검색

			CONDITION -> condition
			OPTION -> option

			rtnMap.get("EMP_NAME")
			rtnMap.get("BIZT_TITL")
			rtnMap.get("DEPT_CODE")
			rtnMap.get("DEPT_NAME")
			rtnMap.get("MAIL_ID")
			rtnMap.get("INSA_DIVS")
			rtnMap.get("BIZT_ETC")

			swagger
			{
			  "type" : "1",
			  "condition" : "박혜",
			  "option" : ""
			}

			{
			  "type" : "1",
			  "condition" : "",
			  "option" : "111390"
			}

			*/

			inputMap.put("empInfo", StringUtil.isNullToString(paramMap.get("condition")));
			inputMap.put("deptCode", StringUtil.isNullToString(paramMap.get("option")));

			rtnMap = (List<GsrsMap>)commonDAO.selectList(_COMMON_NAMESPACE + "selectGetData1", inputMap);

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("2")) {

			// 부서검색
			/*

			case 2: GetData2(CONDITION, OPTION, URL_DIVS, LIKE_YN, GUBUN); break;	  //부서검색

			CONDITION -> condition
			OPTION -> option
			URL_DIVS -> url
			LIKE_YN -> like
			GUBUN -> gubun

			rtnMap.get("DEPT_CODE")
			rtnMap.get("DEPT_NAME")
			rtnMap.get("FUNC_AREA")
			rtnMap.get("AREA_NAME")
			rtnMap.get("SITE_CD")
			rtnMap.get("CURC_CODE")
			rtnMap.get("DTLS_YN")
			rtnMap.get("COST_DEPT")
			rtnMap.get("COST_DEPTNM")
			rtnMap.get("STRT_DATE")
			rtnMap.get("USE_END_DATE")
			rtnMap.get("RCPT_MNGR_YN")
			rtnMap.get("RCPT_TERM")
			rtnMap.get("RECP_YN")
			rtnMap.get("BRANCH_YN")
			rtnMap.get("DEPT_DIVS")
			rtnMap.get("BRANCH_POST")

			swagger
			{
			  "type" : "2",
			  "condition" : "91751J",
			  "option" : "I",
			  "like" : "Y"
			}

			*/


			inputMap.put("strClass", "1");
			inputMap.put("strCode", StringUtil.isNullToString(paramMap.get("condition")));
			inputMap.put("strName", "");
			inputMap.put("strEmp", empNo);
			inputMap.put("strAuth", auth);
			inputMap.put("strFlag", StringUtil.isNullToString(paramMap.get("option")));
			inputMap.put("strAcct", StringUtil.isNullToString(paramMap.get("url")));
			inputMap.put("strLike", StringUtil.isNullToString(paramMap.get("like")));
			inputMap.put("strGroup", userGroup);
			inputMap.put("strGubun", StringUtil.isNullToString(paramMap.get("gubun")));
			inputMap.put("strLang", "");


			rtnMap = (List<GsrsMap>)commonDAO.selectList(_COMMON_NAMESPACE + "selectGetData2", inputMap);
		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("3")) {

			// 적요코드 조회
			/*

			case 3: GetData3(CONDITION, OPTION); break;	  //적요코드 조회

			CONDITION -> condition
			OPTION -> option

			rtnMap.get("NOTE_NAME")
			rtnMap.get("NOTE_CODE")

			swagger
			{
			  "type" : "3",
			  "condition" : "3104",
			  "option" : "1001"
			}

			{
			  "type" : "3",
			  "condition" : "3104",
			  "option" : ""
			}

			*/

			inputMap.put("strOption", StringUtil.isNullToString(paramMap.get("condition")));
			inputMap.put("strCode", StringUtil.isNullToString(paramMap.get("option")));

			if (!StringUtil.isNullToString(inputMap.get("strCode")).trim().equals("")){
				rtnMap = (List<GsrsMap>)commonDAO.selectList(_CORPORATION_CARD + "GetEtcList2", inputMap);	// 적요항목 조회
			}
			else{
				rtnMap = (List<GsrsMap>)commonDAO.selectList(_CORPORATION_CARD + "getEtcList", inputMap);  // 적요항목 조회
			}
		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("4")) {

			// 부서별 카드정보 조회
			/*

			case 4: GetData4(CONDITION); break;			  //부서별 카드정보 조회

			CONDITION -> condition

			rtnMap.get("ORIGIN_NUM")
			rtnMap.get("EMP_NM")
			rtnMap.get("CARD_NUM")
			rtnMap.get("CMPN_NAME")

			swagger
			{
			  "type" : "4",
			  "condition" : "90474J",
			  "option" : ""
			}
			*/

			inputMap.put("strDept", StringUtil.isNullToString(paramMap.get("condition")));

			rtnMap = (List<GsrsMap>)commonDAO.selectList(_COMMON_NAMESPACE + "selectGetData4", inputMap);	// 부서별 보유카드 조회

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("5")) {

			// 계정과목 조회
			/*

			case 5: GetData5(CONDITION); break;			  //계정과목 조회

			CONDITION -> condition

			rtnMap.get("MANG_YN")
			rtnMap.get("ACCT_NAME")
			rtnMap.get("DRCR_DIVS")
			rtnMap.get("ISSU_DIVS")
			rtnMap.get("FUND_YN")
			rtnMap.get("SLIP_YN")
			rtnMap.get("FNSH_DATE_YN")
			rtnMap.get("REMD_DIVS")
			rtnMap.get("ACCT_CODE")
			rtnMap.get("USE_DIVS")
			rtnMap.get("INTR_RATE_YN")
			rtnMap.get("CNTL_YN")

			swagger
			{
			  "type" : "5",
			  "condition" : "예수금"
			}


			*/

			inputMap.put("strKey", StringUtil.isNullToString(paramMap.get("condition")));

			rtnMap = (List<GsrsMap>)commonDAO.selectList(_BUSINESS_TRIP + "getAcctName2", inputMap);	// 계정과목 조회

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("6")) {

			// 비용항목 조회
			/*

			case 6: GetData6(CONDITION, OPTION, GUBUN, URL_DIVS); break;			  //비용항목 조회

			CONDITION -> condition
			OPTION -> option
			GUBUN -> gubun
			URL_DIVS -> url

			rtnMap.get("ACCT_GRP")
			rtnMap.get("ACCT_GRP_NAME")
			rtnMap.get("DTLS_YN")

			swagger
			{
			  "type" : "6",
			   "condition": "",
			  "option": "",
			  "gubun": "A",
			  "url": ""
			}

			소스에서는 더 받는게 있는데 UAS_B_UC001.cs 에서는 주석이 되어 있는 부분이 있음 개발시 꼭 받아야 되는 부분이면 쿼리부터 수정해야됨

			Response.Write("1," + resultDataset.Tables[0].Rows[0]["Acct_Grp"].ToString() + "," +
				resultDataset.Tables[0].Rows[0]["Acct_Grp_Name"].ToString() + "," +
				resultDataset.Tables[0].Rows[0]["Dtls_Yn"].ToString());

			//resultDataset.Tables[0].Rows[0]["fund_yn"].ToString() + "," +
			//resultDataset.Tables[0].Rows[0]["note_yn"].ToString() + "," +
			//resultDataset.Tables[0].Rows[0]["fnsh_date_yn"].ToString() + "," +


			*/

			inputMap.put("strKey", StringUtil.isNullToString(paramMap.get("condition")));
			inputMap.put("strNoAcctGrp", StringUtil.isNullToString(paramMap.get("option")));
			inputMap.put("strRemdDivs", StringUtil.isNullToString(paramMap.get("gubun")));
			inputMap.put("strInAcctGrp", StringUtil.isNullToString(paramMap.get("url")));

			rtnMap = (List<GsrsMap>)commonDAO.selectList(_BUSINESS_TRIP + "getCostName", inputMap);	// 비용항목 조회

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("7")) {

			// 접대비 총액
			/*

			case 7: GetData7(CONDITION, OPTION, CMPN_NUM, PROF_DATE, PROF_DEPT, PROF_CLSS, PROF_MAIN); break;   //같은사용일, 같은부서, 같은 거래처의 접대비 총액 조회

			CONDITION -> condition
			OPTION -> option
			CMPN_NUM -> cmpn
			PROF_DATE -> date
			PROF_DEPT -> dept
			PROF_CLSS -> clss
			PROF_MAIN -> main

			rtnMap.get("AMT")

			swagger
			{
			  "type" : "7",
			  "condition" : "06012*90084R"
			}
			*/

			String strDept = "";

			if (StringUtil.isNullToString(paramMap.get("condition")) != null && StringUtil.isNullToString(paramMap.get("condition")).contains("*")) {
				String[] array = StringUtil.isNullToString(paramMap.get("condition")).split("\\*");
				if (array.length > 1) {
					strDept = array[1];
				}
			}

			inputMap.put("strDept", strDept);
			inputMap.put("strEmp", StringUtil.isNullToString(paramMap.get("condition")));
			inputMap.put("strDate", StringUtil.isNullToString(paramMap.get("option")));
			inputMap.put("strCmpn", StringUtil.isNullToString(paramMap.get("cmpn")));
			inputMap.put("strProfNum", StringUtil.isNullToString(paramMap.get("date"))
			                       	 + StringUtil.isNullToString(paramMap.get("dept"))
									 + StringUtil.isNullToString(paramMap.get("clss"))
					                 + StringUtil.isNullToString(paramMap.get("main")));

			rtnMap = (List<GsrsMap>)commonDAO.selectList(_COMMON_NAMESPACE + "selectGetData7", inputMap);	// 접대비 총액

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("8")) {

			// 거래처 조회
			/*

			case 8: GetData8(CONDITION, OPTION); break;   //거래처 조회

			CONDITION -> condition
			OPTION -> option

			rtnMap.get("CMPN_NUM")
			rtnMap.get("CMPN_NAME")
			rtnMap.get("TAX_DIVS")
			rtnMap.get("ZIP_CODE")
			rtnMap.get("ADDR1")
			rtnMap.get("ADDR2")
			rtnMap.get("CMPN_SAP")

			swagger
			{
				"type" : "8",
			  	"condition" : "GS",
			  	"option" : "1013274048"
			}

			*/

			inputMap.put("strDivs", StringUtil.isNullToString(paramMap.get("condition")));
			inputMap.put("strKey", StringUtil.isNullToString(paramMap.get("option")));

			rtnMap = (List<GsrsMap>)commonDAO.selectList(_CORPORATION_CARD + "getCmpyKey", inputMap);	// 거래처 조회

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("9")) {

			// 전체 적요코드 조회
			/*

			case 9: GetData9(CONDITION, OPTION); break;	  //전체 적요코드 조회

			쿼리에 문제가 있어서 만들기만 하고 테스트도 안됨 꼭 사용해야 되면 쿼리부터 수정해야됨

			*/

			inputMap.put("searchText", StringUtil.isNullToString(paramMap.get("condition")));
			inputMap.put("acctCode", StringUtil.isNullToString(paramMap.get("option")));

			rtnMap = (List<GsrsMap>) commonDAO.selectList(_COMMON_NAMESPACE + "selectGetData9", inputMap);    // 전체 적요코드 조회

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("10")) {

			// 환율 조회
			/*

			case 10: GetData10(CONDITION, OPTION); break; //환율 조회

			CONDITION -> condition
			OPTION -> option

			rtnMap.get("EXHG_RATE1")

			swagger
			{
			  "type" : "10",
			  "condition" : "20250409",
			  "option" : "VES"
			}

			*/

			inputMap.put("strDate", StringUtil.isNullToString(paramMap.get("condition")));
			inputMap.put("strCurc", StringUtil.isNullToString(paramMap.get("option")));

			rtnMap = (List<GsrsMap>) commonDAO.selectList(_CORPORATION_CARD + "getExhgRate", inputMap);    // 환율 조회

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("11")) {

			// 출장국가조회
			/*

			case 11: GetData11(CONDITION); break;		  //출장국가조회

			CONDITION -> condition

			rtnMap.get("CTRY_CODE")
			rtnMap.get("CTRY_NAME")
			rtnMap.get("CURC_CODE")
			rtnMap.get("REGN_CODE")

			{
			  "type" : "11",
			  "condition" : "미국"
			}


			*/

			inputMap.put("searchText", StringUtil.isNullToString(paramMap.get("condition")));

			rtnMap = (List<GsrsMap>) commonDAO.selectList(_COMMON_NAMESPACE + "selectGetData11", inputMap);    // 출장국가조회

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("12")) {

			// 결재선 조회
			/*

			case 12: GetData12(EMP_NO, EMP_DEPT, BUSN_DIVS, URL_DIVS, GRP_NUM, DOCU_NUM); break; //결재선 조회

			EMP_NO -> empNo
			EMP_DEPT -> deptCode
			BUSN_DIVS -> busnDivs
			URL_DIVS -> busnDivs
			GRP_NUM -> grpNum
			DOCU_NUM -> docuNum

			rtnMap.get("APPRLINE")
			rtnMap.get("UPLINE")
			rtnMap.get("MSG")

			swagger
			{
			  "type" : "12",
			  "empNo" : "63598",
			  "deptCode" : "06030",
			  "busnDivs" : "UG",
			  "urlDivs" : "",
			  "grpNum" : "UG-20110103-06030-01-10000039",
			  "docuNum" : ""
			}

			*/

			inputMap.put("empNo", StringUtil.isNullToString(paramMap.get("empNo")));
			inputMap.put("deptCode", StringUtil.isNullToString(paramMap.get("deptCode")));
			inputMap.put("busnDivs", StringUtil.isNullToString(paramMap.get("busnDivs")));
			inputMap.put("urlDivs", StringUtil.isNullToString(paramMap.get("urlDivs")));

			inputMap.put("docuNum", StringUtil.isNullToString(paramMap.get("docuNum")));

			if(StringUtil.isNullToString(paramMap.get("grpNum")).isEmpty()){
				inputMap.put("grpNum", "0000");
			}
			else{
				inputMap.put("grpNum", StringUtil.isNullToString(paramMap.get("grpNum")));
			}

			commonDAO.selectList(_CORPORATION_CARD + "gheckApprLine", inputMap); // 결재선 조회

			GsrsMap map = new GsrsMap();
			map.put("apprLine", StringUtil.isNullToString(inputMap.get("apprLine")));
			map.put("upLine", StringUtil.isNullToString(inputMap.get("upLine")));
			map.put("msg", StringUtil.isNullToString(inputMap.get("msg")));

			rtnMap.add(map);

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("13")) {

			// 결재선 조회
			/*

			case 12랑 뭐가 틀린지

			case 13: GetData13(EMP_NO, EMP_DEPT, BUSN_DIVS, "", ""); break;

			EMP_NO -> empNo
			EMP_DEPT -> deptCode
			BUSN_DIVS -> busnDivs

			rtnMap.get("APPRLINE")
			rtnMap.get("UPLINE")
			rtnMap.get("MSG")

			swagger
			{
			  "type" : "13",
			  "empNo" : "63598",
			  "deptCode" : "06030",
			  "busnDivs" : "UG",
			  "urlDivs" : "",
			  "grpNum" : "",
			  "docuNum" : ""
			}

			*/

			inputMap.put("empNo", StringUtil.isNullToString(paramMap.get("empNo")));
			inputMap.put("deptCode", StringUtil.isNullToString(paramMap.get("deptCode")));
			inputMap.put("busnDivs", StringUtil.isNullToString(paramMap.get("busnDivs")));
			inputMap.put("urlDivs", StringUtil.isNullToString(paramMap.get("urlDivs")));
			inputMap.put("docuNum", StringUtil.isNullToString(paramMap.get("docuNum")));
			inputMap.put("grpNum", StringUtil.isNullToString(paramMap.get("grpNum")));


			//rtnMap = (List<GsrsMap>) commonDAO.selectList(_COMMON_NAMESPACE + "selectGetData12", inputMap);    // 결재선 조회

			commonDAO.selectList(_COMMON_NAMESPACE + "selectGetData12", inputMap); // 결재선 조회

			GsrsMap map = new GsrsMap();
			map.put("apprLine", StringUtil.isNullToString(inputMap.get("apprLine")));
			map.put("upLine", StringUtil.isNullToString(inputMap.get("upLine")));
			map.put("msg", StringUtil.isNullToString(inputMap.get("msg")));

			rtnMap.add(map);

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("14")) {

			// 결재선 조회
			/*

			case 14: GetData14(APPR_NUM); break;		  //전표조회용 결재선 조회

			APPR_NUM -> apprNum

			rtnMap.get("APPRLINE")
			rtnMap.get("UPLINE")
			rtnMap.get("MSG")

			swagger
			{
			  "type" : "14",
			  "apprNum" : "AP-UG-20110103-06030-0000041"
			}

			*/

			inputMap.put("apprNum", StringUtil.isNullToString(paramMap.get("apprNum")));

			commonDAO.selectList(_CORPORATION_CARD + "gheckApprLine2", inputMap); // 결재선 조회

			GsrsMap map = new GsrsMap();
			map.put("apprLine", StringUtil.isNullToString(inputMap.get("apprLine")));
			map.put("upLine", StringUtil.isNullToString(inputMap.get("upLine")));
			map.put("msg", StringUtil.isNullToString(inputMap.get("msg")));

			rtnMap.add(map);

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("15")) {

			// 비용항목코드 조회
			/*

			ccase 15: GetData15(); break;				  //비용항목코드 조회

			rtnMap.get("CODE")
			rtnMap.get("CODE_NAME")

			swagger
			{
			  "type" : "15"
			}

			*/

			String strClss = "";

			inputMap.put("strClss", strClss);
			rtnMap = (List<GsrsMap>) commonDAO.selectList(_COMMON_NAMESPACE + "selectGetData15", inputMap);    // 비용항목코드 조회

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("16")) {

			// 과세공제여부별 적요코드 조회
			/*

			case 16: GetData16(CONDITION, OPTION); break; //과세공제여부별 적요코드 조회

			CONDITION -> strOption
			OPTION -> strTax

			rtnMap.get("ACCT_CODE")
			rtnMap.get("ACCT_NAME")

			swagger
			{
			  "type" : "16",
			  "strOption" : "4547",
			  "strTax" : ""
			}
			*/

			inputMap.put("strOption", StringUtil.isNullToString(paramMap.get("strOption")));
			inputMap.put("strTax", StringUtil.isNullToString(paramMap.get("strTax")));
			rtnMap = (List<GsrsMap>) commonDAO.selectList(_COMMON_NAMESPACE + "selectGetData16", inputMap);    // 과세공제여부별 적요코드 조회

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("17")) {

			// 부서 조회
			/*

			case 17: GetData17(CONDITION); break;		  //부서

			CONDITION -> strDept

			rtnMap.get("CNT")

			swagger
			{
			  "type" : "17",
			  "strDept" : "G3010"
			}
			*/

			inputMap.put("strDept", StringUtil.isNullToString(paramMap.get("strDept")));
			rtnMap = (List<GsrsMap>) commonDAO.selectList(_COMMON_NAMESPACE + "selectGetData17", inputMap);    // 부서 조회

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("18")) {

			// 사업단위 조회
			/*

			case 18: GetData18(CONDITION); break;		  //사업단위 조회

			CONDITION -> strFlag

			rtnMap.get("CODE")
			rtnMap.get("CODE_NAME")
			rtnMap.get("SEQ")

			swagger
			{
			  "type" : "18",
			  "strFlag" : "Y"
			}
			*/

			inputMap.put("strFlag", StringUtil.isNullToString(paramMap.get("strFlag")));
			rtnMap = (List<GsrsMap>) commonDAO.selectList(_CORPORATION_CARD + "getDeptOption", inputMap);    // 사업단위 조회

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("19")) {

			// 전표일자 확인
			/*

			case 19: GetData19(CONDITION, OPTION); break; //전표일자 확인

			CONDITION -> strFlag
			OPTION -> strDate

			rtnMap.get("CLSE_YN")
			rtnMap.get("ON_YN")
			rtnMap.get("NOT_DEDU_YN")
			rtnMap.get("NEXT_DATE")
			rtnMap.get("ISSU_DATE")
			rtnMap.get("CLSE_MSG")

			swagger
			{
			  "type" : "19",
			  "strFlag" : "01",
			  "strDate" : "201401"
			}
			*/

			String strYear = StringUtil.isNullToString(paramMap.get("strDate")).substring(0, 4);
			String strMonth  = StringUtil.isNullToString(paramMap.get("strDate")).substring(4, 6);

			inputMap.put("strFlag", StringUtil.isNullToString(paramMap.get("strFlag")));
			inputMap.put("strYear", strYear);
			inputMap.put("strMonth", strMonth);
			rtnMap = (List<GsrsMap>) commonDAO.selectList(_CORPORATION_CARD + "checkProfDate", inputMap);    // 전표일자 확인

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("20")) {

			// 거래처조회 옵션구분제외
			/*

			case 20: GetData20(CONDITION, CMP_TYPE); break;		  // 거래처조회 옵션구분제외

			CONDITION -> strKey
			CMP_TYPE -> strDiv

			rtnMap.get("CMPN_NUM")
			rtnMap.get("CMPN_NAME")

			swagger
			{
			  "type" : "20",
			  "strKey" : "강",
			  "strDiv" : "1"
			}
			*/


			inputMap.put("strKey", StringUtil.isNullToString(paramMap.get("strKey")));
			inputMap.put("strDiv", StringUtil.isNullToString(paramMap.get("strDiv")));

			if(!StringUtil.isNullToString(paramMap.get("strDiv")).equals("")){
				if(StringUtil.isNullToString(paramMap.get("strDiv")).equals("M")){
					rtnMap = (List<GsrsMap>) commonDAO.selectList(_COMMON_NAMESPACE + "selectGetData20_1", inputMap);    // 거래처조회 옵션구분제외
				}
				else{
					rtnMap = (List<GsrsMap>) commonDAO.selectList(_COMMON_NAMESPACE + "selectGetData20_2", inputMap);    // 거래처조회 옵션구분제외
				}
			}
			else {
				rtnMap = (List<GsrsMap>) commonDAO.selectList(_COMMON_NAMESPACE + "selectGetData20_3", inputMap);    // 거래처조회 옵션구분제외
			}



		}

		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("21")) {

			// 계정과목 조회(원가명세서, 판관비명세서)
			/*

			사용하는곳이 없는것 같은데 있다면 쿼리 변경해야됨

			case 21: GetData21(CONDITION); break;		  // 계정과목 조회(원가명세서, 판관비명세서)

			CONDITION -> strKey


			rtnMap.get("CMPN_NUM")
			rtnMap.get("CMPN_NAME")

			swagger
			{
			  	"type" : "21",
			  	"strWhere": " AND acct_code <> '600001' and cntl_cost_yn = 'Y' ",
	  			"strKey": "여비"
			}
			*/

			inputMap.put("strKey", StringUtil.isNullToString(paramMap.get("strKey")));
			inputMap.put("strWhere", StringUtil.isNullToString(paramMap.get("strWhere")));

			rtnMap = (List<GsrsMap>) commonDAO.selectList(_BUSINESS_TRIP + "getAcctName2", inputMap);    // 계정과목 조회(원가명세서, 판관비명세서)



		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("22")) {

			// 회계단위 조회
			/*

			case 22: GetData22(CONDITION); break;		  //회계단위 조회

			CONDITION -> strKey

			rtnMap.get("LVL")
			rtnMap.get("ACCT_UNIT")
			rtnMap.get("UNIT_NAME")

			swagger
			{
			  "type" : "22",
			  "strKey" : "10"
			}
			*/

			//GetUnitKey(string strClass, string strCode, string strName, string strEmp, string strAuth)

			inputMap.put("strClass", "1");
			inputMap.put("strKey", StringUtil.isNullToString(paramMap.get("strKey")));
			inputMap.put("strName", "");
			inputMap.put("strEmp", empNo);
			inputMap.put("strAuth", auth);


			rtnMap = (List<GsrsMap>) commonDAO.selectList(_COMMON_NAMESPACE + "selectGetData22", inputMap);    // 회계단위 조회



		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("23")) {

			// 도움
			/*

			case 23: GetData23(CONDITION, OPTION); break;		  //도움말경로 조회

			도움말 방볍 변경으로 사용안함 amsix 도움말 이용
			*/

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("24")) {

			// 현장멘토 사업본부별 귀속부서 조회
			/*

			case 24: GetData24(CONDITION); break;		  //현장멘토 사업본부별 귀속부서 조회

			CONDITION -> strDept

			rtnMap.get("CODE_NAME")
			rtnMap.get("CODE_EXPL")
			rtnMap.get("FUNC_AREA")
			rtnMap.get("AREA_NAME")

			swagger
			{
			  "type" : "24",
			  "strDept" : "10084B"
			}
			*/

			inputMap.put("strDept", StringUtil.isNullToString(paramMap.get("strDept")));

			rtnMap = (List<GsrsMap>) commonDAO.selectList(_CORPORATION_CARD + "getMentoDvsn", inputMap);    // 현장멘토 사업본부별 귀속부서 조회

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("25")) {

			// 계정과목 조회(출력물용)
			/*

			case 25: GetData25(CONDITION); break;		  //계정과목 조회(출력물용)

			CONDITION -> strKey

			rtnMap.get("ACCT_CODE")
			rtnMap.get("ACCT_NAME")
			rtnMap.get("ISSU_DIVS")
			rtnMap.get("USE_DIVS")
			rtnMap.get("DRCR_DIVS")
			rtnMap.get("FUND_YN")
			rtnMap.get("CNTL_YN")
			rtnMap.get("MANG_YN")
			rtnMap.get("INTR_RATE_YN")
			rtnMap.get("FNSH_DATE_YN")
			rtnMap.get("REMD_DIVS")
			rtnMap.get("SLIP_YN")

			swagger
			{
			  "type" : "25",
			  "strUseDivs" : "A",
	  		  "strKey" : "예금"
			}
			*/

			inputMap.put("strKey", StringUtil.isNullToString(paramMap.get("strKey")));
			inputMap.put("strUseDivs", StringUtil.isNullToString(paramMap.get("strUseDivs")));

			rtnMap = (List<GsrsMap>) commonDAO.selectList(_BUSINESS_TRIP + "getAcctNameView", inputMap);    // 계정과목 조회(출력물용)

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("26")) {

			// 품질보증비 사업본부별 귀속부서 조회
			/*

			case 26: GetData26(CONDITION); break;		  //품질보증비 사업본부별 귀속부서 조회

			CONDITION -> strDept

			rtnMap.get("CODE_NAME")
			rtnMap.get("CODE_EXPL")

			swagger
			{
			  "type" : "26",
			  "strDept" : "A2022"
			}
			*/

			String strUseDivs = "X";

			inputMap.put("strDept", StringUtil.isNullToString(paramMap.get("strDept")));

			rtnMap = (List<GsrsMap>) commonDAO.selectList(_COMMON_NAMESPACE + "getQualityDvsn", inputMap);    // 품질보증비 사업본부별 귀속부서 조회

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("28")) {

			// 계정과목 조회(현장일괄대체전표)
			/*

			case 28: GetData28(CONDITION); break;	  //계정과목 조회(현장일괄대체전표)

			CONDITION -> strKey

			rtnMap.get("ACCT_CODE")
			rtnMap.get("ACCT_NAME")
			rtnMap.get("ISSU_DIVS")
			rtnMap.get("USE_DIVS")
			rtnMap.get("DRCR_DIVS")
			rtnMap.get("FUND_YN")
\			rtnMap.get("CNTL_YN")
			rtnMap.get("MANG_YN")
			rtnMap.get("SLIP_YN")

			swagger
			{
			  "type" : "28",
			  "strKey" : "지급"
			}
			*/

			String strWhere = "AND acct_code Like '4%' AND NOT EXISTS (select * from FATY500 Y500 where CLSS = 'Z2' AND use_yn = 'Y'  AND Y500.code = X200.acct_code)";

			inputMap.put("strKey", StringUtil.isNullToString(paramMap.get("strKey")));
			inputMap.put("strWhere", strWhere);

			rtnMap = (List<GsrsMap>) commonDAO.selectList(_COMMON_NAMESPACE + "selectGetData28", inputMap);    // 계정과목 조회(현장일괄대체전표)

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("29")) {

			/*
			case 29: GetData29(CONDITION); break;	  //구 계정코드 조회

			미사용인듯 사용하려면 쿼리 수정해야됨
			 */

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("30")) {

			/*
			case 30: GetData30(CONDITION); break;	  //구 비용코드 조회

			미사용인듯 사용하려면 쿼리 수정해야됨
			 */

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("31")) {

			/*
			case 31: GetData31(CONDITION, OPTION); break;	  //구 적요코드 조회

			미사용인듯 사용하려면 쿼리 수정해야됨
			 */

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("32")) {

			// 부서검색
			/*

			case 32: GetData32(CONDITION, OPTION, URL_DIVS, LIKE_YN, GUBUN, Lang_TYPE); break;	  //부서검색

			CONDITION -> strCode
			OPTION -> strFlag
			URL_DIVS -> strAcct
			LIKE_YN -> strLike
			GUBUN -> strGubun
			Lang_TYPE -> strLang

			rtnMap.get("DEPT_CODE")
			rtnMap.get("FUNC_AREA")
			rtnMap.get("AREA_NAME")
			rtnMap.get("DEPT_NAME")
			rtnMap.get("SITE_CD")

			rtnMap.get("CURC_CODE")
			rtnMap.get("DTLS_YN")
			rtnMap.get("DTLS_ITEM")
			rtnMap.get("COST_DEPT")
			rtnMap.get("COST_DEPTNM")

			rtnMap.get("STRT_DATE")
			rtnMap.get("USE_END_DATE")
			rtnMap.get("RCPT_MNGR_YN")
			rtnMap.get("RCPT_TERM")
			rtnMap.get("RECP_YN")

			rtnMap.get("BRANCH_YN")
			rtnMap.get("DEPT_DIVS")
			rtnMap.get("BRANCH_POST")

			swagger
			{
			  "type" : "32",
			  "strCode" : "11018",
			  "strFlag" : "",
			  "strAcct" : "",
			  "strLike" : "",
			  "strGubun" : "",
			  "strLang" : ""
			}



			*/

			inputMap.put("strClass", "1");
			inputMap.put("strCode", StringUtil.isNullToString(paramMap.get("strCode")));
			inputMap.put("strName", "");
			inputMap.put("strEmp", StringUtil.isNullToString(empNo));
			inputMap.put("strAuth", StringUtil.isNullToString(auth));
			inputMap.put("strFlag", StringUtil.isNullToString(paramMap.get("strFlag")));
			inputMap.put("strAcct", StringUtil.isNullToString(paramMap.get("strAcct")));
			inputMap.put("strLike", StringUtil.isNullToString(paramMap.get("strLike")));
			inputMap.put("strGroup", StringUtil.isNullToString(userGroup));
			inputMap.put("strGubun", StringUtil.isNullToString(paramMap.get("strGubun")));
			inputMap.put("strLang", StringUtil.isNullToString(paramMap.get("strLang")));

			rtnMap = (List<GsrsMap>) commonDAO.selectList(_CORPORATION_CARD + "getDeptKey", inputMap);    // 부서검색

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("33")) {

			// 결재선 조회
			/*

			case 33: GetData33(APPR_NUM, Lang_TYPE); break;		  //전표조회용 결재선 조회

			APPR_NUM -> apprNum
			Lang_TYPE -> langType

			rtnMap.get("APPRLINE")
			rtnMap.get("UPLINE")
			rtnMap.get("MSG")

			swagger
			{
			  "type" : "33",
			  "apprNum" : "AP-UG-20110103-06030-0000041",
			  "langType" : "EN-US"
			}

			{
			  "type" : "33",
			  "apprNum" : "AP-UG-20110103-06030-0000041",
			  "langType" : ""
			}

			*/

			inputMap.put("apprNum", StringUtil.isNullToString(paramMap.get("apprNum")));

			if(StringUtil.isNullToString(paramMap.get("langType")).equals("EN-US")){
				commonDAO.selectList(_CORPORATION_CARD + "gheckApprLine2En", inputMap); // 결재선 조회 영문
			}
			else{
				commonDAO.selectList(_CORPORATION_CARD + "gheckApprLine2", inputMap); // 결재선 조회
			}


			GsrsMap map = new GsrsMap();
			map.put("apprLine", StringUtil.isNullToString(inputMap.get("apprLine")));
			map.put("upLine", StringUtil.isNullToString(inputMap.get("upLine")));
			map.put("msg", StringUtil.isNullToString(inputMap.get("msg")));

			rtnMap.add(map);

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("34")) {

			// 계정과목 조회
			/*

			case 34: GetData34(CONDITION, OPTION, BUSN_DIVS, PROF_DEPT, EMP_NO); break;

			CONDITION -> divs
			OPTION -> acct
			BUSN_DIVS -> busnDivs
			PROF_DEPT -> deptCode
			EMP_NO -> empNo

			rtnMap.get("APPRLINE")
			rtnMap.get("UPLINE")
			rtnMap.get("MSG")

			swagger
			{
			  "type" : "34",
			  "divs" : "ALL",
			  "acct" : "1101",
			  "empNo" : "63017",
			  "busnDivs" : "UG",
			  "deptCode" : ""
			}


			*/

			inputMap.put("divs", StringUtil.isNullToString(paramMap.get("divs")));
			inputMap.put("acct", StringUtil.isNullToString(paramMap.get("acct")));
			inputMap.put("busnDivs", StringUtil.isNullToString(paramMap.get("busnDivs")));
			inputMap.put("deptCode", StringUtil.isNullToString(paramMap.get("deptCode")));
			inputMap.put("empNo", StringUtil.isNullToString(paramMap.get("empNo")));

			//commonDAO.selectList(_COMMON_NAMESPACE + "selectGetData34", inputMap); // 계정과목 조회

			commonDAO.selectList(_BUSINESS_TRIP + "getAcctName", inputMap); // 계정과목 조회

			return (List<GsrsMap>) inputMap.get("list");

		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("35")) {

			// 보조부용 거래처 조회 --> 휴폐업, 내부거래 상관없이 모두 나올 수 있도록.
			/*

			case 35: GetData35(CONDITION, CMP_TYPE); break; // 보조부용 거래처 조회 --> 휴폐업, 내부거래 상관없이 모두 나올 수 있도록.

			CONDITION -> strKey
			CMP_TYPE -> strDiv

			rtnMap.get("CMPN_NUM")
			rtnMap.get("CMPN_NAME")

			swagger
			{
			  "type" : "35",
			  "strKey" : "강",
			  "strDiv" : "M"
			}
			*/


			inputMap.put("strKey", StringUtil.isNullToString(paramMap.get("strKey")));
			inputMap.put("strDiv", StringUtil.isNullToString(paramMap.get("strDiv")));

			if(!StringUtil.isNullToString(paramMap.get("strDiv")).equals("")){
				if(StringUtil.isNullToString(paramMap.get("strDiv")).equals("M")){
					rtnMap = (List<GsrsMap>) commonDAO.selectList(_COMMON_NAMESPACE + "selectGetData35_1", inputMap);    // 보조부용 거래처 조회 --> 휴폐업, 내부거래 상관없이 모두 나올 수 있도록.
				}
				else{
					rtnMap = (List<GsrsMap>) commonDAO.selectList(_COMMON_NAMESPACE + "selectGetData35_2", inputMap);    // 보조부용 거래처 조회 --> 휴폐업, 내부거래 상관없이 모두 나올 수 있도록.
				}
			}
			else {
				rtnMap = (List<GsrsMap>) commonDAO.selectList(_COMMON_NAMESPACE + "selectGetData35_3", inputMap);    // 보조부용 거래처 조회 --> 휴폐업, 내부거래 상관없이 모두 나올 수 있도록.
			}
		}
		else if(StringUtil.isNullToString(paramMap.get("type")).trim().equals("36")) {

			// GAS(해외법인회계시스템) 거래처 조회
			/*

			case 36: GetData36(CONDITION, OPTION, CORP_CODE); break;   // GAS(해외법인회계시스템) 거래처 조회

			CONDITION -> strDivs
			OPTION -> strKey
			CORP_CODE -> strCorpCode

			rtnMap.get("CMPN_NUM")
			rtnMap.get("CMPN_NAME")
			rtnMap.get("ZIP_CODE")
			rtnMap.get("ADDR1")
			rtnMap.get("ADDR2")

			swagger
			{
			  "type" : "36",
			  "strKey" : "1138107384",
			  "strCorpCode" : "000010"
			}

			*/

			inputMap.put("strDivs", StringUtil.isNullToString(paramMap.get("strDivs")));
			inputMap.put("strKey", StringUtil.isNullToString(paramMap.get("strKey")));
			inputMap.put("strCorpCode", StringUtil.isNullToString(paramMap.get("strCorpCode")));

			rtnMap = (List<GsrsMap>) commonDAO.selectList(_CORPORATION_CARD + "getCmpyKeyGas", inputMap);    // GAS(해외법인회계시스템) 거래처 조회

		}


		return rtnMap;



//		return (List<GsrsMap>) paramMap.get("list");
	}
}
