package com.gsenc.cfs.common.service;

import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Marker;
import org.slf4j.MarkerFactory;
import org.springframework.stereotype.Service;

import com.gsenc.cfs.common.dao.CommonDAO;
import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.cfs.common.sap.SAPInterFaceClass;
import com.gsenc.wsf.common.constant.LogConstants;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.common.util.StringUtil;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class EasCommonSapServiceImpl implements EasCommonSapService {

	private final static String _COMMON_NAMESPACE = "common.EasSap.";
	private final CommonDAO commonDAO;

	Marker marker = MarkerFactory.getMarker(LogConstants.RFC);

	// Sap_Ztr_Vendor_Chk 계좌등록 가능부서 확인
	@SuppressWarnings("unchecked")
	public Map<String, Object> selectZtrVendorChk(Map<String, Object> paramMap) {//UserSessionVO userSession = SessionScopeUtil.getContextSession();

		try {

			SAPInterFaceClass sapInf = new SAPInterFaceClass();
			Map<String, Object> rtnMap = sapInf.selectZtrVendorChk(paramMap);

			// SAP SEVER LOG
			log.info(marker, "[Request ]\n{}", paramMap);
			log.info(marker, "[Response]\n{}", rtnMap);


			UserSessionVO userSession = SessionScopeUtil.getContextSession();
			GsrsMap resultMap = new GsrsMap();
			String empNo = "";

			// 개발시 임시 if문
			if ( userSession == null ) {
				empNo = "63684";
			}
			else{
				empNo = userSession.getEmpNo();
			}

			YearMonth yearMonth = YearMonth.now();
			String yyyyMm = yearMonth.format(DateTimeFormatter.ofPattern("yyyyMM"));

			Map<String, Object> sapLogMap = new HashMap<>();

			sapLogMap.put("divs", "P");         // 구분
			sapLogMap.put("code", StringUtil.isNullToString(paramMap.get("lifnr")));     // 코드
			sapLogMap.put("flag", StringUtil.isNullToString(rtnMap.get("IF_CODE")));         // I/F 결과
			sapLogMap.put("sapMsg", StringUtil.isNullToString(rtnMap.get("IF_MSG")));     // SAP 메시지
			sapLogMap.put("empNo", empNo);   // 사번
			sapLogMap.put("sapCode", "");  // SAP 코드
			sapLogMap.put("subCode", "");  // SUB 코드
			sapLogMap.put("seq", "0");            // 순번
			sapLogMap.put("yyyyMm", yyyyMm);  // 년월

			commonDAO.selectList(_COMMON_NAMESPACE + "selectProcSetIfSap", sapLogMap);


			return rtnMap;

		} catch (Exception e) {
			// 마커를 사용한 로깅
			log.error(marker, "[Request ]\n{}", paramMap);
			log.error(marker, "[Error   ]", e);

		}

		return null;
	}

	// SAP 인터페이스 로그 저장
	@SuppressWarnings("unchecked")
	public void selectProcSetIfSap(Map<String, Object> paramMap) {//UserSessionVO userSession = SessionScopeUtil.getContextSession();

		commonDAO.selectList(_COMMON_NAMESPACE + "selectProcSetIfSap", paramMap);

	}
}
