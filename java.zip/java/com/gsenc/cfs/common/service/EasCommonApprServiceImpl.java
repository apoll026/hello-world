package com.gsenc.cfs.common.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.gsenc.cfs.common.dao.CommonDAO;
import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.wsf.common.util.StringUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class EasCommonApprServiceImpl implements EasCommonApprService {

	private final static String _COMMON_NAMESPACE = "common.EasAppr.";
	private final CommonDAO commonDAO;

	public Map<String, Object> selectCommonProcGetDocuNum(Map<String, Object> paramMap) {//UserSessionVO userSession = SessionScopeUtil.getContextSession();

		Map<String, Object> rtnMap = new HashMap<>();

		String busnDivs = StringUtil.isNullToString(paramMap.get("busnDivs"));  // 업무구분
		String profDate = StringUtil.isNullToString(paramMap.get("profDate"));  // 증빙일자
		String deptCode = StringUtil.isNullToString(paramMap.get("deptCode"));  // 부서코드
		String apprClss = StringUtil.isNullToString(paramMap.get("apprClss"));  // 뭔지 모르겠다 나중에 찾아서 주석 달아야지 (현재 펑션에서는 사용 안하고 있음)
		String docuNum = "";                                                    // 문서번호

		//List<GsrsMap> docuNumList = (List<GsrsMap>)commonDAO.selectList(_COMMON_NAMESPACE + "selectCommonProcGetDocuNum", paramMap);
		commonDAO.selectList(_COMMON_NAMESPACE + "selectCommonProcGetDocuNum", paramMap);

		if(busnDivs == null || busnDivs.isEmpty() || profDate == null || profDate.isEmpty() || deptCode == null || deptCode.isEmpty() ){
			docuNum = "XXXXXX1";
		}
		else{
			docuNum = "DU-" + busnDivs + "-" + profDate + "-" + deptCode + "-" + StringUtil.isNullToString(paramMap.get("docuNum"));
		}

		rtnMap.put("docuNum", docuNum);

		return rtnMap;
	}

	public GsrsMap getAppFaty800(Map<String, Object> paramMap) {
		return (GsrsMap)commonDAO.selectOne(_COMMON_NAMESPACE + "getAppFaty800", paramMap);
	}

}
