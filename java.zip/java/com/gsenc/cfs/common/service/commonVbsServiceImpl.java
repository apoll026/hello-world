package com.gsenc.cfs.common.service;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.gsenc.cfs.common.dao.CommonDAO;
import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.wsf.common.util.StringUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
//@SuppressWarnings("unchecked")
public class commonVbsServiceImpl implements commonVbsService {

	private final static String _COMMON_NAMESPACE = "common.commonVbs.";
	private final CommonDAO commonDAO;

	/*

	AS-IS :  UASI.WebUI.Common.Common.vbs.fnc_PROC_GET_PROF_NUM_COMMIT

	기능 : 세금계산서 발행및 조회

	swagger
	{
	  "profDate": "20250407",
	  "profDept": "070120",
	  "profClss": "01",
	  "busnDivs": "UG"
	}

	{
	  "profDate": "20250407",
	  "profDept": "070120",
	  "profClss": "01",
	  "busnDivs": "UG1"
	}


	*/
	public GsrsMap procGetProfNumCommit(Map<String, Object> paramMap) {//UserSessionVO userSession = SessionScopeUtil.getContextSession();

		GsrsMap resultMap = new GsrsMap();
		String msg = "";

		commonDAO.selectList(_COMMON_NAMESPACE + "procGetProfNumCommit", paramMap);

		resultMap.put("profMain", paramMap.get("profMain"));

		if(StringUtil.isNullToString(paramMap.get("profMain")).equals("EEEE")){
			resultMap.put("msg", "일계표 생성이 되어있지 않습니다.");
		}
		else if(StringUtil.isNullToString(paramMap.get("profMain")).equals("CLSE")){
			resultMap.put("msg", "일계표가 마감되었습니다.");
		}
		else if(StringUtil.isNullToString(paramMap.get("profMain")).equals("SLIP")){
			resultMap.put("msg", "입력전표 차수가 아닙니다.");
		}
		else if(StringUtil.isNullToString(paramMap.get("profMain")).equals("OVER")){
			resultMap.put("msg", "일계표가 초과되었습니다.");
		}
		else{
			resultMap.put("msg", "");
		}



		return resultMap;

	}

	public String objRsReplace(String str){
		str = str.replaceAll("^^γ","&");		// XML 문서 & 변환
		str = str.replaceAll("&amp;","&");		// XML 문서 & 변환
		str = str.replaceAll("&lt;","<");		// XML 문서 < 변환
		str = str.replaceAll("&gt;",">");		// XML 문서 > 변환
		str = str.replaceAll("&quot;","\"\"");	// XML 문서 " 변환
		str = str.replaceAll("&apos;&apos;","'");				// XML 문서 ' 변환
		return str;
	}

	// AS-IS :  UASI.WebUI.Common.Common.vbs.fnc_PROC_GET_APPR_NUM_COMMIT
	public String fncProcGetApprNumCommit(Map<String, Object> paramMap) {//UserSessionVO userSession = SessionScopeUtil.getContextSession();

		commonDAO.selectList(_COMMON_NAMESPACE + "fncProcGetApprNumCommit", paramMap);
		return (String) paramMap.get("apprNum");

	}

	// AS-IS :  UASI.WebUI.Common.Common.vbs.fnc_PROC_GET_APPR_NUM_COMMIT
	public String fncProcGetDocuNum(Map<String, Object> paramMap) {//UserSessionVO userSession = SessionScopeUtil.getContextSession();

		commonDAO.selectList(_COMMON_NAMESPACE + "fncProcGetDocuNum", paramMap);
		return "DU-" + StringUtil.isNullToString(paramMap.get("busnDivs"))  + "-" + StringUtil.isNullToString(paramMap.get("profDate"))  + "-" + StringUtil.isNullToString(paramMap.get("deptCode"))  + "-" + paramMap.get("docuNum");
	}

	// AS-IS :  UASI.WebUI.Common.Common.vbs.fnc_PROC_GET_RQST_NUM
	public String fncProcGetRqstNum(Map<String, Object> paramMap) {//UserSessionVO userSession = SessionScopeUtil.getContextSession();
		commonDAO.selectList(_COMMON_NAMESPACE + "fncProcGetRqstNum", paramMap);
		return (String) paramMap.get("rqstNum");
	}

	// AS-IS :  UASI.WebUI.Common.Common.vbs.fnc_BRANCH_ACCT_CODE
	public String fncBranchAcctCode(Map<String, Object> paramMap) {//UserSessionVO userSession = SessionScopeUtil.getContextSession();

		List<GsrsMap> rtnMap = new ArrayList<GsrsMap>();
		rtnMap = (List<GsrsMap>)commonDAO.selectList(_COMMON_NAMESPACE + "fncBranchAcctCode", paramMap);

		String returnValue;
		if (rtnMap != null && !rtnMap.isEmpty()) {
			returnValue = (String) rtnMap.get(0).get("acctCode");
		} else {
			returnValue = (String) paramMap.get("acctCode");
		}

		return returnValue;

	}
}
