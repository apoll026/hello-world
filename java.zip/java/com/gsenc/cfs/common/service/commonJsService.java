package com.gsenc.cfs.common.service;

import java.util.Map;

public interface commonJsService {

    String funcEduChk(Map<String, Object> paramMap);

    String funcFamtChk(Map<String, Object> paramMap);

    String funcSaveBefrChk(Map<String, Object> paramMap);

}
