package com.gsenc.cfs.common.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gsenc.cfs.common.dao.CommonDAO;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.exception.GsEncException;
import com.gsenc.wsf.common.util.StringUtil;
import com.gsenc.wsf.mail.model.MailRequestVO;
import com.gsenc.wsf.mail.model.MailVO;
import com.gsenc.wsf.mail.service.MailService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional(rollbackFor = {Exception.class})
public class EmailSmsServiceImpl implements EmailSmsService {

	private final static String _PACKAGE_NAMESPACE = "common.EmailSms.";

	@Autowired
	CommonDAO commonDao;

	@Autowired
	MailService mailService;

	public int sendMail(Map<String, Object> paramMap) {

		String subject = StringUtil.isNullToString(paramMap.get("subject"));
		String body = StringUtil.isNullToString(paramMap.get("body"));
		String emailTo = StringUtil.isNullToString(paramMap.get("emailTo")); // "," 로 구분

		MailRequestVO mailRequest = new MailRequestVO();
		mailRequest.setSubject(subject);
		mailRequest.setContent(body);
		mailRequest.setToAddress(emailTo);
		MailVO mailVO = mailService.parseMailRequest(mailRequest);

		// 메일 내용 DB에 저장 (반환값으로 시퀀스 넘어옴)
		int rtnSeq = mailService.sendMail(mailVO);

		// 메일 발송 배치 실행 ( 테스트할때 바로 확인 필요 시 )
		// mailService.sendMailBatch();

		return rtnSeq;
	}

	@Transactional(rollbackFor = {Exception.class})
	public int sendSms(Map<String, Object> paramMap) {

		/*
		Map.entry("phone", strMobile),
		Map.entry("callback", strMobile),
		Map.entry("status", "1"),
		Map.entry("tranmsg", "임차보증금 계약현황 등록/수정 요청"), // SMS 메시지
		Map.entry("ect1", "UAS"),
		Map.entry("type", "0")
		 */

		String phone = StringUtil.isNullToString(paramMap.get("phone"));
		String[] arrPhone = phone.split("\\|");

		String callback = StringUtil.isNullToString(paramMap.get("callback"));
		String[] arrCallback = callback.split("\\|");

		try {
			for (int i=0; i<arrPhone.length; i++){

				paramMap.put("phone", arrPhone[i]);
				paramMap.put("callback", arrCallback[i]);

				System.out.println(paramMap);

				// 해당 프로시저는 에러 인경우 msg로 리턴이 아닌 강제 Exception 처리 되기에 try 로 감싸고 임의로 메시지를 화면에 리턴해줌
				commonDao.selectList(_PACKAGE_NAMESPACE + "sendSms", paramMap);
			}
		} catch (Exception e) {
			throw new GsEncException(e.getMessage(), StatusCodeConstants.FAIL, new HashMap<>());
		}

		return 1;
	}

}
