package com.gsenc.cfs.common.service;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.gsenc.cfs.common.dao.CommonDAO;
import com.gsenc.wsf.common.util.StringUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class MakeObjectVbsServiceImpl implements MakeObjectVbsService {

	private final static String _COMMON_NAMESPACE = "common.makeObject.";
	private final CommonDAO commonDAO;

	/*
	AS-IS :  UASI.WebUI.Common.Common.MakeObject.FUNC_GET_DVSN_AUTH
	문자열로 반환 각 업무에서 문자열로 TRUE, FALSE, ELSE 체크요망
	*/
	public String funcGetDvsnAuth(Map<String, Object> paramMap) {
		return StringUtil.isNullToString(commonDAO.selectOne(_COMMON_NAMESPACE + "funcGetDvsnAuth", paramMap));
	}

}
