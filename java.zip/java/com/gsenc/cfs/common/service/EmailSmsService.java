package com.gsenc.cfs.common.service;

import java.util.Map;

public interface EmailSmsService {

    int sendMail(Map<String, Object> paramMap);

    int sendSms(Map<String, Object> paramMap);
}
