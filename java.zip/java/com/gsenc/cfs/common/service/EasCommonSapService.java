package com.gsenc.cfs.common.service;

import java.util.Map;

public interface EasCommonSapService {

    // Sap_Ztr_Vendor_Chk 계좌등록 가능부서 확인
    Map<String, Object> selectZtrVendorChk(Map<String, Object> paramMap);

    // SAP 인터페이스 로그 저장
    void selectProcSetIfSap(Map<String, Object> paramMap);

}
