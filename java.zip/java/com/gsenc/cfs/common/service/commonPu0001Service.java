package com.gsenc.cfs.common.service;

import java.util.List;
import java.util.Map;

import com.gsenc.cfs.common.model.GsrsMap;

public interface commonPu0001Service {

    List<GsrsMap> selectGetData(Map<String, Object> paramMap);

}
