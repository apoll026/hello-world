package com.gsenc.cfs.common.service;

import java.util.List;
import java.util.Map;

import com.gsenc.cfs.common.model.GsrsMap;

public interface EasCommonCodeService {

    List<GsrsMap> selectCommonProcGetFaty500(Map<String, Object> paramMap);

    List<GsrsMap> selectCommonCodeList(Map<String, Object> paramMap);

    List<GsrsMap> selectCommonCodeQueryList(Map<String, Object> paramMap);

    List<GsrsMap> selectCommonCodeSapList(Map<String, Object> paramMap);

    List<GsrsMap> selectDeptCardList(Map<String, Object> paramMap);

    Boolean selectCommIcheLevel(Map<String, Object> paramMap);
}
