package com.gsenc.cfs.common.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.cfs.common.service.EasCommonCodeService;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "EasCommonCode")
@Validated
@RequestMapping("/api")
public class EasCommonCodeController {

	private final EasCommonCodeService EasCommonCodeService;

	@Operation(summary = "FATY500 공통코드 가져오기")
	@GetMapping(value = "/common/EasCode/selectCommonProcGetFaty500", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<List<GsrsMap>>> selectCommonProcGetFaty500(@RequestParam Map<String, Object> input) {

		return new ResponseEntity<>(CommonResponseVO.<List<GsrsMap>>builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(EasCommonCodeService.selectCommonProcGetFaty500(input))
				.build(), HttpStatus.OK);

	}

	@Operation(summary = "FATY500 공통코드 프로시저로 조회")
	@PostMapping(value = "/common/EasCode/selectCommonCodeList", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<List<GsrsMap>>> selectCommonCodeList(@RequestBody Map<String, Object> input) {

		return new ResponseEntity<>(CommonResponseVO.<List<GsrsMap>>builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(EasCommonCodeService.selectCommonCodeList(input))
				.build(), HttpStatus.OK);

	}

	@Operation(summary = "FATY500_SAP 공통코드 프로시저로 조회")
	@PostMapping(value = "/common/EasCode/selectCommonCodeSapList", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<List<GsrsMap>>> selectCommonCodeSapList(@RequestBody Map<String, Object> input) {

		return new ResponseEntity<>(CommonResponseVO.<List<GsrsMap>>builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(EasCommonCodeService.selectCommonCodeSapList(input))
				.build(), HttpStatus.OK);

	}

	@Operation(summary = "FATY500 공통코드 쿼리로 조회")
	@PostMapping(value = "/common/EasCode/selectCommonCodeQueryList", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<List<GsrsMap>>> selectCommonCodeQueryList(@RequestBody Map<String, Object> input) {

		return new ResponseEntity<>(CommonResponseVO.<List<GsrsMap>>builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(EasCommonCodeService.selectCommonCodeQueryList(input))
				.build(), HttpStatus.OK);

	}

	@Operation(summary = "부서별 보유카드 조회")
	@PostMapping(value = "/common/EasCode/selectDeptCardList", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<List<GsrsMap>>> selectDeptCardList(@RequestBody Map<String, Object> input) {

		return new ResponseEntity<>(CommonResponseVO.<List<GsrsMap>>builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(EasCommonCodeService.selectDeptCardList(input))
				.build(), HttpStatus.OK);

	}

	@Operation(summary = "이체권한 조회")
	@PostMapping(value = "/common/EasCode/selectCommIcheLevel", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<Boolean>> selectCommIcheLevel(@RequestBody Map<String, Object> input) {

		return new ResponseEntity<>(CommonResponseVO.<Boolean>builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(EasCommonCodeService.selectCommIcheLevel(input))
				.build(), HttpStatus.OK);

	}
}
