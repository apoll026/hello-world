
package com.gsenc.cfs.common.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.cfs.common.service.commonJsService;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "commonJs")
@Validated
@RequestMapping("/api")
public class commonJsController {

    private final commonJsService commonJsService;

    @Operation(summary = "AS-IS Common.js.FUNC_EDU_CHK - 교훈련비 작성 여부 확인")
    @PostMapping(value = "/common/commonJs/funcEduChk", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO<String>> funcEduChk(@RequestBody Map<String, Object> input) {
        return new ResponseEntity<>(CommonResponseVO.<String>builder()
                .successOrNot(CommonConstants.YES_FLAG)
                .statusCode(StatusCodeConstants.SUCCESS)
                .data(commonJsService.funcEduChk(input))
                .build(), HttpStatus.OK);
    }

    @Operation(summary = "AS-IS Common.js.FUNC_FAMT_CHK - 외화송금의뢰서 여부 확인")
    @PostMapping(value = "/common/commonJs/funcFamtChk", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO<String>> funcFamtChk(@RequestBody Map<String, Object> input) {
        return new ResponseEntity<>(CommonResponseVO.<String>builder()
                .successOrNot(CommonConstants.YES_FLAG)
                .statusCode(StatusCodeConstants.SUCCESS)
                .data(commonJsService.funcFamtChk(input))
                .build(), HttpStatus.OK);
    }

    @Operation(summary = "AS-IS Common.js.FUNC_SAVE_BEFR_CHK - 저장전 체크오류")
    @PostMapping(value = "/common/commonJs/funcSaveBefrChk", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO<String>> funcSaveBefrChk(@RequestBody Map<String, Object> input) {
        return new ResponseEntity<>(CommonResponseVO.<String>builder()
                .successOrNot(CommonConstants.YES_FLAG)
                .statusCode(StatusCodeConstants.SUCCESS)
                .data(commonJsService.funcSaveBefrChk(input))
                .build(), HttpStatus.OK);
    }

}
