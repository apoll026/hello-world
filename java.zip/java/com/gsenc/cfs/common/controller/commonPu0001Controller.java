package com.gsenc.cfs.common.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.cfs.common.service.commonPu0001Service;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "commonPu0001")
@Validated
@RequestMapping("/api")
public class commonPu0001Controller {

	private final commonPu0001Service commonPu0001Service;

	@Operation(summary = "UAS_B_UC001 에서 사용하던 쿼리들 모음 이름을 바꿔야 되는데 뭐로 해야되나")
	@PostMapping(value = "/common/commonPu0001/selectGetData", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<List<GsrsMap>>> selectGetData(@RequestBody Map<String, Object> input) {
		return new ResponseEntity<>(CommonResponseVO.<List<GsrsMap>>builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(commonPu0001Service.selectGetData(input))
				.build(), HttpStatus.OK);
	}

}
