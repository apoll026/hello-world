package com.gsenc.cfs.common.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.gsenc.cfs.common.service.EasCommonSapService;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "EasCommonSap")
@Validated
@RequestMapping("/api")
public class EasCommonSapController {

	private final EasCommonSapService EasCommonSapService;

	@Operation(summary = "Sap_Ztr_Vendor_Chk 계좌등록 가능부서 확인")
	@PostMapping(value = "/common/easSap/selectZtrVendorChk", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<Map<String, Object>>> selectZtrVendorChk(@RequestBody Map<String, Object> input) {
		return new ResponseEntity<>(CommonResponseVO.<Map<String, Object>>builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(EasCommonSapService.selectZtrVendorChk(input))
				.build(), HttpStatus.OK);
	}

	@Operation(summary = "SAP 인터페이스 로그 저장")
	@PostMapping(value = "/common/easSap/selectProcSetIfSap", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<Void>> selectProcSetIfSap(@RequestBody Map<String, Object> input) {
		return new ResponseEntity<>(CommonResponseVO.<Void>builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.build(), HttpStatus.OK);
	}

}
