package com.gsenc.cfs.common.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.gsenc.cfs.common.service.EasCommonApprService;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "EasCommonAppr")
@Validated
@RequestMapping("/api")
public class EasCommonApprController {

	private final EasCommonApprService EasCommonApprService;

	@Operation(summary = "품의번호 채번 (FATQ810)")
	@GetMapping(value = "/common/EasAppr/selectCommonProcGetDocuNum", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<Map<String, Object>>> selectCommonProcGetDocuNum(@RequestParam Map<String, Object> input) {
		return new ResponseEntity<>(CommonResponseVO.<Map<String, Object>>builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(EasCommonApprService.selectCommonProcGetDocuNum(input))
				.build(), HttpStatus.OK);
	}

	/* // 사용시 주석 해제, 현재 service 만 호출해서 사용중
	@Operation(summary = "결재선 기본 정보 데이터 조회")
	@PostMapping(value = "/common/EasAppr/getAppFaty800", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<GsrsMap>> getAppFaty800(@RequestBody Map<String, Object> input) {
		return new ResponseEntity<>(CommonResponseVO.<GsrsMap>builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(EasCommonApprService.getAppFaty800(input))
				.build(), HttpStatus.OK);
	}
	*/

}
