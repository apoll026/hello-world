
package com.gsenc.cfs.common.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.cfs.common.service.commonVbsService;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "commonVbs")
@Validated
@RequestMapping("/api")
public class commonVbsController {

    private final commonVbsService commonVbsService;

    @Operation(summary = "AS-IS Common.vbs.fnc_PROC_GET_PROF_NUM_COMMIT")
    @PostMapping(value = "/common/commonVbs/procGetProfNumCommit", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO<GsrsMap>> procGetProfNumCommit(@RequestBody Map<String, Object> input) {
        return new ResponseEntity<>(CommonResponseVO.<GsrsMap>builder()
                .successOrNot(CommonConstants.YES_FLAG)
                .statusCode(StatusCodeConstants.SUCCESS)
                .data(commonVbsService.procGetProfNumCommit(input))
                .build(), HttpStatus.OK);
    }

    @Operation(summary = "AS-IS Common.vbs.fnc_PROC_GET_APPR_NUM_COMMIT")
    @PostMapping(value = "/common/commonVbs/fncProcGetApprNumCommit", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO<String>> fncProcGetApprNumCommit(@RequestBody Map<String, Object> input) {
        return new ResponseEntity<>(CommonResponseVO.<String>builder()
                .successOrNot(CommonConstants.YES_FLAG)
                .statusCode(StatusCodeConstants.SUCCESS)
                .data(commonVbsService.fncProcGetApprNumCommit(input))
                .build(), HttpStatus.OK);
    }

    @Operation(summary = "AS-IS Common.vbs.fnc_PROC_GET_DOCU_NUM")
    @PostMapping(value = "/common/commonVbs/fncProcGetDocuNum", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO<String>> fncProcGetDocuNum(@RequestBody Map<String, Object> input) {
        return new ResponseEntity<>(CommonResponseVO.<String>builder()
                .successOrNot(CommonConstants.YES_FLAG)
                .statusCode(StatusCodeConstants.SUCCESS)
                .data(commonVbsService.fncProcGetDocuNum(input))
                .build(), HttpStatus.OK);
    }

    @Operation(summary = "AS-IS Common.vbs.fnc_PROC_GET_RQST_NUM")
    @PostMapping(value = "/common/commonVbs/fncProcGetRqstNum", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO<String>> fncProcGetRqstNum(@RequestBody Map<String, Object> input) {
        return new ResponseEntity<>(CommonResponseVO.<String>builder()
                .successOrNot(CommonConstants.YES_FLAG)
                .statusCode(StatusCodeConstants.SUCCESS)
                .data(commonVbsService.fncProcGetRqstNum(input))
                .build(), HttpStatus.OK);
    }

    @Operation(summary = "AS-IS Common.vbs.fnc_BRANCH_ACCT_CODE")
    @PostMapping(value = "/common/commonVbs/fncBranchAcctCode", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO<String>> fncBranchAcctCode(@RequestBody Map<String, Object> input) {
        return new ResponseEntity<>(CommonResponseVO.<String>builder()
                .successOrNot(CommonConstants.YES_FLAG)
                .statusCode(StatusCodeConstants.SUCCESS)
                .data(commonVbsService.fncBranchAcctCode(input))
                .build(), HttpStatus.OK);
    }


}
