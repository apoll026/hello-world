package com.gsenc.cfs.common.sap;

import java.util.Properties;

import com.sap.conn.jco.ext.DestinationDataEventListener;
import com.sap.conn.jco.ext.DestinationDataProvider;

public class DestinationDataProviderImp implements DestinationDataProvider {
	private Properties properties;

	private DestinationDataEventListener eventListener;

	@Override
	public Properties getDestinationProperties(String arg0) {
		return properties;
	}

	@Override
	public boolean supportsEvents() {

		return true;
	}

	public void setDestinationDataEventListener(DestinationDataEventListener eventLis) {
		this.eventListener = eventLis;
	}

	public void changePropertiesForABAP_AS(Properties prop) {

		if (prop == null) {
			if (eventListener != null) {
				eventListener.deleted("SAP_SERVER");
			}

			properties = null;
		} else {

			if (eventListener != null && prop != null && !prop.equals(properties)) {
				eventListener.updated("SAP_SERVER");
			}
			properties = prop;
		}
	}

}
