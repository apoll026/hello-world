package com.gsenc.cfs.common.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

import jakarta.annotation.Resource;

@Repository
public class CommonDAOImpl implements CommonDAO {

    private final static String _MAPPER_NAMESPACE = "com.gsenc.eas.";

    @Resource
    protected SqlSessionTemplate sqlSessionTemplate;

    @Override
    public void setSqlSessionTemplate(SqlSessionTemplate template) {
        this.sqlSessionTemplate = template;
    }

    @Override
    public int insert(String queryId, Object parameterObject) {
        return sqlSessionTemplate.insert(_MAPPER_NAMESPACE + queryId, parameterObject);
    }

    @Override
    public int update(String queryId, Object parameterObject) {
        return sqlSessionTemplate.update(_MAPPER_NAMESPACE + queryId, parameterObject);
    }

    @Override
    public int delete(String queryId, Object parameterObject) {
        return sqlSessionTemplate.delete(_MAPPER_NAMESPACE + queryId, parameterObject);
    }

    @Override
    public Object selectOne(String queryId, Object parameterObject) {
        return sqlSessionTemplate.selectOne(_MAPPER_NAMESPACE + queryId, parameterObject);
    }

    @Override
    public List<?> selectList(String queryId, Object parameterObject) {
        return sqlSessionTemplate.selectList(_MAPPER_NAMESPACE + queryId, parameterObject);
    }
}
