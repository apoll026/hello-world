package com.gsenc.cfs.common.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;

public interface CommonDAO {

    public void setSqlSessionTemplate(SqlSessionTemplate template);

    public int insert(String queryId, Object parameterObject);

    public int update(String queryId, Object parameterObject);

    public int delete(String queryId, Object parameterObject);

    public Object selectOne(String queryId, Object parameterObject);

    public List<?> selectList(String queryId, Object parameterObject);
}
