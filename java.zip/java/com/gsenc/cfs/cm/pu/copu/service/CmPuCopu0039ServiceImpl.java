package com.gsenc.cfs.cm.pu.copu.service;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.gsenc.cfs.common.dao.CommonDAO;
import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.cfs.common.service.EasCommonCodeService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class CmPuCopu0039ServiceImpl implements CmPuCopu0039Service {

    private final static String _PACKAGE_NAMESPACE = "cm.pu.copu.CmPuCopu0039.";
    private final CommonDAO commonDAO;
    private final EasCommonCodeService easCommonCodeService;

    public GsrsMap selectCmPuCopu0039InitData(Map<String, Object> paramMap) {
        return (GsrsMap) commonDAO.selectOne(_PACKAGE_NAMESPACE + "selectCmPuCopu0039InitData", paramMap);
    }
}
