package com.gsenc.cfs.cm.pu.copu.service;

import java.util.List;
import java.util.Map;

import com.gsenc.cfs.common.model.GsrsMap;

public interface CmPuCopu0010Service {
    List<GsrsMap> selectDeptListAcctYnS(Map<String, Object> paramMap);
    List<GsrsMap> selectDeptListAcctYnA(Map<String, Object> paramMap);
    List<GsrsMap> selectDeptListAcctYnY(Map<String, Object> paramMap);
}
