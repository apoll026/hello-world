package com.gsenc.cfs.cm.pu.copu.service;

import java.util.List;
import java.util.Map;

public interface CmPuCopu0001Service {

    List<Map<String, Object>> selectCmPuCopu0001Query1(Map<String, Object> paramMap);

    List<Map<String, Object>> selectCmPuCopu0001Query2(Map<String, Object> paramMap);
}
