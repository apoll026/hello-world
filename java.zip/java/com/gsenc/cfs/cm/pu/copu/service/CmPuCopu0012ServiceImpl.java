package com.gsenc.cfs.cm.pu.copu.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.gsenc.cfs.common.dao.CommonDAO;
import com.gsenc.cfs.common.model.GsrsMap;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class CmPuCopu0012ServiceImpl implements CmPuCopu0012Service {

    private final static String _PACKAGE_NAMESPACE = "cm.pu.copu.CmPuCopu0012.";
    private final CommonDAO commonDAO;

    @Override
    public List<GsrsMap> selectDetailItemList(Map<String, Object> paramMap) {
        return (List<GsrsMap>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectDetailItemList", paramMap);
    }

    @Override
    public List<GsrsMap> selectTechItemList(Map<String, Object> paramMap) {
        return (List<GsrsMap>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectTechItemList", paramMap);
    }
}
