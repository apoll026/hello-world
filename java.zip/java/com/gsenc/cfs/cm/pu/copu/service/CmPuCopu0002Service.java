package com.gsenc.cfs.cm.pu.copu.service;

import java.util.List;
import java.util.Map;

import com.gsenc.cfs.common.model.GsrsMap;

public interface CmPuCopu0002Service {
    List<GsrsMap> selectFaty500List(Map<String, Object> paramMap);

    GsrsMap selectCmPuCopu0002InitData(Map<String, Object> paramMap);

    Map<String, Object> saveCmPuCopu0002(Map<String, Object> paramMap);
}
