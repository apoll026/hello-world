package com.gsenc.cfs.cm.pu.copu.service;

import java.util.Map;

import com.gsenc.cfs.common.model.GsrsMap;

public interface CmPuCopu0039Service {
    GsrsMap selectCmPuCopu0039InitData(Map<String, Object> paramMap);
}
