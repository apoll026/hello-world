package com.gsenc.cfs.cm.pu.copu.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.cfs.cm.pu.copu.service.CmPuCopu0038Service;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequiredArgsConstructor
@Tag(name = "CmPuCopu0038")
@RequestMapping("/api/cm/pu/copu/CmPuCopu0038")
public class CmPuCopu0038Controller {
    private final CmPuCopu0038Service cmPuCopu0038Service;

    @Operation(summary = "업무구분조회")
    @PostMapping(value = "selectBusnDivs", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO> selectBusnDivs(@RequestBody Map<String, Object> paramMap) {
        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(cmPuCopu0038Service.selectBusnDivs(paramMap))
                        .build(), HttpStatus.OK
        );
    }
}
