package com.gsenc.cfs.cm.pu.copu.service;

import java.util.List;
import java.util.Map;

import com.gsenc.cfs.common.model.GsrsMap;

public interface CmPuCopu0020Service {
    List<GsrsMap> selectEmpKey(Map<String, Object> paramMap);
    List<GsrsMap> selectEmpList(Map<String, Object> paramMap);
    List<GsrsMap> selectEmpListEn(Map<String, Object> paramMap);
}
