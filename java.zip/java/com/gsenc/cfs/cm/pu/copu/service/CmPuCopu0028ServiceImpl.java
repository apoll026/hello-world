package com.gsenc.cfs.cm.pu.copu.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.gsenc.cfs.common.dao.CommonDAO;
import com.gsenc.cfs.common.model.GsrsMap;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class CmPuCopu0028ServiceImpl implements CmPuCopu0028Service {
    private final static String _PACKAGE_NAMESPACE = "cm.pu.copu.CmPuCopu0028.";
    private final CommonDAO commonDAO;

    @Override
    public List<GsrsMap> selectDeptNameKind1(Map<String, Object> paramMap) {
        return (List<GsrsMap>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectAuthDeptName_kind1", paramMap);
    }

    @Override
    public List<GsrsMap> selectDeptNameKind2(Map<String, Object> paramMap) {
        return (List<GsrsMap>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectAuthDeptName_kind2", paramMap);
    }

    @Override
    public List<GsrsMap> selectDeptNameKind3(Map<String, Object> paramMap) {
        return (List<GsrsMap>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectAuthDeptName_kind3", paramMap);
    }
}
