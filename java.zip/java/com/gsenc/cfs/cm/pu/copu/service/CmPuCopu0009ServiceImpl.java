package com.gsenc.cfs.cm.pu.copu.service;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.gsenc.cfs.common.dao.CommonDAO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class CmPuCopu0009ServiceImpl implements CmPuCopu0009Service {

    private final static String _PACKAGE_NAMESPACE = "cm.pu.copu.CmPuCopu0009.";
    private final CommonDAO commonDAO;

    @Override
    public List<Map<String, Object>> selectCmPuCopu0009(Map<String, Object> paramMap) {
        return (List<Map<String, Object>>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectCmPuCopu0009Query1", paramMap);
    }

    @Override
    public List<Map<String, Object>> selectCmPuCopu0009CmpyList(Map<String, Object> paramMap) {

        String gubun = paramMap.get("strGubun").toString();
        String kind = paramMap.get("strKind").toString();  // 거래처 구분 A: 사업자 / B: 주민번호 / C: 사원번호 / D: 해외거래처 / E: 기타거래처

        List<Map<String, Object>> result;

        if(gubun.equals("D")){
            if(kind.equals("C")){
                /* 거래처 조회 gubun = "D", kind = "C" */
                result = (List<Map<String, Object>>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectCmPuCopu0009Query2DC", paramMap);
            }else if(kind.equals("B")){
                /* 거래처 조회 gubun = "D", kind = "B" */
                result = (List<Map<String, Object>>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectCmPuCopu0009Query2DB", paramMap);
            }else{
                /* 거래처 조회 gubun = "D", kind = "OTHER" */
                result = (List<Map<String, Object>>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectCmPuCopu0009Query2DOTHER", paramMap);
            }
        }else{
            if(kind.equals("C")){
                /* 거래처 조회 gubun <> "D", kind = "C" */
                result = (List<Map<String, Object>>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectCmPuCopu0009Query2OTHERC", paramMap);
            }else if(kind.equals("B")){
                /* 거래처 조회 gubun <> "D", kind = "B" */
                result = (List<Map<String, Object>>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectCmPuCopu0009Query2OTHERB", paramMap);
            }else{
                /* 거래처 조회 gubun <> "D", kind = "OTHER */
                result = (List<Map<String, Object>>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectCmPuCopu0009Query2OTHEROTHER", paramMap);
            }
        }

        return result;
    }

    @Override
    public List<Map<String, Object>> selectCmPuCopu0009CmpyDivs() {
        return (List<Map<String, Object>>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectCmPuCopu0009CmpyDivs", Collections.emptyMap());
    }

    @Override
    public List<Map<String, Object>> selectCmPuCopu0009CmpyKey(Map<String, Object> paramMap) {
        return (List<Map<String, Object>>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectCmPuCopu0009CmpyKey", paramMap);
    }

}
