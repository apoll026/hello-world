package com.gsenc.cfs.cm.pu.copu.controller;


import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.gsenc.cfs.cm.pu.copu.service.CmPuCopu0009Service;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "CmPuCopu0009")
@RequestMapping("/api")
public class CmPuCopu0009Controller {

    private final CmPuCopu0009Service cmPuCopu0006Service;


    @Operation(summary = "거래처 조회 (창 로드 시)")
    @PostMapping(value = "/cm/pu/copu/selectCmPuCopu0009", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> selectCmPuCopu0009(@RequestBody Map<String, Object> paramMap) {

        List<Map<String, Object>> result = cmPuCopu0006Service.selectCmPuCopu0009(paramMap);

        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(result)
                        .build(),
                HttpStatus.OK);
    }

    @Operation(summary = "거래처 조회")
    @PostMapping(value = "/cm/pu/copu/selectCmPuCopu0009/cmpyList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> selectCmPuCopu0009CmpyList(@RequestBody Map<String, Object> paramMap) {
        List<Map<String, Object>> result = cmPuCopu0006Service.selectCmPuCopu0009CmpyList(paramMap);

        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(result)
                        .build(),
                HttpStatus.OK);
    }

    @Operation(summary = "거래처구분코드 조회")
    @GetMapping(value = "/cm/pu/copu/selectCmPuCopu0009/cmpyDivs", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> selectCmPuCopu0009CmpyDivs() {

        List<Map<String, Object>> result = cmPuCopu0006Service.selectCmPuCopu0009CmpyDivs();

        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(result)
                        .build(),
                HttpStatus.OK);
    }

    @Operation(summary = "거래처조회 key")
    @PostMapping(value = "/cm/pu/copu/selectCmPuCopu0009/cmpyKey", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> selectCmPuCopu0009CmpyKey(@RequestBody Map<String, Object> paramMap) {

        List<Map<String, Object>> result = cmPuCopu0006Service.selectCmPuCopu0009CmpyKey(paramMap);

        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(result)
                        .build(),
                HttpStatus.OK);
    }

//    @Operation(summary = "거래처 조회 list")
//    @PostMapping(value = "/cm/pu/copu/selectCmPuCopu0009/cmpyList", produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<?> selectCmPuCopu0009CmpyList(@RequestBody Map<String, Object> paramMap) {
//
//        List<Map<String, Object>> result = cmPuCopu0006Service.selectCmPuCopu0009CmpyList(paramMap);
//
//        return new ResponseEntity<>(
//                CommonResponseVO.builder()
//                        .successOrNot(CommonConstants.YES_FLAG)
//                        .statusCode(StatusCodeConstants.SUCCESS)
//                        .data(result)
//                        .build(),
//                HttpStatus.OK);
//    }
}
