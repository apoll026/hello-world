package com.gsenc.cfs.cm.pu.copu.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.gsenc.cfs.common.dao.CommonDAO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class CmPuCopu0001ServiceImpl implements CmPuCopu0001Service {

    private final static String _PACKAGE_NAMESPACE = "cm.pu.empl.CmPuCopu0001.";
    private final CommonDAO commonDAO;

    @Override
    public List<Map<String, Object>> selectCmPuCopu0001Query1(Map<String, Object> paramMap) {
        return (List<Map<String, Object>>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectCmPuCopu0001Query1", paramMap);
    }

    @Override
    public List<Map<String, Object>> selectCmPuCopu0001Query2(Map<String, Object> paramMap) {
        return (List<Map<String, Object>>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectCmPuCopu0001Query2", paramMap);
    }
}
