package com.gsenc.cfs.cm.pu.copu.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.gsenc.cfs.common.dao.CommonDAO;
import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.wsf.common.util.StringUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class CmPuCopu0019ServiceImpl implements CmPuCopu0019Service {

    private final static String _PACKAGE_NAMESPACE = "cm.pu.copu.CmPuCopu0019.";
    private final CommonDAO commonDAO;

    public GsrsMap selectCmPuCopu0019Param(Map<String, Object> paramMap) {
        return (GsrsMap) commonDAO.selectOne(_PACKAGE_NAMESPACE + "selectCmPuCopu0019Param", paramMap);
    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> selectCmPuCopu0019List(Map<String, Object> paramMap) {

        // FATA200 테이블에 데이터가 있으면 파라미터 치환
        GsrsMap fata200 = this.selectCmPuCopu0019Param(paramMap);

        if (fata200 != null){
            paramMap.put("profDate", StringUtil.isNullToString(fata200.get("profDate")));
            paramMap.put("profDept", StringUtil.isNullToString(fata200.get("profDept")));
            paramMap.put("profClss", StringUtil.isNullToString(fata200.get("profClss")));
            paramMap.put("profMain", StringUtil.isNullToString(fata200.get("profMain")));
        }

        List<GsrsMap> list = (List<GsrsMap>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectCmPuCopu0019List", paramMap);

        return new HashMap<>(Map.of(
                "list", list,
                "totalCount", list.size()
        ));
    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> selectCmPuCopu0019SecondList(Map<String, Object> paramMap) {

        List<GsrsMap> list = (List<GsrsMap>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectCmPuCopu0019SecondList", paramMap);

        return new HashMap<>(Map.of(
                "list", list,
                "totalCount", list.size()
        ));
    }
}
