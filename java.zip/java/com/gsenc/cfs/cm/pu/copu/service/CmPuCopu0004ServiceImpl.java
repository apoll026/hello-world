package com.gsenc.cfs.cm.pu.copu.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.gsenc.cfs.common.dao.CommonDAO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class CmPuCopu0004ServiceImpl implements CmPuCopu0004Service {

    private final static String _PACKAGE_NAMESPACE = "cm.pu.copu.CmPuCopu0004.";
    private final CommonDAO commonDAO;

    @Override
    public List<Map<String, Object>> selectCmPuCopu0004(Map<String, Object> paramMap) {

        String busnDivs = paramMap.get("busn_divs").toString();

        List<Map<String, Object>> result;

        if(busnDivs.equals("UZ")){
            // UZ : 확정전표취소
            result = (List<Map<String, Object>>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectCmPuCopu0004UZ", paramMap);
        }else if(busnDivs.equals("VIEW")){
            // VIEW : 전표일반조회
            result = (List<Map<String, Object>>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectCmPuCopu0004VIEW", paramMap);
        }else if(busnDivs.equals("APPR1") || busnDivs.equals("APPR2")){
            // APPR1 : 작성중  /  APPR2 : 결재중
            result = (List<Map<String, Object>>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectCmPuCopu0004APPR", paramMap);
        }else{
            // 그외
            result = (List<Map<String, Object>>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectCmPuCopu0004OTHER", paramMap);
        }

        return result;
    }
}
