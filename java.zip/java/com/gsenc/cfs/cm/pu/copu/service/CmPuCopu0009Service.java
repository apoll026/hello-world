package com.gsenc.cfs.cm.pu.copu.service;


import java.util.List;
import java.util.Map;

public interface CmPuCopu0009Service {

    List<Map<String, Object>> selectCmPuCopu0009(Map<String, Object> paramMap);

    List<Map<String, Object>> selectCmPuCopu0009CmpyList(Map<String, Object> paramMap);

    List<Map<String, Object>> selectCmPuCopu0009CmpyDivs();

    List<Map<String, Object>> selectCmPuCopu0009CmpyKey(Map<String, Object> paramMap);

}
