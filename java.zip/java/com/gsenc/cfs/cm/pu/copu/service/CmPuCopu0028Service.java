package com.gsenc.cfs.cm.pu.copu.service;

import java.util.List;
import java.util.Map;

import com.gsenc.cfs.common.model.GsrsMap;

public interface CmPuCopu0028Service {
    List<GsrsMap> selectDeptNameKind1(Map<String, Object> paramMap);
    List<GsrsMap> selectDeptNameKind2(Map<String, Object> paramMap);
    List<GsrsMap> selectDeptNameKind3(Map<String, Object> paramMap);
}
