package com.gsenc.cfs.cm.pu.copu.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.gsenc.cfs.common.dao.CommonDAO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class CmPuCopu0037ServiceImpl implements CmPuCopu0037Service {
    private final static String _PACKAGE_NAMESPACE = "cm.pu.copu.CmPuCopu0037.";
    private final CommonDAO commonDAO;

    @Override
    public List<Map<String, Object>> selectAccoutGrp(Map<String, Object> paramMap) {
        return (List<Map<String, Object>>)commonDAO.selectList(_PACKAGE_NAMESPACE + "selectAccoutGrp", paramMap);
    }
}
