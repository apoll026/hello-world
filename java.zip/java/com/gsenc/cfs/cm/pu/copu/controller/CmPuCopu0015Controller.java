package com.gsenc.cfs.cm.pu.copu.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.cfs.cm.pu.copu.service.CmPuCopu0015Service;
import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "CmPuCopu0015")
@RequestMapping("/api")
public class CmPuCopu0015Controller {

    private final CmPuCopu0015Service cmPuCopu0015Service;

    @Operation(summary = "부서 미처리 내역 조회")
    @PostMapping(value = "/cm/pu/copu/cmPuCopu0015I1MList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO<Map<String, Object>>> cmPuCopu0015I1MList(@RequestBody Map<String, Object> input) {

        return new ResponseEntity<>(CommonResponseVO.<Map<String, Object>>builder()
                .successOrNot(CommonConstants.YES_FLAG)
                .statusCode(StatusCodeConstants.SUCCESS)
                .data(cmPuCopu0015Service.selectCmPuCopu0015I1MList(input))
                .build(), HttpStatus.OK);

    }

    @Operation(summary = "매입전자(세금)계산서 - 미처리매입리스트 저장")
    @PostMapping(value = "/cm/pu/copu/saveCmPuCopu0015I1", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO<GsrsMap>> saveCmPuCopu0015I1M(@RequestBody Map<String, Object> input) {

        return new ResponseEntity<>(CommonResponseVO.<GsrsMap>builder()
                .successOrNot(CommonConstants.YES_FLAG)
                .statusCode(StatusCodeConstants.SUCCESS)
                .data(cmPuCopu0015Service.saveCmPuCopu0015I1(input))
                .build(), HttpStatus.OK);

    }

}
