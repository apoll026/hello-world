package com.gsenc.cfs.cm.pu.copu.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.cfs.cm.pu.copu.service.CmPuCopu0001Service;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "CmPuCopu0001")
@RequestMapping("/api/cm/pu/copu/CmPuCopu0001")
public class CmPuCopu0001Controller {

    private final CmPuCopu0001Service cmPuCopu0001Service;

    @Operation(summary = "사원조회(페이지로드)")
    @PostMapping(value = "selectEmpKey", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> selectEmpKey(@RequestBody Map<String, Object> paramMap) {

        List<Map<String, Object>> result = cmPuCopu0001Service.selectCmPuCopu0001Query1(paramMap);

        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(result)
                        .build(),
                HttpStatus.OK);
    }


    @Operation(summary = "사원조회(조회버튼)")
    @PostMapping(value = "selectEmpList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> selectEmpList(@RequestBody Map<String, Object> paramMap) {

        List<Map<String, Object>> result = cmPuCopu0001Service.selectCmPuCopu0001Query2(paramMap);

        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(result)
                        .build(),
                HttpStatus.OK);
    }

}
