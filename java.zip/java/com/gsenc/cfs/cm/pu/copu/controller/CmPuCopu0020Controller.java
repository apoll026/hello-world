package com.gsenc.cfs.cm.pu.copu.controller;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.MapUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.cfs.cm.pu.copu.service.CmPuCopu0020Service;
import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequiredArgsConstructor
@Tag(name = "CmPuCopu0020")
@RequestMapping("/api/cm/pu/copu/CmPuCopu0020")
public class CmPuCopu0020Controller {
    private final CmPuCopu0020Service cmPuCopu0020Service;

    @PostMapping(value = "selectEmpKey", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> selectEmpKey(@RequestBody Map<String, Object> paramMap) {
        List<GsrsMap> result = cmPuCopu0020Service.selectEmpKey(paramMap);
        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(result)
                        .build(),
                HttpStatus.OK);
    }


    @PostMapping(value = "selectEmpList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> selectEmpList(@RequestBody Map<String, Object> paramMap) {
//        UserSessionVO userSession = SessionScopeUtil.getContextSession();

        List<GsrsMap> result;
        if (paramMap.containsKey("langCd") && MapUtils.getString(paramMap, "langCd").equals("en")) {
            result = cmPuCopu0020Service.selectEmpListEn(paramMap);
        } else {
            result = cmPuCopu0020Service.selectEmpList(paramMap);
        }
        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(result)
                        .build(),
                HttpStatus.OK);
    }
}
