package com.gsenc.cfs.cm.pu.copu.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.gsenc.cfs.common.dao.CommonDAO;
import com.gsenc.cfs.common.model.GsrsMap;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class CmPuCopu0011ServiceImpl implements CmPuCopu0011Service {

    private final static String _PACKAGE_NAMESPACE = "cm.pu.copu.CmPuCopu0011.";
    private final CommonDAO commonDAO;

    @Override
    public List<GsrsMap> selectAccoCodeList(Map<String, Object> paramMap) {
        commonDAO.selectList(_PACKAGE_NAMESPACE + "callAccoCodeProc", paramMap);
        return (List<GsrsMap>) paramMap.get("resultList");
    }
}
