package com.gsenc.cfs.cm.pu.copu.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gsenc.cfs.common.dao.CommonDAO;
import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.wsf.common.util.DateUtil;
import com.gsenc.wsf.common.util.StringUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class CmPuCopu0003ServiceImpl implements CmPuCopu0003Service {

    private final static String _PACKAGE_NAMESPACE = "cm.pu.copu.CmPuCopu0003.";

    @Autowired
    private CommonDAO commonDao;

    @SuppressWarnings("unchecked")
    public Map<String, Object> selectCmPuCopu0003Init(Map<String, Object> paramMap) {

        String profDate = StringUtil.isNullToString(paramMap.get("profDate")); // yyyymmdd 형식
        String profDept = StringUtil.isNullToString(paramMap.get("profDept"));
        String profClss = StringUtil.isNullToString(paramMap.get("profClss")); // 차수
        String profMain = StringUtil.isNullToString(paramMap.get("profMain")); // 번호

        String hspanConfirmNo = ""; // 확정번호
        String hspanConfirmName = ""; // 승인자
        String hspanConfirmTextDisplay = ""; // 확정번호 Label Display 여부
        String hspanConfirmNoDisplay = ""; // 확정번호 Value Display 여부
        String hspanWriteDate = ""; // 작성일자
        String hspanCurcCode = ""; // 통화단위
        String hspanExhgRate = ""; // 환율
        String hspanDeptName = ""; // 사용부서
        String hspanProfDate = ""; // 입력일자
        String hspanProfClss = ""; // 차수
        String hspanProfMain = ""; // 번호
        String hspanBusnDivs = ""; // 구분
        String hspanEmpName = ""; // 입력자
        String spExhgDate = ""; // 환산일자
        String spSapNum = ""; // sap번호
        String hspanInputNo = profDate + " " + profDept + " " + profClss + " " + profMain; // 입력번호
        String confirmYn = ""; // 확정여부

        List<GsrsMap> fata200List = (List<GsrsMap>)commonDao.selectList(_PACKAGE_NAMESPACE + "selectCmPuCopu0003Fata200List", paramMap);

        int rowCnt = fata200List.size();

        if (rowCnt == 0){ // 확정 : N 일 경우

            confirmYn = "N";

            hspanConfirmTextDisplay = "N";
            hspanConfirmNoDisplay = "N";

            fata200List = (List<GsrsMap>)commonDao.selectList(_PACKAGE_NAMESPACE + "selectCmPuCopu0003Fata100List", paramMap);

            rowCnt = fata200List.size();

        } else { // 확정 : Y 일 경우

            GsrsMap fata200Data = fata200List.get(0);

            confirmYn = "Y";
            hspanConfirmTextDisplay = "Y";
            hspanConfirmNoDisplay = "Y";

            hspanConfirmNo = StringUtil.isNullToString(fata200Data.get("slipDate")) + " " +
                    StringUtil.isNullToString(fata200Data.get("slipDept")) + " " +
                    StringUtil.isNullToString(fata200Data.get("slipClss")) + " " +
                    StringUtil.isNullToString(fata200Data.get("slipMain"));

            hspanConfirmName = StringUtil.isNullToString(fata200Data.get("confirmEmpName"));

        }

        if (rowCnt > 0){

            GsrsMap fata200Data = fata200List.get(0);

            hspanWriteDate = DateUtil.formatDate(StringUtil.isNullToString(fata200Data.get("madeDate")), ".");
            hspanCurcCode = StringUtil.isNullToString(fata200Data.get("curcCode"));

            if (!"KRW".equals(hspanCurcCode)){
                hspanExhgRate = StringUtil.isNullToString(fata200Data.get("exhgRate"));
            }

            hspanDeptName = StringUtil.isNullToString(fata200Data.get("deptName"));
            hspanProfDate = DateUtil.formatDate(profDate, "."); // yyyy.mm.dd
            hspanProfClss = profClss;
            hspanProfMain = profMain;
            hspanBusnDivs = StringUtil.isNullToString(fata200Data.get("busnName"));
            hspanEmpName = StringUtil.isNullToString(fata200Data.get("empName"));
            spExhgDate = DateUtil.formatDate(StringUtil.isNullToString(fata200Data.get("exhgDate")), ".");
            spSapNum = StringUtil.isNullToString(fata200Data.get("sapSlipNum"));

        }

        List<GsrsMap> dataList = new ArrayList<GsrsMap>(); // 분개내역 목록

        if ("Y".equals(confirmYn)){ // 화면에서 DBCR_DIVS 에 따른 컬럼 및 지사환종 값 분기 있음
            dataList = (List<GsrsMap>)commonDao.selectList(_PACKAGE_NAMESPACE + "selectCmPuCopu0003ConfirmYList", paramMap);
        } else {
            dataList = (List<GsrsMap>)commonDao.selectList(_PACKAGE_NAMESPACE + "selectCmPuCopu0003ConfirmNList", paramMap);
        }

        // 화면 Page Load 시 필요한 데이터 셋팅
        return Map.ofEntries(
                Map.entry("hspanConfirmTextDisplay", hspanConfirmTextDisplay),
                Map.entry("hspanConfirmNoDisplay", hspanConfirmNoDisplay),
                Map.entry("hspanConfirmNo", hspanConfirmNo),
                Map.entry("hspanConfirmName", hspanConfirmName),
                Map.entry("hspanWriteDate", hspanWriteDate),
                Map.entry("hspanCurcCode", hspanCurcCode),
                Map.entry("hspanExhgRate", hspanExhgRate),
                Map.entry("hspanDeptName", hspanDeptName),
                Map.entry("hspanProfDate", hspanProfDate),
                Map.entry("hspanProfClss", hspanProfClss),
                Map.entry("hspanProfMain", hspanProfMain),
                Map.entry("hspanBusnDivs", hspanBusnDivs),
                Map.entry("hspanEmpName", hspanEmpName),
                Map.entry("spExhgDate", spExhgDate),
                Map.entry("spSapNum", spSapNum),
                Map.entry("hspanInputNo", hspanInputNo),
                Map.entry("hspanConfirmYN", confirmYn),
                Map.entry("dataList", dataList),
                Map.entry("totalCount", dataList.size())
        );
    }
}
