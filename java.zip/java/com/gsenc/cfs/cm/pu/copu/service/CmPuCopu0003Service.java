package com.gsenc.cfs.cm.pu.copu.service;

import java.util.Map;

public interface CmPuCopu0003Service {
    Map<String, Object> selectCmPuCopu0003Init(Map<String, Object> paramMap);
}
