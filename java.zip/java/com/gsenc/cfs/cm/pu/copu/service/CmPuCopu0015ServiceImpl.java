package com.gsenc.cfs.cm.pu.copu.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gsenc.cfs.common.dao.CommonDAO;
import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.exception.GsEncException;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class CmPuCopu0015ServiceImpl implements CmPuCopu0015Service {

    private final static String _COMMON_NAMESPACE = "cm.pu.copu.CmPuCopu0015.";

    @Autowired
    private CommonDAO commonDAO;

    @SuppressWarnings("unchecked")
    public Map<String, Object> selectCmPuCopu0015I1MList(Map<String, Object> paramMap) {
        //UserSessionVO userSession = SessionScopeUtil.getContextSession();

        Map<String, Object> gridData = null;
        int totalCount = 0;

        paramMap.put("suId", paramMap.get("suId"));						// suId
        paramMap.put("ipId", paramMap.get("ipId"));						// ipId
        paramMap.put("strtIssueDate", paramMap.get("strtIssueDate"));	// strtIssueDate
        paramMap.put("fnshIssueDate", paramMap.get("fnshIssueDate"));	// fnshIssueDate
        paramMap.put("deptCode", paramMap.get("deptCode"));				// deptCode
        paramMap.put("checkYn", paramMap.get("checkYn"));				// checkYn
        paramMap.put("suPersname", paramMap.get("suPersname"));			// suPersname
        paramMap.put("empNo", paramMap.get("empNo"));				    // prcsDivs

        commonDAO.selectList(_COMMON_NAMESPACE + "selectCmPuCopu0015I1MList", paramMap);

        List<GsrsMap> listGsrsMap = (List<GsrsMap>)paramMap.get("list");
        totalCount = listGsrsMap.size();

        gridData = new HashMap<>();
        gridData.put("totalCount", totalCount);
        gridData.put("list", listGsrsMap);

        return gridData;
    }

    @Transactional(rollbackFor = {Exception.class})
    public GsrsMap saveCmPuCopu0015I1(Map<String, Object> paramMap) {
        UserSessionVO userSession = SessionScopeUtil.getContextSession();

        GsrsMap resultMap = new GsrsMap();

        paramMap.put("errRaise", 	"Y");
        paramMap.put("profDate", 	paramMap.get("profDate"));
        paramMap.put("profDept", 	paramMap.get("profDept"));
        paramMap.put("profClss", 	paramMap.get("profClss"));
        paramMap.put("profMain", 	paramMap.get("profMain"));
        paramMap.put("grpNum", 		paramMap.get("grpNum"));
        paramMap.put("systApp", 	paramMap.get("systApp"));   // 시스템 EAS 회계, MMS-구매, PMS-PMS
        paramMap.put("issueDate", 	paramMap.get("issueDate")); // 전자세금계산서 작성일자
        paramMap.put("issueId", 	paramMap.get("issueId"));   // 국세청신고번호
        paramMap.put("invSeq", 		paramMap.get("invSeq"));    // 일련번호
        paramMap.put("gubun", 		paramMap.get("gubun"));

        try {
            // 해당 프로시저는 에러 인경우 msg로 리턴이 아닌 강제 Exception 처리 되기에 try 로 감싸고 임의로 메시지를 화면에 리턴해줌
            commonDAO.selectList(_COMMON_NAMESPACE + "saveCmPuCopu0015I1", paramMap);
        } catch (Exception e) {
            String fullMessage = e.getMessage();
            String pMsg = null;

            if ( fullMessage != null && fullMessage.contains("ORA-20001:") ) {
                int start = fullMessage.indexOf("ORA-20001:") + "ORA-20001:".length();
                int end = fullMessage.indexOf("ORA-", start);
                if ( end == -1 ) {
                    end = fullMessage.length();
                }
                pMsg = fullMessage.substring(start, end).trim();
            }
            throw new GsEncException(pMsg, StatusCodeConstants.FAIL, new HashMap<>());
        }

        // 성공시는 리턴값 있음
        resultMap.put("msg", paramMap.get("msg"));

        return resultMap;

    }
}
