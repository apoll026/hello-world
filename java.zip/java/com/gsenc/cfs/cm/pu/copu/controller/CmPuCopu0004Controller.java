package com.gsenc.cfs.cm.pu.copu.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.gsenc.cfs.cm.pu.copu.service.CmPuCopu0004Service;
import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.cfs.common.service.commonPu0001Service;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "CmPuCopu0004")
@RequestMapping("/api")
public class CmPuCopu0004Controller {

    private final CmPuCopu0004Service cmPuCopu0004Service;
    private final commonPu0001Service commonPu0001Service;

    @Operation(summary = "전표리스트 조회")
    @PostMapping(value = "/cm/pu/copu/selectCmPuCopu0004", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> selectCmPuCopu0004(@RequestBody Map<String, Object> paramMap) {

        List<Map<String, Object>> result = cmPuCopu0004Service.selectCmPuCopu0004(paramMap);

        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(result)
                        .build(),
                HttpStatus.OK);
    }

    @Operation(summary = "전표리스트 onLoad 시점 부서조회")
    @PostMapping(value = "/cm/pu/copu/selectCmPuCopu0004/getDept", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> selectCmPuCopu0004GetDept(@RequestBody Map<String, Object> paramMap) {

        List<GsrsMap> result = commonPu0001Service.selectGetData(paramMap);

        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(result)
                        .build(),
                HttpStatus.OK);
    }
}
