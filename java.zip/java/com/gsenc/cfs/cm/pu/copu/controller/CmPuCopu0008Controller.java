package com.gsenc.cfs.cm.pu.copu.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.cfs.cm.pu.copu.service.CmPuCopu0008Service;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequiredArgsConstructor
@Tag(name = "CmPuCopu0008")
@RequestMapping("/api")
public class CmPuCopu0008Controller {
    private final CmPuCopu0008Service cmPuCopu0008Service;

    @PostMapping(value = "/cm/pu/copu/CmPuCopu0008/getAccName", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAccName(@RequestBody Map<String, Object> paramMap) {
        List<Map<String, Object>> result = cmPuCopu0008Service.getAccName(paramMap);
        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(result)
                        .build(),
                HttpStatus.OK);
    }

    @PostMapping(value = "/cm/pu/copu/CmPuCopu0008/getAcctCode", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAcctCode(@RequestBody Map<String, Object> paramMap) {
        List<Map<String, Object>> result = cmPuCopu0008Service.getAcctCode(paramMap);
        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(result)
                        .build(),
                HttpStatus.OK);
    }

    @PostMapping(value = "/cm/pu/copu/CmPuCopu0008/getDeptInfo", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getDeptInfo(@RequestBody Map<String, Object> paramMap) {
        List<Map<String, Object>> result = cmPuCopu0008Service.getDeptInfo(paramMap);
        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(result)
                        .build(),
                HttpStatus.OK);
    }

    @PostMapping(value = "/cm/pu/copu/CmPuCopu0008/getSearchData", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getSearchData(@RequestBody Map<String, Object> paramMap) {
        List<Map<String, Object>> result = cmPuCopu0008Service.getSearchData(paramMap);
        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(result)
                        .build(),
                HttpStatus.OK);
    }

    @PostMapping(value = "/cm/pu/copu/CmPuCopu0008/getSumFata110", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getSumFata110(@RequestBody Map<String, Object> paramMap) {
        List<Map<String, Object>> result = cmPuCopu0008Service.getSumFata110(paramMap);
        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(result)
                        .build(),
                HttpStatus.OK);
    }

    @PostMapping(value = "/cm/pu/copu/CmPuCopu0008/getCmpnDivs", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getCmpnDivs(@RequestBody Map<String, Object> paramMap) {
        List<Map<String, Object>> result = cmPuCopu0008Service.getCmpnDivs(paramMap);
        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(result)
                        .build(),
                HttpStatus.OK);
    }

}
