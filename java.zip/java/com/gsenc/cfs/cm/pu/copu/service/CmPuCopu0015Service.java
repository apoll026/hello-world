package com.gsenc.cfs.cm.pu.copu.service;

import java.util.Map;

import com.gsenc.cfs.common.model.GsrsMap;

public interface CmPuCopu0015Service {

    public Map<String, Object> selectCmPuCopu0015I1MList(Map<String, Object> paramMap);

    public GsrsMap saveCmPuCopu0015I1(Map<String, Object> paramMap);
}
