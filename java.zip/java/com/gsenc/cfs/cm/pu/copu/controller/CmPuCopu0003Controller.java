package com.gsenc.cfs.cm.pu.copu.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.gsenc.cfs.cm.pu.copu.service.CmPuCopu0003Service;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "CmPuCopu0003")
@RequestMapping("/api")
public class CmPuCopu0003Controller {

    private final CmPuCopu0003Service cmPuCopu0003Service;

    @Operation(summary = "분개내역 조회", description = "분개내역 조회")
    @PostMapping(value = "/cm/pu/copu/selectCmPuCopu0003Init", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO<Map<String, Object>>> selectCmPuCopu0003Init(@RequestBody Map<String, Object> paramMap) {

        return new ResponseEntity<>(
                CommonResponseVO.<Map<String, Object>>builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(cmPuCopu0003Service.selectCmPuCopu0003Init(paramMap))
                        .build(),
                HttpStatus.OK);

    }
}
