package com.gsenc.cfs.cm.pu.copu.service;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.gsenc.cfs.common.dao.CommonDAO;
import com.gsenc.cfs.common.model.GsrsMap;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class CmPuCopu0010ServiceImpl implements CmPuCopu0010Service {

    private final static String _PACKAGE_NAMESPACE = "cm.pu.copu.CmPuCopu0010.";
    private final CommonDAO commonDAO;

    @Override
    public List<GsrsMap> selectDeptListAcctYnS(Map<String, Object> paramMap) {
        String queryId;
        if("B".equals(MapUtils.getString(paramMap, "strType")) || StringUtils.isNotEmpty(MapUtils.getString(paramMap, "strKey"))) {
            if ("en".equals(MapUtils.getString(paramMap, "langCd"))) queryId = "selectDeptList_acctYnS_en";
            else queryId = "selectDeptList_acctYnS_ko";

            return (List<GsrsMap>) commonDAO.selectList(_PACKAGE_NAMESPACE + queryId, paramMap);
        }
        return List.of();
    }

    @Override
    public List<GsrsMap> selectDeptListAcctYnA(Map<String, Object> paramMap) {
        String queryId;
        if("B".equals(MapUtils.getString(paramMap, "strType")) || StringUtils.isNotEmpty(MapUtils.getString(paramMap, "strKey"))) {
            if ("en".equals(MapUtils.getString(paramMap, "langCd"))) queryId = "selectDeptList_acctYnA_en";
            else queryId = "selectDeptList_acctYnA_ko";

            return (List<GsrsMap>) commonDAO.selectList(_PACKAGE_NAMESPACE + queryId, paramMap);
        }
        return List.of();
    }

    @Override
    public List<GsrsMap> selectDeptListAcctYnY(Map<String, Object> paramMap) {
        if("B".equals(MapUtils.getString(paramMap, "strType"))
            || StringUtils.isNotEmpty(MapUtils.getString(paramMap, "strKey"))
            || StringUtils.isNotEmpty(MapUtils.getString(paramMap, "strCode"))
            || StringUtils.isNotEmpty(MapUtils.getString(paramMap, "strName"))) {
            return (List<GsrsMap>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectDeptList_acctYnY", paramMap);
        }
        return List.of();
    }
}
