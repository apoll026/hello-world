package com.gsenc.cfs.cm.pu.copu.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.cfs.cm.pu.copu.service.CmPuCopu0010Service;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequiredArgsConstructor
@Tag(name = "CmPuCopu0010")
@RequestMapping("/api")
public class CmPuCopu0010Controller {
    private final CmPuCopu0010Service cmPuCopu0010Service;

    @Operation(summary = "부서 조회 - acctYn이 S일 때")
    @PostMapping(value = "/cm/pu/copu/selectDeptListAcctYnS", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO> selectDeptListAcctYnS(@RequestBody Map<String, Object> paramMap) {
        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(cmPuCopu0010Service.selectDeptListAcctYnS(paramMap))
                        .build(), HttpStatus.OK);
    }

    @Operation(summary = "부서 조회 - acctYn이 A일 때")
    @PostMapping(value = "/cm/pu/copu/selectDeptListAcctYnA", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO> selectDeptListAcctYnA(@RequestBody Map<String, Object> paramMap) {
        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(cmPuCopu0010Service.selectDeptListAcctYnA(paramMap))
                        .build(), HttpStatus.OK);
    }

    @Operation(summary = "부서 조회 - acctYn이 Y일 때")
    @PostMapping(value = "/cm/pu/copu/selectDeptListAcctYnY", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO> selectDeptListAcctYnY(@RequestBody Map<String, Object> paramMap) {
        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(cmPuCopu0010Service.selectDeptListAcctYnY(paramMap))
                        .build(), HttpStatus.OK);
    }
}
