package com.gsenc.cfs.cm.pu.copu.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.gsenc.cfs.common.dao.CommonDAO;
import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.cfs.common.service.EasCommonCodeService;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.exception.GsEncException;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.common.util.StringUtil;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class CmPuCopu0002ServiceImpl implements CmPuCopu0002Service {

    private final static String _PACKAGE_NAMESPACE = "cm.pu.copu.CmPuCopu0002.";
    private final CommonDAO commonDAO;
    private final EasCommonCodeService easCommonCodeService;

    public List<GsrsMap> selectFaty500List(Map<String, Object> paramMap) {

        UserSessionVO userSession = SessionScopeUtil.getContextSession();

        // 화면에서 전달된 사원번호 값 있으면 그 값으로 처리
        String empNo = StringUtil.isNullToString(paramMap.get("empNo"));
        if (empNo.isEmpty() && userSession != null){
            empNo = userSession.getEmpNo();
        }

        if (StringUtil.isNullToString(paramMap.get("cmpn")).isEmpty()){
            /*
            throw new BusinessException("거래처 정보가 정확하지 않습니다.",
                    StatusCodeConstants.PARAMETER_VALUE_ERROR);
             */
            throw new GsEncException("거래처 정보가 정확하지 않습니다.",
                    StatusCodeConstants.PARAMETER_VALUE_ERROR, new HashMap<>());
        }

        //commonDAO.selectList(_PACKAGE_NAMESPACE + "selectFaty500List", paramMap);
        //List<GsrsMap> resultList = (List<GsrsMap>)paramMap.get("list");

        // 공통코드 easCommonCodeService 에서 가져오도록 변경
        List<GsrsMap> resultList = easCommonCodeService.selectCommonCodeList(paramMap);

        // 람다식 에러 때문에 하단에 final 변수 생성
        String finalEmpNo = empNo;

        return resultList.stream()
                .filter(data -> finalEmpNo.equals(StringUtil.isNullToString(data.get("code"))))
                .collect(Collectors.toList());
    }

    public GsrsMap selectCmPuCopu0002InitData(Map<String, Object> paramMap) {
        return (GsrsMap) commonDAO.selectOne(_PACKAGE_NAMESPACE + "selectCmPuCopu0002InitData", paramMap);
    }

    public Map<String, Object> saveCmPuCopu0002(Map<String, Object> paramMap) {
        try {
            // 해당 프로시저는 에러 인경우 msg로 리턴이 아닌 강제 Exception 처리 되기에 try 로 감싸고 임의로 메시지를 화면에 리턴해줌
            commonDAO.selectList(_PACKAGE_NAMESPACE + "saveCmPuCopu0002", paramMap);
        } catch (Exception e) {
            throw new GsEncException(e.getMessage(), StatusCodeConstants.FAIL, new HashMap<>());
        }

        // 성공시는 리턴값 있음
        return new HashMap<>(Map.of(
                "msg", StringUtil.isNullToString(paramMap.get("msg"))
        ));
    }
}
