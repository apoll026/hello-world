package com.gsenc.cfs.cm.pu.copu.service;

import java.util.List;
import java.util.Map;

public interface CmPuCopu0004Service {

    List<Map<String, Object>> selectCmPuCopu0004(Map<String, Object> paramMap);
}
