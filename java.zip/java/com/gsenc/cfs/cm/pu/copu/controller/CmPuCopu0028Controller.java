package com.gsenc.cfs.cm.pu.copu.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.cfs.cm.pu.copu.service.CmPuCopu0028Service;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequiredArgsConstructor
@Tag(name = "CmPuCopu0028")
@RequestMapping("/api/cm/pu/copu/CmPuCopu0028")
public class CmPuCopu0028Controller {
    private final CmPuCopu0028Service cmPuCopu0028Service;

    @Operation(summary = "코드조회 - 사업부")
    @PostMapping(value = "selectDeptNameKind1", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO> selectDeptNameKind1(@RequestBody Map<String, Object> paramMap) {
        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(cmPuCopu0028Service.selectDeptNameKind1(paramMap))
                        .build(), HttpStatus.OK
        );
    }

    @Operation(summary = "코드조회 - 사업단위")
    @PostMapping(value = "selectDeptNameKind2", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO> selectDeptNameKind2(@RequestBody Map<String, Object> paramMap) {
        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(cmPuCopu0028Service.selectDeptNameKind2(paramMap))
                        .build(), HttpStatus.OK
        );
    }

    @Operation(summary = "코드조회 - 부서")
    @PostMapping(value = "selectDeptNameKind3", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO> selectDeptNameKind3(@RequestBody Map<String, Object> paramMap) {
        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(cmPuCopu0028Service.selectDeptNameKind3(paramMap))
                        .build(), HttpStatus.OK
        );
    }
}
