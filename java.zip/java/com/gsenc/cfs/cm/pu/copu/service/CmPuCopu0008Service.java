package com.gsenc.cfs.cm.pu.copu.service;

import java.util.List;
import java.util.Map;

public interface CmPuCopu0008Service {
    List<Map<String, Object>> getAccName(Map<String, Object> paramMap);
    List<Map<String, Object>> getAcctCode(Map<String, Object> paramMap);
    List<Map<String, Object>> getDeptInfo(Map<String, Object> paramMap);
    List<Map<String, Object>> getSearchData(Map<String, Object> paramMap);
    List<Map<String, Object>> getSumFata110(Map<String, Object> paramMap);
    List<Map<String, Object>> getCmpnDivs(Map<String, Object> paramMap);
}
