package com.gsenc.cfs.cm.pu.copu.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.cfs.cm.pu.copu.service.CmPuCopu0019Service;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "CmPuCopu0019")
@RequestMapping("/api")
public class CmPuCopu0019Controller {

    private final CmPuCopu0019Service cmPuCopu0019Service;

    @Operation(summary = "교육훈련비 첫번째 그리드 조회", description = "교육훈련비 첫번째 그리드 조회")
    @PostMapping(value = "/cm/pu/copu/selectCmPuCopu0019List", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO<Map<String, Object>>> selectCmPuCopu0019List(@RequestBody Map<String, Object> paramMap) {
        return new ResponseEntity<>(
                CommonResponseVO.<Map<String, Object>>builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(cmPuCopu0019Service.selectCmPuCopu0019List(paramMap))
                        .build(),
                HttpStatus.OK);
    }

    @Operation(summary = "교육훈련비 두번째 그리드 조회", description = "교육훈련비 두번째 그리드 조회")
    @PostMapping(value = "/cm/pu/copu/selectCmPuCopu0019SecondList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO<Map<String, Object>>> selectCmPuCopu0019SecondList(@RequestBody Map<String, Object> paramMap) {
        return new ResponseEntity<>(
                CommonResponseVO.<Map<String, Object>>builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(cmPuCopu0019Service.selectCmPuCopu0019SecondList(paramMap))
                        .build(),
                HttpStatus.OK);
    }
}
