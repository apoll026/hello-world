package com.gsenc.cfs.cm.pu.copu.service;

import java.util.List;
import java.util.Map;

import com.gsenc.cfs.common.model.GsrsMap;

public interface CmPuCopu0012Service {
    List<GsrsMap> selectDetailItemList(Map<String, Object> paramMap);
    List<GsrsMap> selectTechItemList(Map<String, Object> paramMap);
}
