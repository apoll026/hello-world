package com.gsenc.cfs.cm.pu.copu.service;

import java.util.List;
import java.util.Map;

import com.gsenc.cfs.common.model.GsrsMap;

public interface CmPuCopu0011Service {
    List<GsrsMap> selectAccoCodeList(Map<String, Object> paramMap);
}
