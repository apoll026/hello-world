package com.gsenc.cfs.cm.pu.copu.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.cfs.cm.pu.copu.service.CmPuCopu0002Service;
import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "CmPuCopu0002")
@RequestMapping("/api")
public class CmPuCopu0002Controller {

    private final CmPuCopu0002Service cmPuCopu0002Service;

    @Operation(summary = "회원정보에 해당하는 코드 드롭다운리스트 조회")
    @PostMapping(value = "/cm/pu/copu/selectInitCodeData", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO<List<GsrsMap>>> selectFaty500List(@RequestBody Map<String, Object> paramMap) {
        return new ResponseEntity<>(
                CommonResponseVO.<List<GsrsMap>>builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(cmPuCopu0002Service.selectFaty500List(paramMap))
                        .build(),
                HttpStatus.OK);
    }

    @Operation(summary = "상세 조회")
    @PostMapping(value = "/cm/pu/copu/selectCmPuCopu0002InitData", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO<GsrsMap>> selectCmPuCopu0002InitData(@RequestBody Map<String, Object> paramMap) {
        return new ResponseEntity<>(
                CommonResponseVO.<GsrsMap>builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(cmPuCopu0002Service.selectCmPuCopu0002InitData(paramMap))
                        .build(),
                HttpStatus.OK);
    }

    @Operation(summary = "거래처 등록")
    @PostMapping(value = "/cm/pu/copu/saveCmPuCopu0002", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO<Map<String, Object>>> saveCmPuCopu0002(@RequestBody Map<String, Object> paramMap) {
        return new ResponseEntity<>(
                CommonResponseVO.<Map<String, Object>>builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(cmPuCopu0002Service.saveCmPuCopu0002(paramMap))
                        .build(),
                HttpStatus.OK);
    }
}
