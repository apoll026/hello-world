package com.gsenc.cfs.cm.pu.copu.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.cfs.cm.pu.copu.service.CmPuCopu0039Service;
import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "CmPuCopu0039")
@RequestMapping("/api")
public class CmPuCopu0039Controller {

    private final CmPuCopu0039Service cmPuCopu0039Service;

    @Operation(summary = "상세 조회")
    @PostMapping(value = "/cm/pu/copu/CmPuCopu0039/selectInitData", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO<GsrsMap>> selectInitData(@RequestBody Map<String, Object> paramMap) {
        return new ResponseEntity<>(
                CommonResponseVO.<GsrsMap>builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(cmPuCopu0039Service.selectCmPuCopu0039InitData(paramMap))
                        .build(),
                HttpStatus.OK);
    }
}
