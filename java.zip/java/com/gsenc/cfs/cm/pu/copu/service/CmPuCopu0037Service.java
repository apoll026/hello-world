package com.gsenc.cfs.cm.pu.copu.service;

import java.util.List;
import java.util.Map;

public interface CmPuCopu0037Service {
    List<Map<String, Object>> selectAccoutGrp(Map<String, Object> paramMap);
}
