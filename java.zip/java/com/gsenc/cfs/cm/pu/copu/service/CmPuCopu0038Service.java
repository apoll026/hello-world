package com.gsenc.cfs.cm.pu.copu.service;

import java.util.List;
import java.util.Map;

public interface CmPuCopu0038Service {
    List<Map<String, Object>> selectBusnDivs(Map<String, Object> paramMap);
}
