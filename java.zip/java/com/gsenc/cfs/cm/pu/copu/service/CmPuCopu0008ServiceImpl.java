package com.gsenc.cfs.cm.pu.copu.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.gsenc.cfs.common.dao.CommonDAO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class CmPuCopu0008ServiceImpl implements CmPuCopu0008Service {
    private final static String _PACKAGE_NAMESPACE = "cm.pu.copu.CmPuCopu0008.";
    private final CommonDAO commonDAO;

    @Override
    public List<Map<String, Object>> getAccName(Map<String, Object> paramMap) {
        commonDAO.selectList(_PACKAGE_NAMESPACE + "getAccName", paramMap);
        return (List<Map<String, Object>>) paramMap.get("oRc");
    }

    @Override
    public List<Map<String, Object>> getAcctCode(Map<String, Object> paramMap) {
        return (List<Map<String, Object>>) commonDAO.selectList(_PACKAGE_NAMESPACE + "getAcctCode", paramMap);
    }

    @Override
    public List<Map<String, Object>> getDeptInfo(Map<String, Object> paramMap) {
        return (List<Map<String, Object>>) commonDAO.selectList(_PACKAGE_NAMESPACE + "getDeptInfo", paramMap);
    }

    @Override
    public List<Map<String, Object>> getSearchData(Map<String, Object> paramMap) {
        return (List<Map<String, Object>>) commonDAO.selectList(_PACKAGE_NAMESPACE + "getSearchData", paramMap);
    }

    @Override
    public List<Map<String, Object>> getSumFata110(Map<String, Object> paramMap) {
        return (List<Map<String, Object>>) commonDAO.selectList(_PACKAGE_NAMESPACE + "getSumFata110", paramMap);
    }

    @Override
    public List<Map<String, Object>> getCmpnDivs(Map<String, Object> paramMap) {
        return (List<Map<String, Object>>) commonDAO.selectList(_PACKAGE_NAMESPACE + "getCmpnDivs", paramMap);
    }



}
