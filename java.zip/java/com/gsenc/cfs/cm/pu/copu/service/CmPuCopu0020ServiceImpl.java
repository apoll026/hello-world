package com.gsenc.cfs.cm.pu.copu.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.gsenc.cfs.common.dao.CommonDAO;
import com.gsenc.cfs.common.model.GsrsMap;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class CmPuCopu0020ServiceImpl implements CmPuCopu0020Service {

    private final static String _PACKAGE_NAMESPACE = "cm.pu.copu.CmPuCopu0020.";
    private final CommonDAO commonDAO;

    @Override
    public List<GsrsMap> selectEmpKey(Map<String, Object> paramMap) {
        return (List<GsrsMap>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectEmpKey", paramMap);
    }

    @Override
    public List<GsrsMap> selectEmpList(Map<String, Object> paramMap) {
        return (List<GsrsMap>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectEmpList", paramMap);
    }
    @Override
    public List<GsrsMap> selectEmpListEn(Map<String, Object> paramMap) {
        return (List<GsrsMap>) commonDAO.selectList(_PACKAGE_NAMESPACE + "selectEmpListEn", paramMap);
    }
}
