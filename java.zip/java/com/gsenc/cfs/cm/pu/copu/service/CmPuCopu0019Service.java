package com.gsenc.cfs.cm.pu.copu.service;

import java.util.Map;

import com.gsenc.cfs.common.model.GsrsMap;

public interface CmPuCopu0019Service {

    GsrsMap selectCmPuCopu0019Param(Map<String, Object> paramMap);

    Map<String, Object> selectCmPuCopu0019List(Map<String, Object> paramMap);

    Map<String, Object> selectCmPuCopu0019SecondList(Map<String, Object> paramMap);
}
