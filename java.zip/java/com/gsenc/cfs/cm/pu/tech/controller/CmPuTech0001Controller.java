package com.gsenc.cfs.cm.pu.tech.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.cfs.cm.pu.tech.service.CmPuTech0001Service;
import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "CmPuTech0001")
@Validated
@RequestMapping("/api")
public class CmPuTech0001Controller {
	private final CmPuTech0001Service cmPuTech0001Service;

	@Operation(summary = "사원 조회", description = "검색어 조건으로 사원번호 or 사원명에서 조회")
	@GetMapping(value = "/v1/selectEmpKey", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<List<GsrsMap>>> selectEmpKey(@RequestParam Map<String, Object> input) {
		return new ResponseEntity<>(
				CommonResponseVO.<List<GsrsMap>>builder()
						.successOrNot(CommonConstants.YES_FLAG)
						.statusCode(StatusCodeConstants.SUCCESS)
						.data(cmPuTech0001Service.selectEmpKey(input))
						.build(),
				HttpStatus.OK);
	}
}
