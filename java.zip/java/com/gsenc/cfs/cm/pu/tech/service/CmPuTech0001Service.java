package com.gsenc.cfs.cm.pu.tech.service;

import java.util.List;
import java.util.Map;

import com.gsenc.cfs.common.model.GsrsMap;

public interface CmPuTech0001Service {
    List<GsrsMap> selectEmpKey(Map<String, Object> input);

}
