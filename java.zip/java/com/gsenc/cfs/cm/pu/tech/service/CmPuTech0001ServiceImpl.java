package com.gsenc.cfs.cm.pu.tech.service;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gsenc.cfs.common.dao.CommonDAO;
import com.gsenc.cfs.common.model.GsrsMap;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CmPuTech0001ServiceImpl implements CmPuTech0001Service {

	private final static String _COMMON_NAMESPACE = "cm.pu.tech.CmPuTech0001.";

	@Autowired
	private CommonDAO commonDao;

	@SuppressWarnings("unchecked")
	public List<GsrsMap> selectEmpKey(Map<String, Object> input) {
		return (List<GsrsMap>)commonDao.selectList(_COMMON_NAMESPACE + "selectEmpKey", input);
	}
}
