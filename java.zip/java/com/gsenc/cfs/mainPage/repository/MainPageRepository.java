package com.gsenc.cfs.mainPage.repository;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.cfs.mainPage.model.MainBbsVO;
import com.gsenc.cfs.mainPage.model.MainNoticeVO;

@Mapper
public interface MainPageRepository {
    void selectMainCountData(@Param("params") Map<String, Object> params);
    List<MainNoticeVO> selectMainNoticeData();
    List<MainBbsVO> selectMainBbsData();

}
