package com.gsenc.cfs.mainPage.service;

import java.util.List;

import com.gsenc.cfs.mainPage.model.MainBbsVO;
import com.gsenc.cfs.mainPage.model.MainCountVO;
import com.gsenc.cfs.mainPage.model.MainNoticeVO;

public interface MainPageService {

    MainCountVO findMainCountData(String empNo);
    List<MainNoticeVO> findMainNoticeData();
    List<MainBbsVO> findMainBbsData();

}
