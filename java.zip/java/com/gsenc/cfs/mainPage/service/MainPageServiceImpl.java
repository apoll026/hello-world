package com.gsenc.cfs.mainPage.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.gsenc.cfs.mainPage.model.MainBbsVO;
import com.gsenc.cfs.mainPage.model.MainCountVO;
import com.gsenc.cfs.mainPage.model.MainNoticeVO;
import com.gsenc.cfs.mainPage.repository.MainPageRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class MainPageServiceImpl implements MainPageService {
	private final MainPageRepository mainPageRepository;

	@Override
	public MainCountVO findMainCountData(String empNo) {
		try {
			// String tmp = "63927";
			Map<String, Object> params = new HashMap<>();
			params.put("i_empno", empNo);
			params.put("o_rc", null);  // OUT 파라미터 반드시 포함
			mainPageRepository.selectMainCountData(params);
			List<MainCountVO> result = (List<MainCountVO>)params.get("o_rc");

			return result.get(0);
		} catch (Exception e) {
			System.err.println("PROC_GET_MAIN_COUNT error - empNo: " + empNo + ", 오류: " + e.getMessage());
			e.printStackTrace();
			return new MainCountVO();
		}
	}

	@Override
	public List<MainNoticeVO> findMainNoticeData() {
		return mainPageRepository.selectMainNoticeData();
	}

	@Override
	public List<MainBbsVO> findMainBbsData() {
		return mainPageRepository.selectMainBbsData();
	}

}
