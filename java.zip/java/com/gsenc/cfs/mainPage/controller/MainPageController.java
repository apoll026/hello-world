package com.gsenc.cfs.mainPage.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.cfs.mainPage.model.MainBbsVO;
import com.gsenc.cfs.mainPage.model.MainCountVO;
import com.gsenc.cfs.mainPage.model.MainNoticeVO;
import com.gsenc.cfs.mainPage.service.MainPageService;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "MainPage")
@Validated
@RequestMapping("/api")
public class MainPageController {

    private final MainPageService mainPageService;

    @Operation(summary = "메인화면 건수 데이터", description = "메인화면 건수 데이터")
    @GetMapping(value = "/main/count", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO<MainCountVO>> findMainCountData (@Parameter(description = "empNo", example = "12345") @RequestParam String empNo){
        return new ResponseEntity<>(
                CommonResponseVO.<MainCountVO>builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(mainPageService.findMainCountData(empNo))
                        .build(),
                HttpStatus.OK);
    }

    @Operation(summary = "메인화면 공지사항 데이터", description = "메인화면 건수 데이터")
    @GetMapping(value = "/main/notice", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO<List<MainNoticeVO>>> findMainNoticeData (){
        return new ResponseEntity<>(
                CommonResponseVO.<List<MainNoticeVO>>builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(mainPageService.findMainNoticeData())
                        .build(),
                HttpStatus.OK);
    }

    @Operation(summary = "메인화면 게시판 데이터", description = "메인화면 건수 데이터")
    @GetMapping(value = "/main/bbs", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO<List<MainBbsVO>>> findMainBbsData (){
        return new ResponseEntity<>(
                CommonResponseVO.<List<MainBbsVO>>builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(mainPageService.findMainBbsData())
                        .build(),
                HttpStatus.OK);
    }

}
