package com.gsenc.cfs.mainPage.model;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class MainBbsVO {
    private String bbsNo;
    private String bbsTitle;
    private String dataUpdDtm;
}
