package com.gsenc.cfs.mainPage.model;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class MainNoticeVO {
    private String noticeNo;
    private String noticeTitle;
    private String dataUpdDtm;
}
