package com.gsenc.cfs.mainPage.model;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class MainCountVO {
    private int apprCnt=0;
    private int apprPndgCnt=0;
    private int cardUnprCnt=0;
    private int reApprCnt=0;
    private int unprocPurTaxCnt=0;
    private int vchrTempCnt=0;
}
