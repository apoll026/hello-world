package com.gsenc.cfs.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.server.PathContainer;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.pattern.PathPattern;
import org.springframework.web.util.pattern.PathPatternParser;

import com.gsenc.wsf.common.filter.BufferedRequestWrapper;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SampleFilter extends OncePerRequestFilter {

	private final List<PathPattern> excludePathList = new ArrayList<PathPattern>();

	public SampleFilter(String[] excludePaths) {
		PathPatternParser pathPatternParser = new PathPatternParser();
		for (String excludePath : excludePaths) {
			excludePathList.add(pathPatternParser.parse(excludePath));
		}
	}

	@Override
	protected void doFilterInternal(HttpServletRequest req, HttpServletResponse response,
		FilterChain filterChain) throws ServletException, IOException {
		// shouldNotFilter에서 멀티파트 요청을 이미 걸렀으므로 여기서는 안전하게 래핑할 수 있습니다.
		BufferedRequestWrapper request = new BufferedRequestWrapper(req);

		// 아무일도 하지 않고 다음 핕터로 보냅니다. 필터를 구현하려면 이 코드 위에 작성하세요.
		filterChain.doFilter(request, response);
	}

	@Override
	protected boolean shouldNotFilter(HttpServletRequest request) throws ServletException {
		// 필터를 그냥 통과시키려면 true 를 리턴

		// 멀티파트 요청인 경우, 요청 본문을 읽지 않도록 필터를 건너뜁니다.
		String contentType = request.getContentType();
		if (contentType != null && contentType.toLowerCase().startsWith("multipart/")) {
			return true;
		}

		PathContainer parsePath = PathContainer.parsePath(request.getRequestURI());

		for (PathPattern pattern : excludePathList) {
			if (pattern.matches(parsePath)) {
				// log.debug("shouldNotFilter -- ExcludePath is : " + pattern.getPatternString() + "matched requestURI is : " +  request.getRequestURI() );
				return true;
			}
		}
		return false;
	}

}
