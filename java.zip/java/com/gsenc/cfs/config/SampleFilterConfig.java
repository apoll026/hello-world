package com.gsenc.cfs.config;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.gsenc.cfs.filter.SampleFilter;

@Configuration
public class SampleFilterConfig implements WebMvcConfigurer {
	/**
	 * Sample용 필터입니다.
	 * 이 필터는 아무일도 하지 않습니다.
	 * 만약 추가 필터가 필요할 경우 이 코드를 복사해서 사용하세요.
	 */
	@Bean
	public FilterRegistrationBean<SampleFilter> samplefilter() {

		// 필터적용을 제외할 Path Pattern
		String[] excludePaths = {
			"/api/v1/files/dext5editor-upload"
			, "/api/v1/dev/login"
			, "/api/v1/dev/outlogin"
			, "/api/swagger-ui/**"
			, "/swagger-resources/**"
			, "/soap/**"
			, "/api/v1/namoFileUpload"
			, "/file/**"
			, "/api/v1/approval/mobile/**"
			, "/api/v1/verify/**"
			, "/api/v1/Down2Excel/**"
			, "/api/cfs/view/**"
		};
		SampleFilter sampleFilter = new SampleFilter(excludePaths);

		FilterRegistrationBean<SampleFilter> registrationBean = new FilterRegistrationBean<>();
		registrationBean.setFilter(sampleFilter);
		registrationBean.setOrder(3);
		registrationBean.setName("samplefilter");
		return registrationBean;
	}
}
