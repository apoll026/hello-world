package com.gsenc.cfs.config;

import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.media.Schema;
import io.swagger.v3.oas.models.media.StringSchema;

@Configuration
@EnableWebMvc
public class SwaggerConfig {

    @Bean
    public OpenAPI openAPI() {
        Schema translatedMessageSchema = new Schema<Map<String, String>>()
            .addProperties("multilanguage.hello", new StringSchema().example("안녕하세요!"))
            .addProperties("multilanguage.page.translationInfo", new StringSchema().example("번역은 DeepL 번역기를 사용했습니다."));

        return new OpenAPI()
            //.components(new Components().addSchemas("TranslatedMessageSchema", translatedMessageSchema))
            .info(apiInfo());
    }

    private Info apiInfo() {
        return new Info()
            .title("표준개발Framework BE API Document")
            .description("표준개발Framework BE API 테스트를 위한 Swagger")
            .version("1.0.0");
    }

}
