package com.gsenc.cfs.bsl.common.repository;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.gsenc.cfs.common.model.GsrsMap;

@Mapper
public interface CmNTxRepository {

    List<GsrsMap> getFaty500(Map<String, Object> paramMap);

}
