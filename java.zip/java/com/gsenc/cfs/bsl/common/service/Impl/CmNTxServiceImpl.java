package com.gsenc.cfs.bsl.common.service.Impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.gsenc.cfs.bsl.common.repository.CmNTxRepository;
import com.gsenc.cfs.bsl.common.service.CmNTxService;
import com.gsenc.cfs.common.model.GsrsMap;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CmNTxServiceImpl implements CmNTxService {

    private final CmNTxRepository cmNTxRepository;

    @Override
    public List<GsrsMap> getFaty500(Map<String, Object> paramMap)  {//UserSessionVO userSession = SessionScopeUtil.getContextSession();

        List<GsrsMap> result = null;
        Map<String, Object> params = new HashMap<>();
        params.put("class", paramMap.get("class"));
        params.put("o_rc", null);  // OUT 파라미터 반드시 포함
        try {
            cmNTxRepository.getFaty500(params);
            result = (List<GsrsMap>)params.get("o_rc");

        } catch (Exception e) {
            System.err.println("gefaty500 오류: " + e.getMessage());
            e.printStackTrace();
        }
        return result;
        //commonDAO.selectList(_COMMON_NAMESPACE + "gefaty500", paramMap);
        //return (List<GsrsMap>) paramMap.get("list");
    }
}
