package com.gsenc.cfs.bsl.common.service;

import java.util.List;
import java.util.Map;

import com.gsenc.cfs.common.model.GsrsMap;

public interface CmNTxService {

    List<GsrsMap> getFaty500(Map<String, Object> paramMap);

}
