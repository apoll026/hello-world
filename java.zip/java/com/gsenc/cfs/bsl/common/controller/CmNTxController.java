
package com.gsenc.cfs.bsl.common.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.cfs.bsl.common.service.CmNTxService;
import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "common")
@Validated
@RequestMapping("/api")
public class CmNTxController {

    private final CmNTxService CmNTxService;

    @Operation(summary = "UASI.DB.BSL.Common.CmNTx.Get_FATY500 - FATY500 코드 드롭다운리스트 조회 (PKG_BASE) ")
    @PostMapping(value = "/bsl/common/CmNTx/getFaty500", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponseVO<List<GsrsMap>>> getFaty500(@RequestBody Map<String, Object> input) {
        return new ResponseEntity<>(CommonResponseVO.<List<GsrsMap>>builder()
                .successOrNot(CommonConstants.YES_FLAG)
                .statusCode(StatusCodeConstants.SUCCESS)
                .data(CmNTxService.getFaty500(input))
                .build(), HttpStatus.OK);
    }

}
