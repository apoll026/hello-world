package com.gsenc.cfs.sample.repository;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.cfs.sample.model.ExcelSampleVO;

@Mapper
public interface ExcelRepository {
    //temp query
    List<ExcelSampleVO> selectExcelSamples();

    Map<String, Object> findLargeExcelAnyRow();

    List<Map<String, Object>> fetchLargeExcelBatch(@Param("offset") int offset, @Param("limit") int limit);
}
