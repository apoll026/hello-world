package com.gsenc.cfs.sample.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.gsenc.cfs.sample.model.GridManageVO.GridManageConditionVo;
import com.gsenc.cfs.sample.model.GridManageVO.GridManageRequestVo;
import com.gsenc.cfs.sample.model.GridManageVO.GridManageResponseVo;
import com.gsenc.wsf.session.model.UserSessionVO;

@Mapper
public interface GridManageRepository {
	List<GridManageResponseVo> selectList(@Param("condition") GridManageConditionVo gridManageConditionVo);

	int selectListTotalCount(@Param("condition") GridManageConditionVo gridManageConditionVo);

	int deleteData(@Param("savaData") List<GridManageRequestVo> gridManageRequestVos,
		@Param("session") UserSessionVO UserSessionVO);

	int updateData(@Param("savaData") List<GridManageRequestVo> gridManageRequestVos,
		@Param("session") UserSessionVO UserSessionVO);

	int insertData(@Param("savaData") List<GridManageRequestVo> gridManageRequestVos,
		@Param("session") UserSessionVO UserSessionVO);

}
