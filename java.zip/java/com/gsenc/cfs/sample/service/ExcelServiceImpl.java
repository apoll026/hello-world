package com.gsenc.cfs.sample.service;

import static com.gsenc.wsf.common.util.ExcelUtil.getListData;

import java.io.IOException;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.gsenc.cfs.constants.ExcelConstants;
import com.gsenc.cfs.sample.model.ExcelConversionVO;
import com.gsenc.cfs.sample.model.ExcelSampleVO;
import com.gsenc.cfs.sample.repository.ExcelRepository;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.exception.BusinessException;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class ExcelServiceImpl implements ExcelService {

    private final ExcelRepository excelSampleRepository;

    private final JdbcTemplate jdbcTemplate;



    @Override
    @Transactional(readOnly = true)
    //Sample Query
    public List<ExcelSampleVO> findExcelSample() {
        return excelSampleRepository.selectExcelSamples();
    }

    @Override
    public List<ExcelSampleVO> uploadExcel(MultipartFile file){
        List<ExcelSampleVO> excelSampleVOList = new ArrayList<ExcelSampleVO>();
        Workbook workbook = null;
        try {
            // file이 없을 경우 예외 처리
            if (file == null || file.isEmpty()) {
                log.info("No file");
                throw new BusinessException("No file", StatusCodeConstants.FAIL);
            }

            // file의 타입이 xlsx가 아닐 경우 예외 처리
            String contentType = file.getContentType();
            if (!ExcelConstants.XLSX.equals(contentType)) {
                log.info("Not Excel File");
                throw new BusinessException("Not Excel File", StatusCodeConstants.FAIL);
            }

            InputStream inputStream = file.getInputStream();
            workbook = WorkbookFactory.create(inputStream);
            int columnCount = workbook.getSheetAt(0).getRow(0).getLastCellNum();
            List<Map<String, Object>> listMap = getListData(file, 1, columnCount);

            for(Map<String, Object> map : listMap){
                ExcelSampleVO excelSampleInfo = new ExcelSampleVO();
                excelSampleInfo.setCmnGrCd(map.get("0").toString());
                excelSampleInfo.setCmnCd(map.get("1").toString());
                excelSampleInfo.setCmnCdNm(map.get("2").toString());
                excelSampleVOList.add(excelSampleInfo);
            }

//            // TODO : DB 저장
//            for(CommonCodeResponseVO commconCodeInfo : commonCodeVOList){
//                // 구현
//            }
        } catch (IOException e) {
            throw new BusinessException("IOException Occurred", StatusCodeConstants.FAIL,e);
        } catch (NullPointerException e) {
            log.error(e.getMessage(),e);
            throw new NullPointerException();
        }finally {
            if (workbook != null) {
                try {
                    workbook.close();
                } catch (IOException e) {
                    log.error(e.getMessage(),e);
                }
            }
        }

        return excelSampleVOList;
    }

    // TODO: Util로 이동
    @Override
    public Workbook excelDownload(ExcelConversionVO excelConversion) {
        try{
            // create Excel file
            Workbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet(excelConversion.getSheetName());

            // header style
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerFont.setColor(IndexedColors.BLACK.index);

            CellStyle headerCellStyle = workbook.createCellStyle();
            headerCellStyle.setFont(headerFont);
            headerCellStyle.setFillForegroundColor(HSSFColorPredefined.GREY_25_PERCENT.getIndex());
            headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            //create Header
            Row headerRow = sheet.createRow(0);
            int colIndex = 0;
            for (String header : excelConversion.getHeader()) {
                Cell headerCell = headerRow.createCell((colIndex++));
                headerCell.setCellStyle(headerCellStyle);
                headerCell.setCellValue(header);
            }

            // create Data row
            int rowNum = 1;
            for (List<String> rows : excelConversion.getData()) {
                Row row = sheet.createRow(rowNum++);
                int dataColumnIndex = 0;
                for (String cellvalue : rows) {
                    row.createCell(dataColumnIndex++).setCellValue(cellvalue);
                }
            }

            return workbook;
        }catch(Exception e){
            throw new BusinessException("Create Excel Fail", StatusCodeConstants.FAIL,e);
        }
    }

    @Override
    public Map<String, Object> findLargeExcelAnyRow() {
        return excelSampleRepository.findLargeExcelAnyRow();
    }

    @Override
    public List<Map<String, Object>> fetchLargeExcelBatch(int offset, int limit) {
        return excelSampleRepository.fetchLargeExcelBatch(offset, limit);
    }

    public List<Map<String, Object>> fetchLargeExcelRange(int start, int end) {
        String sql = "SELECT * FROM tb_large_data WHERE c0 >= ? AND c0 <= ?";

        return jdbcTemplate.query(
                con -> {
                    PreparedStatement ps = con.prepareStatement(sql, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
                    ps.setFetchSize(500); // streaming
                    ps.setInt(1, start);
                    ps.setInt(2, end);
                    return ps;
                },
                (ResultSetExtractor<List<Map<String, Object>>>) rs -> {
                    List<Map<String, Object>> results = new ArrayList<>();
                    ResultSetMetaData meta = rs.getMetaData();
                    int columnCount = meta.getColumnCount();

                    while (rs.next()) {
                        Map<String, Object> row = new LinkedHashMap<>();
                        for (int i = 1; i <= columnCount; i++) {
                            row.put(meta.getColumnLabel(i), rs.getObject(i));
                        }
                        results.add(row);
                    }

                    return results;
                }
        );
    }

}
