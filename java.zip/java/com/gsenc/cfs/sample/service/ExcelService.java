package com.gsenc.cfs.sample.service;

import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.multipart.MultipartFile;

import com.gsenc.cfs.sample.model.ExcelConversionVO;
import com.gsenc.cfs.sample.model.ExcelSampleVO;

public interface ExcelService {
    List<ExcelSampleVO> findExcelSample();
    List<ExcelSampleVO> uploadExcel(MultipartFile file);
    Workbook excelDownload(ExcelConversionVO excelConversion);
    Map<String, Object> findLargeExcelAnyRow();
    List<Map<String, Object>> fetchLargeExcelBatch(int offset, int limit);

    List<Map<String, Object>> fetchLargeExcelRange(int start, int end);
}
