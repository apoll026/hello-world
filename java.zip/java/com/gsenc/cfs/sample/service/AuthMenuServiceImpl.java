package com.gsenc.cfs.sample.service;

import java.util.Objects;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gsenc.cfs.sample.model.AuthMenuRequestVO;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.role.repository.RoleMenuRepository;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class AuthMenuServiceImpl implements AuthMenuService {

	private final RoleMenuRepository roleMenuRepository;
	UserSessionVO session = SessionScopeUtil.getContextSession();
	@Override
	public int upsertSampleMenuAuth(AuthMenuRequestVO authMenuRequestVO) {
		try{
			if(Objects.equals(authMenuRequestVO.getPgmAuth(), "4")){
				roleMenuRepository.deleteMenuAuth(authMenuRequestVO.getAuth(), authMenuRequestVO.getPgmId(), session);
			}else{
				roleMenuRepository.upsertMenuAuth(authMenuRequestVO.getAuth(),authMenuRequestVO.getPgmAuth(),authMenuRequestVO.getPgmId(), session);
			}
			return 1;
		}catch (Exception e) {
			e.printStackTrace();
			return 0;
		}

	}
}
