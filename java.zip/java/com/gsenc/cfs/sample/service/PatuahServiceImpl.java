package com.gsenc.cfs.sample.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ebestech.btss.BVat;
import com.gsenc.cfs.sample.model.PatuahRequestVO;
import com.gsenc.cfs.sample.model.PatuahResponseVO;
import com.gsenc.wsf.common.util.PatuahUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class PatuahServiceImpl implements PatuahService {

	private final PatuahUtil patuahUtil;

	@Override
	public PatuahResponseVO getCorpInfo(PatuahRequestVO patuahRequestVO) {

		PatuahResponseVO response = null;
		try {
			BVat vat = patuahUtil.getCompumTax(patuahRequestVO.getReqCorpNum());
			response = PatuahResponseVO.builder()
				.seq(vat.getSeq())
				.corpNum(vat.getCorpNum())
				.vatKind(vat.getVatKind())
				.closeDate(vat.getCloseDate())
				.build();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return response;
	}
}
