package com.gsenc.cfs.sample.service.GridManage;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gsenc.cfs.sample.model.GridManageVO.GridManageConditionVo;
import com.gsenc.cfs.sample.model.GridManageVO.GridManageRequestVo;
import com.gsenc.cfs.sample.model.GridManageVO.GridManageResponseVo;
import com.gsenc.cfs.sample.repository.GridManageRepository;
import com.gsenc.wsf.common.constant.CrudConstants;
import com.gsenc.wsf.common.exception.BusinessException;
import com.gsenc.wsf.common.model.DmlResponseVO;
import com.gsenc.wsf.common.model.PaginationResponseVO;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class GridManageServiceImpl implements GridManageService {

	private final GridManageRepository gridManageRepository;

	@Override
	public PaginationResponseVO<GridManageResponseVo> selectList(GridManageConditionVo gridManageConditionVo) {
		return PaginationResponseVO.<GridManageResponseVo>builder()
			.totalCount(gridManageRepository.selectListTotalCount(gridManageConditionVo))
			.list(gridManageRepository.selectList(gridManageConditionVo))
			.build();
	}

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public DmlResponseVO saveGridManageData(List<GridManageRequestVo> saveData) {
		UserSessionVO session = SessionScopeUtil.getContextSession();
		DmlResponseVO dmlResponseVO = new DmlResponseVO();

		List<GridManageRequestVo> insertDataList = new ArrayList<>();
		List<GridManageRequestVo> updateDataList = new ArrayList<>();
		List<GridManageRequestVo> deleteDataList = new ArrayList<>();

		for (GridManageRequestVo data : saveData) {
			switch (data.getSState()) {
				case CrudConstants.CREATE:
					insertDataList.add(data);
					break;
				case CrudConstants.UPDATE:
					updateDataList.add(data);
					break;
				case CrudConstants.DELETE:
					deleteDataList.add(data);
					break;
			}
		}
		dmlResponseVO.setDeletedRows(
			deleteDataList.isEmpty() ? 0 : gridManageRepository.deleteData(deleteDataList, session));
		dmlResponseVO.setUpdatedRows(
			updateDataList.isEmpty() ? 0 : gridManageRepository.updateData(updateDataList, session));
		dmlResponseVO.setInsertedRows(
			insertDataList.isEmpty() ? 0 : gridManageRepository.insertData(insertDataList, session));

		if (dmlResponseVO.getDeletedRows() + dmlResponseVO.getInsertedRows() + dmlResponseVO.getUpdatedRows() == 0) {
			throw new BusinessException("Fail");
		}

		return dmlResponseVO;
	}

}
