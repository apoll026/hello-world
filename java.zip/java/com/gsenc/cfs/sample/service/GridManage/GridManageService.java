package com.gsenc.cfs.sample.service.GridManage;

import java.util.List;

import com.gsenc.cfs.sample.model.GridManageVO.GridManageConditionVo;
import com.gsenc.cfs.sample.model.GridManageVO.GridManageRequestVo;
import com.gsenc.cfs.sample.model.GridManageVO.GridManageResponseVo;
import com.gsenc.wsf.common.model.DmlResponseVO;
import com.gsenc.wsf.common.model.PaginationResponseVO;

public interface GridManageService {

	PaginationResponseVO<GridManageResponseVo> selectList(GridManageConditionVo ibSheetSampleConditionVo);

	DmlResponseVO saveGridManageData(List<GridManageRequestVo> saveData);

}
