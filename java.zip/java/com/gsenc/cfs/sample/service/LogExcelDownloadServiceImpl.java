package com.gsenc.cfs.sample.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Service;

import com.gsenc.cfs.constants.ExcelConstants;
import com.gsenc.cfs.sample.model.ExcelConversionVO;
import com.gsenc.cfs.sample.model.ExcelRequestVO;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.log.model.BatchLogVO;
import com.gsenc.wsf.log.model.EmailLogRequestVO;
import com.gsenc.wsf.log.model.EmailLogResponseVO;
import com.gsenc.wsf.log.model.IfLogRequestVO;
import com.gsenc.wsf.log.model.IfLogResponseVO;
import com.gsenc.wsf.log.model.LoginLogRequestVO;
import com.gsenc.wsf.log.model.LoginLogResponseVO;
import com.gsenc.wsf.log.model.MenuLogRequestVO;
import com.gsenc.wsf.log.model.MenuLogResponseVO;
import com.gsenc.wsf.log.repository.BatchLogRepository;
import com.gsenc.wsf.log.repository.EmailLogRepository;
import com.gsenc.wsf.log.repository.IfLogRepository;
import com.gsenc.wsf.log.repository.LoginLogRepository;
import com.gsenc.wsf.log.repository.MenuLogRepository;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class LogExcelDownloadServiceImpl implements LogExcelDownloadService {

	private final LoginLogRepository loginLogRepository;
	private final EmailLogRepository emailLogRepository;
	private final MenuLogRepository menuLogRepository;
	private final IfLogRepository ifLogRepository;
	private final BatchLogRepository batchLogRepository;
	private final ExcelService excelService; // TODO: UTIL로 변경하면 해당 클래스는 wsf-core로 이동

	@Override
	public void downloadLogInLogListExcel(ExcelRequestVO<LoginLogRequestVO> condition,
		HttpServletResponse response) throws IOException {
		List<LoginLogResponseVO> data = loginLogRepository.selectLoginLogList(condition.getSearchCondition(),
			SessionScopeUtil.getContextSession());

		List<List<String>> excelData = new ArrayList<>();
		for (LoginLogResponseVO row : data) {
			List<String> rowData = new ArrayList<>();
			rowData.add(row.getContDtm());    //로그인 일시
			rowData.add(row.getContUserId());  //로그인 사용자 id
			rowData.add(row.getEmpNm());      //로그인 사용자 명
			rowData.add(row.getDeptNm());      //로그인 사용자 부서명
			rowData.add(row.getContIp());     //로그인 IP
			excelData.add(rowData);
		}

		ExcelConversionVO excelConversion = ExcelConversionVO.builder()
			.fileName(condition.getFileName())
			.sheetName(condition.getSheetName())
			.header(condition.getHeader())
			.data(excelData)
			.build();

		ServletOutputStream outStream = null;
		Workbook workbook = null;

		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();

		try {
			workbook = excelService.excelDownload(excelConversion);

			//열 너비 자동 조정
			int a = excelData.get(0).size();
			for (int i = 0; i < excelData.get(0).size(); i++) {
				workbook.getSheet(condition.getSheetName()).autoSizeColumn(i);
			}
			//사용자명 너비 autoSize 적용이 안되어 수동 조정
			workbook.getSheet(condition.getSheetName()).setColumnWidth(3, 3000);

			workbook.write(outByteStream);
			byte[] outArray = outByteStream.toByteArray();

			response.setCharacterEncoding("UTF-8");
			response.setContentType(ExcelConstants.XLSX);
			response.setHeader("Content-Disposition",
				"attachment; filename=\"" + URLEncoder.encode(excelConversion.getFileName(), "UTF-8") + ".xlsx\"");

			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();

		} catch (IOException ex) {
			log.error("Failed to create report file " + excelConversion.getFileName(), ex);
		} catch (Exception ex) {
			log.error("Error while generating report file " + excelConversion.getFileName(), ex);
		} finally {
			if (outStream != null) {
				outStream.close();
			}
			if (workbook != null) {
				workbook.close();
			}
			if (outByteStream != null) {
				outByteStream.close();
			}
		}
	}

	@Override
	public void downloadEmailLogListExcel(ExcelRequestVO<EmailLogRequestVO> condition,
		HttpServletResponse response) throws IOException {
		List<EmailLogResponseVO> data = emailLogRepository.selectEmailLogList(condition.getSearchCondition(),
			SessionScopeUtil.getContextSession());

		List<List<String>> excelData = new ArrayList<>();
		for (EmailLogResponseVO row : data) {
			List<String> rowData = new ArrayList<>();
			rowData.add(row.getEmlTrnmStatCd());                    // 발송 상태
			rowData.add(row.getSedDtm());                           // 발송 일시
			rowData.add(row.getEmlRcvrLstCtn());                    // 수신자이메일
			rowData.add(row.getEmlBdyCtn());                    // 발송 내용
			excelData.add(rowData);
		}

		ExcelConversionVO excelConversion = ExcelConversionVO.builder()
			.fileName(condition.getFileName())
			.sheetName(condition.getSheetName())
			.header(condition.getHeader())
			.data(excelData)
			.build();

		ServletOutputStream outStream = null;
		Workbook workbook = null;

		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();

		try {
			workbook = excelService.excelDownload(excelConversion);

			//열 너비 자동 조정
			int a = excelData.get(0).size();
			for (int i = 0; i < excelData.get(0).size(); i++) {
				workbook.getSheet(condition.getSheetName()).autoSizeColumn(i);
			}
			// 발송내용 너비 autoSize 적용이 안되어 수동 조정
			workbook.getSheet(condition.getSheetName()).setColumnWidth(3, 6000);

			workbook.write(outByteStream);
			byte[] outArray = outByteStream.toByteArray();

			response.setCharacterEncoding("UTF-8");
			response.setContentType(ExcelConstants.XLSX);
			response.setHeader("Content-Disposition",
				"attachment; filename=\"" + URLEncoder.encode(excelConversion.getFileName(), "UTF-8") + ".xlsx\"");

			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();

		} catch (IOException ex) {
			log.error("Failed to create report file " + excelConversion.getFileName(), ex);
		} catch (Exception ex) {
			log.error("Error while generating report file " + excelConversion.getFileName(), ex);
		} finally {
			if (outStream != null) {
				outStream.close();
			}
			if (workbook != null) {
				workbook.close();
			}
			if (outByteStream != null) {
				outByteStream.close();
			}
		}
	}

	@Override
	public void downloadMenuAccessLogListExcel(ExcelRequestVO<MenuLogRequestVO> condition,
		HttpServletResponse response) throws IOException {
		List<MenuLogResponseVO> data = menuLogRepository.selectMenuLogList(condition.getSearchCondition(),
			SessionScopeUtil.getContextSession());

		List<List<String>> excelData = new ArrayList<>();
		for (MenuLogResponseVO row : data) {
			List<String> rowData = new ArrayList<>();
			rowData.add(row.getContDtm());    //접근 일시
			rowData.add(row.getPgmName());      //접근 메뉴면
			rowData.add(row.getContUserId()); //사용자id
			rowData.add(row.getEmpNm());      //사용자 명
			rowData.add(row.getContIp());     //IP
			excelData.add(rowData);
		}

		ExcelConversionVO excelConversion = ExcelConversionVO.builder()
			.fileName(condition.getFileName())
			.sheetName(condition.getSheetName())
			.header(condition.getHeader())
			.data(excelData)
			.build();

		ServletOutputStream outStream = null;
		Workbook workbook = null;

		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();

		try {
			workbook = excelService.excelDownload(excelConversion);

			//열 너비 자동 조정
			int a = excelData.get(0).size();
			for (int i = 0; i < excelData.get(0).size(); i++) {
				workbook.getSheet(condition.getSheetName()).autoSizeColumn(i);
			}
			//사용자명 너비 autoSize 적용이 안되어 수동 조정
			workbook.getSheet(condition.getSheetName()).setColumnWidth(3, 3000);

			workbook.write(outByteStream);
			byte[] outArray = outByteStream.toByteArray();

			response.setCharacterEncoding("UTF-8");
			response.setContentType(ExcelConstants.XLSX);
			response.setHeader("Content-Disposition",
				"attachment; filename=\"" + URLEncoder.encode(excelConversion.getFileName(), "UTF-8") + ".xlsx\"");

			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();

		} catch (IOException ex) {
			log.error("Failed to create report file " + excelConversion.getFileName(), ex);
		} catch (Exception ex) {
			log.error("Error while generating report file " + excelConversion.getFileName(), ex);
		} finally {
			if (outStream != null) {
				outStream.close();
			}
			if (workbook != null) {
				workbook.close();
			}
			if (outByteStream != null) {
				outByteStream.close();
			}
		}
	}

	@Override
	public void downloadIFLogListExcel(ExcelRequestVO<IfLogRequestVO> condition, HttpServletResponse response) throws
		IOException {
		List<IfLogResponseVO> data = ifLogRepository.selectIfLogList(condition.getSearchCondition());

		List<List<String>> excelData = new ArrayList<>();
		for (IfLogResponseVO row : data) {
			List<String> rowData = new ArrayList<>();
			rowData.add("E".equals(row.getOptValNm1()) ? "실패" : "성공");        //결과
			rowData.add(row.getIfLogDtm());         //발생 일시
			rowData.add("CLIENT".equals(row.getIfDivsCd()) ? "CLIENT" : "SERVICE");         //송/수신구분
			rowData.add(row.getIfNm());             //IF명
			rowData.add(row.getIfTrmtValCtn());     //IF송신내용
			rowData.add(row.getIfRestValCtn());     //IF수신내용
			rowData.add(row.getOptValNm1());        //부가정보1
			rowData.add(row.getOptValNm2());        //부가정보2
			rowData.add(row.getOptValNm3());        //부가정보3
			rowData.add(row.getOptValNm4());        //부가정보4
			rowData.add(row.getOptValNm5());        //부가정보5
			excelData.add(rowData);
		}

		ExcelConversionVO excelConversion = ExcelConversionVO.builder()
			.fileName(condition.getFileName())
			.sheetName(condition.getSheetName())
			.header(condition.getHeader())
			.data(excelData)
			.build();

		ServletOutputStream outStream = null;
		Workbook workbook = null;

		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();

		try {
			workbook = excelService.excelDownload(excelConversion);

			//열 너비 자동 조정
			int a = excelData.get(0).size();
			for (int i = 0; i < excelData.get(0).size(); i++) {
				workbook.getSheet(condition.getSheetName()).autoSizeColumn(i);
			}
			//사용자명 너비 autoSize 적용이 안되어 수동 조정
			workbook.getSheet(condition.getSheetName()).setColumnWidth(3, 3000);

			workbook.write(outByteStream);
			byte[] outArray = outByteStream.toByteArray();

			response.setCharacterEncoding("UTF-8");
			response.setContentType(ExcelConstants.XLSX);
			response.setHeader("Content-Disposition",
				"attachment; filename=\"" + URLEncoder.encode(excelConversion.getFileName(), "UTF-8") + ".xlsx\"");

			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();

		} catch (IOException ex) {
			log.error("Failed to create report file " + excelConversion.getFileName(), ex);
		} catch (Exception ex) {
			log.error("Error while generating report file " + excelConversion.getFileName(), ex);
		} finally {
			if (outStream != null) {
				outStream.close();
			}
			if (workbook != null) {
				workbook.close();
			}
			if (outByteStream != null) {
				outByteStream.close();
			}
		}
	}

	@Override
	public void downloadBatchLogListExcel(ExcelRequestVO<BatchLogVO> condition, HttpServletResponse response) throws
		IOException {
		List<BatchLogVO> data = batchLogRepository.selectBatchLogList(condition.getSearchCondition());

		List<List<String>> excelData = new ArrayList<>();
		for (BatchLogVO row : data) {
			List<String> rowData = new ArrayList<>();
			rowData.add(row.getBtchLogDtm());
			rowData.add(row.getBtchClsNm());
			rowData.add(row.getBtchMthdNm());
			rowData.add(row.getBtchCrn());
			rowData.add(row.getBtchRslt());
			excelData.add(rowData);
		}

		ExcelConversionVO excelConversion = ExcelConversionVO.builder()
			.fileName(condition.getFileName())
			.sheetName(condition.getSheetName())
			.header(condition.getHeader())
			.data(excelData)
			.build();

		ServletOutputStream outStream = null;
		Workbook workbook = null;

		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();

		try {
			workbook = excelService.excelDownload(excelConversion);

			//열 너비 자동 조정
			int a = excelData.get(0).size();
			for (int i = 0; i < excelData.get(0).size(); i++) {
				workbook.getSheet(condition.getSheetName()).autoSizeColumn(i);
			}
			//사용자명 너비 autoSize 적용이 안되어 수동 조정
			workbook.getSheet(condition.getSheetName()).setColumnWidth(3, 3000);

			workbook.write(outByteStream);
			byte[] outArray = outByteStream.toByteArray();

			response.setCharacterEncoding("UTF-8");
			response.setContentType(ExcelConstants.XLSX);
			response.setHeader("Content-Disposition",
				"attachment; filename=\"" + URLEncoder.encode(excelConversion.getFileName(), "UTF-8") + ".xlsx\"");

			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();

		} catch (IOException ex) {
			log.error("Failed to create report file " + excelConversion.getFileName(), ex);
		} catch (Exception ex) {
			log.error("Error while generating report file " + excelConversion.getFileName(), ex);
		} finally {
			if (outStream != null) {
				outStream.close();
			}
			if (workbook != null) {
				workbook.close();
			}
			if (outByteStream != null) {
				outByteStream.close();
			}
		}
	}
}
