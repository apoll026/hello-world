package com.gsenc.cfs.sample.service;

import com.gsenc.cfs.sample.model.PatuahRequestVO;
import com.gsenc.cfs.sample.model.PatuahResponseVO;

public interface PatuahService {
	PatuahResponseVO getCorpInfo(PatuahRequestVO patuahRequestVO);
}
