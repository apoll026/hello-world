package com.gsenc.cfs.sample.service;

import com.gsenc.cfs.sample.model.AuthMenuRequestVO;

public interface AuthMenuService {
	int upsertSampleMenuAuth(AuthMenuRequestVO authMenuRequestVO);
}
