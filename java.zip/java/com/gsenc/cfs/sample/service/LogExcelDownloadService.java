package com.gsenc.cfs.sample.service;

import java.io.IOException;

import com.gsenc.cfs.sample.model.ExcelRequestVO;
import com.gsenc.wsf.log.model.BatchLogVO;
import com.gsenc.wsf.log.model.EmailLogRequestVO;
import com.gsenc.wsf.log.model.IfLogRequestVO;
import com.gsenc.wsf.log.model.LoginLogRequestVO;
import com.gsenc.wsf.log.model.MenuLogRequestVO;

import jakarta.servlet.http.HttpServletResponse;

public interface LogExcelDownloadService {
	void downloadLogInLogListExcel(ExcelRequestVO<LoginLogRequestVO> condition, HttpServletResponse response) throws
		IOException;

	void downloadEmailLogListExcel(ExcelRequestVO<EmailLogRequestVO> condition, HttpServletResponse response) throws
		IOException;

	void downloadMenuAccessLogListExcel(ExcelRequestVO<MenuLogRequestVO> condition, HttpServletResponse response) throws
		IOException;

	void downloadIFLogListExcel(ExcelRequestVO<IfLogRequestVO> condition, HttpServletResponse response) throws
		IOException;

	void downloadBatchLogListExcel(ExcelRequestVO<BatchLogVO> condition, HttpServletResponse response) throws
		IOException;
}
