package com.gsenc.cfs.sample.controller;

import static com.gsenc.wsf.common.snmip.SNMIPSample.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.UUID;

import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.gsenc.cfs.constants.ExcelConstants;
import com.gsenc.cfs.sample.model.ExcelConversionVO;
import com.gsenc.cfs.sample.model.ExcelSampleVO;
import com.gsenc.cfs.sample.service.ExcelService;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.GsActTypeConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;
import com.gsenc.wsf.log.service.LogService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequiredArgsConstructor
@Tag(name = "Excel")
@Validated
@RequestMapping("/api")
public class ExcelController {

	private final ExcelService excelService;
	private final LogService logService;

	@Value("${aip.upload-path}")
	private String aipUploadPath;

	@GetMapping(value = "/v1/excel/download")
	@Operation(summary = "엑셀 다운로드", description = "엑셀 다운로드")
	public void downloadExcel(HttpServletResponse response, HttpServletRequest request) throws IOException {

		logService.callGsApAccessLog(request, GsActTypeConstants.EX); // 공통 로그 생성

		List<ExcelSampleVO> dataList = excelService.findExcelSample();

		File downloadFile = null;

		// POI 엑셀 파일 생성
		Workbook workbook = null;
		try {
			workbook = new XSSFWorkbook();
			Sheet sheet = workbook.createSheet("Data");

			// header style
			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.BLACK.getIndex());

			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);
			headerCellStyle.setFillForegroundColor(HSSFColorPredefined.GREY_25_PERCENT.getIndex());
			//        headerCellStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);

			//create Header
			Row headerRow = sheet.createRow(0);
			headerRow.createCell(0).setCellValue("Column1");
			headerRow.createCell(1).setCellValue("Column2");
			headerRow.createCell(2).setCellValue("Column3");

			for (int i = 0; i < 3; i++) {
				headerRow.getCell(i).setCellStyle(headerCellStyle);
			}

			// create data
			CreationHelper createHelper = workbook.getCreationHelper();
			CellStyle dateCellStyle = workbook.createCellStyle();
			dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("yyyy-MM-dd"));

			int rowNum = 1;

			for (ExcelSampleVO data : dataList) {
				Row row = sheet.createRow(rowNum++);
				row.createCell(0).setCellValue(data.getCmnGrCd());
				row.createCell(1).setCellValue(data.getCmnCd());
				row.createCell(2).setCellValue(data.getCmnCdNm());
			}

			// 암호화 (민감도 레이블 적용, DRM)
			String subPath = "/download";
			String fileName = UUID.randomUUID().toString() + ".xlsx";
			String filePath = aipUploadPath + subPath + "/" + fileName;

			// 파일 저장
			try (FileOutputStream fos = new FileOutputStream(filePath)) {
				workbook.write(fos);
				workbook.close();
			}
			// 민감도 레이블 적용
			Sample_SetSensitivityLabel(subPath, fileName, "bf6d8c37-5bcf-4bc2-b06b-a6032f19e2a3");

			// 민감도 레이블 API에서 OK 후에도 민감도 레이블 적용 진행중
			// 파일 사이즈가 변경될때까지 확인
			long fileSize = Files.size(Path.of(filePath));
			long newFileSize = fileSize;

			int sec = 0;
			while (fileSize == newFileSize && sec < 30) {
				newFileSize = Files.size(Path.of(filePath));
				Thread.sleep(1000);
				// 최대 30초 까지만 시도 후 Exception 발생
				sec++;
			}

			// 파일의 크기가 변하지 않은 경우 예외 처리
			if (fileSize == newFileSize) {
				throw new IOException("민감도 레이블이 적용되지 않았습니다");
			}

			// 파일 다운로드
			downloadFile = new File(filePath);
			response.setContentType("application/octet-stream");
			response.setHeader("Content-Disposition",
				"attachment; filename=\"" + URLEncoder.encode(downloadFile.getName(), "UTF-8") + "\";");
			response.setContentLengthLong(downloadFile.length());

			try (InputStream is = new FileInputStream(downloadFile)) {
				is.transferTo(response.getOutputStream());
				response.getOutputStream().flush();
			}

		} catch (IOException e) {
			log.error(e.getMessage(), e);
			throw e;
		} catch (InterruptedException e) {
			throw new RuntimeException(e);
		} finally {
			try {
				workbook.close();
				// 다운로드 완료 후 파일 삭제
				downloadFile.delete();
			} catch (IOException e) {
				log.error(e.getMessage(), e);
			}
		}
	}

	@PostMapping(value = "/v1/excel/convert")
	@Operation(summary = "엑셀 변환", description = "엑셀 변환")
	public void convertToExcel(@RequestBody ExcelConversionVO excelConversion, HttpServletResponse response) throws
		IOException {

		// create Excel File and Sheet
		Workbook workbook = null;

		try {
			workbook = new XSSFWorkbook();
			Sheet sheet = workbook.createSheet(excelConversion.getSheetName());

			// create Header row
			List<String> headers = excelConversion.getHeader();
			Row headerRow = sheet.createRow(0);

			int headerColumnIndex = 0;
			for (String header : headers) {
				headerRow.createCell(headerColumnIndex).setCellValue(header);
				headerColumnIndex++;
			}
			// create Data row
			int rowNum = 1;
			for (List<String> rows : excelConversion.getData()) {
				Row row = sheet.createRow(rowNum++);
				int dataColumnIndex = 0;
				for (String cellvalue : rows) {
					row.createCell(dataColumnIndex).setCellValue(cellvalue);
					dataColumnIndex++;
				}
			}

			response.setContentType(ExcelConstants.XLSX);
			response.setHeader("Content-Disposition",
				"attachment; filename=\"" + excelConversion.getFileName() + ".xlsx\"");

			// export file
			workbook.write(response.getOutputStream());
		} catch (IOException e) {
			throw e;
		} finally {
			if (workbook != null) {
				try {
					workbook.close();
				} catch (IOException e) {
					log.error(e.getMessage(), e);
				}
			}
		}
	}

	@PostMapping(value = "/v1/excel/upload", produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(summary = "엑셀 업로드", description = "엑셀 업로드")
	public ResponseEntity<CommonResponseVO<List<ExcelSampleVO>>> uploadExcel(@RequestBody MultipartFile file) {

		return new ResponseEntity<>(
			CommonResponseVO.<List<ExcelSampleVO>>builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(excelService.uploadExcel(file))
				.build(),
			HttpStatus.OK);
	}
}
