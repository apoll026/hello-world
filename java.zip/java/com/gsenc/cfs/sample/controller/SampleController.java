package com.gsenc.cfs.sample.controller;

import java.util.Locale;

import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.cfs.sample.model.AuthMenuRequestVO;
import com.gsenc.cfs.sample.model.PatuahRequestVO;
import com.gsenc.cfs.sample.service.AuthMenuService;
import com.gsenc.cfs.sample.service.PatuahService;
import com.gsenc.wsf.annotation.RequiresRoles;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.mail.model.MailRequestVO;
import com.gsenc.wsf.mail.model.MailVO;
import com.gsenc.wsf.mail.service.MailService;
import com.gsenc.wsf.session.model.UserSessionVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequiredArgsConstructor
@Tag(name = "Sample")
@RequestMapping("/api")
public class SampleController {
	private final MailService mailService;
	private final MessageSource messageSource;
	private final PatuahService patuahService;
	private final AuthMenuService authMenuService;

	@Operation(summary = "EmailTest", description = "EmailTest")
	@PostMapping(value = "/v1/emailTest", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO> sendEmail(
		@RequestBody MailRequestVO mailRequest) {
		UserSessionVO userSession = SessionScopeUtil.getContextSession();

		MailVO mailVO = mailService.parseMailRequest(mailRequest);

		return new ResponseEntity<>(
			CommonResponseVO.builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(mailService.sendMail(mailVO))
				.build(),
			HttpStatus.OK);
	}

	@Operation(summary = "EmailTemplate", description = "EmailTemplate")
	@GetMapping(value = "/v1/emailTemplate", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO> findEmailTemplate(
		@Parameter(description = "템플릿유형", example = "test-template") String templateType) {

		return new ResponseEntity<>(
			CommonResponseVO.builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(mailService.makeTemplate(templateType, null))
				.build(),
			HttpStatus.OK);
	}

	@Operation(summary = "MessageTest", description = "MessageTest")
	@GetMapping(value = "/v1/multiLanguageTest", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO> multiLanguageTest() {

		log.debug("Default Locale: " + Locale.getDefault());

		Locale currentLocale = LocaleContextHolder.getLocale();
		log.debug("**************************");
		log.debug(currentLocale.toString());

		/*LocaleContextHolder.getLocale();로 현재 로케일 판단하여 셋팅 해줌 */

		log.debug("currentLocale");
		log.debug(messageSource.getMessage("com.code.COP_CD.회사명", null, currentLocale));

		log.debug("Default");
		log.debug(messageSource.getMessage("com.code.COP_CD.회사명", null, Locale.getDefault()));

		log.debug("폴란드");
		Locale polandLocale = new Locale("pl", "PL");
		log.debug(messageSource.getMessage("com.code.COP_CD.회사명", null, polandLocale));

		log.debug("중국");
		Locale chinaLocale = new Locale("zh", "CN");
		log.debug(messageSource.getMessage("com.code.COP_CD.회사명", null, chinaLocale));

		log.debug("대만");
		Locale taiwanLocale = new Locale("zh", "TW");
		log.debug(messageSource.getMessage("com.code.COP_CD.회사명", null, taiwanLocale));

		log.debug("영어");
		Locale englishLocale = new Locale("en", "US");
		log.debug(messageSource.getMessage("com.code.COP_CD.회사명", null, englishLocale));
		log.debug(englishLocale.toString());

		return new ResponseEntity<>(
			CommonResponseVO.builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(messageSource.getMessage("com.code.COP_CD.회사명", null, taiwanLocale))
				.build(),
			HttpStatus.OK);
	}

	@Operation(summary = "mailBatchTest", description = "mailBatchTest")
	@GetMapping(value = "/v1/mailBatchTest", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO> mailBatchTest() {

		mailService.sendMailBatch();

		return new ResponseEntity<>(
			CommonResponseVO.builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data("")
				.build(),
			HttpStatus.OK);
	}

	@RequiresRoles(value = "샘플화면.reg001", type = "BTN_KEY")
	@Operation(summary = "roleButtonTest", description = "roleButtonTest")
	@PostMapping(value = "/v1/sample/role-button1", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO> roleButtonTest1() {

		return new ResponseEntity<>(
			CommonResponseVO.builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data("")
				.build(),
			HttpStatus.OK);
	}

	@RequiresRoles(value = "샘플화면._reg001_", type = "BTN_KEY")
	@Operation(summary = "roleButtonTest", description = "roleButtonTest")
	@PostMapping(value = "/v1/sample/role-button2", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO> roleButtonTest2() {

		return new ResponseEntity<>(
			CommonResponseVO.builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data("")
				.build(),
			HttpStatus.OK);
	}

	@Operation(summary = "", description = "roleButtonTest")
	@PostMapping(value = "/v1/sample/role-button3", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO> roleButtonTest3() {

		return new ResponseEntity<>(
			CommonResponseVO.builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data("")
				.build(),
			HttpStatus.OK);
	}

	@Operation(summary = "", description = "authMenuSampleTest")
	@PostMapping(value = "/v1/sample/auth-menu", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO> authMenuSampleTest(@RequestBody AuthMenuRequestVO authMenuRequestVO) {

		return new ResponseEntity<>(
			CommonResponseVO.builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(authMenuService.upsertSampleMenuAuth(authMenuRequestVO))
				.build(),
			HttpStatus.OK);
	}

	@Operation(summary = "patuahTest", description = "patuahTest")
	@PostMapping(value = "/v1/sample/patuahTest", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO> patuahTest(@RequestBody PatuahRequestVO patuahRequestVO) {

		return new ResponseEntity<>(
			CommonResponseVO.builder()
				.successOrNot(CommonConstants.YES_FLAG)
				.statusCode(StatusCodeConstants.SUCCESS)
				.data(patuahService.getCorpInfo(patuahRequestVO))
				.build(),
			HttpStatus.OK);
	}

}
