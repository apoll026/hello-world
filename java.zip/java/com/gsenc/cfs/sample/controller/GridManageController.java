package com.gsenc.cfs.sample.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.gsenc.cfs.sample.model.GridManageVO.GridManageConditionVo;
import com.gsenc.cfs.sample.model.GridManageVO.GridManageRequestVo;
import com.gsenc.cfs.sample.model.GridManageVO.GridManageResponseVo;
import com.gsenc.cfs.sample.service.GridManage.GridManageService;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;
import com.gsenc.wsf.common.model.DmlResponseVO;
import com.gsenc.wsf.common.model.PaginationResponseVO;
import com.gsenc.wsf.common.model.ValidList;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Validated
@RequestMapping("/api")
public class GridManageController {

	private final GridManageService gridManageService;

	@GetMapping(value = "/v1/sample/grid-manage", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<PaginationResponseVO<GridManageResponseVo>>> selectList(
		@Valid GridManageConditionVo condition) {
		return new ResponseEntity<>(CommonResponseVO.<PaginationResponseVO<GridManageResponseVo>>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(gridManageService.selectList(condition))
			.build(), HttpStatus.OK);
	}

	@PostMapping(value = "/v1/sample/grid-manage", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponseVO<DmlResponseVO>> saveGridManageData(
		@RequestBody @Valid ValidList<GridManageRequestVo> saveData) {
		return new ResponseEntity<>(CommonResponseVO.<DmlResponseVO>builder()
			.successOrNot(CommonConstants.YES_FLAG)
			.statusCode(StatusCodeConstants.SUCCESS)
			.data(gridManageService.saveGridManageData(saveData))
			.build(), HttpStatus.OK);
	}

}
