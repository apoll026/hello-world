package com.gsenc.cfs.sample.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class PatuahRequestVO {

	@Schema(description = "사업자 번호", example = "1148198234")
	private String reqCorpNum;

}
