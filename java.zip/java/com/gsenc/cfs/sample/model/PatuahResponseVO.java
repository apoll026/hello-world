package com.gsenc.cfs.sample.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class PatuahResponseVO {

	@Schema(description = "일련번호")
	private String seq;
	@Schema(description = "사업자 번호")
	private String corpNum;
	@Schema(description = "사업자 유형")
	private String vatKind;
	@Schema(description = "휴폐업일자")
	private String closeDate;
}
