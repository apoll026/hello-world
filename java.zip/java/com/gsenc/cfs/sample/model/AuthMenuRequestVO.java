package com.gsenc.cfs.sample.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class AuthMenuRequestVO {

	@Schema(description = "권한그룹")
	private String auth;
	@Schema(description = "화면권한레벨")
	private String pgmAuth;
	@Schema(description = "화면ID")
	private String pgmId;
}
