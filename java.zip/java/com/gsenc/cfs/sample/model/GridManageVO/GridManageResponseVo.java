package com.gsenc.cfs.sample.model.GridManageVO;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.*;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class GridManageResponseVo {
	@JsonProperty("sId")
	private String sId;

	@JsonProperty("sColMsgCode")
	private String sColMsgCode;

	@JsonProperty("sColMsgCtnKR")
	private String sColMsgCtnKR;

	@JsonProperty("sColMsgCtnEN")
	private String sColMsgCtnEN;
}
