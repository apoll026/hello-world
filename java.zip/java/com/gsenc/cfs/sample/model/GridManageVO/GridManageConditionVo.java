package com.gsenc.cfs.sample.model.GridManageVO;

import lombok.*;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Data
@Builder
public class GridManageConditionVo {

	//TODO: Refactor the field names to follow Grid Manage naming conventions
	String searchItem;
	Integer sPriceFrom;
	Integer sPriceTo;
}
