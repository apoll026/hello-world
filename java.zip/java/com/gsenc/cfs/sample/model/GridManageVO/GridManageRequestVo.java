package com.gsenc.cfs.sample.model.GridManageVO;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Data
public class GridManageRequestVo extends GridManageResponseVo {
	@JsonProperty("sState")
	private String sState;
}
