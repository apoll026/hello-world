package com.gsenc.cfs.scheduler;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.gsenc.wsf.annotation.WsfScheduled;
import com.gsenc.wsf.mail.service.MailService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Scheduler Component
 *
 * config.yml에 scheduler.cron.[method 명]으로 표현식 생성
 *
 * Local 환경 테스트시 WsfScheduledAspect의 isEnable 수정
 *
 * @author YT
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class SchedulerComponent {

	private final MailService mailService;

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	// Sample
	// @WsfScheduled(cron = "${scheduler.cron.sample}")
	public Map<String, Object> sample() {
		Map<String, Object> result = new HashMap<>();
		try {
			// 배치 로직

			// 성공
			result.put("resultCode", "S");
			result.put("successCount", 20);

		} catch (Exception e) {
			// 실패
			log.error(e.getMessage(), e);
			result.put("resultCode", "F");
		}

		return result;
	}

	@WsfScheduled(cron = "${scheduler.cron.sendMail}")
	public Map<String, Object> sendMail() {
		Map<String, Object> result = new HashMap<>();
		try {
			// 배치 로직
			int successCount = mailService.sendMailBatch();
			// 성공
			result.put("resultCode", "S");
			result.put("successCount", successCount);

		} catch (Exception e) {
			// 실패
			log.error(e.getMessage(), e);
			result.put("resultCode", "F");
		}

		return result;
	}
}
