package com.gsenc.cfs.cf.rm.service.Impl;

import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Marker;
import org.slf4j.MarkerFactory;
import org.springframework.stereotype.Service;

import com.gsenc.cfs.cf.rm.model.CfRm000001RequestVO;
import com.gsenc.cfs.cf.rm.service.CfRm000001Service;
import com.gsenc.cfs.common.dao.CommonDAO;
import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.cfs.common.sap.SAPInterFaceClass;
import com.gsenc.wsf.common.constant.LogConstants;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.common.util.StringUtil;
import com.gsenc.wsf.session.model.UserCompanySessionVO;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class CfRm000001ServiceImpl implements CfRm000001Service {

    private final static String _COMMON_NAMESPACE = "common.EasSap.";
    private final CommonDAO commonDAO;

    Marker marker = MarkerFactory.getMarker(LogConstants.RFC);

    @Override
    public GsrsMap selectZtrChangedVendorAcnt(CfRm000001RequestVO cRm000001RequestVO) {

        SAPInterFaceClass sapInf = new SAPInterFaceClass();
        Map<String, Object> rtnMap = null;
        Map<String, Object> sapLogMap = null;
        GsrsMap resultMap = null;

        try {
            UserCompanySessionVO userSession = SessionScopeUtil.getCompanyContextSession();
            resultMap = new GsrsMap();
            String empNo = "";
            String l_Lifnr = "";

            l_Lifnr = cRm000001RequestVO.getCmpnNum();
            // 개발시 임시 if문
            if ( userSession == null ) {
                empNo = "63684";
            }
            else{
                empNo = userSession.getEmpNo();
                l_Lifnr = userSession.getCmpnNum();
            }

            YearMonth yearMonth = YearMonth.now();
            String yyyyMm = yearMonth.format(DateTimeFormatter.ofPattern("yyyyMM"));


            rtnMap = sapInf.selectZtrChangedVendorAcnt(l_Lifnr, "1");

            // SAP SEVER LOG
            log.info(marker, "[Request ]\n{}", l_Lifnr);
            log.info(marker, "[Response]\n{}", rtnMap);

            resultMap.put("CASH_ACCOUNT", rtnMap.get("IF_MSG").toString());
            resultMap.put("CASH_ACCOUNT_CODE", rtnMap.get("IF_CODE").toString());

            sapLogMap = new HashMap<>();
            sapLogMap.put("divs", "P");         // 구분
            sapLogMap.put("code", StringUtil.isNullToString(l_Lifnr));     // 코드
            sapLogMap.put("flag", StringUtil.isNullToString(rtnMap.get("IF_CODE")));         // I/F 결과
            sapLogMap.put("sapMsg", StringUtil.isNullToString(rtnMap.get("IF_MSG")));     // SAP 메시지
            sapLogMap.put("empNo", empNo);   // 사번
            sapLogMap.put("sapCode", "");  // SAP 코드
            sapLogMap.put("subCode", "");  // SUB 코드
            sapLogMap.put("seq", "0");            // 순번
            sapLogMap.put("yyyyMm", yyyyMm);  // 년월

            //commonDAO.selectList(_COMMON_NAMESPACE + "selectProcSetIfSap", sapLogMap);

            rtnMap = sapInf.selectZtrChangedVendorAcnt(l_Lifnr, "2");

            // SAP SEVER LOG
            log.info(marker, "[Request ]\n{}", cRm000001RequestVO);
            log.info(marker, "[Response]\n{}", rtnMap);

            resultMap.put("BUY_ACCOUNT", rtnMap.get("IF_MSG").toString());
            resultMap.put("BUY_ACCOUNT_CODE", rtnMap.get("IF_CODE").toString());

            sapLogMap = new HashMap<>();
            sapLogMap.put("divs", "P");         // 구분
            sapLogMap.put("code", StringUtil.isNullToString(l_Lifnr));     // 코드
            sapLogMap.put("flag", StringUtil.isNullToString(rtnMap.get("IF_CODE")));         // I/F 결과
            sapLogMap.put("sapMsg", StringUtil.isNullToString(rtnMap.get("IF_MSG")));     // SAP 메시지
            sapLogMap.put("empNo", empNo);   // 사번
            sapLogMap.put("sapCode", "");  // SAP 코드
            sapLogMap.put("subCode", "");  // SUB 코드
            sapLogMap.put("seq", "0");            // 순번
            sapLogMap.put("yyyyMm", yyyyMm);  // 년월

            //commonDAO.selectList(_COMMON_NAMESPACE + "selectProcSetIfSap", sapLogMap);

        } catch (Exception e) {
            // 마커를 사용한 로깅
            log.error(marker, "[Request ]\n{}", cRm000001RequestVO);
            log.error(marker, "[Error   ]", e);
        }
        return resultMap;
    }
}
