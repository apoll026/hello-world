package com.gsenc.cfs.cf.rm.service;

import com.gsenc.cfs.cf.rm.model.CfRm000003RequestVO;
import com.gsenc.cfs.common.model.GsrsMap;

public interface CfRm000003Service {

    GsrsMap selectZtrRtfbSend0400Name2(CfRm000003RequestVO cRm000003RequestVO);

}
