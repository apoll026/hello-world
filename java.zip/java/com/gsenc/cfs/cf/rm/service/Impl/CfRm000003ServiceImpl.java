package com.gsenc.cfs.cf.rm.service.Impl;

import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Marker;
import org.slf4j.MarkerFactory;
import org.springframework.stereotype.Service;

import com.gsenc.cfs.cf.rm.model.CfRm000003RequestVO;
import com.gsenc.cfs.cf.rm.service.CfRm000003Service;
import com.gsenc.cfs.common.dao.CommonDAO;
import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.cfs.common.sap.SAPInterFaceClass;
import com.gsenc.wsf.common.constant.LogConstants;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.common.util.StringUtil;
import com.gsenc.wsf.session.model.UserCompanySessionVO;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class CfRm000003ServiceImpl implements CfRm000003Service {

    private final static String _COMMON_NAMESPACE = "common.EasSap.";
    private final CommonDAO commonDAO;

    Marker marker = MarkerFactory.getMarker(LogConstants.RFC);

    @Override
    public GsrsMap selectZtrRtfbSend0400Name2(CfRm000003RequestVO cRm000003RequestVO) {

        SAPInterFaceClass sapInf = new SAPInterFaceClass();
        Map<String, Object> rtnMap = null;
        Map<String, Object> sapLogMap = null;
        GsrsMap resultMap = null;

        try {
            UserCompanySessionVO userSession = SessionScopeUtil.getCompanyContextSession();
            resultMap = new GsrsMap();
            String empNo = "";
            String To_Acnt_Num = "";
            String To_Bank_Code = "";

            empNo = cRm000003RequestVO.getEmpNo();
            To_Acnt_Num = cRm000003RequestVO.getAcntNum().replace("-", "");
            To_Bank_Code = cRm000003RequestVO.getBankCode();

            YearMonth yearMonth = YearMonth.now();
            String yyyyMm = yearMonth.format(DateTimeFormatter.ofPattern("yyyyMM"));

            rtnMap = sapInf.selectZtrRtfbSend0400440Name2(To_Acnt_Num, To_Bank_Code);

            // SAP SEVER LOG
            log.info(marker, "[Request ]\n{}", cRm000003RequestVO);
            log.info(marker, "[Response]\n{}", rtnMap);

            resultMap.put("E_Name", rtnMap.get("E_Name").toString());
            resultMap.put("E_RETURN_CODE", rtnMap.get("E_RETURN_CODE").toString());
            resultMap.put("E_RETURN_VALUE", rtnMap.get("E_RETURN_VALUE").toString());

            sapLogMap = new HashMap<>();
            sapLogMap.put("divs", "P");         // 구분
            sapLogMap.put("code", StringUtil.isNullToString("E_Name"));     // 코드
            sapLogMap.put("flag", StringUtil.isNullToString(rtnMap.get("E_RETURN_CODE")));         // I/F 결과
            sapLogMap.put("sapMsg", StringUtil.isNullToString(rtnMap.get("E_RETURN_VALUE")));     // SAP 메시지
            sapLogMap.put("empNo", empNo);   // 사번
            sapLogMap.put("sapCode", "");  // SAP 코드
            sapLogMap.put("subCode", "");  // SUB 코드
            sapLogMap.put("seq", "0");            // 순번
            sapLogMap.put("yyyyMm", yyyyMm);  // 년월

            //commonDAO.selectList(_COMMON_NAMESPACE + "selectProcSetIfSap", sapLogMap);

        } catch (Exception e) {
            // 마커를 사용한 로깅
            log.error(marker, "[Request ]\n{}", cRm000003RequestVO);
            log.error(marker, "[Error   ]", e);
        }
        return resultMap;
    }
}
