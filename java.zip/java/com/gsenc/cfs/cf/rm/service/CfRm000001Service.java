package com.gsenc.cfs.cf.rm.service;

import java.util.Map;

import com.gsenc.cfs.cf.rm.model.CfRm000001RequestVO;
import com.gsenc.cfs.common.model.GsrsMap;

public interface CfRm000001Service {

    GsrsMap selectZtrChangedVendorAcnt(CfRm000001RequestVO cRm000001RequestVO);

}
