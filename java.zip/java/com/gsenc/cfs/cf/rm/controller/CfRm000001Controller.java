package com.gsenc.cfs.cf.rm.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.cfs.cf.rm.model.CfRm000001RequestVO;
import com.gsenc.cfs.cf.rm.service.CfRm000001Service;
import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "CfRm000001")
@RequestMapping("/api/cf/rm")
public class CfRm000001Controller {

    private final CfRm000001Service cfRm000001Service;

    @Operation(summary = "등록계좌조회") //Sap_Ztr_Changed_Vendor_Acnt
    @PostMapping(value = "/CfRm000001/selectZtrChangedVendorAcnt", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> selectAccountSearch(@RequestBody CfRm000001RequestVO cRm000001RequestVO) {

        GsrsMap result = cfRm000001Service.selectZtrChangedVendorAcnt(cRm000001RequestVO);

        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(result)
                        .build(),
                HttpStatus.OK);
    }

}
