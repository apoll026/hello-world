package com.gsenc.cfs.cf.rm.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.cfs.cf.rm.model.CfRm000003RequestVO;
import com.gsenc.cfs.cf.rm.service.CfRm000003Service;
import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "CfRm000003")
@RequestMapping("/api/cf/rm")
public class CfRm000003Controller {

    private final CfRm000003Service cfRm000003Service;

    @Operation(summary = "등록계좌조회") //Sap_Ztr_Changed_Vendor_Acnt
    @PostMapping(value = "/CfRm000003/selectZtrRtfbSend0400Name2", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> selectZtrRtfbSend0400Name2(@RequestBody CfRm000003RequestVO cRm000003RequestVO) {

        GsrsMap result = cfRm000003Service.selectZtrRtfbSend0400Name2(cRm000003RequestVO);

        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(result)
                        .build(),
                HttpStatus.OK);
    }

}
