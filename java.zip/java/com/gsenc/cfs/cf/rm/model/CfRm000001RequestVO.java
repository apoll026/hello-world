package com.gsenc.cfs.cf.rm.model;

import lombok.*;
import lombok.extern.slf4j.Slf4j;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Slf4j
public class CfRm000001RequestVO {

	/** 사업자코드 */
	private String cmpnCode;
	/** 사업자번호 */
	private String cmpnNum;
	/** 사용자명 */
	private String empNo;
	/** 사용권한 */
	private String auth;

}
