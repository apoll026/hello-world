package com.gsenc.cfs.cf.rm.model;

import lombok.*;
import lombok.extern.slf4j.Slf4j;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Slf4j
public class CfRm000003RequestVO {

	/** 은행코드 */
	private String bankName;
	/** 은행코드 */
	private String bankCode;
	/** 계좌번호 */
	private String acntNum;
	/** 사용자명 */
	private String empNo;
	/** 사용권한 */
	private String auth;

}
