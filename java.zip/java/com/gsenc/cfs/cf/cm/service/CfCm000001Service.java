package com.gsenc.cfs.cf.cm.service;

import java.util.Map;

import com.gsenc.cfs.cf.cm.model.CfCm000001RequestVO;
import com.gsenc.cfs.common.model.GsrsMap;

public interface CfCm000001Service {

    GsrsMap selectZtrRtfbSend0400(CfCm000001RequestVO cfCm000001RequestVO);

    GsrsMap setPartnerCompanyAccountSave(Map<String, Object> paramMap);

}
