package com.gsenc.cfs.cf.cm.service.Impl;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.*;

import org.slf4j.Marker;
import org.slf4j.MarkerFactory;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gsenc.cfs.cf.cm.model.CfCm000001RequestVO;
import com.gsenc.cfs.cf.cm.service.CfCm000001Service;
import com.gsenc.cfs.common.dao.CommonDAO;
import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.cfs.common.sap.SAPInterFaceClass;
import com.gsenc.wsf.common.constant.LogConstants;
import com.gsenc.wsf.common.util.SessionScopeUtil;
import com.gsenc.wsf.common.util.StringUtil;
import com.gsenc.wsf.session.model.UserSessionVO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@Slf4j
@Service
@RequiredArgsConstructor
public class CfCm000001ServiceImpl implements CfCm000001Service {

    private final static String _COMMON_NAMESPACE = "common.EasSap.";
    private final CommonDAO commonDAO;

    Marker marker = MarkerFactory.getMarker(LogConstants.RFC);

    @Override
    public GsrsMap selectZtrRtfbSend0400(CfCm000001RequestVO cfCm000001RequestVO) {

        SAPInterFaceClass sapInf = new SAPInterFaceClass();
        Map<String, Object> rtnMap = null;
        Map<String, Object> sapLogMap = null;
        GsrsMap resultMap = null;

        try {
            UserSessionVO userSession = SessionScopeUtil.getContextSession();
            resultMap = new GsrsMap();
            String empNo = "";
            String To_Acnt_Num = "";
            String To_Bank_Code = "";
            String To_Name = "";

            empNo = cfCm000001RequestVO.getEmpNo();
            To_Acnt_Num = cfCm000001RequestVO.getAcntNum().replace("-", "");
            To_Bank_Code = cfCm000001RequestVO.getBankCode();
            To_Bank_Code = cfCm000001RequestVO.getAcntName();

            YearMonth yearMonth = YearMonth.now();
            String yyyyMm = yearMonth.format(DateTimeFormatter.ofPattern("yyyyMM"));

            rtnMap = sapInf.selectZtrRtfbSend0400440(To_Acnt_Num, To_Bank_Code, To_Name);

            // SAP SEVER LOG
            log.info(marker, "[Request ]\n{}", cfCm000001RequestVO);
            log.info(marker, "[Response]\n{}", rtnMap);

            resultMap.put("E_RETURN_CODE", rtnMap.get("E_RETURN_CODE").toString());
            resultMap.put("E_RETURN_VALUE", rtnMap.get("E_RETURN_VALUE").toString());

            sapLogMap = new HashMap<>();
            sapLogMap.put("divs", "P");         // 구분
            sapLogMap.put("code", StringUtil.isNullToString(rtnMap.get("E_RETURN_CODE")));     // 코드
            sapLogMap.put("flag", StringUtil.isNullToString(rtnMap.get("E_RETURN_CODE")));         // I/F 결과
            sapLogMap.put("sapMsg", StringUtil.isNullToString(rtnMap.get("E_RETURN_VALUE")));     // SAP 메시지
            sapLogMap.put("empNo", empNo);   // 사번
            sapLogMap.put("sapCode", "");  // SAP 코드
            sapLogMap.put("subCode", "");  // SUB 코드
            sapLogMap.put("seq", "0");            // 순번
            sapLogMap.put("yyyyMm", yyyyMm);  // 년월

            //commonDAO.selectList(_COMMON_NAMESPACE + "selectProcSetIfSap", sapLogMap);

        } catch (Exception e) {
            // 마커를 사용한 로깅
            log.error(marker, "[Request ]\n{}", cfCm000001RequestVO);
            log.error(marker, "[Error   ]", e);
        }
        return resultMap;
    }

    @Override
    public GsrsMap setPartnerCompanyAccountSave(Map<String, Object> paramMap) {
        GsrsMap resultMap = null;
        Map<String, String> profileMap = null;
        Map<String, String> fileMap = null;

        String p_flag = "";
        String p_bankCode = "";
        String p_accountNum = "";
        String p_accountName = "";
        String p_loginIp = "";
        String p_empNo = "";
        String p_auth = "";
        List<Map<String, Object>> l_files =  null;



        String fileName = "";
        String fileSize = "";
        String fileUrl = "";
        String filePath = "";
        String fileRelativePath = "";
        String strUpPath = "/cfs";
        //String sEtaxNewFileName = String.valueOf(uuid);
        String sYYMM = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMM"));
        String strTempPath = Paths.get(strUpPath, strUpPath, "temp").toString(); // 첨부파일 임시경로
        Path pathSave = Paths.get(strUpPath, strUpPath, sYYMM);
        String strSavePath = pathSave.toString();
        try {

            if (paramMap.get("p_files") != null) {
                l_files = new ArrayList<>();
                l_files = (List<Map<String, Object>>) paramMap.get("p_files");

                if (!l_files.isEmpty()) {

                }
            }

            //fileName = paramMap.get("").toString();
            //fileSize = paramMap.get("size").toString();
            //fileUrl = paramMap.get("url").toString();
            //log.info("param etc {}", fileName+" :: "+fileSize+" :: "+fileUrl);
            //log.info("param get file {}", paramMap.get("file"));
            //paramMap.get("file");
            //filePath = fileMap.get("path");
            //fileRelativePath = fileMap.get("relativePath");

            File directory = new File(strSavePath);
            if (!directory.exists()) {
                directory.mkdirs();
            }

            Path tempFile = Paths.get(strTempPath, fileName);

            if (Files.exists(tempFile)) {
                Path saveFile = Paths.get(strSavePath, fileName);
                Files.copy(tempFile, saveFile, StandardCopyOption.REPLACE_EXISTING);
                Files.delete(tempFile);
            }
        } catch (Exception e) {
            // 마커를 사용한 로깅
            log.error(marker, "[Request ]\n{}", paramMap);
            log.error(marker, "[Error   ]", e);
        }
        return resultMap;
    }
}
