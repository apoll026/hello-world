package com.gsenc.cfs.cf.cm.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gsenc.cfs.cf.cm.model.CfCm000001RequestVO;
import com.gsenc.cfs.cf.cm.service.CfCm000001Service;
import com.gsenc.cfs.common.model.GsrsMap;
import com.gsenc.wsf.common.constant.CommonConstants;
import com.gsenc.wsf.common.constant.StatusCodeConstants;
import com.gsenc.wsf.common.model.CommonResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Tag(name = "CfCm000001")
@RequestMapping("/api/cf/cm")
public class CfCm000001Controller {

    private final CfCm000001Service cfCm000001Service;

    @Operation(summary = "등록계좌소유주조회") //Sap_Ztr_Changed_Vendor_Acnt
    @PostMapping(value = "/CfCm000001/selectZtrRtfbSend0400", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> selectZtrRtfbSend0400(@RequestBody CfCm000001RequestVO cfCm000001RequestVO) {

        GsrsMap result = cfCm000001Service.selectZtrRtfbSend0400(cfCm000001RequestVO);

        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(result)
                        .build(),
                HttpStatus.OK);
    }

    @Operation(summary = "현금계좌등록") //Sap_Ztr_Changed_Vendor_Acnt
    @PostMapping(value = "/CfCm000001/setPartnerCompanyAccountSave", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> setPartnerCompanyAccountSave(@RequestBody Map<String, Object> paramMap) {

        GsrsMap result = cfCm000001Service.setPartnerCompanyAccountSave(paramMap);

        return new ResponseEntity<>(
                CommonResponseVO.builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(StatusCodeConstants.SUCCESS)
                        .data(result)
                        .build(),
                HttpStatus.OK);
    }

}
