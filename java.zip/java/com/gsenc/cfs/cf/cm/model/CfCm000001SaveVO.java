package com.gsenc.cfs.cf.cm.model;

import lombok.*;
import lombok.extern.slf4j.Slf4j;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Slf4j
public class CfCm000001SaveVO {

	/** 인증서구분 */
	private String flag;
	/** 은행코드 */
	private String bankCode;
	/** 계좌번호 */
	private String acntNum;
	/** 계좌소유주명 */
	private String acntName;
	/** 접속자ip */
	private String loginIp;
	/** 사용자명 */
	private String empNo;
	/** 사용권한 */
	private String auth;

}
