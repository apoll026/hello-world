terraform {
  backend "s3" {
    bucket         = "s3-lgit-an2-_PROJECT_NAME_-dev-terraform-state"
    key            = "ap-northeast-2/pipeline-dev/frontend-_FEATURE_BRANCH_.tfstate"
    region         = "ap-northeast-2"
    dynamodb_table = "table-an2-_PROJECT_NAME_-dev-terraform-lock"
  }
}

provider "aws" {
  region  = "ap-northeast-2"
}
