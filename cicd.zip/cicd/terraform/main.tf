variable "bucketName" {
  type = string
}
variable "vpcEndpoint" {
  type = string
}
data "aws_caller_identity" "current" {}

output "account_id" {
  value =data.aws_caller_identity.current.account_id
}

resource "aws_s3_bucket" "s3-bucket-feature" {
  bucket = var.bucketName
  logging {
    target_bucket =  "s3-lgit-an2-${data.aws_caller_identity.current.account_id}-s3accesslogs"
    target_prefix = "feature"
  }

  tags ={
         Name = var.bucketName,
         Managed = "Terraform"
         }

}

resource "aws_s3_bucket_ownership_controls" "bucket_ownership_controls" {
  bucket = var.bucketName  
  rule {
    object_ownership = "BucketOwnerPreferred"
  }
  depends_on = [aws_s3_bucket.s3-bucket-feature ]
}

resource "aws_s3_bucket_acl" "s3-acl-pri" {
  for_each             = aws_s3_bucket_ownership_controls.bucket_ownership_controls
  bucket =  var.bucketName
  acl    = "private"
}


resource "aws_s3_bucket_server_side_encryption_configuration" "s3-encryption-kms" {
  bucket = var.bucketName
  rule {
      apply_server_side_encryption_by_default {
        sse_algorithm = "AES256"
      }
    }
}

resource "aws_s3_bucket_public_access_block" "s3-bucket-public-access-block-pri" {
  bucket = var.bucketName
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_policy" "s3-bucket-policy" {
  bucket = var.bucketName
  policy = <<POLICY
{
      "Version": "2012-10-17",
      "Statement": [
    {
      "Sid": "bucket account policy",
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:PutObject",
        "s3:PutObjectAcl",
        "s3:ListBucket"
      ],
      "Resource": [
                "arn:aws:s3:::${var.bucketName}",
                "arn:aws:s3:::${var.bucketName}/*"
            ],
      "Principal": {
        "AWS": [
          "arn:aws:iam::${data.aws_caller_identity.current.account_id}:root"
        ]
      }
    },
    {
      "Sid": "AllowSSLRequestsOnly",
      "Effect": "Deny",
      "Principal": "*",
      "Action": "s3:*",
      "Resource": [
                "arn:aws:s3:::${var.bucketName}",
                "arn:aws:s3:::${var.bucketName}/*"
            ],
      "Condition": {
        "Bool": {
          "aws:SecureTransport": "false"
        }
      }
    },
     {
            "Sid": "CombinedConditionalDenyStatement",
            "Effect": "Allow",
            "Principal": "*",
            "Action": "s3:*",
            "Resource": [
                "arn:aws:s3:::${var.bucketName}",
                "arn:aws:s3:::${var.bucketName}/*"
            ],
            "Condition": {
                "StringEquals": {
                    "aws:SourceVpce": "${var.vpcEndpoint}"
                }
            }
        }
  ]
}
POLICY
}
