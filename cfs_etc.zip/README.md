# your-system-id Front-End

이 repository는 표준 프레임워크 Front-End 개발소스 repository입니다.

## WEB F/W 환경설정 가이드

본 Git repository를 ( http://13.124.203.107:9004/ami/wsf-fe ) Download 한 후 각자 프로젝트 repository로 복사해서 작업하시기 바랍니다.  
(또는 해당 repository에서 zip 파일로 다운로드해서 작업하시기 바랍니다.)

### 수정할 내용

- package.json 파일의 YOUR_SYSTEMID_HERE 문자열
- .env-cmdrc 파일의 dev, prd 블럭
- Logo.tsx 파일의 div 블럭
- RestApi.ts 파일의 enum ServiceName ( 두개 이상의 Back-End 서비스를 이용할 경우 구분을 하기 위함임. )
- Jenkinsfile 파일의 stage('DEV App Build') 블럭 ==> Jenkins를 이용해 개발서버 Deploy 할 경우 사용됨.

### 다국어 메시지 일괄 추출 처리 방법

- multi-lang-find.py 파일을 참조 합니다.

개발WAS서버에서 Build 시 메모리 부족현상 해결방법

- SWAP 메모리를 설정합니다. ( 빌드시간이 약 40%정도 증가하나 시스템이 다운되지는 않음. )

```bash
$ sudo fallocate -l 4G /swapfile
>> 파일 /swapfile 로 4기가 할당

$ sudo chmod 600 /swapfile

$ sudo mkswap /swapfile
>> 스왑파일로 만들기 이때 UUID 가 출력되는데 저장해둘 것.
>> 예) UUID=XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

$ sudo swapon /swapfile
>> 스왑활성화

$ free -h
>> 스왑확인

$ sudo vi /etc/fstab
>> fstab 파일에 아래줄 추가 - 재부팅시에도 적용하기 위함.
>> UUID=XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX     /swapfile   swap   defaults          0   0

```

## 폴더 구조 (아래는 각 프로젝트에서 편집 바랍니다.)

- 이 프로젝트는 CRA로 구성되었습니다. [Create React App](https://github.com/facebook/create-react-app).

```bash
│── cicd/								          # Docker, Jenkins 스크립트 파일
├── public/                  			# Static assets
│   └── assets/              			# 프로젝트 하면서 바뀌지 않을 기타 정적 파일 (이미지, 폰트 등)
│
├── src/
│   ├── apis/                			# 프로젝트에서 사용되는 api 정의
│   │
│   ├── assets/              			# 프로젝트 하면서 바뀔 수도 있는 정적 파일(이미지, 폰트, 스타일 등 컴포넌트에서 import해서 사용)
│   │   ├── images/
│   │   └── fonts/
│   │   └── styles/
│   │
│   ├── components/          			# 전역으로 재사용 가능한 UI 컴포넌트, 공통 기능으로 이루어진 컴포넌트
│   │   ├── Button/
│   │   ├── Bookmark/
│   │   ├── Layout/
│   │   ├── Modal/
│   │   └── ...
│   │
│   ├── locales/            			# 다국어용 json 파일
│   │   └── message_ko.json
│   │
│   ├── mocks/            		  	# mock up api 정의
│   │   └── Bookmark/
│   │   		└── Bookmark.ts
│   │
│   ├── models/            		  	# type, enum 정의
│   │   └── Bookmark/
│   │   		└── Bookmark.ts
│   │
│   ├── hooks/               			# 컴포넌트에 종속적이지 않고 기능을 가진 커스텀 훅
│   │   └── Bookmark/
│   │   		└── useBookmark.ts
│   │
│   ├── pages/               			# 페이지 컴포넌트(메뉴단위 순서로)
│   │   ├── Board/
│   │   │   ├── components/	 			# 페이지에 종속되는 컴포넌트(다른 메뉴에서도 쓰인다면 components로 이동)
│   │   │   │		└── BoardListHeader.tsx
│   │   │   ├── hooks/			 		  # 페이지 컴포넌트에 사용하는 커스텀 훅
│   │   │   │		└── useBoardList.ts
│   │   │   ├── schemas/				  # 페이지 스키마
│   │   │   │		└── boardSchemas.ts
│   │   │   └── BoardListPage.tsx	# 가장 큰 단위 컴포넌트를 ~~Page.tsx로 정의
│   │   └── ...
│   │
│   ├── stores/               		# zustand로 관리되는 state 관리
│   │   └── useBookmarkStore.ts
│   │
│   ├── utils/               			# 공통 모듈성 util 관리
│   │   └── ApiUtil.ts
│   │
│   ├── App.tsx               		# 최상위 component
│   ├── index.tsx               	# root element에 App.tsx 컴포넌트를 렌더링
│   └── ...
│
├── .gitignore               			# Git 무시 파일
├── .env-cmdrc             				# App 환경변수 관리
├── .eslintrc.cjs             		# eslint 정의
├── .npmrc             					  # npm url 정의
├── .prettierrc.json            	# prettier 정의
├── tsconfig.json             		# typescript config 설정
├── package.json             			# 프로젝트 정보 및 의존성(dependencies)을 관리
├── index.html             				# react 기본 html
└── vite.config							      # vite config 설정
```

## 프로젝트 시작

package manager로 `yarn`을 사용합니다.

`yarn`은 npm global로 설치할 수 있습니다.

```bash
npm install -g yarn
```

## trouble shooting

### error: self signed certificate in certificate chain

yarn ssl issue로 인한 error.

```bash
yarn config set "strict-ssl" false
```

## 디펜던시 설치

```bash
yarn install
```

## 개발 실행

```bash
yarn start
```

## lint

```bash
yarn lint
yarn lint:fix
```

## Mock Service Worker

- .env-cmdrc에 REACT_APP_MSW_ENABLE이 'Y'로 설정되었는지 확인
- /src/mocks/handlers.ts의 handlers에 api Mocking 작성
- /src/mocks/handlers.ts의 handlerUrls에 작성한 api의 url 추가
