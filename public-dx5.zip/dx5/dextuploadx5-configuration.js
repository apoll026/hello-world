﻿/* dextuploadx5-configuration Copyright ⓒ DEXTSolution Inc. */
(function (win) {
    win.dextuploadx5Configuration = {
        // authkey: Authentication Key string
        authkey: "MRKjhGE/XAkxccADAylJ8E5UNElBY4cm5KxocLQSU76+hOOgInUFzHt7/8A9KANG0vKoaOUwI72dSU80qu0JJWL7XUDITF9786uvqfYTn+nC3O2aZ5fM0ForEucARrwq",
        // productPath: DEXTUploadX5 location path (It MUST be a web address started with http or https.)
        productPath: location.origin+'/dx5',
    };
})(window);