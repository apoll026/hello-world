import { loadDext5Scripts } from '@/amxis/utils/loadDext5.ts';
import { Button } from '@amxis/design-system';
import { Box } from '@mui/system';
import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';
import axios from 'axios';
import { v4 as uuidv4 } from 'uuid';
import { FileInfo } from '@/amxis/models/admin/FileInfo.ts';
import { useFilesToUnuseUpdateMutation } from '@/amxis/hooks/queries/file/use-files-update-to-unuse-mutation.ts';
import { FileId } from '@/amxis/models/admin/FileId.ts';

declare const dx5: any;
type FileUploaderDext5Props = {
  id?: string;
  initialFiles?: FileInfo[]; // 목록에 추가할 파일 (서버/DB에 존재하는 파일)
  initialGrId?: string; // 파일그룹ID (지정없으면 랜덤고유키)
  maxFileCount?: number; // 파일갯수 제한
  acceptFileTypes?: string[]; // 파일 필터
  excludeFileTypes?: string[]; // 제외 파일
  isTst?: boolean;
  isFileOpenBtn?: boolean; // 파일선택버튼 유무
  isFileDeleteBtn?: boolean; // 선택삭제버튼 유무
  guiStyle?: string; // dext5 style : list (default), tile, single, grid
  uploadUrl?: string; // 업로드 URL
  deleteUrl?: string; // 삭제 URL
  maxFileSize?: number; // 파일별 제한용량 (MB)
  maxTotalSize?: number; // 전체 제한용량 (MB)
  // grid 컬럼 추가 기능은 추후 필요시 테스트 후 업데이트
  // initialColumns?: any[]; // 추가 컬럼 (style grid만 가능, position 2부터 가능, 지정없으면 3부터 자동입력)
  // onColumnDataDisplaying?: (id, itemId, columnKey, columnValue) => void;
  // onColumnDataBinding?: (id, itemId, columnKey, columnValue) => void;
};
const FileUploaderDext5 = forwardRef<HTMLDivElement, FileUploaderDext5Props>(
  (props, ref: React.Ref<any>) => {
    const { isTst = false, isFileOpenBtn = true, isFileDeleteBtn = true } = props;
    const dextId = props.id ?? 'dext5';
    const guiStyle = props.guiStyle ?? 'list';
    const uploadUrl = props.uploadUrl ?? '/v1/dextfile/upload';
    const deleteUrl = props.deleteUrl ?? '/v1/files/unuse';
    const [initialFiles, setInitialFiles] = useState<FileInfo[]>(props.initialFiles ?? []);
    const { mutateAsync: filesToUnuseUpdateMutationAsync } =
      useFilesToUnuseUpdateMutation(deleteUrl);
    const atchFileGrId = useRef(props.initialGrId || uuidv4()).current;
    let fileSaveResult = '';
    let resolveUpload: (() => void) | null = null;

    const containerRef = useRef<HTMLDivElement>(null);

    const [isDx5Ready, setIsDx5Ready] = useState(false);

    const onDX5Error = (id: string, code: string, msg: string) => {
      console.error('Error occurred in Dext5:', { id, code, msg });
    };

    useEffect(() => {
      if (isDx5Ready && props.initialFiles) {
        const dx = dx5.get(dextId);
        if (dx) {
          dx.clearItems();

          // 새로운 파일들 추가
          props.initialFiles.forEach((file) => {
            dx.addVirtualFile({
              vindex: file.atchFileId,
              name: file.atchFileNm,
              size: file.atchFileSize,
              // meta: file?.meta ?? {},
            });
          });
        }
      }
    }, [isDx5Ready, props.initialFiles]);

    useEffect(() => {
      if (isDx5Ready) {
        const dx = dx5.get(dextId);
        if (dx) {
          // dx.clearItems();
          // 순필터 적용
          if (props.acceptFileTypes && props.acceptFileTypes.length > 0) {
            const extensions = props.acceptFileTypes.filter((ext) => ext !== '').join(';');

            if (extensions) {
              dx.setExtensionFilter(extensions);
            }
          }
          // 역필터 적용
          if (props.excludeFileTypes && props.excludeFileTypes.length > 0) {
            const extensions = props.excludeFileTypes.filter((ext) => ext !== '').join(';');

            if (extensions) {
              dx.setExtensionFilter(extensions, true);
            }
          }
        }
      }
    }, [isDx5Ready, props.acceptFileTypes, props.excludeFileTypes]);

    const onDX5Created = (id: string) => {
      const dx = dx5.get(id);
      dx.setSplitString('|');
      if (props.maxTotalSize) {
        dx.setMaxTotalSize(1024 * 1024 * props.maxTotalSize);
      }
      if (props.maxFileSize) {
        dx.setMaxFileSize(1024 * 1024 * props.maxFileSize);
      }
      if (props.maxFileCount) {
        dx.setMaxFileCount(props.maxFileCount);
      }
      dx.useProgressDialog(false);

      if (props.acceptFileTypes && props.acceptFileTypes.length > 0) {
        const extensions = props.acceptFileTypes.filter((ext) => ext !== '').join(';');

        if (extensions) {
          dx.setExtensionFilter(extensions);
        }
      }

      // if (props.initialColumns && props.initialColumns.length > 0) {
      //   let startPosition = 3;
      //   props.initialColumns.forEach((item) => {
      //     dx.createColumn({ ...item, position: startPosition++ });
      //   });
      // }

      setIsDx5Ready(true);

      // dx.clearItems();

      // if (initialFiles && initialFiles.length > 0) {
      //   initialFiles.forEach((file) => {
      //     dx.addVirtualFile({
      //       vindex: file.atchFileId,
      //       name: file.atchFileNm,
      //       size: file.atchFileSize,
      //     });
      //   });
      // }
    };

    // const onDX5ColumnDataDisplaying = (id, itemId, columnKey, columnValue) => {
    //   return props.onColumnDataDisplaying?.(id, itemId, columnKey, columnValue);
    // };

    // const onDX5ColumnDataBinding = (id, itemId, columnKey, columnValue) => {
    //   return props.onColumnDataBinding?.(id, itemId, columnKey, columnValue);
    // };

    const onDX5ItemsAdded = (id: string, count: number, arr) => {
      const dx = dx5.get(id);
      arr.forEach((itemId) => {
        dx.setMetaDataById(itemId, 'name', atchFileGrId);
      });
    };

    const onDX5BeforeItemsAdd = (id: string, arr: any) => {
      if (props.maxFileCount === 1) {
        const dx = dx5.get(id);
        dx.clearItems();
      }
    };
    const onDX5UploadBegin = (id: string) => {};
    const onDX5UploadCompleted = (id: string) => {
      if (resolveUpload) {
        resolveUpload();
        resolveUpload = null;
      }

      const dx = dx5.get(id);
      fileSaveResult = dx.getResponses(0);
      dx.clearItems();
    };
    const getDx = (id: string) => {
      return dx5.get(id);
    };
    const getAtchFileGrId = () => {
      return atchFileGrId;
    };
    const clearItems = (id: string) => {
      dx5.get(id).clearItems();
    };
    const openFileDialog = (id: string) => {
      dx5.get(id).openFileDialog();
    };
    const removeById = (id: string, itemId: string) => {
      dx5.get(id).removeById(itemId);
    };
    const removeCheckedItems = (id: string) => {
      const dx = dx5.get(id);
      dx.removeChecked();
    };

    const uploadFrom = async (id: string) => {
      const dx = dx5.get(id);
      const deletedVirtualFiles = dx.getRemovedFiles();
      if (deletedVirtualFiles.length > 0) {
        const deletedFilesId: FileId[] = deletedVirtualFiles.map((file) => ({
          atchFileGrId: atchFileGrId,
          atchFileId: file.vindex,
        }));
        const response = await filesToUnuseUpdateMutationAsync(deletedFilesId);
        if (!response) {
          throw new Error('failed file delete');
        }
      }

      if (dx.hasUploadableItems()) {
        const headers = axios.defaults.headers.common;

        Object.keys(headers).forEach((key) => {
          const value = headers[key];
          if (value) {
            dx.setCustomHeader(key, value);
          }
        });
        dx.setUploadURL(`${process.env.API_BASE_URL}/api${uploadUrl}`);

        const uploadCompletedPromise = new Promise<void>((resolve) => {
          resolveUpload = resolve;
        });

        // 여기서 재정의 해줘야 resolveUpload 인식가능
        dx.events.uploadCompleted = (id: string) => {
          if (resolveUpload) {
            resolveUpload();
            resolveUpload = null;
          }

          const dx = dx5.get(id);
          fileSaveResult = dx.getResponses(0);
          if (fileSaveResult) {
            fileSaveResult = JSON.parse(fileSaveResult);
          }
          dx.clearItems();
        };
        dx.upload('AUTO');

        // 완료될 때까지 대기
        await uploadCompletedPromise;

        return {
          atchFileGrId,
          fileSaveResult,
        };
      } else {
        fileSaveResult = 'NONE';
        return {
          atchFileGrId,
          fileSaveResult,
        };
      }
    };
    useImperativeHandle(ref, () => ({
      getDx: (id) => {
        return getDx(id);
      },
      getAtchFileGrId: () => {
        return getAtchFileGrId();
      },
      uploadFrom: (id) => {
        return uploadFrom(id);
      },
      clearItems: (id) => {
        clearItems(id);
      },
      openFileDialog: (id) => {
        openFileDialog(id);
      },
      removeById: (id, itemId) => {
        removeById(id, itemId);
      },
    }));
    useEffect(() => {
      loadDext5Scripts()
        .then(() => {
          if (dx5?.create) {
            dx5.create({
              id: dextId,
              style: guiStyle,
              parentId: `${dextId}-container`,
              btnFile: 'btn-add-files',
              btnFolder: 'btn-add-folder',
              events: {
                created: onDX5Created,
                error: onDX5Error,
                itemsAdded: onDX5ItemsAdded,
                beforeItemsAdd: onDX5BeforeItemsAdd,
                uploadBegin: onDX5UploadBegin,
                uploadCompleted: onDX5UploadCompleted,
                // columnDataDisplaying: onDX5ColumnDataDisplaying,
                // columnDataBinding: onDX5ColumnDataBinding,
              },
            });
          } else {
            console.error('dx5 is not defined');
          }
        })
        .catch(console.error);
    }, []);

    return (
      <Box>
        <div
          id={`${dextId}-container`}
          ref={containerRef}
          style={{ width: '100%', height: '100%' }}
        />

        <Box display="flex" justifyContent="flex-end" gap="4px">
          {isTst && <Button onClick={() => uploadFrom(dextId)}>업로드</Button>}
          {isTst && (
            <Button
              onClick={() => {
                console.log(dx5.get(dextId).getItems());
                console.log('atchFileGrId:', atchFileGrId);
                console.log('props.initialGrId:', props.initialGrId);
                console.log('initialFiles:', initialFiles);
              }}
            >
              테스트
            </Button>
          )}
          {isFileOpenBtn && (
            <Button
              onClick={() => {
                openFileDialog(dextId);
              }}
            >
              파일 선택
            </Button>
          )}
          {isFileDeleteBtn && (
            <Button
              appearance="outlined"
              priority="normal"
              size="large"
              onClick={() => removeCheckedItems(dextId)}
            >
              선택 삭제
            </Button>
          )}
        </Box>
      </Box>
    );
  }
);

FileUploaderDext5.displayName = 'FileUploaderDext5';

export default FileUploaderDext5;
