import React, { useEffect, useState } from 'react';
import { Box, Typography } from '@mui/material';
import { useTranslation } from 'react-i18next';
import { InputField } from '@amxis/design-system';
import { useMenuContext } from '@/amxis/components/menu-provider';
import useSessionStore from '@/amxis/stores/useSessionStore.ts';
import { useSideBarMenus } from './use-side-bar-menus.ts';
import { SideMenuList } from './side-menu-list.tsx';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { getAllMenusSearch } from '@/amxis/apis/admin/MenuApi.ts';
import { MenuVO } from '@/amxis/models/admin/Menu.ts';
import { useTheme } from '@mui/system';
import { MenuLeftmenuIcon } from '@amxis/design-system/icon';

type SideMenuBarProps = {
  sidebarWidth: number;
  headerHeight: number;
  sideMenuListHeight: string;
  isSidebarOpen: boolean;
  setIsSidebarOpen: React.Dispatch<React.SetStateAction<boolean>>;
};

type MenuOption = {
  label: string;
  value: string;
};

function SideMenuBar({
  sidebarWidth,
  headerHeight,
  sideMenuListHeight,
  isSidebarOpen,
  setIsSidebarOpen,
}: SideMenuBarProps) {
  const {
    palette: { semantic },
  } = useTheme();
  const [isOpened] = useState(true);
  const [menuOptions, setMenuOptions] = useState<MenuOption[]>([]);
  const [menuData, setMenuData] = useState<MenuVO[]>([]);
  const location = useLocation();
  const [searchInputValue, setSearchInputValue] = useState(''); // 사용자가 입력 중인 메뉴(검색어)
  const [selectedMenuOption, setSelectedMenuOption] = useState<MenuOption | null>(null); // 사용자가 선택한 메뉴 옵션
  const [isMenuOptionSelected, setIsMenuOptionSelected] = useState(false); // 메뉴 옵션 선택 플래그(입력값 초기화용)

  // 1뎁스 메뉴들의 토글 상태 관리
  const [activeDepth1MenuId, setActiveDepth1MenuId] = useState<string | null>(null);

  const menuContext = useMenuContext();
  const { headerMenus } = useSessionStore();
  const { t } = useTranslation();
  const navigate = useNavigate();

  const { sideMenus } = useSideBarMenus();

  useEffect(() => {
    // 메뉴 옵션 선택 후 페이지 이동 시 입력값과 선택값 초기화
    if (isMenuOptionSelected) {
      setSearchInputValue('');
      setSelectedMenuOption(null);
      setIsMenuOptionSelected(false);
    }
  }, [location.pathname]);

  // 메뉴 검색 옵션 데이터 가져오기
  useEffect(() => {
    const fetchMenuOptions = async () => {
      // 세션이 없거나 헤더 메뉴가 없으면 API 호출하지 않음
      if (!menuContext.selectedHeaderMenu || headerMenus.length === 0) {
        return;
      }

      try {
        const menuDataResult = await getAllMenusSearch();
        if (menuDataResult) {
          setMenuData(menuDataResult);
          const options = menuDataResult.map((menu: MenuVO) => ({
            label: menu.pgmName || menu.pgmId,
            value: menu.pgmId,
          }));
          setMenuOptions(options);
        }
      } catch (error) {
        console.error('메뉴 검색 데이터를 가져오는데 실패했습니다:', error);
      }
    };

    fetchMenuOptions();
  }, [menuContext.selectedHeaderMenu, headerMenus]);

  const generateHeaderMenuName = (pgmId: string) => {
    const headerMenu = headerMenus.find((item) => item.pgmId === pgmId);
    return String(t(`${headerMenu?.msgCtn}`, `${headerMenu?.pgmName}`));
  };

  // 1뎁스 메뉴 토글 핸들러
  const handleDepth1MenuToggle = (menuId: string | null) => {
    setActiveDepth1MenuId(menuId);
  };

  const handleInputChange = (e, newInputValue) => {
    setSearchInputValue(newInputValue);
    setSelectedMenuOption(null);
    setIsMenuOptionSelected(false);
  };

  // 메뉴 검색에서 선택된 메뉴로 이동
  const handleMenuSelect = (e, selectedValue, reason) => {
    if (reason === 'clear') {
      setSearchInputValue('');
      setSelectedMenuOption(null);
      setIsMenuOptionSelected(false);
      setActiveDepth1MenuId(null);
      return;
    }

    if (selectedValue) {
      const selectedMenu = menuData.find((menu) => menu.pgmId === selectedValue.value);

      if (selectedMenu && selectedMenu.pgmUrl) {
        setSelectedMenuOption(selectedValue);
        setIsMenuOptionSelected(true);
        navigate('/' + selectedMenu.pgmUrl);
      }
    }
  };

  if (!menuContext.selectedHeaderMenu || sideMenus.length === 0) {
    return null;
  }

  return (
    <Box
      width={isOpened ? `${sidebarWidth}px` : '0'}
      bgcolor={semantic.color.commonBgBasic}
      sx={{
        borderTopRightRadius: '12px',
        boxShadow: '0px 0px 10px 0px rgba(0, 0, 0, 0.12)',
      }}
    >
      {isOpened && (
        <>
          {/* 헤더 로고 + 메뉴 아이콘 */}
          <Box
            sx={{
              height: `${headerHeight}px`,
              paddingLeft: '12px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}
          >
            <Link to="/">
              <Typography
                variant="h2"
                sx={{
                  fontSize: '17px',
                  color: semantic.color.navTopTextSysNameLogo,
                }}
              >
                전자전표시스템
              </Typography>
            </Link>
            <Box
              sx={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                width: `${headerHeight}px`,
                height: `${headerHeight}px`,
                cursor: 'pointer',
              }}
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            >
              <MenuLeftmenuIcon
                leftArea
                iconSize={24}
                sx={{ color: semantic.color.commonTextLight }}
              />
            </Box>
          </Box>

          {/* 메뉴 검색 */}
          <Box sx={{ padding: '10px 8px' }}>
            <InputField
              type="search"
              usecase="text"
              inputValue={searchInputValue}
              value={selectedMenuOption}
              onInputChange={handleInputChange}
              onChange={handleMenuSelect}
              placeholder="메뉴를 검색하세요."
              options={menuOptions}
            />
          </Box>

          {/* 메인 메뉴명 */}
          <Typography
            variant="h3"
            sx={{
              margin: '0 8px',
              padding: '8px 0',
              color: semantic.color.navLeftTextSelected,
              borderBottom: `1px solid ${semantic.color.commonBorderLight}`,
            }}
          >
            {generateHeaderMenuName(menuContext.selectedHeaderMenu)}
          </Typography>

          {/* 메뉴 리스트 */}
          <Box
            sx={{
              overflowY: 'auto',
              height: sideMenuListHeight,
            }}
          >
            {sideMenus.map((it) => (
              <SideMenuList
                key={it.menuInfo.pgmId}
                summary={{ menuInfo: it.menuInfo }}
                content={it.children}
                isActive={true}
                menuId={it.menuInfo.pgmId}
                activeMenuId={activeDepth1MenuId}
                onMenuToggle={handleDepth1MenuToggle}
              />
            ))}
          </Box>
        </>
      )}
    </Box>
  );
}

export { SideMenuBar };
