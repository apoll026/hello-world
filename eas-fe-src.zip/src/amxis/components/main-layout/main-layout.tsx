import React, { Suspense, useEffect, useRef, useState } from 'react';
import { Outlet, useLocation } from 'react-router';
import { Box, Typography, useTheme } from '@mui/material';
import { useMenuContext } from '@/amxis/components/menu-provider';
import { SideMenuBar } from './side-menu-bar.tsx';
import { PageHeaderLayout } from './page-header-layout.tsx';
import { NoticePopupModals } from './notice-popup-modals.tsx';
import { usePreventRightClickEffect } from './use-prevent-right-click-effect.ts';
import { usePreventDevToolShortcutEffect } from './use-prevent-dev-tool-shortcut-effect.ts';
import { HeaderMenuBar } from './header-menu-bar.tsx';
import { Link } from 'react-router-dom';
import { ProgressIndicator } from '@amxis/design-system';
import { MenuLeftmenuIcon } from '@amxis/design-system/icon';

type MainLayoutProps = {
  noPaddingPage?: boolean;
  noShowPageHeader?: boolean;
  noShowPageHeaderBreadcrumbMenu?: boolean;
};

function MainLayout({
  noPaddingPage = false,
  noShowPageHeader = false,
  noShowPageHeaderBreadcrumbMenu = false,
}: MainLayoutProps) {
  const {
    palette: { semantic },
  } = useTheme();
  const location = useLocation();
  const scrollRef = useRef<HTMLDivElement>(null);
  const { showMenu } = useMenuContext();

  usePreventRightClickEffect();
  usePreventDevToolShortcutEffect();

  const hasMenuBar = showMenu && location.pathname !== '/errorPage';

  const [isMobile, setIsMobile] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  // const [isZoom, setIsZoom] = useState(false);

  const baseWidth_iPad11Pro = 1210; // 1210 * 834
  const baseWidth_iPad13Pro = 1376; // 1376 * 1032
  const baseWidth = 1680;

  const headerHeight = 52;
  const sidebarWidth = 230;
  const scrollWidth = 6;

  const [headerMenusNum, setHeaderMenusNum] = useState(() => {
    const width = window.innerWidth;

    if (width <= baseWidth) return 8;
    else return 10;
  });

  useEffect(() => {
    const handleResize = () => {
      const width = window.innerWidth;
      const isNowMobile = width <= baseWidth_iPad13Pro;

      setIsMobile(isNowMobile);
      setIsSidebarOpen(!isNowMobile);
      // setIsZoom(width <= baseWidth_iPad11Pro);

      if (width <= baseWidth) setHeaderMenusNum(8);
      else setHeaderMenusNum(10);

      if (location.pathname == '/') {
        setIsSidebarOpen(false);
      }
    };

    handleResize(); // 초기 실행
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    // 페이지 이동 시 스크롤 위치 초기화
    scrollRef.current?.scrollTo(0, 0);
  }, [location.pathname]);

  return (
    <Box
      display="flex"
      height={window.innerWidth < baseWidth_iPad11Pro ? `calc(100vh - ${scrollWidth}px)` : '100vh'}
    >
      {/* 사이드 메뉴 */}
      {hasMenuBar && (
        <Box
          width={location.pathname === '/login' ? '0' : isSidebarOpen ? `${sidebarWidth}px` : '0'}
          sx={{
            position: isMobile ? 'fixed' : 'relative',
            left: isSidebarOpen ? '0' : `-${sidebarWidth}px`,
            transition: isMobile ? '0.5s' : '',
            backgroundColor: isMobile ? 'transparent' : semantic.color.navTopBgBasic,
            zIndex: 30,
          }}
        >
          <SideMenuBar
            sidebarWidth={sidebarWidth}
            headerHeight={headerHeight}
            sideMenuListHeight={
              window.innerWidth < baseWidth_iPad11Pro
                ? `calc(100vh - 145px - ${scrollWidth}px)`
                : 'calc(100vh - 145px)'
            }
            isSidebarOpen={isSidebarOpen}
            setIsSidebarOpen={setIsSidebarOpen}
          />
        </Box>
      )}

      {/* 사이드 메뉴 배경 */}
      <Box
        sx={{
          transition: '0.5s',
          opacity: isSidebarOpen && isMobile ? 1 : 0,
          visibility: isSidebarOpen && isMobile ? 'visible' : 'hidden',
          position: 'fixed',
          inset: 0,
          backgroundColor: semantic.color.commonBgDim,
          zIndex: 19,
        }}
        onClick={() => setIsSidebarOpen(!isSidebarOpen)}
      />

      <Box
        display="flex"
        flexDirection="column"
        flex="1"
        sx={{
          minWidth: isMobile
            ? `calc(${baseWidth_iPad11Pro}px)`
            : `calc(${baseWidth_iPad11Pro}px - ${sidebarWidth}px)`,
          overflowX: 'hidden',
          paddingBottom: '12px',
        }}
      >
        {/* 헤더 로고 + 메뉴 아이콘 */}
        {location.pathname !== '/login' && hasMenuBar && (
          <Box
            sx={{
              position: 'absolute',
              top: 0,
              left: 0,
              zIndex: 20,
              width: `${sidebarWidth}px`,
              height: `${headerHeight}px`,
              paddingLeft: '12px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}
          >
            <Link to="/">
              <Typography
                variant="h2"
                sx={{
                  fontSize: '17px',
                  color: semantic.color.navTopTextSysNameLogo,
                }}
              >
                전자전표시스템
              </Typography>
            </Link>
            {location.pathname !== '/' && (
              <Box
                sx={{
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center',
                  width: `${headerHeight}px`,
                  height: `${headerHeight}px`,
                  cursor: 'pointer',
                }}
                onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              >
                <MenuLeftmenuIcon iconSize={24} sx={{ color: semantic.color.commonTextLight }} />
              </Box>
            )}
          </Box>
        )}

        {/* 헤더 메뉴 */}
        {location.pathname !== '/login' && (
          <HeaderMenuBar
            headerHeight={headerHeight}
            headerMenusNum={headerMenusNum}
            setIsSidebarOpen={setIsSidebarOpen}
          />
        )}

        {/* 콘텐츠 */}
        <Box
          ref={scrollRef}
          flex="1"
          p={noPaddingPage ? '0' : '12px 16px 0'}
          sx={{
            overflowY: 'auto',
            // zoom: isZoom ? '0.8' : '1',
          }}
        >
          {!noShowPageHeader && (
            <PageHeaderLayout showBreadcrumbMenu={!noShowPageHeaderBreadcrumbMenu} />
          )}
          <Box
            sx={{
              height: 'calc(100% - 41px)', // PageHeaderLayout 높이 빼기
              '&.hasInnerNav': { padding: '0 30px 50px 0' },
            }}
          >
            <Suspense
              fallback={
                <Box height="100%" display="flex" justifyContent="center" alignItems="center">
                  <ProgressIndicator shape="circular" apprearance="infinite" />
                </Box>
              }
            >
              <Outlet />
            </Suspense>
          </Box>
        </Box>
      </Box>
    </Box>
  );
}

function PlainMainLayout() {
  return <MainLayout noPaddingPage noShowPageHeader noShowPageHeaderBreadcrumbMenu />;
}

function PlainMainLayoutWithNoticePopups() {
  return (
    <>
      <PlainMainLayout />
      <NoticePopupModals />
    </>
  );
}

function MainLayoutWithNoticePopups() {
  return (
    <>
      <MainLayout />
      <NoticePopupModals />
    </>
  );
}

export { MainLayout, PlainMainLayout, PlainMainLayoutWithNoticePopups, MainLayoutWithNoticePopups };
