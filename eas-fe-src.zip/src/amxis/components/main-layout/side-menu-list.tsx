import { Box, Typography } from '@mui/material';
import { useMenuContext } from '@/amxis/components/menu-provider';
import { Menu } from '@/amxis/models/admin/Menu.ts';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Link, useNavigate } from 'react-router-dom';
import { toAbsolutePath } from './main-layout.utils.ts';
import { MenuType } from './menu.types.ts';
import { useTheme } from '@mui/system';
import { ArrowChevron2Icon } from '@amxis/design-system/icon';
import { $semantic } from '@amxis/design-system';

// 새창으로 처리
const chkSessionNewWin = () => {
  const cookieNewWin =
    document.cookie
      .split('; ')
      .find((row) => row.startsWith('NEW_WIN='))
      ?.split('=')[1] || '';

  return cookieNewWin ? true : false;
};

const handleNewWindowTab = (url: string) => {
  window.open(url + '/nolayout', '_blank');
};

const SmallDot = () => (
  <Box component="svg" width="4px" height="4px" viewBox="0 0 4 4" mr="8px">
    <circle cx="2" cy="2" r="2" fill="currentColor" />
  </Box>
);

const menuHeight = 32;

type SideMenuContentProps = {
  contentList: MenuType[];
  isActive: boolean;
  forceClose?: boolean;
  depth?: number;
};

function SideMenuContent({ contentList, isActive, forceClose, depth = 1 }: SideMenuContentProps) {
  const {
    palette: { semantic },
  } = useTheme();
  const { t } = useTranslation();
  const { currentMenu } = useMenuContext();
  const navigate = useNavigate();

  // 같은 레벨에서 현재 열려있는 메뉴 ID를 관리
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);

  const navigateToMenu = (prgmUrl: string) => {
    if (prgmUrl) navigate(toAbsolutePath(prgmUrl), { replace: false });
  };

  // 메뉴 토글 핸들러
  const handleMenuToggle = (menuId: string | null) => {
    setActiveMenuId(menuId);
    // console.log(`Menu toggled: ${menuId}`); // 디버깅용 로그
  };

  // forceClose가 true일 때 모든 메뉴 닫기
  useEffect(() => {
    if (forceClose) {
      setActiveMenuId(null);
    }
  }, [forceClose]);

  return (
    <>
      {contentList.map((it) => {
        const childMenus =
          it.children?.filter((c) => c.menuInfo.useYn === 'Y' && c.menuInfo.menuDispYn === 'Y') ||
          [];
        const hasChildren = childMenus.length > 0;

        return hasChildren ? (
          <SideMenuList
            key={it.menuInfo.pgmId}
            summary={{ menuInfo: it.menuInfo }}
            content={childMenus}
            isActive={isActive}
            forceClose={forceClose}
            depth={depth}
            menuId={it.menuInfo.pgmId}
            activeMenuId={activeMenuId}
            onMenuToggle={handleMenuToggle}
          />
        ) : it.menuInfo.useYn === 'Y' ? (
          <Box
            key={it.menuInfo.pgmId}
            overflow="hidden"
            padding={`0 8px 0 ${(depth - 1) * 14}px`}
            onClick={() => {
              // 자식 메뉴가 없는 최하위 메뉴에서만 네비게이트
              const childMenus =
                it.children?.filter(
                  (c) => c.menuInfo.useYn === 'Y' && c.menuInfo.menuDispYn === 'Y'
                ) || [];
              const hasChildMenus = childMenus.length > 0;

              if (!hasChildMenus) {
                // 개인별접근권한조회에서 사용체크시 로그인동안에는 새창으로 메뉴 띄움
                if (chkSessionNewWin()) {
                  handleNewWindowTab(toAbsolutePath(it.menuInfo.pgmUrl ?? ''));
                } else {
                  navigateToMenu(it.menuInfo.pgmUrl ?? '');
                }
              }
            }}
          >
            <Box
              component={!hasChildren ? Link : 'div'}
              to={
                !hasChildren && it.menuInfo.pgmUrl && !chkSessionNewWin()
                  ? toAbsolutePath(it.menuInfo.pgmUrl)
                  : undefined
              }
              height={isActive ? `${menuHeight}px` : 0}
              display="flex"
              alignItems="center"
              fontSize="13px"
              fontWeight={currentMenu?.pgmId === it.menuInfo.pgmId ? 500 : 400}
              sx={{
                padding: '0 6px 0 8px',
                transition: '0.3s',
                borderRadius: `${$semantic.shared.radius.radiusButtonM}px`,
                backgroundColor:
                  currentMenu?.pgmId === it.menuInfo.pgmId ||
                  currentMenu?.upgmId === it.menuInfo.pgmId
                    ? semantic.color.navLeftBgLastChildSelected2
                    : 'transparent',
                color:
                  currentMenu?.pgmId === it.menuInfo.pgmId
                    ? semantic.color.navLeftTextLastChildSelected
                    : semantic.color.navLeftTextDefault,
                '&:hover': {
                  backgroundColor:
                    currentMenu?.pgmId === it.menuInfo.pgmId
                      ? semantic.color.navLeftBgLastChildSelected2
                      : semantic.color.navLeftBg1LevelHover,
                },
              }}
            >
              {depth > 1 && <SmallDot />}
              {t(it.menuInfo.msgCtn, it.menuInfo.pgmName)}
            </Box>
          </Box>
        ) : null;
      })}
    </>
  );
}

type SideMenuSummaryProps = {
  header: Menu;
  isSelectedMenu: boolean;
  depth: number;
};

function SideMenuSummary({ header, isSelectedMenu, depth }: SideMenuSummaryProps) {
  const { t } = useTranslation();

  return (
    <Box display="flex" alignItems="center" flex={1}>
      {depth > 1 && <SmallDot />}
      <Typography variant="h6" fontWeight={isSelectedMenu ? 500 : 400}>
        {t(header.msgCtn, header.pgmName)}
      </Typography>
    </Box>
  );
}

type SideMenuListProps = {
  summary: { menuInfo: Menu };
  content: MenuType[];
  isActive: boolean;
  forceClose?: boolean;
  depth?: number;
  menuId?: string;
  activeMenuId?: string | null;
  onMenuToggle?: (menuId: string | null) => void;
};

function SideMenuList({
  summary,
  content,
  isActive,
  forceClose,
  depth = 1,
  menuId,
  activeMenuId,
  onMenuToggle,
}: SideMenuListProps) {
  const {
    palette: { semantic },
  } = useTheme();
  const [isOpen, setIsOpen] = useState(false);
  const { currentMenu } = useMenuContext();
  const navigate = useNavigate();
  const { menuInfo } = summary;
  const hasEpsMenus = content.some((c) => c.menuInfo.useYn === 'Y');
  const isCurrentMenu =
    currentMenu?.pgmId === menuInfo.pgmId ||
    (currentMenu?.useYn === 'N' && currentMenu?.upgmId === menuInfo.pgmId);
  const isSelectedMenu = hasEpsMenus ? isOpen : isCurrentMenu;

  const navigateToMenu = (prgmUrl: string, linkTo?: boolean) => {
    if (linkTo && prgmUrl) {
      navigate(toAbsolutePath(prgmUrl), { replace: false });
      return; // 네비게이션 후 바로 리턴하여 토글 로직 실행 방지
    }

    // 하위 메뉴가 있는 경우에만 토글 로직 실행
    if (hasEpsMenus) {
      const newIsOpen = !isOpen;
      setIsOpen(newIsOpen);

      // 부모에게 메뉴 토글 알리기 (같은 레벨 메뉴들 제어용)
      if (onMenuToggle && menuId) {
        onMenuToggle(newIsOpen ? menuId : null);
      }
    }
  };

  // 같은 레벨에서 다른 메뉴가 열렸을 때 현재 메뉴 닫기
  useEffect(() => {
    if (activeMenuId && activeMenuId !== menuId && isOpen) {
      setIsOpen(false);
      // console.log(`Closing menu: ${menuId} because activeMenuId changed to ${activeMenuId}`); // 디버깅용 로그
    }
  }, [activeMenuId, menuId, isOpen]);

  useEffect(() => {
    if (forceClose) setIsOpen(false);
  }, [forceClose]);

  // 현재 메뉴가 변경될 때 해당 메뉴까지의 경로를 자동으로 열기
  useEffect(() => {
    if (currentMenu?.pgmId && hasEpsMenus && !forceClose) {
      // 더 안전한 방법: 재귀적으로 모든 하위 메뉴 ID를 수집
      const getAllChildMenuIds = (menuList: MenuType[]): string[] => {
        const ids: string[] = [];
        menuList.forEach((menu) => {
          ids.push(menu.menuInfo.pgmId);
          if (menu.children && menu.children.length > 0) {
            ids.push(...getAllChildMenuIds(menu.children));
          }
        });
        return ids;
      };

      const allChildIds = getAllChildMenuIds(content);
      const shouldOpen = allChildIds.includes(currentMenu.pgmId);

      if (shouldOpen && !isOpen) {
        // 즉시 실행하지 않고 다음 렌더링 사이클로 지연
        setTimeout(() => {
          setIsOpen(true);
          // 자동으로 열릴 때도 부모에게 알리기
          if (onMenuToggle && menuId) {
            onMenuToggle(menuId);
          }
        }, 0);
      }
    }
  }, [currentMenu?.pgmId, hasEpsMenus, forceClose]);

  return (
    <Box display="flex" flexDirection="column" overflow="hidden">
      {menuInfo.useYn === 'Y' && (
        <Box p={`0 8px 0 ${depth === 1 ? 8 : (depth - 1) * 14}px`}>
          <Box
            height={isActive ? `${menuHeight}px` : 0}
            display="flex"
            alignItems="center"
            gap="2px"
            sx={{
              cursor: 'pointer',
              padding: '0 6px 0 8px',
              transition: '0.3s',
              borderRadius: `${$semantic.shared.radius.radiusButtonM}px`,
              backgroundColor:
                isSelectedMenu && !hasEpsMenus
                  ? semantic.color.navLeftBgLastChildSelected2
                  : 'transparent',
              color: isSelectedMenu
                ? hasEpsMenus
                  ? semantic.color.navLeftTextSelected
                  : semantic.color.navLeftTextLastChildSelected
                : semantic.color.navLeftTextDefault,
              '&:hover': {
                backgroundColor:
                  isSelectedMenu && !hasEpsMenus
                    ? semantic.color.navLeftBgLastChildSelected2
                    : semantic.color.navLeftBg1LevelHover,
              },
            }}
            onClick={() => navigateToMenu(menuInfo.pgmUrl ?? '', !hasEpsMenus)}
          >
            <SideMenuSummary header={menuInfo} isSelectedMenu={isSelectedMenu} depth={depth} />
            {hasEpsMenus && (
              <ArrowChevron2Icon
                appearance="single"
                direction="down"
                iconSize={16}
                sx={{
                  transition: '0.3s',
                  transform: isSelectedMenu ? 'rotate(180deg)' : 'none',
                  color: isSelectedMenu
                    ? semantic.color.commonTextBasic
                    : semantic.color.commonTextNormal,
                }}
              />
            )}
          </Box>
        </Box>
      )}
      {menuInfo.useYn === 'Y' && hasEpsMenus && (
        <SideMenuContent
          contentList={content.filter((item) => item.menuInfo.useYn === 'Y')}
          isActive={isOpen}
          forceClose={!isOpen}
          depth={depth + 1} // 자식만 +1
        />
      )}
    </Box>
  );
}

export { SideMenuList };
