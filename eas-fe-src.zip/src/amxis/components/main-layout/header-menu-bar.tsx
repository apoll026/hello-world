import {
  Box,
  ClickAwayListener,
  MenuItem,
  MenuList,
  Paper,
  Popper,
  Typography,
  useTheme,
} from '@mui/material';
import { Avatar, OptionList } from '@amxis/design-system';
import { useMenuContext } from '@/amxis/components/menu-provider';
import useSessionStore from '@/amxis/stores/useSessionStore.ts';
import { useDisplayEmpName } from './use-display-emp-name.ts';
import { HeaderLinkList } from './header-link-list.tsx';
import {
  CommunicationBookmarkIcon,
  ControlCloseIcon,
  MenuMoreIcon,
} from '@amxis/design-system/icon';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useBookMarkStore } from '@/amxis/stores/useBookMarkStore.ts';
import { BookMark } from '@/amxis/models/admin/Menu';
import { $scale } from '@amxis/design-system/design-token';

type HeaderMenuBarProps = {
  headerHeight: number;
  headerMenusNum?: number;
  setIsSidebarOpen?: (open: boolean) => void;
};

function HeaderMenuBar({ headerHeight, headerMenusNum = 0, setIsSidebarOpen }: HeaderMenuBarProps) {
  const {
    palette: {
      semantic: { color },
    },
  } = useTheme();
  const { headerMenus, mailId, menus } = useSessionStore();
  const menuContext = useMenuContext();
  const { displayEmpNm } = useDisplayEmpName();
  const { bookMarkMenus, removeBookMark } = useBookMarkStore();
  const navigate = useNavigate();

  // 선택된 메뉴가 자식 메뉴를 가지고 있는지 확인하는 함수
  const hasChildMenus = (menuId: string): boolean => {
    if (!menus) return false;

    const childMenus = menus.filter((menu) => menu.upgmId === menuId && menu.useYn === 'Y');
    return childMenus.length > 0;
  };

  const [menuAnchorEl, setMenuAnchorEl] = useState<null | HTMLElement>(null);
  const [bookmarkAnchorEl, setBookmarkAnchorEl] = useState<null | Element>(null);
  const [bookmarkOpen, setBookmarkOpen] = useState(false);
  const { fetchBookMarkMenus } = useBookMarkStore();

  useEffect(() => {
    fetchBookMarkMenus();
  }, [fetchBookMarkMenus]);

  // 더보기 메뉴 클릭 핸들러
  const handleClickMoreMenu = (event: React.MouseEvent<SVGSVGElement, MouseEvent>) => {
    // event.currentTarget을 미리 저장 (React의 이벤트 풀링 대응)
    const target = event.currentTarget;

    // 북마크가 열려있으면 먼저 닫기
    if (bookmarkOpen) {
      setBookmarkOpen(false);
      setBookmarkAnchorEl(null);
    }

    // 더보기 메뉴 토글
    if (menuAnchorEl) {
      setMenuAnchorEl(null);
    } else {
      setMenuAnchorEl(target as unknown as HTMLElement);
    }
  };

  const handleOptionListClose = () => {
    setMenuAnchorEl(null);
  };

  // 북마크 아이콘 클릭 핸들러
  const handleBookmarkClick = (event: React.MouseEvent<SVGSVGElement, MouseEvent>) => {
    // 더보기 메뉴가 열려있으면 먼저 닫기
    if (menuAnchorEl) {
      setMenuAnchorEl(null);
    }

    // 북마크 메뉴 토글
    if (bookmarkOpen) {
      setBookmarkOpen(false);
      setBookmarkAnchorEl(null);
    } else {
      setBookmarkAnchorEl(event.currentTarget);
      setBookmarkOpen(true);
    }
  };

  const handleBookmarkClose = () => {
    setBookmarkOpen(false);
    setBookmarkAnchorEl(null);
  };

  // 북마크 아이템 클릭 핸들러
  const handleBookmarkItemClick = (pgmUrl: string) => {
    // 북마크 메뉴 닫기
    handleBookmarkClose();

    // 페이지 이동
    if (pgmUrl) {
      navigate('/' + pgmUrl);
    }
  };

  // 북마크 삭제 핸들러
  const handleBookmarkDelete = async (event: React.MouseEvent, bookMark: BookMark) => {
    event.stopPropagation(); // 메뉴 아이템 클릭 이벤트 방지
    await removeBookMark(bookMark);
  };

  const listWidth = 220;
  const listStyles = {
    mt: 1,
    border: `1px solid ${color.commonBorderStrong}`,
    borderRadius: '2px',
    boxShadow: '0px 0px 2px 0px rgba(0, 0, 0, 0.17), 0px 4px 5px 0px rgba(0, 0, 0, 0.11)',
  };

  return (
    <Box
      position="relative"
      height={`${headerHeight}px`}
      bgcolor={color.navTopBgBasic}
      display="flex"
      alignItems="center"
      justifyContent="center"
      borderBottom={`1px solid ${color.commonBorderBasic}`}
    >
      {mailId && (
        <>
          {/* 메뉴 영역 */}
          <HeaderLinkList headerMenusNum={headerMenusNum} setIsSidebarOpen={setIsSidebarOpen} />

          {/* 오른쪽 영역 */}
          <Box display="flex" gap="8px" position="absolute" right="0" px="16px">
            {headerMenus.filter((menu) => menu.useYn === 'Y' && menu.menuDispYn === 'Y').length >
              headerMenusNum && (
              <ClickAwayListener onClickAway={handleOptionListClose}>
                <Box>
                  {/* 메뉴 더보기 버튼 */}
                  {headerMenusNum < 10 && (
                    <MenuMoreIcon
                      direction="horizontal"
                      iconSize={24}
                      onClick={handleClickMoreMenu}
                      sx={{
                        cursor: 'pointer',
                        color: color.commonTextLight,
                        backgroundColor: menuAnchorEl
                          ? color.controlLinedBgBasicActive
                          : 'transparent',
                        borderRadius: '2px',
                      }}
                    />
                  )}

                  {/* 메뉴 리스트 */}
                  <Popper
                    open={Boolean(menuAnchorEl)}
                    anchorEl={menuAnchorEl}
                    placement="bottom-end"
                    modifiers={[
                      {
                        name: 'offset',
                        options: {
                          offset: [0, 0],
                        },
                      },
                    ]}
                  >
                    <OptionList
                      width={listWidth}
                      sx={{
                        backgroundColor: 'transparent',
                        zIndex: '101',
                        '& .MuiList-root': {
                          ...listStyles,
                          padding: '8px 0',
                          '& li': {
                            lineHeight: 1.5,
                            '&:hover': {
                              background: color.infoBgSecondary,
                            },
                          },
                        },
                      }}
                      options={headerMenus
                        .filter((menu) => menu.useYn === 'Y' && menu.menuDispYn === 'Y')
                        .filter((menu, index) => index > headerMenusNum - 1)
                        .map((menu) => ({
                          label: menu.pgmName || '',
                          value: menu.pgmId || '',
                        }))}
                      anchorEl={menuAnchorEl}
                      open={Boolean(menuAnchorEl)}
                      type="none"
                      onSelectClick={(value) => {
                        const selectedMenu = headerMenus.find((menu) => menu.pgmId === value);
                        if (selectedMenu) {
                          // 메뉴 선택 후 OptionList 닫기
                          setMenuAnchorEl(null);

                          // 자식 메뉴가 있는지 확인
                          const hasChildren = hasChildMenus(selectedMenu.pgmId);
                          if (typeof setIsSidebarOpen === 'function') {
                            setIsSidebarOpen(true);
                          }
                          // 자식이 있는 경우 사이드 메뉴만 업데이트 (페이지 이동 안함)
                          // 자식이 없는 경우 페이지 이동도 함께 수행
                          menuContext.handleMenuChange({
                            ...menuContext,
                            selectedHeaderMenu: selectedMenu.pgmId,
                            clickedByHeaderMenu: !hasChildren, // 자식이 없을 때만 페이지 이동
                          });
                        }
                      }}
                    />
                  </Popper>
                </Box>
              </ClickAwayListener>
            )}

            {/* 북마크 보기 버튼 */}
            <CommunicationBookmarkIcon
              appearance={bookmarkOpen ? 'filled' : 'lined'}
              iconSize={24}
              onClick={handleBookmarkClick}
              sx={{
                cursor: 'pointer',
                color: bookmarkOpen ? $scale.color.warningMinor500 : color.commonTextLight,
              }}
            />

            {/* 북마크 리스트 */}
            <Popper
              open={bookmarkOpen}
              anchorEl={bookmarkAnchorEl}
              placement="bottom-end"
              sx={{ zIndex: 1300 }}
            >
              <ClickAwayListener onClickAway={handleBookmarkClose}>
                <Paper sx={listStyles}>
                  <MenuList sx={{ padding: '8px 0', width: `${listWidth}px` }}>
                    {bookMarkMenus.length > 0 ? (
                      bookMarkMenus.map((item) => (
                        <MenuItem
                          key={item.pgmId}
                          onClick={() => handleBookmarkItemClick(item.pgmUrl ?? '')}
                          sx={{
                            display: 'flex',
                            gap: '4px',
                            padding: '6px 8px',
                            '&:hover': {
                              backgroundColor: color.infoBgSecondary,
                            },
                          }}
                        >
                          {/* 북마크 아이콘 */}
                          <CommunicationBookmarkIcon
                            appearance="filled"
                            iconSize={16}
                            sx={{ color: $scale.color.warningMinor500 }}
                          />
                          {/* 메뉴명 */}
                          <Typography
                            variant="bodyBasic"
                            sx={{
                              flex: 1,
                              color: color.commonTextBasic,
                              overflow: 'hidden',
                              textOverflow: 'ellipsis',
                              whiteSpace: 'nowrap',
                            }}
                          >
                            {item.pgmName}
                          </Typography>
                          {/* 삭제 아이콘 */}
                          <ControlCloseIcon
                            size="default"
                            iconSize={16}
                            sx={{ color: color.commonTextLight }}
                            onClick={(event) => handleBookmarkDelete(event, item)}
                          />
                        </MenuItem>
                      ))
                    ) : (
                      <MenuItem disabled>북마크가 없습니다</MenuItem>
                    )}
                  </MenuList>
                </Paper>
              </ClickAwayListener>
            </Popper>

            {/* 사용자 정보 */}
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                cursor: 'pointer',
              }}
            >
              <Avatar size="xsmall" contentType="icon" alt={displayEmpNm} />
              <Typography variant="headerAreaUtilMenu">{displayEmpNm}</Typography>
            </Box>
          </Box>
        </>
      )}
    </Box>
  );
}

export { HeaderMenuBar };
