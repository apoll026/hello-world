import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Box, Typography, useTheme } from '@mui/material';
import { useMenuContext } from '@/amxis/components/menu-provider';
import { Menu } from '@/amxis/models/admin/Menu.ts';
import useSessionStore from '@/amxis/stores/useSessionStore.ts';
import { MenuType } from './menu.types.ts';
import { nest } from './main-layout.utils.ts';
import { isEmpty } from 'lodash';

type HeaderLinkListProps = {
  headerMenusNum: number;
  setIsSidebarOpen?: (open: boolean) => void;
};

function HeaderLinkList({ headerMenusNum, setIsSidebarOpen }: HeaderLinkListProps) {
  const {
    palette: { semantic },
  } = useTheme();
  const { headerMenus, menus } = useSessionStore();
  const menuContext = useMenuContext();
  const navigate = useNavigate();
  const { t } = useTranslation();

  // 선택된 메뉴가 자식 메뉴를 가지고 있는지 확인하는 함수
  const hasChildMenus = (menuId: string): boolean => {
    if (!menus) return false;

    const childMenus = menus.filter((menu) => menu.upgmId === menuId && menu.useYn === 'Y');
    return childMenus.length > 0;
  };

  // 최하위 레벨의 첫 번째 활성화된 메뉴를 재귀적으로 찾는 함수
  // 자식이 있는 메뉴는 반환하지 않고 null을 반환하여 페이지 이동 방지
  const findDeepestFirstMenu = (menuType: MenuType): Menu | null => {
    const { menuInfo, children } = menuType;

    // 활성화된 자식 메뉴들을 정렬해서 가져오기
    const activeChildren = children
      .filter((child) => child.menuInfo.useYn === 'Y')
      .sort((a, b) => (a.menuInfo.sortOrd || 0) - (b.menuInfo.sortOrd || 0));

    // 자식이 없거나 모든 자식이 비활성화된 경우 (최하위 메뉴)
    if (activeChildren.length === 0) {
      // 현재 메뉴가 활성화되어 있고 pgmUrl이 있으면 반환
      return menuInfo.useYn === 'Y' && menuInfo.pgmUrl ? menuInfo : null;
    }

    // 자식이 있는 경우 페이지 이동하지 않음 (사이드 메뉴만 열기)
    return null;
  };

  const retrieveMenu = () => {
    if (!menus || !menuContext.selectedHeaderMenu) {
      return '';
    }

    const depth1Menus: Menu[] = menus
      .filter((item) => item.upgmId === menuContext.selectedHeaderMenu)
      .sort((a, b) => (a.sortOrd || 0) - (b.sortOrd || 0));

    // Menu[]를 MenuType[]로 변환하는 헬퍼 함수
    const convertToMenuType = (menus: Menu[]): MenuType[] => {
      return menus.map((menu) => ({
        menuInfo: menu,
        children: convertToMenuType(menu.childrens || []),
      }));
    };

    const newSideMenuList: MenuType[] = [];
    depth1Menus.forEach((item) => {
      const tree = nest(menus, item.pgmId);

      newSideMenuList.push({
        menuInfo: item,
        children: convertToMenuType(tree),
      });
    });

    // 첫 번째 메뉴에서 최하위 레벨의 첫 번째 메뉴 찾기
    if (newSideMenuList.length > 0) {
      return findDeepestFirstMenu(newSideMenuList[0]);
    }

    return null;
  };

  useEffect(() => {
    if (menuContext.clickedByHeaderMenu) {
      const menu = retrieveMenu();

      // 메뉴가 있는 경우에만 페이지 이동 (최하위 메뉴인 경우)
      if (menu && !isEmpty(menu)) {
        navigate('/' + menu.pgmUrl, { replace: false });
      }
      // 메뉴가 없는 경우는 자식이 있는 메뉴이므로 사이드 메뉴만 업데이트됨
    }
  }, [menuContext.selectedHeaderMenu]);

  return (
    <Box display="flex" gap="8px">
      {headerMenus
        ?.filter(
          (menu) => menu.useYn?.toUpperCase() === 'Y' && menu.menuDispYn?.toUpperCase() === 'Y'
        )
        .filter((_, index) => index < headerMenusNum!)
        .map((menu) => (
          <Box
            key={menu.pgmId}
            onClick={() => {
              // 자식 메뉴가 있는지 확인
              const hasChildren = hasChildMenus(menu.pgmId);
              // 자식이 있든 없든 사이드바를 무조건 true로 열기
              if (typeof setIsSidebarOpen === 'function') {
                setIsSidebarOpen(true);
              }
              // 자식이 있는 경우 사이드 메뉴만 업데이트 (페이지 이동 안함)
              // 자식이 없는 경우 페이지 이동도 함께 수행
              menuContext.handleMenuChange({
                ...menuContext,
                selectedHeaderMenu: menu.pgmId,
                clickedByHeaderMenu: !hasChildren, // 자식이 없을 때만 페이지 이동
              });
            }}
            sx={{
              userSelect: 'none',
              cursor: 'pointer',
              borderRadius: '999px',
              backgroundColor:
                menu.pgmId === menuContext.selectedHeaderMenu
                  ? semantic.color.navTopBgMenu
                  : 'transparent',
              padding: '8px 16px',
            }}
          >
            <Typography
              variant="h5"
              sx={{
                color:
                  menu.pgmId === menuContext.selectedHeaderMenu
                    ? semantic.color.navTopTextSysNameSelected
                    : semantic.color.commonTextLight,
                '&:hover': {
                  color:
                    menu.pgmId === menuContext.selectedHeaderMenu
                      ? semantic.color.navTopTextSysNameSelected
                      : semantic.color.navTopTextSysNameBasic,
                },
              }}
            >
              {t(`${menu.msgCtn}`, `${menu.pgmName}`)}
            </Typography>
          </Box>
        ))}
    </Box>
  );
}

export { HeaderLinkList };
