import { Box, SxProps, Typography } from '@mui/material';
import { Theme } from '@mui/system';
import { ReactNode } from 'react';
import { useTheme } from '@amxis/design-system';

// Spacer 정의
type SpacerProps = {
  type?: 'v' | 'h';
  size?: string;
};

export const Spacer = ({ type, size }: SpacerProps) => {
  let height = '0';
  let width = '0';
  let display = 'inline-block';

  switch (type) {
    case 'v':
      height = '100%';
      width = `${size}px`;
      display = 'inline-block';
      break;
    case 'h':
      width = '100%';
      height = `${size}px`;
      display = 'block';
      break;
  }

  return <div style={{ height: height, width: width, display: display }}></div>;
};

type ButtonGroupProps = {
  children?: ReactNode;
  justifyContent?:
    | 'flex-start'
    | 'center'
    | 'flex-end'
    | 'space-between'
    | 'space-around'
    | 'space-evenly';
  sx?: SxProps<Theme>;
};

export const ButtonGroup = ({ children, justifyContent = 'flex-end', sx }: ButtonGroupProps) => {
  return (
    <Box
      display="flex"
      justifyContent={justifyContent}
      gap="4px"
      sx={{
        width: '100%',
        ...sx,
      }}
    >
      {children}
    </Box>
  );
};

type DialogContentContainerProps = {
  children?: ReactNode;
};

export const DialogContentContainer = ({ children }: DialogContentContainerProps) => {
  return <Box sx={{}}>{children}</Box>;
};

type DialogContentProps = {
  children?: ReactNode;
};

export const DialogContent = ({ children }: DialogContentProps) => {
  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        fontSize: '13px',
        fontFamily: 'Spoqa Han Sans Neo',
        lineHeight: '19.5px',
      }}
    >
      {children}
    </div>
  );
};

type DialogButtonGroupProps = {
  children?: ReactNode;
};

export const DialogButtonGroup = ({ children }: DialogButtonGroupProps) => {
  return (
    <>
      <Spacer type="h" size="4" />
      <div
        style={{
          display: 'flex',
          justifyContent: 'flex-end',
          gap: '4px',
          alignItems: 'center',
        }}
      >
        {children}
      </div>
    </>
  );
};

interface ContentFlexProps {
  height?: string | number;
  children?: ReactNode;
}

export const ContentFlex = ({ height = '100%', children }: ContentFlexProps) => {
  return <Box sx={{ display: 'flex', gap: '24px', height: height }}>{children}</Box>;
};

export const GridInfoSection = ({ children }) => {
  return (
    <>
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          height: '28px',
        }}
      >
        <Typography variant="h3">{children}</Typography>
      </Box>
      <Spacer type="h" size="4" />
    </>
  );
};

interface TitleContentsContainerProps {
  isDialog?: boolean;
  gap?: string | number;
  children: ReactNode;
}

export const TitleContentsContainer = ({
  isDialog = false,
  gap = '12px',
  children,
}: TitleContentsContainerProps) => {
  return (
    <Box
      display="flex"
      flexDirection="column"
      gap={gap}
      sx={{
        ...(!isDialog && {
          height: '100%',
        }),
      }}
    >
      {children}
    </Box>
  );
};

interface TitleContentsProps {
  isDialog?: boolean;
  gap?: string | number;
  width?: string | number;
  height?: string | number;
  sx?: SxProps<Theme>;
  children: ReactNode;
}

export const TitleContents = ({
  isDialog = false,
  gap = '4px',
  width,
  height,
  sx,
  children,
}: TitleContentsProps) => {
  const [theme] = useTheme();

  return (
    <Box
      display="flex"
      flexDirection="column"
      gap={gap}
      width={width}
      height={height}
      sx={{
        ...(!isDialog && {
          padding: '16px',
          borderRadius: '12px',
          backgroundColor: theme.palette.semantic.color.commonBgBasic,
        }),
        ...sx,
      }}
    >
      {children}
    </Box>
  );
};

interface DialogContentsContainerProps {
  children: ReactNode;
}

export const DialogContentsContainer = ({ children }: DialogContentsContainerProps) => {
  return (
    <Box display="flex" flexDirection="column" gap="12px">
      {children}
    </Box>
  );
};

interface DialogContentsProps {
  width?: string | number;
  sx?: SxProps<Theme>;
  children: ReactNode;
}

export const DialogContents = ({ width, sx, children }: DialogContentsProps) => {
  return (
    <Box display="flex" flexDirection="column" gap="4px" width={width} sx={sx}>
      {children}
    </Box>
  );
};
