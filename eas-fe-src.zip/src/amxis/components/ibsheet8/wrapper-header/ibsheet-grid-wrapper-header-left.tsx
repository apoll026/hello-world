import { Box, SxProps, Theme, Typography, useTheme } from '@mui/material';
import { RowModelType } from 'ag-grid-community';

import { HelperText } from '@amxis/design-system';
import IBSheetGridPageSizeControl, {
  IBSheetGridPageSizeControlProps,
} from './ibsheet-grid-page-size-control';
import { mergeSx } from '@/amxis/utils/sx-util';

export type LanguageType = 'ko' | 'en' | 'zhC';

export type IBSheetGridWrapperHeaderLeftProps = {
  title?: string;
  gridType?: RowModelType;
  rowCount?: number;
  total?: number;
  hasPageSizeArea?: boolean;
  hasTotalCountArea?: boolean;
  pageSizeControlProps?: IBSheetGridPageSizeControlProps;
  infoText?: string;
  language?: LanguageType;
  sx?: SxProps<Theme>;
};

export const IBSheetGridWrapperHeaderLeft = ({
  title,
  gridType,
  rowCount = 0,
  total = 0,
  hasPageSizeArea = false,
  hasTotalCountArea = true,
  pageSizeControlProps,
  infoText,
  language,
  sx,
}: IBSheetGridWrapperHeaderLeftProps) => {
  const theme = useTheme();

  const headerLeftStyle = mergeSx(
    {
      color: theme.palette.semantic.color.commonTextBasic,
      width: 'fit-content',
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
    },
    sx
  );

  const formatTotal = (total: number) => {
    return total.toLocaleString('ko-KR');
  };

  return (
    <Box sx={headerLeftStyle}>
      <Typography typography="h3" overflow="hidden" whiteSpace="nowrap">
        {title}
      </Typography>

      {hasTotalCountArea && (
        <Box
          display="flex"
          gap="2px"
          color={theme.palette.semantic.color.commonTextBasic}
          typography="bodyBasic"
        >
          <Typography variant="bodyXlarge">{language === 'en' ? 'Total' : '총'}</Typography>
          {gridType === 'infinite' ? (
            <>
              <Typography color={theme.palette.semantic.color.commonTextPrimary}>
                {rowCount}
              </Typography>
              <Typography color={theme.palette.semantic.color.commonTextLighter}>/</Typography>
              <Typography color={theme.palette.semantic.color.commonTextLighter}>
                {formatTotal(total)}
              </Typography>
            </>
          ) : (
            <>
              <Typography
                variant="bodyXlarge"
                color={theme.palette.semantic.color.commonTextSecondary}
              >
                {formatTotal(total)}
              </Typography>
              <Typography variant="bodyXlarge">{language === 'en' ? 'rows' : '건'}</Typography>
            </>
          )}
        </Box>
      )}

      {hasPageSizeArea && total !== 0 && <IBSheetGridPageSizeControl {...pageSizeControlProps} />}
      {infoText && <HelperText infoText={infoText} leadingIcon />}
    </Box>
  );
};

export default IBSheetGridWrapperHeaderLeft;
