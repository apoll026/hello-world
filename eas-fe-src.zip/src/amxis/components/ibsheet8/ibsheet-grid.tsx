import React, { forwardRef, useEffect, useImperativeHandle, useRef } from 'react';
import loader from '@ibsheet/loader';
import { Box } from '@mui/material';
import IBSheetGridWrapperHeader from './wrapper-header/ibsheet-grid-wrapper-header';
import { IBSheetGridHeaderRightMember } from './wrapper-header/ibsheet-grid-wrapper-header-right';
import { Sheet, SheetOptions } from '@/amxis/models/common/Ibsheet';
import { useTheme } from '@mui/system';
import { $semantic } from '@amxis/design-system';

export interface IBSheetGridProps {
  isHeaderSectionEnabled: boolean;
  id: string;
  el: string;
  options: SheetOptions;
  data?: any[];
  width?: string;
  minHeight?: string;
  maxHeight?: string;
  height?: string;
  title?: string;
  headerButton?: IBSheetGridHeaderRightMember[];
  total?: number;
  hasPageSizeArea?: boolean;
  infoText?: string;
}

export interface IBSheetGridRef {
  getSheet: () => Sheet | null;
}

// eslint-disable-next-line react/display-name
const IBSheetGrid = forwardRef<IBSheetGridRef, IBSheetGridProps>(
  (
    {
      id,
      el,
      options,
      title,
      width = '100%',
      minHeight = '103px', // 화면 크기 작으면 그리드 안뜨는 이슈 대응
      maxHeight,
      height,
      isHeaderSectionEnabled = true,
      headerButton,
      hasPageSizeArea = false,
      total,
      infoText,
    },
    ref
  ) => {
    const {
      palette: {
        semantic: { color },
      },
    } = useTheme();
    const sheetRef = useRef<Sheet | null>(null);

    useEffect(() => {
      loader.createSheet({ id, el, options }).then(() => {
        sheetRef.current = loader.getIBSheetStatic();
      });

      return () => {
        loader.removeSheet(id);
      };
    }, []);

    // 외부에 IBSheet 인스턴스 getter 제공
    useImperativeHandle(ref, () => ({
      getSheet: () => sheetRef.current,
    }));

    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', flexGrow: 1 }}>
        {isHeaderSectionEnabled && (
          <IBSheetGridWrapperHeader
            left={{ title, hasPageSizeArea, total, infoText }}
            right={{ buttonFamily: headerButton }}
          />
        )}
        <Box
          sx={{
            width,
            minHeight,
            ...(maxHeight && { maxHeight }),
            ...(height ? { height } : { flex: 1 }),
            position: 'relative',
            borderRadius: `${$semantic.shared.radius.radiusTable}px`,
            overflow: 'hidden',
            '&::before': {
              content: '""',
              position: 'absolute',
              inset: 0,
              border: `1px solid ${color.commonBorderBasic}`,
              borderRadius: 'inherit',
              pointerEvents: 'none',
              zIndex: 1, // 배경색보다 위로
            },
          }}
        >
          <Box
            id={el}
            sx={{
              height: '100% !important',
              overflow: 'visible !important', // 그리드 border 안보이는 이슈 대응
            }}
          />
        </Box>
      </Box>
    );
  }
);

export default IBSheetGrid;
