import { Box, useTheme } from '@mui/system';
import { Typography } from '@mui/material';
import { ModalType } from '@/amxis/stores/useCommonDialogStore.ts';
import React from 'react';
import { useTranslation } from 'react-i18next';
import { StatusWarningIcon } from '@amxis/design-system/icon';

/**
 @param {ModalType} modalType : Dialog 타입
 @param {string} title : Dialog에 들어갈 제목
 */

interface ICustomDialogTitleProps {
  modalType: ModalType;
  title?: string | null;
}

const CustomDialogTitle = ({ modalType, title }: ICustomDialogTitleProps) => {
  const { t } = useTranslation();
  const {
    palette: {
      semantic: { color },
    },
  } = useTheme();

  const getColor = () => {
    switch (modalType) {
      case 'warning':
        return color.commonTextWarningMajor;
      case 'error':
        return color.commonTextError;
      default:
        return color.commonTextPrimaryExtreme;
    }
  };

  return (
    <Box
      display="flex"
      alignItems="center"
      gap={modalType === 'warning' || modalType === 'error' ? '4px' : '8px'}
      py="2px"
    >
      {/* 아이콘 */}
      {modalType === 'alert' || modalType === 'confirm' ? (
        <Box
          sx={{
            width: '8px',
            height: '8px',
            borderRadius: '0.5rem',
            backgroundColor: getColor(),
          }}
        />
      ) : (
        <StatusWarningIcon
          appearance="filled"
          iconSize={20}
          sx={{
            color: modalType === 'warning' ? color.commonTextWarningMajor : color.commonTextError,
          }}
        />
      )}

      {/* 타이틀 */}
      <Typography variant="h2" color={getColor()}>
        {title ?? t('common.title.알림', '__알림')}
      </Typography>
    </Box>
  );
};

export default CustomDialogTitle;
