/** @jsxImportSource @emotion/react */
import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Controller, useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import _ from 'lodash';

import { Message, MessageInfo } from '@/amxis/models/admin/Message.ts';
import { CommonYN } from '@/amxis/models/common/Common.ts';
import { CrudCode } from '@/amxis/models/common/Edit.ts';

import { useCommonCodeNamesQuery } from '@/amxis/hooks/queries/common/use-common-code-names-query.ts';
import { useMessagesMsgCtnQuery } from '@/amxis/hooks/queries/message/use-messages-msgCtn-query.ts';
import { useSaveMessagesMutate } from '@/amxis/hooks/queries/message/use-save-messages-mutate.ts';

import useLanguageStore from '@/amxis/stores/useLanguageStore.ts';
import { useMessageModalStore } from '@/amxis/stores/useMessageModalStore.ts';

import CustomDialogTitle from '@/amxis/components/modals/common/CustomDialogTitle.tsx';

import {
  DialogButtonGroup,
  DialogContentContainer,
  DialogContent,
  Spacer,
} from '@/amxis/components/layout/layouts.tsx';
import {
  Button,
  DetailTableDataCell,
  DetailTableHeaderCell,
  DetailTableLine,
  DetailTableRow,
  Dialog,
  HelperText,
  InputField,
  Label,
  Switch,
  TitleArea,
  useMessageBar,
  DropdownField,
  DropdownOption,
} from '@amxis/design-system';
import { ControlConfirmIcon } from '@amxis/design-system/icon';
import { Box } from '@mui/material';
import { useCommonDialogStore } from '@/amxis/stores/useCommonDialogStore.ts';
export const MessageModal = () => {
  const { t } = useTranslation();
  const { currentLanguage } = useLanguageStore();
  const { openCommonDialog } = useCommonDialogStore();
  const { showMessageBar } = useMessageBar();
  const { isOpen, msgCtn, koMessage, yesCallback, noCallback, setMessageModalStateWhenModalClose } =
    useMessageModalStore();

  const dropDownOption = [{label:'코드명칭', value:'C'},{label:'화면용레벨', value:'L'},{label:'Alert메시지', value:'A'},{label:'에러메시지', value:'E'},{label:'안내메시지', value:'I'},{label:'그리드헤더', value:'G'},{label:'AMXIS', value:'AMXIS'}];

  const messageModalSchema = z.object({
    msgCtn: z
      .string()
      .min(
        1,
        `${t(`common.label.{{}}를 입력해 주세요.`, `__{{inputTarget}}를 입력해 주세요.`, {
          inputTarget: `${t('message.label.메시지코드', '메시지코드')}`,
        })}`
      )
      .transform((val) => val.trimEnd())
      .refine((val) => !/^\s/.test(val), {
        message: String(
          t(
            'common.alert.공백으로 시작하는 코드는 등록할 수 없습니다.',
            '__공백으로 시작하는 코드는 등록할 수 없습니다.'
          )
        ),
      }),
    msgTxtCtn1: z.string().min(1),
    msgTxtCtn2: z.string().min(1).optional(),
    msgTxtCtn3: z.string().min(1).optional(),
    msgTxtCtn4: z.string().min(1).optional(),
    msgTxtCtn5: z.string().min(1).optional(),
    rmk: z.string().optional(),
    useYn: z.enum([CommonYN.Y, CommonYN.N]),
    optValCtn1: z
      .string()
      .min(
        1,
        `${t('A00002', '메시지유형을 선택하세요',{'P1':'메시지유형'})}`
      ),
  });
  type MessageModalForm = z.infer<typeof messageModalSchema>;

  const {
    data: fetchedLanguageCode,
    isFetched: isLanguageFetched,
    refetch: refetchLanguageCode,
  } = useCommonCodeNamesQuery('LANG_CD');
  const {
    data: fetchedMessageData,
    isFetched: isMsgCtnFetched,
    refetch: refetchMessageData,
  } = useMessagesMsgCtnQuery(
    {
      msgCtn: msgCtn,
    },
    isLanguageFetched
  );
  const { status: status, mutate: saveMessages } = useSaveMessagesMutate();
  const [messages, setMessages] = useState<Message[]>([]);

  useEffect(() => {
    if (isLanguageFetched) {
      refetchLanguageCode();
    }
  }, [currentLanguage]);

  const {
    handleSubmit,
    control,
    formState: { errors },
    getValues,
    setValue,
    reset,
  } = useForm<MessageModalForm>({
    resolver: zodResolver(messageModalSchema),
    defaultValues: {
      optValCtn1:'',
      msgCtn: '',
      msgTxtCtn1: '',
      msgTxtCtn2: '',
      msgTxtCtn3: '',
      msgTxtCtn4: '',
      msgTxtCtn5: '',
      rmk: '',
      useYn: CommonYN.Y,
    },
  });

  const setFormDefaultValues = (messageInfo: MessageInfo) => {
    setValue('optValCtn1', messageInfo.optValCtn1);
    setValue('msgCtn', messageInfo.msgCtn);
    setValue('msgTxtCtn1', messageInfo.msgTxtCtn1);
    setValue('msgTxtCtn2', messageInfo.msgTxtCtn2);
    setValue('msgTxtCtn3', messageInfo.msgTxtCtn3);
    setValue('msgTxtCtn4', messageInfo.msgTxtCtn4);
    setValue('msgTxtCtn5', messageInfo.msgTxtCtn5);
    setValue('rmk', messageInfo.rmk);
    setValue('useYn', messageInfo.useYn);
  };

  useEffect(() => {
    if (isOpen) {
      let initMessage = {
        optValCtn1:'',
        msgCtn: '',
        msgTxtCtn1: '',
        msgTxtCtn2: undefined,
        msgTxtCtn3: undefined,
        msgTxtCtn4: undefined,
        msgTxtCtn5: undefined,
        rmk: '',
        useYn: CommonYN.Y,
      } as MessageInfo;
      if (isLanguageFetched && isMsgCtnFetched) {
        if (
          fetchedLanguageCode !== null &&
          fetchedLanguageCode !== undefined &&
          fetchedMessageData
        ) {
          if (msgCtn && (_.isEmpty(fetchedLanguageCode) || _.isEmpty(fetchedMessageData))) {
            refetchMessageData().then((result) => {
              if (!result.data || result.data?.length === 0) {
                openCommonDialog({
                  modalType: 'confirm',
                  content: t(
                    'message-management.confirm.해당하는 메시지코드가 없습니다. 추가하시겠습니까?',
                    '__해당하는 메시지코드가 없습니다. 추가하시겠습니까?'
                  ),
                  onClose: () => {
                    setMessageModalStateWhenModalClose();
                    return;
                  },
                });
              }
            });
          }

          initMessage = {
            ...initMessage,
            optValCtn1: fetchedMessageData[0]?.optValCtn1 ?? '',
            msgCtn: msgCtn ?? '',
            useYn: fetchedMessageData[0]?.useYn ?? CommonYN.Y,
            rmk: fetchedMessageData[0]?.rmk ?? '',
          };

          for (let i = 0; i < fetchedLanguageCode.length; i++) {
            const languageCode = fetchedLanguageCode[i].cmnCd ?? '';
            const foundMessageByLanguageCode = fetchedMessageData.filter(
              (message) => message.langCd === languageCode
            );

            if (foundMessageByLanguageCode.length !== 0) {
              initMessage[`msgTxtCtn${i + 1}`] = foundMessageByLanguageCode[0].msgTxtCtn ?? '';
            } else {
              initMessage[`msgTxtCtn${i + 1}`] = '';
            }
          }
          if (koMessage && koMessage !== '') {
            initMessage['msgTxtCtn1'] = koMessage;
          }
        }
      }
      setFormDefaultValues(initMessage);
    }
  }, [isOpen, fetchedLanguageCode, isLanguageFetched, fetchedMessageData, isMsgCtnFetched]);

  useEffect(() => {
    if (fetchedMessageData !== null && fetchedMessageData !== undefined) {
      setMessages(fetchedMessageData);
    }
  }, [fetchedMessageData]);

  const handleNoButtonClick = useCallback(async () => {
    setMessageModalStateWhenModalClose();
    if (noCallback) {
      noCallback();
    }
    reset();
  }, [noCallback, setMessageModalStateWhenModalClose]);

  const handleYesButtonClick = handleSubmit(async () => {
    const { optValCtn1, rmk, useYn, msgCtn, ...restOfMsgTxtCtn } = getValues();

    const messagesToSave = [] as Message[];

    fetchedLanguageCode?.map((language, index) => {
      const targetLangCd = language.cmnCd || '';
      const targetMsgTxtCtn = _.get(restOfMsgTxtCtn, `msgTxtCtn${index + 1}`);
      messagesToSave.push({
        crudKey: _.isEmpty(messages.find((message) => message.langCd === targetLangCd))
          ? CrudCode.CREATE
          : CrudCode.UPDATE,
        msgCtn: msgCtn,
        langCd: targetLangCd,
        msgTxtCtn: targetMsgTxtCtn || '',
        rmk: rmk || '',
        useYn: useYn === CommonYN.N ? CommonYN.N : CommonYN.Y,
        optValCtn1: optValCtn1 || '',
        optValCtn2: null,
        optValCtn3: null,
        dataInsUserId: null,
        dataInsUserIp: null,
        dataInsDtm: null,
        dataUpdUserId: null,
        dataUpdUserIp: null,
        dataUpdDtm: null,
        langCdList: null,
        msgTxtCtnList: null,
        dataUpdDtmList: null,
        dataUpdUserIdList: null,
        useYnList: null,
        optValCtn1List: null,
      });
    });

    saveMessages(messagesToSave, {
      onSuccess: () => {
        showMessageBar({
          message: t('common.alert.저장되었습니다.', '__저장되었습니다.'),
          multipleLines: true,
          usecase: 'success',
        });
        setMessageModalStateWhenModalClose();
        if (yesCallback) {
          const formMsgCtn = [getValues('msgTxtCtn1'), getValues('msgCtn')];
          reset();
          yesCallback(formMsgCtn);
        }
      },

      onError: (error) => {
        
        const statusCode = (error.response?.data as any)?.statusCode;
        
        if (statusCode === 'DUPLICATED_VALUE_ERROR') {
          showMessageBar({
            message: t(
              'message-management.alert.중복 된 메시지코드입니다.',
              '__중복 된 메시지코드입니다.'
            ),
            multipleLines: true,
            usecase: 'error',
          });
        } else {
          showMessageBar({
            message: t(
              'message-management.alert.저장 중 오류가 발생했습니다.',
              '__저장 중 오류가 발생했습니다..'
            ),
            multipleLines: true,
            usecase: 'error',
          });
        }
      },
    });
  });

  return (
    <>
      {isOpen && (
        <Dialog
          customHeaderTitle={
            <CustomDialogTitle title={t('message-management.title.메시지 관리', '__메시지 관리')} />
          }
          position="basic"
          type={'modal'}
          size={800}
          open={isOpen}
          handleClose={handleNoButtonClick}
          customContentArea={
            <DialogContentContainer>
              {!msgCtn ? (
                <TitleArea isSubTitle title={t('common.label.메시지등록', '__메시지등록')} />
              ) : (
                <TitleArea isSubTitle title={t('common.label.메시지수정', '__메시지수정')} />
              )}
              <Spacer type="h" size="4" />
              <DialogContent>
                <DetailTableLine>
                  <DetailTableRow>
                    <DetailTableHeaderCell>
                      <Label
                        labelText={`${t('message-management.label.메시지유형', '메시지유형')}`}
                        isRequired
                      />
                    </DetailTableHeaderCell>
                    <DetailTableDataCell>
                      
                      <Controller
                        control={control}
                        name="optValCtn1"
                        render={({ field }) => (
                          <DropdownField
                            fullWidth
                            status={errors?.optValCtn1?.message ? 'error' : 'default'}
                            options={dropDownOption}
                            size="medium"
                            placeholder="선택하세요."
                            isInput={false}
                            onChange={(_, value) => {
                              if (typeof value === 'object' && value !== null && 'value' in value) {
                                const extractedValue = typeof value === "object" && value !== null && "value" in value ? value.value : value;
                                field.onChange(extractedValue); // formData.pgmId에 값 설정
                              }
                            }}
                            value={dropDownOption.find(opt => opt.value === field.value) ?? null}
                          />
                        )}
                      />
                      
                      <Box mt="4px">
                        <HelperText infoText={errors?.optValCtn1?.message ?? ''} usecase="error" />
                      </Box>
                    </DetailTableDataCell>
                  </DetailTableRow>
                  <DetailTableRow>
                    <DetailTableHeaderCell>
                      <Label
                        labelText={`${t('message-management.label.메시지코드', '__메시지코드')}`}
                        isRequired
                      />
                    </DetailTableHeaderCell>
                    <DetailTableDataCell>
                      {!msgCtn ? (
                        <Controller
                          control={control}
                          name="msgCtn"
                          render={({ field }) => (
                            <InputField
                              value={field.value}
                              onChange={field.onChange}
                              id="msgCtn"
                              size="small"
                              fullWidth
                              status={errors?.msgCtn?.message ? 'error' : 'default'}
                              placeholder={`${t(
                                `common.label.{{}}를 입력하세요.`,
                                `__{{inputTarget}}를 입력하세요.`,
                                {
                                  inputTarget: `${t('message.label.메시지코드', '메시지코드')}`,
                                }
                              )}`}
                            />
                          )}
                        />
                      ) : (
                        <div style={{ fontSize: '0.8125rem' }}>{msgCtn}</div>
                      )}
                      <Box mt="4px">
                        <HelperText infoText={errors?.msgCtn?.message ?? ''} usecase="error" />
                      </Box>
                    </DetailTableDataCell>
                  </DetailTableRow>
                  {isLanguageFetched &&
                    fetchedLanguageCode &&
                    fetchedLanguageCode.map((languageCode, index) => {
                      const langName = languageCode.cmnCdNm;
                      return (
                        <tr key={`msgTxtCtn${index + 1}`}>
                          <DetailTableHeaderCell>
                            <Label
                              labelText={`${t('message.label.메시지', '메시지')}-${langName}`}
                              isRequired
                            />
                          </DetailTableHeaderCell>
                          <DetailTableDataCell>
                            <Controller
                              control={control}
                              name={
                                `msgTxtCtn${index + 1}` as
                                  | 'msgTxtCtn1'
                                  | 'msgTxtCtn2'
                                  | 'msgTxtCtn3'
                                  | 'msgTxtCtn4'
                                  | 'msgTxtCtn5'
                              }
                              render={({ field }) => (
                                <InputField
                                  value={field.value}
                                  onChange={field.onChange}
                                  id={`msgTxtCtn${index + 1}`}
                                  size="small"
                                  fullWidth
                                  status={
                                    errors?.[`msgTxtCtn${index + 1}`] &&
                                    errors[`msgTxtCtn${index + 1}`]?.message
                                      ? 'error'
                                      : 'default'
                                  }
                                  placeholder={`${t(
                                    `common.label.{{}}를 입력하세요.`,
                                    `__{{inputTarget}}를 입력하세요.`,
                                    {
                                      inputTarget: `${t(
                                        'message.label.메시지',
                                        '메시지'
                                      )}-${langName}`,
                                    }
                                  )}`}
                                />
                              )}
                            />
                            <Box mt="4px">
                              <HelperText
                                infoText={
                                  errors?.[`msgTxtCtn${index + 1}`] &&
                                  errors[`msgTxtCtn${index + 1}`]?.message
                                    ? `${t(
                                        `common.label.{{}}를 입력해 주세요.`,
                                        `__{{inputTarget}}를 입력해 주세요.`,
                                        {
                                          inputTarget: `${t(
                                            'message.label.메시지',
                                            '메시지'
                                          )}-${langName}`,
                                        }
                                      )}`
                                    : ''
                                }
                                usecase="error"
                              />
                            </Box>
                          </DetailTableDataCell>
                        </tr>
                      );
                    })}
                  <DetailTableRow>
                    <DetailTableHeaderCell>
                      <Label labelText={`${t('message-management.label.비고', '__비고')}`} />
                    </DetailTableHeaderCell>
                    <DetailTableDataCell>
                      <Controller
                        control={control}
                        name="rmk"
                        render={({ field }) => (
                          <InputField
                            value={field.value}
                            onChange={field.onChange}
                            id="rmk"
                            size="small"
                            fullWidth
                            placeholder={`${t(
                              `common.label.{{}}를 입력하세요.`,
                              `__{{inputTarget}}를 입력하세요.`,
                              {
                                inputTarget: `${t('message-management.label.비고', '비고')}`,
                              }
                            )}`}
                          />
                        )}
                      />
                    </DetailTableDataCell>
                  </DetailTableRow>
                  <DetailTableRow>
                    <DetailTableHeaderCell>
                      <Label
                        labelText={`${t('message-management.label.사용여부', '__사용여부')}`}
                      />
                    </DetailTableHeaderCell>
                    <DetailTableDataCell>
                      <Controller
                        control={control}
                        name="useYn"
                        render={({ field: { value, onChange } }) => (
                          <Switch
                            id="useYn"
                            type="basic"
                            value={value}
                            label={t('common.option.사용', '__사용') as string}
                            checked={value === CommonYN.Y}
                            onChange={() => {
                              onChange(value === CommonYN.Y ? CommonYN.N : CommonYN.Y);
                            }}
                          />
                        )}
                      />
                    </DetailTableDataCell>
                  </DetailTableRow>
                </DetailTableLine>
              </DialogContent>
              <DialogButtonGroup>
                <Button
                  appearance="outlined"
                  priority="normal"
                  size="medium"
                  onClick={handleNoButtonClick}
                  buttonLabel={t('common.button.닫기', '__닫기')}
                />
                <Button
                  appearance="contained"
                  priority="primary"
                  size="medium"
                  onClick={handleYesButtonClick}
                  iconComponent={<ControlConfirmIcon size="small" />}
                  autoFocus
                  buttonLabel={t('common.button.저장', '__저장')}
                />
              </DialogButtonGroup>
            </DialogContentContainer>
          }
        />
      )}
    </>
  );
};
