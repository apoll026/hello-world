import { Session } from '@/amxis/models/common/Session.ts';
import {
  CommonRequest,
  CommonResponse,
  DmlResponse,
  Method,
  ServiceName,
} from '@/amxis/models/common/RestApi.ts';
import { callApi } from '@/amxis/utils/ApiUtil.ts';
import { BookMark, Menu } from '../models/admin/Menu';

export const devLogin = async (mailId: string, langCd: string) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/dev/login`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: { mailId: mailId, langCd: langCd },
  };
  const response: CommonResponse<Session> = await callApi(request);

  return response;
};

export const sendCertNumber = async (mailId: string, userPass: string, langCd: string) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/verify/sendCertNumber`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: { mailId: mailId, userPass: userPass, langCd: langCd },
  };
  const response: CommonResponse<Session> = await callApi(request);

  return response;
};

export const checkCertNumber = async (mailId: string, authCode: string, langCd: string) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/verify/checkCertNumber`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: { mailId: mailId, authCode: authCode, langCd: langCd },
  };
  const response: CommonResponse<Session> = await callApi(request);

  return response;
};

export const checkAdminIp = async () => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/v1/verify/checkAdminIp`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };
  const response: CommonResponse<any> = await callApi(request);

  return response;
};

export const getSession = async () => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/v1/session`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };
  const response: CommonResponse<Session> = await callApi(request);

  return response;
};

export const getBookMarkMenus = async () => {
  const request: CommonRequest = {
    method: Method.GET,
    url: `/bookmark`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
  };
  const response: CommonResponse<Menu[]> = await callApi(request);
  return response;
};

export const insertBookMark = async (bookMarkMenus: BookMark) => {
  const request: CommonRequest = {
    method: Method.POST,
    url: `/bookmark`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: bookMarkMenus,
  };
  const response: CommonResponse<DmlResponse> = await callApi(request);
  return response.successOrNot === 'Y' ? response.data : null;
};
export const deleteBookMark = async (bookMarkMenus: BookMark) => {
  const request: CommonRequest = {
    method: Method.PUT,
    url: `/bookmark`,
    serviceName: ServiceName.YOUR_BACK_END_SERVICE_NAME,
    bodyParams: bookMarkMenus,
  };
  const response: CommonResponse<DmlResponse> = await callApi(request);
  return response.successOrNot === 'Y' ? response.data : null;
};
