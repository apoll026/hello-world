import { useNavigate } from 'react-router';
import {
  Button,
  DetailTableDataCell,
  DetailTableHeaderCell,
  DetailTableLine,
  DetailTableRow,
  HelperText,
  InputField,
  Label,
  useMessageBar,
  useTheme,
} from '@amxis/design-system';
import { Box, FormControl, MenuItem, Select, Typography } from '@mui/material';
import { Login } from '@mui/icons-material';

import * as z from 'zod';
import { Controller, useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useLoginMutation } from '@/amxis/hooks/queries/login/use-login-mutation.ts';
import { useSendCertNumberMutation } from '@/amxis/hooks/queries/login/use-send-cert-number-mutation.ts';
import { useCheckCertNumberMutation } from '@/amxis/hooks/queries/login/use-check-cert-number-mutation.ts';
import { useCheckAdminIpMutation } from '@/amxis/hooks/queries/login/use-check-admin-ip-mutation.ts';
import { useLoading } from '@/amxis/components/loader';
import useLanguageStore from '@/amxis/stores/useLanguageStore.ts';
import useSessionStore from '@/amxis/stores/useSessionStore.ts';
import { LanguageCode } from '@/amxis/models/common/Session.ts';
import { useEffect, useRef, useState } from 'react';
import { Code } from '@/amxis/models/common/CommonCode.ts';

const languages: Code[] = [
  {
    cmnCd: LanguageCode.ko,
    cmnCdNm: 'KOR',
  },
  {
    cmnCd: LanguageCode.en,
    cmnCdNm: 'ENG',
  },
  {
    cmnCd: LanguageCode.zhC,
    cmnCdNm: 'CHN',
  },
];

const createLoginSchema = (isPassVerify: boolean) => {
  const baseSchema = {
    mailId: z
      .string({
        required_error: '사용자ID를 반드시 입력하세요.', // non undefined
      })
      .min(1, '사용자ID를 반드시 입력하세요.'), // non empty string
    langCd: z
      .nativeEnum(LanguageCode, {
        required_error: '언어를 반드시 선택하세요.',
      })
      .or(z.string().min(1, '언어를 반드시 선택하세요.')),
  };

  if (isPassVerify) {
    return z.object({
      ...baseSchema,
      userPass: z.string().optional(),
      authCode: z.string().optional(),
    });
  } else {
    return z.object({
      ...baseSchema,
      userPass: z
        .string({
          required_error: '비밀번호를 반드시 입력하세요.', // non undefined
        })
        .min(1, '비밀번호를 반드시 입력하세요.'), // non empty string
      authCode: z.string().optional(),
    });
  }
};

const loginSchema = createLoginSchema(`${process.env.NODE_ENV}` === 'local');
type LoginForm = z.infer<typeof loginSchema>;

function LoginPage() {
  const appEnv = `${process.env.NODE_ENV}`;

  // 인증을 통과할 Env 설정 (임시로 dev 허용)
  const isPassVerify = appEnv === 'local' || appEnv === 'dev';

  const [authStep, setAuthStep] = useState<'password' | 'authCode'>('password');
  const [isIpVerified, setIsIpVerified] = useState(false);

  const [theme] = useTheme();
  const { setSession } = useSessionStore();
  const { changeLanguage } = useLanguageStore();
  const navigate = useNavigate();
  const { openLoading } = useLoading();
  const { mutateAsync: loginAsync } = useLoginMutation();
  const { mutateAsync: sendCertNumberAsync } = useSendCertNumberMutation();
  const { mutateAsync: checkCertNumberAsync } = useCheckCertNumberMutation();
  const { mutateAsync: checkAdminIpAsync } = useCheckAdminIpMutation();
  const { showMessageBar } = useMessageBar();
  const msgCtn = useRef<String>('');

  // IP 검증 함수
  const checkAdminIp = async () => {
    try {
      if (isPassVerify) {
        setIsIpVerified(true);
        return;
      }

      const response = await checkAdminIpAsync();

      if (response.successOrNot === 'Y') {
        setIsIpVerified(true);
      } else {
        navigate('/errorPage', { replace: true });
      }
    } catch (error) {
      console.error('IP 검증 중 오류 발생:', error);
      navigate('/errorPage', { replace: true });
    }
  };

  // 컴포넌트 마운트 시 IP 검증 수행
  useEffect(() => {
    checkAdminIp();
  }, []);

  const {
    handleSubmit,
    control,
    formState: { errors },
    watch,
  } = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      mailId: isPassVerify ? '' : '',
      userPass: isPassVerify ? 'a' : '',
      langCd: 'KOR',
      authCode: '',
    },
  });

  const watchedValues = watch();

  const getLanguageCode = (langCd: string) => {
    switch (langCd) {
      case 'ENG':
        return 'en';
      case 'CMN':
        return 'zhC';
      default:
        return 'ko';
    }
  };

  // 인증번호 요청 함수
  const handleRequestAuthCode = async () => {
    if (!watchedValues.mailId || !watchedValues.userPass) {
      showMessageBar({
        message: 'ID와 패스워드를 모두 입력해주세요.',
        usecase: 'error',
      });
      return;
    }

    try {
      openLoading(true);

      // 인증번호 발송 API 호출 (로컬이 아닌 경우)
      const langCd = getLanguageCode(watchedValues.langCd);
      const certData = {
        mailId: watchedValues.mailId,
        userPass: watchedValues.userPass,
        langCd: langCd,
      };

      const response = await sendCertNumberAsync(certData);

      if (response.successOrNot !== 'Y' || !response?.data) {
        // 실패시 기존 메시지 유지
        showMessageBar({
          message: '로그인에 실패하였습니다.',
          usecase: 'error',
        });
        return;
      }

      // 인증번호 발송 성공시 인증번호 입력 단계로 이동
      setAuthStep('authCode');
      showMessageBar({
        message: '인증번호가 발송되었습니다.',
        usecase: 'success',
      });
    } catch (e) {
      console.log({ e });
      showMessageBar({
        message: '인증번호 발송 중 오류가 발생했습니다.',
        usecase: 'error',
      });
    } finally {
      openLoading(false);
    }
  };

  const onSubmit = handleSubmit(async ({ mailId, langCd, authCode }) => {
    // 로컬 환경이 아니고 인증번호 단계에서 인증번호가 없으면 리턴
    if (!isPassVerify && authStep === 'authCode' && !authCode) {
      showMessageBar({
        message: '인증번호를 입력해주세요.',
        usecase: 'error',
      });
      return;
    }

    try {
      langCd = getLanguageCode(langCd);
      openLoading(true);
      // setSession({ mailId: mailId });

      let response;

      if (isPassVerify) {
        // 로컬 환경에서는 패스워드 없이 dev 로그인
        const loginData = { mailId, langCd };
        response = await loginAsync(loginData);

        if (response.successOrNot !== 'Y' || !response?.data) {
          showMessageBar({
            message: '로그인에 실패하였습니다.',
            usecase: 'error',
          });
          return;
        }
      } else {
        // 로컬이 아닌 경우에는 인증번호 확인 API 호출
        const checkCertData = { mailId, authCode: authCode!, langCd };
        response = await checkCertNumberAsync(checkCertData);

        if (response.successOrNot !== 'Y' || !response?.data) {
          showMessageBar({
            message: '인증에 실패하였습니다.',
            usecase: 'error',
          });
          return;
        }
      }

      const session = response.data;

      // if (useSessionStore.getState().mailId != session.mailId) {
      //   msgCtn.current = '로그인에 실패하였습니다.';
      //   throw new Error('로그인에 실패하였습니다.');
      // }

      changeLanguage(session.langCd || 'ko');

      setSession(session);

      document.cookie = 'NEW_WIN=; path=/; max-age=0'; // 개인별접근권한조회에서 만든 쿠키가 있다면 로그인 시 삭제

      //우선 firstPage는 "/"가 있는 session.menus의 첫번째 url이고,만약 없다면 menus.menu ==="" 를 제외한 첫번쨰 "/"가 없는 url로 지정
      navigate('/', { replace: false });
    } catch (e) {
      console.log({ e });
      showMessageBar({
        message: msgCtn.current,
        usecase: 'error',
      });
    } finally {
      openLoading(false);
    }
  });

  return (
    <Box
      sx={{ margin: '0 auto', paddingTop: '160px' }}
      bgcolor={theme.palette.semantic.color.commonBgDeeper}
    >
      {isIpVerified && (
        <Box display="flex" flexDirection="column" justifyContent="center">
          <Box sx={{ width: '450px', margin: '0 auto' }}>
            <Typography variant="h2" textAlign="center" fontSize="24px" lineHeight="150%">
              표준프레임워크 로그인
            </Typography>
            <form onSubmit={onSubmit}>
              <Box
                mt="10px"
                px="24px"
                py="16px"
                minWidth="364px"
                bgcolor={theme.palette.semantic.color.commonBgBasic}
                boxShadow="0px 7px 10px 0px rgba(0, 0, 0, 0.12), 0px 0px 2px 0px rgba(0, 0, 0, 0.22)"
                display="flex"
                flexDirection="column"
              >
                {/* ID 입력 */}
                <Box display="flex" alignItems="center">
                  <Label
                    htmlFor="mailId"
                    labelText="ID"
                    textAlign="left"
                    minWidth="80px"
                    isRequired
                  />
                  <Box ml="8px" flex="1">
                    <Controller
                      control={control}
                      name="mailId"
                      render={({ field }) => (
                        <InputField
                          value={field.value}
                          onChange={field.onChange}
                          id="mailId"
                          autoComplete={'username'}
                          size="small"
                          fullWidth
                          placeholder="ID를 입력하세요."
                          disabled={!isPassVerify && authStep === 'authCode'}
                        />
                      )}
                    />
                    <Box mt="4px">
                      <HelperText infoText={errors?.mailId?.message ?? ''} usecase="error" />
                    </Box>
                  </Box>
                </Box>

                {/* 패스워드 입력 - 로컬 환경이 아닐 때만 표시 */}
                {!isPassVerify && (
                  <Box mt="8px" display="flex" alignItems="center">
                    <Label
                      htmlFor="userPass"
                      labelText="패스워드"
                      textAlign="left"
                      minWidth="80px"
                      isRequired
                    />
                    <Box ml="8px" flex="1" display="flex" gap="8px">
                      <Box flex="1">
                        <Controller
                          control={control}
                          name="userPass"
                          render={({ field }) => (
                            <InputField
                              value={field.value}
                              onChange={field.onChange}
                              autoComplete={'current-password'}
                              id="userPass"
                              size="small"
                              isPassword={true}
                              fullWidth
                              placeholder="패스워드를 입력하세요."
                              disabled={authStep === 'authCode'}
                            />
                          )}
                        />
                        <Box mt="4px">
                          <HelperText infoText={errors?.userPass?.message ?? ''} usecase="error" />
                        </Box>
                      </Box>
                      {/* 인증번호 요청 버튼 */}
                      {authStep === 'password' && (
                        <Button
                          type="button"
                          size="small"
                          appearance="outlined"
                          priority="primary"
                          onClick={handleRequestAuthCode}
                        >
                          확인
                        </Button>
                      )}
                    </Box>
                  </Box>
                )}

                {/* 인증번호 입력 (로컬이 아니고 인증번호 단계일 때만 표시) */}
                {!isPassVerify && authStep === 'authCode' && (
                  <Box mt="8px" display="flex" alignItems="center">
                    <Label
                      htmlFor="authCode"
                      labelText="인증번호"
                      textAlign="left"
                      minWidth="80px"
                      isRequired
                    />
                    <Box ml="8px" flex="1">
                      <Controller
                        control={control}
                        name="authCode"
                        render={({ field }) => (
                          <InputField
                            value={field.value || ''}
                            onChange={field.onChange}
                            id="authCode"
                            size="small"
                            fullWidth
                            placeholder="인증번호를 입력하세요."
                          />
                        )}
                      />
                      <Box mt="4px">
                        <HelperText infoText={errors?.authCode?.message ?? ''} usecase="error" />
                      </Box>
                    </Box>
                  </Box>
                )}

                {/* 언어 선택 */}
                <Box mt="8px" display="flex" alignItems="center">
                  <Label
                    htmlFor="language-select"
                    labelText="언어설정"
                    textAlign="left"
                    minWidth="80px"
                    isRequired
                  />
                  <Box ml="8px" flex="1">
                    <FormControl fullWidth>
                      <Controller
                        control={control}
                        name="langCd"
                        render={({ field }) => (
                          // TODO: change to @amxis/design-system component
                          <Select
                            value={field.value}
                            onChange={field.onChange}
                            id="language-select"
                            label=""
                            size="small"
                            displayEmpty
                            fullWidth
                            renderValue={(renderValue) =>
                              renderValue ? renderValue : '언어를 선택하세요.'
                            }
                          >
                            {languages.map((lang) => (
                              <MenuItem key={lang.cmnCd} value={lang.cmnCdNm}>
                                {lang.cmnCdNm}
                              </MenuItem>
                            ))}
                          </Select>
                        )}
                      />
                      <Box mt="4px">
                        <HelperText infoText={errors?.langCd?.message ?? ''} usecase="error" />
                      </Box>
                    </FormControl>
                  </Box>
                </Box>

                {/* 로그인 버튼 */}
                <Box display="flex" alignItems="center" justifyContent="flex-end" mt="12px">
                  <Button
                    type="submit"
                    size="small"
                    appearance="contained"
                    priority="primary"
                    iconPosition="leading"
                    iconComponent={<Login />}
                    disabled={!isPassVerify && authStep === 'password'}
                  >
                    로그인
                  </Button>
                </Box>
              </Box>
            </form>
          </Box>
          <Box sx={{ width: '700px', margin: '50px auto 0' }}>
            <DetailTableLine>
              <DetailTableRow>
                <DetailTableHeaderCell align="center">ID</DetailTableHeaderCell>
                <DetailTableHeaderCell align="center">사번</DetailTableHeaderCell>
                <DetailTableHeaderCell align="center">성명</DetailTableHeaderCell>
                <DetailTableHeaderCell align="center">부서</DetailTableHeaderCell>
                <DetailTableHeaderCell align="center">권한 그룹</DetailTableHeaderCell>
              </DetailTableRow>
              <DetailTableRow>
                <DetailTableDataCell align="center">jhseo7</DetailTableDataCell>
                <DetailTableDataCell align="center">83528</DetailTableDataCell>
                <DetailTableDataCell align="center">서지현</DetailTableDataCell>
                <DetailTableDataCell align="center">IT팀</DetailTableDataCell>
                <DetailTableDataCell align="center">시스템관리자 </DetailTableDataCell>
              </DetailTableRow>
              <DetailTableRow>
                <DetailTableDataCell align="center">wjlee04</DetailTableDataCell>
                <DetailTableDataCell align="center">67966</DetailTableDataCell>
                <DetailTableDataCell align="center">이원재</DetailTableDataCell>
                <DetailTableDataCell align="center">안전보건팀</DetailTableDataCell>
                <DetailTableDataCell align="center">일반사용자</DetailTableDataCell>
              </DetailTableRow>
              <DetailTableRow>
                <DetailTableDataCell align="center">jwkim02</DetailTableDataCell>
                <DetailTableDataCell align="center">67981</DetailTableDataCell>
                <DetailTableDataCell align="center">김진우</DetailTableDataCell>
                <DetailTableDataCell align="center">재무팀</DetailTableDataCell>
                <DetailTableDataCell align="center">재무</DetailTableDataCell>
              </DetailTableRow>
              <DetailTableRow>
                <DetailTableDataCell align="center">gcssjh</DetailTableDataCell>
                <DetailTableDataCell align="center">90769</DetailTableDataCell>
                <DetailTableDataCell align="center">송종훈</DetailTableDataCell>
                <DetailTableDataCell align="center">시설관리(공통)</DetailTableDataCell>
                <DetailTableDataCell align="center">현장일반</DetailTableDataCell>
              </DetailTableRow>
              <DetailTableRow>
                <DetailTableDataCell align="center">hhsong</DetailTableDataCell>
                <DetailTableDataCell align="center">67341</DetailTableDataCell>
                <DetailTableDataCell align="center">송현호</DetailTableDataCell>
                <DetailTableDataCell align="center">공릉아파트건설공사(서울)</DetailTableDataCell>
                <DetailTableDataCell align="center">현장관리</DetailTableDataCell>
              </DetailTableRow>
            </DetailTableLine>
          </Box>
        </Box>
      )}
    </Box>
  );
}

export { LoginPage };
