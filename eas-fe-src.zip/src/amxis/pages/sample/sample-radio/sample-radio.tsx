import React, { useState } from 'react';
import { Box, RadioGroup, Typography } from '@mui/material';
import { $semantic, Radio } from '@amxis/design-system';

export const SampleRadio = () => {
  const [value, setValue] = useState<string>('option1');

  const handleOnChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setValue(event?.target.value);
  };

  return (
    <Box>
      <Typography variant="bodySmall">{`[${value}]`}</Typography>
      <RadioGroup
        value={value}
        onChange={handleOnChange}
        sx={{
          display: 'flex',
          flexDirection: 'row',
          gap: `${$semantic.shared.size.sizesCommon.size12}px`,
        }}
      >
        <Radio labelText="option1" value="option1" />
        <Radio labelText="option2" value="option2" />
        <Radio labelText="option3" value="option3" />
      </RadioGroup>
      <br />

      <Typography variant="h5">status: default</Typography>
      <RadioGroup
        sx={{
          display: 'flex',
          flexDirection: 'row',
          gap: `${$semantic.shared.size.sizesCommon.size12}px`,
        }}
      >
        <Radio labelText="default1" value="default1" checked />
        <Radio labelText="default2" value="default2" />
      </RadioGroup>
      <br />

      <Typography variant="h5">status: disabled</Typography>
      <RadioGroup
        sx={{
          display: 'flex',
          flexDirection: 'row',
          gap: `${$semantic.shared.size.sizesCommon.size12}px`,
        }}
      >
        <Radio labelText="disabled1" value="disabled1" checked disabled />
        <Radio labelText="disabled2" value="disabled2" disabled />
      </RadioGroup>
      <br />

      <Typography variant="h5">status: readOnly</Typography>
      <RadioGroup
        sx={{
          display: 'flex',
          flexDirection: 'row',
          gap: `${$semantic.shared.size.sizesCommon.size12}px`,
        }}
      >
        <Radio labelText="readOnly1" value="readOnly1" checked readOnly />
        <Radio labelText="readOnly2" value="readOnly2" readOnly />
      </RadioGroup>
      <br />
    </Box>
  );
};
