import { useState } from 'react';
import { Box, Typography } from '@mui/material';
import { Slider } from '@amxis/design-system';

export const SampleSlider = () => {
  const SAMPLE_CONTINUOUS_MARKER = [
    { value: 2018 * 12, label: '2018' },
    { value: 2019 * 12, label: '2019' },
    { value: 2020 * 12, label: '2020' },
    { value: 2021 * 12, label: '2021' },
    { value: 2022 * 12, label: '2022' },
  ];
  const SAMPLE_DISCRETE_MARKER = [
    { value: 1, label: 'Lv.1' },
    { value: 2, label: 'Lv.2' },
    { value: 3, label: 'Lv.3' },
    { value: 4, label: 'Lv.4' },
    { value: 5, label: 'Lv.5' },
  ];

  const [value1, setValue1] = useState<[number, number]>([500, 1900]);
  const handleChange1 = (newValue: [number, number]) => {
    setValue1(newValue);
  };
  const [value2, setValue2] = useState<number>(2000);
  const handleChange2 = (newValue: number) => {
    setValue2(newValue);
  };
  const [value3, setValue3] = useState<[number, number]>([2018 * 12 + 6, 2021 * 12 + 6]);
  const handleChange3 = (newValue: [number, number]) => {
    setValue3(newValue);
  };
  const [value4, setValue4] = useState<number>(2018 * 12 + 6);
  const handleChange4 = (newValue: number) => {
    setValue4(newValue);
  };
  const [value5, setValue5] = useState<number>(3);
  const handleChange5 = (newValue: number) => {
    setValue5(newValue);
  };

  return (
    <>
      <Typography variant="h2">Continuous Slider - Value Text Type</Typography>
      <Typography variant="h4">Double-Select</Typography>
      <Typography variant="bodySmall">{`[${value1[0]} ~ ${value1[1]}]`}</Typography>
      <Box sx={{ width: '350px' }}>
        <Slider
          usecase="double"
          min={0}
          max={2500}
          minDistance={300}
          step={10}
          showValue={true}
          valueLabelFormat={(v: number, _: number) => `${v}만`}
          value={value1}
          onChange={handleChange1}
        />
      </Box>
      <Typography variant="h4">Single-Select</Typography>
      <Typography variant="bodySmall">{`[${value2}]`}</Typography>
      <Box sx={{ width: '350px' }}>
        <Slider
          usecase="single"
          min={0}
          max={2500}
          step={10}
          showValue={true}
          valueLabelFormat={(v: number, _: number) => `${v}만`}
          value={value2}
          onChange={handleChange2}
        />
      </Box>
      <Typography variant="h2">Continuous Slider - Marking Type</Typography>
      <Typography variant="h4">Double-Select</Typography>
      <Typography variant="bodySmall">{`[${value3[0]} ~ ${value3[1]}]`}</Typography>
      <Box sx={{ width: '350px' }}>
        <Slider
          usecase="doubleMarking"
          min={2017 * 12 + 9}
          max={2022 * 12 + 3}
          marks={SAMPLE_CONTINUOUS_MARKER}
          value={value3}
          onChange={handleChange3}
        />
      </Box>
      <Typography variant="h4">Single-Select</Typography>
      <Typography variant="bodySmall">{`[${value4}]`}</Typography>
      <Box sx={{ width: '350px' }}>
        <Slider
          usecase="singleMarking"
          min={2017 * 12 + 9}
          max={2022 * 12 + 3}
          marks={SAMPLE_CONTINUOUS_MARKER}
          value={value4}
          onChange={handleChange4}
        />
      </Box>
      <Typography variant="h2">Discrete Slider</Typography>
      <Typography variant="bodySmall">{`[${value5}]`}</Typography>
      <Box sx={{ width: '350px' }}>
        <Slider
          usecase="discrete"
          marks={SAMPLE_DISCRETE_MARKER}
          min={1}
          max={5}
          value={value5}
          onChange={handleChange5}
        />
      </Box>
    </>
  );
};
