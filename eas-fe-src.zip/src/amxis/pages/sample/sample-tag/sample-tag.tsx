import { Tag } from '@amxis/design-system';
import { Box } from '@mui/material';

export const SampleTag = () => {
  return (
    <Box my="24px">
      <Box display="flex" flexDirection={'row'} gap={'4px'}>
        <Tag appearance="boxing" colorType="confirmed">
          추가
        </Tag>
        <Tag appearance="boxing" colorType="confirmed">
          완료
        </Tag>
        <Tag appearance="boxing" colorType="confirmed">
          성공
        </Tag>
        <Tag appearance="boxing" colorType="confirmed">
          수락
        </Tag>
        <Tag appearance="non-boxing" colorType="confirmed">
          승인
        </Tag>
      </Box>
      <Box display="flex" flexDirection={'row'} gap={'4px'}>
        <Tag appearance="boxing" colorType="secondary">
          진행중
        </Tag>
        <Tag appearance="boxing" colorType="secondary">
          작성중
        </Tag>
        <Tag appearance="non-boxing" colorType="secondary">
          처리중
        </Tag>
      </Box>
      <Box display="flex" flexDirection={'row'} gap={'4px'}>
        <Tag appearance="boxing" colorType="warning-minor">
          작성대기
        </Tag>
        <Tag appearance="non-boxing" colorType="warning-minor">
          수정
        </Tag>
      </Box>
      <Box display="flex" flexDirection={'row'} gap={'4px'}>
        <Tag appearance="boxing" colorType="warning-major">
          승인대기
        </Tag>
        <Tag appearance="non-boxing" colorType="warning-major">
          승인대기
        </Tag>
      </Box>
      <Box display="flex" flexDirection={'row'} gap={'4px'}>
        <Tag appearance="boxing" colorType="error">
          에러
        </Tag>
        <Tag appearance="boxing" colorType="error">
          거부
        </Tag>
        <Tag appearance="boxing" colorType="error">
          불가
        </Tag>
        <Tag appearance="boxing" colorType="error">
          반려
        </Tag>
        <Tag appearance="boxing" colorType="error">
          지연
        </Tag>
        <Tag appearance="boxing" colorType="error">
          긴급
        </Tag>
        <Tag appearance="non-boxing" colorType="error">
          삭제
        </Tag>
      </Box>
      <Box display="flex" flexDirection={'row'} gap={'4px'}>
        <Tag appearance="boxing" colorType="done">
          기간만료
        </Tag>
        <Tag appearance="boxing" colorType="done">
          종료
        </Tag>
        <Tag appearance="boxing" colorType="done">
          마감
        </Tag>
        <Tag appearance="non-boxing" colorType="done">
          비활성
        </Tag>
      </Box>
      <Box display="flex" flexDirection={'row'} gap={'4px'}>
        <Tag appearance="boxing" colorType="colorB">
          가능
        </Tag>
        <Tag appearance="boxing" colorType="colorB">
          등록
        </Tag>
        <Tag appearance="boxing" colorType="colorB">
          접수
        </Tag>
        <Tag appearance="boxing" colorType="colorB">
          작성
        </Tag>
        <Tag appearance="non-boxing" colorType="colorB">
          요청
        </Tag>
      </Box>
      <Box display="flex" flexDirection={'row'} gap={'4px'}>
        <Tag appearance="boxing" colorType="colorA">
          colorA
        </Tag>
        <Tag appearance="non-boxing" colorType="colorA">
          colorA
        </Tag>
      </Box>
      <Box display="flex" flexDirection={'row'} gap={'4px'}>
        <Tag appearance="boxing" colorType="colorC">
          colorC
        </Tag>
        <Tag appearance="non-boxing" colorType="colorC">
          colorC
        </Tag>
      </Box>
      <Box display="flex" flexDirection={'row'} gap={'4px'}>
        <Tag appearance="boxing" colorType="colorD">
          colorD
        </Tag>
        <Tag appearance="non-boxing" colorType="colorD">
          colorD
        </Tag>
      </Box>
      <Box display="flex" flexDirection={'row'} gap={'4px'}>
        <Tag appearance="boxing" colorType="primary">
          primary
        </Tag>
        <Tag appearance="non-boxing" colorType="primary">
          primary
        </Tag>
      </Box>
    </Box>
  );
};
