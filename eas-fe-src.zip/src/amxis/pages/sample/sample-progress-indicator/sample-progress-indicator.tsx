import { ProgressIndicator } from '@amxis/design-system';
import { Box, Typography } from '@mui/material';
import { useEffect, useState } from 'react';

export const SampleProgressIndicator = () => {
  const [value, setValue] = useState<number>(0);

  useEffect(() => {
    const interval = setInterval(() => {
      if (value < 100) {
        setValue((prevValue) => prevValue + 1);
      } else {
        clearInterval(interval);
      }
    }, 200);

    return () => clearInterval(interval);
  }, [value]);

  return (
    <>
      <Typography variant="h4">Limited - Circular</Typography>
      <Typography variant="bodySmall">{`value: [${value}]`}</Typography>
      <ProgressIndicator shape="circular" apprearance="limited" value={value} />
      <Box my="20px" />
      <Typography variant="h4">Limited - Linear</Typography>
      <Typography variant="bodySmall">{`value: [${value}]`}</Typography>
      <ProgressIndicator shape="linear" apprearance="limited" value={value} />
      <Box my="20px" />
      <Typography variant="h4">Infinite - Circular</Typography>
      <ProgressIndicator shape="circular" apprearance="infinite" />
      <Box my="20px" />
      <Typography variant="h4">Infinite - Linear</Typography>
      <ProgressIndicator shape="linear" apprearance="infinite" />
      <Box my="20px" />
      <Typography variant="h4">Placement Example</Typography>
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        width="500px"
        height="200px"
        bgcolor="gray"
      >
        <ProgressIndicator shape="circular" apprearance="infinite" placement="default" />
      </Box>
    </>
  );
};
