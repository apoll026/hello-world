/**
 Component Name : 부서 검색 search-input
 Component ID   : department-search-input.tsx
 Component Desc : 권한설정 팝업 > 부서 검색 input
 Author         : lgho
 Create Date    : 2024.09.01
 modify Date    : 2024.11.01
 */

import parse from 'autosuggest-highlight/parse';
import match from 'autosuggest-highlight/match';
import { useEffect, useState } from 'react';
import { $semantic, Chip, InputField, Tooltip } from '@amxis/design-system';
import { Autocomplete, CircularProgress, Grid, useTheme } from '@mui/material';
import { Box } from '@mui/system';
import { FunctionSearchIcon, StatusMisuseIcon } from '@amxis/design-system/icon';
import { Container, HelperText, StyledInputWrapper } from './auto-complete-css.tsx';
import { AutoCompleteSampleType, getAutoCompleteSampleDatas } from './auto-complete-mock.ts';

interface AutoCompleteInputParams {
  onlyPopup?: boolean;
  disabled?: boolean;
  readonly?: boolean;
  height?: string;
  size?: 'small' | 'medium' | 'large';
  status?: 'default' | 'error' | 'warning' | 'confirm';
  type?: '1' | '2';
  chipType?: 'default' | 'user';
  chipImg?: string;

  limitTag?: boolean;

  onInit?: AutoCompleteSampleType[];
  onChange: (dataList: AutoCompleteSampleType[]) => void;
  handleExistInputValue?: (e: any) => void;
  width?: string;

  limitTags?: number;
  singleSelect?: boolean;
  isInGrid?: boolean;
  placeholder?: string;
  helperText?: string;
}

export interface InputChipBoxProps {
  onlyPopup?: boolean;
  readonly?: boolean;
  disabled?: boolean;
  chipType?: 'default' | 'user';
  chipImg?: string;

  width?: string;
  height?: string;
  status?: 'default' | 'error' | 'warning' | 'confirm';
  type?: '1' | '2';
  isInGrid?: boolean;
}

const PADDING_SIZE = {
  large: {
    paddingTop: '5px',
    paddingBottom: '5px',
  },
  medium: {
    paddingTop: '3px',
    paddingBottom: '3px',
  },
  small: {
    paddingTop: '1px',
    paddingBottom: '1px',
  },
};

const BORDER_SIZE = {
  large: {
    radius: `${$semantic.shared.radius.radiusInputFieldL}px`,
  },
  medium: {
    radius: `${$semantic.shared.radius.radiusInputFieldM}px`,
  },
  small: {
    radius: `${$semantic.shared.radius.radiusInputFieldS}px`,
  },
};

const AutoCompleteInput = ({
  onlyPopup,
  readonly,
  disabled,
  height = '100%',
  size = 'small',
  status = 'default',
  type,
  chipType = 'user',
  chipImg = '',
  onInit,
  onChange,
  handleExistInputValue,
  width,
  limitTags = 3,
  singleSelect = false,
  isInGrid = false,
  placeholder = '',
  helperText,
}: AutoCompleteInputParams) => {
  const theme = useTheme();
  // const { t } = useTranslation();
  const [open, setOpen] = useState(false);
  const [options, setOptions] = useState<AutoCompleteSampleType[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [openModal, setOpenModal] = useState<boolean>(false);
  const [textValue, setTextValue] = useState<string>('');
  const [dataList, setDataList] = useState<AutoCompleteSampleType[]>(onInit ?? []);

  useEffect(() => {
    if (onInit) {
      setDataList(onInit);
    }
  }, [onInit]);

  //텍스트 입력시 실행되는 함수
  useEffect(() => {
    if (textValue?.length > 1) {
      const timer = setTimeout(() => {
        setLoading(true);
        setOpen(true);
        getAutoCompleteSampleDatas(textValue).then((data) => {
          const mergedOptions = [
            ...data.dataList,
            ...dataList.filter(
              (selected) => !data.dataList.some((opt) => opt.code === selected.code)
            ),
          ];
          setOptions(mergedOptions);
          setLoading(false);
        });
      }, 700);
      return () => clearTimeout(timer);
    } else {
      setOptions([]);
    }
  }, [textValue]);

  const handleClickText = () => {
    if (textValue?.length > 1) {
      setOpen(true);
    }
  };

  const handleClickSearchBtn = (e) => {
    e.stopPropagation();
    setOpenModal(true);
  };

  /**
   * 부서팝업 저장 버튼 클릭시 아니면 input에 key-in으로 유저 넣을 경우 유저 데이터 상태 변경함수
   * onChange로 변경된 내용 상위 컴포넌트에 올림
   * @param {AutoCompleteSampleType[]} data
   * @param {boolean} isLastSelect
   * @returns {void}
   */
  const handleChangeData = (fruit: AutoCompleteSampleType[], isLastSelect: boolean) => {
    let selectedFruitList = fruit;
    if (singleSelect && fruit.length > 1) {
      if (isLastSelect) {
        selectedFruitList = [fruit[fruit.length - 1]];
      } else {
        selectedFruitList = [fruit[0]];
      }
    }

    setDataList(selectedFruitList);
    onChange(selectedFruitList);
    setOpen(false);
  };

  const handleTextFieldChange = (e) => {
    setTextValue(e.target.value);
    handleExistInputValue && handleExistInputValue(e.target.value);
  };

  return (
    <>
      <StyledInputWrapper width={width}>
        <Container
          width={width}
          height={height}
          status={status}
          type={type}
          readonly={readonly}
          disabled={disabled}
          chipType={chipType}
          chipImg={chipImg}
          isInGrid={isInGrid}
        >
          <Autocomplete
            limitTags={limitTags}
            readOnly={readonly || onlyPopup}
            disabled={disabled}
            open={open}
            multiple
            options={options}
            filterOptions={(x) => x}
            filterSelectedOptions
            noOptionsText={'해당 데이터를 찾을 수 없습니다.'}
            value={dataList}
            sx={{
              '& .MuiInputBase-root button.MuiAutocomplete-clearIndicator': {
                display: singleSelect ? 'none' : 'block',
              },
            }}
            onInputChange={(e, value, reason) => {
              //input에 delete버튼 클릭시 reason 값을 통해 input값 제어
              if (reason === 'clear' || reason === 'reset') {
                setTextValue('');
                setOptions([]);
              }
            }}
            onChange={(event, newValue, reason) => {
              //delete 버튼과 data 넣는 이벤트 모두 이곳에서 통제된다.
              if (reason === 'clear') {
                setTextValue('');
              }
              handleExistInputValue && handleExistInputValue('');

              const allString = newValue.every((value) => typeof value === 'string');

              if (allString) {
                //이 경우는 delete 버튼을 눌러서 Autocomplete에 데이터가 빈 경우 이곳으로 통제된다.
                if (newValue) {
                  handleChangeData([], false);
                }
              } else {
                //이 경우는 delete 버튼을 눌러도 데이터가 있을 경우, data를 추가한 경우 이곳으로 통제된다.
                handleChangeData(newValue as AutoCompleteSampleType[], true);
              }
            }}
            onBlur={() => {
              handleExistInputValue && handleExistInputValue('');
              setOpen(false);
            }}
            onClose={() => {
              setLoading(false);
            }}
            isOptionEqualToValue={(option, value) => option.code === value.code}
            getOptionLabel={(option) => {
              if (typeof option === 'string') {
                return option;
              } else {
                return option.fvalue ? option.fvalue : '';
              }
            }}
            loading={loading}
            renderTags={(value: readonly AutoCompleteSampleType[]) =>
              //태그 컴포넌트
              value.map((option: AutoCompleteSampleType, index: number) => (
                <Box
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    height: '100%',
                    maxWidth: index === 0 ? 'calc(100% - 38px)' : 'calc(100% - 23px)',
                  }}
                  key={option.code + index}
                >
                  <Tooltip placement="bottom" title={option.fvalue ?? ''} type="hover">
                    <Box sx={{ width: '100%', height: '100%' }}>
                      <Chip
                        chipText={option.fvalue ?? ''}
                        deletable={true}
                        onDelete={() => {
                          if (readonly || disabled) return;

                          const updatedDataList =
                            dataList?.filter((fruit) => fruit.code !== value[index].code) || [];
                          setDataList(updatedDataList);
                          onChange(updatedDataList);
                        }}
                        size="small"
                        type="input"
                        sx={{
                          width: '100%',
                          height: '100%',
                          verticalAlign: 'middle',
                          '& > div': {
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            gap: '4px',
                            textAlign: 'left',
                            minWidth: '20px',
                          },
                          '& > div > div:nth-of-type(2)': {
                            maxWidth: '100%',
                          },
                          '& > div > div:nth-of-type(2) > p': {
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap',
                          },
                        }}
                      />
                    </Box>
                  </Tooltip>
                </Box>
              ))
            }
            renderOption={(props, option, { inputValue }) => {
              if (!option) return undefined;

              //key-in시 드롭박스에 list 컴포넌트
              const matches = match(option?.fvalue || '', inputValue, { insideWords: true });
              const parts = parse(option?.fvalue || '', matches);

              return (
                <li {...props} key={option?.code} style={{ padding: '5px 5px 5px 5px' }}>
                  <Grid container alignItems="center">
                    <Grid item sx={{ width: 'calc(100% - 35px)', wordWrap: 'break-word' }}>
                      {parts.map((part, index) => (
                        <span
                          key={index}
                          style={{
                            fontWeight: part.highlight ? 700 : 400,
                          }}
                        >
                          {part.text}
                        </span>
                      ))}
                    </Grid>
                  </Grid>
                </li>
              );
            }}
            renderInput={(params) => (
              //input 컴포넌트
              <InputField
                sx={{
                  minWidth: '10%',
                }}
                onClick={handleClickText}
                value={textValue}
                onChange={handleTextFieldChange}
                placeholder={
                  dataList.length === 0 ? (placeholder === '' ? '입력하세요.' : placeholder) : ''
                }
                onKeyDown={(event) => {
                  if (event.key === 'Enter') {
                    if (options?.[0]) {
                      setTextValue('');
                      handleChangeData([options[0], ...dataList], false);
                      setOptions([]);
                      setOpen(false);
                    }

                    event.preventDefault();
                  }
                }}
                {...params}
                InputProps={{
                  ...params.InputProps,
                  style:
                    !readonly && !disabled
                      ? {
                          paddingTop: PADDING_SIZE[size].paddingTop,
                          paddingBottom: PADDING_SIZE[size].paddingBottom,
                          paddingLeft: '6px',
                          paddingRight: singleSelect ? '6px' : '30px',
                          borderRadius: BORDER_SIZE[size].radius,
                          minHeight: isInGrid ? 'unset' : '28px',
                          height: height,
                          alignItems: 'center',
                          display: 'inline-flex',
                          flexDirection: isInGrid ? 'row' : undefined,
                          flexWrap: isInGrid ? 'nowrap' : undefined,
                        }
                      : {
                          paddingTop: PADDING_SIZE[size].paddingTop,
                          paddingBottom: PADDING_SIZE[size].paddingBottom,
                          paddingLeft: '6px',
                          paddingRight: '6px',
                          borderRadius: BORDER_SIZE[size].radius,
                          minHeight: isInGrid ? 'unset' : '28px',
                          height: height,
                          alignItems: 'center',
                          flexWrap: isInGrid ? 'nowrap' : undefined,
                        },
                  startAdornment: (
                    <>
                      {!readonly && !disabled && (
                        <FunctionSearchIcon
                          appearance="lined"
                          iconSize={16}
                          fill={theme.palette.semantic.color.commonTextBasic}
                          sx={{
                            margin: `2px`,
                            cursor: 'pointer',
                          }}
                          onClick={handleClickSearchBtn}
                        />
                      )}
                      {params.InputProps.startAdornment}
                    </>
                  ),
                  endAdornment: (
                    <>
                      {loading ? (
                        <CircularProgress
                          color="primary"
                          size={20}
                          style={{ margin: 'auto', boxSizing: 'content-box' }}
                        />
                      ) : null}
                      {params.InputProps.endAdornment}
                    </>
                  ),
                }}
              />
            )}
            clearIcon={
              !singleSelect && (
                <StatusMisuseIcon
                  appearance="filled"
                  fill={theme.palette.semantic.color.commonTextLighter}
                  iconSize={16}
                  sx={{ marginRight: '-1px' }}
                />
              )
            }
          />
        </Container>
        {helperText && <HelperText status={status}>{helperText}</HelperText>}
      </StyledInputWrapper>
      {/* {openModal && renderModal()} */}
    </>
  );
};

export default AutoCompleteInput;
