import React, { useState } from 'react';
import { Box, Typography } from '@mui/material';
import {
  Button,
  Dialog,
  DialogNavigationSize,
  DialogNavigationType,
  Radio,
  RadioGroup,
} from '@amxis/design-system';

export const SampleDialog = () => {
  const [modalSize, setModalSize] = useState<DialogNavigationSize>(800);
  const [modalType, setModalType] = useState<DialogNavigationType>('modal');
  const [isOutBound, setIsOutBound] = useState(false);
  const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);
  const [anchorEl2, setAnchorEl2] = useState<HTMLButtonElement | null>(null);
  const [anchorElChild, setAnchorElChild] = useState<HTMLButtonElement | null>(null);
  const [anchorElChild2, setAnchorElChild2] = useState<HTMLButtonElement | null>(null);
  const isOpenDialog = Boolean(anchorEl);
  const isOpenDialog2 = Boolean(anchorEl2);
  const isOpenDialogChild = Boolean(anchorElChild);
  const isOpenDialogChild2 = Boolean(anchorElChild2);

  const handleChangeModalSize = (event: React.ChangeEvent<HTMLInputElement>) => {
    setModalSize(event?.target.value as unknown as DialogNavigationSize);
  };

  const handleChangeModalType = (event: React.ChangeEvent<HTMLInputElement>) => {
    setModalType(event?.target.value as unknown as DialogNavigationType);
  };

  const openDialog = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
    if (window.innerHeight - event.currentTarget.getBoundingClientRect().bottom < 200) {
      setIsOutBound(true);
      return;
    }
    setIsOutBound(false);
  };

  const closeDialog = () => {
    setAnchorEl(null);
  };

  const openChildDialog = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorElChild(event.currentTarget);
    if (window.innerHeight - event.currentTarget.getBoundingClientRect().bottom < 200) {
      setIsOutBound(true);
      return;
    }
    setIsOutBound(false);
  };

  const closeChildDialog = () => {
    setAnchorElChild(null);
  };

  const openDialog2 = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl2(event.currentTarget);
  };

  const closeDialog2 = () => {
    setAnchorEl2(null);
  };

  const openChildDialog2 = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorElChild2(event.currentTarget);
  };

  const closeChildDialog2 = () => {
    setAnchorElChild2(null);
  };

  return (
    <Box display="flex" flexDirection="column" gap="10px">
      <Box display="flex" alignItems="center" gap="10px">
        <Typography variant="h5">Select modal sizes: </Typography>
        <RadioGroup
          value={modalSize}
          onChange={handleChangeModalSize}
          sx={{
            display: 'flex',
            flexDirection: 'row',
            gap: '12px',
          }}
        >
          <Radio labelText="400" value={400} />
          <Radio labelText="600" value={600} />
          <Radio labelText="800" value={800} />
          <Radio labelText="1000" value={1000} />
          <Radio labelText="1200" value={1200} />
          <Radio labelText="1400" value={1400} />
          <Radio labelText="1600" value={1600} />
        </RadioGroup>
      </Box>

      <Box display="flex" alignItems="center" gap="10px">
        <Typography variant="h5">Select modal types: </Typography>
        <RadioGroup
          value={modalType}
          onChange={handleChangeModalType}
          sx={{
            display: 'flex',
            flexDirection: 'row',
            gap: '12px',
          }}
        >
          <Radio labelText="Modal" value="modal" />
          <Radio labelText="Modaless" value="modaless" />
        </RadioGroup>
      </Box>

      <Box>
        <Button onClick={openDialog}>Open Dialog</Button>
        <Dialog
          isDraggable={false}
          position="basic"
          type={modalType}
          size={modalSize}
          open={isOpenDialog}
          isOutBound={isOutBound}
          title="Default Dialog"
          customContentArea={
            <Box>
              <Typography variant="h3">Click this button to open nested dialog</Typography>
              <Button sx={{ marginTop: '20px' }} onClick={openChildDialog}>
                Open Dialog
              </Button>
              <Dialog
                isDraggable={false}
                position="basic"
                type={modalType}
                size={600}
                open={isOpenDialogChild}
                isOutBound={isOutBound}
                title="Default Dialog Child"
                contentArea="nested dialog"
                handleClose={closeChildDialog}
              />
            </Box>
          }
          handleClose={closeDialog}
        />
      </Box>

      <Box>
        <Button onClick={openDialog2}>Open Draggable Dialog</Button>
        <Dialog
          isDraggable={true}
          type={modalType}
          size={modalSize}
          open={isOpenDialog2}
          title="Draggable Dialog (Drag Here!)"
          customContentArea={
            <Box>
              <Typography variant="h3">Click this button to open nested dialog</Typography>
              <Button sx={{ marginTop: '20px' }} onClick={openChildDialog2}>
                Open Dialog
              </Button>
              <Dialog
                isDraggable={true}
                isBounded={true}
                type={modalType}
                size={600}
                open={isOpenDialogChild2}
                title="Draggable Dialog Child (Drag Here!)"
                contentArea="nested dialog"
                handleClose={closeChildDialog2}
              />
            </Box>
          }
          handleClose={closeDialog2}
        />
      </Box>
    </Box>
  );
};
