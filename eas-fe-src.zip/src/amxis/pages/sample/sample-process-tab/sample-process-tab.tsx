import {
  Divider,
  ProcessTab,
  ProcessTabDataProps,
  Button,
  Tab,
  TabDataProps,
  makeDeletedNewTabs,
  makeSelectedNewTabs,
} from '@amxis/design-system';
import { Box, Typography } from '@mui/material';
import { useState } from 'react';

const tabInTabItems: TabDataProps[] = [
  {
    id: 1,
    item: { tabName: '탭 아이템 1-1', showNotification: true, close: true },
    contents: <Box>item1-1</Box>,
  },
  {
    id: 2,
    item: { tabName: '탭 아이템 1-2', close: true },
    contents: <Box>item1-2</Box>,
  },
  {
    id: 3,
    item: {
      tabName: '12자가 넘는 탭 길고 긴 탭',
      showCount: true,
      close: true,
      count: 1,
    },
    contents: <Box>item1-3</Box>,
  },
];

const TabInTab = () => {
  const [data, setData] = useState(tabInTabItems);

  const handleSelect = (selectingIndex: number) => {
    setData(makeSelectedNewTabs(data, selectingIndex));
  };

  const handleDelete = (deletingIndex: number) => {
    setData(makeDeletedNewTabs(data, deletingIndex));
  };

  return <Tab isTabInTab data={data} onSelect={handleSelect} onClose={handleDelete} />;
};

const tabs: ProcessTabDataProps[] = [
  {
    id: 1,
    item: { status: 'inProgress', tabName: '1단계', totalAmount: 100, currentAmount: 10 },
    contents: <TabInTab />,
  },
  {
    id: 2,
    item: {
      status: 'standBy',
      tabName: '2단계',
    },
    contents: <Box>Item2</Box>,
  },
  {
    id: 3,
    item: { status: 'standBy', tabName: '3단계' },
    contents: <Box>Item3</Box>,
  },
  {
    id: 4,
    item: { status: 'standBy', tabName: '4단계' },
    contents: <Box>Item4</Box>,
  },
  {
    id: 5,
    item: { status: 'disabled', tabName: '4단계 완료 시 활성화' },
    contents: <Box>Item5</Box>,
  },
  {
    id: 6,
    item: { status: 'standBy', tabName: '6단계' },
    contents: <Box>Item6</Box>,
  },
  {
    id: 7,
    item: { status: 'standBy', tabName: '7단계' },
    contents: <Box>Item7</Box>,
  },
  {
    id: 8,
    item: { status: 'standBy', tabName: '8단계' },
    contents: <Box>Item8</Box>,
  },
  {
    id: 9,
    item: { status: 'standBy', tabName: '9단계' },
    contents: <Box>Item9</Box>,
  },
  {
    id: 10,
    item: { status: 'standBy', tabName: '10단계' },
    contents: <Box>Item10</Box>,
  },
  {
    id: 11,
    item: { status: 'standBy', tabName: '11단계' },
    contents: <Box>Item11</Box>,
  },
  {
    id: 12,
    item: { status: 'standBy', tabName: '12단계' },
    contents: <Box>Item12</Box>,
  },
  {
    id: 13,
    item: { status: 'standBy', tabName: '13단계' },
    contents: <Box>Item13</Box>,
  },
  {
    id: 14,
    item: { status: 'standBy', tabName: '14단계' },
    contents: <Box>Item14</Box>,
  },
  {
    id: 15,
    item: { status: 'standBy', tabName: '15단계' },
    contents: <Box>Item15</Box>,
  },
  {
    id: 16,
    item: { status: 'standBy', tabName: '16단계' },
    contents: <Box>Item16</Box>,
  },
];

export const ProcessTabSample = () => {
  const [data, setData] = useState(tabs);
  const [selectedTabIndex, setSelectedTabIndex] = useState(0);

  const handleSelect = (selectingIndex: number) => {
    setSelectedTabIndex(selectingIndex);
  };

  const handleProcess = () => {
    const activeTabIndex = data.findIndex((tab) => tab.item.status === 'inProgress');

    let newData = data.map((tab, idx) => {
      const totalAmount = (Math.floor(Math.random() * 10) + 1) * 100;
      const currentAmount = (Math.floor(Math.random() * (totalAmount / 10)) + 1) * 10;
      return idx === activeTabIndex
        ? {
            ...tab,
            ...{
              item: { ...tab.item, status: 'done' as const, currentAmount: tab.item.totalAmount },
            },
          }
        : idx === activeTabIndex + 1
        ? {
            ...tab,
            ...{
              item: {
                ...tab.item,
                status: 'inProgress' as const,
                totalAmount,
                currentAmount,
              },
            },
          }
        : tab;
    });
    newData = toggleTabEnabled(newData);
    if (newData.filter((tab) => tab.item.status === 'done').length === data.length) {
      setSelectedTabIndex(data.length);
    }
    setData(newData);
  };

  const handleRevoke = () => {
    const activeTabIndex = data.findIndex((tab) => tab.item.status === 'inProgress');
    let newData = data.map((tab, idx) =>
      idx === activeTabIndex - 1
        ? { ...tab, ...{ item: { ...tab.item, status: 'inProgress' as const } } }
        : idx === activeTabIndex
        ? {
            ...tab,
            ...{
              item: {
                ...tab.item,
                status: 'standBy' as const,
                totalAmount: 0,
                currentAmount: 0,
              },
            },
          }
        : tab
    );
    newData = toggleTabEnabled(newData);
    setData(newData);
  };

  const toggleTabEnabled = (data: ProcessTabDataProps[]) => {
    if (data[3].item.status !== 'done')
      return data.map((tab, idx) =>
        idx === 4 ? { ...tab, ...{ item: { ...tab.item, status: 'disabled' as const } } } : tab
      );
    else return data;
  };

  const handleReset = () => {
    const newData = data.map((tab, index) => ({
      ...tab,
      ...{
        item: {
          ...tab.item,
          status:
            index === 0
              ? ('inProgress' as const)
              : index === 4
              ? ('disabled' as const)
              : ('standBy' as const),
          totalAmount: index === 0 ? 100 : 0,
          currentAmount: index === 0 ? 10 : 0,
        },
      },
    }));
    setData(newData);
    setSelectedTabIndex(0);
  };
  const canRevoke = data.filter((tab) => tab.item.status === 'done').length > 0;
  const allDone = data.filter((tab) => tab.item.status === 'done').length === data.length;

  const [data2, setData2] = useState(tabs);
  const [selectedTabIndex2, setSelectedTabIndex2] = useState(0);

  const handleSelect2 = (selectingIndex: number) => {
    setSelectedTabIndex2(selectingIndex);
  };

  const handleProcess2 = () => {
    const activeTabIndex = data2.findIndex((tab) => tab.item.status === 'inProgress');

    let newData = data2.map((tab, idx) => {
      const totalAmount = (Math.floor(Math.random() * 10) + 1) * 100;
      const currentAmount = (Math.floor(Math.random() * (totalAmount / 10)) + 1) * 10;
      return idx === activeTabIndex
        ? {
            ...tab,
            ...{
              item: { ...tab.item, status: 'done' as const, currentAmount: tab.item.totalAmount },
            },
          }
        : idx === activeTabIndex + 1
        ? {
            ...tab,
            ...{
              item: {
                ...tab.item,
                status: 'inProgress' as const,
                totalAmount,
                currentAmount,
              },
            },
          }
        : tab;
    });
    newData = toggleTabEnabled2(newData);
    if (newData.filter((tab) => tab.item.status === 'done').length === data2.length) {
      setSelectedTabIndex2(data.length);
    }
    setData2(newData);
  };

  const handleRevoke2 = () => {
    const activeTabIndex = data2.findIndex((tab) => tab.item.status === 'inProgress');
    let newData = data2.map((tab, idx) =>
      idx === activeTabIndex - 1
        ? { ...tab, ...{ item: { ...tab.item, status: 'inProgress' as const } } }
        : idx === activeTabIndex
        ? {
            ...tab,
            ...{
              item: {
                ...tab.item,
                status: 'standBy' as const,
                totalAmount: 0,
                currentAmount: 0,
              },
            },
          }
        : tab
    );
    newData = toggleTabEnabled2(newData);
    setData2(newData);
  };

  const toggleTabEnabled2 = (data: ProcessTabDataProps[]) => {
    if (data[3].item.status !== 'done')
      return data.map((tab, idx) =>
        idx === 4 ? { ...tab, ...{ item: { ...tab.item, status: 'disabled' as const } } } : tab
      );
    else return data;
  };

  const handleReset2 = () => {
    const newData = data2.map((tab, index) => ({
      ...tab,
      ...{
        item: {
          ...tab.item,
          status:
            index === 0
              ? ('inProgress' as const)
              : index === 4
              ? ('disabled' as const)
              : ('standBy' as const),
          totalAmount: index === 0 ? 100 : 0,
          currentAmount: index === 0 ? 10 : 0,
        },
      },
    }));
    setData2(newData);
    setSelectedTabIndex2(0);
  };
  const canRevoke2 = data2.filter((tab) => tab.item.status === 'done').length > 0;
  const allDone2 = data2.filter((tab) => tab.item.status === 'done').length === data2.length;

  return (
    <Box sx={{ width: '60%' }}>
      <Typography variant="h1">Default ProcessTab Sample</Typography>
      <ProcessTab
        appearance="default"
        data={data}
        onSelect={handleSelect}
        selectedIndex={selectedTabIndex}
      />
      {allDone ? <Typography>All steps completed</Typography> : <></>}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
        {allDone ? (
          <Button onClick={handleReset} sx={{ marginLeft: 'auto' }}>
            RESET
          </Button>
        ) : (
          <>
            <Button onClick={handleRevoke} disabled={!canRevoke}>
              REVOKE
            </Button>
            <Button onClick={handleProcess}>PROCESS</Button>
          </>
        )}
      </Box>
      <Divider />
      <Typography variant="h1">Complex ProcessTab Sample</Typography>
      <ProcessTab
        appearance="complex"
        data={data2}
        onSelect={handleSelect2}
        selectedIndex={selectedTabIndex2}
      />
      {allDone2 ? <Typography>All steps completed</Typography> : <></>}
      <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
        {allDone2 ? (
          <Button onClick={handleReset2} sx={{ marginLeft: 'auto' }}>
            RESET
          </Button>
        ) : (
          <>
            <Button onClick={handleRevoke2} disabled={!canRevoke2}>
              REVOKE
            </Button>
            <Button onClick={handleProcess2}>PROCESS</Button>
          </>
        )}
      </Box>
    </Box>
  );
};
