import { DatePickerCalendar, DateRangePickerValueType, DualDatePicker, QuarterPicker } from '@amxis/design-system';
import { Box, Typography } from '@mui/material';
import { Dayjs } from 'dayjs';
import React, { useState } from 'react';

export const SampleDatePickerCalendar = () => {
  const [date, setDate] = useState<Dayjs | null>(null);
  const [date2, setDate2] = useState<Dayjs | null>(null);
  const [dates, setDates] = useState<DateRangePickerValueType>([]);
  const [dates2, setDates2] = useState<DateRangePickerValueType>([]);
  const [dates3, setDates3] = useState<DateRangePickerValueType>([]);
  const [dates4, setDates4] = useState<DateRangePickerValueType>([]);
  const [month, setMonth] = useState<Dayjs | null>(null);
  const [month2, setMonth2] = useState<Dayjs | null>(null);
  const [year, setYear] = useState<Dayjs | null>(null);
  const [year2, setYear2] = useState<Dayjs | null>(null);
  const [quarter, setQuarter] = useState<Dayjs | null>(null);
  const [dualDates, setDualDates] = useState<DateRangePickerValueType>([]);

  return (
    <Box>
      {/* Elevation Type */}
      <Typography variant="h2">[Elevation Type]</Typography>

      <Typography variant="h5">usecase=&quot;date&quot;</Typography>
      <div>{JSON.stringify(date)}</div>
      <DatePickerCalendar
        elevation
        usecase="date"
        value={date}
        status="default"
        onChange={(date: Dayjs) => {
          setDate(date);
        }}
      />

      <Typography variant="h5">usecase=&quot;date-range-single&quot;</Typography>
      <div>{JSON.stringify(dates, null, 2)}</div>
      <DatePickerCalendar
        elevation
        usecase="date-range-single"
        value={dates}
        status="default"
        onChange={(date: DateRangePickerValueType) => {
          console.log('onInputChange: ' + date[0]?.toString() + '-' + date[1]?.toString());
          setDates(date);
        }}
      />

      <Typography variant="h5">usecase=&quot;date-range-multi&quot;</Typography>
      <div>{JSON.stringify(dates2, null, 2)}</div>
      <DatePickerCalendar
        elevation
        usecase="date-range-multi"
        value={dates2}
        status="default"
        onChange={(date: DateRangePickerValueType) => {
          console.log('onInputChange: ' + date[0]?.toString() + '-' + date[1]?.toString());
          setDates2(date);
        }}
      />

      <Typography variant="h5">usecase=&quot;month&quot;</Typography>
      <div>{JSON.stringify(month)}</div>
      <DatePickerCalendar
        elevation
        usecase="month"
        value={month}
        status="default"
        onChange={(date: Dayjs) => {
          console.log('onInputChange: ' + `${date.month() + 1}`);
          setMonth(date);
        }}
      />

      <Typography variant="h5">usecase=&quot;year&quot;</Typography>
      <div>{JSON.stringify(year)}</div>
      <DatePickerCalendar
        elevation
        usecase="year"
        value={year}
        status="default"
        onChange={(date: Dayjs) => {
          console.log('onInputChange: ' + date.year());
          setYear(date);
        }}
      />
      <br />

      {/* Embed Type */}
      <Typography variant="h2">[Embed Type]</Typography>

      <Typography variant="h5">usecase=&quot;date&quot;</Typography>
      <div>{JSON.stringify(date2)}</div>
      <DatePickerCalendar
        value={date2}
        usecase="date"
        onChange={(date: Dayjs | null) => {
          console.log('onChange: ' + date?.toString());
          setDate2(date);
        }}
      />

      <Typography variant="h5">usecase=&quot;date-range-single&quot;</Typography>
      <div>{JSON.stringify(dates3, null, 2)}</div>
      <DatePickerCalendar
        value={dates3}
        usecase="date-range-single"
        onChange={(date: DateRangePickerValueType) => {
          console.log('onInputChange: ' + date[0]?.toString() + '-' + date[1]?.toString());
          setDates3(date);
        }}
      />

      <Typography variant="h5">usecase=&quot;date-range-multi&quot;</Typography>
      <div>{JSON.stringify(dates4, null, 2)}</div>
      <DatePickerCalendar
        value={dates4}
        usecase="date-range-multi"
        onChange={(date: DateRangePickerValueType) => {
          console.log('onInputChange: ' + date[0]?.toString() + '-' + date[1]?.toString());
          setDates4(date);
        }}
      />

      <Typography variant="h5">usecase=&quot;month&quot;</Typography>
      <div>{JSON.stringify(month2)}</div>
      <DatePickerCalendar
        value={month2}
        usecase="month"
        onChange={(date: Dayjs) => {
          console.log('onInputChange: ' + `${date.month() + 1}`);
          setMonth2(date);
        }}
      />

      <Typography variant="h5">usecase=&quot;year&quot;</Typography>
      <div>{JSON.stringify(year2)}</div>
      <DatePickerCalendar
        value={year2}
        usecase="year"
        onChange={(date: Dayjs) => {
          console.log('onInputChange: ' + date.year());
          setYear2(date);
        }}
      />
      <br />

      {/* Quarter Type */}
      <Typography variant="h2">[Quarter Type]</Typography>

      <div>{JSON.stringify([quarter, quarter?.add(3, 'month')])}</div>
      <Typography variant="h5">size=&quot;small&quot;</Typography>
      <QuarterPicker
        size="small"
        value={quarter}
        onChange={(date: Dayjs) => {
          setQuarter(date);
        }}
      />

      <Typography variant="h5">size=&quot;medium&quot;</Typography>
      <QuarterPicker
        size="medium"
        value={quarter}
        onChange={(date: Dayjs) => {
          setQuarter(date);
        }}
      />

      <Typography variant="h5">size=&quot;large&quot;</Typography>
      <QuarterPicker
        size="large"
        value={quarter}
        onChange={(date: Dayjs) => {
          setQuarter(date);
        }}
      />

      <Typography variant="h5">readOnly</Typography>
      <QuarterPicker
        readOnly
        value={quarter}
        onChange={(date: Dayjs) => {
          setQuarter(date);
        }}
      />

      <Typography variant="h5">disabled</Typography>
      <QuarterPicker
        disabled
        value={quarter}
        onChange={(date: Dayjs) => {
          setQuarter(date);
        }}
      />
      <br />

      {/* DualDate Type */}
      <Typography variant="h2">[DualDate Type]</Typography>

      <div>{JSON.stringify(dualDates, null, 2)}</div>
      <Typography variant="h5">size=&quot;small&quot;</Typography>
      <DualDatePicker
        size="small"
        value={dualDates}
        onChange={setDualDates}
      />

      <Typography variant="h5">size=&quot;medium&quot;</Typography>
      <DualDatePicker
        size="medium"
        value={dualDates}
        onChange={setDualDates}
      />

      <Typography variant="h5">size=&quot;large&quot;</Typography>
      <DualDatePicker
        size="large"
        value={dualDates}
        onChange={setDualDates}
      />

      <Typography variant="h5">status=&quot;error&quot;</Typography>
      <DualDatePicker
        status="error"
        value={dualDates}
        onChange={setDualDates}
      />

      <Typography variant="h5">status=&quot;confirmed&quot;</Typography>
      <DualDatePicker
        status="confirmed"
        value={dualDates}
        onChange={setDualDates}
      />

      <Typography variant="h5">status=&quot;warning&quot;</Typography>
      <DualDatePicker
        status="warning"
        value={dualDates}
        onChange={setDualDates}
      />

      <Typography variant="h5">readOnly</Typography>
      <DualDatePicker
        readOnly
        value={dualDates}
        onChange={setDualDates}
      />

      <Typography variant="h5">disabled</Typography>
      <DualDatePicker
        disabled
        value={dualDates}
        onChange={setDualDates}
      />
      <br />
    </Box>
  );
};
