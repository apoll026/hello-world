import { useCallback, useMemo } from 'react';
import { MenuInfo } from '../types/grid-manage.types';
import { useGridManageStore } from '@/amxis/stores/useGridManageStore';
import { useMenuAllQuery } from '@/amxis/hooks/queries/menu/use-menu-query';
import { MenuVO } from '@/amxis/models/admin/Menu';

type MenuTree = MenuInfo & { Items?: MenuTree[] };

const TOP_ID = 'EAS_P0000000';

export const useMenuListGrid = () => {
  const { setSelectedMenu, clearConfigGrid, searchCondition } = useGridManageStore();

  // 1) 서버 VO -> 평면 구조 매핑
  const mapMenuData = useCallback((data: MenuVO[]): MenuInfo[] => {
    return (
      data?.map((menu): MenuInfo => ({
        pgmId: menu.pgmId,
        pgmName: menu.pgmName || '',
        pgmUrl: menu.pgmUrl || '',
        upgmId: menu.upgmId ?? '',
        seq: menu.sortOrd?.toString() || '',
        pmFlag: menu.mnuLvNo === 1 ? 'M' : 'P',
        useYn: (menu.useYn as 'Y' | 'N') || 'Y',
      })) || []
    );
  }, []);

  // 2) 조회 (flat)
  const { data: menuData, isLoading } = useMenuAllQuery<MenuInfo[]>(
    { ...searchCondition },
    { select: mapMenuData }
  );

  // 공통 정렬 함수
  const toNum = (s?: string) => {
    const n = Number(s);
    return Number.isFinite(n) ? n : Number.MAX_SAFE_INTEGER;
  };
  const sortRec = (nodes: MenuTree[]) => {
    nodes.sort((a, b) => {
      const sa = toNum(a.seq);
      const sb = toNum(b.seq);
      if (sa !== sb) return sa - sb;
      return a.pgmName.localeCompare(b.pgmName);
    });
    nodes.forEach((n) => n.Items && sortRec(n.Items));
  };

  // 3) flat -> tree (TOP 포함 + TOP 자식만)
  const { menuTreeData, menuTreeWithTop } = useMemo(() => {
    const rows = menuData ?? [];
    if (rows.length === 0) return { menuTreeData: [] as MenuTree[], menuTreeWithTop: [] as MenuTree[] };

    const byId = new Map<string, MenuTree>();
    const childrenOf = new Map<string, MenuTree[]>();

    // 노드 사전
    for (const r of rows) byId.set(r.pgmId, { ...r });

    // 부모->자식 매핑 (self-parent 방지)
    for (const r of rows) {
      if (!r.upgmId) continue;
      if (r.pgmId === r.upgmId) continue; // 자기 자신을 부모로 등록 금지
      const child = byId.get(r.pgmId);
      if (!child) continue;
      const list = childrenOf.get(r.upgmId) ?? [];
      list.push(child);
      childrenOf.set(r.upgmId, list);
    }

    // Items 주입
    for (const [pid, kids] of childrenOf) {
      const parent = byId.get(pid);
      if (parent) parent.Items = kids;
    }

    // 최상위 노드 객체
    const topNode = byId.get(TOP_ID);

    // A) TOP의 자식들만 루트로 (UI에 많이 쓰는 형태)
    let roots: MenuTree[] = [];
    if (topNode?.Items?.length) {
      roots = [...topNode.Items];
    } else {
      roots = rows
        .filter((r) => r.upgmId === TOP_ID && r.pgmId !== r.upgmId)
        .map((r) => byId.get(r.pgmId)!)
        .filter(Boolean);
    }

    // B) TOP을 포함한 전체 트리
    const withTop = topNode ? [topNode] : roots;

    // 정렬
    sortRec(roots);
    sortRec(withTop);

    return { menuTreeData: roots, menuTreeWithTop: withTop };
  }, [menuData]);

  // 4) 선택 핸들러
  const handleMenuSelect = useCallback(
    (pgmId: string) => {
      const { selectedMenu } = useGridManageStore.getState();
      if (selectedMenu !== pgmId) {
        clearConfigGrid();
      }
      setSelectedMenu(pgmId);
    },
    [setSelectedMenu, clearConfigGrid]
  );

  return {
    // 기존 flat
    menuData: menuData || [],
    loading: isLoading,

    // 추가: 트리
    menuTreeData,     // TOP의 자식들만 루트로
    menuTreeWithTop,  // TOP(EAS_P0000000)까지 포함한 전체 트리

    handleMenuSelect,
  };
};
