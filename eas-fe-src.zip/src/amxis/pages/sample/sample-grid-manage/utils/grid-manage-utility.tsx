import React from 'react';
import { createRoot } from 'react-dom/client';
import { ThemeProvider } from '@/amxis/components/theme-provider';
import { DataGridCellTag } from '@amxis/design-system';
import { CrudCode } from '@/amxis/models/common/Edit';
import { GridConfigInfo } from '../types/grid-manage.types';
import { IbSheetColProperty } from '@/amxis/pages/sample/sample-ibsheet/IbSheetColProperty';

export class GridManageUtility {
  private rowStatesRef: React.MutableRefObject<Map<string, string>>;
  private reactRootsRef: React.MutableRefObject<Map<string, any>>;

  constructor(
    rowStatesRef: React.MutableRefObject<Map<string, string>>,
    reactRootsRef: React.MutableRefObject<Map<string, any>>
  ) {
    this.rowStatesRef = rowStatesRef;
    this.reactRootsRef = reactRootsRef;
  }

  /**
   * 상태 태그를 렌더링하는 공통 함수
   */
  renderStateTag = (sheet: any, row: any, state: string) => {
    if (!sheet || !row) return;

    const cell = sheet.getCell(row, 'sState');
    if (!cell) return;

    const innerDiv = cell.querySelector('div');
    if (!innerDiv) return;

    const rowId = row.id;

    if (this.reactRootsRef.current.has(rowId)) {
      const existingRoot = this.reactRootsRef.current.get(rowId);
      setTimeout(() => {
        try {
          existingRoot.unmount();
        } catch (error) {
          console.warn('React root 정리 중 오류:', error);
        }
      }, 0);
      this.reactRootsRef.current.delete(rowId);
    }

    innerDiv.innerHTML = '';

    const mountPoint = document.createElement('div');
    mountPoint.style.width = '100%';
    mountPoint.style.height = '100%';
    mountPoint.style.display = 'flex';
    mountPoint.style.alignItems = 'center';
    mountPoint.style.justifyContent = 'center';
    innerDiv.appendChild(mountPoint);

    try {
      const root = createRoot(mountPoint);
      this.reactRootsRef.current.set(rowId, root);

      let tagElement: JSX.Element | null = null;

      switch (state) {
        case CrudCode.CREATE:
          tagElement = (
            <ThemeProvider>
              <DataGridCellTag appearance="boxing" colorType="confirmed">
                추가
              </DataGridCellTag>
            </ThemeProvider>
          );
          break;
        case CrudCode.UPDATE:
          tagElement = (
            <ThemeProvider>
              <DataGridCellTag appearance="boxing" colorType="secondary">
                수정
              </DataGridCellTag>
            </ThemeProvider>
          );
          break;
        case CrudCode.DELETE:
          tagElement = (
            <ThemeProvider>
              <DataGridCellTag appearance="boxing" colorType="error">
                삭제
              </DataGridCellTag>
            </ThemeProvider>
          );
          break;
        default:
          // 기본 상태일 때는 태그를 표시하지 않음
          return;
      }

      if (tagElement) {
        root.render(tagElement);
        // 렌더링 후 강제로 레이아웃 갱신
        requestAnimationFrame(() => {
          innerDiv.style.visibility = 'visible';
        });
      }
    } catch (error) {
      console.error('상태 태그 렌더링 오류:', error);
    }
  };

  /**
   * 특정 행의 상태 태그 제거
   */
  removeStateTag = (sheet: any, rowId: string) => {
    if (this.reactRootsRef.current.has(rowId)) {
      setTimeout(() => {
        try {
          const root = this.reactRootsRef.current.get(rowId);
          if (root) {
            root.unmount();
            this.reactRootsRef.current.delete(rowId);
          }
        } catch (error) {
          console.warn('상태 태그 제거 중 오류:', error);
        }
      }, 0);
    }

    this.rowStatesRef.current.delete(rowId);
  };

  /**
   * 모든 상태 태그를 다시 렌더링하는 함수
   */
  reRenderAllStateTags = (sheet: any) => {
    if (!sheet) return;

    setTimeout(() => {
      this.reactRootsRef.current.forEach((root, rowId) => {
        try {
          root.unmount();
        } catch (error) {
          console.warn(`React root 정리 오류 (rowId: ${rowId}):`, error);
        }
      });
      this.reactRootsRef.current.clear();

      // 상태가 있는 행들만 다시 렌더링
      this.rowStatesRef.current.forEach((state, rowId) => {
        try {
          const row = sheet.getRowById(rowId);
          if (row) {
            this.renderStateTag(sheet, row, state);
          }
        } catch (error) {
          console.warn(`행 ${rowId} 상태 태그 재렌더링 오류:`, error);
        }
      });
    }, 0);
  };

  /**
   * 행 상태 설정 및 UI 업데이트
   */
  setRowState = (sheet: any, rowId: string, state: string) => {
    if (!sheet || !rowId) return;

    this.rowStatesRef.current.set(rowId, state);
    const row = sheet.getRowById(rowId);

    if (row) {
      this.renderStateTag(sheet, row, state);

      setTimeout(() => {
        const updatedRow = sheet.getRowById(rowId);
        if (updatedRow) {
          this.renderStateTag(sheet, updatedRow, state);
        }
      }, 10);
    }
  };

  /**
   * 행 추가 기능
   */
  addRow = (sheet: any, selectedMenu: string, sheetId: string) => {
    try {
      if (sheet) {
        const newRow = sheet[sheetId].addRow({ next: sheet[sheetId].getFirstRow() });
        const rowId = newRow.id;

        sheet[sheetId].setValue(newRow, 'pgmId', selectedMenu);

        // 상태 저장 및 태그 렌더링
        this.setRowState(sheet[sheetId], rowId, CrudCode.CREATE);

      } else {
        console.warn('시트를 찾을 수 없습니다.');
      }
    } catch (err) {
      console.error('시트 접근 실패:', err);
    }
  };

  /**
   * 행 삭제 기능
   */
  deleteRow = (sheet: any, sheetId: string) => {
    try {
      if (sheet) {
        const rows = sheet[sheetId].getRowsByChecked('sCheck');

        for (let i = 0; i < rows.length; i++) {
          const row = rows[i];
          const rowId = row.id;
          const isNewlyAdded = row.Added;

          sheet[sheetId].setValue(row, 'sCheck', false);

          if (isNewlyAdded) {
            // 새로 추가된 행은 완전히 삭제
            sheet[sheetId].deleteRow({
              row: row,
              del: 1,
              visible: 0,
            });
            this.removeStateTag(sheet[sheetId], rowId);
          } else {
            // 기존 행은 삭제 표시만
            sheet[sheetId].deleteRow({
              row: row,
              del: 1,
              visible: 1,
            });
            this.setRowState(sheet[sheetId], rowId, CrudCode.DELETE);
          }
        }
      } else {
        console.warn('시트를 찾을 수 없습니다.');
      }
    } catch (err) {
      console.error('시트 접근 실패:', err);
    }
  };

  /**
   * 행 복사 기능 (IBSheet copyRow API 사용)
   */
  copySelectedRows = (sheet: any, sheetId: string) => {
    try {
      if (!sheet) {
        console.warn('시트를 찾을 수 없습니다.');
        return;
      }

      const selectedRows = sheet[sheetId].getRowsByChecked('sCheck');
      
      if (selectedRows.length === 0) {
        console.warn('복사할 행을 선택해주세요.');
        return;
      }

      selectedRows.forEach((selectedRow: any) => {
        const copiedRow = sheet[sheetId].copyRow({
          row: selectedRow,
          next: sheet[sheetId].getLastRow()
        });

        if (copiedRow) {
          this.setRowState(sheet[sheetId], copiedRow.id, CrudCode.CREATE);
        }
      });

    } catch (err) {
      console.error('행 복사 실패:', err);
    }
  };

  /**
   * Excel 다운로드 기능
   */
  excelDownload = (sheet: any, sheetId: string) => {
    try {
      if (sheet) {
        const param = {
          FileName: `${sheetId}_data.xlsx`,
          downCols: 'Visible',
          downRows: 'Visible',
        };
        sheet[sheetId].down2Excel({
          param,
        });
      } else {
        console.warn('시트를 찾을 수 없습니다.');
      }
    } catch (err) {
      console.error('시트 접근 실패:', err);
    }
  };

  /**
   * 상태 관련 리소스 정리
   */
  cleanup = () => {
    setTimeout(() => {
      this.reactRootsRef.current.forEach((root) => {
        try {
          root.unmount();
        } catch (error) {
          console.warn('React root 정리 오류:', error);
        }
      });
      this.reactRootsRef.current.clear();
    }, 0);

    // 상태 초기화
    this.rowStatesRef.current.clear();
  };

  /**
   * 그리드에서 변경된 설정 데이터 추출
   */
  static getChangedConfigData(sheet: any, sheetId: string): GridConfigInfo[] {
    const changedData: GridConfigInfo[] = [];

    if (!sheet || !sheet[sheetId]) return changedData;

    const addedRows = sheet[sheetId].getRowsByStatus('Added');
    const changedRows = sheet[sheetId].getRowsByStatus('Changed');
    const deletedRows = sheet[sheetId].getRowsByStatus('Deleted');

    // 추가된 행들
    addedRows.forEach((row: any) => {
      if (!row.Deleted) {
        changedData.push({
          sState: CrudCode.CREATE,
          pgmId: sheet[sheetId].getValue(row, 'pgmId') || '',
          gridId: sheet[sheetId].getValue(row, 'gridId') || '',
          columnId: sheet[sheetId].getValue(row, 'columnId') || '',
          columnMsgCd: sheet[sheetId].getValue(row, 'columnMsgCd') || '',
          columnMsgCont: sheet[sheetId].getValue(row, 'columnMsgCont') || '',
          description: sheet[sheetId].getValue(row, 'description') || '',
          display: sheet[sheetId].getValue(row, 'display') === 1 ? 'Y' : 'N',
          orderNo: sheet[sheetId].getValue(row, 'orderNo') || '0',
          readonly: sheet[sheetId].getValue(row, 'readonly') === 1 ? 'Y' : 'N',
          align: sheet[sheetId].getValue(row, 'align') || 'left',
          dataType: sheet[sheetId].getValue(row, 'dataType') || 'Text',
          format: sheet[sheetId].getValue(row, 'format') || '',
          comboCd: sheet[sheetId].getValue(row, 'comboCd') || '',
          width: sheet[sheetId].getValue(row, 'width') || '100',
          minWidth: sheet[sheetId].getValue(row, 'minWidth') || '0',
          relWidth: sheet[sheetId].getValue(row, 'relWidth') || '1',
          enumValue: sheet[sheetId].getValue(row, 'enumValue') || '',
          enumKey: sheet[sheetId].getValue(row, 'enumKey') || '',
          etcValue: sheet[sheetId].getValue(row, 'etcValue') || '',
          isMergeYn: sheet[sheetId].getValue(row, 'isMergeYn') === 1 ? 'Y' : 'N',
          treeKeyYn: sheet[sheetId].getValue(row, 'treeKeyYn') === 1 ? 'Y' : 'N',
          isRequired: sheet[sheetId].getValue(row, 'isRequired') === 1 ? 'Y' : 'N',
          maxLength: sheet[sheetId].getValue(row, 'maxLength') || '',
        });
      }
    });

    // 수정된 행들
    changedRows.forEach((row: any) => {
      if (!row.Added && !row.Deleted) {
        changedData.push({
          sState: CrudCode.UPDATE,
          pgmId: sheet[sheetId].getValue(row, 'pgmId') || '',
          gridId: sheet[sheetId].getValue(row, 'gridId') || '',
          columnId: sheet[sheetId].getValue(row, 'columnId') || '',
          columnMsgCd: sheet[sheetId].getValue(row, 'columnMsgCd') || '',
          columnMsgCont: sheet[sheetId].getValue(row, 'columnMsgCont') || '',
          description: sheet[sheetId].getValue(row, 'description') || '',
          display: sheet[sheetId].getValue(row, 'display') === 1 ? 'Y' : 'N',
          orderNo: sheet[sheetId].getValue(row, 'orderNo') || '0',
          readonly: sheet[sheetId].getValue(row, 'readonly') === 1 ? 'Y' : 'N',
          align: sheet[sheetId].getValue(row, 'align') || 'left',
          dataType: sheet[sheetId].getValue(row, 'dataType') || 'Text',
          format: sheet[sheetId].getValue(row, 'format') || '',
          comboCd: sheet[sheetId].getValue(row, 'comboCd') || '',
          width: sheet[sheetId].getValue(row, 'width') || '100',
          minWidth: sheet[sheetId].getValue(row, 'minWidth') || '0',
          relWidth: sheet[sheetId].getValue(row, 'relWidth') || '1',
          etcValue: sheet[sheetId].getValue(row, 'etcValue') || '',
          isMergeYn: sheet[sheetId].getValue(row, 'isMergeYn') === 1 ? 'Y' : 'N',
          treeKeyYn: sheet[sheetId].getValue(row, 'treeKeyYn') === 1 ? 'Y' : 'N',
          isRequired: sheet[sheetId].getValue(row, 'isRequired') === 1 ? 'Y' : 'N',
          maxLength: sheet[sheetId].getValue(row, 'maxLength') || '',
        });
      }
    });

    // 삭제 행들
    deletedRows.forEach((row: any) => {
      if (!row.Added) {
        changedData.push({
          sState: CrudCode.DELETE,
          pgmId: sheet[sheetId].getValue(row, 'pgmId') || '',
          gridId: sheet[sheetId].getValue(row, 'gridId') || '',
          columnId: sheet[sheetId].getValue(row, 'columnId') || ''
        });
      }
    });

    return changedData;
  }

  /**
   * 그리드 변경사항 여부 확인 (정적 메서드)
   */
  static hasChanges(sheet: any, sheetId: string): boolean {
    if (!sheet || !sheet[sheetId]) return false;

    const addedRows = sheet[sheetId].getRowsByStatus('Added');
    const changedRows = sheet[sheetId].getRowsByStatus('Changed');
    const deletedRows = sheet[sheetId].getRowsByStatus('Deleted');

    return addedRows.length > 0 || changedRows.length > 0 || deletedRows.length > 0;
  }

  /**
   * 설정 데이터 유효성 검증
   */
  static validateConfigData(configData: GridConfigInfo[]): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];

    configData.forEach((config, index) => {
      if (!config.columnId.trim()) {
        errors.push(`${index + 1}번째 행: 컬럼ID는 필수입니다.`);
      }
      if (!config.pgmId.trim()) {
        errors.push(`${index + 1}번째 행: 프로그램ID는 필수입니다.`);
      }
      if (!config.gridId.trim()) {
        errors.push(`${index + 1}번째 행: 그리드ID는 필수입니다.`);
      }

      type ValidDataTypes = NonNullable<IbSheetColProperty['Type']>;
      const validDataTypes: ValidDataTypes[] = [
        'Text', 'Lines', 'Int', 'Float', 'Date', 'Button',
        'Link', 'Html', 'Img', 'Enum', 'Radio', 'Bool',
        'Pass', 'File', 'Drag'
      ];
      if (config.dataType && !validDataTypes.includes(config.dataType as any)) {
        errors.push(`${index + 1}번째 행: 유효하지 않은 데이터 타입입니다.`);
      }

      type ValidAlign = NonNullable<IbSheetColProperty['Align']>;
      const validAligns: ValidAlign[] = ['left', 'center', 'right'];
      if (config.align && !validAligns.includes(config.align.toLowerCase() as ValidAlign)) {
        errors.push(`${index + 1}번째 행: 정렬은 left, center, right 중 하나여야 합니다.`);
      }
    });

    // 중복 검증: 프로그램ID + 그리드ID + 컬럼ID 조합이 유일해야 함
    const duplicateErrors = this.validateDuplicateKeys(configData);
    errors.push(...duplicateErrors);

    return {
      isValid: errors.length === 0,
      errors,
    };
  }

  /**
   * 프로그램ID, 그리드ID, 컬럼ID 조합의 중복 검증
   */
  static validateDuplicateKeys(configData: GridConfigInfo[]): string[] {
    const errors: string[] = [];
    const keyMap = new Map<string, number[]>();

    // 삭제 상태가 아닌 데이터만 중복 검증 대상
    const validData = configData.filter(config => config.sState !== CrudCode.DELETE);

    validData.forEach((config, index) => {
      // 필수 값이 모두 있는 경우만 중복 검증
      if (config.pgmId.trim() && config.gridId.trim() && config.columnId.trim()) {
        const key = `${config.pgmId.trim()}|${config.gridId.trim()}|${config.columnId.trim()}`;
        
        if (!keyMap.has(key)) {
          keyMap.set(key, []);
        }
        keyMap.get(key)!.push(index + 1);
      }
    });

    // 중복된 키 찾기
    keyMap.forEach((rowNumbers, key) => {
      if (rowNumbers.length > 1) {
        const [pgmId, gridId, columnId] = key.split('|');
        errors.push(
          `프로그램ID "${pgmId}", 그리드ID "${gridId}", 컬럼ID "${columnId}"의 조합이 중복됩니다. (${rowNumbers.join(', ')}번째 행)`
        );
      }
    });

    return errors;
  }
}
