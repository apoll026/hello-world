import { SheetOptions } from '@/amxis/models/common/Ibsheet';
import { CrudCode } from '@/amxis/models/common/Edit';

export const createConfigGridOptions = (
  onRenderFirstFinish?: () => void,
  onClick?: () => void,
  setRowState?: (sheet: any, rowId: string, state: string) => void,
  reRenderAllStateTags?: (sheet: any) => void,
  rowStatesRef?: React.MutableRefObject<Map<string, string>>
): SheetOptions => ({
  Cfg: {
    CustomScroll: 3, 
    TouchScroll: 3,
    SearchMode: 2,
    HeaderCheck: 1,
    MessageWidth: 300,
    InfoRowConfig: {
      Visible: false,
    },
  },
  Events: {
    onRenderFirstFinish: () => {
      onRenderFirstFinish?.();
    },
    onClick: (evtParam: any) => {
      if (evtParam.col == 'sColMsgCode') onClick?.();
    },
    onRowAdd: (evtParam: any) => {
      evtParam.row['sState'] = CrudCode.CREATE;
    },
    onAfterChange: (paramObject: any) => {
      const sheet = paramObject.sheet;

      if (!setRowState || !rowStatesRef) return;

      // Changed 상태의 행들을 찾아서 수정 태그 렌더링
      const rows = sheet.getRowsByStatus('Changed');
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const rowId = row.id;

        // Added가 아니고 Delete 상태가 아닌 경우에만 수정 상태로 변경
        if (!row.Added && !row.Deleted && rowStatesRef.current.get(rowId) !== CrudCode.DELETE) {
          setRowState(sheet, rowId, CrudCode.UPDATE);
        }
      }
    },
    onAfterSort: (evtParam: any) => {
      const sheet = evtParam.sheet;
      if (reRenderAllStateTags) {
        setTimeout(() => {
          reRenderAllStateTags(sheet);
        }, 100);
      }
    },
    onRenderFinish: (paramObject: any) => {
      const sheet = paramObject.sheet;
      if (reRenderAllStateTags) {
        setTimeout(() => {
          reRenderAllStateTags(sheet);
        }, 50);
      }
    },
  },
  Cols: [
    {
      Header: 'SID',
      Type: 'Text',
      Name: 'sId',
      AddEdit: 1,
      Visible: 0
    },
    {
      Header: { HeaderCheck: 0, Value: '' },
      Type: 'Bool',
      Name: 'sCheck',
      Width: 40,
      CanEdit: 1,
      NoChanged: true,
    },
    {
      Header: '상태',
      Name: 'sState',
      Type: 'Html',
      Width: 60,
      CanEdit: 0
    },
    {
      Header: '프로그램 ID',
      Name: 'pgmId',
      Type: 'Text',
      RelWidth: 1,
      CanEdit: 0,
      AddEdit: 0
    },
    {
      Header: '그리드 ID',
      Name: 'gridId',
      Type: 'Text',
      RelWidth: 1,
      CanEdit: 0,
      AddEdit: 1
    },
    {
      Header: '컬럼 ID',
      Name: 'columnId',
      Type: 'Text',
      RelWidth: 1,
      CanEdit: 1
    },
    {
      Header: '컬럼명 메시지 코드',
      Name: 'columnMsgCd',
      Type: 'Text',
      RelWidth: 1,
      CanEdit: 1
    },
    {
      Header: '메시지 내용-한국어',
      Name: 'columnMsgCont',
      Type: 'Text',
      RelWidth: 1,
      CanEdit: 0
    },
    {
      Header: '컬럼설명',
      Name: 'description',
      Type: 'Text',
      RelWidth: 1,
      CanEdit: 1
    },
    {
      Header: { HeaderCheck: 0, Value: 'Display'},
      Name: 'display',
      Type: 'Bool',
      RelWidth: 1,
      CanEdit: 1,
      AddEdit: 1
    },
    {
      Header: '순번',
      Name: 'orderNo',
      Type: 'Text',
      RelWidth: 1,
      CanEdit: 1
    },
    {
      Header: { HeaderCheck: 0, Value: 'ReadOnly'},
      Name: 'readonly',
      Type: 'Bool',
      RelWidth: 1,
      CanEdit: 1
    },
    {
      Header: '정렬',
      Name: 'align',
      Type: 'Enum',
      RelWidth: 1,
      CanEdit: 1,
      Enum: '|Center|Left|Right',
      EnumKeys: '|Center|Left|Right',
    },
    {
      Header: 'Data Type',
      Name: 'dataType',
      Type: 'Enum',
      RelWidth: 1,
      CanEdit: 1,
      Enum: '|Text|Lines|Int|Float|Date|Button|Link|Html|Img|Enum|Radio|Bool|Pass|File|Drag',
      EnumKeys: '|Text|Lines|Int|Float|Date|Button|Link|Html|Img|Enum|Radio|Bool|Pass|File|Drag',
    },
    {
      Header: 'Data Format',
      Name: 'format',
      Type: 'Text',
      RelWidth: 1,
      CanEdit: 1
    },
    {
      Header: '콤보 Value',
      Name: 'comboCd',
      Type: 'Text',
      RelWidth: 1,
      CanEdit: 1
    },
    {
      Header: '컬럼폭',
      Name: 'width',
      Type: 'Text',
      RelWidth: 1,
      CanEdit: 1
    },
    {
      Header: '최소 컬럼폭',
      Name: 'minWidth',
      Type: 'Text',
      RelWidth: 1,
      CanEdit: 1
    },
    {
      Header: '상대 컬럼폭',
      Name: 'relWidth',
      Type: 'Text',
      RelWidth: 1,
      CanEdit: 1
    },
    {
      Header: { HeaderCheck: 0, Value: '병합여부'},
      Name: 'isMergeYn',
      Type: 'Bool',
      RelWidth: 1,
      CanEdit: 1
    },
    {
      Header: { HeaderCheck: 0, Value: 'TreeGrid Key'},
      Name: 'treeKeyYn',
      Type: 'Bool',
      RelWidth: 1,
      CanEdit: 1
    },
    {
      Header: { HeaderCheck: 0, Value: '필수여부'},
      Name: 'isRequired',
      Type: 'Bool',
      RelWidth: 1,
      CanEdit: 1
    },
    {
      Header: '입력값 길이',
      Name: 'maxLength',
      Type: 'Int',
      RelWidth: 1,
      CanEdit: 1
    },
    {
      Header: '기타 설정값',
      Name: 'etcValue',
      Type: 'Text',
      RelWidth: 8,
      CanEdit: 1
    },
  ],
});
