import { SheetOptions } from '@/amxis/models/common/Ibsheet';
import { cfg } from '@/utils/cfg.ts';

export const createMenuGridOptions = (
  onRowSelect: (menu: any) => void,
  onRenderFirstFinish?: () => void,
  reRenderAllStateTags?: (sheet: any) => void,
): SheetOptions => ({
  // Cfg: {
  //   CustomScroll: 3,
  //   TouchScroll: 3,
  //   SearchMode: 2,
  //   HeaderCheck: 1,
  //   MessageWidth: 300,
  //   InfoRowConfig: {
  //     Visible: false,
  //   },
  //   MainCol:'pgmName'
  // },
  Cfg: cfg('preset1',{
    CustomScroll: 3,
    TouchScroll: 3,
    SearchMode: 2,
    HeaderCheck: 1,
    MessageWidth: 300,
    MainCol:'pgmName'
  }),

  Events: {
    onRenderFirstFinish: () => {
      onRenderFirstFinish?.();
    },
    onAfterClick: ({row}) => {
      onRowSelect(row.pgmId);
    },
    onAfterSort: (evtParam: any) => {
      const sheet = evtParam.sheet;
      if (reRenderAllStateTags) {
        setTimeout(() => {
          reRenderAllStateTags(sheet);
        }, 100);
      }
    },
    onRenderFinish: (paramObject: any) => {
      const sheet = paramObject.sheet;
      if (reRenderAllStateTags) {
        setTimeout(() => {
          reRenderAllStateTags(sheet);
        }, 50);
      }
    },
  },
  Cols: [
    {
      Header: '프로그램 명',
      Name: 'pgmName',
      Type: 'Text',
      Width: 300,
      Align: 'Left',
      CanEdit: 0,
    },
    {
      Header: '프로그램 ID',
      Name: 'pgmId',
      Type: 'Text',
      Width: 300,
      Align: 'Center',
      CanEdit: 0,
    },
    {
      Header: '프로그램 URL',
      Type: 'Text',
      Name: 'pgmUrl',
      RelWidth: 1,
      CanEdit: 0,
    },
    {
      Header: '순번',
      Name: 'seq',
      Type: 'Text',
      Width: 60,
      Align: 'Center',
      CanEdit: 0,
    },
    {
      Header: '프로그램 메뉴 구분',
      Name: 'pmFlag',
      Type: 'Enum',
      Enum: '|P|M',
      Width: 150,
      Align: 'Center',
      CanEdit: 0,
    },
    {
      Header: '사용여부',
      Name: 'useYn',
      Type: 'Enum',
      Enum: '|Y|N',
      Width: 100,
      Align: 'Center',
      CanEdit: 0,
    },
  ],
});
