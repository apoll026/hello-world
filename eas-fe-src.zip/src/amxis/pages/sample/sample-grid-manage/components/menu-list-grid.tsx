import React, { useRef, useEffect, useMemo, forwardRef, useImperativeHandle } from 'react';
import IBSheetGrid, { IBSheetGridRef } from '@/amxis/components/ibsheet8/ibsheet-grid';
import { useGridManageStore } from '@/amxis/stores/useGridManageStore';
import { createMenuGridOptions } from '../constants/menu-grid-options';
import { MenuInfo } from '../types/grid-manage.types';

interface MenuListGridProps {
  data: MenuInfo[];
  onMenuSelect: (pgmId: string) => void;
}

const MenuListGrid = forwardRef<IBSheetGridRef, MenuListGridProps>(({ data, onMenuSelect }, ref) => {
  const gridRef = useRef<IBSheetGridRef>(null);
  
  const { 
    isMenuGridReady, 
    setMenuGridReady
  } = useGridManageStore();

  useImperativeHandle(ref, () => ({
    getSheet: () => gridRef.current?.getSheet() || null,
  }));

  const handleRowSelect = (pgmId) => {
    onMenuSelect(pgmId);
  };

  const gridOptions = useMemo(() =>
    createMenuGridOptions(
      handleRowSelect,
      () => setMenuGridReady(true)
    ),
    [setMenuGridReady]
  );

  useEffect(() => {
    if (!isMenuGridReady || !data || data.length === 0) return;

    const sheet = gridRef.current?.getSheet();
    if (sheet) {
      sheet['menuGrid'].loadSearchData(data, 0);
      sheet['menuGrid'].showTreeLevel(1,0,1);
    }
  }, [isMenuGridReady, data]);

  return (
    <IBSheetGrid
      ref={gridRef}
      id="menuGrid"
      el="menu-grid-el"
      options={gridOptions}
      total={data.length}
      title="프로그램 목록"
      isHeaderSectionEnabled={true}
      height="300px"
    />
  );
});

MenuListGrid.displayName = 'MenuListGrid';

export default MenuListGrid;