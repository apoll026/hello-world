import React, { useEffect } from 'react';
import { Box, Typography, Divider, Stack } from '@mui/material';
import { Button, FormItem, InputField, SearchArea } from '@amxis/design-system';
import { Grid } from '@mui/material';
import { Controller, useForm } from 'react-hook-form';
import { ButtonGroup, Spacer } from '@/amxis/components/layout';
import MenuListGrid from './components/menu-list-grid';
import GridConfigurationGrid from './components/grid-configuration-grid';
import { useMenuListGrid } from './hooks/use-menu-list-grid';
import { useGridConfigGrid } from './hooks/use-grid-config-grid';
import { useGridManageStore } from '@/amxis/stores/useGridManageStore';
import { MenuSearchCondition } from './types/grid-manage.types';
import { useRef } from 'react';
import { IBSheetGridRef } from '@/amxis/components/ibsheet8/ibsheet-grid';

const GridManagePage = () => {
  const menuGridRef = useRef<IBSheetGridRef>(null);
  const configGridRef = useRef<IBSheetGridRef>(null);
  
  const { selectedMenu, setSearchCondition,reset } = useGridManageStore();
  
  const {
    menuData,
    menuTreeData,
    loading: menuLoading,
    handleMenuSelect,
  } = useMenuListGrid();

  const {
    configData,
    loading: configLoading,
  } = useGridConfigGrid();

  const { handleSubmit, control } = useForm<MenuSearchCondition>({
    defaultValues: {
      pgmId: '',
      pgmName: '',
      useYn: '',
    },
  });

  useEffect(() => {
    return () => {
      reset();
    };
  }, [reset]);

  const handleSearch = handleSubmit(async (searchCondition) => {
    setSearchCondition(searchCondition);
  });

  const handleKeyPress = (event: React.KeyboardEvent) => {
    if (event.key === 'Enter') {
      handleSearch();
    }
  };

  const handleDebugInfo = () => {
    console.log('=== 전체 디버그 정보 ===');
    console.log('선택된 메뉴:', selectedMenu);
    console.log('메뉴 데이터:', menuData);
    console.log('설정 데이터:', configData);
    console.log('로딩 상태:', { menuLoading, configLoading });
    
    const menuSheet = menuGridRef.current?.getSheet();
    const configSheet = configGridRef.current?.getSheet();
    
    if (menuSheet) {
      console.log('\n=== 메뉴 그리드 정보 ===');
      console.log('메뉴 그리드 행 개수:', menuSheet['menuGrid']?.getRowCount?.() || 0);
    }
    
    if (configSheet) {
      console.log('\n=== 설정 그리드 정보 ===');
      console.log('설정 그리드 행 개수:', configSheet['configGrid']?.getRowCount?.() || 0);
    }
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%', p: 2 }}>
      {/* 페이지 제목 */}
      <Typography variant="h4" sx={{ mb: 2 }}>
        그리드 관리 페이지
      </Typography>
      
      {/* 검색 영역 */}
      <Box width="100%">
        <SearchArea
          searchButtonLabel="조회"
          conditions={
            <>
              <Grid item xs={4}>
                <FormItem
                  label="프로그램 ID"
                  labelAlign="right"
                  render={() => (
                    <Controller
                      control={control}
                      name="pgmId"
                      render={({ field }) => (
                        <InputField
                          fullWidth
                          value={field.value || ''}
                          onChange={field.onChange}
                          size="medium"
                          placeholder="프로그램 ID를 입력하세요"
                          onKeyPress={handleKeyPress}
                        />
                      )}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={4}>
                <FormItem
                  label="메뉴명"
                  labelAlign="right"
                  render={() => (
                    <Controller
                      control={control}
                      name="pgmName"
                      render={({ field }) => (
                        <InputField
                          fullWidth
                          value={field.value || ''}
                          onChange={field.onChange}
                          size="medium"
                          placeholder="메뉴명을 입력하세요"
                          onKeyPress={handleKeyPress}
                        />
                      )}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={4}>
                <FormItem
                  label="사용여부"
                  labelAlign="right"
                  render={() => (
                    <Controller
                      control={control}
                      name="useYn"
                      render={({ field }) => (
                        <InputField
                          fullWidth
                          value={field.value || ''}
                          onChange={field.onChange}
                          size="medium"
                          placeholder="Y 또는 N"
                          onKeyPress={handleKeyPress}
                        />
                      )}
                    />
                  )}
                />
              </Grid>
            </>
          }
          onSearch={handleSearch}
        />
      </Box>

      <Spacer type="h" size="16" />

      <Stack spacing={2}>
        {/* 상단 그리드 - 메뉴 목록 */}
        <MenuListGrid
          ref={menuGridRef}
          data={menuTreeData}
          onMenuSelect={handleMenuSelect}
        />
        <Divider />
        {/* 하단 그리드 - 그리드 설정 */}
        <GridConfigurationGrid
          ref={configGridRef}
          data={configData}
        />
        
      </Stack>

      <Spacer type="h" size="16" />

      {/* 저장 버튼 영역 */}
      <ButtonGroup>
        <Button
          appearance="outlined"
          size="medium"
          onClick={handleDebugInfo}
        >
          디버그 정보
        </Button>
      </ButtonGroup>
    </Box>
  );
};

export default GridManagePage;