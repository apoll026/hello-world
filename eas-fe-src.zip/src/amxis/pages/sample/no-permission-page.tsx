import { Label } from '@amxis/design-system';
import { Box } from '@mui/material';

export const NoPermissionPage = () => {
  return (
    <Box my="24px">
        <Label labelText="Router에는 등록이 되어있지만 권한이 없는 화면" isRequired />
    </Box>
  );
};
