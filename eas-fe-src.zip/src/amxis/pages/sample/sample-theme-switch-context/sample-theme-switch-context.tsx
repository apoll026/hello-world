import { useTheme } from '@amxis/design-system/hooks';
import { Box } from '@mui/material';
import { Button, Switch } from '@amxis/design-system';
import { useState } from 'react';

export const ThemeSwitchContextSample = () => {
  const [_, toggleTheme] = useTheme();
  const [checked, setChecked] = useState(true);
  return (
    <Box display={'flex'} alignItems={'center'} gap={1}>
      <h4>Switch Theme</h4>
      <Box>
        <Switch
          type="contained-icon"
          checked={checked}
          onClick={() => {
            setChecked(!checked);
            toggleTheme();
          }}
        />
      </Box>
      <Button
        appearance="contained"
        onClick={() => {
          toggleTheme({ resetToSystem: true });
        }}
        buttonLabel={'reset to system theme'}
      />
    </Box>
  );
};
