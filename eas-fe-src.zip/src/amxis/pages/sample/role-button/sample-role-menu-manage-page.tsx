import { CommonResponse } from '@/amxis/models/common/RestApi.ts';
import { ContainerLayout } from '@/amxis/components/container-layout';
import { SamplePageTitle } from '@/amxis/pages/sample/__components/sample-page-title.tsx';
import { Box, Grid, RadioGroup, Typography } from '@mui/material';
import { DocumentContentH2 } from '@/amxis/pages/sample/__components/document-content-h2.tsx';
import {
  $semantic,
  Button,
  DropdownField,
  DropdownOption,
  FormItem,
  InputField,
  Radio,
  SearchArea,
  useMessageBar,
  useTheme,
} from '@amxis/design-system';
import { ContainerBox } from '@/amxis/pages/sample/__components/container-box.tsx';
import { useState } from 'react';

import { Spacer } from '@/amxis/components/layout';
import { getSession } from '@/amxis/apis/Session';
import useSessionStore from '@/amxis/stores/useSessionStore';
import { upsertAuthMenu } from '@/amxis/apis/sample/AuthMenuSampleApi';
import { AuthMenuRequest } from '@/amxis/models/admin/Menu';
import { changeSessionMenus } from '@/amxis/apis/admin/MenuApi';
import { t } from 'i18next';
import { DocumentContentH3 } from '../__components/document-content-h3';
import { Controller } from 'react-hook-form';
import { AuthButtonWrapper, AuthComponentWrapper } from '@/amxis/components/role-button-wrapper';
import { MenuAuth } from '@/amxis/models/common/MenuAuth';
import { useMenuContext } from '@/amxis/components/menu-provider';

const SampleAuthMenuManagePage = () => {
  const [theme] = useTheme();
  const { auth, setSession } = useSessionStore();
  const { menus } = useSessionStore();
  console.log(menus);
  const { currentMenu } = useMenuContext();
  const menu = menus?.find((menu) => menu.pgmId === currentMenu.pgmId);
  const pgmAuth = menu?.pgmAuth;
  const { showMessageBar } = useMessageBar();
  const [value1, setValue1] = useState<DropdownOption | null>(null);
  const ColorType = {
    PRIMARY: `${$semantic.light.color.commonBgPrimary}`,
    SECONDARY: `${$semantic.light.color.commonBgSecondary}`,
    BASIC: `${$semantic.light.color.legendBasicBgColorANormal}`,
    NORMAL: `${$semantic.light.color.legendBasicBgColorCNormal}`,
    LEGEND: `${$semantic.light.color.legendBasicBgColorCNormal}`,
  } as const;
  const MOCK_SELECTIONS_DEFAULT: DropdownOption[] = [
    {
      value: '1',
      label: '조회+Excel+출력',
      statusColor: ColorType.PRIMARY,
      figures: 8,
    },
    {
      value: '2',
      label: '조회+Excel',
      statusColor: ColorType.SECONDARY,
      figures: 9,
    },
    {
      value: '3',
      label: '조회',
      statusColor: ColorType.BASIC,
      figures: 8,
    },
    {
      value: '4',
      label: '메뉴 숨김',
      statusColor: ColorType.BASIC,
      figures: 8,
    },
  ];
  return (
    <ContainerBox>
      <ContainerLayout>
        <SamplePageTitle>화면권한샘플</SamplePageTitle>
        <Box mt="48px" />
        <DocumentContentH2 title="화면권한관리샘플" />
        <DocumentContentH3 title="화면권한관리샘플 화면 설명" />
        <Typography
          variant="body2"
          sx={{ color: theme.palette.semantic.color.commonTextBasic, whiteSpace: 'pre-line' }}
        >
          {"아래의 Dropdown으로 프로그램'화면권한테스트샘플'의 화면 권한을 제어할 수 있습니다." +
            "\n이중 '메뉴 숨김'옵션은 사용자의 프로그램'화면권한테스트샘플'에 대한 접근 권한을 회수하여 좌측 메뉴란에서 제거합니다."}
        </Typography>
        <Box display="flex" flexDirection="column" width="40%">
          <Box>
            <DropdownField
              isInput={false}
              options={MOCK_SELECTIONS_DEFAULT}
              placeholder="Placeholder"
              usecase="key-in"
              onChange={(_, value) => {
                setValue1(value as DropdownOption);
              }}
              value={value1}
              useClearIcon
              size="medium"
            />
          </Box>
          <Spacer type="h" size="16" />
          <Box display="flex" justifyContent="flex-end">
            <Button
              size="large"
              appearance="contained"
              priority="normal"
              onClick={async () => {
                if (value1?.value === undefined) {
                  alert('undefined가 있습니다.');
                  return;
                }
                const authMenuRequest: AuthMenuRequest = {
                  pgmId: 'EAS_AM000135',
                  pgmAuth: value1?.value,
                  auth: auth,
                };
                const response: CommonResponse | null = await upsertAuthMenu(authMenuRequest);
                if (response.data === 1) {
                  showMessageBar({
                    message: t('common.alert.저장되었습니다.', '저장되었습니다.'),
                    usecase: 'success',
                  });
                  await changeSessionMenus().then(async () => {
                    const response = await getSession();
                    if (response.successOrNot === 'Y' && response?.data) {
                      const session = response.data;
                      setSession(session);
                    }
                  });
                } else {
                  showMessageBar({
                    message: t('common.alert.저장에 실패하였습니다.', '저장에 실패하였습니다.'),
                    usecase: 'success',
                  });
                }
              }}
            >
              저장
            </Button>
          </Box>
        </Box>
      </ContainerLayout>
    </ContainerBox>
  );
};

export default SampleAuthMenuManagePage;
