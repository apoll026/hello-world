import { TitleArea, Breadcrumb, InputField, Button, Divider } from '@amxis/design-system';
import { ControlResetIcon, FileExceldownloadIcon } from '@amxis/design-system/icon';
import { $semantic } from '@amxis/design-system/design-token';
import { Box, Typography } from '@mui/material';
import { useState } from 'react';

const LEGENDS = [
  { color: $semantic.light.color.legendStatusBgConfirmedNormal, label: '일정준수' },
  { color: $semantic.light.color.legendStatusBgWarningMinorNormal, label: '지연주의' },
  { color: $semantic.light.color.legendStatusBgErrorNormal, label: '지연' },
  { color: $semantic.light.color.legendStatusBorderColorDoneNormal, label: '완료' },
  { color: 'transparent', label: '계획중' },
];

export const SampleTitleArea = () => {
  const [bookmark, setBookmark] = useState(false);
  return (
    <>
      <TitleArea
        title="Default Title Area"
        bookmark={bookmark}
        onFavorite={() => setBookmark(!bookmark)}
        isSubTitle={false}
        bullet={false}
      ></TitleArea>
      <Divider sx={{ my: '12px' }} />
      <TitleArea
        title="화면 타이틀"
        isSubTitle={false}
        bullet
        bookmark
        searchAreaSwitch
        breadcrumb={
          <Breadcrumb
            limitWidth="100"
            data={[
              {
                label: 'Home',
                url: '/home',
                onClick: () => console.log('home'),
              },
              {
                label: 'Child1asdfffffffffff',
                url: '/child1',
                onClick: () => console.log('child1'),
              },
              {
                label: 'Page Nameasdfffffffffffffffffffffvwe',
              },
            ]}
          />
        }
      />
      <Divider sx={{ my: '12px' }} />
      <TitleArea
        title="서브타이틀"
        language="en"
        totalCases={32}
        isSubTitle
        helpertext={{
          infoText: 'Info Text (optional)',
          leadingIcon: true,
          sx: { '.MuiBox-root': { display: 'flex' } },
        }}
        filter={
          <InputField
            type="search"
            usecase="text"
            options={[{ label: 'Item', value: 'Item' }]}
            size="small"
            placeholder="Placeholder"
          />
        }
        rightButtons={
          <>
            <Button
              appearance="outlined"
              buttonLabel="다운로드"
              iconComponent={<FileExceldownloadIcon iconSize={16} />}
              iconPosition="leading"
              priority="normal"
              size="small"
              sx={{ ml: '4px' }}
            />
            <Button
              appearance="outlined"
              buttonLabel="새로고침"
              iconComponent={<ControlResetIcon size="default" iconSize={16} />}
              iconPosition="leading"
              priority="normal"
              size="small"
            />
          </>
        }
      >
        <Box display="flex" alignItems="center" gap="8px" mr="4px">
          {LEGENDS.map((item) => (
            <Box key={item.label} display="flex" alignItems="center" gap="4px">
              <Box
                width="12px"
                height="12px"
                borderRadius="50%"
                bgcolor={item.color}
                border={
                  item.label === '계획중'
                    ? `1px solid ${$semantic.light.color.legendStatusBorderColorDoneStrong}`
                    : 'none'
                }
              ></Box>
              <Typography color={$semantic.light.color.commonTextLight} typography="bodySmall">
                {item.label}
              </Typography>
            </Box>
          ))}
        </Box>
      </TitleArea>
    </>
  );
};
