import { ControlResetIcon } from '@amxis/design-system/icon';
import {
  DropdownField,
  FormItem,
  InputField,
  SearchArea,
  Button,
  Chip,
  DropdownOption,
} from '@amxis/design-system';
import { Box, Grid } from '@mui/material';
import { useState } from 'react';

type SearchConditionType1 = {
  required1?: DropdownOption | null;
  required2?: DropdownOption[];
  general1?: string;
  general2?: { option?: DropdownOption | null; text?: string };
  additional1?: DropdownOption | null;
  additional2?: DropdownOption[];
  additional3?: string;
  additional4?: string;
  additional5?: string;
  additional6?: { option?: DropdownOption | null; text?: string };
};

type MyOptionType = {
  optionName: string;
  condition: SearchConditionType1;
};

export const SampleSearchArea = () => {
  const initalCondition: SearchConditionType1 = {
    required1: null,
    required2: [],
    general1: '',
    general2: { option: null, text: '' },
    additional1: null,
    additional2: [],
    additional3: '',
    additional4: '',
    additional5: '',
    additional6: { option: null, text: '' },
  };
  const [searchCondition1, setSearchCondition1] = useState<SearchConditionType1>(initalCondition);
  const [myOptions, setMyOptions] = useState<MyOptionType[]>([]);

  return (
    <Box display={'flex'} flexDirection={'column'} rowGap={5} mt={5}>
      <Box width={'1168px'}>
        <SearchArea
          searchButtonLabel={"검색"}
          myOptions={myOptions.length !== 0 ? myOptions.map((o) => o.optionName) : undefined}
          onSearch={() => console.log('조회조건 : ' + JSON.stringify(searchCondition1))}
          onResetCondition={() => {
            console.log('조회조건 reset');
            setSearchCondition1(initalCondition);
          }}
          onSaveOption={() => {
            if (myOptions.length !== 4) {
              console.log('조회조건 저장 : ' + JSON.stringify(searchCondition1));
              setMyOptions([
                ...myOptions,
                {
                  optionName: 'MyOption' + (myOptions.length + 1),
                  condition: searchCondition1,
                },
              ]);
            }
          }}
          onSelectedMyOption={(v) => {
            console.log(v?.toString());
            setSearchCondition1(myOptions.filter((o) => o.optionName === v)[0].condition);
          }}
          conditions={
            <>
              <Grid item xs={4}>
                <FormItem
                  required
                  label="필수 조회조건 01"
                  labelAlign="right"
                  render={({ status }) => (
                    <DropdownField
                      fullWidth
                      status={status}
                      options={[
                        { label: 'Item', value: 'Item' },
                        { label: 'Item1', value: 'Item1' },
                        { label: 'Item2', value: 'Item2' },
                        { label: 'Item3', value: 'Item3' },
                      ]}
                      size="medium"
                      placeholder="Selected Option"
                      onChange={(_e, v) =>
                        setSearchCondition1({ ...searchCondition1, required1: v as DropdownOption })
                      }
                      value={searchCondition1.required1}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={4}>
                <FormItem
                  required
                  label="필수 조회조건 02"
                  labelAlign="right"
                  render={({ status }) => (
                    <InputField
                      type="search"
                      usecase="chip-single"
                      fullWidth
                      status={status}
                      options={[
                        { label: 'Keyword', value: 'Keyword' },
                        { label: 'Keyword1', value: 'Keyword1' },
                        { label: 'Keyword2', value: 'Keyword2' },
                        { label: 'Keyword3', value: 'Keyword3' },
                      ]}
                      size="medium"
                      placeholder="Selected Option"
                      onChange={(_e, v) =>
                        setSearchCondition1({
                          ...searchCondition1,
                          required2: v as DropdownOption[],
                        })
                      }
                      value={searchCondition1.required2}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={4}>
                <FormItem
                  label="일반 조회조건 01"
                  labelAlign="right"
                  render={({ status }) => (
                    <Box display="flex" alignItems="center" gap="4px">
                      <InputField
                        type="text"
                        fullWidth
                        status={status}
                        size="medium"
                        placeholder="입력하세요."
                        onChange={(e) =>
                          setSearchCondition1({ ...searchCondition1, general1: e.target.value })
                        }
                        value={searchCondition1.general1}
                      />
                      <Button
                        size="medium"
                        priority="normal"
                        appearance="outlined"
                        iconComponent={<ControlResetIcon size="default" iconSize={20} />}
                        onClick={() => {
                          setSearchCondition1({ ...searchCondition1, general1: '' });
                        }}
                      />
                    </Box>
                  )}
                />
              </Grid>
              <Grid item xs={8}>
                <FormItem
                  label="일반 조회조건 02"
                  labelAlign="right"
                  render={({ status }) => (
                    <Box display="flex" alignItems="center" gap="4px">
                      <DropdownField
                        fullWidth
                        sx={{ width: 'calc(100% / 3)' }}
                        status={status}
                        options={[
                          { label: 'Item', value: 'Item' },
                          { label: 'Item1', value: 'Item1' },
                          { label: 'Item2', value: 'Item2' },
                          { label: 'Item3', value: 'Item3' },
                        ]}
                        size="medium"
                        placeholder="Selected Option"
                        onChange={(_e, v) =>
                          setSearchCondition1({
                            ...searchCondition1,
                            general2: {
                              text: searchCondition1.general2?.text,
                              option: v as DropdownOption,
                            },
                          })
                        }
                        value={searchCondition1.general2?.option}
                      />
                      <InputField
                        sx={{ width: 'calc(100% / 3 * 2)' }}
                        type="text"
                        fullWidth
                        status={status}
                        size="medium"
                        placeholder="입력하세요."
                        onChange={(e) =>
                          setSearchCondition1({
                            ...searchCondition1,
                            general2: {
                              text: e.target.value,
                              option: searchCondition1.general2?.option,
                            },
                          })
                        }
                        value={searchCondition1.general2?.text}
                      />
                    </Box>
                  )}
                />
              </Grid>
            </>
          }
          extraConditions={
            <>
              <Grid item xs={4}>
                <FormItem
                  label="추가조회 01"
                  labelAlign="right"
                  render={({ status }) => (
                    <DropdownField
                      fullWidth
                      status={status}
                      options={[
                        { label: 'Item', value: 'Item' },
                        { label: 'Item1', value: 'Item1' },
                        { label: 'Item2', value: 'Item2' },
                        { label: 'Item3', value: 'Item3' },
                      ]}
                      size="medium"
                      placeholder="Selected Option"
                      onChange={(_e, v) =>
                        setSearchCondition1({
                          ...searchCondition1,
                          additional1: v as DropdownOption,
                        })
                      }
                      value={searchCondition1.additional1}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={4}>
                <FormItem
                  label="추가조회 02"
                  labelAlign="right"
                  render={({ status }) => (
                    <InputField
                      type="search"
                      usecase="chip-single"
                      fullWidth
                      status={status}
                      options={[
                        { label: 'Keyword', value: 'Keyword' },
                        { label: 'Keyword1', value: 'Keyword1' },
                        { label: 'Keyword2', value: 'Keyword2' },
                        { label: 'Keyword3', value: 'Keyword3' },
                      ]}
                      size="medium"
                      placeholder="Selected Option"
                      onChange={(_e, v) =>
                        setSearchCondition1({
                          ...searchCondition1,
                          additional2: v as DropdownOption[],
                        })
                      }
                      value={searchCondition1.additional2}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={4}>
                <FormItem
                  label="추가조회 03"
                  labelAlign="right"
                  render={({ status }) => (
                    <InputField
                      type="text"
                      fullWidth
                      status={status}
                      size="medium"
                      placeholder="입력하세요."
                      onChange={(e) =>
                        setSearchCondition1({ ...searchCondition1, additional3: e.target.value })
                      }
                      value={searchCondition1.additional3}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={4}>
                <FormItem
                  label="추가조회 04"
                  labelAlign="right"
                  render={({ status }) => (
                    <InputField
                      type="text"
                      fullWidth
                      status={status}
                      size="medium"
                      placeholder="입력하세요."
                      onChange={(e) =>
                        setSearchCondition1({ ...searchCondition1, additional4: e.target.value })
                      }
                      value={searchCondition1.additional4}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={8}>
                <FormItem
                  label="추가조회 05"
                  labelAlign="right"
                  render={() => (
                    <Box display="flex" alignItems="center" gap="4px" flexWrap="wrap">
                      <Chip
                        type="choice"
                        chipText="Option001"
                        size="medium"
                        selected={searchCondition1.additional5 === 'Option001'}
                        onClick={() =>
                          setSearchCondition1({ ...searchCondition1, additional5: 'Option001' })
                        }
                      />
                      <Chip
                        type="choice"
                        chipText="Option002"
                        size="medium"
                        selected={searchCondition1.additional5 === 'Option002'}
                        onClick={() =>
                          setSearchCondition1({ ...searchCondition1, additional5: 'Option002' })
                        }
                      />
                      <Chip
                        type="choice"
                        chipText="Option003"
                        size="medium"
                        selected={searchCondition1.additional5 === 'Option003'}
                        onClick={() =>
                          setSearchCondition1({ ...searchCondition1, additional5: 'Option003' })
                        }
                      />
                      <Chip
                        type="choice"
                        chipText="Option004"
                        size="medium"
                        selected={searchCondition1.additional5 === 'Option004'}
                        onClick={() =>
                          setSearchCondition1({ ...searchCondition1, additional5: 'Option004' })
                        }
                      />
                    </Box>
                  )}
                />
              </Grid>
              <Grid item xs={8}>
                <FormItem
                  label="추가조회 06"
                  labelAlign="right"
                  render={({ status }) => (
                    <Box display="flex" alignItems="center" gap="4px">
                      <DropdownField
                        sx={{ width: 'calc(100% / 3)' }}
                        status={status}
                        options={[
                          { label: 'Item', value: 'Item' },
                          { label: 'Item1', value: 'Item1' },
                          { label: 'Item2', value: 'Item2' },
                          { label: 'Item3', value: 'Item3' },
                        ]}
                        size="medium"
                        placeholder="Selected Option"
                        onChange={(_e, v) =>
                          setSearchCondition1({
                            ...searchCondition1,
                            additional6: {
                              option: v as DropdownOption,
                              text: searchCondition1.additional6?.text,
                            },
                          })
                        }
                        value={searchCondition1.additional6?.option}
                      />
                      <InputField
                        type="text"
                        sx={{ width: 'calc(100% / 3 * 2)' }}
                        status={status}
                        size="medium"
                        placeholder="입력하세요."
                        onChange={(e) =>
                          setSearchCondition1({
                            ...searchCondition1,
                            additional6: {
                              text: e.target.value,
                              option: searchCondition1.additional6?.option,
                            },
                          })
                        }
                        value={searchCondition1.additional6?.text}
                      />
                    </Box>
                  )}
                />
              </Grid>
            </>
          }
        />
      </Box>
      <Box width={'720px'}>
        <SearchArea
          conditions={
            <>
              <Grid item xs={6}>
                <FormItem
                  required
                  label="필수 조회조건 01"
                  labelAlign="right"
                  render={({ status }) => (
                    <DropdownField
                      fullWidth
                      status={status}
                      options={[
                        { label: 'Item', value: 'Item' },
                        { label: 'Item1', value: 'Item1' },
                        { label: 'Item2', value: 'Item2' },
                        { label: 'Item3', value: 'Item3' },
                      ]}
                      size="medium"
                      placeholder="Selected Option"
                    />
                  )}
                />
              </Grid>
              <Grid item xs={6}>
                <FormItem
                  required
                  label="필수 조회조건 02"
                  labelAlign="right"
                  render={({ status }) => (
                    <InputField
                      type="search"
                      usecase="chip-single"
                      fullWidth
                      status={status}
                      options={[
                        { label: 'Keyword', value: 'Keyword' },
                        { label: 'Keyword1', value: 'Keyword1' },
                        { label: 'Keyword2', value: 'Keyword2' },
                        { label: 'Keyword3', value: 'Keyword3' },
                      ]}
                      size="medium"
                      placeholder="Selected Option"
                    />
                  )}
                />
              </Grid>

              <Grid item xs={12}>
                <FormItem
                  label="일반 조회조건 02"
                  labelAlign="right"
                  render={({ status }) => (
                    <Box display="flex" alignItems="center" gap="4px">
                      <DropdownField
                        fullWidth
                        sx={{ width: 'calc(100% / 3)' }}
                        status={status}
                        options={[
                          { label: 'Item', value: 'Item' },
                          { label: 'Item1', value: 'Item1' },
                          { label: 'Item2', value: 'Item2' },
                          { label: 'Item3', value: 'Item3' },
                        ]}
                        size="medium"
                        placeholder="Selected Option"
                      />
                      <InputField
                        sx={{ width: 'calc(100% / 3*2)' }}
                        type="text"
                        fullWidth
                        status={status}
                        size="medium"
                        placeholder="입력하세요."
                      />
                    </Box>
                  )}
                />
              </Grid>
            </>
          }
        />
      </Box>
      <Box width={'1003px'}>
        <SearchArea
          conditions={
            <>
              <Grid item xs={8}>
                <FormItem
                  required
                  label="필수 조회조건 01"
                  labelAlign="right"
                  render={({ status }) => (
                    <Box display="flex" alignItems="center" gap="4px">
                      <DropdownField 
                        fullWidth
                        sx={{ width: 'calc(100% / 3)' }}
                        status={status}
                        options={[
                          { label: 'Item', value: 'Item' },
                          { label: 'Item1', value: 'Item1' },
                          { label: 'Item2', value: 'Item2' },
                          { label: 'Item3', value: 'Item3' },
                        ]}
                        size="medium"
                        placeholder="Selected Option"
                      />
                      <InputField
                        sx={{ width: 'calc(100% / 3*2)' }}
                        type="text"
                        fullWidth
                        status={status}
                        size="medium"
                        placeholder="입력하세요."
                      />
                    </Box>
                  )}
                />
              </Grid>
              <Grid item xs={4}>
                <FormItem
                  required
                  label="필수 조회조건2"
                  labelAlign="right"
                  render={({ status }) => (
                    <InputField
                      type="text"
                      fullWidth
                      status={status}
                      size="medium"
                      placeholder="입력하세요."
                    />
                  )}
                />
              </Grid>
              <Grid item xs={4}>
                <FormItem
                  label="조건3"
                  labelAlign="right"
                  render={({ status }) => (
                    <InputField
                      type="text"
                      fullWidth
                      status={status}
                      size="medium"
                      placeholder="입력하세요."
                    />
                  )}
                />
              </Grid>
              <Grid item xs={4}>
                <FormItem
                  label="조건4"
                  labelAlign="right"
                  render={({ status }) => (
                    <InputField
                      type="text"
                      fullWidth
                      status={status}
                      size="medium"
                      placeholder="입력하세요."
                    />
                  )}
                />
              </Grid>
              <Grid item xs={4}>
                <FormItem
                  label="조건5"
                  labelAlign="right"
                  render={({ status }) => (
                    <InputField
                      type="text"
                      fullWidth
                      status={status}
                      size="medium"
                      placeholder="입력하세요."
                    />
                  )}
                />
              </Grid>
            </>
          }
        />
      </Box>
    </Box>
  );
};
