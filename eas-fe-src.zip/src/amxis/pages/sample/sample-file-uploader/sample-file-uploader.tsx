import { Box, Typography } from '@mui/material';
import { FileInfoType, FileUploader, FileUploaderReadonly } from '@amxis/design-system';
import React, { useState } from 'react';

export const SampleFileUploader = () => {
  const [selectedFiles1, setSelectedFiles1] = useState<FileInfoType[]>([]);
  const [selectedFiles2, setSelectedFiles2] = useState<FileInfoType[]>([]);
  const [selectedFiles3, setSelectedFiles3] = useState<FileInfoType[]>([]);

  const handleFileOnChange1 = (files: FileInfoType[]) => {
    setSelectedFiles1(files);
  };

  const handleFileOnChange2 = (files: FileInfoType[]) => {
    setSelectedFiles2(files);
  };

  const handleFileOnChange3 = (files: FileInfoType[]) => {
    setSelectedFiles3(files);
  };

  return (
    <Box>
      <Typography variant="h2">FileUploader</Typography>
      <Typography variant="h5">variant: default</Typography>
      <FileUploader
        variant="default"
        acceptFiles={['.pdf', '.svg', '.png', '.jpg']}
        selectedFiles={[
          { tag: { text: '기안/통신지', color: 'colorA' }, name: 'aaaaaaaaa.zip', size: 12344, url: '' },
          { tag: { text: '기타증빙', color: 'colorB' }, name: 'bbbbbbbbbbbb.pdf', size: 2345, url: '' },
          { tag: { text: '세금계산서', color: 'colorC' }, name: 'cccccccccccc.txt', size: 345636, url: '' },
          { name: 'dddddddddddd.pdf', size: 234, url: '' },
        ]}
        onFileChange={handleFileOnChange1}
      />
      <br />

      <Typography variant="h5">variant: thumbnail</Typography>
      <FileUploader
        variant="thumbnail"
        acceptFiles={['.pdf', '.svg', '.png', '.jpg']}
        selectedFiles={selectedFiles2}
        onFileChange={handleFileOnChange2}
      />
      <br />

      <Typography variant="h5">variant: namo</Typography>
      <FileUploader
        variant="namo"
        acceptFiles={['.pdf', '.svg', '.png', '.jpg']}
        selectedFiles={selectedFiles3}
        onFileChange={handleFileOnChange3}
      />
      <br />
      <br />

      <Typography variant="h2">FileUploaderReadonly</Typography>
      <FileUploaderReadonly
        selectedFiles={[
          { tag: { text: '기안/통신지', color: 'colorA' }, name: 'aaaaaaaaaaa.zip', size: 12344, url: '' },
          { tag: { text: '기타증빙', color: 'colorB' }, name: 'bbbbbbbbbbbb.pdf', size: 2345, url: '' },
          { tag: { text: '세금계산서', color: 'colorC' }, name: 'cccccccccccc.txt', size: 345636, url: '' },
          { name: 'dddddddddddddd.pdf', size: 234, url: '' },
        ]}
        onFileClick={(_fileName: string, _fileUrl: string) => {
        }}
      />
      <br />
    </Box>
  );
};
