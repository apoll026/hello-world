import { ContainerLayout } from '@/amxis/components/container-layout';
import { SamplePageTitle } from '@/amxis/pages/sample/__components/sample-page-title.tsx';
import { Box } from '@mui/material';
import {
  Button,
  Description,
  DetailTableDataCell,
  DetailTableHeaderCell,
  DetailTableLine,
  DetailTableRow,
  InputField,
  Label,
  TitleArea,
} from '@amxis/design-system';
import { ContainerBox } from '@/amxis/pages/sample/__components/container-box.tsx';
import { useState } from 'react';
import { callPatuahApi } from '@/amxis/apis/common/Patuah.ts';
import { PatuahResult } from '@/amxis/models/common/PatuahResult.ts';

export const PatuahTestPage = () => {
  const [reqCorpNum, setReqCorpNum] = useState<string>('1148198234');
  const [result, setResult] = useState<PatuahResult | null>(null);

    const handleCallApi = async () => {

    try {
      const response = await callPatuahApi(reqCorpNum);
      setResult(response.data ?? null);
    } catch (e) {
      console.error(e);
    }

  }

  return (
    <ContainerBox>
      <ContainerLayout>
        <SamplePageTitle>Patuah 연동</SamplePageTitle>
        <Box mt="48px" />

        <Box>
          <TitleArea title="Request" isSubTitle />
          <DetailTableLine>
            <DetailTableRow>
              <DetailTableHeaderCell>
                <Label labelText="사업자 번호" isRequired={true} />
              </DetailTableHeaderCell>
              <DetailTableDataCell>
                <Box>
                  <InputField
                    fullWidth
                    onChange={(event) => {
                      setReqCorpNum(event?.target?.value)
                    }}
                    id="reqCorpNum"
                    value={reqCorpNum}
                    size="medium"
                    status="default"
                    textAlign="left"
                    type="text"
                    placeholder={'reqCorpNum'}
                  />
                </Box>
              </DetailTableDataCell>
            </DetailTableRow>
          </DetailTableLine>
          <Box mt="24px" />
          <TitleArea title="Response" isSubTitle />
          <DetailTableLine>
            <DetailTableRow>
              <DetailTableHeaderCell>
                <Label labelText="일련번호" />
              </DetailTableHeaderCell>
              <DetailTableDataCell>
                <Box>
                  <InputField
                    fullWidth
                    id="seq"
                    value={result?.seq ?? ''}
                    size="medium"
                    status="default"
                    textAlign="left"
                    type="text"
                    readOnly={true}
                    placeholder={'seq'}
                  />
                </Box>
              </DetailTableDataCell>
            </DetailTableRow>
            <DetailTableRow>
              <DetailTableHeaderCell>
                <Label labelText="사업자 번호" />
              </DetailTableHeaderCell>
              <DetailTableDataCell>
                <Box>
                  <InputField
                    fullWidth
                    id="corpNum"
                    value={result?.corpNum ?? ''}
                    size="medium"
                    status="default"
                    textAlign="left"
                    type="text"
                    readOnly={true}
                    placeholder={'corpNum'}
                  />
                </Box>
              </DetailTableDataCell>
            </DetailTableRow>
            <DetailTableRow>
              <DetailTableHeaderCell>
                <Label labelText="사업자 유형" />
              </DetailTableHeaderCell>
              <DetailTableDataCell>
                <Box>
                  <InputField
                    fullWidth
                    id="vatKind"
                    value={result?.vatKind ?? ''}
                    size="medium"
                    status="default"
                    textAlign="left"
                    type="text"
                    readOnly={true}
                    placeholder={'vatKind'}
                  />
                </Box>
                <Description
                  title="유형"
                  usecase="normal"
                  ordered={false}
                  listData={[
                    {
                      content: '1 : 일반',
                    },
                    {
                      content: '2 : 간이',
                    },
                    {
                      content: 'A : 간이(세금계산서 발급 사업자)',
                    },
                    {
                      content: '3 : 면세',
                    },
                    {
                      content: '4 : 휴업',
                    },
                    {
                      content: '5 : 폐업',
                    },
                    {
                      content: '6 : 비영리',
                    },
                    {
                      content: '9 : 알수없음',
                    },
                  ]}
                />
              </DetailTableDataCell>
            </DetailTableRow>
            <DetailTableRow>
              <DetailTableHeaderCell>
                <Label labelText="휴폐업일자" />
              </DetailTableHeaderCell>
              <DetailTableDataCell>
                <Box>
                  <InputField
                    fullWidth
                    id="closeDate"
                    value={result?.closeDate ?? ''}
                    size="medium"
                    status="default"
                    textAlign="left"
                    type="text"
                    readOnly={true}
                    placeholder={'closeDate'}
                  />
                </Box>
              </DetailTableDataCell>
            </DetailTableRow>
          </DetailTableLine>
        </Box>
        <Box mt="24px">
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'flex-start',
              gap: '4px',
            }}
          >
            <Button size="large" appearance="contained" priority="normal" onClick={handleCallApi}>
              API 호출
            </Button>
          </Box>
        </Box>
      </ContainerLayout>
    </ContainerBox>
  );
};
