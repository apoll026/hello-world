import React, { useEffect, useState } from 'react';
import { Box, Typography } from '@mui/material';
import { $semantic, Checkbox, CheckboxProps } from '@amxis/design-system';

export const SampleCheckbox = () => {
  const SAMPLE_CHECKBOX_ITEMS: CheckboxProps[] = [
    {
      id: 'checkBox1',
      labelText: 'option1',
      value: 'option1',
    },
    {
      id: 'checkBox2',
      labelText: 'option2',
      value: 'option2',
    },
    {
      id: 'checkBox3',
      labelText: 'option3',
      value: 'option3',
    },
  ];
  const [checkboxItems, setCheckboxItems] = useState<CheckboxProps[]>(SAMPLE_CHECKBOX_ITEMS);
  const [headerChecked, setHeaderChecked] = useState<boolean>();
  const [selectedValue, setSelectedValue] = useState<string>();

  const handleHeaderOnChange = (checked: boolean) => {
    setCheckboxItems(checkboxItems.map((item) => ({ ...item, checked: checked })));
  };

  const handleOnChange = (id: string, checked: boolean) => {
    setCheckboxItems(
      checkboxItems.map((item) => (item.id === id ? { ...item, checked: checked } : item))
    );
  };

  useEffect(() => {
    const checkedItems = checkboxItems
      .filter((item) => {
        return item.checked;
      })
      .map((item) => {
        return item.value;
      });
    setHeaderChecked(checkedItems.length === checkboxItems.length);
    setSelectedValue(checkedItems.join(', '));
  }, [checkboxItems]);

  return (
    <Box>
      <Typography variant="bodySmall">{`[${selectedValue}]`}</Typography>
      <Box display="flex" gap={`${$semantic.shared.size.sizesCommon.size12}px`}>
        <Checkbox
          // readOnly
          // disabled
          labelText="전체"
          checked={headerChecked}
          indeterminate={
            !checkboxItems.every((item) => item.checked) &&
            !checkboxItems.every((item) => !item.checked)
          }
          onChange={handleHeaderOnChange}
        />
        {checkboxItems.map((item) => {
          return (
            <Checkbox
              key={item.id}
              value={item.value}
              labelText={item.labelText}
              checked={item.checked}
              onChange={(checkedStatus) => handleOnChange(item.id ?? '', checkedStatus)}
            />
          );
        })}
      </Box>
      <br />

      <Typography variant="h5">status: default</Typography>
      <Box display="flex" gap={`${$semantic.shared.size.sizesCommon.size12}px`}>
        <Checkbox labelText="전체" checked={true} indeterminate={true} />
        <Checkbox labelText="default1" checked={true} />
        <Checkbox labelText="default2" checked={false} />
      </Box>
      <br />

      <Typography variant="h5">status: disabled</Typography>
      <Box display="flex" gap={`${$semantic.shared.size.sizesCommon.size12}px`}>
        <Checkbox disabled labelText="전체" checked={true} indeterminate={true} />
        <Checkbox disabled labelText="disabled1" checked={true} />
        <Checkbox disabled labelText="disabled2" checked={false} />
      </Box>
      <br />

      <Typography variant="h5">status: readOnly</Typography>
      <Box display="flex" gap={`${$semantic.shared.size.sizesCommon.size12}px`}>
        <Checkbox readOnly labelText="전체" checked={true} indeterminate={true} />
        <Checkbox readOnly labelText="readOnly1" checked={true} />
        <Checkbox readOnly labelText="readOnly2" checked={false} />
      </Box>
      <br />
    </Box>
  );
};
