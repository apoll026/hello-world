import { Switch } from '@amxis/design-system';
import { Box } from '@mui/material';
import { useState } from 'react';
import { $scale, $semantic } from '@amxis/design-system/design-token';

export const SampleSwitch = () => {
  const [check, setChecked] = useState(true);
  const [check2, setChecked2] = useState(true);
  return (
    <Box my="24px">
      <Switch type="basic" />
      <Switch type="basic" color="secondary" checked={check} onChange={() => setChecked(!check)} />
      <Switch label="Result" type="basic" color="primary" />
      <Switch type="contained-label" />
      <Switch type="contained-label" text="secondary" checkedText="secondary" color="secondary" />
      <Switch type="contained-label" text="선택" checkedText="필수" />
      <Switch
        type="contained-label"
        text="미사용"
        checkedText="사용중"
        checked={check2}
        onChange={() => setChecked2(!check2)}
      />
      <Switch type="contained-label" text="텍스트가길어졌을때" checkedText="텍스트가길어졌을때" />
      <Switch type="contained-icon" />

      <Box sx={{ padding: '30px' }}>
        <Switch type="contained-label" text="primary" checkedText="primary" color="primary" />
        <Switch type="contained-label" text="secondary" checkedText="secondary" color="secondary" />
      </Box>
      <Box
        sx={{
          padding: '30px',
          width: '30px',
          height: '30px',
          backgroundColor: 'semantic.color.commonBgSecondary',
        }}
      ></Box>
      <Box
        sx={{
          padding: '30px',
          width: '30px',
          height: '30px',
          backgroundColor: 'semantic.color.controlFilledBgPrimary',
        }}
      ></Box>
      <Box
        sx={{
          padding: '30px',
          width: '30px',
          height: '30px',
          backgroundColor: 'semantic.color.controlLinedBorderPrimaryActive',
        }}
      ></Box>
    </Box>
  );
};
