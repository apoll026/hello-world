import { Box, Typography, useTheme } from '@mui/material';
import { SummaryCard } from 'amxis/pages/template/home/components/SummaryCard/SummaryCard.tsx';
import MainBg from '@/amxis/assets/images/home4/main_bg.png';
import { BoardCard } from '@/amxis/pages/template/home/components/BoardCard/BoardCard.tsx';
import { Spacer } from '@/amxis/components/layout';
import React from 'react';
import { LinkCard } from '@/amxis/pages/template/home/components/LinkCard/LinkCard.tsx';
import { Container } from '../../template/home/components/Container';
import useMainPage from './use-main-page';

export const MainPage = () => {
  const {
    palette: {
      semantic: { color },
    },
  } = useTheme();
  const {
    mainContactList,
    mainLinkCardItems,
    mainSummaryCardItems,
    noticeMainDataList,
    noticeBbsDataList,
  } = useMainPage();

  return (
    <Container>
      {/* Banner */}
      <Box
        sx={{
          height: '166px',
          padding: '0 25px 0 40px',
          backgroundImage: `url(${MainBg})`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          borderRadius: '16px',
        }}
      >
        {/* 왼쪽 영역 */}
        <Box display="flex" flexDirection="column" gap="8px">
          <Typography fontWeight={700} fontSize="24px" color={color.commonTextLight}>
            전자전표시스템
          </Typography>
          <Box
            sx={{
              width: '32px',
              height: '2px',
              backgroundColor: `${color.commonTextNormal}`,
              borderRadius: '999px',
              mx: '8px',
            }}
          />
          <Typography fontWeight={400} fontSize="16px" color={color.commonTextNormal}>
            Electronic Accounting System
          </Typography>
        </Box>

        {/* 오른쪽 영역 */}
        <Box display="flex" gap="24px" textAlign="right" color={color.commonTextNormal}>
          {mainContactList.map((list, index) => (
            <Box key={index} display="flex" gap="2px">
              <Typography variant="h6">{list.part}</Typography>

              <Box display="flex" flexDirection="column" gap="6px">
                {list.contacts.map((contact, index) => (
                  <Typography key={index} variant="h6" fontWeight={400}>
                    {contact}
                  </Typography>
                ))}
              </Box>
            </Box>
          ))}
        </Box>
      </Box>
      <Spacer type="h" size="40" />

      <Box display="flex" gap="40px">
        <Box display="flex" flexDirection="column" gap="40px" flex={1}>
          {/* Summary Card */}
          <Box display="grid" gridTemplateColumns="repeat(3, 1fr)" gap="8px">
            {mainSummaryCardItems?.map((item, index) => (
              <SummaryCard key={index} {...item} />
            ))}
          </Box>

          {/* Link Card */}
          <Box display="flex" gap="1px" flex={1}>
            {mainLinkCardItems.map((item, index) => (
              <LinkCard
                key={index}
                {...item}
                isFirst={index === 0}
                isLast={index === mainLinkCardItems.length - 1}
              />
            ))}
          </Box>
        </Box>

        {/* Board Card */}
        <Box display="flex" flexDirection="column" gap="20px" width="428px" height="545px">
          <BoardCard sx={{ height: '56.3%' }} {...noticeMainDataList} />
          <BoardCard sx={{ height: '43.7%' }} {...noticeBbsDataList} />
        </Box>
      </Box>
    </Container>
  );
};
