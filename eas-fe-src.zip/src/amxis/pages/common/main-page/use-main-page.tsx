import Summary1 from '@/amxis/assets/images/home4/summary1.svg';
import Summary2 from '@/amxis/assets/images/home4/summary2.svg';
import Summary3 from '@/amxis/assets/images/home4/summary3.svg';
import Summary4 from '@/amxis/assets/images/home4/summary4.svg';
import Summary5 from '@/amxis/assets/images/home4/summary5.svg';
import Summary6 from '@/amxis/assets/images/home4/summary6.svg';
import { cardBackgrounds } from './main-page-css';
import { useMainPageQuery } from '@/amxis/hooks/queries/main-page/use-main-page-query';
import useSessionStore from '@/amxis/stores/useSessionStore';
import { useTranslation } from 'react-i18next';
import {
  ControlAddIcon,
  EditEdit2Icon,
  FileDocument2Icon,
  StatusConfirmedIcon,
} from '@amxis/design-system/icon';
import { useNavigate } from 'react-router-dom';
import { useMainNoticeQuery } from '@/amxis/hooks/queries/main-page/use-main-notice-query';
import { useEffect, useState } from 'react';
import { useMainBbsQuery } from '@/amxis/hooks/queries/main-page/use-main-bbs-query';
import { ILinkCard } from '../../template/home/components/LinkCard/LinkCard';
import { ISummaryCardItem } from '../../template/home/components/SummaryCard/SummaryCard';
import { IBoardCard, IBoardCardItem } from '../../template/home/components/BoardCard/BoardCard';

const useMainPage = () => {
  const { t } = useTranslation();
  const { empNo } = useSessionStore();
  const [noticeDataList, setNoticeDataList] = useState<IBoardCardItem[]>();
  const [bbsDataList, setBbsDataList] = useState<IBoardCardItem[]>();
  const { data: fetchedMainCountData } = useMainPageQuery(empNo);
  const { data: fetchedMainNoticeData } = useMainNoticeQuery();
  const { data: fetchedMainBbsData } = useMainBbsQuery();
  const navigate = useNavigate();

  const onClickSummaryCard = (url: string) => {
    navigate(url);
  };

  useEffect(() => {
    const noticeTransferDataList = fetchedMainNoticeData?.map(
      ({ noticeNo, noticeTitle, dataUpdDtm }) => ({
        id: noticeNo,
        title: noticeTitle,
        rightText: dataUpdDtm,
      })
    );
    setNoticeDataList(noticeTransferDataList);
  }, [fetchedMainNoticeData]);

  useEffect(() => {
    const bbsTransferDataList = fetchedMainBbsData?.map(({ bbsNo, bbsTitle }) => ({
      id: bbsNo,
      title: bbsTitle,
      leftTag: <FileDocument2Icon appearance="lined" iconSize={16} />,
      // rightText: dataUpdDtm,
    }));
    setBbsDataList(bbsTransferDataList);
  }, [fetchedMainBbsData]);

  // 공통코드 호출에서 데이터 가져오기
  const mainContactList = [
    {
      part: '건축주택 >',
      contacts: [
        '외주사업 : 강주헌(4453)',
        '일반건축 : 김세은(6225)',
        '정비사업 : 김진우(1030)',
        '공공/PFV : 방창현(2143)',
      ],
    },
    {
      part: '플랜트 :',
      contacts: ['이동일(3265)', '이효상(3529)', '정보현(3873)'],
    },
    {
      part: '인프라/신사업 :',
      contacts: ['황성준(2086)', '공석영(3783)'],
    },
  ];

  const mainSummaryCardItems: ISummaryCardItem[] = [
    {
      title: t('main.label.매입세금계산서\n미처리', '매입세금계산서\n미처리'),
      background: cardBackgrounds.ORANGE,
      imgUrl: Summary1,
      shadow: 'none',
      total: fetchedMainCountData?.unprocPurTaxCnt,
      onClickTotal: () => {
        onClickSummaryCard(`/sample/layouts`);
      },
    },
    {
      title: t('main.label.법인카드\n미처리', '법인카드\n미처리'),
      background: cardBackgrounds.ORANGE,
      imgUrl: Summary2,
      shadow: 'none',
      total: fetchedMainCountData?.cardUnprCnt,
      onClickTotal: () => {
        onClickSummaryCard(`/sample/nolayout`);
      },
    },
    {
      title: t('main.label.입력중인\n전표', '입력중인\n전표'),
      background: cardBackgrounds.BLUE,
      imgUrl: Summary3,
      shadow: 'none',
      total: fetchedMainCountData?.vchrTempCnt,
      onClickTotal: () => {
        onClickSummaryCard(`/sample/components`);
      },
    },
    {
      title: t('main.label.반송된\n전표', '반송된\n전표'),
      background: cardBackgrounds.BLUE,
      imgUrl: Summary4,
      shadow: 'none',
      total: fetchedMainCountData?.reApprCnt,
      onClickTotal: () => {
        onClickSummaryCard(`/sample/popup`);
      },
    },
    {
      title: t('main.label.결재중인\n전표', '결재중인\n전표'),
      background: cardBackgrounds.BLUE,
      imgUrl: Summary5,
      shadow: 'none',
      total: fetchedMainCountData?.apprPndgCnt,
      onClickTotal: () => {
        onClickSummaryCard(`/sample/file-upload`);
      },
    },
    {
      title: '결재대기\n문서',
      background: cardBackgrounds.BLUE,
      imgUrl: Summary6,
      shadow: 'none',
      total: fetchedMainCountData?.apprCnt,
      onClickTotal: () => {
        onClickSummaryCard(`/sample/excel-manage`);
      },
    },
  ];

  const mainLinkCardItems: ILinkCard[] = [
    {
      icon: <EditEdit2Icon appearance="lined" iconSize={24} />,
      title: t('main.label.권한 신청', '권한 신청'),
      onClickArrow: () => {
        onClickSummaryCard(`/sample/email-send`);
      },
    },
    {
      icon: <StatusConfirmedIcon appearance="lined" iconSize={24} />,
      title: t('main.label.내 권한 확인', '내 권한 확인'),
      onClickArrow: () => {
        onClickSummaryCard(`/sample/sso-test`);
      },
    },
  ];

  const noticeMainDataList: IBoardCard = {
    title: '공지사항',
    actions: [
      {
        icon: <ControlAddIcon size="small" iconSize={20} />,
        text: '더보기',
        onTakeAction: () => {
          onClickSummaryCard('/sm/notice');
        },
      },
    ],
    listItems: noticeDataList ?? [],
    targetUrl: '/sm/notice/detail/',
  };

  const noticeBbsDataList: IBoardCard = {
    title: '재경업무 처리요령',
    actions: [
      {
        icon: <ControlAddIcon size="small" iconSize={20} />,
        text: '더보기',
        onTakeAction: () => {
          onClickSummaryCard('/sm/bbs');
        },
      },
    ],
    listItems: bbsDataList ?? [],
    targetUrl: '/sm/bbs/detail/',
  };

  return {
    mainContactList,
    mainLinkCardItems,
    mainSummaryCardItems,
    noticeMainDataList,
    noticeBbsDataList,
  };
};

export default useMainPage;
