import { Button, useTheme } from '@amxis/design-system';
import { Box } from '@mui/system';
import { Link } from 'react-router-dom';
import useSessionStore from '@/amxis/stores/useSessionStore.ts';
import { Typography } from '@mui/material';

function HomePage() {
  const [theme] = useTheme();
  const { mailId } = useSessionStore();

  const isLogin = Boolean(mailId);

  return (
    <Box height="100%" p="32px" bgcolor={theme.palette.semantic.color.commonBgDeeper}>
      <Box>
        {isLogin ? (
          <>
            <Typography variant="h2">Home Page</Typography>
          </>
        ) : (
          <Link to="/login">
            <Button type="button" appearance="contained">
              Go to Login Page
            </Button>
          </Link>
        )}
      </Box>
    </Box>
  );
}

export { HomePage };
