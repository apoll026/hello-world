export enum MenuAuth {
  ONE = '1', //저장, 삭제 
  TWO = '2', //엑셀, 출력
  THREE = '3', //조회
}
