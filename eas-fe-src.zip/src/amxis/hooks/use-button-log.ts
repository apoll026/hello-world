import { ButtonLogRequestVo } from '@/amxis/models/admin/ButtonLog.ts';
import { ColDef, DataGridCellTooltip, DateRangePickerValueType } from '@amxis/design-system';
import dayjs from 'dayjs';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { keepPreviousData } from '@tanstack/react-query';
import { z } from 'zod';
import { isValidDateRangePickerValue } from '@/amxis/utils/DateUtil.ts';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import useLanguageStore from '@/amxis/stores/useLanguageStore.ts';
import { useButtonLogsQuery } from './queries/log/use-button-logs-query.ts';

type ButtonLogSearchForm = {
  dates: DateRangePickerValueType;
  searchItem?: string;
};

const useButtonLogs = () => {
  const { t } = useTranslation();
  const { currentLanguage } = useLanguageStore();
  const [pageSize, setPageSize] = useState(20);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchCondition, setSearchCondition] = useState<ButtonLogRequestVo>({
    contDtmFr: dayjs().add(-1, 'month').format('YYYYMMDD').toString(),
    contDtmTo: dayjs().format('YYYYMMDD').toString(),
    searchItem: '',
    pageSize: '20',
    start: '0',
  });

  const { data: fetchedButtonLogs } = useButtonLogsQuery(searchCondition, {
    placeholderData: keepPreviousData,
  });

  const DataRangePickerValue = z.custom<{ arg: DateRangePickerValueType }>(
    (val) => {
      return isValidDateRangePickerValue(val);
    },
    {
      message: `${t(
        'menu-log.label.접속일자를 다시 선택해 주세요',
        '__접속일자를 다시 선택해 주세요'
      )}`,
    }
  );

  const buttonLogSearchSchema = z.object({
    dates: DataRangePickerValue,
    searchItem: z.string().optional(),
  });

  const {
    handleSubmit,
    control,
    formState: { errors },
    getValues,
  } = useForm<ButtonLogSearchForm>({
    resolver: zodResolver(buttonLogSearchSchema),
    defaultValues: {
      dates: [dayjs().add(-1, 'month'), dayjs()],
      searchItem: '',
    },
  });

  const handleSearch = handleSubmit(async ({ dates, searchItem }) => {
    setSearchCondition({
      ...searchCondition,
      contDtmFr:
        dayjs(dates ? dates[0] : getValues('dates')[0])
          .format('YYYYMMDD')
          .toString() || '',
      contDtmTo:
        dayjs(dates ? dates[1] : getValues('dates')[1])
          .format('YYYYMMDD')
          .toString() || '',
      searchItem: searchItem || '',
      start: '0',
    });
    setCurrentPage(1);
  });

  const defaultColum: ColDef = {
    cellStyle: { textAlign: 'center' },
    flex: 1,
    sortable: false,
  };

  const columnDefs: ColDef[] = [
    {
      cellStyle: {
        textAlign: 'center',
      },
      field: 'contDtm',
      headerName: String(t('button.log.column.접근 일시', '__일시')),
      width: 200,
    },

    {
      headerName: String(t('code.label.버튼코드', '__버튼코드')),
      colId: 'btnCd',
      field: 'btnCd',
      width: 150,
    },
    {
      cellStyle: {
        textAlign: 'center',
      },
      field: 'empName',
      headerName: String(t('button.log.column.사용자명', '__사용자명')),
      width: 150,
    },
    {
      cellStyle: {
        textAlign: 'center',
      },
      field: 'contIp',
      headerName: String(t('button.log.접속IP', '__접속IP')),
      width: 200,
    },
  ];

  return {
    searchCondition,
    setSearchCondition,
    columnDefs,
    defaultColum,
    handleSearch,
    errors,
    currentLanguage,
    pageSize,
    setPageSize,
    currentPage,
    setCurrentPage,
    fetchedButtonLogs,
    control,
  };
};

export default useButtonLogs;
