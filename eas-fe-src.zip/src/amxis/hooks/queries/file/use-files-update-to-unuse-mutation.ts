import { modifyFilesToUnuseByGrIdAndFileId } from '@/amxis/apis/admin/FileUpload.ts';
import { useReactMutation } from '@/amxis/hooks/use-react-mutation.ts';
import { FileId } from '@/amxis/models/admin/FileId.ts';

function useFilesToUnuseUpdateMutation(url?: string) {
  return useReactMutation((idList: FileId[]) => {
    return modifyFilesToUnuseByGrIdAndFileId(idList, url);
  });
}

export { useFilesToUnuseUpdateMutation };
